package bg.demax.document.storage.dtos;

import java.util.Date;

public class AlterDocumentDto {
    private byte[] hash;
    private Date expiration;
    private Boolean pubRead;
    private Boolean pubExpDate;
    
    public byte[] getHash() {
        return hash;
    }
    public void setHash(byte[] hash) {
        this.hash = hash;
    }
    public Date getExpiration() {
        return expiration;
    }
    public void setExpiration(Date expiration) {
        this.expiration = expiration;
    }
    public Boolean getPubRead() {
        return pubRead;
    }
    public void setPubRead(Boolean pubRead) {
        this.pubRead = pubRead;
    }
    public Boolean getPubExpDate() {
        return pubExpDate;
    }
    public void setPubExpDate(Boolean pubExpDate) {
        this.pubExpDate = pubExpDate;
    }

}
