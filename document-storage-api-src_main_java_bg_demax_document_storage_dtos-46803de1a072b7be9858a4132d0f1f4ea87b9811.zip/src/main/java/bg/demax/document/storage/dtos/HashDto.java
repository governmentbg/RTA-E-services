package bg.demax.document.storage.dtos;

public class HashDto {
    byte[] hash;

    public byte[] getHash() {
        return hash;
    }

    public void setHash(byte[] hash) {
        this.hash = hash;
    }        
}
