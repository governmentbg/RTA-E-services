package bg.demax.document.storage.dtos;

import java.util.Date;

public class LoadDocumentDto {
    private byte[] hash;
    private byte[] data;
    private Date expiration;
    private Boolean pubRead;
    private Boolean pubExpDate;
    private int userId;

    public byte[] getHash() {
        return hash;
    }
    public void setHash(byte[] hash) {
        this.hash = hash;
    }
    public byte[] getData() {
        return data;
    }
    public void setData(byte[] data) {
        this.data = data;
    }
    public Date getExpiration() {
        return expiration;
    }
    public void setExpiration(Date expiration) {
        this.expiration = expiration;
    }

    public Boolean getPubRead() {
        return pubRead;
    }
    public void setPubRead(Boolean pubRead) {
        this.pubRead = pubRead;
    }
    public Boolean getPubExpDate() {
        return pubExpDate;
    }
    public void setPubExpDate(Boolean pubExpDate) {
        this.pubExpDate = pubExpDate;
    }
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
}
