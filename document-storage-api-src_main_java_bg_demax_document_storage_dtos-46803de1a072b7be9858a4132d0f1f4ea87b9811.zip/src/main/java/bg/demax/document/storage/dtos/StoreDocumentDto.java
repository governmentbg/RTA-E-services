package bg.demax.document.storage.dtos;

import java.util.Date;

public class StoreDocumentDto {
    byte[] data;
    Date expiration;

    public byte[] getData() {
        return data;
    }
    public void setData(byte[] data) {
        this.data = data;
    }
    public Date getExpiration() {
        return expiration;
    }
    public void setExpiration(Date expiration) {
        this.expiration = expiration;
    }
}
