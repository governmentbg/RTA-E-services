package bg.demax.documentsrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "bg.demax")
public class DocumentStorageRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocumentStorageRestApplication.class, args);
	}

}
