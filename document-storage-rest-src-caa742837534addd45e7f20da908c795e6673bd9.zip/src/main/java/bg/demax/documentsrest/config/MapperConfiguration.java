package bg.demax.documentsrest.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import bg.demax.documentsrest.dbobjects.Document;
import bg.demax.documentsrest.dbobjects.DocumentInfo;
import bg.demax.documentsrest.repository.AutomaticResultSetDataMapper;

@Configuration
public class MapperConfiguration {
	@Bean
	public AutomaticResultSetDataMapper<Document> getDocumentRowMapper() {
		return new AutomaticResultSetDataMapper<Document>(new Document());
	}

	@Bean
	public AutomaticResultSetDataMapper<DocumentInfo> getDocumentInfoRowMapper() {
		return new AutomaticResultSetDataMapper<DocumentInfo>(new DocumentInfo());
	}
}
