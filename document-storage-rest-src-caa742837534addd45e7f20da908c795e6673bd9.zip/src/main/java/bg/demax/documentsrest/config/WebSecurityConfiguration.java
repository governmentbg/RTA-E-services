package bg.demax.documentsrest.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;
import org.springframework.security.web.authentication.preauth.RequestHeaderAuthenticationFilter;

import bg.demax.documentsrest.security.UserDetailsServiceImpl;


@Configuration
@EnableWebSecurity
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

	private static final String PRE_AUTH_HEADER_NAME = "X-Client-Certificate";

    @Autowired
	private UserDetailsServiceImpl userDetailsService;

	@Autowired
	private AuthenticationEntryPoint authenticationEntryPoint;

	@Autowired
	private AccessDeniedHandler accessDeniedHandler;

	@Bean
	public AuthenticationManager authenticationManager() {
		return new ProviderManager(Arrays.asList(preAuthenticatedAuthenticationProvider()));
	}

	private PreAuthenticatedAuthenticationProvider preAuthenticatedAuthenticationProvider() {
		PreAuthenticatedAuthenticationProvider provider = new PreAuthenticatedAuthenticationProvider();

		provider.setPreAuthenticatedUserDetailsService(userDetailsService);

		return provider;
	}

	private AbstractPreAuthenticatedProcessingFilter preAuthenticatedProcessingFilter() {
		RequestHeaderAuthenticationFilter filter = new RequestHeaderAuthenticationFilter();

		filter.setPrincipalRequestHeader(PRE_AUTH_HEADER_NAME);
		filter.setAuthenticationManager(authenticationManager());
		filter.setExceptionIfHeaderMissing(false);

		return filter;
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
		.csrf().disable()
		.addFilterAt(preAuthenticatedProcessingFilter(), AbstractPreAuthenticatedProcessingFilter.class)
		.exceptionHandling()
			.accessDeniedHandler(accessDeniedHandler)
			.authenticationEntryPoint(authenticationEntryPoint);

		authRequestsAndAddMatchers(http);

		http.authorizeRequests().anyRequest().authenticated();
	}

	private ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry authRequestsAndAddMatchers(
			HttpSecurity httpSecurity) throws Exception {

		return httpSecurity.authorizeRequests()
				.mvcMatchers("/swagger-ui.html", "/webjars/**", "/swagger-resources/**", "/v2/**").permitAll()
				.mvcMatchers(HttpMethod.GET, "/chip**").hasAnyRole("GENERIC_USER");
	}

}
