package bg.demax.documentsrest.controller;

import java.nio.file.AccessDeniedException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.document.storage.dtos.AlterDocumentDto;
import bg.demax.document.storage.dtos.HashDto;
import bg.demax.document.storage.dtos.LoadDocumentDto;
import bg.demax.document.storage.dtos.StoreDocumentDto;
import bg.demax.documentsrest.service.DocumentService;

@RestController
@RequestMapping("/document")
public class DocumentController {

	@Autowired
	private DocumentService documentService;

	@GetMapping("/{hash}")
	public LoadDocumentDto getDocumentForHash(@PathVariable(value = "hash") String hash) throws AccessDeniedException {
		LoadDocumentDto dto = documentService.getDocumentDto(hash);
		return dto;
	}

	@GetMapping("/filter_non_existing/")
	public List<HashDto> returnExistingHashes(@RequestBody List<HashDto> hashes) throws AccessDeniedException {
		List<HashDto> dto = documentService.filterNonExisting(hashes);
		return dto;
	}

	@PostMapping(consumes = "application/json", produces = "application/json")
	public HashDto storeDocument(@RequestBody StoreDocumentDto request) {
		return documentService.storeDocumentDto(request);
	}

	@PutMapping(consumes = "application/json", produces = "application/json")
	public HashDto alterDocument(@RequestBody AlterDocumentDto request) {
		return documentService.alterDocumentDto(request);
	}

	@DeleteMapping(consumes = "application/json", produces = "application/json")
	public void deleteDocument(@RequestBody HashDto request) throws AccessDeniedException {
		documentService.deleteDocumentDto(request);
	}
}
