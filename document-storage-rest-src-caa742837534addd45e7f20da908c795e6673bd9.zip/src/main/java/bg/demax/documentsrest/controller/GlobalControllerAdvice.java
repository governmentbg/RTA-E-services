package bg.demax.documentsrest.controller;

import java.util.Collections;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import bg.demax.documentsrest.dto.ApplicationExceptionDto;


@RestControllerAdvice
public class GlobalControllerAdvice extends ResponseEntityExceptionHandler {
	private static final Logger logger = LogManager.getLogger();

	@ExceptionHandler(RuntimeException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public ApplicationExceptionDto handleRuntimeException(RuntimeException ex, HttpServletRequest request) {
		logger.log(Level.DEBUG, ex);
		return convertException(ex, request);
	}

	private ApplicationExceptionDto convertException(RuntimeException ex, HttpServletRequest request) {
		setResponseTypeToJson(request);
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError(ex.getClass().getSimpleName());
		String message = ex.getMessage();
		dto.setMessage(message);
		return dto;
	}

	private void setResponseTypeToJson(HttpServletRequest request) {
		request.setAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE,
				Collections.singleton(MediaType.APPLICATION_JSON));
	}
}
