package bg.demax.documentsrest.dbobjects;

import java.util.Date;

public class DocumentInfo {
    private byte[] hash;
    private int userId;
    private Date expiration;
    private Boolean pubRead;
    private Boolean pubExpDate;

    public Boolean getPubRead() {
        return pubRead;
    }
    public void setPubRead(Boolean pubRead) {
        this.pubRead = pubRead;
    }
    public Boolean getPubExpDate() {
        return pubExpDate;
    }
    public void setPubExpDate(Boolean pubExpDate) {
        this.pubExpDate = pubExpDate;
    }
    public byte[] getHash() {
        return hash;
    }
    public void setHash(byte[] hash) {
        this.hash = hash;
    }
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public Date getExpiration() {
        return expiration;
    }
    public void setExpiration(Date expiration) {
        this.expiration = expiration;
    }    
}
