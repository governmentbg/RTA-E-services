package bg.demax.documentsrest.repository;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

public class AutomaticResultSetDataMapper<T> implements RowMapper<T> {

	private T instance;

	public AutomaticResultSetDataMapper(T instance) {
		this.instance = instance;
	}

	public T mapResultSet(ResultSet resultSet)
			throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException,
			NoSuchMethodException, SecurityException, SQLException {

		T dto = (T) instance.getClass().newInstance();

		List<Method> methods = Arrays.asList(dto.getClass().getDeclaredMethods());
		for (Method Method : methods) {
			Method.setAccessible(true);
		}

		for (Method method : methods) {
			String name = method.getName().replaceAll("^(set|get)", "");
			name = Character.toLowerCase(name.charAt(0)) + name.substring(1);
			Parameter[] params = method.getParameters();

			if (params.length > 0) {
				try {

					Parameter firstParam = params[0];
					String type = firstParam.getType().getSimpleName().toLowerCase();
					if (type.equals("int") || type.equals("integer")) {
						method.invoke(dto, resultSet.getInt(name.toLowerCase()));
					} else if (type.equals("string")) {
						method.invoke(dto, resultSet.getString(name.toLowerCase()));
					} else if (type.equals("float")) {
						method.invoke(dto, resultSet.getFloat(name.toLowerCase()));
					} else if (type.equals("byte[]")) {
						method.invoke(dto, resultSet.getBytes(name.toLowerCase()));
					} else if (type.equals("date")) {
						method.invoke(dto, resultSet.getDate(name.toLowerCase()));
					} else {
						// TODO handle individually
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}

		return dto;
	}

	@Override
	public T mapRow(ResultSet rs, int rowNum) throws SQLException {
		try {
			return mapResultSet(rs);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
