package bg.demax.documentsrest.repository;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import bg.demax.documentsrest.dbobjects.Document;
import bg.demax.documentsrest.dbobjects.DocumentInfo;

@Repository
public class DocumentRepository {

	private static String GET_DOCUMENT_QUERY = "SELECT * FROM  documents WHERE hash = :hash";
	private static String GET_DOCUMENT_INFO_QUERY = "SELECT hash, userid, pubread, pubexpdate, expiration "
			+ "FROM  documents WHERE hash = :hash";
	private static String GET_DOCUMENT_OWNER_QUERY = "SELECT userid FROM  documents WHERE hash = :hash";
	private static String PUT_DOCUMENT_QUERY = "INSERT INTO documents (data, expiration, userId) "
			+ "VALUES (:data, :expiration, :userId) ON CONFLICT (hash) DO UPDATE SET pubread = TRUE, pubexpdate = TRUE RETURNING hash";
	private static String DROP_DOCUMENT_QUERY = "DELETE FROM documents WHERE hash = :hash RETURNING hash";
	private static String ALTER_DOCUMENT_QUERY = "UPDATE documents SET pubread = :pubread, pubexpdate = :pubexpdate WHERE hash = :hash RETURNING hash";

	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;

	@Autowired
	private AutomaticResultSetDataMapper<Document> documentRowMapper;

	@Autowired
	private AutomaticResultSetDataMapper<DocumentInfo> documentInfoRowMapper;

	public Document getDocumentForHash(byte[] hash) {

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("hash", hash);

		List<Document> result = jdbcTemplate.query(GET_DOCUMENT_QUERY, paramMap, documentRowMapper);

		if (result == null || result.isEmpty())
			return null;

		return result.get(0);
	}

	public DocumentInfo getDocumentInfoForHash(byte[] hash) {

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("hash", hash);

		List<DocumentInfo> result = jdbcTemplate.query(GET_DOCUMENT_INFO_QUERY, paramMap, documentInfoRowMapper);

		if (result == null || result.isEmpty())
			return null;

		return result.get(0);
	}

	public Integer getDocumentOwnerForHash(byte[] hash) {

		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("hash", hash);

		return jdbcTemplate.query(GET_DOCUMENT_OWNER_QUERY, paramMap, (res) -> {
			if (res.next()) {
				return res.getInt("userid");
			}
			return null;
		});
	}

	public byte[] putDocument(byte[] data, Date expiration, int userId) {

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("data", data);
		parameters.put("expiration", expiration);
		parameters.put("userId", userId);
		return jdbcTemplate.query(PUT_DOCUMENT_QUERY, parameters, (res) -> {
			if (res.next()) {
				return res.getBytes("hash");
			}
			return null;
		});
	}

	public int dropDocument(byte[] hash) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("hash", hash);
		return jdbcTemplate.query(DROP_DOCUMENT_QUERY, parameters, (res) -> {
			if (res.next()) {
				return 1;
			}
			return 0;
		});
	}

	public byte[] alterDocument(byte[] hash, boolean pubread, boolean pubexpdate, Date expiration) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("hash", hash);
		parameters.put("expiration", expiration);
		parameters.put("pubread", pubread);
		parameters.put("pubexpdate", pubexpdate);

		return jdbcTemplate.query(ALTER_DOCUMENT_QUERY, parameters, (res) -> {
			if (res.next()) {
				return res.getBytes("hash");
			}
			return null;
		});
	}
}
