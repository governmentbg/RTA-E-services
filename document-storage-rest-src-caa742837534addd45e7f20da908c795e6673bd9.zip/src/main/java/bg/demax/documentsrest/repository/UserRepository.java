package bg.demax.documentsrest.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Repository;

import bg.demax.documentsrest.security.UserDetailsRowMapper;

@Repository
public class UserRepository {

	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;

	@Autowired
	private UserDetailsRowMapper userDetailsRowMapper;

	public String getUsername(String certificate) {
		Map<String, Object> arguments = new HashMap<>();
		arguments.put("certificate", certificate);

		String query = "SELECT id FROM public.users WHERE certificate = :certificate";
		String result = jdbcTemplate.query(query, arguments, (res) -> {
			if (res.next()) {
				return res.getString(1);
			}
			return null;
		});

		return result;
	}

	public UserDetails getUserDetails(String certificate) {
		Map<String, Object> arguments = new HashMap<>();
		arguments.put("certificate", certificate);

		String query = "SELECT * FROM public.users WHERE certificate = :certificate";

		List<UserDetails> result = jdbcTemplate.query(query, arguments, userDetailsRowMapper);
		if (result == null || result.isEmpty())
			return null;

		return result.get(0);
	}
}
