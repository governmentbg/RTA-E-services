package bg.demax.documentsrest.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;


@Component
public class SecurityAuthenticationFailure implements AccessDeniedHandler, AuthenticationEntryPoint {
	private static final Logger log = LogManager.getLogger(SecurityAuthenticationFailure.class);

	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException, ServletException {
		setHttpServletResponse(response, authException.getMessage());
	}

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response,
			AccessDeniedException accessDeniedException) throws IOException, ServletException {
		setHttpServletResponse(response, accessDeniedException.getMessage());
	}

	private void setHttpServletResponse(HttpServletResponse response, String exceptionMsg) throws IOException {
		response.setStatus(HttpServletResponse.SC_FORBIDDEN);
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);

		// ApplicationExceptionDto exceptionDto = new ApplicationExceptionDto();
		// exceptionDto.setError("Error during authentication. Bad Credentials.");
		// exceptionDto.setMessage(exceptionMsg);
		// String responseJson = ObjectMapperUtils.toJson(exceptionDto);
		log.warn(exceptionMsg);

		response.getWriter().write(exceptionMsg);
	}
}
