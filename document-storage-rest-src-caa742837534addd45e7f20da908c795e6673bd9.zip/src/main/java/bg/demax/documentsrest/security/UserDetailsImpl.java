package bg.demax.documentsrest.security;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class UserDetailsImpl implements UserDetails {

    private static final long serialVersionUID = -8205705665134068013L;
    private Integer userId;
    private String username;
    private String publicKey;

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		//TODO get role from db
		GrantedAuthority authority = new SimpleGrantedAuthority("ROLE_GENERIC_USER");
		List<GrantedAuthority> authorities = Arrays.asList(authority);
		return authorities;
	}
	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}
	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}
	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}
	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}
	@Override
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPublicKey() {
		return publicKey;
	}
	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

    public int getUserId() {
	return userId;
    }
    
    public void setUserId(int userId) {
	this.userId = userId;
    }
}
