package bg.demax.documentsrest.security;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

@Component
public class UserDetailsRowMapper implements RowMapper<UserDetails> {

	@Override
	public UserDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		UserDetailsImpl userDetails = new UserDetailsImpl();
		userDetails.setUsername(rs.getString("username"));
		userDetails.setPublicKey(rs.getString("certificate"));
		userDetails.setUserId(Integer.parseInt(rs.getString("id")));
		return userDetails;
	}
	
}
