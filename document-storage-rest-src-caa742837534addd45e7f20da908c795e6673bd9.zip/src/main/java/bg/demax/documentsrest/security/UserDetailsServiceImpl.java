package bg.demax.documentsrest.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.documentsrest.repository.UserRepository;

@Service
public class UserDetailsServiceImpl implements AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> {

	public static String ROLE_PREFIX = "ROLE_";

	@Autowired
	private UserRepository userRepository;

	@Override
	@Transactional(readOnly = true)
	public UserDetails loadUserDetails(PreAuthenticatedAuthenticationToken token) throws UsernameNotFoundException {
		String publicKey = ((String) token.getPrincipal()).trim();
		UserDetails userDetails = userRepository.getUserDetails(publicKey);

		if (userDetails == null) {
			throw new UsernameNotFoundException("User with public key " + publicKey + " not found");
		}

		return userDetails;
	}
}
