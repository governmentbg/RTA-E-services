package bg.demax.documentsrest.service;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.documentsrest.dbobjects.Document;
import bg.demax.documentsrest.dbobjects.DocumentInfo;
import bg.demax.document.storage.dtos.AlterDocumentDto;
import bg.demax.document.storage.dtos.HashDto;
import bg.demax.document.storage.dtos.LoadDocumentDto;
import bg.demax.document.storage.dtos.StoreDocumentDto;
import bg.demax.documentsrest.repository.DocumentRepository;
import bg.demax.documentsrest.security.UserDetailsImpl;

@Service
public class DocumentService {

    @Autowired
    DocumentRepository documentRepository;

    /* s must be an even-length string. */
    private static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }

    @Transactional(readOnly = true)
    public LoadDocumentDto getDocumentDto(String hash) {
        AbstractAuthenticationToken auth = (AbstractAuthenticationToken) SecurityContextHolder.getContext()
                .getAuthentication();
        UserDetailsImpl details = (UserDetailsImpl) auth.getPrincipal();

        Document doc = documentRepository.getDocumentForHash(hexStringToByteArray(hash));
        if (doc == null)
            throw new IllegalArgumentException("hash not found");

        if (doc.getUserId() != details.getUserId() && doc.getPubRead() == false)
            throw new AccessDeniedException("User does not own ressource!");

        LoadDocumentDto result = new LoadDocumentDto();
        result.setData(doc.getData());
        result.setHash(doc.getHash());
        result.setExpiration(doc.getExpiration());
        return result;
    }

    @Transactional
    public HashDto storeDocumentDto(StoreDocumentDto document) {
        AbstractAuthenticationToken auth = (AbstractAuthenticationToken) SecurityContextHolder.getContext()
                .getAuthentication();
        UserDetailsImpl details = (UserDetailsImpl) auth.getPrincipal();

        HashDto result = new HashDto();

        result.setHash(
                documentRepository.putDocument(document.getData(), document.getExpiration(), details.getUserId()));

        return result;
    }

    @Transactional
    public void deleteDocumentDto(HashDto request) throws AccessDeniedException {
        AbstractAuthenticationToken auth = (AbstractAuthenticationToken) SecurityContextHolder.getContext()
                .getAuthentication();
        UserDetailsImpl details = (UserDetailsImpl) auth.getPrincipal();

        DocumentInfo documentInfo = documentRepository.getDocumentInfoForHash(request.getHash());
        if (documentInfo == null)
            throw new IllegalArgumentException("hash not found");

        if (documentInfo.getUserId() != details.getUserId())
            throw new AccessDeniedException("user not owner of the object to be deleted");

        if (documentInfo.getPubRead())
            throw new AccessDeniedException("document is public, can not be deleted before the exp date");

        documentRepository.dropDocument(request.getHash());
    }

    @Transactional(readOnly = true)
    public List<HashDto> filterNonExisting(List<HashDto> hashes) {
        List<HashDto> ret = new LinkedList<>();

        for (HashDto dto : hashes) {
            Integer userId = documentRepository.getDocumentOwnerForHash(dto.getHash());
            if (userId == null)
                continue;

            ret.add(dto);
        }

        return ret;
    }

    @Transactional
    public HashDto alterDocumentDto(AlterDocumentDto request) {
        AbstractAuthenticationToken auth = (AbstractAuthenticationToken) SecurityContextHolder.getContext()
                .getAuthentication();
        UserDetailsImpl details = (UserDetailsImpl) auth.getPrincipal();

        DocumentInfo documentInfo = documentRepository.getDocumentInfoForHash(request.getHash());
        if (documentInfo == null)
            throw new IllegalArgumentException("hash not found");

        HashDto result = new HashDto();

        if (documentInfo.getPubRead() && !request.getPubRead())
            throw new AccessDeniedException("user not allowed to unpubish document");

        if (documentInfo.getPubRead() && request.getExpiration().before(documentInfo.getExpiration()))
            throw new AccessDeniedException("user not allowed to shorten the exp date");

        if (documentInfo.getUserId() != details.getUserId()) {
            if (documentInfo.getPubExpDate() && documentInfo.getPubRead()) {
                result.setHash(documentRepository.alterDocument(documentInfo.getHash(), documentInfo.getPubRead(),
                        documentInfo.getPubExpDate(), request.getExpiration()));
            } else
                throw new AccessDeniedException("user not allowed to alter this document");
        } else {
            result.setHash(documentRepository.alterDocument(documentInfo.getHash(), request.getPubRead(),
                    request.getPubExpDate(), request.getExpiration()));
        }

        return result;
    }
}
