package bg.demax.techinsprfidrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechinspRfidRestApplicationTests {

	// @Test
	// void contextLoads() {
	// }

}
