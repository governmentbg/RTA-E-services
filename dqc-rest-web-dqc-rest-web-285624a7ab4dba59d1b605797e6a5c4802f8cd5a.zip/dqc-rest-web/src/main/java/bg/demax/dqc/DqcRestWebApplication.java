package bg.demax.dqc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DqcRestWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(DqcRestWebApplication.class, args);
	}

}
