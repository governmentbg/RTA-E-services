package bg.demax.dqc.conf;

import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@PropertySource({ "classpath:dqc-card-db.properties" })
@EnableJpaRepositories(basePackages = "bg.demax.dqc.db.card", entityManagerFactoryRef = "dqcCardEntityManager", transactionManagerRef = "dqcCardTransactionManager")
@Profile("!test")
public class DqcCardDBConf {

	@Autowired
	private Environment env;

	public DqcCardDBConf() {
		super();
	}

	@Bean
	@Primary
	public DataSource dqcCardDataSource() {
		final DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(env.getProperty("dqc.card.driver.class.name"));
		dataSource.setUrl(env.getProperty("dqc.card.datasource.url"));
		dataSource.setUsername(env.getProperty("dqc.card.datasource.username"));
		dataSource.setPassword(env.getProperty("dqc.card.datasource.password"));

		return dataSource;
	}

	@Bean
	@Primary
	public LocalContainerEntityManagerFactoryBean dqcCardEntityManager() {
		final LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(dqcCardDataSource());
		em.setPackagesToScan("bg.demax.dqc.db.card.entity");

		final HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		final HashMap<String, Object> properties = new HashMap<String, Object>();
		properties.put("hibernate.ddl-auto", env.getProperty("dqc.card.hibernate.ddl-auto"));
		properties.put("hibernate.dialect", env.getProperty("spring.jpa.properties.hibernate.dialect"));
		properties.put("hibernate.jdbc.lob.non_contextual_creation", env.getProperty("dqc.card.properties.hibernate.jdbc.lob.non_contextual_creation"));
		properties.put("hibernate.show_sql", env.getProperty("dqc.card.jpa.show-sql"));
		properties.put("hibernate.use_sql_comments", env.getProperty("dqc.card.jpa.show-sql"));
		properties.put("hibernate.format_sql", env.getProperty("dqc.card.jpa.show-sql"));
		em.setJpaPropertyMap(properties);

		return em;
	}

	@Bean
	@Primary
	public PlatformTransactionManager dqcCardTransactionManager() {
		final JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(dqcCardEntityManager().getObject());
		return transactionManager;
	}
}
