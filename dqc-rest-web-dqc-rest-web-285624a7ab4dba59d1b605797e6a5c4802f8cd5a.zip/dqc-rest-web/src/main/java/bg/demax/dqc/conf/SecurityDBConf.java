package bg.demax.dqc.conf;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
import org.springframework.transaction.PlatformTransactionManager;

import bg.demax.security.RoleHierarchyImpl;
import bg.demax.shared.hibernate.GenericFinder;
import bg.demax.shared.hibernate.GenericGateway;
import bg.demax.shared.hibernate.GenericSearchSupport;
import bg.demax.shared.hibernate.PagingAndSortingSupport;

@Configuration
@PropertySource({ "classpath:security-db.properties" })
public class SecurityDBConf {

	@Autowired
	private Environment env;

	public SecurityDBConf() {
		super();
	}
	
	@Bean 
	public GenericFinder genericFinder() {
		GenericFinder genericFinder = new GenericFinder();
		return genericFinder;
	}
	
	@Bean 
	public GenericGateway genericGateway() {
		GenericGateway genericGateway = new GenericGateway();
		return genericGateway;
	}
	
	@Bean
	public GenericSearchSupport genericSearchSupport() {
		GenericSearchSupport genericSearchSupport = new GenericSearchSupport();
		return genericSearchSupport;
	}
	
	@Bean
	public PagingAndSortingSupport pagingAndSortingSupport() {
		PagingAndSortingSupport pagingAndSortingSupport = new PagingAndSortingSupport();
		return pagingAndSortingSupport;
	}

	@Bean
	public LocalSessionFactoryBean securitySessionFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(securityDataSource());
		sessionFactory.setPackagesToScan("bg.demax.security.entity");
		sessionFactory.setHibernateProperties(securityProperties());

		return sessionFactory;
	}

	@Bean
	public DataSource securityDataSource() {
		final DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(env.getProperty("security.driver.class.name"));
		dataSource.setUrl(env.getProperty("security.datasource.url"));
		dataSource.setUsername(env.getProperty("security.datasource.username"));
		dataSource.setPassword(env.getProperty("security.datasource.password"));

		return dataSource;
	}

	@Bean
	public PlatformTransactionManager securityTransactionManager() {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(securitySessionFactory().getObject());
		return transactionManager;
	}
	
	@Bean
	public RoleHierarchy roleHierarchy(){
		return RoleHierarchyImpl.getInstance();
	}

	private final Properties securityProperties() {
		Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty("hibernate.ddl-auto",  env.getProperty("security.hibernate.ddl-auto"));
		hibernateProperties.setProperty("hibernate.dialect", env.getProperty("spring.jpa.properties.hibernate.dialect"));
		hibernateProperties.setProperty("hibernate.jdbc.lob.non_contextual_creation", env.getProperty("security.properties.hibernate.jdbc.lob.non_contextual_creation"));;

		return hibernateProperties;
	}
}
