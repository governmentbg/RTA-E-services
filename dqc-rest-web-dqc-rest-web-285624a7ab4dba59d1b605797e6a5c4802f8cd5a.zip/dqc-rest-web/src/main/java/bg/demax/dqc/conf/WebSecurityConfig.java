package bg.demax.dqc.conf;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsChecker;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;

import bg.demax.security.auth.CryptoTokenAuthenticationFilter;
import bg.demax.security.auth.PreAuthenticationChecker;
import bg.demax.security.service.CryptoTokenAuthenticationService;

@Configuration
@EnableWebSecurity
@ComponentScan("bg.demax.security")
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Autowired
	private CryptoTokenAuthenticationService cryptoTokenAuthenticationService;
	
	private CryptoTokenAuthenticationFilter cryptoTokenAuthenticationFilter;

	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception {
		
		PreAuthenticatedAuthenticationProvider preAuthenticatedAuthenticationProvider = new PreAuthenticatedAuthenticationProvider();
		preAuthenticatedAuthenticationProvider.setPreAuthenticatedUserDetailsService(cryptoTokenAuthenticationService);
		preAuthenticatedAuthenticationProvider.setUserDetailsChecker(userDetailsChecker());
		auth.authenticationProvider(preAuthenticatedAuthenticationProvider);

	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		cryptoTokenAuthenticationFilter = new CryptoTokenAuthenticationFilter();
		cryptoTokenAuthenticationFilter.setAuthenticationManager(authenticationManager());
		
		http.addFilterBefore(cryptoTokenAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
		
		http.csrf().disable();
		
		
		http.authorizeRequests()
	      .antMatchers("/dqc-card-check**")
	      .hasAnyAuthority("ROLE_DQC_REST_API")
	      .anyRequest()
	      .authenticated();
		
		http.authorizeRequests()
	      .antMatchers("/dqc-cards**")
	      .hasAnyAuthority("ROLE_DQC_REST_API")
	      .anyRequest()
	      .authenticated();
	}
	
	@Bean
	public UserDetailsChecker userDetailsChecker() {
		UserDetailsChecker UserDetailsChecker = new PreAuthenticationChecker();
		return UserDetailsChecker;
	}
}
