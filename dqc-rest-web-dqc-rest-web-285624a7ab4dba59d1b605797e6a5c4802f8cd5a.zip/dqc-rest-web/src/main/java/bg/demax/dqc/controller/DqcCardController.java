package bg.demax.dqc.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.dqc.converter.CardDtoConverter;
import bg.demax.dqc.db.card.entity.Card;
import bg.demax.dqc.dto.ApiError;
import bg.demax.dqc.dto.DqcCardDto;
import bg.demax.dqc.service.DqcCardService;

@RestController
@RequestMapping("/dqc-cards")
public class DqcCardController {
	
	private static Logger log = LoggerFactory.getLogger(DqcCardController.class);
	
	@Autowired
	private DqcCardService dqcCardService;
	
	@Autowired 
	private CardDtoConverter converter;
	
	@Autowired 
	private ObjectMapper objectMapper;
	
	@PostMapping(value = "/create", consumes = "application/json; charset=utf-8", produces = "application/json; charset=utf-8")
	public  ResponseEntity<String> createNewDqcCard(@Valid @RequestBody DqcCardDto dto) throws JsonProcessingException { 
		String jsonStr = "" ;
		HttpStatus status = HttpStatus.CREATED;
		
		try {
			Card newCard = converter.convert(dto);
			newCard = dqcCardService.createNewCard(newCard);
			dto = converter.convert(newCard);
			jsonStr = objectMapper.writeValueAsString(dto);
		} catch (Exception ex){
			status = HttpStatus.BAD_REQUEST;
			ApiError error = new ApiError(status, ex);
			jsonStr = objectMapper.writeValueAsString(error);
			log.error("", ex);
		}
 		return ResponseEntity.status(status).body(jsonStr);
	}
}
