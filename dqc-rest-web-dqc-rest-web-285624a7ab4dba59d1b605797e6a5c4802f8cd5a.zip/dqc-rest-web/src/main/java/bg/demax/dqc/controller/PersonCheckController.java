package bg.demax.dqc.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.dqc.dto.ApiError;
import bg.demax.dqc.dto.DqcCardsCheckDto;
import bg.demax.dqc.dto.DqcCardsCheckWrapperDto;
import bg.demax.dqc.exception.NoCardFoundException;
import bg.demax.dqc.service.PersonCheckService;

@RestController
@RequestMapping("/dqc-card-check")
public class PersonCheckController {
	
	private static Logger log = LoggerFactory.getLogger(PersonCheckController.class);

	@Autowired
	private PersonCheckService personCheckService;
	
	@Autowired 
	private ObjectMapper objectMapper;

	@GetMapping(value = "/persons/{identNumb}", produces = "application/json; charset=utf-8")
	public ResponseEntity<String> checkForIdentNumber(@PathVariable String identNumb) throws JsonProcessingException {
		String jsonStr = "" ;
		HttpStatus status = HttpStatus.OK;
		
		try {
			List<DqcCardsCheckDto> dtos = personCheckService.getAllForIdentNumb(identNumb);
			DqcCardsCheckWrapperDto cardsDto = new DqcCardsCheckWrapperDto(dtos);
			jsonStr = objectMapper.writeValueAsString(cardsDto);
		} catch (NoCardFoundException ncfe) {
			ApiError error = new ApiError(HttpStatus.NOT_FOUND);
			jsonStr = objectMapper.writeValueAsString(error);
			log.info(identNumb, ncfe);
			status = HttpStatus.NOT_FOUND;
		} catch (Exception ex){
			ApiError error = new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, ex);
			jsonStr = objectMapper.writeValueAsString(error);
			log.error(identNumb, ex);
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		
		return ResponseEntity.status(status).body(jsonStr);
	}
}
