package bg.demax.dqc.converter;

import java.time.LocalDate;
import java.util.Set;

import javax.validation.Valid;
import javax.xml.bind.DatatypeConverter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.dqc.db.card.entity.Card;
import bg.demax.dqc.db.card.entity.Certificate;
import bg.demax.dqc.dto.DqcCardCertificateDto;
import bg.demax.dqc.dto.DqcCardDto;

@Component
public class CardDtoConverter implements Converter<DqcCardDto, Card> {

	@Autowired
	private PersonDtoConverter personDtoConverter;
	
	@Autowired
	private DqcCertificateConverter dqcCertificateConverter;
	
	@Override
	public Card convert(DqcCardDto dto) {
		Card card = new Card();
		
		card.setFirstName(dto.getFirstName().toUpperCase());
		card.setFirstNameCyr(dto.getFirstNameCyr().toUpperCase());
		card.setSurName(dto.getSurName().toUpperCase());
		card.setSurNameCyr(dto.getSurNameCyr().toUpperCase());
		if(dto.getFathersName() != null) {
			card.setFathersName(dto.getFathersName().toUpperCase());
		}
		if(dto.getFathersNameCyr() != null) {
			card.setFathersNameCyr(dto.getFathersNameCyr().toUpperCase());
		}
		card.setCCats(dto.getCategoriesC().toUpperCase());
		card.setDCats(dto.getCategoriesD().toUpperCase());
		card.setCCatsDate(getDate(dto.getCatsCDate()));
		card.setDCatsDate(getDate(dto.getCatsDDate()));
		card.setIssueDate(getDate(dto.getIssueDate()));
		card.setResidenceAddress(dto.getResidenceAddress().toUpperCase());
		card.setPostalDistrict(dto.getPostalDistrict().toUpperCase());
		card.setPostalCity(dto.getPostalCity().toUpperCase());
		card.setPostalAddress(dto.getPostalAddress().toUpperCase());
		if (dto.getPhone() != null) {
			card.setPhone(dto.getPhone());
		}
		if (dto.getEmail() != null) {
			card.setEmail(dto.getEmail());
		}
		card.setLicenseNumber(dto.getLicenseNumber().toUpperCase());
		card.setLicenseIssueDate(dto.getLicenseIssueDate());
		card.setPassNumber(dto.getPassNumber().toUpperCase());
		card.setPassIssuer(dto.getPassIssuer().toUpperCase());
		card.setPassIssueDate(getDate(dto.getPassIssueDate()));
		card.setDescription(dto.getDescription().toUpperCase());
		card.setResidenceDistrict(dto.getResidenceDistrict().toUpperCase());
		card.setResidenceCity(dto.getResidenceCity().toUpperCase());
		card.setLicenseIssuer(dto.getLicenseIssuer().toUpperCase());
		
		card.setFace(DatatypeConverter.parseBase64Binary(dto.getFace()));
		card.setSignature(DatatypeConverter.parseBase64Binary(dto.getSignature()));
		card.setState(Card.SUBMITTED);
		card.setPerson(personDtoConverter.convert(dto.getPerson()));
		
		setCertifcate(card, dto.getCargoCertificate(), true);
		setCertifcate(card, dto.getPassengerCertificate(), false);
		
		return card;
	}

	private LocalDate getDate(LocalDate dtoDate) {
		if (dtoDate != null) {
			return dtoDate;
		} else {
			return LocalDate.of(1970, 1, 1);
		}
	}

	private void setCertifcate(Card card, DqcCardCertificateDto cargoCertificate, boolean isCargo) {
		if(cargoCertificate == null) {
			return;
		}
		
		Certificate certificate = dqcCertificateConverter.convert(cargoCertificate);
		certificate.getCards().add(card);
		
		if (isCargo) {
			certificate.setCategory(Certificate.CARGO);
		} else {
			certificate.setCategory(Certificate.PASSENGERS);
		}
		
		card.getCertificates().add(certificate);
	}

	public @Valid DqcCardDto convert(Card newCard) {
		DqcCardDto dto = new DqcCardDto();
		
		dto.setFirstName(newCard.getFirstName().toUpperCase());
		dto.setFirstNameCyr(newCard.getFirstNameCyr().toUpperCase());
		dto.setSurName(newCard.getSurName().toUpperCase());
		dto.setSurNameCyr(newCard.getSurNameCyr().toUpperCase());
		dto.setFathersName(newCard.getFathersName().toUpperCase());
		dto.setFathersNameCyr(newCard.getFathersNameCyr().toUpperCase());
		dto.setCategoriesC(newCard.getCCats().toUpperCase());
		dto.setCategoriesD(newCard.getDCats().toUpperCase());
		dto.setCatsCDate(getDate(newCard.getCCatsDate()));
		dto.setCatsDDate(getDate(newCard.getDCatsDate()));
		dto.setIssueDate(getDate(newCard.getIssueDate()));		
		dto.setResidenceAddress(newCard.getResidenceAddress().toUpperCase());
		dto.setPostalDistrict(newCard.getPostalDistrict().toUpperCase());
		dto.setPostalCity(newCard.getPostalCity().toUpperCase());
		dto.setPostalAddress(newCard.getPostalAddress().toUpperCase());
		dto.setPhone(newCard.getPhone());
		dto.setEmail(newCard.getEmail());
		dto.setLicenseNumber(newCard.getLicenseNumber().toUpperCase());
		dto.setLicenseIssueDate(newCard.getLicenseIssueDate());
		dto.setPassNumber(newCard.getPassNumber().toUpperCase());
		dto.setPassIssuer(newCard.getPassIssuer().toUpperCase());
		dto.setPassIssueDate(getDate(newCard.getPassIssueDate()));
		dto.setDescription(newCard.getDescription().toUpperCase());
		dto.setResidenceDistrict(newCard.getResidenceDistrict().toUpperCase());
		dto.setResidenceCity(newCard.getResidenceCity().toUpperCase());
		dto.setLicenseIssuer(newCard.getLicenseIssuer().toUpperCase());
		
		dto.setFace(DatatypeConverter.printBase64Binary(newCard.getFace()));
		dto.setSignature(DatatypeConverter.printBase64Binary(newCard.getSignature()));
		dto.setPerson(personDtoConverter.convert(newCard.getPerson()));
		
		setCertifcates(dto, newCard.getCertificates());
		
		return dto;
	}

	private void setCertifcates(DqcCardDto dto, Set<Certificate> certificates) {
		certificates.forEach(certificate ->{
			if(certificate.getCategory().equals(Certificate.CARGO)) {
				DqcCardCertificateDto certDto = dqcCertificateConverter.convert(certificate);
				dto.setCargoCertificate(certDto);
			} else {
				DqcCardCertificateDto certDto = dqcCertificateConverter.convert(certificate);
				dto.setPassengerCertificate(certDto);
			}
		});
		
	}
}
