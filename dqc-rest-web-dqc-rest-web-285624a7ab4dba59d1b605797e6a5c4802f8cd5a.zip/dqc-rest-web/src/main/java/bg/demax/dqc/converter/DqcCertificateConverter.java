package bg.demax.dqc.converter;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.dqc.db.card.entity.Certificate;
import bg.demax.dqc.dto.DqcCardCertificateDto;

@Component
public class DqcCertificateConverter implements Converter<DqcCardCertificateDto, Certificate>{

	@Override
	public Certificate convert(DqcCardCertificateDto dto) {
		Certificate cert = new Certificate();
		
		cert.setStartDate(dto.getStartDate());
		cert.setCertType(dto.getCertType());
		cert.setEndDate(dto.getEndDate());
		cert.setIssuer(getFormattedIssuer(dto.getIssuer()));
		cert.setIssueDate(dto.getIssueDate());
		cert.setIssuerNumber(getFormattedIssuerNumber(dto.getIssuerNumber()));
		cert.setCertType(dto.getCertType());
	
		return cert;
	}

	private String getFormattedIssuerNumber(String issuerNumber) {
		if(issuerNumber.length() < DqcCardCertificateDto.ISSUER_NUMBER_MAX_SIZE) {
			issuerNumber = StringUtils.leftPad(
					issuerNumber, 
					DqcCardCertificateDto.ISSUER_NUMBER_MAX_SIZE, 
					"0");
		}
		return issuerNumber;
	}

	private String getFormattedIssuer(String issuer) {
		if(issuer.length() < DqcCardCertificateDto.ISSUER_MAX_SIZE) {
			issuer = StringUtils.leftPad(
					issuer, 
					DqcCardCertificateDto.ISSUER_MAX_SIZE, 
					"0");
		}
		return issuer;
	}

	public DqcCardCertificateDto convert(Certificate certificate) {
		DqcCardCertificateDto certDto = new DqcCardCertificateDto();
		
		certDto.setStartDate(certificate.getStartDate());
		certDto.setCertType(certificate.getCertType());
		certDto.setEndDate(certificate.getEndDate());
		certDto.setIssuer(certificate.getIssuer());
		certDto.setIssueDate(certificate.getIssueDate());
		certDto.setIssuerNumber(certificate.getIssuerNumber());
		certDto.setCertType(certificate.getCertType());
	
		return certDto;
	}
}
