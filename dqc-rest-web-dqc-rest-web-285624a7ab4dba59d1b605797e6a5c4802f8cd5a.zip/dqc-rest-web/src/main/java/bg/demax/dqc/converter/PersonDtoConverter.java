package bg.demax.dqc.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.dqc.db.card.entity.Person;
import bg.demax.dqc.dto.PersonDto;

@Component
public class PersonDtoConverter implements Converter<PersonDto, Person>{

	@Override
	public Person convert(PersonDto dto) {
		StringBuilder personalNumberStringBuilder = new StringBuilder();
		
		if(dto.getPersonalNumberType() == PersonDto.LNC) {
			personalNumberStringBuilder.append(PersonDto.LNC_PREFIX);
		}
	    personalNumberStringBuilder.append(dto.getPersonalNumber());
		
		Person person = new Person();
		person.setPersonalNumber(personalNumberStringBuilder.toString());
		person.setBirthDate(dto.getBirthDate());
		person.setBirthPlace(dto.getBirthPlace());
		person.setBirthPlaceCyr(dto.getBirthPlaceCyr());

		return person;
	}

	public PersonDto convert(Person person) {
		
		PersonDto dto = new PersonDto();
		dto.setPersonalNumber(person.getPersonalNumber().replaceAll(PersonDto.LNC_PREFIX, ""));
		dto.setBirthDate(person.getBirthDate());
		dto.setBirthPlace(person.getBirthPlace());
		person.setBirthPlaceCyr(person.getBirthPlaceCyr());
		
		return dto;
	}
}
