package bg.demax.dqc.db.card.entity;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Formula;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "cards")
public class Card {
	
	public static final int VALID_TO_YEARS = 5;

	public static final String BLOCKED = "blocked";

	public static final String SUBMITTED = "submitted";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "card_id")
	private Integer id;

	@NotNull
	@Column(name = "first_name")
	private String firstName;

	@NotNull
	@Column(name = "first_name_cyr")
	private String firstNameCyr;

	@NotNull
	@Column(name = "surname")
	private String surName;

	@NotNull
	@Column(name = "surname_cyr")
	private String surNameCyr;

	@NotNull
	@Column(name = "fathers_name")
	private String fathersName = "";

	@NotNull
	@Column(name = "fathers_name_cyr")
	private String fathersNameCyr = "";

	@NotNull
	@Column(name = "c_cats")
	private String cCats;

	@NotNull
	@Column(name = "d_cats")
	private String dCats;

	@Column(name = "seq_number")
	private String seqNumber;

	@NotNull
	@Column(name = "issue_date")
	private LocalDate issueDate;

	@NotNull
	@Column(name = "c_cats_date")
	private LocalDate cCatsDate;

	@NotNull
	@Column(name = "d_cats_date")
	private LocalDate dCatsDate;

	@NotNull
	@Column(name = "state")
	private String state;

	@Column(name = "residence_address")
	private String residenceAddress;

	@Column(name = "postal_district")
	private String postalDistrict;

	@Column(name = "postal_city")
	private String postalCity;

	@Column(name = "postal_address")
	private String postalAddress;

	@Column(name = "phone")
	private String phone = "";

	@Column(name = "email")
	private String email = "";

	@Column(name = "license_number")
	private String licenseNumber;

	@Column(name = "license_issuer")
	private String licenseIssuer;

	@Column(name = "license_issue_date")
	private LocalDate licenseIssueDate;

	@Column(name = "pass_number")
	private String passNumber;

	@Column(name = "pass_issuer")
	private String passIssuer;
	
	@Column(name = "pass_issue_date")
	private LocalDate passIssueDate;

	@Column(name = "description")
	private String description;

	@Column(name = "residence_district")
	private String residenceDistrict;

	@Column(name = "residence_city")
	private String residenceCity;

	@Formula(value = "(select max(cert.cert_id) from certificates cert inner join cert_cards cc on cc.cert_id = cert.cert_id where cc.card_id = card_id and cert.category = 'Товари')")
	private Integer latestCargoCertifcateId;

	@Formula(value = "(select max(cert.cert_id) from certificates cert inner join cert_cards cc on cc.cert_id = cert.cert_id where cc.card_id = card_id and cert.category = 'Пътници')")
	private Integer latestPassengersIssueCertifcateId;

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "person_id")
	private Person person;

	@NotNull
	@Lob
	@Basic(fetch = FetchType.LAZY)
	@Column(name = "face")
	private byte[] face;

	@NotNull
	@Lob
	@Basic(fetch = FetchType.LAZY)
	@Column(name = "sign")
	private byte[] signature;

	@ManyToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinTable(name = "cert_cards", joinColumns = { @JoinColumn(name = "card_id") }, inverseJoinColumns = {
			@JoinColumn(name = "cert_id") })
	private Set<Certificate> certificates = new HashSet<>();
}
