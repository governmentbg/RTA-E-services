package bg.demax.dqc.db.card.entity;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "certificates")
public class Certificate {
	
	public static final String TYPE_PROLONG_35 = "P35";
	public static final String TYPE_35 = "35";
	public static final String TYPE_70 = "70";
	public static final String TYPE_140 = "140";

	public static final String CARGO = "Товари";
	public static final String PASSENGERS = "Пътници";
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cert_id")
	private Integer id;
	
	@NotNull
	@Column(name = "end_date", columnDefinition = "DATE")
	private LocalDate endDate;
	
	@NotNull
	@Column(name = "issue_date", columnDefinition = "DATE")
	private LocalDate issueDate;
	
	@NotNull
	@Column(name = "start_date", columnDefinition = "DATE")
	private LocalDate startDate;
	
	@NotNull
	@Column(name = "cert_type")
	private String certType;
	
	@NotNull
	@Column(name = "issuer_number")
	private String issuerNumber;
	
	@NotNull
	@Column(name = "issuer")
	private String issuer;
	
	@NotNull
	@Column(name = "category")
	private String category;

	@ManyToMany(fetch = FetchType.LAZY, mappedBy = "certificates")
	private Set<Card> cards = new HashSet<Card>();
}
