package bg.demax.dqc.db.card.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "gen_sequences")
public class GeneratedSequence {
	
	public static final String PERIOD_SERIAL_NAME = "period_serial";
	public static final String BEGIN_SERIAL_NAME = "begin_serial";
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "seq_id")
	private Integer id;
	
	@Column(name = "seq_name")
	private String seqName;
	
	@Column(name = "min_value") 
	private String minValue;
	
	@Column(name = "max_value")
	private String maxValue;
	
	@Column(name = "curr_value") 		
	private String currentValue;
}
