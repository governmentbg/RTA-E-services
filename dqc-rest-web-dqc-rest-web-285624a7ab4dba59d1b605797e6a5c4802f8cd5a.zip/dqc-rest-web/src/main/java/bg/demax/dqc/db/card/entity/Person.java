package bg.demax.dqc.db.card.entity;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "persons")
public class Person {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "person_id")
	private Integer id;
	
	@NotNull
	@Column(name = "personal_number")
	private String personalNumber;
	
	@NotNull
	@Column(name = "birth_place")
	private String birthPlace;
	
	@NotNull
	@Column(name = "birth_place_cyr")
	private String birthPlaceCyr;
	
	@NotNull
	@Column(name = "birth_date")
	private LocalDate birthDate;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "person")
	private Set<Card> cards = new HashSet<Card>();
}
