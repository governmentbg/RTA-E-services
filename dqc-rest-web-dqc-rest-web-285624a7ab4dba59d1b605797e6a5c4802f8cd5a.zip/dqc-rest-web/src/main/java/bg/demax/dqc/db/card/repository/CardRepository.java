package bg.demax.dqc.db.card.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.dqc.db.card.entity.Card;

@Repository
public interface CardRepository extends JpaRepository <Card, Integer> {

	@Query(" select distinct c from Card c inner join fetch c.person p where p.personalNumber = :identNumb and c.state = 'personalized' order by c.id desc ")
	Card getForValidIdentNumb(@Param("identNumb") String identNumb);

	@Query(" select c from Card c inner join c.person p where p.id = :personId and c.state != 'blocked' order by c.id desc")
	List<Card> findPreviousCardForPerson(@Param("personId") Integer personId);

	@Query("select distinct c from Card c inner join fetch c.person p where p.personalNumber = :identNumb order by c.id desc")
	List<Card> getAllForIdentNumb(String identNumb);
}
