package bg.demax.dqc.db.card.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.dqc.db.card.entity.Certificate;

@Repository
public interface CertificateRepository extends JpaRepository <Certificate, Integer> {

	@Query("select c "
			+ " from Certificate c "
			+ " join c.cards cd "
			+ " where cd.id = :cardId "
			+ " order by c.endDate desc ")
	List<Certificate> getCetificatesForCard(@Param("cardId") Integer id);


	@Query("select case when count(c) > 0 then true else false end "
			+ " from Certificate c "
			+ " join c.cards cd "
			+ " join cd.person p"
			+ " where p.personalNumber = :personalNumber "
			+ " and c.category = :category")
	boolean getBeginnerCertificateForPersonalNumber(@Param("personalNumber") String personalNumber,
													@Param("category") String certCategory);


	@Query("select case when count(c) > 0 then true else false end "
			+ " from Certificate c "
			+ " join c.cards cd "
			+ " join cd.person p"
			+ " where p.personalNumber = :personalNumber "
			+ " and c.category = :category"
			+ " and (c.certType = '280' or c.certType = '140') ")
	boolean getBeginnerCertificateForPersonalNumberAfterOrderDate(@Param("personalNumber")String personalNumber, 
																  @Param("category")  String category);

}
