package bg.demax.dqc.db.card.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.dqc.db.card.entity.GeneratedSequence;

@Repository
public interface GeneratedSequenceRepository extends JpaRepository<GeneratedSequence, Integer> {

	@Query("select gs from GeneratedSequence gs where seqName = :seqName")
	GeneratedSequence findCurrentValueByName(@Param("seqName")String seqName);
	
}
