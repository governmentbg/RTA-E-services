package bg.demax.dqc.db.card.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.dqc.db.card.entity.Person;

@Repository
public interface PersonResository extends JpaRepository<Person, Integer> {

	@Query("select p from Person p where p.personalNumber = :personalNumber")
	Person findByPersonalNumber(@Param("personalNumber") String personalNumber);

}
