package bg.demax.dqc.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import bg.demax.dqc.db.card.entity.Certificate;
import lombok.Getter;

@Getter
public class CertificateDto {

	private String issuerNumber;
	private String certType;
	private String issuer;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate startDate;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate endDate;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate issueDate;
	
	public CertificateDto(Certificate cert) {
		if(cert == null){
			return;
		}
		issuerNumber = cert.getIssuerNumber();
		certType = cert.getCertType();
		issueDate = cert.getIssueDate();
		issuer = cert.getIssuer();
		startDate = cert.getStartDate();
		endDate = cert.getEndDate();
	}
}
