package bg.demax.dqc.dto;

import java.time.LocalDate;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.sun.istack.NotNull;

import bg.demax.dqc.validation.ValidDqcCardCertificateDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@ValidDqcCardCertificateDto
public class DqcCardCertificateDto {
	
	public static final int ISSUER_NUMBER_MAX_SIZE = 6;
	public static final int ISSUER_MAX_SIZE = 3;
	
	@NotNull
	@Size(min = 1, max = ISSUER_NUMBER_MAX_SIZE)
	private String issuerNumber;
    
	@NotNull
	@Size(min = 1, max = ISSUER_MAX_SIZE)
	private String  issuer;
    
	@NotNull
	private String  certType;
    
    @NotNull
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate startDate;
    
    @NotNull
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate endDate;
    
    @NotNull
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate issueDate;
    
    @NotNull
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    private LocalDate validTo;
}
