package bg.demax.dqc.dto;

import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import bg.demax.dqc.validation.ValidCCategories;
import bg.demax.dqc.validation.ValidCardDto;
import bg.demax.dqc.validation.ValidCyrillic;
import bg.demax.dqc.validation.ValidDCategories;
import bg.demax.dqc.validation.ValidDqcCardCertificateDto;
import bg.demax.dqc.validation.ValidLatin;
import bg.demax.dqc.validation.ValidPersonDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@ValidCardDto
public class DqcCardDto {
	
	@NotNull
	@ValidLatin
	private String firstName;

	@NotNull
	@ValidCyrillic
	private String firstNameCyr;

	@NotNull
	@ValidLatin
	private String surName;

	@NotNull
	@ValidCyrillic
	private String surNameCyr;
	
	@ValidLatin
	private String fathersName;

	@ValidCyrillic
	private String fathersNameCyr;

	@ValidCCategories
	private String categoriesC;

	@ValidDCategories
	private String categoriesD;
	
	@NotNull
	private String residenceAddress;
	
	@ValidCyrillic
	private String postalDistrict;
	
	@ValidCyrillic
	private String postalCity;
	
	@NotNull
	private String postalAddress;
	
	@Pattern(regexp = "[0-9 -/+]{2,15}")
	private String phone;
	
	@Email
	private String email;
	
	@ValidLatin
	private String licenseNumber;
	
	@ValidCyrillic
	private String licenseIssuer;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate licenseIssueDate;
	
	@Pattern(regexp = "[a-zA-Z0-9 \":;,+-./]*")
	private String passNumber;
	
	private String passIssuer;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate passIssueDate;
	
	@ValidCyrillic
	private String description;
	
	@ValidCyrillic
	private String residenceDistrict;
	
	@ValidCyrillic
	private String residenceCity;

	@NotNull
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate issueDate;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate catsCDate;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate catsDDate;

	@NotNull
	@ValidPersonDto
	private PersonDto person;

	@NotNull
	private String face;

	@NotNull
	private String signature;
	
	@ValidDqcCardCertificateDto
	private DqcCardCertificateDto cargoCertificate;
	
	@ValidDqcCardCertificateDto
	private DqcCardCertificateDto passengerCertificate;
}
