package bg.demax.dqc.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import bg.demax.dqc.db.card.entity.Card;

// does not like lombok cCatsDatest
public class DqcCardsCheckDto {
	
	private String firstNameCyr;
	private String fathersNameCyr;
	private String surNameCyr;
	private String state;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate birthDate;
	private String birthPlaceCyr;
	private String seqNumber;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate issueDate;
	private String cCats;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate cCatsDate;
	private String dCats;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate dCatsDate;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate validTo;
	
	private CertificateDto cargoCertDto;
	private CertificateDto passengerCertDto;

	public DqcCardsCheckDto(Card card, CertificateDto cargoCertDto, CertificateDto passengerCertDto) {
		firstNameCyr = card.getFirstNameCyr();
		fathersNameCyr = card.getFathersNameCyr();
		surNameCyr = card.getSurNameCyr();
		birthDate = card.getPerson().getBirthDate();
		birthPlaceCyr = card.getPerson().getBirthPlaceCyr();
		seqNumber = card.getSeqNumber();
		issueDate = card.getIssueDate();
		cCats = card.getCCats();
		cCatsDate = card.getCCatsDate();
		dCats = card.getDCats();
		dCatsDate = card.getDCatsDate();
		state = card.getState();
		this.cargoCertDto = cargoCertDto;
		this.passengerCertDto = passengerCertDto;
		validTo = getValidTo();
	}

	private LocalDate getValidTo() {
		LocalDate latestIssueDate = getLatestIssueDateTo();
		return latestIssueDate.plusYears(Card.VALID_TO_YEARS);
	}

	private LocalDate getLatestIssueDateTo() {
		LocalDate cargoIssueDate = getIssueDate(cargoCertDto);
		LocalDate passengerIssueDate = getIssueDate(passengerCertDto);
		
		if(cargoIssueDate != null && passengerIssueDate != null) {
			if(cargoIssueDate.isAfter(passengerIssueDate)) {
				return cargoIssueDate;
			}
			
			return passengerIssueDate;
		}
		
		if(cargoIssueDate != null) {
			return cargoIssueDate;
		} else {
			return passengerIssueDate;
		}
	}

	private LocalDate getIssueDate(CertificateDto dto) {
		if(dto != null && dto.getIssueDate() != null) {
			return dto.getIssueDate();
		}
		return null;
	}

	public String getFirstNameCyr() {
		return firstNameCyr;
	}

	public String getFathersNameCyr() {
		return fathersNameCyr;
	}

	public String getSurNameCyr() {
		return surNameCyr;
	}

	public LocalDate getBirthDate() {
		return birthDate;
	}

	public String getBirthPlaceCyr() {
		return birthPlaceCyr;
	}

	public String getSeqNumber() {
		return seqNumber;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public String getcCats() {
		return cCats;
	}

	public LocalDate getcCatsDate() {
		return cCatsDate;
	}

	public String getdCats() {
		return dCats;
	}

	public LocalDate getdCatsDate() {
		return dCatsDate;
	}

	public CertificateDto getCargoCertDto() {
		return cargoCertDto;
	}

	public CertificateDto getPassengerCertDto() {
		return passengerCertDto;
	}

	public String getState() {
		return state;
	}
}
