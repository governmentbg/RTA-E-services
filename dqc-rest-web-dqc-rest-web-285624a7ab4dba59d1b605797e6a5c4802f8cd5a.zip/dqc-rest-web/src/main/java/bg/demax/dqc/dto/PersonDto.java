package bg.demax.dqc.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import bg.demax.dqc.validation.ValidCyrillic;
import bg.demax.dqc.validation.ValidPersonDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@ValidPersonDto
public class PersonDto {
	
	public static final short EGN = 1;
	public static final short LNC = 2;
	public static final short NAP = 3;
	public static final String LNC_PREFIX = "Ч";

	@NotNull
	private String personalNumber;
	
	@NotNull
	private Short personalNumberType;

	private String birthPlace;

	@ValidCyrillic
	private String birthPlaceCyr;

	@NotNull
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	private LocalDate birthDate;
}