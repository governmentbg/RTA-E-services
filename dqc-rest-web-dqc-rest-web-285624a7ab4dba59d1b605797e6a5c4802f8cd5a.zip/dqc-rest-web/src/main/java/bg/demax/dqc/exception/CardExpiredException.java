package bg.demax.dqc.exception;

import bg.demax.dqc.dto.DqcCardsCheckDto;
import lombok.Getter;

@Getter
public class CardExpiredException extends RuntimeException {
	private static final long serialVersionUID = 733436075971894216L;
	
	DqcCardsCheckDto dto;
	
	public CardExpiredException(DqcCardsCheckDto dto) {
		this.dto = dto;
	}

}
