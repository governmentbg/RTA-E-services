package bg.demax.dqc.exception;

public class CertificateIsNotValidException extends RuntimeException {
	
	private static final long serialVersionUID = -3365035893168976774L;

	public CertificateIsNotValidException(String message) {
		super(message);
	}

}
