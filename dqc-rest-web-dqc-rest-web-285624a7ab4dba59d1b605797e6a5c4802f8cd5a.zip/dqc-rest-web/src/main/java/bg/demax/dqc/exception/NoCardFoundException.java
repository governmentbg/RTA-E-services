package bg.demax.dqc.exception;

public class NoCardFoundException extends RuntimeException {

	private static final long serialVersionUID = 242718938215661843L;

}
