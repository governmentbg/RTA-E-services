package bg.demax.dqc.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.dqc.db.card.entity.Card;
import bg.demax.dqc.db.card.entity.Certificate;
import bg.demax.dqc.db.card.repository.CertificateRepository;
import bg.demax.dqc.exception.CertificateIsNotValidException;
import bg.demax.dqc.util.ExpirationDateUtil;

@Service
public class CertificateService {
	
	private static final int MAX_HOUR_TRAINING_PER_DAY = 8;
	private static final LocalDate OLD_ORDER_DATE_CARGO = LocalDate.parse("2009-09-10");
	private static final LocalDate OLD_ORDER_DATE_PASSENGERS = LocalDate.parse("2008-09-10");
	
	@Autowired
	private CertificateRepository certificateRepository;

	@Transactional(readOnly = true)
	public LocalDate getCardExpirationDate(Integer id) {
		List<Certificate> certs = certificateRepository.getCetificatesForCard(id);
		if (certs == null || certs.isEmpty()) {
			return null;
		}
		Certificate cert = certs.get(0);
		return ExpirationDateUtil.calculateExpirationLocaDate(cert.getEndDate());
	}
	
	@Transactional(readOnly = true)
	public void checkCertificates(Set<Certificate> certificates) throws CertificateIsNotValidException {
		for(Certificate certificate : certificates) {
			if(personAlreadyHasBeginnerCertificate(certificate)) {
				//throw new CertificateIsNotValidException("Already has a beginner certificate " + certificate.getCategory());
			}
			
			if(!hasBeginnerCertificateAfterOrderDate(certificate)) {
				throw new CertificateIsNotValidException("A beginner certificate " + certificate.getCategory()+ " is missing!");
			}
			
			if(!hasTransitionalCertificates(certificate) && !hasBeginerCertificateInSet(certificates, certificate)) {
				throw new CertificateIsNotValidException("Transitional certificate is missing!");
			}
			
			if(educationalPeriodIsNotValid(certificate)) {
				throw new CertificateIsNotValidException("Educational period is too short!");
			}
		}
	}

	private boolean hasBeginerCertificateInSet(Set<Certificate> certificates, Certificate certificateToIgnore ) {
		for(Certificate cert : certificates){
			if(!cert.equals(certificateToIgnore)) {
				if(!cert.getCategory().equals(certificateToIgnore.getCategory())
					&& (!cert.getCertType().equals(Certificate.TYPE_35) 
						&& !cert.getCertType().equals(Certificate.TYPE_70))) {
					return true;
				}
			}
		}
		return false;
	}

	private boolean educationalPeriodIsNotValid(Certificate certificate) {
		int hours = 0;
		String periodInHours;
		if (certificate.getCertType().equals(Certificate.TYPE_PROLONG_35)) {
			periodInHours = certificate.getCertType().replaceAll("P", "");
		} else {
			periodInHours = certificate.getCertType();
		}
		
		hours = Integer.parseInt(periodInHours);
		
		int minDaysForTraining = hours / MAX_HOUR_TRAINING_PER_DAY;
		
		Long daysInTraining = ChronoUnit.DAYS.between(certificate.getStartDate(), certificate.getEndDate());
		
		if(daysInTraining >= minDaysForTraining) {
			return false;
		}
		
		return true;
	}

	private boolean hasTransitionalCertificates(Certificate certificate) {
		if(certificate.getCertType().equals(Certificate.TYPE_35) 
				|| certificate.getCertType().equals(Certificate.TYPE_70)) {
			Card card = certificate.getCards().iterator().next();
			String personalNumber = card.getPerson().getPersonalNumber();
			String category = certificate.getCategory();
			
			if(category.equals(Certificate.CARGO)) {
				category = Certificate.PASSENGERS;
			} else {
				category = Certificate.CARGO;
			}
			
			boolean certificateExists = certificateRepository.getBeginnerCertificateForPersonalNumber(
					personalNumber, category);
			return certificateExists;
		}
		return true;
	}

	private boolean hasBeginnerCertificateAfterOrderDate(Certificate certificate) {
		
		boolean certificateExists = true;
		
		if(certificate.getCertType().equals(Certificate.TYPE_PROLONG_35)) {
			Card card = certificate.getCards().iterator().next();
			String personalNumber = card.getPerson().getPersonalNumber();
				
			if(certificate.getCategory().equals(Certificate.CARGO) 
				&& (card.getCCatsDate() == null 
					|| card.getCCatsDate().isAfter(OLD_ORDER_DATE_CARGO))) {
				 certificateExists = certificateRepository.getBeginnerCertificateForPersonalNumberAfterOrderDate(
						personalNumber, certificate.getCategory());
				
			} else if(certificate.getCategory().equals(Certificate.PASSENGERS) 
				&& (card.getDCatsDate() == null 
					|| card.getDCatsDate().isAfter(OLD_ORDER_DATE_PASSENGERS))) {
				 certificateExists = certificateRepository.getBeginnerCertificateForPersonalNumberAfterOrderDate(
						personalNumber, certificate.getCategory());
			}
		}
		return certificateExists;
	}

	private boolean personAlreadyHasBeginnerCertificate(Certificate certificate) {
		if(!certificate.getCertType().equals(Certificate.TYPE_PROLONG_35)) {
			Card card = certificate.getCards().iterator().next();
			String personalNumber = card.getPerson().getPersonalNumber();
			boolean certificateExists = certificateRepository.getBeginnerCertificateForPersonalNumber(
					personalNumber, certificate.getCategory());
			if(certificateExists) {
				return true;
			}
			return false;
		}
		return false;
	}
}
