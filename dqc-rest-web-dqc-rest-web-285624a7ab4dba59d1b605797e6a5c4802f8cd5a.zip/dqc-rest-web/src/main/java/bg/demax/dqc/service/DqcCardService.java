package bg.demax.dqc.service;

import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import bg.demax.dqc.db.card.entity.Card;
import bg.demax.dqc.db.card.entity.Certificate;
import bg.demax.dqc.db.card.entity.GeneratedSequence;
import bg.demax.dqc.db.card.entity.Person;
import bg.demax.dqc.db.card.repository.CardRepository;
import bg.demax.dqc.db.card.repository.CertificateRepository;
import bg.demax.dqc.db.card.repository.GeneratedSequenceRepository;
import bg.demax.dqc.db.card.repository.PersonResository;

@Service
@Validated
public class DqcCardService {

	private static final DecimalFormat SEQUENCE_NUMBER_FORMATTER = new DecimalFormat("000000");

	@Autowired
	private CardRepository cardRepository;

	@Autowired
	private PersonResository personResository;

	@Autowired
	private CertificateRepository certificateRepository;

	@Autowired
	private CertificateService certificateService;

	@Autowired
	private LoggingService loggingService;

	@Autowired
	private GeneratedSequenceRepository generatedSequenceRepository;

	@Transactional
	public Card createNewCard(@Valid Card card) {

		certificateService.checkCertificates(card.getCertificates());

		Person person = card.getPerson();

		Person dbPerson = personResository.findByPersonalNumber(person.getPersonalNumber());
		if (dbPerson != null) {
			person.setId(dbPerson.getId());
			person = personResository.save(person);
			card.setPerson(person);
		}

		checkCertificatesInDatabase(card);

		blockPerviousCards(person.getId());

		setSequenceNumber(card);

		card = cardRepository.save(card);

		loggingService.logCard(card, "Created card");

		return card;
	}

	private void setSequenceNumber(Card card) {
		Example<Card> example = Example.of(card);
		Optional<Card> opt = cardRepository.findOne(example);
		if (opt.isPresent()) {
			Card dbCard = opt.get();
			card.setSeqNumber(dbCard.getSeqNumber());
		} else {
			StringBuilder sequence = new StringBuilder();

			boolean isProlong = false;
			for (Certificate certificate : card.getCertificates()) {
				if (certificate.getCertType().contains("P")) {
					isProlong = true;
				}
			}
			
			GeneratedSequence gs = null;

			if (isProlong) {
				gs = generatedSequenceRepository.findCurrentValueByName(GeneratedSequence.PERIOD_SERIAL_NAME);
				sequence.append("P");
			} else {
				gs = generatedSequenceRepository.findCurrentValueByName(GeneratedSequence.BEGIN_SERIAL_NAME);
				sequence.append("N");
			}

			Long currentValue = Long.parseLong(gs.getCurrentValue());
			String number = SEQUENCE_NUMBER_FORMATTER.format(currentValue);
			sequence.append(number);
			card.setSeqNumber(sequence.toString());

			currentValue++;
			gs.setCurrentValue(currentValue.toString());
			generatedSequenceRepository.save(gs);
		}
	}

	private void checkCertificatesInDatabase(Card card) {
		Set<Certificate> savedCerts = new HashSet<>();

		card.getCertificates().forEach(certificate -> {
			Example<Certificate> example = Example.of(certificate);
			List<Certificate> opt = certificateRepository.findAll(example, new Sort(Sort.Direction.DESC, "id"));
			if (!opt.isEmpty()) {
				Certificate dbCertificate = opt.get(0);
				dbCertificate = certificateRepository.getOne(dbCertificate.getId());
				savedCerts.add(dbCertificate);
			} else {
				certificate = certificateRepository.save(certificate);
				savedCerts.add(certificate);
			}
		});

		card.setCertificates(savedCerts);
	}

	private void blockPerviousCards(Integer personId) {
		if (personId == null) {
			return;
		}

		List<Card> prevCards = cardRepository.findPreviousCardForPerson(personId);
		prevCards.forEach(prevCard -> {
			prevCard.setState(Card.BLOCKED);
			cardRepository.save(prevCard);
			loggingService.logCard(prevCard, "Blocked card");
		});
	}

	@Transactional(readOnly = true)
	public Card checkIfInDatabase(Card card) {
		Example<Card> example = Example.of(card);
		Optional<Card> opt = cardRepository.findOne(example);
		return opt.get();
	}
}
