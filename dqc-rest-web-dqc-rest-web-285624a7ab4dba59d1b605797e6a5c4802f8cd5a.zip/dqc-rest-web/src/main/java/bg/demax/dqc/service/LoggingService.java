package bg.demax.dqc.service;

import java.time.LocalDateTime;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bg.demax.dqc.db.card.entity.Card;
import bg.demax.dqc.db.card.entity.CardLog;
import bg.demax.dqc.db.card.entity.User;
import bg.demax.dqc.db.card.repository.CardLogRepository;
import bg.demax.dqc.db.card.repository.UserRepository;

@Service
public class LoggingService {
	
	private static final String USER_NAME = "e-services";
	
	@Autowired
	private CardLogRepository cardLogRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Transactional
	public void logCard(Card card, String description) {
		
		User user = userRepository.findByUserName(USER_NAME);
		
		CardLog log = new CardLog();
		log.setCard(card);
		log.setCreator(user);
		log.setDescription(description);
		log.setLogMade(LocalDateTime.now());
		
		cardLogRepository.save(log);
	}
}
