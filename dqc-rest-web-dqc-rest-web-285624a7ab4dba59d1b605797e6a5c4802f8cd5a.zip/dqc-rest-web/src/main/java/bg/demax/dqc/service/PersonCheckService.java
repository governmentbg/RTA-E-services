package bg.demax.dqc.service;



import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.dqc.db.card.entity.Card;
import bg.demax.dqc.db.card.entity.Certificate;
import bg.demax.dqc.db.card.repository.CardRepository;
import bg.demax.dqc.db.card.repository.CertificateRepository;
import bg.demax.dqc.dto.CertificateDto;
import bg.demax.dqc.dto.DqcCardsCheckDto;
import bg.demax.dqc.exception.CardExpiredException;
import bg.demax.dqc.exception.NoCardFoundException;

@Service
public class PersonCheckService {
	
	@Autowired
	private CardRepository cardRepository;
	
	@Autowired
	private CertificateRepository certificateRepository;
	
	@Autowired
	private CertificateService certificateService;

	@Transactional(readOnly = true)
	public DqcCardsCheckDto getForValidIdentNumb(String identNumb) {
		Card card = cardRepository.getForValidIdentNumb(identNumb);
		if(card == null) {
			throw new NoCardFoundException();
		}
		LocalDate expirationDate = certificateService.getCardExpirationDate(card.getId());
		
		CertificateDto cargoCertDto = createCerifcateDto(card.getLatestCargoCertifcateId());
		CertificateDto passengerCertDto = createCerifcateDto(card.getLatestPassengersIssueCertifcateId());
		
		DqcCardsCheckDto dto = new DqcCardsCheckDto(card, cargoCertDto, passengerCertDto);
		
		if(expirationDate.isBefore(LocalDate.now())){
			throw new CardExpiredException(dto);
		}
		
		return dto;
	}
	
	@Transactional(readOnly = true)
	public List<DqcCardsCheckDto> getAllForIdentNumb(String identNumb) {
		List<Card> cards = cardRepository.getAllForIdentNumb(identNumb);
		if(cards == null || cards.isEmpty()) {
			throw new NoCardFoundException();
		}
		
		List<DqcCardsCheckDto> cardDtos = new LinkedList<>();
		cards.forEach(card -> {
			CertificateDto cargoCertDto = createCerifcateDto(card.getLatestCargoCertifcateId());
			CertificateDto passengerCertDto = createCerifcateDto(card.getLatestPassengersIssueCertifcateId());
			DqcCardsCheckDto dto = new DqcCardsCheckDto(card, cargoCertDto, passengerCertDto);
			cardDtos.add(dto);
		});
		
		return cardDtos;
	}
	
	private CertificateDto createCerifcateDto(Integer cerId) {
		if(cerId == null){
			return null;
		}
		Certificate cert = certificateRepository.getOne(cerId);
		return new CertificateDto(cert);
	}
}
