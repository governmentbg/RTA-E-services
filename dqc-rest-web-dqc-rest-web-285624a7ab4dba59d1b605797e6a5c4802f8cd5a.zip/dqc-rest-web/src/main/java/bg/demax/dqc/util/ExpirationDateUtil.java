package bg.demax.dqc.util;

import java.time.LocalDate;
import java.util.Date;

public class ExpirationDateUtil {
	
	public static Date calculateExpirationDate(Date endDate) {
		if(endDate == null){
			return null;
		}
		
		long time = endDate.getTime();
		time += 1000L * 60 * 60 * 24 * (365 * 5 - 1);
		Date expirationDate = new Date();
		expirationDate.setTime(time);
		return expirationDate;
	}
	
	public static LocalDate calculateExpirationLocaDate(LocalDate endDate) {
		return endDate.plusYears(5).minusDays(1);
	}
}
