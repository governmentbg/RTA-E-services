package bg.demax.dqc.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import bg.demax.dqc.dto.DqcCardDto;

public class CardDtoValidator implements ConstraintValidator<ValidCardDto, DqcCardDto> {
	
	@Override
	public boolean isValid(DqcCardDto card, ConstraintValidatorContext context) {
		if ((card.getCategoriesC() == null || card.getCategoriesC().isEmpty())
				&& (card.getCategoriesD() == null || card.getCategoriesD().isEmpty())) {
			context.buildConstraintViolationWithTemplate("Error in card categories").addConstraintViolation();
			return false;
		}

		if ((card.getCatsCDate() == null && !card.getCategoriesC().isEmpty())
				|| (card.getCatsDDate() == null && !card.getCategoriesD().isEmpty())) {
			context.buildConstraintViolationWithTemplate("Error in card categories").addConstraintViolation();
			return false;
			
		}

		return true;
	}
}
