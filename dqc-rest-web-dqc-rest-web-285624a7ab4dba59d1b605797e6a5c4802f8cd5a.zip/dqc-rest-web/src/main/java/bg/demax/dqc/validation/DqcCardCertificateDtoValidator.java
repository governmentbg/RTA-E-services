package bg.demax.dqc.validation;

import java.time.temporal.ChronoUnit;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import bg.demax.dqc.dto.DqcCardCertificateDto;

public class DqcCardCertificateDtoValidator implements ConstraintValidator<ValidDqcCardCertificateDto, DqcCardCertificateDto> {
	private static final int MIN_CERTIFICATE_TRAINING_DURATION_DAYS = 5;
	private static final int INCLUDE_LAST_DAY = 1;

	@Override
	public boolean isValid(DqcCardCertificateDto dto, ConstraintValidatorContext context) {
		if (dto == null) {
			return true;
		}
		if (dto.getStartDate().isAfter(dto.getEndDate())) {
			context.buildConstraintViolationWithTemplate("Error endDate is before startDate!").addConstraintViolation();
			return false;
		}
		
		if ((ChronoUnit.DAYS.between(dto.getStartDate(), dto.getEndDate()) + INCLUDE_LAST_DAY) < MIN_CERTIFICATE_TRAINING_DURATION_DAYS) {
			context.buildConstraintViolationWithTemplate("Error trainnig duration is bellow " + MIN_CERTIFICATE_TRAINING_DURATION_DAYS + " days!").addConstraintViolation();
			return false;
		}

		return true;
	}
}