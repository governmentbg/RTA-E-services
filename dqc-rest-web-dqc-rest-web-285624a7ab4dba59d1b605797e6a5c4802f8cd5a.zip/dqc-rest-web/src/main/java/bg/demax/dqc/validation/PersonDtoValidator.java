package bg.demax.dqc.validation;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import bg.demax.dqc.dto.PersonDto;

public class PersonDtoValidator implements ConstraintValidator<ValidPersonDto, PersonDto> {
	
	private static final String DATE_FORMATTER_PATTERN = "yyyy-MM-dd";
	
	@Override
	public boolean isValid(PersonDto personDto, ConstraintValidatorContext context) {
		if(personDto.getPersonalNumberType() != PersonDto.EGN) {
			return true;
		}
		
		if(!checkPersNoBirth(personDto.getPersonalNumber(), personDto.getBirthDate())) {
			context.buildConstraintViolationWithTemplate("Error in PersonalNumber and BirthDateCheck").addConstraintViolation();
			return false;
		}
		return true;
	}

	private boolean checkPersNoBirth(String personalNumber, LocalDate birthDate) {
		if(personalNumber == null || birthDate == null) {	   
			return true;
		}
		String birthDateString = birthDate.format(DateTimeFormatter.ofPattern(DATE_FORMATTER_PATTERN));
		try {
		    if(personalNumber.charAt(0) == '\u0427')
			return true;
		    
		    int monthDigitInt = Integer.parseInt("" + personalNumber.charAt(2));
		    
		    if (monthDigitInt == 4 || monthDigitInt == 5) {
		    	monthDigitInt = monthDigitInt - 4;
		    }
	    
			if (personalNumber.charAt(0) != birthDateString.charAt(2)
					|| personalNumber.charAt(1) != birthDateString.charAt(3)
					|| Character.forDigit(monthDigitInt, 10) != birthDateString.charAt(5)
					|| personalNumber.charAt(3) != birthDateString.charAt(6)
					|| personalNumber.charAt(4) != birthDateString.charAt(8)
					|| personalNumber.charAt(5) != birthDateString.charAt(9)) {

				return false;
		    }
		} catch (Exception e) {
		    return false;
		}

		return true;
	}
}
