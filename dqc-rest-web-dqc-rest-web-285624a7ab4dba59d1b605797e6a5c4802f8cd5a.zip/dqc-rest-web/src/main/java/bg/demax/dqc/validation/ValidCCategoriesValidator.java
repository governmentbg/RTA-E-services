package bg.demax.dqc.validation;

import java.util.Arrays;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidCCategoriesValidator implements ConstraintValidator<ValidCCategories, String> {
	
	private List<String> C_CATEGORIES = Arrays.asList("", "C", "C1", "C CE", "C1 C1E");
	
	@Override
	public boolean isValid(String string, ConstraintValidatorContext context) {
		if(C_CATEGORIES.contains(string)) {
			return true;
		} 
		
		return false; 
	}
}
