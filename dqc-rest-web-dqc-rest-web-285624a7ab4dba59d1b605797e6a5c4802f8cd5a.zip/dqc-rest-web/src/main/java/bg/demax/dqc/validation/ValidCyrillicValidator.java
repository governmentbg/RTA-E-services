package bg.demax.dqc.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidCyrillicValidator implements ConstraintValidator<ValidCyrillic, String> {
	
	private String TYPE_TEXT_CYRILLIC = "[\\u0410-\\u044F0-9 \\\"\\n:;,+-./()]*";
	
	@Override
	public boolean isValid(String string, ConstraintValidatorContext context) {
		if(string == null || string.isEmpty()) {
			return true;
		}
		
		if(string.matches(TYPE_TEXT_CYRILLIC)) {
			return true;
		} 
		
		return false; 
	}
}