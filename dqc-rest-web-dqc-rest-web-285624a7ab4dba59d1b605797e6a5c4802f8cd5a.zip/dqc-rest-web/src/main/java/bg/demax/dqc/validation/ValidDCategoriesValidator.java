package bg.demax.dqc.validation;

import java.util.Arrays;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidDCategoriesValidator implements ConstraintValidator<ValidDCategories, String> {
	
	private List<String> D_CATEGORIES = Arrays.asList("", "D", "D1", "D DE", "D1 D1E" );
	
	@Override
	public boolean isValid(String string, ConstraintValidatorContext context) {
		if(D_CATEGORIES.contains(string)) {
			return true;
		} 
		
		return false; 
	}
}
