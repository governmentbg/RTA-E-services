package bg.demax.dqc.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidLatinValidator implements ConstraintValidator<ValidLatin, String> {
	
	private String TYPE_TEXT_LATIN = "[a-zA-Z0-9 \":;,+-./]*";
	
	@Override
	public boolean isValid(String string, ConstraintValidatorContext context) {
		if(string == null || string.isEmpty()) {
			return true;
		}
			
		if(string.matches(TYPE_TEXT_LATIN)) {
			return true;
		} 
		
		return false; 
	}
}