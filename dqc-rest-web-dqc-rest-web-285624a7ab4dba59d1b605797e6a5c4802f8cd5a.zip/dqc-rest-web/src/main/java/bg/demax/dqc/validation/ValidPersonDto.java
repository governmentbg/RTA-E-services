package bg.demax.dqc.validation;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Documented
@Retention(RUNTIME)
@Target({ ElementType.FIELD,
	ElementType.PARAMETER,
	ElementType.TYPE,
	ElementType.METHOD,
	ElementType.LOCAL_VARIABLE,
	ElementType.CONSTRUCTOR,
	ElementType.TYPE_PARAMETER,
	ElementType.TYPE_USE })
@Constraint(validatedBy = PersonDtoValidator.class)
public @interface ValidPersonDto {

	String message() default "{person.invalid}";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};

}
