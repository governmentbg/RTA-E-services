package bg.demax.dqc.test.conf;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableJpaRepositories(basePackages = "bg.demax.dqc.db.card", entityManagerFactoryRef = "dqcCardEntityManager", transactionManagerRef = "dqcCardTransactionManager")
@Profile("test")
public class TestDqcCardDBConf {

	public TestDqcCardDBConf() {
		super();
	}

	@Primary
	public DataSource dqcCardDataSource() {
	       return new EmbeddedDatabaseBuilder()
	            .generateUniqueName(true)
	            .setType(EmbeddedDatabaseType.H2)
	            .setScriptEncoding("UTF-8")
	            .ignoreFailedDrops(true)
	            //.addScript("schema.sql")
	            //.addScripts("user_data.sql", "country_data.sql")
	            .build();
	    }

	@Bean
	@Primary
	public LocalContainerEntityManagerFactoryBean dqcCardEntityManager() {
		final LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(dqcCardDataSource());
		em.setPackagesToScan("bg.demax.dqc.db.card.entity");

		final HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		return em;
	}

	@Bean
	@Primary
	public PlatformTransactionManager dqcCardTransactionManager() {
		final JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(dqcCardEntityManager().getObject());
		return transactionManager;
	}
}
