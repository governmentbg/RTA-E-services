package bg.demax.dqc.test.controller;

import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.dqc.db.card.entity.Card;
import bg.demax.dqc.db.card.entity.Certificate;
import bg.demax.dqc.db.card.entity.GeneratedSequence;
import bg.demax.dqc.db.card.repository.CardLogRepository;
import bg.demax.dqc.db.card.repository.CardRepository;
import bg.demax.dqc.db.card.repository.CertificateRepository;
import bg.demax.dqc.db.card.repository.GeneratedSequenceRepository;
import bg.demax.dqc.db.card.repository.PersonResository;
import bg.demax.dqc.db.card.repository.UserRepository;
import bg.demax.dqc.dto.DqcCardCertificateDto;
import bg.demax.dqc.dto.DqcCardDto;
import bg.demax.dqc.dto.PersonDto;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles(profiles = "test")
public class TestDqcCardController {
	
    @Autowired
    private MockMvc mockMvc;
    
	@MockBean
	private CardRepository cardRepository;
	
	@MockBean
	private PersonResository personResository;
	
	@MockBean
	private CertificateRepository certificateRepository;
	
	@MockBean
	private CardLogRepository cardLogRepository;
	
	@MockBean
	private UserRepository userRepository;
	
	@MockBean
	private GeneratedSequenceRepository generatedSequenceRepository;
	
	@Autowired 
	private ObjectMapper objectMapper;
	
	@Test
	public void testCardCreateNoRoleCheck() throws Exception {
		DqcCardDto dto = getDqcCardDto();
		
		String jsonStr = objectMapper.writeValueAsString(dto);
		
		mockMvc.perform(post("/dqc-rest-web/dqc-cards/create")
				 	.contextPath("/dqc-rest-web")
	                .content(jsonStr)
	                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
		 			.andExpect(status().isForbidden());	
	}

	@Test
	@WithMockUser(roles = "DQC_REST_API")
	public void testCardCreate() throws Exception {
		DqcCardDto dto = getDqcCardDto();

		String jsonStr = objectMapper.writeValueAsString(dto);
		
		given(generatedSequenceRepository.findCurrentValueByName(GeneratedSequence.BEGIN_SERIAL_NAME)).will(new Answer<GeneratedSequence>() {
			@Override
			public GeneratedSequence answer(InvocationOnMock invocation) throws Throwable {
				GeneratedSequence generatedSequence = new GeneratedSequence();
				generatedSequence.setCurrentValue("1");
				return generatedSequence;
			}	
		});
		
		given(certificateRepository.save(Mockito.any(Certificate.class))).will(new Answer<Certificate>() {
			@Override
			public Certificate answer(InvocationOnMock invocation) throws Throwable {
				Certificate cert = (Certificate) invocation.getArgument(0);
				cert.setId(2);
				return cert;
			}
		});

		given(cardRepository.save(Mockito.any(Card.class))).willAnswer(new Answer<Card>() {
			@Override
			public Card answer(InvocationOnMock invocation) throws Throwable {
				Card card = (Card) invocation.getArgument(0);
				card.setId(1);
				return card;
			}
		});

		given(certificateRepository.getBeginnerCertificateForPersonalNumberAfterOrderDate(Mockito.any(String.class),
				Mockito.any(String.class))).willReturn(true);

		mockMvc.perform(post("/dqc-rest-web/dqc-cards/create").contextPath("/dqc-rest-web").content(jsonStr)
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)).andExpect(status().isCreated());
	}
	
	@Test
	@WithMockUser(roles = "DQC_REST_API")
	public void testCardCreateLNC() throws Exception {
		DqcCardDto dto = getDqcCardDto();
		dto.getPerson().setPersonalNumberType(PersonDto.LNC);

		String jsonStr = objectMapper.writeValueAsString(dto);
		
		given(generatedSequenceRepository.findCurrentValueByName(GeneratedSequence.BEGIN_SERIAL_NAME)).will(new Answer<GeneratedSequence>() {
			@Override
			public GeneratedSequence answer(InvocationOnMock invocation) throws Throwable {
				GeneratedSequence generatedSequence = new GeneratedSequence();
				generatedSequence.setCurrentValue("1");
				return generatedSequence;
			}	
		});
		
		given(certificateRepository.save(Mockito.any(Certificate.class))).will(new Answer<Certificate>() {
			@Override
			public Certificate answer(InvocationOnMock invocation) throws Throwable {
				Certificate cert = (Certificate) invocation.getArgument(0);
				cert.setId(2);
				return cert;
			}
		});

		given(cardRepository.save(Mockito.any(Card.class))).willAnswer(new Answer<Card>() {
			@Override
			public Card answer(InvocationOnMock invocation) throws Throwable {
				Card card = (Card) invocation.getArgument(0);
				card.setId(1);
				assertTrue(card.getPerson().getPersonalNumber().contains(PersonDto.LNC_PREFIX));
				return card;
			}
		});

		given(certificateRepository.getBeginnerCertificateForPersonalNumberAfterOrderDate(Mockito.any(String.class),
				Mockito.any(String.class))).willReturn(true);

		mockMvc.perform(post("/dqc-rest-web/dqc-cards/create").contextPath("/dqc-rest-web").content(jsonStr)
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)).andExpect(status().isCreated());
	}
	
	@Test
	@WithMockUser(roles = "DQC_REST_API")
	public void testCardCreateNoMiddleName() throws Exception {
		DqcCardDto dto = getDqcCardDto();
		dto.setFathersName(null);
		dto.setFathersNameCyr(null);

		String jsonStr = objectMapper.writeValueAsString(dto);
		
		given(generatedSequenceRepository.findCurrentValueByName(GeneratedSequence.BEGIN_SERIAL_NAME)).will(new Answer<GeneratedSequence>() {
			@Override
			public GeneratedSequence answer(InvocationOnMock invocation) throws Throwable {
				GeneratedSequence generatedSequence = new GeneratedSequence();
				generatedSequence.setCurrentValue("1");
				return generatedSequence;
			}	
		});
		
		given(certificateRepository.save(Mockito.any(Certificate.class))).will(new Answer<Certificate>() {
			@Override
			public Certificate answer(InvocationOnMock invocation) throws Throwable {
				Certificate cert = (Certificate) invocation.getArgument(0);
				cert.setId(2);
				return cert;
			}
		});

		given(cardRepository.save(Mockito.any(Card.class))).willAnswer(new Answer<Card>() {
			@Override
			public Card answer(InvocationOnMock invocation) throws Throwable {
				Card card = (Card) invocation.getArgument(0);
				card.setId(1);
				return card;
			}
		});

		given(certificateRepository.getBeginnerCertificateForPersonalNumberAfterOrderDate(Mockito.any(String.class),
				Mockito.any(String.class))).willReturn(true);

		mockMvc.perform(post("/dqc-rest-web/dqc-cards/create").contextPath("/dqc-rest-web").content(jsonStr)
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)).andExpect(status().isCreated());
	}
	
	@Test
	@WithMockUser(roles = "DQC_REST_API")
	public void testCardCreateCyrilycCheck() throws Exception {
		DqcCardDto dto = getDqcCardDto();
		dto.setFirstNameCyr("This should fail");
		
		String jsonStr = objectMapper.writeValueAsString(dto);		
		
		 mockMvc.perform(post("/dqc-rest-web/dqc-cards/create")
				 	.contextPath("/dqc-rest-web")
	                .content(jsonStr)
	                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
		 			.andExpect(status().isBadRequest());
	}
	
	@Test
	@WithMockUser(roles = "DQC_REST_API")
	public void testCardCreateLatinCheck() throws Exception {
		DqcCardDto dto = getDqcCardDto();
		dto.setFirstName("Трябва да не мине");
		
		String jsonStr = objectMapper.writeValueAsString(dto);		
		
		 mockMvc.perform(post("/dqc-rest-web/dqc-cards/create")
				 	.contextPath("/dqc-rest-web")
	                .content(jsonStr)
	                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
		 			.andExpect(status().isBadRequest());
	}
	
	@Test
	@WithMockUser(roles = "DQC_REST_API")
	public void testCardCreatePhoneCheck() throws Exception {
		DqcCardDto dto = getDqcCardDto();
		dto.setFirstName("Трябва да не мине");
		
		String jsonStr = objectMapper.writeValueAsString(dto);		
		
		 mockMvc.perform(post("/dqc-rest-web/dqc-cards/create")
				 	.contextPath("/dqc-rest-web")
	                .content(jsonStr)
	                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
		 			.andExpect(status().isBadRequest());
	}
	
	
	@Test
	@WithMockUser(roles = "DQC_REST_API")
	public void testCardCreateMailCheck() throws Exception {
		DqcCardDto dto = getDqcCardDto();
		dto.setEmail("Трябва да не мине");
		
		String jsonStr = objectMapper.writeValueAsString(dto);		
		
		 mockMvc.perform(post("/dqc-rest-web/dqc-cards/create")
				 	.contextPath("/dqc-rest-web")
	                .content(jsonStr)
	                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
		 			.andExpect(status().isBadRequest());
	}
	
	@Test
	@WithMockUser(roles = "DQC_REST_API")
	public void testCardCreateCertificateDateCheck() throws Exception {

		
		DqcCardCertificateDto passengerCertificate = getPassengerCertificate();
		passengerCertificate.setEndDate(LocalDate.now().minusDays(10));
		
		DqcCardDto dto = getDqcCardDto();
		dto.setPassengerCertificate(passengerCertificate);
		
		String jsonStr = objectMapper.writeValueAsString(dto);		
			
		mockMvc.perform(post("/dqc-rest-web/dqc-cards/create")
				 	.contextPath("/dqc-rest-web")
	                .content(jsonStr)
	                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
		 			.andExpect(status().isBadRequest());
	}
	
	@Test
	@WithMockUser(roles = "DQC_REST_API")
	public void testCardCreateCertificateLessThenFiveDaysDateCheck() throws Exception {
		
		DqcCardCertificateDto passengerCertificate = getPassengerCertificate();
		passengerCertificate.setEndDate(passengerCertificate.getStartDate().plusDays(3));
		
		DqcCardDto dto = getDqcCardDto();
		dto.setPassengerCertificate(passengerCertificate);
		
		String jsonStr = objectMapper.writeValueAsString(dto);		
			
		mockMvc.perform(post("/dqc-rest-web/dqc-cards/create")
				 	.contextPath("/dqc-rest-web")
	                .content(jsonStr)
	                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
		 			.andExpect(status().isBadRequest());
	}
	
	/*
	 * @Test
	 * 
	 * @WithMockUser(roles = "DQC_REST_API") public void
	 * testCardCreateCertificateValidationPersonAlreadyHasBeginnerCertificateCheck()
	 * throws Exception { DqcCardDto dto = getDqcCardDto();
	 * dto.getCargoCertificate().setCertType(Certificate.TYPE_35);
	 * 
	 * String jsonStr = objectMapper.writeValueAsString(dto);
	 * 
	 * given(certificateRepository.getBeginnerCertificateForPersonalNumber(Mockito.
	 * any(String.class), Mockito.any(String.class))) .willReturn(true);
	 * 
	 * mockMvc.perform(post("/dqc-rest-web/dqc-cards/create")
	 * .contextPath("/dqc-rest-web") .content(jsonStr)
	 * .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
	 * .andExpect(status().isBadRequest()); }
	 */
	
	@Test
	@WithMockUser(roles = "DQC_REST_API")
	public void testCardCreateCertificateValidationBeginnerCertificateForPersonalNumberAfterOrderDateCheck() throws Exception {
		DqcCardDto dto = getDqcCardDto();
		dto.setCatsCDate(LocalDate.parse("2007-09-10"));
		
		String jsonStr = objectMapper.writeValueAsString(dto);
		
		given(certificateRepository.getBeginnerCertificateForPersonalNumber(
				Mockito.any(String.class), 
				Mockito.any(String.class)))
			.willReturn(false);
		given(certificateRepository.getBeginnerCertificateForPersonalNumberAfterOrderDate(
				Mockito.any(String.class), 
				Mockito.any(String.class)))
			.willReturn(false);
			
		mockMvc.perform(post("/dqc-rest-web/dqc-cards/create")
				 	.contextPath("/dqc-rest-web")
	                .content(jsonStr)
	                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
		 			.andExpect(status().isBadRequest());
	}
	
	@Test
	@WithMockUser(roles = "DQC_REST_API")
	public void testCardCreateCertificateValidationhasTransitionalCertificatesCheck() throws Exception {
		DqcCardDto dto = getDqcCardDto();
		dto.getCargoCertificate().setCertType(Certificate.TYPE_35);
		
		String jsonStr = objectMapper.writeValueAsString(dto);
		given(certificateRepository.save(Mockito.any(Certificate.class))).will(new Answer<Certificate>() {
			@Override
			public Certificate answer(InvocationOnMock invocation) throws Throwable {
				Certificate cert = (Certificate) invocation.getArgument(0);
				cert.setId(2);
				return cert;
			}
		});	
		given(certificateRepository.getBeginnerCertificateForPersonalNumber(
				dto.getPerson().getPersonalNumber(), 
				Certificate.CARGO))
			.willReturn(false);
		given(certificateRepository.getBeginnerCertificateForPersonalNumberAfterOrderDate(
				Mockito.any(String.class), 
				Mockito.any(String.class)))
			.willReturn(true);
		given(certificateRepository.getBeginnerCertificateForPersonalNumber(
				dto.getPerson().getPersonalNumber(), 
				Certificate.PASSENGERS))
		.willReturn(false);
			
		mockMvc.perform(post("/dqc-rest-web/dqc-cards/create")
				 	.contextPath("/dqc-rest-web")
	                .content(jsonStr)
	                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
		 			.andExpect(status().isBadRequest());
	}
	
	@Test
	@WithMockUser(roles = "DQC_REST_API")
	public void testCardCreateCertificateValidationhasTransitionalCertificatesInSetCheck() throws Exception {
		DqcCardDto dto = getDqcCardDto();
		dto.getCargoCertificate().setCertType(Certificate.TYPE_35);
		
		String jsonStr = objectMapper.writeValueAsString(dto);
		
		given(certificateRepository.save(Mockito.any(Certificate.class)))
			.willAnswer(ans -> ans.getArgument(0));
		
		given(cardRepository.save(Mockito.any(Card.class)))
			.will(ans -> ans.getArgument(0));
		
		given(certificateRepository.getBeginnerCertificateForPersonalNumber(
				dto.getPerson().getPersonalNumber(), 
				Certificate.CARGO))
			.willReturn(false);
		given(certificateRepository.getBeginnerCertificateForPersonalNumberAfterOrderDate(
				Mockito.any(String.class), 
				Mockito.any(String.class)))
			.willReturn(false);
		given(certificateRepository.getBeginnerCertificateForPersonalNumber(
				dto.getPerson().getPersonalNumber(), 
				Certificate.PASSENGERS))
		.willReturn(false);
		
		given(generatedSequenceRepository.findCurrentValueByName(GeneratedSequence.PERIOD_SERIAL_NAME))
			.willReturn(getGeneratedSquence());
		
		given(generatedSequenceRepository.findCurrentValueByName(GeneratedSequence.BEGIN_SERIAL_NAME))
			.willReturn(getGeneratedSquence());
			
		mockMvc.perform(post("/dqc-rest-web/dqc-cards/create")
				 	.contextPath("/dqc-rest-web")
	                .content(jsonStr)
	                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
		 			.andExpect(status().isCreated());
	}
	
	private GeneratedSequence getGeneratedSquence() {
		GeneratedSequence sq = new GeneratedSequence();
		sq.setCurrentValue("1");
		return sq;
	}

	@Test
	@WithMockUser(roles = "DQC_REST_API")
	public void testCertifcateValidationEducationalPeriodIsNotValidCheck() throws Exception {
		DqcCardDto dto = getDqcCardDto();
		dto.getCargoCertificate().setCertType(Certificate.TYPE_140);
		dto.getCargoCertificate().setEndDate(dto.getCargoCertificate().getStartDate().plusDays(6));
		dto.getPassengerCertificate().setCertType(Certificate.TYPE_140);
		
		String jsonStr = objectMapper.writeValueAsString(dto);
		
		given(certificateRepository.getBeginnerCertificateForPersonalNumber(
				Mockito.any(String.class), 
				Mockito.any(String.class)))
		.willReturn(false);
		
		mockMvc.perform(post("/dqc-rest-web/dqc-cards/create")
				 	.contextPath("/dqc-rest-web")
	                .content(jsonStr)
	                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
		 			.andExpect(status().isBadRequest());
	}
	
	
	@Test
	@WithMockUser(roles = "DQC_REST_API")
	public void testCertifcateValidationCheck() throws Exception {
		DqcCardDto dto = getDqcCardDto();
		
		String jsonStr = objectMapper.writeValueAsString(dto);		
		
		mockMvc.perform(post("/dqc-rest-web/dqc-cards/create")
				 	.contextPath("/dqc-rest-web")
	                .content(jsonStr)
	                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
		 			.andExpect(status().isBadRequest());
	}
	
	
	
	private DqcCardDto getDqcCardDto() {
		DqcCardDto dto = new DqcCardDto();
		dto.setFirstName("test");
		dto.setFirstNameCyr("Тест");
		dto.setSurName("Testt");
		dto.setSurNameCyr("Тест");
		dto.setFathersName("Testtt");
		dto.setFathersNameCyr("Тест");
		dto.setCategoriesC("C");
		dto.setCategoriesD("D");
		dto.setResidenceAddress("Няма");
		dto.setPostalDistrict("Нямаа");
		dto.setPostalCity("1748");
		dto.setPostalAddress("Нямааа");
		dto.setPhone("0898828296");
		dto.setEmail("test@test.bg");
		dto.setLicenseNumber("00002");
		dto.setLicenseIssuer("ТестЛиценсеИздател");
		dto.setLicenseIssueDate(LocalDate.now());
		dto.setPassNumber("0003");
		dto.setPassIssuer("Издал разрешение");
		dto.setPassIssueDate(LocalDate.now());
		dto.setDescription("Описание");
		dto.setResidenceDistrict("Община");
		dto.setResidenceCity("Град");
		dto.setIssueDate(LocalDate.now());
		dto.setCatsCDate(LocalDate.now());
		dto.setCatsDDate(LocalDate.now());
		dto.setPerson(getPerson());
		dto.setFace("12313");
		dto.setSignature("13213");
		dto.setCargoCertificate(getCargoCertificate());
		dto.setPassengerCertificate(getPassengerCertificate());

		return dto;
	}

	private DqcCardCertificateDto getPassengerCertificate() {
		DqcCardCertificateDto dto = new DqcCardCertificateDto();
		dto.setIssuerNumber("1");
		dto.setIssuer("002");
		dto.setCertType(Certificate.TYPE_140);
		dto.setStartDate(LocalDate.now().minusDays(25));
		dto.setEndDate(LocalDate.now());
		dto.setIssueDate(LocalDate.now());
		dto.setValidTo(LocalDate.now().plusYears(5));
		
		return dto;
	}

	private DqcCardCertificateDto getCargoCertificate() {
		DqcCardCertificateDto dto = new DqcCardCertificateDto();
		dto.setIssuerNumber("3");
		dto.setIssuer("04");
		dto.setCertType(Certificate.TYPE_140);
		dto.setStartDate(LocalDate.now().minusDays(25));
		dto.setEndDate(LocalDate.now());
		dto.setIssueDate(LocalDate.now());
		dto.setValidTo(LocalDate.now().plusYears(5));
		
		return dto;
	}

	private PersonDto getPerson() {
		PersonDto dto = new PersonDto();
		dto.setPersonalNumber("8107115843");
		dto.setPersonalNumberType(PersonDto.EGN);
		dto.setBirthPlace("Test");
		dto.setBirthPlaceCyr("Тест");
		dto.setBirthDate(LocalDate.parse("1981-07-11"));
		
		return dto;
	}
}
