package bg.demax.iaaa.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IaaaGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(IaaaGatewayApplication.class, args);
	}

}
