package bg.demax.iaaa.gateway.config;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.iaaa.gateway.restproxying.resttemplate.RestProxyingRestTemplateService;
import bg.demax.iaaa.gateway.restproxying.resttemplate.config.RestProxyingRestTemplateConfig;
import bg.demax.iaaa.gateway.utils.ObjectMapperUtils;

@Configuration
public class BeanConfigurations {

	@Autowired
	private RestProxyingRestTemplateService service;

	@Bean
	public GenericSearchSupport genericSearchSupport() {
		return new GenericSearchSupport();
	}

	@Bean
	@Qualifier(BeanQualifiers.CACHE_OBJECT_MAPPER)
	public ObjectMapper jsonMapper() {
		ObjectMapper mapper = new ObjectMapper();

		JavaTimeModule javaTimeModule = new JavaTimeModule();
		javaTimeModule.addSerializer(
				new LocalDateTimeSerializer(DateTimeFormatter.ofPattern(IaaaGatewayConstants.DATE_TIME_FORMAT)));
		javaTimeModule
				.addSerializer(new LocalDateSerializer(DateTimeFormatter.ofPattern(IaaaGatewayConstants.DATE_FORMAT)));
		javaTimeModule.addDeserializer(LocalDateTime.class,
				new LocalDateTimeDeserializer(DateTimeFormatter.ofPattern(IaaaGatewayConstants.DATE_TIME_FORMAT)));
		javaTimeModule.addDeserializer(LocalDate.class,
				new LocalDateDeserializer(DateTimeFormatter.ofPattern(IaaaGatewayConstants.DATE_FORMAT)));

		mapper.registerModule(javaTimeModule);

		return mapper;
	}

	@Bean
	@Primary
	public ObjectMapper defaultMapper() {
		return ObjectMapperUtils.getNewConfiguredObjectMapper();
	}

	@Bean
	@Qualifier(BeanQualifiers.GRAO_REST_TEMPLATE)
	public RestTemplate graoRestTemplate() {
		RestProxyingRestTemplateConfig config = new RestProxyingRestTemplateConfig();
		config.setReadTimeout((short) 15);
		config.setConnectionTimeout((short) 15);
		RestTemplate restTemplate = service.createRestTemplate(config);

		return restTemplate;
	}
}
