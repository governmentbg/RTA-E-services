package bg.demax.iaaa.gateway.config;

public interface BeanQualifiers {

	String IAAA_PROXIES_DATASOURCE = "iaaa-proxies-datasource";
	String IAAA_PROXIES_SESSION_FACTORY = "iaaa-proxies-session-factory";
	String IAAA_PROXIES_TRANSACTION_MANAGER = "iaaa-proxies-transaction-manager";
	String IAAA_PROXIES_GENERIC_REPOSITORY = "iaaa-proxies-generic-repository";

	String IAAA_IMG_DATASOURCE = "iaaa-img-datasource";
	String IAAA_IMG_SESSION_FACTORY = "iaaa-img-session-factory";
	String IAAA_IMG_TRANSACTION_MANAGER = "iaaa-img-transaction-manager";

	String CACHE_OBJECT_MAPPER = "postgre-json-object-mapper";

	String DEFAULT_SPRING_BOOT_CONVERSION_SERVICE = "mvcConversionService";

	String GRAO_REST_TEMPLATE = "grao-rest-template";

}
