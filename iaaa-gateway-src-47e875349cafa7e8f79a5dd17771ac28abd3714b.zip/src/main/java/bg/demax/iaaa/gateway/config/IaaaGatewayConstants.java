package bg.demax.iaaa.gateway.config;

public interface IaaaGatewayConstants {

	String SPRING_PROFILE_TEST = "test";              // profile for unit tests
	String SPRING_PROFILE_IAAA_TEST = "iaaa-test";    // profile for deployment to the iaaa test env at 192.168.168.25
	String SPRING_PROFILE_PRODUCTION = "production";  // profile for deployment to the production env at 192.168.168.28
	String SPRING_PROFILE_DEVELOPMENT = "dev";        // profile for deployment to the dev env at drive.demax.bg

	String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm";	  // ISO-8601 standard DateTimeFormatter.ISO_DATE_TIME
	String DATE_FORMAT = "yyyy-MM-dd";				  // ISO-8601 standard DateTimeFormatter.ISO_DATE

	String DUMMY_REST_TEMPLATE = "dummy-rest-template";

	String[] IAAA_PROXIES_ENTITY_PACKAGES_TO_SCAN = { "bg.demax.iaaa.gateway.db.entity.iaaaproxies" };

	String[] IAAA_IMG_ENTITY_PACKAGES_TO_SCAN = {
		"bg.demax.pub.entity",
		"bg.demax.security.entity",
		"bg.demax.techinsp.entity",
	};

	String IAAA_PROXIES_REPOSITORY_PACKAGE = "bg.demax.iaaa.gateway.db.repository.iaaaproxies";

	String IAAA_IMG_REPOSITORY_PACKAGE = "bg.demax.iaaa.gateway.db.repository.iaaaimg";

	String[] TEAM_SPIKE = {
		"i.rusev@demax.bg",
		"k.nacheva@demax.bg",
		"zg.ivanova@demax.bg",
		"s.dakova@demax.bg",
		"martin@demax.bg"
	};

}
