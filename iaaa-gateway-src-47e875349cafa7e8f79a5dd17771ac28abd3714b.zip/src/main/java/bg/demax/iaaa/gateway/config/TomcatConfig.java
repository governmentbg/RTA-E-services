package bg.demax.iaaa.gateway.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile({ IaaaGatewayConstants.SPRING_PROFILE_IAAA_TEST, IaaaGatewayConstants.SPRING_PROFILE_PRODUCTION })
public class TomcatConfig {

	private static final String PROTOCOL = "AJP/1.3";

	@Value("${apache2_to_tomcat.ajp.enabled}")
	private boolean tomcatAjpEnabled;

	@Value("${server.port}")
	private int ajpPort;

	@Value("${apache2_to_tomcat.ajp.secure}")
	private boolean secure;

	@Value("${apache2_to_tomcat.ajp.scheme}")
	private String scheme;

	@Bean
	public ConfigurableServletWebServerFactory webServerFactory() {
		TomcatServletWebServerFactory factory = new TomcatServletWebServerFactory();
		if (tomcatAjpEnabled) {
			factory.setProtocol(PROTOCOL);

			factory.addConnectorCustomizers(connector -> {
				connector.setScheme(scheme);
				connector.setPort(ajpPort);
				connector.setSecure(secure);
			});
		}

		return factory;
	}
}
