package bg.demax.iaaa.gateway.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;
import org.springframework.security.web.authentication.preauth.RequestHeaderAuthenticationFilter;

import bg.demax.iaaa.gateway.security.SecurityGroups;
import bg.demax.iaaa.gateway.security.UserDetailsServiceImpl;

@Configuration
@EnableWebSecurity
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

	public static final String PRE_AUTH_HEADER_NAME = "SSL_PUBLIC_KEY";

	@Autowired
	private UserDetailsServiceImpl userDetailsService;

	@Autowired
	private AuthenticationEntryPoint authenticationEntryPoint;

	@Autowired
	private AccessDeniedHandler accessDeniedHandler;

	@Bean
	public AuthenticationManager authenticationManager() {
		return new ProviderManager(Arrays.asList(preAuthenticatedAuthenticationProvider()));
	}

	private PreAuthenticatedAuthenticationProvider preAuthenticatedAuthenticationProvider() {
		PreAuthenticatedAuthenticationProvider provider = new PreAuthenticatedAuthenticationProvider();

		provider.setPreAuthenticatedUserDetailsService(userDetailsService);

		return provider;
	}

	private AbstractPreAuthenticatedProcessingFilter preAuthenticatedProcessingFilter() {
		RequestHeaderAuthenticationFilter filter = new RequestHeaderAuthenticationFilter();

		filter.setPrincipalRequestHeader(PRE_AUTH_HEADER_NAME);
		filter.setAuthenticationManager(authenticationManager());
		filter.setExceptionIfHeaderMissing(false);

		return filter;
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
		.addFilterAt(preAuthenticatedProcessingFilter(), AbstractPreAuthenticatedProcessingFilter.class)
		.cors()
		.and()
		.csrf().disable()
		.exceptionHandling()
			.accessDeniedHandler(accessDeniedHandler)
			.authenticationEntryPoint(authenticationEntryPoint);

		authRequestsAndAddMatchers(http);

		http.authorizeRequests().anyRequest().authenticated();
	}

	private ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry authRequestsAndAddMatchers(
			HttpSecurity httpSecurity) throws Exception {

		return httpSecurity
				.authorizeRequests()
				.mvcMatchers("/swagger-ui.html", "/webjars/**", "/swagger-resources/**", "/v2/**").permitAll()
					.mvcMatchers(HttpMethod.GET, "/api/test").hasAnyRole(SecurityGroups.GENERIC.getRolesInGroup())
					.mvcMatchers(HttpMethod.GET, "/api/test/regix/cache").hasAnyRole(SecurityGroups.GENERIC.getRolesInGroup())
					.mvcMatchers(HttpMethod.GET, "/api/vehicles/inspections/last/valid").hasAnyRole(SecurityGroups.INSPECTIONS.getRolesInGroup())
					.mvcMatchers(HttpMethod.GET, "/api/vehicles/inspections/last").hasAnyRole(SecurityGroups.INSPECTIONS.getRolesInGroup())
					.mvcMatchers(HttpMethod.GET, "/api/vehicles/inspections/history").hasAnyRole(SecurityGroups.INSPECTIONS.getRolesInGroup())
					.mvcMatchers(HttpMethod.PUT, "/api/rest-proxying/config/**").hasAnyRole(SecurityGroups.FULL_ACCESS.getRolesInGroup())
					.mvcMatchers("/api/proxy/dqc/**").hasAnyRole(SecurityGroups.PROXY.getRolesInGroup())
					.mvcMatchers("/api/proxy/road-service/**").hasAnyRole(SecurityGroups.PROXY.getRolesInGroup())
					.mvcMatchers("/api/proxy/auto/**").hasAnyRole(SecurityGroups.PROXY.getRolesInGroup())
					.mvcMatchers("/api/grao/**").hasAnyRole(SecurityGroups.GENERIC.getRolesInGroup());
	}
}
