package bg.demax.iaaa.gateway.config.db;

public interface CacheDbTablenames {

	String INSPECTIONS_LAST_VALID = "l_inspections_last_valid";
	String INSPECTIONS_LAST = "l_inspections_last";
	String INSPECTIONS_HISTORY = "l_inspections_history";
	String CACHE_SCHEMA = "iaaa_gateway";
	String GRAO_PERSON_DATA = "l_grao_person_data";

}
