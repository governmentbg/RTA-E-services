package bg.demax.iaaa.gateway.config.db;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.zaxxer.hikari.HikariDataSource;

import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;

@Configuration
@Profile("!" + IaaaGatewayConstants.SPRING_PROFILE_TEST)
public class DataSourceConfiguration {

	@Value("${jdbc.config.iaaa-proxies.url}")
	private String iaaaProxiesJdbcUrl;

	@Value("${jdbc.config.iaaa-proxies.username}")
	private String iaaaProxiesUsername;

	@Value("${jdbc.config.iaaa-proxies.password}")
	private String iaaaProxiesPassword;

	@Value("${jdbc.config.iaaa-img-repl.url}")
	private String iaaaImgJdbcUrl;

	@Value("${jdbc.config.iaaa-img-repl.username}")
	private String iaaaImgUsername;

	@Value("${jdbc.config.iaaa-img-repl.password}")
	private String iaaaImgPassword;

	private static final int MAX_POOL_SIZE = 2;
	private static final long CONNECTION_TIMEOUT = 2 * 60 * 1000;
	private static final long MAX_CONNECTION_IDLE_TIMEOUT = 3 * 60 * 1000;

	@Bean
	@Qualifier(BeanQualifiers.IAAA_PROXIES_DATASOURCE)
	public DataSource dataSourceForIaaaProxies() {
		HikariDataSource dataSource = new HikariDataSource();

		dataSource.setJdbcUrl(iaaaProxiesJdbcUrl);
		dataSource.setUsername(iaaaProxiesUsername);
		dataSource.setPassword(iaaaProxiesPassword);
		dataSource.setMaximumPoolSize(MAX_POOL_SIZE);
		dataSource.setConnectionTimeout(CONNECTION_TIMEOUT);
		dataSource.setIdleTimeout(MAX_CONNECTION_IDLE_TIMEOUT);
		dataSource.setMinimumIdle(0);

		return dataSource;
	}

	@Bean
	@Qualifier(BeanQualifiers.IAAA_IMG_DATASOURCE)
	public DataSource dataSourceForIaaImgTest() {
		HikariDataSource dataSource = new HikariDataSource();

		dataSource.setJdbcUrl(iaaaImgJdbcUrl);
		dataSource.setUsername(iaaaImgUsername);
		dataSource.setPassword(iaaaImgPassword);
		dataSource.setMaximumPoolSize(MAX_POOL_SIZE);
		dataSource.setConnectionTimeout(CONNECTION_TIMEOUT);
		dataSource.setIdleTimeout(MAX_CONNECTION_IDLE_TIMEOUT);
		dataSource.setMinimumIdle(0);

		return dataSource;
	}
}
