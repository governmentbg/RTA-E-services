package bg.demax.iaaa.gateway.config.db;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;

@Configuration
@Profile("!" + IaaaGatewayConstants.SPRING_PROFILE_TEST)
@EnableJpaRepositories(
		basePackages = IaaaGatewayConstants.IAAA_IMG_REPOSITORY_PACKAGE,
		entityManagerFactoryRef = BeanQualifiers.IAAA_IMG_SESSION_FACTORY,
		transactionManagerRef = BeanQualifiers.IAAA_IMG_TRANSACTION_MANAGER
)
public class IaaaImgDbConfiguration {

	@Value("${hibernate.dialect}")
	private String dialect;

	@Value("${hibernate.format_sql}")
	private String formatSql;

	@Value("${hibernate.show_sql}")
	private String showSql;

	@Value("${hibernate.temp.use_jdbc_metadata_defaults}")
	private String jdbcMetaDataDefaults;

	@Autowired
	@Qualifier(BeanQualifiers.IAAA_IMG_DATASOURCE)
	private DataSource iaaaImgDataSource;

	@Bean(name = BeanQualifiers.IAAA_IMG_TRANSACTION_MANAGER)
	public PlatformTransactionManager iaaaImgTransactionManager() {
		JpaTransactionManager jpaTransactionManager = new JpaTransactionManager();
		jpaTransactionManager.setEntityManagerFactory(sessionFactoryBean().getObject());
		return jpaTransactionManager;
	}

	@Bean(name = BeanQualifiers.IAAA_IMG_SESSION_FACTORY)
	@Qualifier(BeanQualifiers.IAAA_IMG_SESSION_FACTORY)
	public LocalSessionFactoryBean sessionFactoryBean() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(iaaaImgDataSource);
		sessionFactory.setPackagesToScan(IaaaGatewayConstants.IAAA_IMG_ENTITY_PACKAGES_TO_SCAN);
		sessionFactory.setHibernateProperties(hibernateProperties());
		return sessionFactory;
	}

	private Properties hibernateProperties() {
		Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty("hibernate.dialect", dialect);
		hibernateProperties.setProperty("hibernate.format_sql", formatSql);
		hibernateProperties.setProperty("hibernate.show_sql", showSql);
		hibernateProperties.setProperty("hibernate.temp.use_jdbc_metadata_defaults", jdbcMetaDataDefaults);

		return hibernateProperties;
	}
}
