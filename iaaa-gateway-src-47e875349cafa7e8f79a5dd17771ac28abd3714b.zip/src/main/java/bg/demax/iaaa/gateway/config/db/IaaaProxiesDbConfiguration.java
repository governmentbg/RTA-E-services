package bg.demax.iaaa.gateway.config.db;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;
import bg.demax.iaaa.gateway.db.repository.GenericRepository;

@Configuration
@Profile("!" + IaaaGatewayConstants.SPRING_PROFILE_TEST)
@EnableJpaRepositories(
		basePackages = IaaaGatewayConstants.IAAA_PROXIES_REPOSITORY_PACKAGE,
		entityManagerFactoryRef = BeanQualifiers.IAAA_PROXIES_SESSION_FACTORY,
		transactionManagerRef = BeanQualifiers.IAAA_PROXIES_TRANSACTION_MANAGER
)
public class IaaaProxiesDbConfiguration {

	@Value("${hibernate.dialect}")
	private String dialect;

	@Value("${hibernate.format_sql}")
	private String formatSql;

	@Value("${hibernate.show_sql}")
	private String showSql;

	@Value("${hibernate.temp.use_jdbc_metadata_defaults}")
	private String jdbcMetaDataDefaults;

	@Autowired
	@Qualifier(BeanQualifiers.IAAA_PROXIES_DATASOURCE)
	private DataSource iaaaProxiesDataSource;

	@Bean(name = BeanQualifiers.IAAA_PROXIES_TRANSACTION_MANAGER)
	public PlatformTransactionManager iaaaImgTransactionManager() {
		JpaTransactionManager jpaTransactionManager = new JpaTransactionManager();
		jpaTransactionManager.setEntityManagerFactory(sessionFactoryBean().getObject());
		return jpaTransactionManager;
	}

	@Bean(name = BeanQualifiers.IAAA_PROXIES_SESSION_FACTORY)
	@Qualifier(BeanQualifiers.IAAA_PROXIES_SESSION_FACTORY)
	public LocalSessionFactoryBean sessionFactoryBean() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(iaaaProxiesDataSource);
		sessionFactory.setPackagesToScan(IaaaGatewayConstants.IAAA_PROXIES_ENTITY_PACKAGES_TO_SCAN);
		sessionFactory.setHibernateProperties(hibernateProperties());
		return sessionFactory;
	}

	@Bean
	@Qualifier(BeanQualifiers.IAAA_PROXIES_GENERIC_REPOSITORY)
	public GenericRepository iaaaProxiesGenericRepository() {
		return new GenericRepository(sessionFactoryBean().getObject());
	}

	@Bean
	public NamedParameterJdbcTemplate getJdbcTemplate() {
		return new NamedParameterJdbcTemplate(iaaaProxiesDataSource);
	}

	private Properties hibernateProperties() {
		Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty("hibernate.dialect", dialect);
		hibernateProperties.setProperty("hibernate.format_sql", formatSql);
		hibernateProperties.setProperty("hibernate.show_sql", showSql);
		hibernateProperties.setProperty("hibernate.temp.use_jdbc_metadata_defaults", jdbcMetaDataDefaults);

		return hibernateProperties;
	}

}