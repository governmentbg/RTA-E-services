package bg.demax.iaaa.gateway.config.restproxying;

public class ProxyConfigurationProperties {
	private String localPath;
	private String remoteUrl;
	private String httpMethod;
	private String keystore;
	private String truststore;
	private String keystorePassword;
	private String truststorePassword;
	private Short readTimeoutSeconds;
	private Short connectionTimeoutSeconds;
	private String keystoreType;
	private String truststoreType;
	private String cacheTableName;
	private String basicAuthUsername;
	private String basicAuthPassword;

	public String getLocalPath() {
		return localPath;
	}

	public void setLocalPath(String localPath) {
		this.localPath = localPath;
	}

	public String getRemoteUrl() {
		return remoteUrl;
	}

	public void setRemoteUrl(String remoteUrl) {
		this.remoteUrl = remoteUrl;
	}

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	public String getKeystore() {
		return keystore;
	}

	public void setKeystore(String keystore) {
		this.keystore = keystore;
	}

	public String getTruststore() {
		return truststore;
	}

	public void setTruststore(String truststore) {
		this.truststore = truststore;
	}

	public String getKeystorePassword() {
		return keystorePassword;
	}

	public void setKeystorePassword(String keystorePassword) {
		this.keystorePassword = keystorePassword;
	}

	public String getTruststorePassword() {
		return truststorePassword;
	}

	public void setTruststorePassword(String truststorePassword) {
		this.truststorePassword = truststorePassword;
	}

	public Short getReadTimeoutSeconds() {
		return readTimeoutSeconds;
	}

	public void setReadTimeoutSeconds(Short readTimeoutSeconds) {
		this.readTimeoutSeconds = readTimeoutSeconds;
	}

	public Short getConnectionTimeoutSeconds() {
		return connectionTimeoutSeconds;
	}

	public void setConnectionTimeoutSeconds(Short connectionTimeoutSeconds) {
		this.connectionTimeoutSeconds = connectionTimeoutSeconds;
	}

	public String getKeystoreType() {
		return keystoreType;
	}

	public void setKeystoreType(String keystoreType) {
		this.keystoreType = keystoreType;
	}

	public String getTruststoreType() {
		return truststoreType;
	}

	public void setTruststoreType(String truststoreType) {
		this.truststoreType = truststoreType;
	}

	public String getCacheTableName() {
		return cacheTableName;
	}

	public void setCacheTableName(String cacheTableName) {
		this.cacheTableName = cacheTableName;
	}

	public String getBasicAuthUsername() {
		return basicAuthUsername;
	}

	public void setBasicAuthUsername(String basicAuthUsername) {
		this.basicAuthUsername = basicAuthUsername;
	}

	public String getBasicAuthPassword() {
		return basicAuthPassword;
	}

	public void setBasicAuthPassword(String basicAuthPassword) {
		this.basicAuthPassword = basicAuthPassword;
	}

}
