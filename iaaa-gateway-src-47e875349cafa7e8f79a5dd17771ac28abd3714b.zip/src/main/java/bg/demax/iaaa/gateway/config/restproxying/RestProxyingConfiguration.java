package bg.demax.iaaa.gateway.config.restproxying;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;

@Configuration
@Profile("!" + IaaaGatewayConstants.SPRING_PROFILE_TEST)
public class RestProxyingConfiguration {

	//Example for when  adding proxy config as app properties
	//
	//@Bean
	//@ConfigurationProperties("proxy.road-service.psycho-cert")
	//public ProxyConfigurationProperties proxyConfigPropsPsychoCertCheckProps() {
		//ProxyConfigurationProperties properties = new ProxyConfigurationProperties();
		//return properties;
	//}

}
