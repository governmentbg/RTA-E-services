package bg.demax.iaaa.gateway.config.swagger;

public interface Swagger2Constants {
	String VALID_CATEGORIES = "L3,L3e,L4,L4e,L5,L6e,L1,L2,L1e,L2e,L5e,L7e,M1,M1G,M2,M2G,M3,M3G,"
			+ "N1,N1G,AB1,AB2,AP2,N2,AP1,N2G,N3,N3G,O1,O2,O3,O4,T";

	String VALID_INSPECTION_TYPES = "ЛЕК АВТОМОБИЛ, АВТОБУС, ТОВАРЕН АВТОМОБИЛ, МОТОЦИКЛЕТ, ВЛЕКАЧ, КОЛЕСЕН ТРАКТОР,"
			+ " МОТОПЕД, МОТОЦИКЛЕТ С КОШ, ПОЛУРЕМАРКЕ, РЕМАРКЕ ЗА ЛЕК АВТОМОБИЛ, РЕМАРКЕ ЗА ТОВАРЕН АВТОМОБИЛ,"
			+ " ТРИКОЛЕСНО ПС, ЧЕТИРИКОЛЕСНО ПС, КОЛЕСАР,СПЕЦИАЛЕН АВТОМОБИЛ ";
}
