package bg.demax.iaaa.gateway.controller;

import java.util.concurrent.Callable;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.iaaa.gateway.config.db.CacheDbTablenames;
import bg.demax.iaaa.gateway.controller.params.GraoParams;
import bg.demax.iaaa.gateway.graowsdl.GraoResponse;
import bg.demax.iaaa.gateway.service.CacheService;
import bg.demax.iaaa.gateway.service.GraoService;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@RequestMapping("api/grao")
public class GraoController {

	@Autowired
	private GraoService graoService;

	@Autowired
	private CacheService cacheService;

	@GetMapping(path = "/person", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public GraoResponse getGraoResponse(@Valid GraoParams params, @ApiIgnore @RequestHeader HttpHeaders headers) throws Exception {

		GraoResponse graoResponse = cacheService.smartCache(new Callable<GraoResponse>() {
			@Override
			public GraoResponse call() throws Exception {
				return graoService.getGraoResponse(params);
			}
		}, params, headers, CacheDbTablenames.GRAO_PERSON_DATA, GraoResponse.class);

		return graoResponse;
	}
}
