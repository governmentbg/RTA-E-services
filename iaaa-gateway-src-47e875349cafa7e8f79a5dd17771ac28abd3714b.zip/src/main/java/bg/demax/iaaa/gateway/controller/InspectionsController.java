package bg.demax.iaaa.gateway.controller;

import java.util.List;
import java.util.concurrent.Callable;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.type.TypeReference;

import bg.demax.iaaa.gateway.config.db.CacheDbTablenames;
import bg.demax.iaaa.gateway.controller.params.InspectionParams;
import bg.demax.iaaa.gateway.controller.params.InspectionParamsLight;
import bg.demax.iaaa.gateway.controller.utils.ControllerUtil;
import bg.demax.iaaa.gateway.dto.HistoryInspectionDto;
import bg.demax.iaaa.gateway.dto.LastInspectionDto;
import bg.demax.iaaa.gateway.dto.ValidInspectionResponse;
import bg.demax.iaaa.gateway.search.InspectionSearch;
import bg.demax.iaaa.gateway.service.CacheService;
import bg.demax.iaaa.gateway.service.InspectionsService;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@RequestMapping("/api/vehicles/inspections")
public class InspectionsController {

	@Autowired
	private InspectionsService inspectionsService;

	@Autowired
	private CacheService cacheService;

	@GetMapping("/last/valid")
	@ApiOperation(value = "${tswag.InspectionsController.checkForValidInspection}")
	public ValidInspectionResponse checkForValidInspection(@Valid InspectionParams params,
			@ApiIgnore @RequestHeader HttpHeaders headers) throws Exception {

		InspectionSearch search = new InspectionSearch();
		BeanUtils.copyProperties(params, search);

		ValidInspectionResponse validInspectionResponse = cacheService
				.smartCache(new Callable<ValidInspectionResponse>() {
					@Override
					public ValidInspectionResponse call() throws Exception {
						return inspectionsService.checkForValidInspection(search);
					}
				}, params, headers, CacheDbTablenames.INSPECTIONS_LAST_VALID, ValidInspectionResponse.class);

		return validInspectionResponse;
	}

	@GetMapping("/last")
	@ApiOperation(value = "${tswag.InspectionsController.getLastInspection}")
	public ResponseEntity<LastInspectionDto> getLastInspection(@Valid InspectionParamsLight params,
			@ApiIgnore @RequestHeader HttpHeaders headers) throws Exception {

		InspectionSearch search = new InspectionSearch();
		BeanUtils.copyProperties(params, search);

		LastInspectionDto lastInspection = cacheService.smartCache(new Callable<LastInspectionDto>() {
			@Override
			public LastInspectionDto call() throws Exception {
				return inspectionsService.getLastInspection(search);
			}
		}, params, headers, CacheDbTablenames.INSPECTIONS_LAST, LastInspectionDto.class);

		return ControllerUtil.createResponseEntity(lastInspection);
	}

	@GetMapping("/history")
	@ApiOperation(value = "${tswag.InspectionsController.getInspectionsHistory}")
	public ResponseEntity<List<HistoryInspectionDto>> getInspectionsHistory(@Valid InspectionParamsLight params,
			@ApiIgnore @RequestHeader HttpHeaders headers) throws Exception {

		InspectionSearch search = new InspectionSearch();
		BeanUtils.copyProperties(params, search);

		List<HistoryInspectionDto> inspections = cacheService.smartCache(new Callable<List<HistoryInspectionDto>>() {
			@Override
			public List<HistoryInspectionDto> call() throws Exception {
				return inspectionsService.getInspectionsHistory(search);
			}
		}, params, headers, CacheDbTablenames.INSPECTIONS_HISTORY, new TypeReference<List<HistoryInspectionDto>>() {});

		return ControllerUtil.createResponseEntity(inspections);
	}
}
