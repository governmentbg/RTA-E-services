package bg.demax.iaaa.gateway.controller.params;

import javax.validation.constraints.NotBlank;

public class GraoParams {
	@NotBlank
	private String egn;

	public String getEgn() {
		return egn;
	}

	public void setEgn(String egn) {
		this.egn = egn;
	}
}
