package bg.demax.iaaa.gateway.controller.params;

import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;

import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;
import io.swagger.annotations.ApiModelProperty;

public class InspectionParams extends InspectionParamsLight {

	@DateTimeFormat(pattern = IaaaGatewayConstants.DATE_TIME_FORMAT)
	@ApiModelProperty(value = "${tswag.InspectionParams.date}")
	private LocalDateTime validUponDateTime;

	@ApiModelProperty(value = "${tswag.stickerNum}")
	private Long stickerNum;

	public LocalDateTime getValidUponDateTime() {
		return validUponDateTime;
	}

	public void setValidUponDateTime(LocalDateTime validUponDateTime) {
		this.validUponDateTime = validUponDateTime;
	}

	public Long getStickerNum() {
		return stickerNum;
	}

	public void setStickerNum(Long stickerNum) {
		this.stickerNum = stickerNum;
	}
}
