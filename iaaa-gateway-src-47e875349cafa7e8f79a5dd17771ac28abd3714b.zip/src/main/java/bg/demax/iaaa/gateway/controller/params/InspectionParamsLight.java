package bg.demax.iaaa.gateway.controller.params;

import org.hibernate.validator.constraints.Length;

import bg.demax.iaaa.gateway.utils.validators.EitherPresent;
import bg.demax.iaaa.gateway.utils.validators.NotNullEmptyFields;
import io.swagger.annotations.ApiModelProperty;

@NotNullEmptyFields
public class InspectionParamsLight {

	@EitherPresent
	@ApiModelProperty(value = "${tswag.regNum}")
	private String regNum;

	@Length(max = 20)
	@EitherPresent
	@ApiModelProperty(value = "${tswag.vin}", example = "WF0WXXGCDW4S43465")
	private String vin;

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public String getRegNum() {
		return regNum;
	}

	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}
}
