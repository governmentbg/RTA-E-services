package bg.demax.iaaa.gateway.controller.restproxying;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.RequestEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.iaaa.gateway.restproxying.RestProxyingService;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/proxy/auto")
public class AutoRestProxyingController {

	@Autowired
	private RestProxyingService restProxyingService;

	@RequestMapping(value = "**", method = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
			RequestMethod.DELETE, RequestMethod.PATCH })
	@ApiOperation(value = "${tswag.AutoRestProxyingController.mirrorRequest}")
	public Object mirrorRequest(RequestEntity<?> requestEntity,
			@RequestParam MultiValueMap<String, String> paramMap) throws Exception {

		return restProxyingService.mirrorRest(requestEntity, paramMap);
	}

}
