package bg.demax.iaaa.gateway.controller.restproxying;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.iaaa.gateway.restproxying.requestconfig.RestProxyingRequestConfigService;

@RestController
@RequestMapping("/api/rest-proxying/config")
public class RestProxyingRequestConfigController {

	@Autowired
	private RestProxyingRequestConfigService restProxyingRequestConfigService;

	@PutMapping("/{id}")
	public void updateRestProxyingRequestConfig(@PathVariable Integer id) {

		restProxyingRequestConfigService.updateRestProxyingRequestConfig(id);
	}

	@PutMapping
	public void updateAllRestProxyingRequestConfigs() {

		restProxyingRequestConfigService.updateAll();
	}
}
