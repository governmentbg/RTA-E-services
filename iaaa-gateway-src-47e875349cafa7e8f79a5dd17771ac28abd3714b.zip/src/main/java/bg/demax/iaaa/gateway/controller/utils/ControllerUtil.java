package bg.demax.iaaa.gateway.controller.utils;

import java.util.Collection;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class ControllerUtil {

	public static <T> ResponseEntity<T> createResponseEntity(T object) {
		boolean isStatusOk = object != null;
		if (object instanceof Collection<?>) {
			isStatusOk = isStatusOk && !((Collection<?>) object).isEmpty();
		}
		return createResponseEntity(object, isStatusOk);
	}

	public static <T> ResponseEntity<T> createResponseEntity(T object, boolean isStatusOk) {
		HttpStatus httpStatus = null;
		if (isStatusOk) {
			httpStatus = HttpStatus.OK;
		} else {
			httpStatus = HttpStatus.NO_CONTENT;
		}
		return new ResponseEntity<T>(object, httpStatus);
	}
}
