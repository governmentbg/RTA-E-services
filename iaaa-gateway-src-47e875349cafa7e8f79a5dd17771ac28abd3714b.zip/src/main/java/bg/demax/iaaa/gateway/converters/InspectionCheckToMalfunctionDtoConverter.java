package bg.demax.iaaa.gateway.converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.gateway.dto.MalfunctionDto;
import bg.demax.iaaa.gateway.dto.NomenclatureDto;
import bg.demax.techinsp.entity.InspectionCheck;
import bg.demax.techinsp.entity.InspectionElement;

@Component
public class InspectionCheckToMalfunctionDtoConverter implements Converter<InspectionCheck, MalfunctionDto> {

	@Override
	public MalfunctionDto convert(InspectionCheck from) {
		if (from != null) {
			MalfunctionDto dto = new MalfunctionDto();
			InspectionElement inspElement = from.getId().getElement();

			dto.setDescription(inspElement.getDescription());

			NomenclatureDto cardinality = new NomenclatureDto();
			if (inspElement.getCardinality() != null) {
				cardinality.setCode(inspElement.getCardinality().getCardinality());
				cardinality.setDescription(inspElement.getCardinality().getDescription());
			}
			dto.setCardinality(cardinality);
			dto.setCheckValue(from.getValue());

			StringBuilder sb = new StringBuilder();

			while (inspElement != null) {
				sb.insert(0, inspElement.getDescIndex());
				inspElement = inspElement.getParent();
			}
			dto.setCode(sb.toString());

			return dto;
		}
		return null;
	}
}
