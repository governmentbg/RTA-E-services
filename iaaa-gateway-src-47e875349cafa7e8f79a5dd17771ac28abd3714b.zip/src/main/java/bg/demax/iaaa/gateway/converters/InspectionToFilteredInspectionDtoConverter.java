package bg.demax.iaaa.gateway.converters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.gateway.dto.HistoryInspectionDto;
import bg.demax.iaaa.gateway.dto.PermitLightDto;
import bg.demax.iaaa.gateway.dto.VehicleForFilteredInspectionDto;
import bg.demax.techinsp.entity.Inspection;

@Component
public class InspectionToFilteredInspectionDtoConverter implements Converter<Inspection, HistoryInspectionDto> {

	@Autowired
	private AppConversionService conversionService;

	@Override
	public HistoryInspectionDto convert(Inspection from) {
		if (from != null) {
			HistoryInspectionDto dto = new HistoryInspectionDto();
			dto.setId(from.getId());
			dto.setStickerNum(from.getReceivedSignNumber());
			dto.setEndDateTime(from.getEndDateTime());

			if (from.getRoadVehicleVersion() != null) {
				VehicleForFilteredInspectionDto vehicleDto = conversionService.convert(from.getRoadVehicleVersion(),
						VehicleForFilteredInspectionDto.class);
				dto.setVehicle(vehicleDto);
			}
			if (from.getPermitLine() != null && from.getPermitLine().getPermit() != null) {
				PermitLightDto permit = new PermitLightDto();
				permit.setNumber(from.getPermitLine().getPermit().getPermitNumber());
				dto.setPermit(permit);
			}

			return dto;
		}
		return null;
	}
}
