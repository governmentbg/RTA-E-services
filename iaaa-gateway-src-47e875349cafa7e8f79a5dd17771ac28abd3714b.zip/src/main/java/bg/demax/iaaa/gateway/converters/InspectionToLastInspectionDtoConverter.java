package bg.demax.iaaa.gateway.converters;

import java.util.Comparator;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.gateway.dto.LastInspectionDto;
import bg.demax.iaaa.gateway.dto.MalfunctionDto;
import bg.demax.iaaa.gateway.dto.NomenclatureDto;
import bg.demax.iaaa.gateway.dto.PermitDto;
import bg.demax.iaaa.gateway.dto.VehicleDto;
import bg.demax.iaaa.gateway.dto.VehiclePresentingPerson;
import bg.demax.techinsp.entity.Inspection;

@Component
public class InspectionToLastInspectionDtoConverter implements Converter<Inspection, LastInspectionDto> {

	@Autowired
	private AppConversionService conversionService;

	@Override
	public LastInspectionDto convert(Inspection from) {
		if (from != null) {
			LastInspectionDto dto = new LastInspectionDto();
			dto.setId(from.getId());
			dto.setStickerNum(from.getReceivedSignNumber());
			dto.setEndDateTime(from.getEndDateTime());
			dto.setNextInspectionDate(from.getNextInspectionDate());

			VehicleDto vehicleDto = conversionService.convert(from.getRoadVehicleVersion(), VehicleDto.class);
			dto.setVehicle(vehicleDto);

			NomenclatureDto conclusion = new NomenclatureDto();
			conclusion.setCode(from.getConclusion().name());
			conclusion.setDescription(from.getConclusion().getDescription());
			dto.setConclusion(conclusion);

			Set<MalfunctionDto> malfunctions = conversionService.convertSet(from.getInspectionChecks(), MalfunctionDto.class);
			dto.setMalfunctions(malfunctions.stream()
					.sorted(Comparator.comparing(MalfunctionDto::getCode))
					.collect(Collectors.toList()));
			if (from.getPermitLine() != null) {
				dto.setPermit(conversionService.convert(from.getPermitLine().getPermit(), PermitDto.class));
			}

			VehiclePresentingPerson person = new VehiclePresentingPerson();
			person.setEgn(from.getPersonEGN());
			person.setNames(from.getPersonName());
			dto.setVehPresentingPerson(person);

			return dto;
		}
		return null;
	}
}
