package bg.demax.iaaa.gateway.converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.gateway.dto.ValidInspectionDto;
import bg.demax.techinsp.entity.Inspection;

@Component
public class InspectionToValidInspectionDtoConverter implements Converter<Inspection, ValidInspectionDto> {

	@Override
	public ValidInspectionDto convert(Inspection from) {
		if (from != null) {
			ValidInspectionDto dto = new ValidInspectionDto();
			dto.setId(from.getId());
			if (from.getRoadVehicleVersion() != null && from.getRoadVehicleVersion().getCategory() != null) {
				dto.setCategory(from.getRoadVehicleVersion().getCategory().getCode());
			}
			if (from.getInspectionType() != null) {
				dto.setType(from.getInspectionType().getCode());
			}
			dto.setEndDateTime(from.getEndDateTime());
			dto.setStickerNum(from.getReceivedSignNumber());
			dto.setNextInspectionDate(from.getNextInspectionDate());

			return dto;
		}
		return null;
	}
}
