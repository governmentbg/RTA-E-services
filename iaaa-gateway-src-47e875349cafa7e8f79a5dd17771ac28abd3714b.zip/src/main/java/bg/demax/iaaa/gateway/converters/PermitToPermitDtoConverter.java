package bg.demax.iaaa.gateway.converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.gateway.dto.PermitDto;
import bg.demax.techinsp.entity.Permit;

@Component
public class PermitToPermitDtoConverter implements Converter<Permit, PermitDto> {

	@Override
	public PermitDto convert(Permit from) {
		if (from != null) {
			PermitDto dto = new PermitDto();
			dto.setNumber(from.getPermitNumber());
			if (from.getSubject() != null) {
				dto.setCompanyEik(from.getSubject().getIdentityNumber());
			}
			if (from.getKtpCity() != null) {
				dto.setAddress(from.getKtpCity().getName() + " " + from.getKtpAddress());
			}
			dto.setCompanyName(from.getSubjectVersion().getFullName());

			return dto;
		}
		return null;
	}
}
