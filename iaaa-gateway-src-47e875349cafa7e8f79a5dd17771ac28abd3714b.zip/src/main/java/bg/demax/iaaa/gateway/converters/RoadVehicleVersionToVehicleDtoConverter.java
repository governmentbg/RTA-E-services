package bg.demax.iaaa.gateway.converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.gateway.dto.VehicleDto;
import bg.demax.pub.entity.RoadVehicleVersion;

@Component
public class RoadVehicleVersionToVehicleDtoConverter implements Converter<RoadVehicleVersion, VehicleDto> {

	@Override
	public VehicleDto convert(RoadVehicleVersion from) {
		if (from != null) {
			VehicleDto dto = new VehicleDto();
			if (from.getRoadVehicle() != null) {
				dto.setVin(from.getRoadVehicle().getVin() != null ? from.getRoadVehicle().getVin() : from.getRoadVehicle().getFrameNumber());
			}
			dto.setRegNum(from.getRegistrationNumber());
			if (from.getCategory() != null) {
				dto.setCategory(from.getCategory().getCode());
			}
			dto.setFirstRegistrationDate(from.getFirstRegistrationDate());
			dto.setvMake(from.getMake());
			dto.setMileage(from.getCurrentKmState());

			return dto;
		}
		return null;
	}
}
