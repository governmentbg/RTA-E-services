package bg.demax.iaaa.gateway.converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.gateway.dto.VehicleForFilteredInspectionDto;
import bg.demax.pub.entity.RoadVehicleVersion;

@Component
public class RoadVehicleVersionToVehicleForFilteredInspectionDtoConverter
		implements Converter<RoadVehicleVersion, VehicleForFilteredInspectionDto> {

	@Override
	public VehicleForFilteredInspectionDto convert(RoadVehicleVersion from) {
		if (from != null) {
			VehicleForFilteredInspectionDto dto = new VehicleForFilteredInspectionDto();
			if (from.getRoadVehicle() != null) {
				dto.setVin(from.getRoadVehicle().getVin() != null ? from.getRoadVehicle().getVin() : from.getRoadVehicle().getFrameNumber());
			}
			dto.setRegNum(from.getRegistrationNumber());
			dto.setMileage(from.getCurrentKmState());

			return dto;
		}
		return null;
	}
}
