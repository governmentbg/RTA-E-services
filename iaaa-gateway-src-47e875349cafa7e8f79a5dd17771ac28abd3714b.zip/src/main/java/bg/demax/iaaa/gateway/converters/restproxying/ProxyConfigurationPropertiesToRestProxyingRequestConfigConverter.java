package bg.demax.iaaa.gateway.converters.restproxying;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import bg.demax.iaaa.gateway.config.restproxying.ProxyConfigurationProperties;
import bg.demax.iaaa.gateway.converters.AppConversionService;
import bg.demax.iaaa.gateway.restproxying.requestconfig.config.RestProxyingRequestConfig;
import bg.demax.iaaa.gateway.restproxying.resttemplate.RestProxyingRestTemplateService;
import bg.demax.iaaa.gateway.restproxying.resttemplate.config.RestProxyingRestTemplateConfig;
import bg.demax.iaaa.gateway.utils.notifiers.ProjectSupportNotificationService;

@Component
public class ProxyConfigurationPropertiesToRestProxyingRequestConfigConverter
	implements Converter<ProxyConfigurationProperties, RestProxyingRequestConfig> {

	private static final String REQUEST_CONFIG_CREATION_EXCEPTION =
			"There was a problem with creating rest proxying configuration for "
			+ "request with local url - %s and remote url - %s : ";

	@Autowired
	private RestProxyingRestTemplateService proxyingRestTemplateService;

	@Autowired
	private AppConversionService conversionService;

	@Autowired
	private ProjectSupportNotificationService notificationService;

	@Override
	public RestProxyingRequestConfig convert(ProxyConfigurationProperties source) {
		RestProxyingRequestConfig restProxyingRequest = new RestProxyingRequestConfig();

		try {
			restProxyingRequest.setLocalPath(source.getLocalPath());
			restProxyingRequest.setRemoteUrl(source.getRemoteUrl());
			restProxyingRequest.setHttpMethod(source.getHttpMethod());
			restProxyingRequest.setCacheTableName(source.getCacheTableName());

			RestProxyingRestTemplateConfig restTemplateConfigDto = conversionService
					.convert(source, RestProxyingRestTemplateConfig.class);

			RestTemplate restTemplate = proxyingRestTemplateService.createRestTemplate(restTemplateConfigDto);
			restProxyingRequest.setRestTemplate(restTemplate);
		} catch (Exception e) {
			notificationService.notify(String.format(REQUEST_CONFIG_CREATION_EXCEPTION,
					source.getLocalPath(), source.getRemoteUrl()) + e.getMessage());
		}

		return restProxyingRequest;
	}

}
