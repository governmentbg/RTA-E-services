package bg.demax.iaaa.gateway.converters.restproxying;

import java.io.InputStream;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.gateway.config.restproxying.ProxyConfigurationProperties;
import bg.demax.iaaa.gateway.enums.SSLCertificateType;
import bg.demax.iaaa.gateway.restproxying.resttemplate.config.RestProxyingRestTemplateConfig;
import bg.demax.iaaa.gateway.restproxying.resttemplate.config.RestProxyingSSLCertificateConfig;

@Component
public class ProxyConfigurationPropertiesToRestProxyingRestTemplateConfigConverter
	implements Converter<ProxyConfigurationProperties, RestProxyingRestTemplateConfig> {

	@Override
	public RestProxyingRestTemplateConfig convert(ProxyConfigurationProperties source) {
		RestProxyingRestTemplateConfig restTemplateConfigDto = new RestProxyingRestTemplateConfig();

		restTemplateConfigDto.setReadTimeout(source.getReadTimeoutSeconds());
		restTemplateConfigDto.setConnectionTimeout(source.getConnectionTimeoutSeconds());
		restTemplateConfigDto.setBasicAuthUsername(source.getBasicAuthUsername());
		restTemplateConfigDto.setBasicAuthPassword(source.getBasicAuthPassword());

		RestProxyingSSLCertificateConfig keyStoreDto = createCertConfig(
				source.getKeystore(),
				source.getKeystorePassword(),
				source.getKeystoreType());
		restTemplateConfigDto.setKeyStore(keyStoreDto);

		RestProxyingSSLCertificateConfig trustStoreDto = createCertConfig(
				source.getTruststore(),
				source.getTruststorePassword(),
				source.getTruststoreType());
		restTemplateConfigDto.setTrustStore(trustStoreDto);

		return restTemplateConfigDto;
	}

	private RestProxyingSSLCertificateConfig createCertConfig(String certPath, String password, String type) {
		if (certPath.equals("") || password.equals("") || type.equals("")) {
			return null;
		}

		RestProxyingSSLCertificateConfig certConfig = new RestProxyingSSLCertificateConfig();

		InputStream certDataStream = this.getClass().getClassLoader().getResourceAsStream(certPath);
		certConfig.setCertDataStream(certDataStream);
		certConfig.setPassword(password);
		certConfig.setType(SSLCertificateType.fromValue(type));

		return certConfig;
	}

}
