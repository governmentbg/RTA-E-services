package bg.demax.iaaa.gateway.converters.restproxying;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import bg.demax.iaaa.gateway.converters.AppConversionService;
import bg.demax.iaaa.gateway.db.entity.iaaaproxies.ProxyRequestDetails;
import bg.demax.iaaa.gateway.db.entity.iaaaproxies.RestTemplateConfig;
import bg.demax.iaaa.gateway.restproxying.requestconfig.config.RestProxyingRequestConfig;
import bg.demax.iaaa.gateway.restproxying.resttemplate.RestProxyingRestTemplateService;
import bg.demax.iaaa.gateway.restproxying.resttemplate.config.RestProxyingRestTemplateConfig;
import bg.demax.iaaa.gateway.utils.notifiers.ProjectSupportNotificationService;

@Component
public class ProxyRequestDetailsToRestProxyingRequestConfigConverter
	implements Converter<ProxyRequestDetails, RestProxyingRequestConfig> {

	private static final String REQUEST_CONFIG_CREATION_EXCEPTION =
			"There was a problem with creating rest proxying configuration for "
			+ "request with local url - %s and remote url - %s : ";

	@Autowired
	private RestProxyingRestTemplateService proxyingRestTemplateService;

	@Autowired
	private AppConversionService conversionService;

	@Autowired
	private ProjectSupportNotificationService notificationService;

	@Override
	public RestProxyingRequestConfig convert(ProxyRequestDetails source) {

		RestProxyingRequestConfig restProxyingRequestConfig = new RestProxyingRequestConfig();

		try {
			restProxyingRequestConfig.setLocalPath(source.getLocalPath());
			restProxyingRequestConfig.setRemoteUrl(source.getRemoteUrl());
			restProxyingRequestConfig.setHttpMethod(source.getHttpMethod());
			restProxyingRequestConfig.setCacheTableName(source.getCacheTableName());
			restProxyingRequestConfig.setId(source.getId());
			restProxyingRequestConfig.setIsEnabled(source.getIsEnabled());

			RestTemplateConfig restTemlateConf = source.getRestTemplateConfig();
			RestProxyingRestTemplateConfig restTemplateConfig = conversionService.convert(
					restTemlateConf, RestProxyingRestTemplateConfig.class);

			RestTemplate restTemplate = proxyingRestTemplateService.createRestTemplate(restTemplateConfig);
			restProxyingRequestConfig.setRestTemplate(restTemplate);

		} catch (Exception e) {
			notificationService.notify(String.format(REQUEST_CONFIG_CREATION_EXCEPTION,
					source.getLocalPath(), source.getRemoteUrl()) + e.getMessage());
		}

		return restProxyingRequestConfig;
	}

}
