package bg.demax.iaaa.gateway.converters.restproxying;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.gateway.db.entity.iaaaproxies.RestTemplateConfig;
import bg.demax.iaaa.gateway.db.entity.iaaaproxies.SSLCertificateDetails;
import bg.demax.iaaa.gateway.enums.SSLCertificateType;
import bg.demax.iaaa.gateway.restproxying.resttemplate.config.RestProxyingRestTemplateConfig;
import bg.demax.iaaa.gateway.restproxying.resttemplate.config.RestProxyingSSLCertificateConfig;

@Component
public class RestTemplateConfigToRestProxyingRestTemplateConfigConverter
	implements Converter<RestTemplateConfig, RestProxyingRestTemplateConfig> {

	@Override
	public RestProxyingRestTemplateConfig convert(RestTemplateConfig source) {
		RestProxyingRestTemplateConfig configDto = new RestProxyingRestTemplateConfig();

		configDto.setReadTimeout(source.getReadTimeout());
		configDto.setConnectionTimeout(source.getConnectionTimeout());
		configDto.setBasicAuthUsername(source.getBasicAuthUsername());
		configDto.setBasicAuthPassword(source.getBasicAuthPassword());

		SSLCertificateDetails keyStore = source.getKeyStore();
		if (keyStore != null) {
			RestProxyingSSLCertificateConfig keyStoreDto = createCertConfig(
					keyStore.getCertData().getData(),
					keyStore.getPassword(),
					keyStore.getType());
			configDto.setKeyStore(keyStoreDto);
		}

		SSLCertificateDetails trustStore = source.getTrustStore();
		if (trustStore != null) {
			RestProxyingSSLCertificateConfig trustStoreDto = createCertConfig(
					trustStore.getCertData().getData(),
					trustStore.getPassword(),
					trustStore.getType());
			configDto.setTrustStore(trustStoreDto);
		}

		return configDto;
	}

	private RestProxyingSSLCertificateConfig createCertConfig(byte[] certData, String password, String type) {
		RestProxyingSSLCertificateConfig certConfig = new RestProxyingSSLCertificateConfig();

		InputStream certDataStream = new ByteArrayInputStream(certData);
		certConfig.setCertDataStream(certDataStream);
		certConfig.setPassword(password);
		certConfig.setType(SSLCertificateType.fromValue(type));

		return certConfig;
	}

}
