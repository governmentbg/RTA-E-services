package bg.demax.iaaa.gateway.db.constants;

public interface DbSchemas {

	String IAAA_GATEWAY = "iaaa_gateway";
}
