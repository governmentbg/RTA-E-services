package bg.demax.iaaa.gateway.db.constants;

public interface DbTables {

	String SSL_CERTIFICATES_DATA = "ssl_certificates_data";
	String SSL_CERTIFICATE_DETAILS = "ssl_certificate_details";
	String REST_TEMPLATE_CONFIGS = "rest_template_configs";
	String PROXY_REQUEST_DETAILS = "proxy_request_details";
}
