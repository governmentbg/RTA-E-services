package bg.demax.iaaa.gateway.db.entity.iaaaproxies;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import bg.demax.iaaa.gateway.db.constants.DbSchemas;
import bg.demax.iaaa.gateway.db.constants.DbTables;

@Entity
@Table(schema = DbSchemas.IAAA_GATEWAY, name = DbTables.SSL_CERTIFICATE_DETAILS)
public class SSLCertificateDetails {

	@Id
	@Column(name = "id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "name", nullable = false)
	private String name;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "data_id", nullable = false)
	private SSLCertificateData certData;

	@Column(name = "password", nullable = false)
	private String password;

	@Column(name = "valid_to")
	private LocalDateTime validTo;

	@Column(name = "type", nullable = false)
	private String type;

	@Column(name = "description")
	private String description;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public SSLCertificateData getCertData() {
		return certData;
	}

	public void setCertData(SSLCertificateData certData) {
		this.certData = certData;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LocalDateTime getValidTo() {
		return validTo;
	}

	public void setValidTo(LocalDateTime validTo) {
		this.validTo = validTo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
