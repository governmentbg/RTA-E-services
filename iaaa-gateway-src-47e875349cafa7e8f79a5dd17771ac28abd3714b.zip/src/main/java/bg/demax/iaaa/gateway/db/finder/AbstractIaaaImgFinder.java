package bg.demax.iaaa.gateway.db.finder;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import bg.demax.iaaa.gateway.config.BeanQualifiers;

public abstract class AbstractIaaaImgFinder {

	@Autowired
	@Qualifier(BeanQualifiers.IAAA_IMG_SESSION_FACTORY)
	private SessionFactory sessionFactory;

	protected Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}
}
