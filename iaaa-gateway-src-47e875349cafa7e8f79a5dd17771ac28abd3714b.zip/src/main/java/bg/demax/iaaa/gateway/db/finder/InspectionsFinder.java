package bg.demax.iaaa.gateway.db.finder;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.iaaa.gateway.search.InspectionSearch;
import bg.demax.techinsp.entity.Inspection;

@Repository
public class InspectionsFinder extends AbstractIaaaImgFinder {

	@Autowired
	private GenericSearchSupport searchSupport;

	public Inspection findBySearchParams(InspectionSearch search) {

		String hql = "SELECT inspection FROM Inspection inspection";

		hql = searchSupport.addSearchConstraints(hql, search);

		hql += " ORDER BY inspection.id DESC";

		Query<Inspection> query = getCurrentSession().createQuery(hql, Inspection.class);
		query.setProperties(search);
		query.setMaxResults(1);

		List<Inspection> inspections = query.getResultList();
		return inspections.size() > 0 ? inspections.get(0) : null;
	}

	public List<Inspection> findAllBySearchParams(InspectionSearch search) {

		String hql = "SELECT inspection FROM Inspection inspection";

		hql = searchSupport.addSearchConstraints(hql, search);

		hql += " ORDER BY inspection.id DESC";

		Query<Inspection> query = getCurrentSession().createQuery(hql, Inspection.class);
		query.setProperties(search);

		List<Inspection> inspections = query.getResultList();
		return inspections;
	}
}
