package bg.demax.iaaa.gateway.db.repository;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.config.db.CacheDbTablenames;
import bg.demax.iaaa.gateway.dto.cache.CacheEntry;
import bg.demax.iaaa.gateway.security.SecurityUtilService;
import bg.demax.iaaa.gateway.security.UserDto;

@Repository
public class CacheRepository {

	@Autowired
	private SecurityUtilService securityUtilService;

	private static final Logger log = LogManager.getLogger(CacheRepository.class);

	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;

	@Autowired
	@Qualifier(BeanQualifiers.CACHE_OBJECT_MAPPER)
	private ObjectMapper postgreJsonMapper;

	public <REQ, RES> void logCacheToDb(CacheEntry<REQ, RES> cache, String tableName) {
		UserDto userDto = securityUtilService.getCurrentUser();
		cache.setUserDto(userDto);

		String query = String.format(
				"INSERT INTO %s.%s (workflow, request_time)  VALUES (cast(:cacheJson AS JSON), :requestTime) RETURNING workflow AS workflow",
				CacheDbTablenames.CACHE_SCHEMA, tableName);
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("requestTime", cache.getRequestTime());

		serialize(cache, parameters, "cacheJson");

		String result = jdbcTemplate.query(query, parameters, (res) -> {
			res.next();
			return res.getString(1);
		});

		deserializeCache(result);

	}

	public <REQ, RES> CacheEntry<REQ, RES> getCacheFromDb(REQ request, String tableName, Integer lastHours) {
		LocalDateTime requestTimeAfter = LocalDateTime.now().minusHours(lastHours);
		UserDto userDto = securityUtilService.getCurrentUser();

		String query = String.format(
			"SELECT workflow FROM %s.%s "
			+ "WHERE workflow -> 'request' = (:requestJson)::jsonb "
			+ "AND (workflow -> 'userDto' ->> 'userId')::integer = :userId "
			+ "AND workflow ->> 'error' IS NULL  "
			+ "AND request_time >= :requestTimeAfter "
			+ "ORDER BY request_time DESC "
			+ "LIMIT 1",
				CacheDbTablenames.CACHE_SCHEMA, tableName);

		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("requestTimeAfter", requestTimeAfter);
		parameters.put("userId", userDto.getUserId());

		serialize(request, parameters, "requestJson");

		String result = jdbcTemplate.query(query, parameters, (res) -> {
			if (res.next()) {
				return res.getString(1);
			}
			return null;
		});

		return deserializeCache(result);
	}

	private void serialize(Object cache, Map<String, Object> parameters, String paramName) {
		try {
			String json = postgreJsonMapper.writeValueAsString(cache);
			parameters.put(paramName, json);
		} catch (JsonProcessingException e) {
			log.error(e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	private <REQ, RES> CacheEntry<REQ, RES> deserializeCache(String result) {
		CacheEntry<REQ, RES> entry = null;
		if (result == null) {
			return entry;
		}
		try {
			entry = (CacheEntry<REQ, RES>) postgreJsonMapper.readValue(result, CacheEntry.class);
		} catch (IOException e) {
			log.error(e.getMessage());
		}
		return entry;
	}
}
