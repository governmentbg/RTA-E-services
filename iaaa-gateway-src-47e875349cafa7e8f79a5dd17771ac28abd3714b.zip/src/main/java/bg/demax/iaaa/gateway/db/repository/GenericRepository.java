package bg.demax.iaaa.gateway.db.repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import bg.demax.iaaa.gateway.exception.NoSuchEntityException;

public class GenericRepository {

	private SessionFactory sessionFactory;

	public GenericRepository(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public <ENTITY_TYPE, ID> ENTITY_TYPE findById(Class<ENTITY_TYPE> type, ID id) {
		return getSession().find(type, id);
	}

	public <ENTITY_TYPE, ID> ENTITY_TYPE findByIdOrThrow(Class<ENTITY_TYPE> type, ID id) {
		ENTITY_TYPE result = getSession().find(type, id);
		if (result == null) {
			throw new NoSuchEntityException(type, id);
		}

		return  result;
	}

	public <ENTITY_TYPE> List<ENTITY_TYPE> findAll(Class<ENTITY_TYPE> type) {
		return getSession().createQuery("from " + type.getName(), type).getResultList();
	}

	public void save(Object entity) {
		getSession().persist(entity);
	}

	public void saveOrUpdate(Object object) {
		getSession().saveOrUpdate(object);
	}

	public void flush() {
		getSession().flush();
	}

	public void evict(Object entity) {
		getSession().evict(entity);
	}

	public void evictAll() {
		getSession().clear();
	}

	private Session getSession() {
		return sessionFactory.getCurrentSession();
	}
}
