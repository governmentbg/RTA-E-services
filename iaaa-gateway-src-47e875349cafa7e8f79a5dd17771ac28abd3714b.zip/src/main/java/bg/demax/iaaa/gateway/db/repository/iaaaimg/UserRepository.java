package bg.demax.iaaa.gateway.db.repository.iaaaimg;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.security.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

	public User findUserByUsername(String username);

	public User findUserByPublicKey(String publicKey);
}
