package bg.demax.iaaa.gateway.db.repository.iaaaproxies;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import bg.demax.iaaa.gateway.db.entity.iaaaproxies.ProxyRequestDetails;

@Repository
public interface ProxyRequestDetailsRepository extends CrudRepository<ProxyRequestDetails, Integer> {

	List<ProxyRequestDetails> findAllByIsEnabledTrue();
}
