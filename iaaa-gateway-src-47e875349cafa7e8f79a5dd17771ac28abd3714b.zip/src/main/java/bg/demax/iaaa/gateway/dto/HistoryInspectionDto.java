package bg.demax.iaaa.gateway.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;
import io.swagger.annotations.ApiModelProperty;

public class HistoryInspectionDto {

	@ApiModelProperty(value = "${tswag.inspId}")
	private Long id;

	@ApiModelProperty(value = "${tswag.stickerNum}")
	private Long stickerNum;

	@JsonFormat(pattern = IaaaGatewayConstants.DATE_TIME_FORMAT)
	@ApiModelProperty(value = "${tswag.inspection.endDateTime}")
	private LocalDateTime endDateTime;

	@ApiModelProperty(value = "${tswag.vehicle}")
	private VehicleForFilteredInspectionDto vehicle;

	@ApiModelProperty(value = "${tswag.HistoryInspectionDto.permit}")
	private PermitLightDto permit;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getStickerNum() {
		return stickerNum;
	}

	public void setStickerNum(Long stickerNum) {
		this.stickerNum = stickerNum;
	}

	public LocalDateTime getEndDateTime() {
		return endDateTime;
	}

	public void setEndDateTime(LocalDateTime endDateTime) {
		this.endDateTime = endDateTime;
	}

	public VehicleForFilteredInspectionDto getVehicle() {
		return vehicle;
	}

	public void setVehicle(VehicleForFilteredInspectionDto vehicle) {
		this.vehicle = vehicle;
	}

	public PermitLightDto getPermit() {
		return permit;
	}

	public void setPermit(PermitLightDto permit) {
		this.permit = permit;
	}
}
