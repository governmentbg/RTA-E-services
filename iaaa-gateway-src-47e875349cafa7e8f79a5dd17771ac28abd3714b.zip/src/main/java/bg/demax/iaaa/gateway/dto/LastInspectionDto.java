package bg.demax.iaaa.gateway.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;
import io.swagger.annotations.ApiModelProperty;

public class LastInspectionDto {

	@ApiModelProperty(value = "${tswag.inspId}")
	private Long id;

	@ApiModelProperty(value = "${tswag.stickerNum}")
	private Long stickerNum;

	@ApiModelProperty(value = "${tswag.inspection.endDateTime}")
	@JsonFormat(pattern = IaaaGatewayConstants.DATE_TIME_FORMAT)
	private LocalDateTime endDateTime;

	@ApiModelProperty(value = "${tswag.nextInspDate}")
	@JsonFormat(pattern = IaaaGatewayConstants.DATE_FORMAT)
	private LocalDate nextInspectionDate;

	@ApiModelProperty(value = "${tswag.vehicle}")
	private VehicleDto vehicle;

	@ApiModelProperty(value = "${tswag.conclusion}")
	private NomenclatureDto conclusion;

	@ApiModelProperty(value = "${tswag.malfucntions}")
	private List<MalfunctionDto> malfunctions;

	@ApiModelProperty(value = "${tswag.permit}")
	private PermitDto permit;

	@ApiModelProperty(value = "${tswag.vehPresentingPerson}")
	private VehiclePresentingPerson vehPresentingPerson;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getStickerNum() {
		return stickerNum;
	}

	public void setStickerNum(Long stickerNum) {
		this.stickerNum = stickerNum;
	}

	public LocalDateTime getEndDateTime() {
		return endDateTime;
	}

	public void setEndDateTime(LocalDateTime endDateTime) {
		this.endDateTime = endDateTime;
	}

	public LocalDate getNextInspectionDate() {
		return nextInspectionDate;
	}

	public void setNextInspectionDate(LocalDate nextInspectionDate) {
		this.nextInspectionDate = nextInspectionDate;
	}

	public VehicleDto getVehicle() {
		return vehicle;
	}

	public void setVehicle(VehicleDto vehicle) {
		this.vehicle = vehicle;
	}

	public NomenclatureDto getConclusion() {
		return conclusion;
	}

	public void setConclusion(NomenclatureDto conclusion) {
		this.conclusion =  conclusion;
	}

	public List<MalfunctionDto> getMalfunctions() {
		return malfunctions;
	}

	public void setMalfunctions(List<MalfunctionDto> malfunctions) {
		this.malfunctions = malfunctions;
	}

	public PermitDto getPermit() {
		return permit;
	}

	public void setPermit(PermitDto permit) {
		this.permit = permit;
	}

	public VehiclePresentingPerson getVehPresentingPerson() {
		return vehPresentingPerson;
	}

	public void setVehPresentingPerson(VehiclePresentingPerson vehPresentingPerson) {
		this.vehPresentingPerson = vehPresentingPerson;
	}
}
