package bg.demax.iaaa.gateway.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

import bg.demax.techinsp.entity.InspectionCheckValue;
import io.swagger.annotations.ApiModelProperty;

public class MalfunctionDto extends NomenclatureDto {

	private InspectionCheckValue checkValue;

	@ApiModelProperty(value = "${tswag.MalfunctionDto.cardinality}")
	private NomenclatureDto cardinality;

	public NomenclatureDto getCardinality() {
		return cardinality;
	}

	public void setCardinality(NomenclatureDto cardinality) {
		this.cardinality = cardinality;
	}

	@JsonIgnore
	public InspectionCheckValue getCheckValue() {
		return checkValue;
	}

	public void setCheckValue(InspectionCheckValue checkValue) {
		this.checkValue = checkValue;
	}
}
