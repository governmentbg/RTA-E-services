package bg.demax.iaaa.gateway.dto;

import io.swagger.annotations.ApiModelProperty;

public class NomenclatureDto {

	@ApiModelProperty(value = "${tswag.NomenclatureDto.code}")
	private String code;

	@ApiModelProperty(value = "${tswag.NomenclatureDto.description}")
	private String description;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
