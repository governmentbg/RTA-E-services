package bg.demax.iaaa.gateway.dto;

import io.swagger.annotations.ApiModelProperty;

public class PermitDto {

	@ApiModelProperty(value = "${tswag.PermitDto.number}")
	private Integer number;

	@ApiModelProperty(value = "${tswag.PermitDto.companyName}")
	private String companyName;

	@ApiModelProperty(value = "${tswag.PermitDto.companyEik}")
	private String companyEik;

	@ApiModelProperty(value = "${tswag.PermitDto.address}")
	private String address;

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyEik() {
		return companyEik;
	}

	public void setCompanyEik(String companyEik) {
		this.companyEik = companyEik;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
}
