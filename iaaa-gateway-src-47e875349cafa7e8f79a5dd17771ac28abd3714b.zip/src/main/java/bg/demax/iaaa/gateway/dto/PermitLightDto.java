package bg.demax.iaaa.gateway.dto;

import io.swagger.annotations.ApiModelProperty;

public class PermitLightDto {

	@ApiModelProperty(value = "${tswag.PermitLightDto.number}")
	private Integer number;

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}
}
