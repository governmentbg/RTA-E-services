package bg.demax.iaaa.gateway.dto;

public class ProxyRequestDto {

	/*
	 * Request object: Either query parameters or request body
	 */
	private Object request;

	/*
	 * Request URI without query parameters
	 */
	private String requestUri;

	public Object getRequest() {
		return request;
	}

	public void setRequest(Object request) {
		this.request = request;
	}

	public String getRequestUri() {
		return requestUri;
	}

	public void setRequestUri(String requestUri) {
		this.requestUri = requestUri;
	}

}
