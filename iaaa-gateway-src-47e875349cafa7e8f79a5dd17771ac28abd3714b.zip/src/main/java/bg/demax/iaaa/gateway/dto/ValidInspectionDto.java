package bg.demax.iaaa.gateway.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;
import bg.demax.iaaa.gateway.config.swagger.Swagger2Constants;
import io.swagger.annotations.ApiModelProperty;

public class ValidInspectionDto {
	@ApiModelProperty(value = "${tswag.PermitLightDto.number}")
	private Long id;

	@ApiModelProperty(value = "${tswag.category}", allowableValues = Swagger2Constants.VALID_CATEGORIES)
	private String category;

	@ApiModelProperty(value = "${tswag.inspection.type}", allowableValues = Swagger2Constants.VALID_INSPECTION_TYPES)
	private String type;

	@JsonFormat(pattern = IaaaGatewayConstants.DATE_TIME_FORMAT)
	@ApiModelProperty(value = "${tswag.inspection.endDateTime}")
	private LocalDateTime endDateTime;

	@JsonFormat(pattern = IaaaGatewayConstants.DATE_FORMAT)
	@ApiModelProperty(value = "${tswag.inspection.nextInspectionDate}")
	private LocalDate nextInspectionDate;

	@ApiModelProperty(value = "${tswag.inspection.stickerNum}")
	private Long stickerNum;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public LocalDateTime getEndDateTime() {
		return endDateTime;
	}

	public void setEndDateTime(LocalDateTime endDateTime) {
		this.endDateTime = endDateTime;
	}

	public LocalDate getNextInspectionDate() {
		return nextInspectionDate;
	}

	public void setNextInspectionDate(LocalDate nextInspectionDate) {
		this.nextInspectionDate = nextInspectionDate;
	}

	public Long getStickerNum() {
		return stickerNum;
	}

	public void setStickerNum(Long stickerNum) {
		this.stickerNum = stickerNum;
	}
}
