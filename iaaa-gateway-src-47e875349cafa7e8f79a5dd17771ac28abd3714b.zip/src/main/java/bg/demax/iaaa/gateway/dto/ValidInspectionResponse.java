package bg.demax.iaaa.gateway.dto;

import io.swagger.annotations.ApiModelProperty;

public class ValidInspectionResponse {

	@ApiModelProperty(value = "${tswag.inspection}")
	private ValidInspectionDto inspection;

	@ApiModelProperty(value = "${tswag.ValidInspectionResponse.hasValidInsp}")
	private Boolean hasValidInspection;

	public Boolean getHasValidInspection() {
		return this.hasValidInspection;
	}

	public void setHasValidInspection(Boolean hasValidInspection) {
		this.hasValidInspection = hasValidInspection;
	}

	public ValidInspectionDto getInspection() {
		return inspection;
	}

	public void setInspection(ValidInspectionDto inspection) {
		this.inspection = inspection;
	}
}
