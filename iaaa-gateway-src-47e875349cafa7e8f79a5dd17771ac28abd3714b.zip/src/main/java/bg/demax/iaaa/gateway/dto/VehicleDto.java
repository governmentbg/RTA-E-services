package bg.demax.iaaa.gateway.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;
import bg.demax.iaaa.gateway.config.swagger.Swagger2Constants;
import io.swagger.annotations.ApiModelProperty;

public class VehicleDto {

	@ApiModelProperty(value = "${tswag.vin}")
	private String vin;

	@ApiModelProperty(value = "${tswag.regNum}")
	private String regNum;

	@ApiModelProperty(value = "${tswag.category}", allowableValues = Swagger2Constants.VALID_INSPECTION_TYPES)
	private String category;

	@JsonFormat(pattern = IaaaGatewayConstants.DATE_FORMAT)
	@ApiModelProperty(value = "${tswag.vehicle.firstRegistrationDate}")
	private LocalDate firstRegistrationDate;

	@ApiModelProperty(value = "${tswag.vMake}")
	private String vMake;

	@ApiModelProperty(value = "${tswag.vMake}")
	private Integer mileage;

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public String getRegNum() {
		return regNum;
	}

	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public LocalDate getFirstRegistrationDate() {
		return firstRegistrationDate;
	}

	public void setFirstRegistrationDate(LocalDate firstRegistrationDate) {
		this.firstRegistrationDate = firstRegistrationDate;
	}

	public String getvMake() {
		return vMake;
	}

	public void setvMake(String vMake) {
		this.vMake = vMake;
	}

	public Integer getMileage() {
		return mileage;
	}

	public void setMileage(Integer mileage) {
		this.mileage = mileage;
	}
}
