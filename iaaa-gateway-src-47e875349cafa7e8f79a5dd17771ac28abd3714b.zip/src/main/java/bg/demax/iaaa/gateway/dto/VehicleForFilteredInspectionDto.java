package bg.demax.iaaa.gateway.dto;

import io.swagger.annotations.ApiModelProperty;

public class VehicleForFilteredInspectionDto {

	@ApiModelProperty(value = "${tswag.vin}")
	private String vin;

	@ApiModelProperty(value = "${tswag.regNum}")
	private String regNum;

	@ApiModelProperty(value = "${tswag.vehicle.mileage}")
	private Integer mileage;

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public String getRegNum() {
		return regNum;
	}

	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}

	public Integer getMileage() {
		return mileage;
	}

	public void setMileage(Integer mileage) {
		this.mileage = mileage;
	}
}
