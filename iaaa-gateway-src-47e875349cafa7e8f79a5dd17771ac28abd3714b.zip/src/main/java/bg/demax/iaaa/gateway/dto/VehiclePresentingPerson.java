package bg.demax.iaaa.gateway.dto;

import io.swagger.annotations.ApiModelProperty;

public class VehiclePresentingPerson {

	@ApiModelProperty(value = "${tswag.person.egn}")
	private String egn;

	@ApiModelProperty(value = "${tswag.person.names}")
	private String names;

	public String getEgn() {
		return egn;
	}

	public void setEgn(String egn) {
		this.egn = egn;
	}

	public String getNames() {
		return names;
	}

	public void setNames(String names) {
		this.names = names;
	}

}
