package bg.demax.iaaa.gateway.dto.cache;

import java.time.LocalDateTime;

import bg.demax.iaaa.gateway.security.UserDto;

public class CacheEntry<REQ, RES> {

	private REQ request;
	private RES response;
	private String error;
	private UserDto userDto;
	private LocalDateTime requestTime;
	private LocalDateTime responseTime;

	public CacheEntry() {
	}

	public REQ getRequest() {
		return request;
	}

	public void setRequest(REQ request) {
		this.request = request;
	}

	public RES getResponse() {
		return response;
	}

	public void setResponse(RES response) {
		this.response = response;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public UserDto getUserDto() {
		return userDto;
	}

	public void setUserDto(UserDto userDto) {
		this.userDto = userDto;
	}

	public LocalDateTime getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(LocalDateTime requestTime) {
		this.requestTime = requestTime;
	}

	public LocalDateTime getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(LocalDateTime responseTime) {
		this.responseTime = responseTime;
	}
}
