package bg.demax.iaaa.gateway.dto.controlleradvice;

public class ProxyingRestClientExceptionDto {
	private String error;
	private String message;
	private Integer proxiedHttpStatus;
	private String proxiedResponseBody;
	private String proxiedMethod;
	private String proxiedUrl;

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getProxiedHttpStatus() {
		return proxiedHttpStatus;
	}

	public void setProxiedHttpStatus(Integer proxiedHttpStatus) {
		this.proxiedHttpStatus = proxiedHttpStatus;
	}

	public String getProxiedResponseBody() {
		return proxiedResponseBody;
	}

	public void setProxiedResponseBody(String proxiedResponseBody) {
		this.proxiedResponseBody = proxiedResponseBody;
	}

	public String getProxiedMethod() {
		return proxiedMethod;
	}

	public void setProxiedMethod(String proxiedMethod) {
		this.proxiedMethod = proxiedMethod;
	}

	public String getProxiedUrl() {
		return proxiedUrl;
	}

	public void setProxiedUrl(String proxiedUrl) {
		this.proxiedUrl = proxiedUrl;
	}
}
