package bg.demax.iaaa.gateway.dummy;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;
import bg.demax.iaaa.gateway.dummy.dto.ExamProtocolDto;
import bg.demax.iaaa.gateway.dummy.dto.ExamType;

@Service
public class ExamProtocolService {

	private static final Logger logger = LogManager.getLogger(ExamProtocolService.class);
	private static final String DUMMY_PROTOCOL_ID = "213";

	@Value("${dummy.send.exam.protocols.address}")
	private String examProtocolsUrl;

	@Autowired
	@Qualifier(IaaaGatewayConstants.DUMMY_REST_TEMPLATE)
	private RestTemplate restTemplate;

	@Scheduled(cron = "${dummy.services.cron}")
	@Profile("!" + IaaaGatewayConstants.SPRING_PROFILE_DEVELOPMENT)
	public void sendExamProtocols() {
		ExamProtocolDto examProtocol = new ExamProtocolDto();
		examProtocol.setId(DUMMY_PROTOCOL_ID);
		examProtocol.setExamType(ExamType.PRACTICE);
		try {
			logger.trace("Trying to send exam protocols...");
			ResponseEntity<String> response = this.restTemplate.postForEntity(examProtocolsUrl, examProtocol,
					String.class);
			if (response.getStatusCode().equals(HttpStatus.OK)) {
				logger.trace("Exam protocols sent: " + examProtocol);
			}
		} catch (Exception e) {
			logger.trace("Could not send exam protocols.");
		}
	}
}
