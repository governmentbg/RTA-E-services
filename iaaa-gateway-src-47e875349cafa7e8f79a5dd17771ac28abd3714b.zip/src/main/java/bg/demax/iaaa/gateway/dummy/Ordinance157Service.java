package bg.demax.iaaa.gateway.dummy;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;
import bg.demax.iaaa.gateway.dummy.dto.Ordinances157Dto;

@Service
public class Ordinance157Service {

	private static final Logger logger = LogManager.getLogger(Ordinance157Service.class);

	private static final String DUMMY_IDENT_NUM = "8801013131";

	@Value("${dummy.ordinance.157.inquiry.address}")
	private String ordinance157InquiryUrl;

	@Autowired
	@Qualifier(IaaaGatewayConstants.DUMMY_REST_TEMPLATE)
	private RestTemplate restTemplate;

	@Scheduled(cron = "${dummy.services.cron}")
	@Profile("!" + IaaaGatewayConstants.SPRING_PROFILE_DEVELOPMENT)
	public void getOrdinance157Inquiry() {
		try {
			logger.trace("Trying to get ordinances by article 157 inquiry...");
			Ordinances157Dto response = this.restTemplate.postForObject(ordinance157InquiryUrl, DUMMY_IDENT_NUM,
					Ordinances157Dto.class);
			logger.trace("Ordinance by article 157 inquiry received successfully: " + response);
		} catch (Exception e) {
			logger.trace("Could not receive ordinances by article 157 inquiry");
		}
	}
}
