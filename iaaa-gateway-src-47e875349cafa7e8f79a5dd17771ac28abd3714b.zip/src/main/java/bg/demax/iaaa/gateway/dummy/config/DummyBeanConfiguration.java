package bg.demax.iaaa.gateway.dummy.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;

@Configuration
@EnableScheduling
public class DummyBeanConfiguration {

	@Bean(IaaaGatewayConstants.DUMMY_REST_TEMPLATE)
	public RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate();

		return restTemplate;
	}
}
