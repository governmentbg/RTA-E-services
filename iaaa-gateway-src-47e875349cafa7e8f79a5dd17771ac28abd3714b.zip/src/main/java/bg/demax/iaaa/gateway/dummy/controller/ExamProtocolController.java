package bg.demax.iaaa.gateway.dummy.controller;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.validator.constraints.Length;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.iaaa.gateway.dummy.dto.ExamineePracticeProtocolDto;

@Validated
@RestController
@RequestMapping("/api/dummy/exam-protocols")
public class ExamProtocolController {
	private static final Logger logger = LogManager.getLogger(ExamProtocolController.class);

	@GetMapping("/search")
	public ResponseEntity<ExamineePracticeProtocolDto> checkForValidInspection(@RequestParam @Length(min = 10, max = 10) String egn) {

		String json = "{ \"names\": \"КАЛОЯН ИВАНОВ ИВАНОВ\", \"egn\": \"9812120011\","
				+ " \"protocols\": [ { \"id\": \"0101041335\", \"examType\": 67,"
				+ " \"protocolNumber\": 3006, \"examDateTime\": \"01/11/2018-10:00:00\","
				+ " \"category\": \"B\", \"city\": \"СОФИЯ\","
				+ " \"cabinetAddress\": \"ЖК ГЕО МИЛЕВ, УЛ. АНДРЕЙ НИКОЛОВ, БЛ. 154\","
				+ " \"chairman\": \"ИВАЙЛО ГЕОРГИЕВ ДАНАИЛОВ\", \"theoryExamProtocolId\": 4265,"
				+ " \"theoryExamDate\": \"22/03/2018\", \"practice\": {"
				+ " \"trainingGroundCity\": \"СОФИЯ\","
				+ " \"trainingGroundAddress\": \"ЖК ЛЕВСКИ В, БЛ. 308\","
				+ " \"hasPassedTrainingGroundExam\": true, \"hasPassedRoadExam\": true,"
				+ " \"hasPassed\": true }, \"finalResult\": true,"
				+ " \"code78\": true, \"permit\": { \"permitNumber\": 3099,"
				+ " \"companyName\": \"ТОНИ ПЕТРОВ 2016 ЕООД\","
				+ " \"managerNames\": \"СТОЙКО МИХАЙЛОВ ВЕНЕВ\","
				+ " \"vehicleRegNum\": \"CB7784AP\", \"vehicleMakeModel\": \"МАЗДА 3\" },"
				+ " \"examineeAddress\": \"SOF\", \"remark\": null }]}";

		ObjectMapper mapper = new ObjectMapper();
		mapper.findAndRegisterModules();
		ExamineePracticeProtocolDto examineePracticeProtocolDto = null;
		try {
			examineePracticeProtocolDto = mapper.readValue(json, ExamineePracticeProtocolDto.class);
			logger.trace(examineePracticeProtocolDto);
		} catch (IOException e) {
			logger.trace(e.getMessage());
		}

		return new ResponseEntity<ExamineePracticeProtocolDto>(examineePracticeProtocolDto, HttpStatus.OK);
	}
}
