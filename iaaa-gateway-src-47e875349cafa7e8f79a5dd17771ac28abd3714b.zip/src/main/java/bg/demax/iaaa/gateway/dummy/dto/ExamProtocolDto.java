package bg.demax.iaaa.gateway.dummy.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;

public class ExamProtocolDto {

	private String id;

	private ExamType examType;

	private Long protocolNumber;

	@DateTimeFormat(pattern = IaaaGatewayConstants.DATE_TIME_FORMAT)
	private LocalDateTime examDateTime;

	private String city;

	private String cabinetAddress;

	private String chairman;

	private List<Examinee> examinees;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public ExamType getExamType() {
		return examType;
	}

	public void setExamType(ExamType examType) {
		this.examType = examType;
	}

	public Long getProtocolNumber() {
		return protocolNumber;
	}

	public void setProtocolNumber(Long protocolNumber) {
		this.protocolNumber = protocolNumber;
	}

	public LocalDateTime getExamDateTime() {
		return examDateTime;
	}

	public void setExamDateTime(LocalDateTime examDateTime) {
		this.examDateTime = examDateTime;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCabinetAddress() {
		return cabinetAddress;
	}

	public void setCabinetAddress(String cabinetAddress) {
		this.cabinetAddress = cabinetAddress;
	}

	public String getChairman() {
		return chairman;
	}

	public void setChairman(String chairman) {
		this.chairman = chairman;
	}

	public List<Examinee> getExaminees() {
		return examinees;
	}

	public void setExaminees(List<Examinee> examinees) {
		this.examinees = examinees;
	}

	public class Examinee {
		private String names;
		private String egn;
		private String category;
		private Long theoryExamProtocolId;
		@DateTimeFormat(pattern = "dd/MM/yyyy")
		private LocalDate theoryExamDate;
		private PracticeDto practice;
		private Boolean finalResult;
		private Boolean code78;
		private PermitDto permit;
		private String examineeAddress;
		private String remark;

		public String getNames() {
			return names;
		}

		public void setNames(String names) {
			this.names = names;
		}

		public String getEgn() {
			return egn;
		}

		public void setEgn(String egn) {
			this.egn = egn;
		}

		public String getCategory() {
			return category;
		}

		public void setCategory(String category) {
			this.category = category;
		}

		public Long getTheoryExamProtocolId() {
			return theoryExamProtocolId;
		}

		public void setTheoryExamProtocolId(Long theoryExamProtocolId) {
			this.theoryExamProtocolId = theoryExamProtocolId;
		}

		public LocalDate getTheoryExamDate() {
			return theoryExamDate;
		}

		public void setTheoryExamDate(LocalDate theoryExamDate) {
			this.theoryExamDate = theoryExamDate;
		}

		public PracticeDto getPractice() {
			return practice;
		}

		public void setPractice(PracticeDto practice) {
			this.practice = practice;
		}

		public Boolean getFinalResult() {
			return finalResult;
		}

		public void setFinalResult(Boolean finalResult) {
			this.finalResult = finalResult;
		}

		public Boolean getCode78() {
			return code78;
		}

		public void setCode78(Boolean code78) {
			this.code78 = code78;
		}

		public PermitDto getPermit() {
			return permit;
		}

		public void setPermit(PermitDto permit) {
			this.permit = permit;
		}

		public String getExamineeAddress() {
			return examineeAddress;
		}

		public void setExamineeAddress(String examineeAddress) {
			this.examineeAddress = examineeAddress;
		}

		public String getRemark() {
			return remark;
		}

		public void setRemark(String remark) {
			this.remark = remark;
		}
	}
}
