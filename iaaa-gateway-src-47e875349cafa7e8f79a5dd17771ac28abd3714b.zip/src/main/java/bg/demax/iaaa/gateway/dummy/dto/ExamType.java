package bg.demax.iaaa.gateway.dummy.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonCreator.Mode;

public enum ExamType {
	THEORY(66), PRACTICE(67);

	private int id;

	private ExamType(int id) {
		this.id = id;
	}

	@JsonCreator(mode = Mode.DELEGATING)
	public static ExamType getNameByValue(int id) {
		for (final ExamType e : ExamType.values()) {
			if (e.id == id) {
				return e;
			}
		}
		return null;

	}
}
