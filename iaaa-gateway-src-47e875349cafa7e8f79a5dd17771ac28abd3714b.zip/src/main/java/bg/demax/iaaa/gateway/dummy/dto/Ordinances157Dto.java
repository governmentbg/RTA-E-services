package bg.demax.iaaa.gateway.dummy.dto;

import java.sql.Date;
import java.util.List;

public class Ordinances157Dto {

	private List<Ordinance157> ordinances;

	public List<Ordinance157> getOrdinances() {
		return ordinances;
	}

	public void setOrdinances(List<Ordinance157> ordinances) {
		this.ordinances = ordinances;
	}

	protected class Ordinance157 {

		private Long ordinanceNum;

		private Date issuanceDate;

		private Date licenseReturnDate;

		public Long getOrdinanceNum() {
			return ordinanceNum;
		}

		public void setOrdinanceNum(Long ordinanceNum) {
			this.ordinanceNum = ordinanceNum;
		}

		public Date getIssuanceDate() {
			return issuanceDate;
		}

		public void setIssuanceDate(Date issuanceDate) {
			this.issuanceDate = issuanceDate;
		}

		public Date getLicenseReturnDate() {
			return licenseReturnDate;
		}

		public void setLicenseReturnDate(Date licenseReturnDate) {
			this.licenseReturnDate = licenseReturnDate;
		}
	}
}
