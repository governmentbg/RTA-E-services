package bg.demax.iaaa.gateway.dummy.dto;

public class PermitDto {

	private Long permitNumber;
	private String companyName;
	private String managerNames;
	private String vehicleRegNum;
	private String vehicleMakeModel;

	public Long getPermitNumber() {
		return permitNumber;
	}

	public void setPermitNumber(Long permitNumber) {
		this.permitNumber = permitNumber;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getManagerNames() {
		return managerNames;
	}

	public void setManagerNames(String managerNames) {
		this.managerNames = managerNames;
	}

	public String getVehicleRegNum() {
		return vehicleRegNum;
	}

	public void setVehicleRegNum(String vehicleRegNum) {
		this.vehicleRegNum = vehicleRegNum;
	}

	public String getVehicleMakeModel() {
		return vehicleMakeModel;
	}

	public void setVehicleMakeModel(String vehicleMakeModel) {
		this.vehicleMakeModel = vehicleMakeModel;
	}

}
