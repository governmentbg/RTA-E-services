package bg.demax.iaaa.gateway.dummy.dto;

public class PracticeDto {

	private String trainingGroundCity;
	private String trainingGroundAddress;
	private Boolean hasPassedTrainingGroundExam;
	private Boolean hasPassedRoadExam;
	private Boolean hasPassed;

	public String getTrainingGroundCity() {
		return trainingGroundCity;
	}

	public void setTrainingGroundCity(String trainingGroundCity) {
		this.trainingGroundCity = trainingGroundCity;
	}

	public String getTrainingGroundAddress() {
		return trainingGroundAddress;
	}

	public void setTrainingGroundAddress(String trainingGroundAddress) {
		this.trainingGroundAddress = trainingGroundAddress;
	}

	public Boolean getHasPassedTrainingGroundExam() {
		return hasPassedTrainingGroundExam;
	}

	public void setHasPassedTrainingGroundExam(Boolean hasPassedTrainingGroundExam) {
		this.hasPassedTrainingGroundExam = hasPassedTrainingGroundExam;
	}

	public Boolean getHasPassedRoadExam() {
		return hasPassedRoadExam;
	}

	public void setHasPassedRoadExam(Boolean hasPassedRoadExam) {
		this.hasPassedRoadExam = hasPassedRoadExam;
	}

	public Boolean getHasPassed() {
		return hasPassed;
	}

	public void setHasPassed(Boolean hasPassed) {
		this.hasPassed = hasPassed;
	}

}
