package bg.demax.iaaa.gateway.exception;

public class NoSuchEntityException extends ApplicationException {

	private static final long serialVersionUID = 4062097605868538488L;

	public NoSuchEntityException(Class<?> clazz, Object id) {
		super(clazz.getSimpleName() + " with id " + id + " not found.");
	}

	public NoSuchEntityException(String message) {
		super(message);
	}

}
