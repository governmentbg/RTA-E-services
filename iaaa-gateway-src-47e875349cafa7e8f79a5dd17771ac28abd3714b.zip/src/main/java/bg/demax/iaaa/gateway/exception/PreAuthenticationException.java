package bg.demax.iaaa.gateway.exception;

import org.springframework.security.core.AuthenticationException;

public class PreAuthenticationException extends AuthenticationException {

	private static final long serialVersionUID = 248478596264110592L;

	public PreAuthenticationException(String msg) {
		super(msg);
	}

}
