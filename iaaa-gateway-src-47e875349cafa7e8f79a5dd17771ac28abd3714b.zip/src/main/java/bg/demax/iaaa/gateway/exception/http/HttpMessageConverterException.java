package bg.demax.iaaa.gateway.exception.http;

import bg.demax.iaaa.gateway.exception.ApplicationException;

public class HttpMessageConverterException extends ApplicationException {

	private static final long serialVersionUID = -2190442915921880749L;

	public HttpMessageConverterException(String msg) {
		super(msg);
	}

}
