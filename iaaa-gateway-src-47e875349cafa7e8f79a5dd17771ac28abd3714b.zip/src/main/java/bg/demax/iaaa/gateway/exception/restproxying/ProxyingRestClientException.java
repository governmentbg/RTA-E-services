package bg.demax.iaaa.gateway.exception.restproxying;

import java.net.URI;

import org.springframework.http.HttpMethod;
import org.springframework.web.client.HttpStatusCodeException;

import bg.demax.iaaa.gateway.exception.ApplicationException;

public class ProxyingRestClientException extends ApplicationException {
	private static final long serialVersionUID = -3295055085958862423L;

	private Integer proxiedHttpStatus;
	private String proxiedResponseBody;
	private String proxiedMethod;
	private String proxiedUrl;

	public ProxyingRestClientException(Exception ex, URI proxiedUrl, HttpMethod proxiedMethod) {
		super("There was a problem when making a proxying request. Details:" + ex.getMessage());

		this.proxiedUrl = proxiedUrl.toString();
		this.proxiedMethod = proxiedMethod.toString();

		if (ex instanceof HttpStatusCodeException) {
			HttpStatusCodeException httpEx = (HttpStatusCodeException) ex;

			this.proxiedHttpStatus = httpEx.getStatusCode().value();
			this.proxiedResponseBody = httpEx.getResponseBodyAsString();
		}
	}

	public Integer getProxiedHttpStatus() {
		return proxiedHttpStatus;
	}

	public String getProxiedResponseBody() {
		return proxiedResponseBody;
	}

	public String getProxiedMethod() {
		return proxiedMethod;
	}

	public String getProxiedUrl() {
		return proxiedUrl;
	}
}
