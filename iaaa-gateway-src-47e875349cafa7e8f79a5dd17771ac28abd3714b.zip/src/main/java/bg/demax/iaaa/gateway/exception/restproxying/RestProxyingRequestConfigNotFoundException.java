package bg.demax.iaaa.gateway.exception.restproxying;

import bg.demax.iaaa.gateway.exception.ApplicationException;

public class RestProxyingRequestConfigNotFoundException extends ApplicationException {

	private static final long serialVersionUID = 591051900432837265L;

	private static final String PROXYING_REQ_CONF_NOT_FOUND_MSG =
			"A rest proxying configuration was not found for request with local url - %s and http method - %s.";

	public RestProxyingRequestConfigNotFoundException(String localPath, String httpMethod) {
		super(String.format(PROXYING_REQ_CONF_NOT_FOUND_MSG, localPath, httpMethod));
	}

}
