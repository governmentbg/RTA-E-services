package bg.demax.iaaa.gateway.exception.restproxying;

import bg.demax.iaaa.gateway.exception.ApplicationException;

public class RestTemplateCreationException extends ApplicationException {

	private static final long serialVersionUID = 6669759378188208533L;

	public RestTemplateCreationException() {

	}

	public RestTemplateCreationException(Exception ex) {
		super(ex);
	}

	public RestTemplateCreationException(String message, Object... args) {
		super(String.format(message, args));
	}
}
