
package bg.demax.iaaa.gateway.graowsdl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Address complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Address">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Oblast" type="{http://www.grao.bg/e-gov/ws/}ElemAttributes" minOccurs="0"/>
 *         &lt;element name="Obstina" type="{http://www.grao.bg/e-gov/ws/}ElemAttributes" minOccurs="0"/>
 *         &lt;element name="Place" type="{http://www.grao.bg/e-gov/ws/}ElemAttributes" minOccurs="0"/>
 *         &lt;element name="Street" type="{http://www.grao.bg/e-gov/ws/}ElemAttributes" minOccurs="0"/>
 *         &lt;element name="Number" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Entrance" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Floor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Apartment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RegDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Address", propOrder = {
    "oblast",
    "obstina",
    "place",
    "street",
    "number",
    "entrance",
    "floor",
    "apartment",
    "regDate"
})
public class Address {

    @XmlElement(name = "Oblast")
    protected ElemAttributes oblast;
    @XmlElement(name = "Obstina")
    protected ElemAttributes obstina;
    @XmlElement(name = "Place")
    protected ElemAttributes place;
    @XmlElement(name = "Street")
    protected ElemAttributes street;
    @XmlElement(name = "Number")
    protected String number;
    @XmlElement(name = "Entrance")
    protected String entrance;
    @XmlElement(name = "Floor")
    protected String floor;
    @XmlElement(name = "Apartment")
    protected String apartment;
    @XmlElement(name = "RegDate")
    protected String regDate;

    /**
     * Gets the value of the oblast property.
     * 
     * @return
     *     possible object is
     *     {@link ElemAttributes }
     *     
     */
    public ElemAttributes getOblast() {
        return oblast;
    }

    /**
     * Sets the value of the oblast property.
     * 
     * @param value
     *     allowed object is
     *     {@link ElemAttributes }
     *     
     */
    public void setOblast(ElemAttributes value) {
        this.oblast = value;
    }

    /**
     * Gets the value of the obstina property.
     * 
     * @return
     *     possible object is
     *     {@link ElemAttributes }
     *     
     */
    public ElemAttributes getObstina() {
        return obstina;
    }

    /**
     * Sets the value of the obstina property.
     * 
     * @param value
     *     allowed object is
     *     {@link ElemAttributes }
     *     
     */
    public void setObstina(ElemAttributes value) {
        this.obstina = value;
    }

    /**
     * Gets the value of the place property.
     * 
     * @return
     *     possible object is
     *     {@link ElemAttributes }
     *     
     */
    public ElemAttributes getPlace() {
        return place;
    }

    /**
     * Sets the value of the place property.
     * 
     * @param value
     *     allowed object is
     *     {@link ElemAttributes }
     *     
     */
    public void setPlace(ElemAttributes value) {
        this.place = value;
    }

    /**
     * Gets the value of the street property.
     * 
     * @return
     *     possible object is
     *     {@link ElemAttributes }
     *     
     */
    public ElemAttributes getStreet() {
        return street;
    }

    /**
     * Sets the value of the street property.
     * 
     * @param value
     *     allowed object is
     *     {@link ElemAttributes }
     *     
     */
    public void setStreet(ElemAttributes value) {
        this.street = value;
    }

    /**
     * Gets the value of the number property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumber() {
        return number;
    }

    /**
     * Sets the value of the number property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumber(String value) {
        this.number = value;
    }

    /**
     * Gets the value of the entrance property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEntrance() {
        return entrance;
    }

    /**
     * Sets the value of the entrance property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEntrance(String value) {
        this.entrance = value;
    }

    /**
     * Gets the value of the floor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFloor() {
        return floor;
    }

    /**
     * Sets the value of the floor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFloor(String value) {
        this.floor = value;
    }

    /**
     * Gets the value of the apartment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApartment() {
        return apartment;
    }

    /**
     * Sets the value of the apartment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApartment(String value) {
        this.apartment = value;
    }

    /**
     * Gets the value of the regDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegDate() {
        return regDate;
    }

    /**
     * Sets the value of the regDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegDate(String value) {
        this.regDate = value;
    }

}
