
package bg.demax.iaaa.gateway.graowsdl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BirthData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BirthData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Country" type="{http://www.grao.bg/e-gov/ws/}ElemAttributes" minOccurs="0"/>
 *         &lt;element name="Place" type="{http://www.grao.bg/e-gov/ws/}ElemAttributes" minOccurs="0"/>
 *         &lt;element name="Date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BirthData", propOrder = {
    "country",
    "place",
    "date"
})
public class BirthData {

    @XmlElement(name = "Country")
    protected ElemAttributes country;
    @XmlElement(name = "Place")
    protected ElemAttributes place;
    @XmlElement(name = "Date")
    protected String date;

    /**
     * Gets the value of the country property.
     * 
     * @return
     *     possible object is
     *     {@link ElemAttributes }
     *     
     */
    public ElemAttributes getCountry() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param value
     *     allowed object is
     *     {@link ElemAttributes }
     *     
     */
    public void setCountry(ElemAttributes value) {
        this.country = value;
    }

    /**
     * Gets the value of the place property.
     * 
     * @return
     *     possible object is
     *     {@link ElemAttributes }
     *     
     */
    public ElemAttributes getPlace() {
        return place;
    }

    /**
     * Sets the value of the place property.
     * 
     * @param value
     *     allowed object is
     *     {@link ElemAttributes }
     *     
     */
    public void setPlace(ElemAttributes value) {
        this.place = value;
    }

    /**
     * Gets the value of the date property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDate() {
        return date;
    }

    /**
     * Sets the value of the date property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDate(String value) {
        this.date = value;
    }

}
