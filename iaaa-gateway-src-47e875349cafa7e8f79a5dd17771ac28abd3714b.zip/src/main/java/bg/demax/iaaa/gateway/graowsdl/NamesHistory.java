
package bg.demax.iaaa.gateway.graowsdl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NamesHistory complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NamesHistory">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Type" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Date" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NamesOld" type="{http://www.grao.bg/e-gov/ws/}Names" minOccurs="0"/>
 *         &lt;element name="NamesNew" type="{http://www.grao.bg/e-gov/ws/}Names" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NamesHistory", propOrder = {
    "type",
    "date",
    "namesOld",
    "namesNew"
})
public class NamesHistory {

    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "Date")
    protected String date;
    @XmlElement(name = "NamesOld")
    protected Names namesOld;
    @XmlElement(name = "NamesNew")
    protected Names namesNew;

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the date property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDate() {
        return date;
    }

    /**
     * Sets the value of the date property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDate(String value) {
        this.date = value;
    }

    /**
     * Gets the value of the namesOld property.
     * 
     * @return
     *     possible object is
     *     {@link Names }
     *     
     */
    public Names getNamesOld() {
        return namesOld;
    }

    /**
     * Sets the value of the namesOld property.
     * 
     * @param value
     *     allowed object is
     *     {@link Names }
     *     
     */
    public void setNamesOld(Names value) {
        this.namesOld = value;
    }

    /**
     * Gets the value of the namesNew property.
     * 
     * @return
     *     possible object is
     *     {@link Names }
     *     
     */
    public Names getNamesNew() {
        return namesNew;
    }

    /**
     * Sets the value of the namesNew property.
     * 
     * @param value
     *     allowed object is
     *     {@link Names }
     *     
     */
    public void setNamesNew(Names value) {
        this.namesNew = value;
    }

}
