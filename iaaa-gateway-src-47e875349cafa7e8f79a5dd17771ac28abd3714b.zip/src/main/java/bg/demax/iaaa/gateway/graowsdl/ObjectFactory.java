
package bg.demax.iaaa.gateway.graowsdl;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the bg.demax.iaaa.gateway.graowsdl package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GraoResponse_QNAME = new QName("http://www.grao.bg/e-gov/ws/", "GraoResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: bg.demax.iaaa.gateway.graowsdl
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetPersonDataResponse }
     * 
     */
    public GetPersonDataResponse createGetPersonDataResponse() {
        return new GetPersonDataResponse();
    }

    /**
     * Create an instance of {@link GraoResponse }
     * 
     */
    public GraoResponse createGraoResponse() {
        return new GraoResponse();
    }

    /**
     * Create an instance of {@link GetPersonData }
     * 
     */
    public GetPersonData createGetPersonData() {
        return new GetPersonData();
    }

    /**
     * Create an instance of {@link Names }
     * 
     */
    public Names createNames() {
        return new Names();
    }

    /**
     * Create an instance of {@link NamesHistory }
     * 
     */
    public NamesHistory createNamesHistory() {
        return new NamesHistory();
    }

    /**
     * Create an instance of {@link DeathData }
     * 
     */
    public DeathData createDeathData() {
        return new DeathData();
    }

    /**
     * Create an instance of {@link Address }
     * 
     */
    public Address createAddress() {
        return new Address();
    }

    /**
     * Create an instance of {@link ElemAttributes }
     * 
     */
    public ElemAttributes createElemAttributes() {
        return new ElemAttributes();
    }

    /**
     * Create an instance of {@link ArrayOfNamesHistory }
     * 
     */
    public ArrayOfNamesHistory createArrayOfNamesHistory() {
        return new ArrayOfNamesHistory();
    }

    /**
     * Create an instance of {@link IdentityDoc }
     * 
     */
    public IdentityDoc createIdentityDoc() {
        return new IdentityDoc();
    }

    /**
     * Create an instance of {@link BirthData }
     * 
     */
    public BirthData createBirthData() {
        return new BirthData();
    }

    /**
     * Create an instance of {@link ActDocument }
     * 
     */
    public ActDocument createActDocument() {
        return new ActDocument();
    }

    /**
     * Create an instance of {@link Person }
     * 
     */
    public Person createPerson() {
        return new Person();
    }

    /**
     * Create an instance of {@link ArrayOfAddress }
     * 
     */
    public ArrayOfAddress createArrayOfAddress() {
        return new ArrayOfAddress();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GraoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.grao.bg/e-gov/ws/", name = "GraoResponse")
    public JAXBElement<GraoResponse> createGraoResponse(GraoResponse value) {
        return new JAXBElement<GraoResponse>(_GraoResponse_QNAME, GraoResponse.class, null, value);
    }

}
