
package bg.demax.iaaa.gateway.graowsdl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Person complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Person">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Egn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Names" type="{http://www.grao.bg/e-gov/ws/}Names" minOccurs="0"/>
 *         &lt;element name="ForeignNames" type="{http://www.grao.bg/e-gov/ws/}Names" minOccurs="0"/>
 *         &lt;element name="NamesHistory" type="{http://www.grao.bg/e-gov/ws/}ArrayOfNamesHistory" minOccurs="0"/>
 *         &lt;element name="BirthData" type="{http://www.grao.bg/e-gov/ws/}BirthData" minOccurs="0"/>
 *         &lt;element name="DeathData" type="{http://www.grao.bg/e-gov/ws/}DeathData" minOccurs="0"/>
 *         &lt;element name="Nationality" type="{http://www.grao.bg/e-gov/ws/}ElemAttributes" minOccurs="0"/>
 *         &lt;element name="MaritalStatus" type="{http://www.grao.bg/e-gov/ws/}ElemAttributes" minOccurs="0"/>
 *         &lt;element name="MarriageAct" type="{http://www.grao.bg/e-gov/ws/}ActDocument" minOccurs="0"/>
 *         &lt;element name="Divorce" type="{http://www.grao.bg/e-gov/ws/}ActDocument" minOccurs="0"/>
 *         &lt;element name="ChildrenUnder18" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IdDoc" type="{http://www.grao.bg/e-gov/ws/}IdentityDoc" minOccurs="0"/>
 *         &lt;element name="ResidenceAddress" type="{http://www.grao.bg/e-gov/ws/}Address" minOccurs="0"/>
 *         &lt;element name="CurrentAddress" type="{http://www.grao.bg/e-gov/ws/}Address" minOccurs="0"/>
 *         &lt;element name="ResidenceAddressHistory" type="{http://www.grao.bg/e-gov/ws/}ArrayOfAddress" minOccurs="0"/>
 *         &lt;element name="CurrentAddressHistory" type="{http://www.grao.bg/e-gov/ws/}ArrayOfAddress" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Person", propOrder = {
    "egn",
    "names",
    "foreignNames",
    "namesHistory",
    "birthData",
    "deathData",
    "nationality",
    "maritalStatus",
    "marriageAct",
    "divorce",
    "childrenUnder18",
    "idDoc",
    "residenceAddress",
    "currentAddress",
    "residenceAddressHistory",
    "currentAddressHistory"
})
public class Person {

    @XmlElement(name = "Egn")
    protected String egn;
    @XmlElement(name = "Names")
    protected Names names;
    @XmlElement(name = "ForeignNames")
    protected Names foreignNames;
    @XmlElement(name = "NamesHistory")
    protected ArrayOfNamesHistory namesHistory;
    @XmlElement(name = "BirthData")
    protected BirthData birthData;
    @XmlElement(name = "DeathData")
    protected DeathData deathData;
    @XmlElement(name = "Nationality")
    protected ElemAttributes nationality;
    @XmlElement(name = "MaritalStatus")
    protected ElemAttributes maritalStatus;
    @XmlElement(name = "MarriageAct")
    protected ActDocument marriageAct;
    @XmlElement(name = "Divorce")
    protected ActDocument divorce;
    @XmlElement(name = "ChildrenUnder18")
    protected String childrenUnder18;
    @XmlElement(name = "IdDoc")
    protected IdentityDoc idDoc;
    @XmlElement(name = "ResidenceAddress")
    protected Address residenceAddress;
    @XmlElement(name = "CurrentAddress")
    protected Address currentAddress;
    @XmlElement(name = "ResidenceAddressHistory")
    protected ArrayOfAddress residenceAddressHistory;
    @XmlElement(name = "CurrentAddressHistory")
    protected ArrayOfAddress currentAddressHistory;

    /**
     * Gets the value of the egn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEgn() {
        return egn;
    }

    /**
     * Sets the value of the egn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEgn(String value) {
        this.egn = value;
    }

    /**
     * Gets the value of the names property.
     * 
     * @return
     *     possible object is
     *     {@link Names }
     *     
     */
    public Names getNames() {
        return names;
    }

    /**
     * Sets the value of the names property.
     * 
     * @param value
     *     allowed object is
     *     {@link Names }
     *     
     */
    public void setNames(Names value) {
        this.names = value;
    }

    /**
     * Gets the value of the foreignNames property.
     * 
     * @return
     *     possible object is
     *     {@link Names }
     *     
     */
    public Names getForeignNames() {
        return foreignNames;
    }

    /**
     * Sets the value of the foreignNames property.
     * 
     * @param value
     *     allowed object is
     *     {@link Names }
     *     
     */
    public void setForeignNames(Names value) {
        this.foreignNames = value;
    }

    /**
     * Gets the value of the namesHistory property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfNamesHistory }
     *     
     */
    public ArrayOfNamesHistory getNamesHistory() {
        return namesHistory;
    }

    /**
     * Sets the value of the namesHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfNamesHistory }
     *     
     */
    public void setNamesHistory(ArrayOfNamesHistory value) {
        this.namesHistory = value;
    }

    /**
     * Gets the value of the birthData property.
     * 
     * @return
     *     possible object is
     *     {@link BirthData }
     *     
     */
    public BirthData getBirthData() {
        return birthData;
    }

    /**
     * Sets the value of the birthData property.
     * 
     * @param value
     *     allowed object is
     *     {@link BirthData }
     *     
     */
    public void setBirthData(BirthData value) {
        this.birthData = value;
    }

    /**
     * Gets the value of the deathData property.
     * 
     * @return
     *     possible object is
     *     {@link DeathData }
     *     
     */
    public DeathData getDeathData() {
        return deathData;
    }

    /**
     * Sets the value of the deathData property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeathData }
     *     
     */
    public void setDeathData(DeathData value) {
        this.deathData = value;
    }

    /**
     * Gets the value of the nationality property.
     * 
     * @return
     *     possible object is
     *     {@link ElemAttributes }
     *     
     */
    public ElemAttributes getNationality() {
        return nationality;
    }

    /**
     * Sets the value of the nationality property.
     * 
     * @param value
     *     allowed object is
     *     {@link ElemAttributes }
     *     
     */
    public void setNationality(ElemAttributes value) {
        this.nationality = value;
    }

    /**
     * Gets the value of the maritalStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ElemAttributes }
     *     
     */
    public ElemAttributes getMaritalStatus() {
        return maritalStatus;
    }

    /**
     * Sets the value of the maritalStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ElemAttributes }
     *     
     */
    public void setMaritalStatus(ElemAttributes value) {
        this.maritalStatus = value;
    }

    /**
     * Gets the value of the marriageAct property.
     * 
     * @return
     *     possible object is
     *     {@link ActDocument }
     *     
     */
    public ActDocument getMarriageAct() {
        return marriageAct;
    }

    /**
     * Sets the value of the marriageAct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ActDocument }
     *     
     */
    public void setMarriageAct(ActDocument value) {
        this.marriageAct = value;
    }

    /**
     * Gets the value of the divorce property.
     * 
     * @return
     *     possible object is
     *     {@link ActDocument }
     *     
     */
    public ActDocument getDivorce() {
        return divorce;
    }

    /**
     * Sets the value of the divorce property.
     * 
     * @param value
     *     allowed object is
     *     {@link ActDocument }
     *     
     */
    public void setDivorce(ActDocument value) {
        this.divorce = value;
    }

    /**
     * Gets the value of the childrenUnder18 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChildrenUnder18() {
        return childrenUnder18;
    }

    /**
     * Sets the value of the childrenUnder18 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChildrenUnder18(String value) {
        this.childrenUnder18 = value;
    }

    /**
     * Gets the value of the idDoc property.
     * 
     * @return
     *     possible object is
     *     {@link IdentityDoc }
     *     
     */
    public IdentityDoc getIdDoc() {
        return idDoc;
    }

    /**
     * Sets the value of the idDoc property.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentityDoc }
     *     
     */
    public void setIdDoc(IdentityDoc value) {
        this.idDoc = value;
    }

    /**
     * Gets the value of the residenceAddress property.
     * 
     * @return
     *     possible object is
     *     {@link Address }
     *     
     */
    public Address getResidenceAddress() {
        return residenceAddress;
    }

    /**
     * Sets the value of the residenceAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link Address }
     *     
     */
    public void setResidenceAddress(Address value) {
        this.residenceAddress = value;
    }

    /**
     * Gets the value of the currentAddress property.
     * 
     * @return
     *     possible object is
     *     {@link Address }
     *     
     */
    public Address getCurrentAddress() {
        return currentAddress;
    }

    /**
     * Sets the value of the currentAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link Address }
     *     
     */
    public void setCurrentAddress(Address value) {
        this.currentAddress = value;
    }

    /**
     * Gets the value of the residenceAddressHistory property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAddress }
     *     
     */
    public ArrayOfAddress getResidenceAddressHistory() {
        return residenceAddressHistory;
    }

    /**
     * Sets the value of the residenceAddressHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAddress }
     *     
     */
    public void setResidenceAddressHistory(ArrayOfAddress value) {
        this.residenceAddressHistory = value;
    }

    /**
     * Gets the value of the currentAddressHistory property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAddress }
     *     
     */
    public ArrayOfAddress getCurrentAddressHistory() {
        return currentAddressHistory;
    }

    /**
     * Sets the value of the currentAddressHistory property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAddress }
     *     
     */
    public void setCurrentAddressHistory(ArrayOfAddress value) {
        this.currentAddressHistory = value;
    }

}
