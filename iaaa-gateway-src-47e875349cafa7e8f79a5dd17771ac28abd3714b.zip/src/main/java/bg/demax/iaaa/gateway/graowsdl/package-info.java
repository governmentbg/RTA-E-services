@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.grao.bg/e-gov/ws/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package bg.demax.iaaa.gateway.graowsdl;
