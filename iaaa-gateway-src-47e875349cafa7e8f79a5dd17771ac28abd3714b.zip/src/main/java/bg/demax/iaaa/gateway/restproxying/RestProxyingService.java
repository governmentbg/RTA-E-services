package bg.demax.iaaa.gateway.restproxying;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.util.UriComponentsBuilder;

import bg.demax.iaaa.gateway.config.WebSecurityConfiguration;
import bg.demax.iaaa.gateway.dto.ProxyRequestDto;
import bg.demax.iaaa.gateway.exception.restproxying.ProxyingRestClientException;
import bg.demax.iaaa.gateway.restproxying.requestconfig.RestProxyingRequestConfigService;
import bg.demax.iaaa.gateway.restproxying.requestconfig.config.RestProxyingRequestConfig;
import bg.demax.iaaa.gateway.service.CacheService;


@Service
public class RestProxyingService {

	private static final Logger logger = LogManager.getLogger(RestProxyingService.class);

	@Autowired
	private RestProxyingRequestConfigService requestConfigService;

	@Autowired
	private CacheService cacheService;

	public static final List<String> HEADERS_SKIPPED_WHEN_PROXYING = Collections.unmodifiableList(
				Arrays.asList("host", "cookie", WebSecurityConfiguration.PRE_AUTH_HEADER_NAME)
				.stream().map(h -> h.toLowerCase()).collect(Collectors.toList())
			);

	public Object mirrorRest(RequestEntity<?> requestEntity, @RequestParam MultiValueMap<String, String> paramMap)
			throws Exception {

		String path = requestEntity.getUrl().getPath();
		HttpMethod httpMethod = requestEntity.getMethod();

		RestProxyingRequestConfig proxyingRequestConfig =
				requestConfigService.getRestProxyingRequestConfig(path, httpMethod.toString());
		String pathVariablesPart = getPathVariablesPartIfAny(path, proxyingRequestConfig.getLocalPath());

		String proxyAddress = buildProxyAddress(proxyingRequestConfig.getRemoteUrl(), pathVariablesPart);

		ProxyRequestDto proxyRequestDto = new ProxyRequestDto();
		proxyRequestDto.setRequestUri(proxyAddress);

		if (httpMethod == HttpMethod.GET) {
			proxyRequestDto.setRequest(paramMap);
		} else {
			proxyRequestDto.setRequest(requestEntity.getBody());
		}

		URI newUri = buildUri(proxyAddress, requestEntity.getUrl().getQuery());
		HttpEntity<?> httpEntity = createHttpEntity(requestEntity);

		Object response = cacheService.smartCache(new Callable<Object>() {
			@Override
			public Object call() {
				try {
					ResponseEntity<byte[]> response = proxyingRequestConfig.getRestTemplate()
							.exchange(newUri, httpMethod, httpEntity, byte[].class);

					if (response.getBody() == null) {
						return null;
					}

					byte[] rawResp = response.getBody();
					if (response.getHeaders().getContentType() == MediaType.APPLICATION_OCTET_STREAM) {
						return rawResp;
					} else {
						try {
							return new String(rawResp);
						} catch (Exception exs) {
							logger.debug("Response from " + newUri.toString() + " could not be turned into a string");
							return rawResp;
						}
					}
				} catch (HttpStatusCodeException ex) {
					throw new ProxyingRestClientException(ex, newUri, httpMethod);
				} catch (Exception ex) {
					throw new ProxyingRestClientException(ex, newUri, httpMethod);
				}
			}
		}, proxyRequestDto, requestEntity.getHeaders(), proxyingRequestConfig.getCacheTableName(), Object.class);

		return response;
	}

	private String getPathVariablesPartIfAny(String localPath, String localPathFromConfig) {
		if (!localPathFromConfig.contains("{")) {
			return null;
		}

		int pathVariablesStartIndex = localPathFromConfig.indexOf("{");
		String pathVariablesPart = localPath.substring(pathVariablesStartIndex);

		return pathVariablesPart;
	}

	private String buildProxyAddress(String proxyAddress, String proxyAddressSuffix) {
		if (proxyAddressSuffix != null) {
			if (!proxyAddress.endsWith("/") && !proxyAddressSuffix.startsWith("/")) {
				proxyAddress += "/";
			}
			proxyAddress += proxyAddressSuffix;
		}

		return proxyAddress;
	}

	private URI buildUri(String proxyAddress, String queryParams) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(proxyAddress);
		builder.query(queryParams);

		return builder.build().toUri();
	}

	private HttpEntity<?> createHttpEntity(RequestEntity<?> requestEntity) {
		HttpHeaders newHeaders = new HttpHeaders();
		for (Entry<String, List<String>> headerEntry : requestEntity.getHeaders().entrySet()) {
			if (HEADERS_SKIPPED_WHEN_PROXYING.contains(headerEntry.getKey().toLowerCase())) {
				continue;
			}

			newHeaders.addAll(headerEntry.getKey(), headerEntry.getValue());
		}

		HttpEntity<?> httpEntity = new HttpEntity<Object>(requestEntity.getBody(), newHeaders);

		return httpEntity;
	}
}
