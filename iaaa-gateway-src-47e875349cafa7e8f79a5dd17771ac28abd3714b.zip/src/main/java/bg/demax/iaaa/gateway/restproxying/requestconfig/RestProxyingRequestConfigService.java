package bg.demax.iaaa.gateway.restproxying.requestconfig;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bg.demax.iaaa.gateway.config.restproxying.ProxyConfigurationProperties;
import bg.demax.iaaa.gateway.converters.AppConversionService;
import bg.demax.iaaa.gateway.exception.restproxying.RestProxyingRequestConfigNotFoundException;
import bg.demax.iaaa.gateway.restproxying.requestconfig.config.RestProxyingRequestConfig;
import bg.demax.iaaa.gateway.service.ProxyRequestDetailsService;
import bg.demax.iaaa.gateway.utils.notifiers.ProjectSupportNotificationService;

@Service
public class RestProxyingRequestConfigService {

	private static final String OVERRIDING_CONF_FROM_APP_PROPS_MSG = "Overriding a rest proxying request"
			+ " configuration from application properties for local url - %s and http method - %s. "
			+ "Please remove the config from the application properties";

	private List<RestProxyingRequestConfig> requestConfigsFromDb;

	private List<RestProxyingRequestConfig> requestConfigsFromApplicationProperties;

	@Autowired
	private ProxyRequestDetailsService proxyRequestDetailsService;

	@Autowired
	private AppConversionService conversionService;

	@Autowired
	private ProjectSupportNotificationService notificationService;

	@Autowired(required = false)
	private List<ProxyConfigurationProperties> proxyConfigurationProperties = new ArrayList<>();

	@PostConstruct
	public void setRequestConfigs() {
		this.requestConfigsFromApplicationProperties = conversionService
				.convertList(proxyConfigurationProperties, RestProxyingRequestConfig.class);
		this.requestConfigsFromDb = new ArrayList<RestProxyingRequestConfig>();

		List<RestProxyingRequestConfig> requestConfigs = proxyRequestDetailsService.findAllEnabledProxyingRequestConfigs();
		setRequestConfigsFromDb(requestConfigs);
	}

	public RestProxyingRequestConfig getRestProxyingRequestConfig(String localPath, String httpMethod) {

		RestProxyingRequestConfig restProxyingRequestConfig = findRestProxyingRequestConfig(localPath, httpMethod, requestConfigsFromDb);

		if (restProxyingRequestConfig != null) {
			return restProxyingRequestConfig;
		}

		restProxyingRequestConfig = findRestProxyingRequestConfig(localPath, httpMethod, requestConfigsFromApplicationProperties);

		if (restProxyingRequestConfig != null) {
			return restProxyingRequestConfig;
		}

		throw new RestProxyingRequestConfigNotFoundException(localPath, httpMethod);
	}

	public void updateRestProxyingRequestConfig(Integer id) {
		RestProxyingRequestConfig requestConfigNew = proxyRequestDetailsService.findProxyingRequestConfig(id);
		removeIfAny(requestConfigNew.getId());

		if (requestConfigNew.getIsEnabled()) {
			addToRequestConfigsFromDb(requestConfigNew);
		}
	}

	public void updateAll() {
		requestConfigsFromDb.clear();
		List<RestProxyingRequestConfig> requestConfigs = proxyRequestDetailsService.findAllEnabledProxyingRequestConfigs();
		setRequestConfigsFromDb(requestConfigs);
	}

	private RestProxyingRequestConfig findRestProxyingRequestConfig(String localPath, String httpMethod,
			List<RestProxyingRequestConfig> restProxyingRequestConfigs) {

		for (RestProxyingRequestConfig restProxyingRequestConfig : restProxyingRequestConfigs) {
			if (localPathsMatch(localPath, restProxyingRequestConfig.getLocalPath())
					&& httpMethodsMatch(httpMethod, restProxyingRequestConfig.getHttpMethod())) {
				return restProxyingRequestConfig;
			}
		}

		return null;
	}

	private boolean localPathsMatch(String localPath, String localPathFromConfig) {
		String pathVariableRegex = "\\{.+\\}";
		String pathVariableReplacement = ".+";

		if (localPathFromConfig.contains("{")) {
			localPathFromConfig = localPathFromConfig.replaceAll(pathVariableRegex, pathVariableReplacement);

			if (localPath.matches(localPathFromConfig)) {
				return true;
			}
		} else {
			if (localPath.equals(localPathFromConfig)) {
				return true;
			}
		}

		return false;
	}

	private boolean httpMethodsMatch(String httpMethod, String httpMethodFromConfig) {
		if (httpMethodFromConfig == null || httpMethodFromConfig.equals("")) {
			return true;
		}

		return httpMethodFromConfig.equals(httpMethod);
	}

	private void removeIfAny(Integer id) {
		for (RestProxyingRequestConfig restProxyingRequestConfig : requestConfigsFromDb) {
			if (id.equals(restProxyingRequestConfig.getId())) {
				requestConfigsFromDb.remove(restProxyingRequestConfig);
				return;
			}
		}
	}

	private void setRequestConfigsFromDb(List<RestProxyingRequestConfig> requestConfigs) {
		for (RestProxyingRequestConfig restProxyingRequestConfig : requestConfigs) {
			addToRequestConfigsFromDb(restProxyingRequestConfig);
		}
	}

	private void addToRequestConfigsFromDb(RestProxyingRequestConfig requestConfig) {
		requestConfigsFromDb.add(requestConfig);
		notifyIfOverridingConfigFromAppProps(requestConfig);
	}

	private void notifyIfOverridingConfigFromAppProps(RestProxyingRequestConfig requestConfigNew) {
		RestProxyingRequestConfig restProxyingRequestConfig = findRestProxyingRequestConfig(
				requestConfigNew.getLocalPath(), requestConfigNew.getHttpMethod(),
				requestConfigsFromApplicationProperties);

		if (restProxyingRequestConfig != null) {
			notificationService.notify(String.format(OVERRIDING_CONF_FROM_APP_PROPS_MSG,
					requestConfigNew.getLocalPath(), requestConfigNew.getHttpMethod()));
		}
	}
}