package bg.demax.iaaa.gateway.restproxying.requestconfig.config;

import org.springframework.web.client.RestTemplate;

public class RestProxyingRequestConfig {

	private String localPath;

	private String remoteUrl;

	private String httpMethod;

	private RestTemplate restTemplate;

	private String cacheTableName;

	private Boolean isEnabled;

	/**
	  * Optional.
	  */
	private Integer id;

	public String getLocalPath() {
		return localPath;
	}

	public void setLocalPath(String localPath) {
		this.localPath = localPath;
	}

	public String getRemoteUrl() {
		return remoteUrl;
	}

	public void setRemoteUrl(String remoteUrl) {
		this.remoteUrl = remoteUrl;
	}

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	public RestTemplate getRestTemplate() {
		return restTemplate;
	}

	public void setRestTemplate(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	public String getCacheTableName() {
		return cacheTableName;
	}

	public void setCacheTableName(String cacheTableName) {
		this.cacheTableName = cacheTableName;
	}

	public Boolean getIsEnabled() {
		return isEnabled;
	}

	public void setIsEnabled(Boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	/**
	  * Optional.
	  */
	public Integer getId() {
		return id;
	}

	/**
	  * Optional.
	  */
	public void setId(Integer id) {
		this.id = id;
	}

}
