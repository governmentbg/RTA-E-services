package bg.demax.iaaa.gateway.restproxying.resttemplate;

import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.time.Duration;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.support.BasicAuthenticationInterceptor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import bg.demax.iaaa.gateway.exception.restproxying.RestTemplateCreationException;
import bg.demax.iaaa.gateway.restproxying.resttemplate.config.RestProxyingRestTemplateConfig;
import bg.demax.iaaa.gateway.restproxying.resttemplate.config.RestProxyingSSLCertificateConfig;

@Service
public class RestProxyingRestTemplateService {

	public static final int DEFAULT_READ_TIMEOUT = 30;
	public static final int DEFAULT_CONNECTION_TIMEOUT = 30;

	public RestTemplate createRestTemplate(RestProxyingRestTemplateConfig config) {

		RestTemplate restTemplate;

		if (config.getKeyStore() != null) {
			restTemplate = createRestTemplateWithSSL(config);
		} else {
			Short readTimeout = config.getReadTimeout();
			Short connectionTimeout = config.getConnectionTimeout();
			restTemplate = restTemplateBuilder(readTimeout, connectionTimeout).build();
		}

		addBasicAuthIfAny(restTemplate, config);

		return restTemplate;
	}

	private RestTemplate createRestTemplateWithSSL(RestProxyingRestTemplateConfig config) {

		RestProxyingSSLCertificateConfig keyStoreConfig = config.getKeyStore();
		RestProxyingSSLCertificateConfig trustStoreConfig = config.getTrustStore();
		SSLContext sslContext = createSSLContext(keyStoreConfig, trustStoreConfig);

		HttpClient client = HttpClients.custom()
				.setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
				.setSSLContext(sslContext)
				.build();

		Short readTimeout = config.getReadTimeout();
		Short connectionTimeout = config.getConnectionTimeout();

		RestTemplate restTemplate = restTemplateBuilder(readTimeout, connectionTimeout)
				.requestFactory(() -> new HttpComponentsClientHttpRequestFactory(client))
				.build();

		return restTemplate;
	}

	private SSLContext createSSLContext(RestProxyingSSLCertificateConfig keyStoreConfig, RestProxyingSSLCertificateConfig trustStoreConfig) {

		if (trustStoreConfig == null) {
			return createSSLContextWithAllTrustingTrustManager(keyStoreConfig);
		}

		char[] keyStorePass = keyStoreConfig.getPassword().toCharArray();

		SSLContext sslContext;
		try {
			sslContext = SSLContextBuilder.create()
					.loadKeyMaterial(keyStore(keyStoreConfig), keyStorePass)
					.loadTrustMaterial(keyStore(trustStoreConfig), null)
					.build();
		} catch (Exception ex) {
			throw new RestTemplateCreationException(ex);
		}

		return sslContext;
	}

	private SSLContext createSSLContextWithAllTrustingTrustManager(RestProxyingSSLCertificateConfig keyStoreConfig) {

		char[] keyStorePassword = keyStoreConfig.getPassword().toCharArray();

		KeyManagerFactory keyManagerFactory;
		try {
			keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			keyManagerFactory.init(keyStore(keyStoreConfig), keyStorePassword);
		} catch (Exception  ex) {
			throw new RestTemplateCreationException(ex);
		}

		/* All trusting trust manager */
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs, String authType) {
			}

			public void checkServerTrusted(X509Certificate[] certs, String authType) {
			}
		} };

		SSLContext sslContext;
		try {
			sslContext = SSLContext.getInstance("TLS");
			sslContext.init(keyManagerFactory.getKeyManagers(), trustAllCerts, new java.security.SecureRandom());
		} catch (NoSuchAlgorithmException | KeyManagementException ex) {
			throw new RestTemplateCreationException(ex);
		}

		return sslContext;
	}

	private KeyStore keyStore(RestProxyingSSLCertificateConfig keyStoreConfig) throws Exception {

		String keyStoreType = keyStoreConfig.getType().value();
		InputStream certDataStream = keyStoreConfig.getCertDataStream();
		char[] keyStorePassword = keyStoreConfig.getPassword().toCharArray();

		KeyStore keyStore = KeyStore.getInstance(keyStoreType);
		keyStore.load(certDataStream, keyStorePassword);

		return keyStore;
	}

	private RestTemplateBuilder restTemplateBuilder(Short readTimeout, Short connectionTimeout) {
		RestTemplateBuilder restTemplateBuilder = new RestTemplateBuilder()
				.setConnectTimeout(
						Duration.ofSeconds(connectionTimeout != null ? connectionTimeout : DEFAULT_CONNECTION_TIMEOUT))
				.setReadTimeout(Duration.ofSeconds(readTimeout != null ? readTimeout : DEFAULT_READ_TIMEOUT));

		return restTemplateBuilder;
	}

	private void addBasicAuthIfAny(RestTemplate restTemplate, RestProxyingRestTemplateConfig config) {
		String username = config.getBasicAuthUsername();
		String password = config.getBasicAuthPassword();

		if (username == null || username.trim().isEmpty()) {
			return;
		}

		restTemplate.getInterceptors().add(new BasicAuthenticationInterceptor(username, password));
	}
}
