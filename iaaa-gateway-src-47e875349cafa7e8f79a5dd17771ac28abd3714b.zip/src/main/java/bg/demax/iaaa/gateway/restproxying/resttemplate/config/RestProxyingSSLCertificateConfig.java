package bg.demax.iaaa.gateway.restproxying.resttemplate.config;

import java.io.InputStream;

import bg.demax.iaaa.gateway.enums.SSLCertificateType;

public class RestProxyingSSLCertificateConfig {

	private InputStream certDataStream;

	private String password;

	private SSLCertificateType type;

	public InputStream getCertDataStream() {
		return certDataStream;
	}

	public void setCertDataStream(InputStream certDataStream) {
		this.certDataStream = certDataStream;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public SSLCertificateType getType() {
		return type;
	}

	public void setType(SSLCertificateType type) {
		this.type = type;
	}

}
