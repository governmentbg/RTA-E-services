package bg.demax.iaaa.gateway.search;

import java.time.LocalDateTime;

import bg.demax.hibernate.SearchConstraint;
import bg.demax.techinsp.entity.InspectionStatus;

public class InspectionSearch {

	private String vin;
	private String regNum;
	private LocalDateTime validUponDateTime;
	private Long stickerNum;
	private InspectionStatus inspectionStatus;

	@SearchConstraint(expression = "(inspection.roadVehicle.vin = :vin OR inspection.roadVehicle.frameNumber = :vin)")
	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	@SearchConstraint(value = "inspection.roadVehicleVersion.registrationNumber")
	public String getRegNum() {
		return regNum;
	}

	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}

	@SearchConstraint(expression = "(inspection.inspectionDateTime <= :validUponDateTime AND"
			+ " inspection.nextInspectionDate >= DATE(:validUponDateTime))")
	public LocalDateTime getValidUponDateTime() {
		return validUponDateTime;
	}

	public void setValidUponDateTime(LocalDateTime validUponDateTime) {
		this.validUponDateTime = validUponDateTime;
	}

	@SearchConstraint(value = "inspection.receivedSignNumber")
	public Long getStickerNum() {
		return stickerNum;
	}

	public void setStickerNum(Long stickerNum) {
		this.stickerNum = stickerNum;
	}

	@SearchConstraint(value = "inspection.currentStatus")
	public InspectionStatus getInspectionStatus() {
		return this.inspectionStatus;
	}

	public void setInspectionStatus(InspectionStatus inspectionStatus) {
		this.inspectionStatus = inspectionStatus;
	}
}
