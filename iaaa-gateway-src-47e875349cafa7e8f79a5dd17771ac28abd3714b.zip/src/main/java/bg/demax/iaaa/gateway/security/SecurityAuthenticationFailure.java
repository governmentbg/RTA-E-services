package bg.demax.iaaa.gateway.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.gateway.dto.controlleradvice.ApplicationExceptionDto;
import bg.demax.iaaa.gateway.utils.ObjectMapperUtils;

@Component
public class SecurityAuthenticationFailure implements AccessDeniedHandler, AuthenticationEntryPoint {

	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException, ServletException {
		setHttpServletResponse(response, authException.getMessage());
	}

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response,
			AccessDeniedException accessDeniedException) throws IOException, ServletException {
		setHttpServletResponse(response, accessDeniedException.getMessage());
	}

	private void setHttpServletResponse(HttpServletResponse response, String exceptionMsg) throws IOException {
		response.setStatus(HttpServletResponse.SC_FORBIDDEN);
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);

		ApplicationExceptionDto exceptionDto = new ApplicationExceptionDto();
		exceptionDto.setError("Error during authentication. Bad Credentials.");
		exceptionDto.setMessage(exceptionMsg);
		String responseJson = ObjectMapperUtils.toJson(exceptionDto);

		response.getWriter().write(responseJson);
	}
}
