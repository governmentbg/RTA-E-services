package bg.demax.iaaa.gateway.security;

public enum SecurityGroups {

	FULL_ACCESS( new String[] { SecurityRole.SUPER_ADMIN, SecurityRole.IAAA_GATEWAY_ADMIN }),
	GENERIC(new String[] { SecurityRole.SUPER_ADMIN, SecurityRole.IAAA_GATEWAY_ADMIN, SecurityRole.GENERIC_USER }),
	INSPECTIONS(new String[] { SecurityRole.SUPER_ADMIN, SecurityRole.IAAA_GATEWAY_ADMIN, SecurityRole.GENERIC_USER, SecurityRole.MVR_USER }),
	PROXY(new String[] { SecurityRole.SUPER_ADMIN, SecurityRole.IAAA_GATEWAY_ADMIN, SecurityRole.GENERIC_USER });

	private String[] rolesInGroup;

	private SecurityGroups(String[] rolesInGroup) {
		this.rolesInGroup = rolesInGroup;
	}

	public String[] getRolesInGroup() {
		return this.rolesInGroup;
	}
}
