package bg.demax.iaaa.gateway.security;

public interface SecurityRole {

	/**
	 * Администраторски права за всички приложения, използвана от служители на Демакс и Скимпрот.
	 */
	String SUPER_ADMIN = "ADMIN";

	/**
	 * Администраторски права за системата IAAA-GATEWAY.
	 */
	String IAAA_GATEWAY_ADMIN = "IAAA_GATEWAY_ADMIN";

	/**
	 * Роля за МВР потребител в системата.
	 */
	String MVR_USER = "IAAA_GATEWAY_MVR_USER";

	/**
	 * Роля за достъп до системата с общо предназначение.
	 */
	String GENERIC_USER = "IAAA_GATEWAY_GENERIC_USER";

}
