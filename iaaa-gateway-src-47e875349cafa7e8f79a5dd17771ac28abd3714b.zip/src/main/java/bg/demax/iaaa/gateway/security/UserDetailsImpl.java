package bg.demax.iaaa.gateway.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import bg.demax.iaaa.gateway.exception.PreAuthenticationException;
import bg.demax.security.entity.User;

public class UserDetailsImpl implements UserDetails {
	private static final long serialVersionUID = -8820300515308690353L;

	public static final String ROLE_PREFIX = "ROLE_";

	private Integer userId = null;
	private String username;
	private String password;
	private boolean isEnabled;
	private Collection<? extends GrantedAuthority> authorities;

	public UserDetailsImpl(User user) {
		this.userId = user.getId();
		this.username = user.getUsername();
		this.password = user.getPassword();
		this.isEnabled = user.isEnabled();
		this.authorities = new ArrayList<>();
		List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>();

		if (user.getUserAuthorities() != null) {
			Set<SimpleGrantedAuthority> securityAuthorities = user.getUserAuthorities().stream().map(authority -> {
				return new SimpleGrantedAuthority(authority.getName());
			}).collect(Collectors.toSet());

			authorities.addAll(securityAuthorities);
		}

		if (authorities.isEmpty()) {
			throw new PreAuthenticationException("Username has no AUTHORITIES!");
		}

		this.authorities = authorities;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return authorities;
	}

	@Override
	public String getPassword() {
		return this.password;
	}

	@Override
	public String getUsername() {
		return this.username;
	}

	@Override
	public boolean isAccountNonExpired() {
		return isEnabled();
	}

	@Override
	public boolean isAccountNonLocked() {
		return isEnabled();
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return isEnabled();
	}

	@Override
	public boolean isEnabled() {
		return this.isEnabled;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUsername(String username) {
		this.username = username;
	}
}
