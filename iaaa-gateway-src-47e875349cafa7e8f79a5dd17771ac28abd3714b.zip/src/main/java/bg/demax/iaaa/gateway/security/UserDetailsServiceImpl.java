package bg.demax.iaaa.gateway.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.db.repository.iaaaimg.UserRepository;
import bg.demax.iaaa.gateway.exception.PreAuthenticationException;
import bg.demax.security.entity.User;

@Service
public class UserDetailsServiceImpl implements AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> {

	@Autowired
	private UserRepository userRepository;

	@Override
	@Transactional(value = BeanQualifiers.IAAA_IMG_TRANSACTION_MANAGER, readOnly = true)
	public UserDetails loadUserDetails(PreAuthenticatedAuthenticationToken token) throws UsernameNotFoundException {
		String publicKey = ((String) token.getPrincipal()).trim();

		User user = userRepository.findUserByPublicKey(publicKey);

		if (user == null) {
			throw new PreAuthenticationException("User with pk " + publicKey + " not found");
		}

		return new UserDetailsImpl(user);
	}

}
