package bg.demax.iaaa.gateway.service;

import java.lang.reflect.Type;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.db.repository.CacheRepository;
import bg.demax.iaaa.gateway.dto.cache.CacheEntry;
import bg.demax.iaaa.gateway.exception.ApplicationException;

@Repository
public class CacheService {

	@Autowired
	private CacheRepository cacheRepo;

	@Autowired
	@Qualifier(BeanQualifiers.CACHE_OBJECT_MAPPER)
	private ObjectMapper postgreJsonMapper;

	private static final Logger log = LogManager.getLogger(CacheService.class);

	public static final String CACHE_FIRST_PERIOD_FROM_HEADER_NAME = "x-cache-first-period";
	public static final String CACHE_SECOND_PERIOD_FROM_HEADER_NAME = "x-cache-second-period";
	public static final Integer CACHE_MAX_PERIOD_HOURS = 744; //1 month

	public <RES> RES smartCache(Callable<RES> callable, Object request, HttpHeaders headers, String tableName, Class<RES> clazz)
			throws Exception {

		TypeReference<RES> toValueTypeRef = buildTypeReference(clazz);

		return smartCache(callable, request, headers, tableName, toValueTypeRef);
	}

	public <RES> RES smartCache(Callable<RES> callable, Object request, HttpHeaders headers, String tableName,
			TypeReference<?> toValueTypeRef) throws Exception {
		SmartCacheProperties props = buildCacheProperties(headers, tableName);

		return smartCache(callable, request, props, toValueTypeRef);
	}

	private <REQ, RES> RES smartCache(Callable<RES> callable, REQ request, SmartCacheProperties props,
			TypeReference<?> toValueTypeRef) throws Exception {

		CacheEntry<REQ, RES> cacheEntry = null;
		if (props.getFirstCachePeriodInHours() != null) {
			cacheEntry = cacheRepo.getCacheFromDb(request, props.getTableName(), props.getFirstCachePeriodInHours());
			if (cacheEntry != null) {
				if (cacheEntry.getResponse() != null) {
					return postgreJsonMapper.convertValue(cacheEntry.getResponse(), toValueTypeRef);
				}
				return null;
			}
		}
		try {
			cacheEntry = new CacheEntry<REQ, RES>();

			LocalDateTime reqTime = LocalDateTime.now();
			cacheEntry.setRequestTime(reqTime);
			cacheEntry.setRequest(request);

			try {
				RES response = callable.call();
				cacheEntry.setResponse(response);
				return response;
			} catch (Exception e) {
				cacheEntry.setError(e.getMessage());
				throw e;
			} finally {
				LocalDateTime respTime = LocalDateTime.now();
				cacheEntry.setResponseTime(respTime);
				cacheRepo.logCacheToDb(cacheEntry, props.getTableName());
			}
		} catch (Exception e) {
			e.printStackTrace();
			if (props.getSecondCachePeriodInHours() == null) {
				throw e;
			}
			cacheEntry = cacheRepo.getCacheFromDb(request, props.getTableName(), props.getSecondCachePeriodInHours());
			if (cacheEntry != null) {
				if (cacheEntry.getResponse() != null) {
					return postgreJsonMapper.convertValue(cacheEntry.getResponse(), toValueTypeRef);
				}
				return null;
			} else {
				throw e;
			}
		}
	}

	private SmartCacheProperties buildCacheProperties(HttpHeaders httpHeaders, String cacheTablename) {
		SmartCacheProperties cacheProperties = new SmartCacheProperties();
		cacheProperties.setTableName(cacheTablename);

		setCachePeriod(httpHeaders, CACHE_FIRST_PERIOD_FROM_HEADER_NAME, cacheProperties::setFirstCachePeriodInHours);
		setCachePeriod(httpHeaders, CACHE_SECOND_PERIOD_FROM_HEADER_NAME, cacheProperties::setSecondCachePeriodInHours);
		return cacheProperties;
	}

	private void setCachePeriod(HttpHeaders httpHeaders, String headerName, Consumer<Integer> cachePropSetter) {
		List<String> headerValues = httpHeaders.get(headerName);

		if (headerValues != null && !headerValues.isEmpty()) {
			String cachePeriodStr = headerValues.get(0);
			try {
				Integer cachePeriod = Integer.parseInt(cachePeriodStr);

				if (cachePeriod > CACHE_MAX_PERIOD_HOURS) {
					throw new ApplicationException(String.format("Max cache period is %s but %s was %s.", CACHE_MAX_PERIOD_HOURS,
							headerName, cachePeriod));
				}

				cachePropSetter.accept(cachePeriod);
			} catch (NumberFormatException ex) {
				log.warn("Unparsable cache period value detected.");
			}
		}
	}

	private <T> TypeReference<T> buildTypeReference(Class<T> clazz) {
		JavaType javaType = postgreJsonMapper.getTypeFactory().constructFromCanonical(clazz.getCanonicalName());

		TypeReference<T> toValueTypeRef = new TypeReference<T>() {

			@Override
			public Type getType() {
				return javaType;
			}
		};

		return toValueTypeRef;
	}
}
