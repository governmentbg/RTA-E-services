package bg.demax.iaaa.gateway.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.controller.params.GraoParams;
import bg.demax.iaaa.gateway.exception.ApplicationException;
import bg.demax.iaaa.gateway.graowsdl.GraoResponse;
import bg.demax.iaaa.gateway.utils.notifiers.ProjectSupportNotificationService;

@Service
public class GraoService {

	private static final Logger logger = LogManager.getLogger(GraoService.class);

	@Autowired
	@Qualifier(BeanQualifiers.GRAO_REST_TEMPLATE)
	private RestTemplate graoRt;

	@Autowired
	private ProjectSupportNotificationService notificationService;

	@Value("${grao.address}")
	private String graoAddress;

	public GraoResponse getGraoResponse(GraoParams params) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add("egn", params.getEgn());
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);
		String xmlResult = executeErrorHandledGetPersonData(request);

		GraoResponse graoResponse = toGraoResponse(xmlResult);

		return graoResponse;
	}

	public GraoResponse toGraoResponse(String xml) {
		try {
			JAXBContext context = JAXBContext.newInstance(GraoResponse.class);
			Unmarshaller unmarashaler = context.createUnmarshaller();

			InputStream is = new ByteArrayInputStream(xml.getBytes());
			GraoResponse gr = (GraoResponse) unmarashaler.unmarshal(is);
			is.close();

			return gr;
		} catch (JAXBException | IOException e) {
			logger.warn(e.getMessage() + ".Xml:" + xml);
			notificationService.notify("Could not deserialize grao response", Level.WARN);
			throw new ApplicationException("Could not deserialize grao response");
		}
	}

	private String executeErrorHandledGetPersonData(HttpEntity<MultiValueMap<String, String>> request) {
		try {
			String xmlResult = graoRt.postForObject(this.graoAddress, request, String.class);
			return xmlResult;
		} catch (HttpStatusCodeException e) {
			String errorMessage = e.getMessage() + ". Response body:" + e.getResponseBodyAsString();
			logger.warn(errorMessage);
			notificationService.notify("Unexpected error when exchaning with grao.", Level.WARN);
			throw new ApplicationException("Unexpected error when exchaning with grao.");
		} catch (Exception e) {
			logger.warn(e.getMessage());
			notificationService.notify("Unexpected error when exchaning with grao.", Level.WARN);
			throw new ApplicationException("Unexpected error when exchaning with grao.");
		}
	}
}
