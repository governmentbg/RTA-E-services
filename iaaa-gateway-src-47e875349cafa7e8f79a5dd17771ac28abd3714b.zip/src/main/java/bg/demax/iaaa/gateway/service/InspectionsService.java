package bg.demax.iaaa.gateway.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.converters.AppConversionService;
import bg.demax.iaaa.gateway.db.finder.InspectionsFinder;
import bg.demax.iaaa.gateway.dto.HistoryInspectionDto;
import bg.demax.iaaa.gateway.dto.LastInspectionDto;
import bg.demax.iaaa.gateway.dto.MalfunctionDto;
import bg.demax.iaaa.gateway.dto.ValidInspectionDto;
import bg.demax.iaaa.gateway.dto.ValidInspectionResponse;
import bg.demax.iaaa.gateway.search.InspectionSearch;
import bg.demax.techinsp.entity.Inspection;
import bg.demax.techinsp.entity.InspectionCheckValue;
import bg.demax.techinsp.entity.InspectionConclusion;
import bg.demax.techinsp.entity.InspectionStatus;

@Service
public class InspectionsService {
	@Autowired
	private InspectionsFinder inspectionsFinder;

	@Autowired
	private AppConversionService conversionService;

	@Transactional(value = BeanQualifiers.IAAA_IMG_TRANSACTION_MANAGER, readOnly = true)
	public ValidInspectionResponse checkForValidInspection(InspectionSearch search) {
		search.setInspectionStatus(InspectionStatus.COMPLETED);
		if (search.getValidUponDateTime() == null) {
			search.setValidUponDateTime(LocalDateTime.now());
		}
		Inspection inspection = inspectionsFinder.findBySearchParams(search);
		if (inspection != null && inspection.getConclusion() == InspectionConclusion.NA) {
			inspection = null;
		}
		ValidInspectionDto inspectionDto = conversionService.convert(inspection, ValidInspectionDto.class);

		ValidInspectionResponse validInspectionResponse = new ValidInspectionResponse();
		validInspectionResponse.setInspection(inspectionDto);
		validInspectionResponse.setHasValidInspection(inspectionDto != null);
		return validInspectionResponse;
	}

	@Transactional(value = BeanQualifiers.IAAA_IMG_TRANSACTION_MANAGER, readOnly = true)
	public LastInspectionDto getLastInspection(InspectionSearch search) {
		search.setInspectionStatus(InspectionStatus.COMPLETED);
		Inspection inspection = inspectionsFinder.findBySearchParams(search);

		LastInspectionDto lastInspection = conversionService.convert(inspection, LastInspectionDto.class);
		if (lastInspection != null && lastInspection.getMalfunctions() != null) {
			List<MalfunctionDto> onlyCheckedAsNMalfunctions = lastInspection.getMalfunctions().stream()
					.filter(m -> m != null)
					.filter(m -> m.getCheckValue() == InspectionCheckValue.N)
					.collect(Collectors.toList());
			lastInspection.setMalfunctions(onlyCheckedAsNMalfunctions);
		}

		return lastInspection;
	}

	@Transactional(value = BeanQualifiers.IAAA_IMG_TRANSACTION_MANAGER, readOnly = true)
	public List<HistoryInspectionDto> getInspectionsHistory(InspectionSearch search) {
		search.setInspectionStatus(InspectionStatus.COMPLETED);
		List<Inspection> inspections = inspectionsFinder.findAllBySearchParams(search);

		List<HistoryInspectionDto> filteredInsp = conversionService.convertList(inspections, HistoryInspectionDto.class);

		return filteredInsp;
	}
}
