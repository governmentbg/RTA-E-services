package bg.demax.iaaa.gateway.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.converters.AppConversionService;
import bg.demax.iaaa.gateway.db.entity.iaaaproxies.ProxyRequestDetails;
import bg.demax.iaaa.gateway.db.repository.iaaaproxies.ProxyRequestDetailsRepository;
import bg.demax.iaaa.gateway.exception.NoSuchEntityException;
import bg.demax.iaaa.gateway.restproxying.requestconfig.config.RestProxyingRequestConfig;

@Service
public class ProxyRequestDetailsService {

	@Autowired
	private ProxyRequestDetailsRepository proxyRequestDetailsRepository;

	@Autowired
	private AppConversionService conversionService;

	@Transactional(value = BeanQualifiers.IAAA_PROXIES_TRANSACTION_MANAGER, readOnly = true)
	public List<RestProxyingRequestConfig> findAllEnabledProxyingRequestConfigs() {
		List<ProxyRequestDetails> proxyRequestsDetails = proxyRequestDetailsRepository.findAllByIsEnabledTrue();

		return conversionService.convertList(proxyRequestsDetails, RestProxyingRequestConfig.class);
	}

	@Transactional(value = BeanQualifiers.IAAA_PROXIES_TRANSACTION_MANAGER, readOnly = true)
	public RestProxyingRequestConfig findProxyingRequestConfig(Integer id) {
		ProxyRequestDetails proxyRequestDetails = proxyRequestDetailsRepository.findById(id).orElse(null);

		if (proxyRequestDetails == null) {
			throw new NoSuchEntityException(ProxyRequestDetails.class, id);
		}

		return conversionService.convert(proxyRequestDetails, RestProxyingRequestConfig.class);
	}

}
