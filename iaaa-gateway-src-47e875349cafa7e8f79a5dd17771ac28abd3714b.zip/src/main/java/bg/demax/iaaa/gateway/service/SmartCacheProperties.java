package bg.demax.iaaa.gateway.service;

public class SmartCacheProperties {

	private Integer firstCachePeriodInHours;
	private Integer secondCachePeriodInHours;
	private String tableName;

	public SmartCacheProperties() {
	}

	public SmartCacheProperties(Integer firstCachePeriodInHours, Integer secondCachePeriodInHours, String tableName) {
		super();
		this.firstCachePeriodInHours = firstCachePeriodInHours;
		this.secondCachePeriodInHours = secondCachePeriodInHours;
		this.tableName = tableName;
	}

	public Integer getFirstCachePeriodInHours() {
		return firstCachePeriodInHours;
	}

	public void setFirstCachePeriodInHours(Integer firstCachePeriodInHours) {
		this.firstCachePeriodInHours = firstCachePeriodInHours;
	}

	public Integer getSecondCachePeriodInHours() {
		return secondCachePeriodInHours;
	}

	public void setSecondCachePeriodInHours(Integer secondCachePeriodInHours) {
		this.secondCachePeriodInHours = secondCachePeriodInHours;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
}