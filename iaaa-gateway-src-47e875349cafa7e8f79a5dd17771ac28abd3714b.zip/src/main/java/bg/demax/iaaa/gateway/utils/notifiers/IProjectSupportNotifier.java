package bg.demax.iaaa.gateway.utils.notifiers;

import org.apache.logging.log4j.Level;

public interface IProjectSupportNotifier {

	void notify(String notification, Level notificationLevel);
}
