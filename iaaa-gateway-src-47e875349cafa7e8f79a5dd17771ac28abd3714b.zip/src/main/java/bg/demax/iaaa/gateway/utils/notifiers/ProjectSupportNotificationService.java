package bg.demax.iaaa.gateway.utils.notifiers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
public class ProjectSupportNotificationService {

	private static final Logger logger = LogManager.getLogger(ProjectSupportNotificationService.class);

	@Autowired(required = false)
	private List<IProjectSupportNotifier> notifiers = new ArrayList<>();

	@Autowired
	private Environment env;

	public void notify(String notification) {
		notify(notification, Level.INFO);
	}

	public void notify(String notification, Level level) {
		String notificationWithProfile = "Active spring profiles: " + Arrays.toString(env.getActiveProfiles()) + ". Message: " + notification;
		logger.trace(notification);
		notifiers.forEach(notifier -> notifier.notify(notificationWithProfile, level));
	}
}
