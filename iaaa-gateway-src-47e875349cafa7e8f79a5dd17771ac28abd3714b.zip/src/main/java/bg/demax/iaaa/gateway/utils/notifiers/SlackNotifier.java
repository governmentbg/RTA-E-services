package bg.demax.iaaa.gateway.utils.notifiers;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.spi.StandardLevel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.github.seratch.jslack.Slack;
import com.github.seratch.jslack.api.webhook.Payload;

import bg.demax.iaaa.gateway.IaaaGatewayApplication;
import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;

@Service
@Profile("!" + IaaaGatewayConstants.SPRING_PROFILE_TEST)
public class SlackNotifier implements IProjectSupportNotifier {

	private static final Logger log = LogManager.getLogger(SlackNotifier.class);

	@Value("${slack.webhook}")
	private String urlSlackWebHook;

	@Value("${slack.channel}")
	private String channel;

	@Value("${slack.emoji}")
	private String emoji;

	@Value("${slack.level}")
	private Level level;

	@Override
	public void notify(String notification, Level notificationLevel) {
		if (notificationLevel.intLevel() <= level.intLevel() && notificationLevel.intLevel() > StandardLevel.OFF.intLevel()) {
			process(notification);
		}
	}

	private void process(String message) {
		Payload payload = Payload.builder()
				.channel(channel)
				.username(IaaaGatewayApplication.class.getSimpleName())
				.iconEmoji(emoji)
				.text(message)
				.build();
		try {
			Slack.getInstance().send(urlSlackWebHook, payload);

		} catch (Exception e) {
			log.error(e.getMessage());
		}
	}
}
