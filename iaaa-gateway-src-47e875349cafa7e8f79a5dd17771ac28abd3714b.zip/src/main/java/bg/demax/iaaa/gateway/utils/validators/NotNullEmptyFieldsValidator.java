package bg.demax.iaaa.gateway.utils.validators;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.util.ReflectionUtils;

public class NotNullEmptyFieldsValidator implements ConstraintValidator<NotNullEmptyFields, Object> {

	public void initialize(NotNullEmptyFields constraintAnnotation) {
	}

	@Override
	public boolean isValid(Object requestParam, ConstraintValidatorContext constraintValidatorContext) {
		Map<String, List<String>> invalidGroups = getInvalidAnnotationGroups(requestParam);
		StringBuilder violatingGroupsStringBuilder = new StringBuilder();
		for (List<String> group : invalidGroups.values()) {
			violatingGroupsStringBuilder.append(group).append(", ");
		}
		if (!invalidGroups.isEmpty()) {
			String message = "All properties: " + violatingGroupsStringBuilder.toString()
				+ "have annotation EitherPresent, at least one from each group must have a value";
			constraintValidatorContext.disableDefaultConstraintViolation();
			constraintValidatorContext.buildConstraintViolationWithTemplate(message).addConstraintViolation();
		}
		return invalidGroups.isEmpty();
	}

	private Map<String, List<String>> getInvalidAnnotationGroups(Object requestParam) {
		Map<String, List<String>> allGroups = getAllAnnotationGroups(requestParam);

		Map<String, List<String>> invalidGroups = new HashMap<>();
		for (Map.Entry<String, List<String>> group : allGroups.entrySet()) {
			boolean groupInvalid = true;
			for (String name : group.getValue()) {
				if (name == null) {
					groupInvalid = false;
					break;
				}
			}
			if (groupInvalid) {
				invalidGroups.put(group.getKey(), group.getValue());
			}
		}
		return invalidGroups;
	}

	private Map<String, List<String>> getAllAnnotationGroups(Object requestParam) {
		Map<String, List<String>> allGroups = new HashMap<>();

		ReflectionUtils.doWithFields(requestParam.getClass(), field -> {
			boolean originalAccessibility = field.isAccessible();
			field.setAccessible(true);

			EitherPresent eitherPresentAnnotation = field.getAnnotation(EitherPresent.class);
			if (eitherPresentAnnotation != null) {
				String objVal = (String) field.get(requestParam);
				String objName = null;
				if (objVal == null || objVal.isEmpty()) {
					JsonProperty jsonPropertyAnnotation = field.getAnnotation(JsonProperty.class);
					if (jsonPropertyAnnotation != null) {
						objName = jsonPropertyAnnotation.value();
					}
					else {
						objName = field.getName();
					}
				}
				String objGroup = eitherPresentAnnotation.group();
				List<String> groupVals = allGroups.get(objGroup) != null ? allGroups.get(objGroup) : new ArrayList<>();
				groupVals.add(objName);
				allGroups.put(objGroup, groupVals);
			}

			field.setAccessible(originalAccessibility);
		});
		return allGroups;
	}
}
