package bg.demax.iaaa.gateway;

public class DelMeTestIT {

}
