package bg.demax.iaaa.gateway;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashSet;
import java.util.Set;

import org.assertj.core.util.Arrays;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.DefaultMockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import bg.demax.iaaa.gateway.security.SecurityGroups;
import bg.demax.iaaa.gateway.security.UserDetailsImpl;
import bg.demax.iaaa.gateway.testutils.SecurityTestUtil;
import bg.demax.security.entity.Authority;
import bg.demax.security.entity.User;

@WebAppConfiguration
public abstract class AbstractMvcTest extends AbstractRepositoryTest {

	@Autowired
	private WebApplicationContext webApplicationContext;

	protected MockMvc mockMvc;
	protected MvcObjectMapper mvcOm;

	@Before
	public void setup() {
		this.mockMvc = setupMockMvcBuilder(MockMvcBuilders.webAppContextSetup(webApplicationContext), true).build();
		this.mvcOm = new MvcObjectMapper(mockMvc);
	}

	protected DefaultMockMvcBuilder setupMockMvcBuilder(DefaultMockMvcBuilder builder, boolean withCsrf) {
		MockHttpServletRequestBuilder mockServletRequestBuilder = MockMvcRequestBuilders.get("/");
		if (withCsrf) {
			mockServletRequestBuilder.with(csrf());
		}

		return builder
				.defaultRequest(mockServletRequestBuilder.contentType(MediaType.APPLICATION_JSON)
						.header("X-Requested-With", "XMLHttpRequest"))
				.apply(SecurityMockMvcConfigurers.springSecurity());
	}

	protected ResultActions performRequestWithRole(MockHttpServletRequestBuilder request, String role)
			throws Exception {
		if (!role.startsWith(UserDetailsImpl.ROLE_PREFIX)) {
			role = UserDetailsImpl.ROLE_PREFIX + role;
		}
		User user = new User();
		user.setId(1);
		user.setUsername("mock_poli");
		user.setEnabled(true);
		Authority authority = new Authority();
		authority.setName(role);
		Set<Authority> authorities = new HashSet<Authority>();
		authorities.add(authority);
		user.setUserAuthorities(authorities);
		request.with(user(new UserDetailsImpl(user)));
		return mockMvc.perform(request);
	}

	protected void testRequestPermissions(MockHttpServletRequestBuilder request, SecurityGroups securityGroups,
			ResultMatcher whenHasPermissions, ResultMatcher whenNoPermissions) {

		try {
			mockMvc.perform(request).andExpect(status().isForbidden());
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		SecurityTestUtil.getAllRoles().forEach(role -> {
			boolean hasPermission = Arrays.asList(securityGroups.getRolesInGroup()).contains(role);
			ResultMatcher expectedResult = hasPermission ? whenHasPermissions : whenNoPermissions;

			try {
				performRequestWithRole(request, role).andExpect(expectedResult);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

}