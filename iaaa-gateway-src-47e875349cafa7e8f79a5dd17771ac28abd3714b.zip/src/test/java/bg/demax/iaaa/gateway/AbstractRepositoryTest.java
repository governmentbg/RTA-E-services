package bg.demax.iaaa.gateway;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import bg.demax.iaaa.gateway.IaaaGatewayApplication;
import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;
import bg.demax.iaaa.gateway.testutils.PostgreDbCleaner;
import bg.demax.iaaa.gateway.testutils.SqlScriptExecutor;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { IaaaGatewayApplication.class })
@ActiveProfiles(IaaaGatewayConstants.SPRING_PROFILE_TEST)

//without this data source pools will NOT be closed after context reload and as a result will use up database connections
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public abstract class AbstractRepositoryTest {

	@Autowired
	@Qualifier(BeanQualifiers.IAAA_IMG_SESSION_FACTORY)
	private SessionFactory iaaaImgSessionFactory;

	@Autowired
	@Qualifier(BeanQualifiers.IAAA_PROXIES_SESSION_FACTORY)
	private SessionFactory iaaaProxiesSessionFactory;

	@Autowired
	protected SqlScriptExecutor sqlScriptExecutor;

	@Autowired
	@Qualifier(BeanQualifiers.IAAA_IMG_DATASOURCE)
	protected DataSource iaaaImgDataSource;

	@Autowired
	@Qualifier(BeanQualifiers.IAAA_PROXIES_DATASOURCE)
	protected DataSource cacheDataSource;

	@Before
	public void reintDatabase() throws SQLException {
		PostgreDbCleaner.trunkateAllAndResetSequences(iaaaImgDataSource.getConnection());
		PostgreDbCleaner.trunkateAllAndResetSequences(cacheDataSource.getConnection());
	}

	protected Session getIaaaImgCurrentSession() {
		return iaaaImgSessionFactory.getCurrentSession();
	}

	protected Session getIaaaProxiesCurrentSession() {
		return iaaaProxiesSessionFactory.getCurrentSession();
	}
}
