package bg.demax.iaaa.gateway;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;

@SpringBootTest
@ActiveProfiles(IaaaGatewayConstants.SPRING_PROFILE_TEST)
public class IaaaGatewayApplicationTests {

	@Test
	public void contextLoads() {
	}

}
