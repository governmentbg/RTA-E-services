package bg.demax.iaaa.gateway.annotation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import bg.demax.iaaa.gateway.testutils.ValidatorsUtil;
import bg.demax.iaaa.gateway.utils.validators.EitherPresent;
import bg.demax.iaaa.gateway.utils.validators.NotNullEmptyFields;

import com.fasterxml.jackson.annotation.JsonProperty;

public class NotNullEmptyFieldsValidatorTest {

	@Test
	public void testNotNullEmptyFieldsValidator_All_Present_OK() throws Exception {

		TestClass params = new TestClass();
		params.setProp1("PA1403BP");
		params.setProp2("WF0WXXGCDW4S43465");
		params.setProp3("CA1525PB");
		params.setProp4("WWFHW1282WHFEJW");

		List<String> result = ValidatorsUtil.getConstrainViolationMessages(params);
		assertEquals(0, result.size());
	}

	@Test
	public void testNotNullEmptyFieldsValidator_Only_One_Present_Each_Group_OK() throws Exception {

		TestClass params = new TestClass();
		params.setProp1("PA1403BP");
		params.setProp3("CA1525PB");

		List<String> result = ValidatorsUtil.getConstrainViolationMessages(params);
		assertEquals(0, result.size());
	}

	@Test
	public void testNotNullEmptyFieldsValidator_One_Group_Empty_Error() throws Exception {

		TestClass params = new TestClass();
		params.setProp1("PA1403BP");

		List<String> result = ValidatorsUtil.getConstrainViolationMessages(params);
		String errorMsg = result.get(0);

		String expectedMessage = "All properties: [prop3, prop4], have annotation EitherPresent, at least one from each group must have a value";
		assertTrue(errorMsg.contains(expectedMessage));
		assertEquals(1, result.size());
	}

	@Test
	public void testNotNullEmptyFieldsValidator_Has_Error_Message_Fields_Are_Empty() throws Exception {

		TestClass params = new TestClass();
		params.setProp1("");
		params.setProp2(null);
		params.setProp3(null);
		params.setProp4("");

		List<String> result = ValidatorsUtil.getConstrainViolationMessages(params);
		String errorMsg = result.get(0);

		String expectedMessage = "All properties: [prop1, notProp2], [prop3, prop4],"
				+ " have annotation EitherPresent, at least one from each group must have a value";
		assertTrue(errorMsg.contains(expectedMessage));
		assertEquals(1, result.size());
	}

	@Test
	public void testNotNullEmptyFieldsValidator_JsonProperty_Name_Passed_In_Error_Msg() {
		TestClass params = new TestClass();
		params.setProp3("PA1403BP");

		List<String> result = ValidatorsUtil.getConstrainViolationMessages(params);
		String errorMsg = result.get(0);

		String expectedMessage = "All properties: [prop1, notProp2], have annotation EitherPresent, at least one from each group must have a value";
		assertTrue(errorMsg.contains(expectedMessage));
		assertEquals(1, result.size());
	}

	@NotNullEmptyFields
	@SuppressWarnings("unused")
	private static class TestClass {

		@EitherPresent
		private String prop1;

		@EitherPresent
		@JsonProperty("notProp2")
		private String prop2;

		@EitherPresent(group = "test_group")
		private String prop3;

		@EitherPresent(group = "test_group")
		private String prop4;

		public String getProp1() {
			return prop1;
		}

		public void setProp1(String prop1) {
			this.prop1 = prop1;
		}

		public String getProp2() {
			return prop2;
		}

		public void setProp2(String prop2) {
			this.prop2 = prop2;
		}

		public String getProp3() {
			return prop3;
		}

		public void setProp3(String prop3) {
			this.prop3 = prop3;
		}

		public String getProp4() {
			return prop4;
		}

		public void setProp4(String prop4) {
			this.prop4 = prop4;
		}
	}
}
