package bg.demax.iaaa.gateway.config;

import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.testcontainers.containers.PostgreSQLContainer;

import com.zaxxer.hikari.HikariDataSource;

import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;
import bg.demax.iaaa.gateway.db.repository.GenericRepository;
import bg.demax.iaaa.gateway.testutils.DockerContainerSingletons;

@Configuration
@Profile(IaaaGatewayConstants.SPRING_PROFILE_TEST)
@EnableJpaRepositories(
		basePackages = IaaaGatewayConstants.IAAA_PROXIES_REPOSITORY_PACKAGE,
		entityManagerFactoryRef = BeanQualifiers.IAAA_PROXIES_SESSION_FACTORY,
		transactionManagerRef = BeanQualifiers.IAAA_PROXIES_TRANSACTION_MANAGER
)
public class IaaaProxiesDbTestConfiguration {

	@Bean
	@Qualifier(BeanQualifiers.IAAA_PROXIES_DATASOURCE)
	public DataSource iaaaProxiesDataSource() throws SQLException {
		PostgreSQLContainer<?> pgContainer = DockerContainerSingletons.getCacheDbPgContainer();

		HikariDataSource dataSource = new HikariDataSource();
		dataSource.setJdbcUrl(pgContainer.getJdbcUrl());
		dataSource.setPassword(pgContainer.getPassword());
		dataSource.setUsername(pgContainer.getUsername());

		return dataSource;
	}

	@Bean(name = BeanQualifiers.IAAA_PROXIES_TRANSACTION_MANAGER)
	public PlatformTransactionManager iaaaImgTransactionManager() throws SQLException {
		JpaTransactionManager jpaTransactionManager = new JpaTransactionManager();
		jpaTransactionManager.setEntityManagerFactory(sessionFactoryBean().getObject());
		return jpaTransactionManager;
	}

	@Bean(name = BeanQualifiers.IAAA_PROXIES_SESSION_FACTORY)
	@Qualifier(BeanQualifiers.IAAA_PROXIES_SESSION_FACTORY)
	public LocalSessionFactoryBean sessionFactoryBean() throws SQLException {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(iaaaProxiesDataSource());
		sessionFactory.setPackagesToScan(IaaaGatewayConstants.IAAA_PROXIES_ENTITY_PACKAGES_TO_SCAN);
		sessionFactory.setHibernateProperties(hibernateProperties());
		return sessionFactory;
	}

	@Bean
	@Qualifier(BeanQualifiers.IAAA_PROXIES_GENERIC_REPOSITORY)
	public GenericRepository iaaaProxiesGenericRepository() throws SQLException {
		return new GenericRepository(sessionFactoryBean().getObject());
	}

	@Bean
	public NamedParameterJdbcTemplate getJdbcTemplate() throws SQLException {
		return new NamedParameterJdbcTemplate(iaaaProxiesDataSource());
	}

	private Properties hibernateProperties() {
		Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty("hibernate.hbm2ddl.auto", "update");
		hibernateProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.PostgreSQL91Dialect");
		hibernateProperties.setProperty("hibernate.show_sql", "false");
		hibernateProperties.setProperty("hibernate.temp.use_jdbc_metadata_defaults", "false");

		return hibernateProperties;
	}
}
