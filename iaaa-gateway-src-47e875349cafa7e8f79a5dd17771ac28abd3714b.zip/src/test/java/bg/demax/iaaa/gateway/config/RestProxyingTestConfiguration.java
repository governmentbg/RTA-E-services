package bg.demax.iaaa.gateway.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import bg.demax.iaaa.gateway.config.restproxying.ProxyConfigurationProperties;

@Configuration
@Profile(IaaaGatewayConstants.SPRING_PROFILE_TEST)
public class RestProxyingTestConfiguration {

	@Bean
	@ConfigurationProperties("proxy.test")
	public ProxyConfigurationProperties proxyConfigProps() {
		ProxyConfigurationProperties properties = new ProxyConfigurationProperties();
		return properties;
	}

	@Bean
	@ConfigurationProperties("proxy.test-with-p12")
	public ProxyConfigurationProperties proxyConfigPropsWithP12() {
		ProxyConfigurationProperties properties = new ProxyConfigurationProperties();
		return properties;
	}
}
