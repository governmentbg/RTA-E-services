package bg.demax.iaaa.gateway.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockserver.model.JsonBody.json;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import org.junit.Before;
import org.junit.Test;
import org.mockserver.client.MockServerClient;
import org.mockserver.model.Header;
import org.mockserver.model.HttpRequest;
import org.mockserver.model.HttpResponse;
import org.mockserver.model.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.testcontainers.containers.MockServerContainer;

import bg.demax.iaaa.gateway.AbstractMvcTest;
import bg.demax.iaaa.gateway.db.entity.iaaaproxies.ProxyRequestDetails;
import bg.demax.iaaa.gateway.dto.controlleradvice.ApplicationExceptionDto;
import bg.demax.iaaa.gateway.dto.controlleradvice.ProxyingRestClientExceptionDto;
import bg.demax.iaaa.gateway.exception.ApplicationException;
import bg.demax.iaaa.gateway.exception.restproxying.ProxyingRestClientException;
import bg.demax.iaaa.gateway.restproxying.requestconfig.RestProxyingRequestConfigService;
import bg.demax.iaaa.gateway.security.SecurityGroups;
import bg.demax.iaaa.gateway.service.CacheService;
import bg.demax.iaaa.gateway.utils.DbImportService;
import bg.demax.iaaa.gateway.utils.ObjectMapperUtils;
import bg.demax.iaaa.gateway.utils.RestProxyingUtil;

@ContextConfiguration(initializers = {AutoRestProxyingControllerTest.Initializer.class})
public class AutoRestProxyingControllerTest extends AbstractMvcTest {

	private static final String CONTROLLER_ENDPOINT = "/api/proxy/auto";

	private static final String LOCAL_URL_FROM_APP_PROPS = CONTROLLER_ENDPOINT + "/test/from/properties/{id1}/{id2}";
	private static final String MISSING_CONFIG_FOR_LOCAL_URL = CONTROLLER_ENDPOINT + "/i/do/not/exist";
	private static final String LOCAL_URL_FROM_DB_WITH_TRUSTSTORE = CONTROLLER_ENDPOINT	 + "/test/from/db/{id1}";
	private static final String LOCAL_URL_FROM_DB_WITHOUT_TRUSTSTORE = CONTROLLER_ENDPOINT	 + "/test/from/db";

	private static final String MOCK_SERVER_RESPONSE = "{\"result\":\"OK\",\"happy\":\"Yes\"}";

	private static MockServerContainer mockServer;

	static {
		mockServer = new MockServerContainer("5.10.0");
		mockServer.start();
	}

	public static class Initializer implements ApplicationContextInitializer<ConfigurableApplicationContext> {

		public void initialize(ConfigurableApplicationContext configurableApplicationContext) {
			TestPropertyValues.of(
					"proxy.test.remote_url=" + mockServer.getEndpoint(),
					"proxy.test-with-p12.remote_url=" + mockServer.getEndpoint()
				).applyTo(configurableApplicationContext.getEnvironment());
		}
	}

	private MockServerClient mockServerClient = new MockServerClient(
				mockServer.getContainerIpAddress(),
				mockServer.getServerPort()
			);

	@Autowired
	private DbImportService dbImportService;

	@Autowired
	private RestProxyingRequestConfigService configService;

	@Before
	public void init() throws IOException {
		ProxyRequestDetails proxyRequestDetailsWithTrustStore = getProxyRequestDetailsWithTrustStore();
		ProxyRequestDetails proxyRequestDetailsWithoutTrustStore = getProxyRequestDetailsWithoutTrustStore();
		ProxyRequestDetails proxyRequestDetailsWithoutSSL = getProxyRequestDetailsWithoutSSL();
		ProxyRequestDetails proxyRequestDetailsWithBasicAuth = getProxyRequestDetailsWithBasicAuth();

		dbImportService.saveProxyRequestDetails(proxyRequestDetailsWithTrustStore);
		dbImportService.saveProxyRequestDetails(proxyRequestDetailsWithoutTrustStore);
		dbImportService.saveProxyRequestDetails(proxyRequestDetailsWithoutSSL);
		dbImportService.saveProxyRequestDetails(proxyRequestDetailsWithBasicAuth);

		configService.updateAll();
	}

	@Test
	public void test_permissions() throws Exception {
		String id1 = "1";
		String id2 = "2";

		mockRemoteServer(HttpMethod.GET.toString(), "/1/2");

		MockHttpServletRequestBuilder request = get(LOCAL_URL_FROM_APP_PROPS, id1, id2);

		mockMvc.perform(request).andExpect(status().isForbidden());
		testRequestPermissions(request, SecurityGroups.PROXY, status().is2xxSuccessful(), status().isForbidden());
	}

	@Test
	public void test_precondition_failed_when_no_request_config_found() throws Exception {

		MockHttpServletRequestBuilder request = get(MISSING_CONFIG_FOR_LOCAL_URL);

		performRequestWithRole(request, SecurityGroups.PROXY.getRolesInGroup()[0])
			.andExpect(status().isPreconditionFailed());
	}

	@Test
	public void test_failed_dependency_when_remote_url_is_not_found() throws Exception {

		mockRemoteServer(HttpMethod.GET.toString(), "/i/am/troll");

		MockHttpServletRequestBuilder request = get(LOCAL_URL_FROM_DB_WITHOUT_TRUSTSTORE);

		performRequestWithRole(request, SecurityGroups.PROXY.getRolesInGroup()[0])
			.andExpect(status().isFailedDependency());
	}

	@Test
	public void testErrorPropagationFromProxiedServiceToClient() throws Exception {
		String method = HttpMethod.GET.toString();
		String pathVar1 = "testErrorPropagationFromProxiedServiceToClient";
		String pathVar2 = "pathVar2";
		String remotePathSuffix = "/" + pathVar1 + "/" + pathVar2;
		Integer remoteStatusCode = HttpStatus.CONFLICT.value();
		MockServerDummyResponse mockServerDummyResponse = new MockServerDummyResponse();
		mockServerDummyResponse.setHappy("No");
		mockServerDummyResponse.setResult("You surprised me with that one.");
		HttpResponse httpResponse = new HttpResponse();
		httpResponse.withStatusCode(remoteStatusCode);
		httpResponse.withBody(ObjectMapperUtils.toJson(mockServerDummyResponse));

		mockServerClient
		.when(
			HttpRequest.request()
				.withMethod(method)
				.withPath(remotePathSuffix))
			.respond(httpResponse);

		MockHttpServletRequestBuilder request = get(LOCAL_URL_FROM_APP_PROPS, pathVar1, pathVar2);

		ResultActions ra = performRequestWithRole(request, SecurityGroups.PROXY.getRolesInGroup()[0])
			.andExpect(status().isFailedDependency());

		String rawResponse = ra.andReturn().getResponse().getContentAsString();
		assertTrue(rawResponse != null && !rawResponse.isEmpty());

		ProxyingRestClientExceptionDto exDto = mvcOm.getResponseObjectFromResultActions(ra, ProxyingRestClientExceptionDto.class);
		assertEquals(ProxyingRestClientException.class.getSimpleName(), exDto.getError());
		assertEquals(method, exDto.getProxiedMethod());
		assertEquals("There was a problem when making a proxying request. Details:409 Conflict", exDto.getMessage());
		assertEquals(remoteStatusCode, exDto.getProxiedHttpStatus());
		assertTrue(exDto.getProxiedUrl().endsWith(remotePathSuffix));


		MockServerDummyResponse serializedDummyResponse = ObjectMapperUtils.fromJson(exDto.getProxiedResponseBody(), MockServerDummyResponse.class);
		assertEquals(mockServerDummyResponse.getHappy(), serializedDummyResponse.getHappy());
		assertEquals(mockServerDummyResponse.getResult(), serializedDummyResponse.getResult());
	}

	@Test
	public void test_remote_request_with_configs_from_app_props() throws Exception {
		String id1 = "1";
		String id2 = "2";

		mockRemoteServer(HttpMethod.GET.toString(), "/1/2");

		MockHttpServletRequestBuilder request = get(LOCAL_URL_FROM_APP_PROPS, id1, id2);

		verifyResponse(request);
	}

	@Test
	public void test_remote_request_with_configs_from_app_props_with_p12() throws Exception {
		String id1 = "1";
		String id2 = "2";

		mockRemoteServer(HttpMethod.POST.toString(), "/1/2");

		MockHttpServletRequestBuilder request = post(LOCAL_URL_FROM_APP_PROPS, id1, id2);

		verifyResponse(request);
	}

	@Test
	public void test_remote_request_with_configs_from_db_with_truststore() throws Exception {
		String id1 = "1";

		mockRemoteServer(HttpMethod.GET.toString(), "/1");

		MockHttpServletRequestBuilder request = get(LOCAL_URL_FROM_DB_WITH_TRUSTSTORE, id1);

		verifyResponse(request);
	}

	@Test
	public void test_remote_request_with_configs_from_db_without_truststore() throws Exception {

		mockRemoteServer(HttpMethod.GET.toString(), "");

		MockHttpServletRequestBuilder request = get(LOCAL_URL_FROM_DB_WITHOUT_TRUSTSTORE);

		verifyResponse(request);
	}

	@Test
	public void test_remote_request_with_configs_from_db_without_ssl() throws Exception {

		mockRemoteServer(HttpMethod.POST.toString(), "");

		MockHttpServletRequestBuilder request = post(LOCAL_URL_FROM_DB_WITHOUT_TRUSTSTORE);

		verifyResponse(request);
	}

	@Test
	public void test_remote_request_with_configs_from_db_with_basic_auth() throws Exception {
		MockHttpServletRequestBuilder request = put(LOCAL_URL_FROM_DB_WITHOUT_TRUSTSTORE);

		mockRemoteServerWithBasicAuth(HttpMethod.PUT.toString(), "", RestProxyingUtil.BASIC_AUTH_USERNAME,
				RestProxyingUtil.BASIC_AUTH_PASSWORD + "suffixToMakePasswordWrong");

		performRequestWithRole(request, SecurityGroups.PROXY.getRolesInGroup()[0])
			.andExpect(status().isFailedDependency());


		mockRemoteServerWithBasicAuth(HttpMethod.PUT.toString(), "", RestProxyingUtil.BASIC_AUTH_USERNAME,
				RestProxyingUtil.BASIC_AUTH_PASSWORD);



		verifyResponse(request);
	}

	@Test
	public void testMaxCachePeriod() throws Exception {

		mockRemoteServer(HttpMethod.GET.toString(), "/1");

		MockHttpServletRequestBuilder request = get(LOCAL_URL_FROM_DB_WITH_TRUSTSTORE, "1");
		request.header(CacheService.CACHE_FIRST_PERIOD_FROM_HEADER_NAME, CacheService.CACHE_MAX_PERIOD_HOURS);

		ResultActions ra = performRequestWithRole(request, SecurityGroups.PROXY.getRolesInGroup()[0]);
		ra.andExpect(status().isOk());


		request = get(LOCAL_URL_FROM_DB_WITH_TRUSTSTORE, "1");
		request.header(CacheService.CACHE_FIRST_PERIOD_FROM_HEADER_NAME, CacheService.CACHE_MAX_PERIOD_HOURS + 1);
		ra = performRequestWithRole(request, SecurityGroups.PROXY.getRolesInGroup()[0]);
		ra.andExpect(status().is(409));
		ApplicationExceptionDto resp = mvcOm.getResponseObjectFromResultActions(ra, ApplicationExceptionDto.class);
		assertEquals(ApplicationException.class.getSimpleName(), resp.getError());
		assertTrue(resp.getMessage().indexOf(Integer.toString(CacheService.CACHE_MAX_PERIOD_HOURS)) > -1);

	}

	private void mockRemoteServer(String method, String path) {
		mockServerClient
			.when(
				HttpRequest.request()
					.withMethod(method)
					.withPath(path))
			.respond(
				HttpResponse.response()
					.withStatusCode(HttpStatus.OK.value())
					.withContentType(MediaType.APPLICATION_JSON)
					.withBody(json(MOCK_SERVER_RESPONSE)));
	}

	private void mockRemoteServerWithBasicAuth(String method, String path, String username, String password) {
		mockServerClient
			.when(
				HttpRequest.request()
					.withMethod(method)
					.withPath(path)
					.withHeader(getBasicAuthHeader(username, password)))
			.respond(
				HttpResponse.response()
					.withStatusCode(HttpStatus.OK.value())
					.withContentType(MediaType.APPLICATION_JSON)
					.withBody(json(MOCK_SERVER_RESPONSE)));
	}

	private void verifyResponse(MockHttpServletRequestBuilder request) throws Exception {

		ResultActions ra = performRequestWithRole(request, SecurityGroups.PROXY.getRolesInGroup()[0]);
		ra.andExpect(status().isOk());

		MockHttpServletResponse response = ra.andReturn().getResponse();
		String respContent = response.getContentAsString();

		assertEquals(MOCK_SERVER_RESPONSE, respContent);
	}

	private ProxyRequestDetails getProxyRequestDetailsWithTrustStore() throws IOException {
		return RestProxyingUtil.getSSLRequestDetails(LOCAL_URL_FROM_DB_WITH_TRUSTSTORE, mockServer.getEndpoint(),
				HttpMethod.GET, true, true, false);
	}

	private ProxyRequestDetails getProxyRequestDetailsWithoutTrustStore() throws IOException {
		return RestProxyingUtil.getSSLRequestDetails(LOCAL_URL_FROM_DB_WITHOUT_TRUSTSTORE, mockServer.getEndpoint(),
				HttpMethod.GET, true, false, false);
	}

	private ProxyRequestDetails getProxyRequestDetailsWithoutSSL() throws IOException {
		return RestProxyingUtil.getSSLRequestDetails(LOCAL_URL_FROM_DB_WITHOUT_TRUSTSTORE, mockServer.getEndpoint(),
				HttpMethod.POST, false, false, false);
	}

	private ProxyRequestDetails getProxyRequestDetailsWithBasicAuth() throws IOException {
		return RestProxyingUtil.getSSLRequestDetails(LOCAL_URL_FROM_DB_WITHOUT_TRUSTSTORE, mockServer.getEndpoint(),
				HttpMethod.PUT, false, false, true);
	}

	private Header getBasicAuthHeader(String username, String password) {

		Charset charset = StandardCharsets.ISO_8859_1;

		String credentialsString = username + ":" + password;
		byte[] encodedBytes = Base64.getEncoder().encode(credentialsString.getBytes(charset));
		String encodedCredentials = new String(encodedBytes, charset);

		String basicAuthHeaderValue = "Basic " + encodedCredentials;

		return new Header(HttpHeaders.AUTHORIZATION, new String[] {basicAuthHeaderValue});
	}

	public static class MockServerDummyResponse {
		private String result;
		private String happy;

		public String getResult() {
			return result;
		}

		public void setResult(String result) {
			this.result = result;
		}

		public String getHappy() {
			return happy;
		}

		public void setHappy(String happy) {
			this.happy = happy;
		}

	}
}
