package bg.demax.iaaa.gateway.controller;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.web.client.RestTemplate;

import bg.demax.iaaa.gateway.AbstractMvcTest;
import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.controller.params.GraoParams;
import bg.demax.iaaa.gateway.graowsdl.GraoResponse;
import bg.demax.iaaa.gateway.security.SecurityGroups;
import bg.demax.iaaa.gateway.testutils.TestScripts;
import bg.demax.iaaa.gateway.utils.ObjectMapperUtils;

public class GraoControllerTest extends AbstractMvcTest {
	private static final String GRAO_CONTROLLER_ADDRESS = "/api/grao";
	private static final String PERSON_DATA_ADDRESS = GRAO_CONTROLLER_ADDRESS + "/person";

	private static final String GRAO_RESP_FILE_PATH = "static/grao_response.xml";

	@MockBean
	@Qualifier(BeanQualifiers.GRAO_REST_TEMPLATE)
	private RestTemplate graoRt;

	@Value("${grao.address}")
	private String graoAddress;

	@Test
	public void testGetGraoResponse_permissions() throws Exception {

		MockHttpServletRequestBuilder request = get(PERSON_DATA_ADDRESS);

		testRequestPermissions(request, SecurityGroups.GENERIC, status().isBadRequest(),
				status().isForbidden());
	}

	@Test
	public void testGetGraoResponse() throws Exception {

		Mockito.when(graoRt.postForObject(Mockito.eq(this.graoAddress), Mockito.any(), Mockito.eq(String.class)))
			.thenReturn(TestScripts.readFile(GRAO_RESP_FILE_PATH));

		GraoParams graoParams = new GraoParams();
		graoParams.setEgn("6101047500");
		MockHttpServletRequestBuilder request = get(PERSON_DATA_ADDRESS);
		request.params(ObjectMapperUtils.toParams(graoParams));

		ResultActions ra = performRequestWithRole(request, SecurityGroups.GENERIC.getRolesInGroup()[0]);
		ra.andExpect(status().isOk());
		GraoResponse graoResponse = mvcOm.getResponseObjectFromResultActions(ra, GraoResponse.class);

		assertEquals("БУЛ.ВАСИЛ АПРИЛОВ", graoResponse.getPerson().getResidenceAddress().getStreet().getText());
	}

}
