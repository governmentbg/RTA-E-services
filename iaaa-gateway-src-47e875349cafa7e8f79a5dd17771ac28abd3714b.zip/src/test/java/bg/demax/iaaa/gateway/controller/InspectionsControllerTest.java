package bg.demax.iaaa.gateway.controller;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.util.MultiValueMap;

import bg.demax.iaaa.gateway.AbstractMvcTest;
import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;
import bg.demax.iaaa.gateway.controller.params.InspectionParams;
import bg.demax.iaaa.gateway.controller.params.InspectionParamsLight;
import bg.demax.iaaa.gateway.dto.HistoryInspectionDto;
import bg.demax.iaaa.gateway.dto.LastInspectionDto;
import bg.demax.iaaa.gateway.dto.MalfunctionDto;
import bg.demax.iaaa.gateway.dto.ValidInspectionResponse;
import bg.demax.iaaa.gateway.security.SecurityGroups;
import bg.demax.iaaa.gateway.security.SecurityRole;
import bg.demax.iaaa.gateway.security.SecurityUtilService;
import bg.demax.iaaa.gateway.testutils.TestScripts;
import bg.demax.iaaa.gateway.utils.ObjectMapperUtils;

public class InspectionsControllerTest extends AbstractMvcTest {

	private static final String INSPECTIONS_ENDPOINT = "/api/vehicles/inspections";
	private static final String INSPECTIONS_LAST_VALID_ENDPOINT = INSPECTIONS_ENDPOINT + "/last/valid";
	private static final String INSPECTIONS_LAST_ENDPOINT = INSPECTIONS_ENDPOINT + "/last";
	private static final String INSPECTIONS_HISTORY_ENDPOINT = INSPECTIONS_ENDPOINT + "/history";

	private static final String VALID_INSPECTION_VIN = "TESTVIN1234567890";
	private static final String VALID_INSPECTION_FRAME = "TESTFRAME1234567892";
	private static final Long STICKER_NUM = 201120112011L;

	@MockBean
	private SecurityUtilService securityUtilService;

	@Before
	public void initSetup() {
		sqlScriptExecutor.execute(TestScripts.INSPECTION_DEPENDENCIES, BeanQualifiers.IAAA_IMG_DATASOURCE);
	}

	/*
	 * TESTS FOR ENDPOINT "/api/inspection/valid"
	 */

	@Test
	public void checkForValidInspection_test_authentication_permissions() throws Exception {
		InspectionParams params = new InspectionParams();
		params.setVin("TMBMS46Y864551234");

		MockHttpServletRequestBuilder request = get(INSPECTIONS_LAST_VALID_ENDPOINT);
		request.params(ObjectMapperUtils.toParams(params));

		mockMvc.perform(request).andExpect(status().isForbidden());
		testRequestPermissions(request, SecurityGroups.INSPECTIONS, status().is2xxSuccessful(),
				status().isForbidden());
	}

	@Test
	public void checkForValidInspection_test_invalid_params() throws Exception {
		InspectionParams params = new InspectionParams();

		MockHttpServletRequestBuilder request = get(INSPECTIONS_LAST_VALID_ENDPOINT);
		request.params(ObjectMapperUtils.toParams(params));

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isBadRequest());
	}

	@Test
	public void checkForValidInspection_test_valid_inspection_found() throws Exception {
		InspectionParams params = new InspectionParams();
		params.setVin(VALID_INSPECTION_VIN);
		params.setStickerNum(STICKER_NUM);
		params.setValidUponDateTime(LocalDateTime.of(2018, 8, 12, 0, 0));

		MockHttpServletRequestBuilder request = get(INSPECTIONS_LAST_VALID_ENDPOINT);
		MultiValueMap<String, String> paramsMap = ObjectMapperUtils.toParams(params);
		paramsMap.set("validUponDateTime", convertLocalDateTimeToFormattedString(params.getValidUponDateTime()));
		request.params(paramsMap);

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isOk());
	}

	@Test
	public void checkForValidInspection_test_valid_inspection_not_found() throws Exception {
		InspectionParams params = new InspectionParams();
		params.setVin("TMBMS46Y864551234");

		MockHttpServletRequestBuilder request = get(INSPECTIONS_LAST_VALID_ENDPOINT);
		request.params(ObjectMapperUtils.toParams(params));

		ResultActions ra = performRequestWithRole(request, SecurityRole.GENERIC_USER);
		ra.andExpect(status().isOk());
		ValidInspectionResponse validInspectionResponse = mvcOm.getResponseObjectFromResultActions(ra, ValidInspectionResponse.class);
		assertEquals(false, validInspectionResponse.getHasValidInspection());
	}

	/*
	 * TESTS FOR ENDPOINT "/api/inspection/last"
	 */

	@Test
	public void getLastInspection_test_authentication_permissions() throws Exception {
		InspectionParamsLight params = new InspectionParamsLight();
		params.setVin("TMBMS46Y864551234");

		MockHttpServletRequestBuilder request = get(INSPECTIONS_LAST_ENDPOINT);
		request.params(ObjectMapperUtils.toParams(params));

		mockMvc.perform(request).andExpect(status().isForbidden());
		testRequestPermissions(request, SecurityGroups.INSPECTIONS, status().is2xxSuccessful(),
				status().isForbidden());
	}

	@Test
	public void getLastInspection_test_invalid_params() throws Exception {
		InspectionParamsLight params = new InspectionParamsLight();

		MockHttpServletRequestBuilder request = get(INSPECTIONS_LAST_ENDPOINT);
		request.params(ObjectMapperUtils.toParams(params));

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isBadRequest());
	}

	@Test
	public void getLastInspection_test_valid_inspection_found() throws Exception {
		InspectionParamsLight params = new InspectionParamsLight();
		params.setVin(VALID_INSPECTION_VIN);
		params.setRegNum("CA8124PE");

		MockHttpServletRequestBuilder request = get(INSPECTIONS_LAST_ENDPOINT);
		request.params(ObjectMapperUtils.toParams(params));

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isOk());

		LastInspectionDto lastInspectionDto = mvcOm.getResponseObjectFromRequest(request, LastInspectionDto.class);
		assertEquals(4L, lastInspectionDto.getId().longValue());
		assertEquals(6, lastInspectionDto.getMalfunctions().size());
		MalfunctionDto malfunction = lastInspectionDto.getMalfunctions().get(0);
		assertEquals("0.2б)", malfunction.getCode());
		assertEquals("Непълен, нечетлив", malfunction.getDescription());
		assertEquals("ЗП", malfunction.getCardinality().getCode());
		assertEquals("IA", lastInspectionDto.getConclusion().getCode());
		assertEquals("АСЕНОВГРАД ШЕСТА № 473", lastInspectionDto.getPermit().getAddress());
		assertEquals("5002122541", lastInspectionDto.getPermit().getCompanyEik());
		assertEquals("ТОНИ ДИМИТРОВ", lastInspectionDto.getVehPresentingPerson().getNames());
	}

	@Test
	public void getLastInspection_test_valid_inspection_by_reg_num_not_found() throws Exception {
		InspectionParamsLight params = new InspectionParamsLight();
		params.setRegNum("C4444PE");

		MockHttpServletRequestBuilder request = get(INSPECTIONS_LAST_ENDPOINT);
		request.params(ObjectMapperUtils.toParams(params));

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isNoContent());
	}

	@Test
	public void getLastInspection_test_valid_inspection_by_vin_not_found() throws Exception {
		InspectionParamsLight params = new InspectionParamsLight();
		params.setVin("TMBMS46Y864551234");

		MockHttpServletRequestBuilder request = get(INSPECTIONS_LAST_ENDPOINT);
		request.params(ObjectMapperUtils.toParams(params));

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isNoContent());
	}

	/*
	 * TESTS FOR ENDPOINT "/api/inspection/history"
	 */

	@Test
	public void filterInspections_test_authentication_permissions() throws Exception {
		InspectionParamsLight params = new InspectionParamsLight();
		params.setVin("TMBMS46Y864551234");

		MockHttpServletRequestBuilder request = get(INSPECTIONS_HISTORY_ENDPOINT);
		request.params(ObjectMapperUtils.toParams(params));

		mockMvc.perform(request).andExpect(status().isForbidden());
		testRequestPermissions(request, SecurityGroups.INSPECTIONS, status().is2xxSuccessful(),
				status().isForbidden());
	}

	@Test
	public void filterInspections_test_invalid_params() throws Exception {
		InspectionParamsLight params = new InspectionParamsLight();

		MockHttpServletRequestBuilder request = get(INSPECTIONS_HISTORY_ENDPOINT);
		request.params(ObjectMapperUtils.toParams(params));

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isBadRequest());
	}

	@Test
	public void filterInspections_test_valid_inspection_found_by_vin() throws Exception {
		InspectionParamsLight params = new InspectionParamsLight();
		String vin = "TESTVIN1234567892";
		params.setVin(vin);

		MockHttpServletRequestBuilder request = get(INSPECTIONS_HISTORY_ENDPOINT);
		request.params(ObjectMapperUtils.toParams(params));

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isOk());

		List<HistoryInspectionDto> filteredInspections = mvcOm.getListFromResultActions(
				performRequestWithRole(request, SecurityRole.GENERIC_USER), HistoryInspectionDto.class);

		assertEquals(3, filteredInspections.size());
		for (HistoryInspectionDto insp : filteredInspections) {
			assertEquals(vin, insp.getVehicle().getVin());
			assertEquals(121, insp.getPermit().getNumber().intValue());
		}
	}

	@Test
	public void filterInspections_test_valid_inspection_found_by_frame_number() throws Exception {
		InspectionParamsLight params = new InspectionParamsLight();
		params.setVin(VALID_INSPECTION_FRAME);

		MockHttpServletRequestBuilder request = get(INSPECTIONS_HISTORY_ENDPOINT);
		request.params(ObjectMapperUtils.toParams(params));

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isOk());

		List<HistoryInspectionDto> filteredInspections = mvcOm.getListFromResultActions(
				performRequestWithRole(request, SecurityRole.GENERIC_USER), HistoryInspectionDto.class);

		assertEquals(1, filteredInspections.size());
		HistoryInspectionDto inspectionDto = filteredInspections.get(0);
		assertEquals(VALID_INSPECTION_FRAME, inspectionDto.getVehicle().getVin());
	}

	@Test
	public void filterInspections_test_valid_inspection_found_by_vin_and_reg_num() throws Exception {
		InspectionParamsLight params = new InspectionParamsLight();
		String vin = "TESTVIN1234567892";
		String regNum = "CB3223BC";
		params.setVin(vin);
		params.setRegNum(regNum);

		MockHttpServletRequestBuilder request = get(INSPECTIONS_HISTORY_ENDPOINT);
		request.params(ObjectMapperUtils.toParams(params));

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isOk());

		List<HistoryInspectionDto> filteredInspections = mvcOm.getListFromResultActions(
				performRequestWithRole(request, SecurityRole.GENERIC_USER), HistoryInspectionDto.class);

		assertEquals(2, filteredInspections.size());
		for (HistoryInspectionDto insp : filteredInspections) {
			assertEquals(vin, insp.getVehicle().getVin());
			assertEquals(regNum, insp.getVehicle().getRegNum());
			assertEquals(121, insp.getPermit().getNumber().intValue());
		}
	}

	@Test
	public void filterInspections_test_valid_inspection_by_reg_num_not_found_returns_204() throws Exception {
		InspectionParamsLight params = new InspectionParamsLight();
		params.setRegNum("C4444PE");
		params.setVin("11223344556677889");

		MockHttpServletRequestBuilder request = get(INSPECTIONS_HISTORY_ENDPOINT);
		request.params(ObjectMapperUtils.toParams(params));

		ResultActions ra = performRequestWithRole(request, SecurityRole.GENERIC_USER);
		ra.andExpect(status().isNoContent());

		List<HistoryInspectionDto> filteredInspectionDtos = mvcOm.getListFromResultActions(ra,
				HistoryInspectionDto.class);
		assertEquals(0, filteredInspectionDtos.size());

	}

	private String convertLocalDateTimeToFormattedString(LocalDateTime dt) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(IaaaGatewayConstants.DATE_TIME_FORMAT);
		return dt.format(formatter);
	}
}
