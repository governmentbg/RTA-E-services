package bg.demax.iaaa.gateway.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import bg.demax.iaaa.gateway.AbstractMvcTest;
import bg.demax.iaaa.gateway.db.entity.iaaaproxies.ProxyRequestDetails;
import bg.demax.iaaa.gateway.security.SecurityGroups;
import bg.demax.iaaa.gateway.utils.DbImportService;
import bg.demax.iaaa.gateway.utils.RestProxyingUtil;
import bg.demax.iaaa.gateway.utils.notifiers.ProjectSupportNotificationService;

public class RestProxyingRequestConfigControllerTest extends AbstractMvcTest {

	private static final String CONTROLLER_ENDPOINT = "/api/rest-proxying/config";

	private static final String UPDATE_REQUEST_CONFIG_ENDPOINT = CONTROLLER_ENDPOINT + "/{id}";

	@Autowired
	private DbImportService dbImportService;

	@MockBean
	private ProjectSupportNotificationService notificationService;

	@Test
	public void test_permissions() throws Exception {
		String id = "1";

		MockHttpServletRequestBuilder request = put(UPDATE_REQUEST_CONFIG_ENDPOINT, id);

		mockMvc.perform(request).andExpect(status().isForbidden());
		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isConflict(), status().isForbidden());
	}

	@Test
	public void test_updateRestProxyingRequestConfig_notifies_if_app_prop_is_overwritten() throws Exception {
		String localPathFromAppProp = "/api/proxy/auto/test/from/properties/{id1}/{id2}";
		HttpMethod httpMethodFromAppProp = HttpMethod.POST;

		ProxyRequestDetails proxyRequestDetails = RestProxyingUtil
				.getSSLRequestDetails(localPathFromAppProp, "https://111.1.1/new", httpMethodFromAppProp, false, false, false);

		int id = dbImportService.saveProxyRequestDetails(proxyRequestDetails);

		MockHttpServletRequestBuilder request = put(UPDATE_REQUEST_CONFIG_ENDPOINT, id);

		ResultActions ra = performRequestWithRole(request, SecurityGroups.FULL_ACCESS.getRolesInGroup()[0]);
		ra.andExpect(status().isOk());

		Mockito.verify(notificationService).notify(Mockito.anyString());
	}

}
