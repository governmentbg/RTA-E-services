package bg.demax.iaaa.gateway.converter;

import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import bg.demax.iaaa.gateway.AbstractContextTest;
import bg.demax.iaaa.gateway.converters.InspectionToFilteredInspectionDtoConverter;
import bg.demax.iaaa.gateway.dto.HistoryInspectionDto;
import bg.demax.iaaa.gateway.dto.VehicleForFilteredInspectionDto;
import bg.demax.iaaa.gateway.testutils.MockObjectsUtil;
import bg.demax.techinsp.entity.Inspection;

public class InspectionToFilteredInspectionConverterTest extends AbstractContextTest {

	@Autowired
	private InspectionToFilteredInspectionDtoConverter inspFilteredConverter;

	@Test
	public void convertInspectionToValidInspectionDto_test() throws Exception {

		Inspection from = MockObjectsUtil.getInspection();

		HistoryInspectionDto dto = inspFilteredConverter.convert(from);

		assertEquals(1234L, dto.getId().longValue());
		assertEquals(201120112011L, dto.getStickerNum().longValue());
		assertEquals(LocalDateTime.of(2020, 02, 02, 11, 0, 0), dto.getEndDateTime());

		VehicleForFilteredInspectionDto vehicle = dto.getVehicle();

		assertEquals("TEST1231231231234", vehicle.getVin());
		assertEquals("CB0000AK", vehicle.getRegNum());
		assertEquals(56000, vehicle.getMileage().intValue());
		assertEquals(222, dto.getPermit().getNumber().intValue());

		from.getRoadVehicle().setVin(null);
		from.getRoadVehicle().setFrameNumber("FRAME_NUMBER");

		dto = inspFilteredConverter.convert(from);

		assertEquals("FRAME_NUMBER", dto.getVehicle().getVin());
	}
}
