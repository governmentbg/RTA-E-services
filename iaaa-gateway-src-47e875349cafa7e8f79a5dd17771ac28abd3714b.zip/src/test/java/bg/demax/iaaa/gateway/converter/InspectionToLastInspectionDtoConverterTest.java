package bg.demax.iaaa.gateway.converter;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import bg.demax.iaaa.gateway.AbstractContextTest;
import bg.demax.iaaa.gateway.converters.InspectionToLastInspectionDtoConverter;
import bg.demax.iaaa.gateway.dto.LastInspectionDto;
import bg.demax.iaaa.gateway.dto.MalfunctionDto;
import bg.demax.iaaa.gateway.dto.NomenclatureDto;
import bg.demax.iaaa.gateway.dto.PermitDto;
import bg.demax.iaaa.gateway.dto.VehicleDto;
import bg.demax.iaaa.gateway.dto.VehiclePresentingPerson;
import bg.demax.iaaa.gateway.testutils.MockObjectsUtil;
import bg.demax.techinsp.entity.Inspection;
import bg.demax.techinsp.entity.InspectionCheckValue;
import bg.demax.techinsp.entity.InspectionElementCardinality;

public class InspectionToLastInspectionDtoConverterTest extends AbstractContextTest {

	@Autowired
	private InspectionToLastInspectionDtoConverter inspValidConverter;

	@Test
	public void convertInspectionToLastInspectionDto_test() throws Exception {

		Inspection from = MockObjectsUtil.getInspection();

		LastInspectionDto dto = inspValidConverter.convert(from);

		assertEquals(1234L, dto.getId().longValue());
		assertEquals(201120112011L, dto.getStickerNum().longValue());
		assertEquals(LocalDateTime.of(2020, 02, 02, 11, 0, 0), dto.getEndDateTime());
		assertEquals(LocalDate.of(2021, 2, 1), dto.getNextInspectionDate());

		VehicleDto vehicle = dto.getVehicle();

		assertEquals("TEST1231231231234", vehicle.getVin());
		from.getRoadVehicle().setVin(null);
		from.getRoadVehicle().setFrameNumber("FRAME_NUMBER");

		dto = inspValidConverter.convert(from);

		assertEquals("FRAME_NUMBER", dto.getVehicle().getVin());

		assertEquals("CB0000AK", vehicle.getRegNum());
		assertEquals("M1", vehicle.getCategory());
		assertEquals(LocalDate.of(2005, 5, 1), vehicle.getFirstRegistrationDate());
		assertEquals("Make", vehicle.getvMake());
		assertEquals(56000, dto.getVehicle().getMileage().intValue());

		NomenclatureDto conclustion = dto.getConclusion();

		assertEquals("IA", conclustion.getCode());
		assertEquals("Допуска се за движение", conclustion.getDescription());

		List<MalfunctionDto> malfunctions = dto.getMalfunctions();

		for (MalfunctionDto malf : malfunctions) {

			assertEquals(InspectionCheckValue.Y, malf.getCheckValue());
			assertEquals(InspectionElementCardinality.DANGEROUS_DAMAGE.getDescription(),
					malf.getCardinality().getDescription());
			assertEquals(InspectionElementCardinality.DANGEROUS_DAMAGE.getCardinality(),
					malf.getCardinality().getCode());
		}

		PermitDto permit = dto.getPermit();

		assertEquals(222, permit.getNumber().intValue());
		assertEquals("Full Name", permit.getCompanyName());
		assertEquals("130460283", permit.getCompanyEik());
		assertEquals("Sofia Vitoha str 1", permit.getAddress());

		VehiclePresentingPerson person = dto.getVehPresentingPerson();

		assertEquals("5612124512", person.getEgn());
		assertEquals("Person Name", person.getNames());
	}
}
