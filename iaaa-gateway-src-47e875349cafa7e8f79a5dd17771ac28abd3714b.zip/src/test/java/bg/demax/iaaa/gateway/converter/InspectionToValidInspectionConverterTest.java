package bg.demax.iaaa.gateway.converter;

import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import bg.demax.iaaa.gateway.AbstractContextTest;
import bg.demax.iaaa.gateway.converters.InspectionToValidInspectionDtoConverter;
import bg.demax.iaaa.gateway.dto.ValidInspectionDto;
import bg.demax.iaaa.gateway.testutils.MockObjectsUtil;
import bg.demax.techinsp.entity.Inspection;
import bg.demax.techinsp.entity.InspectionType;

public class InspectionToValidInspectionConverterTest extends AbstractContextTest {

	@Autowired
	private InspectionToValidInspectionDtoConverter inspValidConverter;

	@Test
	public void convertInspectionToValidInspectionDto_test() throws Exception {

		Inspection from = MockObjectsUtil.getInspection();

		ValidInspectionDto dto = inspValidConverter.convert(from);

		assertEquals(1234L, dto.getId().longValue());
		assertEquals(LocalDateTime.of(2020, 02, 02, 11, 0, 0), dto.getEndDateTime());
		assertEquals(InspectionType.CODE_VEHICLE, dto.getType());
		assertEquals("M1", dto.getCategory());
	}
}
