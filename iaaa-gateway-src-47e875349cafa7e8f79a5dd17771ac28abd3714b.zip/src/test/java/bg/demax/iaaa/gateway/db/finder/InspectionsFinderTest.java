package bg.demax.iaaa.gateway.db.finder;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.time.LocalDateTime;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.iaaa.gateway.AbstractRepositoryTest;
import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.db.finder.InspectionsFinder;
import bg.demax.iaaa.gateway.search.InspectionSearch;
import bg.demax.iaaa.gateway.testutils.TestScripts;
import bg.demax.techinsp.entity.Inspection;

@Transactional(value = BeanQualifiers.IAAA_IMG_TRANSACTION_MANAGER)
public class InspectionsFinderTest extends AbstractRepositoryTest {

	@Autowired
	private InspectionsFinder inspectionsFinder;

	@Before
	public void init() {
		sqlScriptExecutor.execute(TestScripts.INSPECTION_DEPENDENCIES, BeanQualifiers.IAAA_IMG_DATASOURCE);
	}

	/*
	 * TESTS FOR "findValidInspection"
	 */

	@Test
	public void findValidInspectionTest__OK() {
		InspectionSearch search = new InspectionSearch();
		search.setRegNum("CA8124PE");
		search.setVin("TESTVIN1234567890");
		search.setValidUponDateTime(LocalDateTime.of(2018, 8, 12, 0, 0));

		Inspection inspection = inspectionsFinder.findBySearchParams(search);

		assertTrue(inspection != null);
	}

	@Test
	public void findValidInspectionTest__OK_When_There_Are_Many_Inspections_We_Get_Latest_One() {
		InspectionSearch search = new InspectionSearch();
		search.setRegNum("CA8124PE");
		search.setVin("TESTVIN1234567890");
		search.setValidUponDateTime(LocalDateTime.of(2018, 8, 12, 0, 0));

		Inspection inspection = inspectionsFinder.findBySearchParams(search);

		assertTrue(inspection.getRoadVehicleVersion().getId() == 4);
	}

	@Test
	public void findValidInspectionTest__No_Valid_Inspections_Towards_Requested_Date() {
		InspectionSearch search = new InspectionSearch();
		search.setRegNum("CA8124PE");
		search.setValidUponDateTime(LocalDateTime.of(2019, 8, 12, 0, 0));

		Inspection inspection = inspectionsFinder.findBySearchParams(search);

		assertTrue(inspection == null);
	}

	@Test
	public void findValidInspectionTest__No_Such_VIN() {
		InspectionSearch search = new InspectionSearch();
		search.setRegNum("CA8124PE");
		search.setVin("NO_SUCH_VIN_12345");
		search.setValidUponDateTime(LocalDateTime.of(2018, 8, 12, 0, 0));

		Inspection inspection = inspectionsFinder.findBySearchParams(search);

		assertTrue(inspection == null);
	}

	@Test
	public void findValidInspectionTest__Inspection_Found_With_Not_Valid_Conclusions_OK() {
		InspectionSearch search = new InspectionSearch();
		search.setRegNum("CA2278BP");
		search.setVin("TESTVIN1234567892");
		search.setValidUponDateTime(LocalDateTime.of(2018, 8, 12, 0, 0));

		Inspection inspection = inspectionsFinder.findBySearchParams(search);

		assertTrue(inspection != null);
	}

	/*
	 * TESTS FOR "getLastInspection"
	 */

	@Test
	public void getLastInspectionTest__OK() {
		InspectionSearch search = new InspectionSearch();
		search.setVin("TESTVIN1234567890");

		Inspection inspection = inspectionsFinder.findBySearchParams(search);

		assertTrue(inspection != null);
		assertTrue(inspection.getInspectionChecks() != null);
		assertEquals(7, inspection.getInspectionChecks().size());
	}
}