package bg.demax.iaaa.gateway.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.iaaa.gateway.AbstractRepositoryTest;
import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.config.db.CacheDbTablenames;
import bg.demax.iaaa.gateway.controller.params.InspectionParamsLight;
import bg.demax.iaaa.gateway.converters.InspectionToLastInspectionDtoConverter;
import bg.demax.iaaa.gateway.db.repository.CacheRepository;
import bg.demax.iaaa.gateway.dto.LastInspectionDto;
import bg.demax.iaaa.gateway.dto.cache.CacheEntry;
import bg.demax.iaaa.gateway.security.SecurityUtilService;
import bg.demax.iaaa.gateway.security.UserDto;
import bg.demax.iaaa.gateway.testutils.MockObjectsUtil;

public class CacheRepositoryTest extends AbstractRepositoryTest {

	public static final Integer HOURS_BACK = 5;

	@Autowired
	private CacheRepository cacheRepository;

	@MockBean
	private SecurityUtilService securityUtilService;

	@Autowired
	@Qualifier(BeanQualifiers.CACHE_OBJECT_MAPPER)
	private ObjectMapper postgreJsonMapper;

	@Autowired
	private InspectionToLastInspectionDtoConverter inspLastConverter;

	@Test
	public void testLogCacheToDb() throws Exception {
		CacheEntry<InspectionParamsLight, LastInspectionDto> cache = buildCacheEntry();
		InspectionParamsLight request = cache.getRequest();
		LastInspectionDto response = cache.getResponse();

		cacheRepository.logCacheToDb(cache, CacheDbTablenames.INSPECTIONS_LAST_VALID);

		String queryString = String.format("SELECT * FROM %s.%s", CacheDbTablenames.CACHE_SCHEMA,
				CacheDbTablenames.INSPECTIONS_LAST_VALID);
		String result = sqlScriptExecutor.executeSQLQuery(queryString, BeanQualifiers.IAAA_PROXIES_DATASOURCE);

		CacheEntry<?, ?> deserializedCacheEntry = postgreJsonMapper.readValue(result, CacheEntry.class);
		LastInspectionDto deserializedResponse = postgreJsonMapper.convertValue(deserializedCacheEntry.getResponse(),
				LastInspectionDto.class);
		InspectionParamsLight deserializedRequest = postgreJsonMapper.convertValue(deserializedCacheEntry.getRequest(),
				InspectionParamsLight.class);

		assertNotNull(deserializedCacheEntry);

		assertEquals(request.getRegNum(), deserializedRequest.getRegNum());
		assertEquals(request.getVin(), deserializedRequest.getVin());

		assertEquals(response.getConclusion().getCode(), deserializedResponse.getConclusion().getCode());
		assertEquals(response.getConclusion().getDescription(), deserializedResponse.getConclusion().getDescription());

		String responseDateTime = getFormattedDate(response);
		String deserializedresponseDateTime = getFormattedDate(deserializedResponse);

		assertEquals(responseDateTime, deserializedresponseDateTime);

	}

	@Test
	public void testGetCacheFromDb_OK() throws Exception {
		CacheEntry<InspectionParamsLight, LastInspectionDto> cache = buildCacheEntry();
		cache.setResponse(null);

		cacheRepository.logCacheToDb(cache, CacheDbTablenames.INSPECTIONS_LAST_VALID);

		CacheEntry<InspectionParamsLight, LastInspectionDto> deserializedCacheEntry = cacheRepository
				.getCacheFromDb(cache.getRequest(), CacheDbTablenames.INSPECTIONS_LAST_VALID, HOURS_BACK);

		assertNotNull(deserializedCacheEntry);
	}

	@Test
	public void testGetCacheFromDb_Has_Error_Msg() throws Exception {
		CacheEntry<InspectionParamsLight, LastInspectionDto> cache = buildCacheEntry();
		cache.setError("Error has occur");

		cacheRepository.logCacheToDb(cache, CacheDbTablenames.INSPECTIONS_LAST_VALID);

		CacheEntry<InspectionParamsLight, LastInspectionDto> deserializedCacheEntry = cacheRepository
				.getCacheFromDb(cache.getRequest(), CacheDbTablenames.INSPECTIONS_LAST_VALID, HOURS_BACK);

		assertNull(deserializedCacheEntry);
	}

	@Test
	public void testGetCacheFromDb_Same_Request_Different_User() throws Exception {
		CacheEntry<InspectionParamsLight, LastInspectionDto> cache = buildCacheEntry();

		cacheRepository.logCacheToDb(cache, CacheDbTablenames.INSPECTIONS_LAST_VALID);

		Mockito.when(securityUtilService.getCurrentUser()).thenReturn(new UserDto());

		CacheEntry<InspectionParamsLight, LastInspectionDto> deserializedCacheEntry = cacheRepository
				.getCacheFromDb(cache.getRequest(), CacheDbTablenames.INSPECTIONS_LAST_VALID, HOURS_BACK);

		assertNull(deserializedCacheEntry);
	}

	private CacheEntry<InspectionParamsLight, LastInspectionDto> buildCacheEntry() {
		UserDto userDto = new UserDto();
		userDto.setUserId(1);
		userDto.setUsername("USERNAME");

		InspectionParamsLight request = new InspectionParamsLight();

		request.setRegNum("CB8215KC");
		request.setVin("11111111112222222");

		LastInspectionDto response = inspLastConverter.convert(MockObjectsUtil.getInspection());
		response.setEndDateTime(LocalDateTime.now());

		Mockito.when(securityUtilService.getCurrentUser()).thenReturn(userDto);

		CacheEntry<InspectionParamsLight, LastInspectionDto> cache = new CacheEntry<InspectionParamsLight, LastInspectionDto>();
		cache.setRequest(request);
		cache.setResponse(response);
		cache.setRequestTime(LocalDateTime.now());

		return cache;
	}

	private String getFormattedDate(Object object) {
		for (Field f : object.getClass().getDeclaredFields()) {
			JsonFormat df = f.getAnnotation(JsonFormat.class);
			if (df != null && f != null) {
				boolean originalAccessability = f.isAccessible();
				f.setAccessible(true);
				LocalDateTime localDateTime = null;
				try {
					localDateTime = (LocalDateTime) f.get(object);
				} catch (IllegalArgumentException | IllegalAccessException e) {
					e.printStackTrace();
				}
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern(df.pattern());
				f.setAccessible(originalAccessability);
				return localDateTime.format(formatter);
			}
		}
		return null;
	}
}