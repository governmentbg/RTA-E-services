package bg.demax.iaaa.gateway.security;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import bg.demax.iaaa.gateway.AbstractMvcTest;
import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.config.WebSecurityConfiguration;
import bg.demax.iaaa.gateway.testutils.TestScripts;

public class AuthenticationTest extends AbstractMvcTest {

	private static final String TEST_AUTHENTICATION_ENDPOINT = "/api/test";
	private static final String VALID_PRE_AUTH_HEADER_VALUE = "mock_key";
	private static final String INVALID_PRE_AUTH_HEADER_VALUE = "invalid_key";

	@Before
	public void init() {
		sqlScriptExecutor.execute(new String[] { TestScripts.USERS, TestScripts.AUTHORITIES, TestScripts.USERS_AUTHORITIES},
				BeanQualifiers.IAAA_IMG_DATASOURCE);
	}

	@Test
	public void testAuthenticationWithValidPreAuthHeaderName() throws Exception {
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get(TEST_AUTHENTICATION_ENDPOINT)
				.header(WebSecurityConfiguration.PRE_AUTH_HEADER_NAME, VALID_PRE_AUTH_HEADER_VALUE);

		mockMvc.perform(request).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void testAuthenticationWithInvalidPreAuthHeaderName() throws Exception {
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get(TEST_AUTHENTICATION_ENDPOINT)
				.header(WebSecurityConfiguration.PRE_AUTH_HEADER_NAME, INVALID_PRE_AUTH_HEADER_VALUE);

		mockMvc.perform(request).andExpect(MockMvcResultMatchers.status().isForbidden());
	}
}
