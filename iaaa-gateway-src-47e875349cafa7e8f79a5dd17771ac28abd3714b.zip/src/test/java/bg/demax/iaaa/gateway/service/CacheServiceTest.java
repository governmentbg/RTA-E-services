package bg.demax.iaaa.gateway.service;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.List;
import java.util.concurrent.Callable;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;

import com.fasterxml.jackson.core.type.TypeReference;

import bg.demax.iaaa.gateway.db.repository.CacheRepository;
import bg.demax.iaaa.gateway.dto.cache.CacheEntry;
import bg.demax.iaaa.gateway.exception.ApplicationException;

@RunWith(MockitoJUnitRunner.class)
public class CacheServiceTest {

	@InjectMocks
	private CacheService cacheService;

	@Mock
	private CacheRepository cacheRepository;

	@Test
	public void testSmartCache_cacheProperties() throws Exception {
		Integer firstCachePeriodInHours = 2;
		Integer secondCachePeriodInHours = 24;
		String cacheTable = "cacheTable";
		String exceptionMsg = "Custom exception message here.";

		Object request = new Object();

		HttpHeaders headers = new HttpHeaders();
		headers.add(CacheService.CACHE_FIRST_PERIOD_FROM_HEADER_NAME, Integer.toString(firstCachePeriodInHours));
		headers.add(CacheService.CACHE_SECOND_PERIOD_FROM_HEADER_NAME, Integer.toString(secondCachePeriodInHours));

		Mockito.when(cacheRepository.getCacheFromDb(Mockito.eq(request), Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(null);

		Callable<String> mockCallable = new Callable<String>() {
			@Override
			public String call() throws CustomCallableException {
				if (firstCachePeriodInHours == 2) {
					throw new CustomCallableException(exceptionMsg);
				}
				return "Not reaching here!";

			}
		};

		ArgumentCaptor<CacheEntry<?, ?>> errorMsgCaptor = ArgumentCaptor.forClass(CacheEntry.class);

		assertThatExceptionOfType(CustomCallableException.class).isThrownBy(() -> {
			cacheService.smartCache(mockCallable, request, headers, cacheTable, new TypeReference<List<String>>() {
			});
		});

		Mockito.verify(cacheRepository, Mockito.times(1)).logCacheToDb(errorMsgCaptor.capture(),
				Mockito.eq(cacheTable));

		assertEquals(exceptionMsg, errorMsgCaptor.getValue().getError());

		Mockito.verify(cacheRepository, Mockito.times(1)).getCacheFromDb(Mockito.any(), Mockito.eq(cacheTable),
				Mockito.eq(firstCachePeriodInHours));

		Mockito.verify(cacheRepository, Mockito.times(1)).getCacheFromDb(request, cacheTable, secondCachePeriodInHours);

	}

	@Test
	public void testSmartCache_WhenResponseFromCacheIsNullAndNoErrorsFoundWeReturnNull() throws Exception {
		Integer firstCachePeriodInHours = 2;

		HttpHeaders headers = new HttpHeaders();
		headers.add(CacheService.CACHE_FIRST_PERIOD_FROM_HEADER_NAME, Integer.toString(firstCachePeriodInHours));

		CacheEntry<Object, Object> cache = new CacheEntry<Object, Object>();
		cache.setRequest(new Object());
		cache.setResponse(null);

		Mockito.when(cacheRepository.getCacheFromDb(Mockito.any(), Mockito.anyString(), Mockito.anyInt()))
				.thenReturn(cache);

		Callable<String> mockCallable = new Callable<String>() {
			@Override
			public String call() throws CustomCallableException {
				return "Response from cache is null, so callable is not called!";

			}
		};

		String response = cacheService.smartCache(mockCallable, new Object(), headers, "cachetable", new TypeReference<String>() {});

		assertNull(response);
	}

	private class CustomCallableException extends ApplicationException {
		private static final long serialVersionUID = 1L;

		public CustomCallableException(String error) {
			super(error);
		}
	}
}
