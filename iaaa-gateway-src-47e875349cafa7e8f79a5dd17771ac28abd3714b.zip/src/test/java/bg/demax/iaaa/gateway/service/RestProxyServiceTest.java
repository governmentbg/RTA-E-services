package bg.demax.iaaa.gateway.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.header;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Callable;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.support.RestGatewaySupport;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.iaaa.gateway.config.BeanConfigurations;
import bg.demax.iaaa.gateway.dto.ProxyRequestDto;
import bg.demax.iaaa.gateway.dto.cache.CacheEntry;
import bg.demax.iaaa.gateway.restproxying.RestProxyingService;
import bg.demax.iaaa.gateway.restproxying.requestconfig.RestProxyingRequestConfigService;
import bg.demax.iaaa.gateway.restproxying.requestconfig.config.RestProxyingRequestConfig;

@RunWith(MockitoJUnitRunner.class)
public class RestProxyServiceTest {

	private static final String CACHE_ENTRY_JSON_PATH_GET = "static/proxy/cache_entry_GET_REQUEST.json";
	private static final String CACHE_ENTRY_JSON_PATH_POST = "static/proxy/cache_entry_POST_REQUEST.json";
	private static final String RESPONSE_JSON_PATH_GET = "static/proxy/response.json";

	public static final String LOCAL_ENDPOINT = "/api/test";
	public static final String LOCAL_URL_FROM_DB = "http://localhost:123" + LOCAL_ENDPOINT;
	public static final String MOCK_SERVER_ADDRESS = "http://localhost:19088";
	private static final String SSL_PUBLIC_KEY_HEADER = "SSL_PUBLIC_KEY";

	@Mock
	private CacheService cacheService;

	@Mock
	private RestProxyingRequestConfigService requestConfigService;

	@InjectMocks
	private RestProxyingService proxyService;

	private ObjectMapper primaryMapper;

	private ObjectMapper postgreJsonMapper;

	private RestTemplate restTemplate;

	private MockRestServiceServer mockServer;

	@Before
	public void setUp() {
		BeanConfigurations beanConfigurations = new BeanConfigurations();
		primaryMapper = beanConfigurations.defaultMapper();
		postgreJsonMapper = beanConfigurations.jsonMapper();

		RestGatewaySupport gateway = new RestGatewaySupport();
		this.restTemplate = new RestTemplate();
		gateway.setRestTemplate(restTemplate);
		mockServer = MockRestServiceServer.createServer(gateway);
	}

	@Test
	@SuppressWarnings("unchecked")
	public void testMirrorRest_Get() throws Exception {

		CacheEntry<?, ?> cacheEntry = postgreJsonMapper.readValue(readFile(CACHE_ENTRY_JSON_PATH_GET), CacheEntry.class);

		ProxyRequestDto requestDto = postgreJsonMapper.convertValue(cacheEntry.getRequest(), ProxyRequestDto.class);

		MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<String, String>();
		Map<String, String> maps = (Map<String, String>) requestDto.getRequest();
		paramMap.setAll(maps);

		URI requestUri = UriComponentsBuilder.fromUriString(requestDto.getRequestUri()).build().toUri();
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(LOCAL_URL_FROM_DB).query(requestUri.getQuery()).build();

		URI uri = uriComponents.toUri();

		mockServer.expect(requestTo(uri))
			.andExpect(method(HttpMethod.GET))
			.andExpect(header(SSL_PUBLIC_KEY_HEADER, "test"))
			.andRespond(withSuccess(readFile(RESPONSE_JSON_PATH_GET), MediaType.APPLICATION_JSON));

		HttpHeaders headers = new HttpHeaders();
		headers.add(SSL_PUBLIC_KEY_HEADER, "test");

		RequestEntity<Object> requestEntity = new RequestEntity<Object>(paramMap, headers, HttpMethod.GET, uri);

		HttpEntity<Object> response = restTemplate.exchange(uri, HttpMethod.GET, requestEntity, Object.class);

		Mockito.when(cacheService.smartCache(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.eq(Object.class)))
			.thenReturn(response.getBody());

		Mockito.when(requestConfigService.getRestProxyingRequestConfig(Mockito.anyString(), Mockito.anyString()))
			.thenReturn(restProxyingRequestConfig(LOCAL_URL_FROM_DB, restTemplate));

		Object result = proxyService.mirrorRest(requestEntity, paramMap);

		mockServer.verify();
		assertTrue(result instanceof LinkedHashMap<?, ?>);
		assertEquals(cacheEntry.getResponse(), result);
	}

	@Test
	public void testMirrorRest_Post() throws Exception {

		CacheEntry<?, ?> cacheEntry = postgreJsonMapper.readValue(readFile(CACHE_ENTRY_JSON_PATH_POST), CacheEntry.class);

		ProxyRequestDto request = postgreJsonMapper.convertValue(cacheEntry.getRequest(), ProxyRequestDto.class);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(LOCAL_URL_FROM_DB).build();
		URI uri = uriComponents.toUri();

		mockServer.expect(requestTo(uri))
			.andExpect(method(HttpMethod.POST))
			.andExpect(content().string(primaryMapper.writeValueAsString(request)))
			.andExpect(header(SSL_PUBLIC_KEY_HEADER, "test"))
			.andRespond(withSuccess(readFile(RESPONSE_JSON_PATH_GET), MediaType.APPLICATION_JSON));

		HttpHeaders headers = new HttpHeaders();
		headers.add(SSL_PUBLIC_KEY_HEADER, "test");

		RequestEntity<Object> requestEntity = new RequestEntity<Object>(request, headers, HttpMethod.POST, uri);

		HttpEntity<Object> response = restTemplate.exchange(uri, HttpMethod.POST, requestEntity, Object.class);

		Mockito.when(cacheService.smartCache(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.eq(Object.class)))
			.thenReturn(response.getBody());

		Mockito.when(requestConfigService.getRestProxyingRequestConfig(Mockito.anyString(), Mockito.anyString()))
			.thenReturn(restProxyingRequestConfig(LOCAL_URL_FROM_DB, restTemplate));

		Object result = proxyService.mirrorRest(requestEntity, null);

		mockServer.verify();
		assertTrue(result instanceof LinkedHashMap<?, ?>);
		assertEquals(cacheEntry.getResponse(), result);
	}

	@Test
	public void testMirrorRest_when_pathVariablesExist() throws Exception {

		String pathVariable = "/1/morepath/2/";
		RequestEntity<Object> requestEntity = new RequestEntity<Object>(new Object(), null, HttpMethod.POST,
				new URI(LOCAL_URL_FROM_DB + pathVariable));

		ArgumentCaptor<Object> requestCaptor = ArgumentCaptor.forClass(Object.class);
		@SuppressWarnings("unchecked")
		ArgumentCaptor<Callable<Object>> callableCaptor = ArgumentCaptor.forClass(Callable.class);
		ArgumentCaptor<URI> uriCaptor = ArgumentCaptor.forClass(URI.class);

		RestProxyingRequestConfig restProxyConfig = restProxyingRequestConfig(
				LOCAL_ENDPOINT + "/{id}/morepath/{id}/", Mockito.mock(RestTemplate.class));
		Mockito.when(requestConfigService.getRestProxyingRequestConfig(Mockito.anyString(), Mockito.anyString()))
			.thenReturn(restProxyConfig);

		proxyService.mirrorRest(requestEntity, null);

		Mockito.verify(cacheService, Mockito.times(1))
			.smartCache(callableCaptor.capture(), requestCaptor.capture(), Mockito.any(), Mockito.any(), Mockito.eq(Object.class));

		Callable<Object> callable = callableCaptor.getValue();

		Mockito.when(restProxyConfig.getRestTemplate()
			.exchange(uriCaptor.capture(),
				Mockito.any(HttpMethod.class),
				Mockito.any(HttpEntity.class),
				Mockito.eq(byte[].class))).thenReturn(new ResponseEntity<>(HttpStatus.OK));

		callable.call();

		ProxyRequestDto proxyRequestDto = (ProxyRequestDto) requestCaptor.getValue();
		URI proxyUri = uriCaptor.getValue();

		String expectedRemoteUrl = restProxyConfig.getRemoteUrl() + pathVariable;
		assertEquals(expectedRemoteUrl, proxyRequestDto.getRequestUri());
		assertEquals(expectedRemoteUrl, proxyUri.toString());
	}

	@Test
	public void testMirrorRest_whenBodyIsNull() throws Exception {

		RestProxyingRequestConfig restProxyConfig = new RestProxyingRequestConfig();
		restProxyConfig.setRestTemplate(Mockito.mock(RestTemplate.class));
		restProxyConfig.setLocalPath("any");
		restProxyConfig.setRemoteUrl("http://any.com");

		Mockito.when(requestConfigService.getRestProxyingRequestConfig(Mockito.anyString(), Mockito.anyString()))
			.thenReturn(restProxyConfig);

		Mockito.when(restProxyConfig.getRestTemplate()
			.exchange(Mockito.any(URI.class),
				Mockito.any(HttpMethod.class),
				Mockito.any(HttpEntity.class),
				Mockito.eq(byte[].class))).thenReturn(new ResponseEntity<>(null, HttpStatus.OK));

		RequestEntity<Object> requestEntity = new RequestEntity<Object>(new Object(), null, HttpMethod.POST,
				new URI("any"));

		proxyService.mirrorRest(requestEntity, null);

		@SuppressWarnings("unchecked")
		ArgumentCaptor<Callable<Object>> callableCaptor = ArgumentCaptor.forClass(Callable.class);
		Mockito.verify(cacheService, Mockito.times(1))
			.smartCache(callableCaptor.capture(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.eq(Object.class));


		Object resp = callableCaptor.getValue().call();

		assertEquals(null, resp);
	}

	private String readFile(String filePath) throws IOException {
		Path path = Paths.get(this.getClass().getClassLoader().getResource(filePath).getFile());
		String content = new String(Files.readAllBytes(path));
		return content;
	}

	private RestProxyingRequestConfig restProxyingRequestConfig(String localPath, RestTemplate restTemplate) {
		RestProxyingRequestConfig restProxyingRequestConfig = new RestProxyingRequestConfig();
		restProxyingRequestConfig.setLocalPath(localPath);
		restProxyingRequestConfig.setRemoteUrl(MOCK_SERVER_ADDRESS);
		restProxyingRequestConfig.setRestTemplate(restTemplate);
		return restProxyingRequestConfig;
	}
}