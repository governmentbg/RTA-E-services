package bg.demax.iaaa.gateway.testutils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import bg.demax.pub.entity.City;
import bg.demax.pub.entity.RoadVehicle;
import bg.demax.pub.entity.RoadVehicleVersion;
import bg.demax.pub.entity.Subject;
import bg.demax.pub.entity.SubjectVersion;
import bg.demax.pub.entity.VehicleCategory;
import bg.demax.techinsp.entity.Inspection;
import bg.demax.techinsp.entity.InspectionCheck;
import bg.demax.techinsp.entity.InspectionCheckId;
import bg.demax.techinsp.entity.InspectionCheckValue;
import bg.demax.techinsp.entity.InspectionConclusion;
import bg.demax.techinsp.entity.InspectionElement;
import bg.demax.techinsp.entity.InspectionElementCardinality;
import bg.demax.techinsp.entity.InspectionType;
import bg.demax.techinsp.entity.Permit;
import bg.demax.techinsp.entity.PermitLine;

public class MockObjectsUtil {
	public static Inspection getInspection() {

		Inspection inspection = new Inspection();

		inspection.setId(1234L);

		inspection.setReceivedSignNumber(201120112011L);

		inspection.setEndDateTime(LocalDateTime.of(2020, 02, 02, 11, 0, 0));

		inspection.setNextInspectionDate(LocalDate.of(2021, 2, 1));

		inspection.setPersonEGN("5612124512");

		inspection.setPersonName("Person Name");

		inspection.setConclusion(InspectionConclusion.IA);

		InspectionType type = new InspectionType();

		type.setCode(InspectionType.CODE_VEHICLE);

		inspection.setInspectionType(type);

		RoadVehicleVersion rvv = new RoadVehicleVersion();

		RoadVehicle rv = new RoadVehicle();

		rv.setCurrentVersion(rvv);

		rvv.setRoadVehicle(rv);

		inspection.setRoadVehicle(rv);

		inspection.setRoadVehicleVersion(rvv);

		rv.setVin("TEST1231231231234");

		rv.setId(333L);

		rvv.setRegistrationNumber("CB0000AK");

		rvv.setCurrentKmState(56000);

		VehicleCategory category = new VehicleCategory();

		category.setCode("M1");

		category.setValid(true);

		category.setDescription("Description");

		rvv.setCategory(category);

		rvv.setFirstRegistrationDate(LocalDate.of(2005, 5, 1));

		rvv.setMake("Make");

		Set<InspectionCheck> checks = new HashSet<InspectionCheck>();

		Map<Integer, InspectionCheck> checksMap = new HashMap<Integer, InspectionCheck>();

		for (int i = 0; i < 5; i++) {

			InspectionCheck check = new InspectionCheck();

			InspectionCheckId checkId = new InspectionCheckId();

			check.setId(checkId);

			check.setValue(InspectionCheckValue.Y);

			checkId.setInspection(inspection);

			InspectionElement element = new InspectionElement();

			element.setCardinality(InspectionElementCardinality.DANGEROUS_DAMAGE);

			element.setDescIndex(i + ".2");

			element.setHasCheck(true);

			element.setId(Long.valueOf(i));

			checkId.setElement(element);

			checks.add(check);

			checksMap.put(i, check);

			inspection.setInspectionChecks(checks);

			if (i > 0) {

				InspectionElement parent = checksMap.get(i - 1).getId().getElement();

				element.setParent(parent);

			}

		}

		Subject subject = new Subject();

		subject.setIdentityNumber("130460283");

		City ktpCity = new City();

		ktpCity.setName("Sofia");

		SubjectVersion subjectVersion = new SubjectVersion();

		subjectVersion.setFullName("Full Name");

		subject.setCurrentVersion(subjectVersion);

		subjectVersion.setSubject(subject);

		PermitLine permitLine = new PermitLine();

		permitLine.setId(111);

		Permit permit = new Permit();

		permitLine.setPermit(permit);

		List<PermitLine> permitLines = new ArrayList<PermitLine>();

		permitLines.add(permitLine);

		permit.setPermitLines(permitLines);

		permit.setPermitNumber(222);

		permit.setSubject(subject);

		permit.setKtpCity(ktpCity);

		permit.setKtpAddress("Vitoha str 1");

		permit.setSubjectVersion(subjectVersion);

		inspection.setPermitLine(permitLine);

		return inspection;

	}
}
