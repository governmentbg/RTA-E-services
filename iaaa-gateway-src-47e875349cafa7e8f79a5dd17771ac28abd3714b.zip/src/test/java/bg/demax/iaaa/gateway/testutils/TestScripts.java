package bg.demax.iaaa.gateway.testutils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public interface TestScripts {

	String INIT_IAAA_SCRIPT = "/sql/init_iaaa_db.sql";
	String INIT_CACHE_SCRIPT = "/sql/init_cache_db.sql";

	/* ******** SECURITY ******** */

	String USERS = "/sql/security/users.sql";
	String USERS_AUTHORITIES = "/sql/security/users_authorities.sql";
	String AUTHORITIES = "/sql/security/authorities.sql";

	/* ******** PUBLIC ******** */

	String N_CITIES = "/sql/public/n_cities.sql";
	String N_COUNTRIES = "/sql/public/n_countries.sql";
	String N_MUNS = "/sql/public/n_muns.sql";
	String N_ORG_UNITS = "/sql/public/n_org_units.sql";
	String N_REGIONS = "/sql/public/n_regions.sql";
	String N_RV_SPECIFIC_TYPES = "/sql/public/n_rv_specific_types.sql";
	String N_VCATEGORIES = "/sql/public/n_vcategories.sql";
	String RVS = "/sql/public/rvs.sql";
	String RVS_VERSIONS = "/sql/public/rvs_versions.sql";
	String SUBJ_VERSIONS = "/sql/public/subj_versions.sql";
	String SUBJECTS = "/sql/public/subjects.sql";

	/* ******** TECHINSP ******** */

	String INSP_CHECKS = "/sql/techinsp/insp_checks.sql";
	String INSPECTIONS = "/sql/techinsp/inspections.sql";
	String N_INSP_ELEMENTS = "/sql/techinsp/n_insp_elements.sql";
	String N_INSP_TYPES = "/sql/techinsp/n_insp_types.sql";
	String N_PERMIT_STATUSES = "/sql/techinsp/n_permit_statuses.sql";
	String PERMIT_LINES = "/sql/techinsp/permit_lines.sql";
	String PERMITS = "/sql/techinsp/permits.sql";

	List<String> INSPECTION_DEPENDENCIES = Arrays.asList(N_COUNTRIES, N_REGIONS, N_MUNS, N_CITIES, N_ORG_UNITS,
			N_VCATEGORIES, N_RV_SPECIFIC_TYPES, N_INSP_TYPES, N_INSP_ELEMENTS, N_PERMIT_STATUSES, RVS, RVS_VERSIONS,
			SUBJECTS, SUBJ_VERSIONS, PERMITS, PERMIT_LINES, INSPECTIONS, INSP_CHECKS);

	static String readFile(String filePath) {
		Path path = Paths.get(TestScripts.class.getClassLoader().getResource(filePath).getFile());

		Stream<String> lines = null;
		try {
			lines = Files.lines(path);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage());
		}
		String contents = lines.collect(Collectors.joining(System.lineSeparator()));
		lines.close();

		return contents;
	}

}
