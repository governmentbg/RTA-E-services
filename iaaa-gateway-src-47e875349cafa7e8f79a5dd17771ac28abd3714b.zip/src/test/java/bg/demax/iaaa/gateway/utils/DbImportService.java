package bg.demax.iaaa.gateway.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.iaaa.gateway.config.BeanQualifiers;
import bg.demax.iaaa.gateway.db.entity.iaaaproxies.ProxyRequestDetails;
import bg.demax.iaaa.gateway.db.entity.iaaaproxies.RestTemplateConfig;
import bg.demax.iaaa.gateway.db.entity.iaaaproxies.SSLCertificateDetails;
import bg.demax.iaaa.gateway.db.repository.GenericRepository;

@Service
public class DbImportService {

	@Autowired
	@Qualifier(BeanQualifiers.IAAA_PROXIES_GENERIC_REPOSITORY)
	private GenericRepository genericRepository;

	@Transactional(value = BeanQualifiers.IAAA_PROXIES_TRANSACTION_MANAGER)
	public void saveToDb(Object obj) {
		if (obj != null) {
			genericRepository.saveOrUpdate(obj);
		}
	}

	@Transactional(value = BeanQualifiers.IAAA_PROXIES_TRANSACTION_MANAGER)
	public int saveProxyRequestDetails(ProxyRequestDetails proxyRequestDetails) {
		RestTemplateConfig rtConfig = proxyRequestDetails.getRestTemplateConfig();
		SSLCertificateDetails keyStoreDetails = rtConfig.getKeyStore();
		SSLCertificateDetails trustStoreDetails = rtConfig.getTrustStore();

		if (keyStoreDetails != null) {
			saveToDb(keyStoreDetails.getCertData());
		}

		if (trustStoreDetails != null) {
			saveToDb(trustStoreDetails.getCertData());
		}

		saveToDb(keyStoreDetails);
		saveToDb(trustStoreDetails);
		saveToDb(rtConfig);
		saveToDb(proxyRequestDetails);

		return proxyRequestDetails.getId();
	}

}