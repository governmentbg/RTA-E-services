package bg.demax.iaaa.gateway.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;

import org.junit.Test;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.iaaa.gateway.config.IaaaGatewayConstants;
import bg.demax.iaaa.gateway.utils.ObjectMapperUtils;

public class ObjectMapperUtilsTest {
	@Test
	public void testDateTimeSerialization_withStandartConfiguredOm() throws IOException {
		ObjectMapper om = ObjectMapperUtils.getNewConfiguredObjectMapper();

		CustomObj obj = new CustomObj();
		obj.setName("testName");
		obj.setAge(42);
		obj.setDate1(LocalDateTime.now().minusYears(1));
		obj.setDate2(LocalDateTime.now().minusDays(100));

		String serializedObj = om.writeValueAsString(obj);


		CustomObj deserializedObj = om.readValue(serializedObj, CustomObj.class);

		assertEquals(obj.getName(), deserializedObj.getName());
		assertEquals(obj.getAge(), deserializedObj.getAge());


		//json format does not include seconds so they are skipped when serializing.
		//max difference between serialized and deserialized date should be =< 59 seconds
		LocalDateTime originalJsonFormatDate = obj.getDate1();
		LocalDateTime deserializedJsonFormatDate = deserializedObj.getDate1();
		Duration duration = Duration.between(originalJsonFormatDate, deserializedJsonFormatDate);
		assertTrue(duration.getSeconds() <= 59);

		assertEquals(obj.getDate2(), deserializedObj.getDate2());
	}

	public static class CustomObj {
		private String name;
		private Integer age;

		@JsonFormat(pattern = IaaaGatewayConstants.DATE_TIME_FORMAT)
		private LocalDateTime date1;

		@DateTimeFormat(pattern = IaaaGatewayConstants.DATE_TIME_FORMAT)
		private LocalDateTime date2;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Integer getAge() {
			return age;
		}

		public void setAge(Integer age) {
			this.age = age;
		}

		public LocalDateTime getDate1() {
			return date1;
		}

		public void setDate1(LocalDateTime date1) {
			this.date1 = date1;
		}

		public LocalDateTime getDate2() {
			return date2;
		}

		public void setDate2(LocalDateTime date2) {
			this.date2 = date2;
		}

	}
}
