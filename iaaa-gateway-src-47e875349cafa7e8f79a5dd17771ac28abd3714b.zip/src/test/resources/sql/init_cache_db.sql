CREATE SCHEMA iaaa_gateway;
CREATE ROLE iaaa_gateway;

CREATE TABLE iaaa_gateway.l_inspections_last_valid (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);

CREATE TABLE iaaa_gateway.l_inspections_history (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);

CREATE TABLE iaaa_gateway.l_inspections_last (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);

CREATE TABLE iaaa_gateway.l_proxy_dqc_valid_card_check (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);

CREATE TABLE iaaa_gateway.l_proxy_dqc_roster_check (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);

CREATE TABLE iaaa_gateway.l_proxy_road_service_psycho_cert_check (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);


-- good example of how to actually create a table in production
BEGIN;
CREATE TABLE iaaa_gateway.l_grao_person_data 
		     ( 
		 	     workflow jsonb NOT NULL, 
		 	     id SERIAL PRIMARY KEY, 
		 	     request_time timestamp without time zone 
		 	 ) ;
CREATE INDEX iaaa_gateway_l_grao_person_data_idx ON iaaa_gateway.l_grao_person_data (request_time) ;
GRANT INSERT, SELECT, UPDATE ON TABLE iaaa_gateway.l_grao_person_data TO iaaa_gateway ;
COMMENT ON TABLE iaaa_gateway.l_grao_person_data IS 'Запазва входните и изходни данни, с които е направена заявката към услугата "Справка в Национална база данни "Население" към ГРАО по ЕГН. Данните минават през преработка към JSON, а не се прави автоматично проксиране."' ;
GRANT USAGE, SELECT ON SEQUENCE iaaa_gateway.l_grao_person_data_id_seq TO iaaa_gateway ;
COMMIT;


