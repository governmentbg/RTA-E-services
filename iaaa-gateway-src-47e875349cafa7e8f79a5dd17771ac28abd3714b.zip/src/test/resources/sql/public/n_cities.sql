INSERT INTO 

public.n_cities(code, name, name_lat, city_type, mun_code, region_code)

VALUES

(1, 'СОФИЯ', 'SOFIA', 1, 1, 'SOF'),
(2, 'ПЕЩЕРА', 'PESHTERA', 1, 2, 'PAZ'),
(3, 'АСЕНОВГРАД', 'ASENOVGRAD', 1, 3, 'PLD');