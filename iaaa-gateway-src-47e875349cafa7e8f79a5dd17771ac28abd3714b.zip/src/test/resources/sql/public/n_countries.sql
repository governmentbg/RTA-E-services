INSERT INTO

public.n_countries(code, char2_code, num_code, name, name_lat, eu_member)

VALUES

('BGR', 'BG', '359', 'БЪЛГАРИЯ', 'BULGARIA', 'Y');
