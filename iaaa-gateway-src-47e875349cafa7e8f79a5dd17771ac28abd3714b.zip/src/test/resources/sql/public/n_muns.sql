INSERT INTO

public.n_muns(code, region_code)

VALUES 

(1, 'SOF'),
(2, 'PAZ'),
(3, 'PLD');
