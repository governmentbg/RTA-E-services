INSERT INTO

public.n_org_units(code, org_unit_type, name, city_code, exam_comittees, is_valid)

VALUES

('РДАА16','РД','Областен отдел "Автомобилна администрация" - Пловдив',3,1,'Y');