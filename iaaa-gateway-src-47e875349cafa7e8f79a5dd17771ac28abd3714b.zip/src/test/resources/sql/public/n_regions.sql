INSERT INTO

public.n_regions(code, name, name_lat, order_no)

VALUES 

('SOF', 'СОФИЯ', 'SOFIA', 1),
('PAZ', 'ПАЗАРДЖИК', 'PAZARDZHIK', 2),
('PLD', 'ПЛОВДИВ', 'PLOVDIV', 3);