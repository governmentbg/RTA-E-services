INSERT INTO 

public.n_rv_specific_types(id, description)
	
VALUES 

(1, 'test');