INSERT INTO

public.n_vcategories(code, description, is_valid)

VALUES

('M1', 'моторните превозни средства за превоз на пътници, в които броят на местата за сядане, без мястото на водача, е не повече от 8', 'Y');