INSERT INTO

public.rvs_versions (id, ver_date, rvs_id, b_first_reg_date, specific_type_id, is_valid, d1_vmake_lat, a_reg_num, j_vcategory, current_km_state) 

VALUES

(1, '2016-02-03', 1, '2010-02-03', 1, TRUE, 'NISSAN JUKE', 'CA8124PE', 'M1', 202030), 
(2, '2018-03-03', 2, '2006-08-03', 1, TRUE, 'TOYOTA RAV4', 'CA8125PE', 'M1', 201040),
(3, '2018-03-04', 3, '2007-05-03', 1, TRUE, 'ACURA MDX', 'CA2278BP', 'M1', 102050),
(4, '2018-02-03', 1, '2011-12-03', 1, TRUE, 'NISSAN JUKE', 'CA8124PE', 'M1', 132356),
(5, '2019-02-04', 3, '2011-12-03', 1, TRUE, 'ACURA MDX', 'CB3223BC', 'M1', 142787),
(6, '2020-02-03', 3, '2011-12-03', 1, TRUE, 'ACURA MDX', 'CB3223BC', 'M1', 161080),
(7, '2020-05-07', 4, '2016-04-03', 1, TRUE, 'NISSAN LEAF', 'PA1403BP', 'M1', 14108);