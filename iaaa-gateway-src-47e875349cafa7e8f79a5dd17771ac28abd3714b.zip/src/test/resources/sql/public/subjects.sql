INSERT INTO

public.subjects(id, ident_num, subject_type, country_code)

VALUES

(22820,'130460250', 'L', 'BGR'),
(22103,'175258785', 'L', 'BGR'),
(22104,'5002122541', 'P', 'BGR');