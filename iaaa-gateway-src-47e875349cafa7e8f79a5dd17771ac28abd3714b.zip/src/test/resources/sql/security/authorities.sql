INSERT INTO security.authorities(authority_id, authority_name, description, orm_version)
VALUES (1, 'ROLE_IAAA_GATEWAY_ADMIN', 'Администраторски права за системата IAAA-GATEWAY', 0);