INSERT INTO security.users (user_id, username, authentication_type, public_key, enabled, orm_version)
VALUES (1, 'mock_poli', 'crypto_token', 'mock_key', true, 0);

