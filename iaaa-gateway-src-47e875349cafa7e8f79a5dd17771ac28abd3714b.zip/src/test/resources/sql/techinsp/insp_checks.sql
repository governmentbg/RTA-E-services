INSERT INTO

techinsp.insp_checks(insp_id, element_id, value)

VALUES

(4, 13650, 'N'),
(4, 13660, 'C'),
(4, 11550, 'N'),
(4, 11640, 'N'),
(4, 10030, 'N'),
(4, 13640, 'N'),
(4, 11565, 'N');