INSERT INTO

techinsp.n_insp_types(code, description)

VALUES 

('VEHICLE', 'Преглед за техническа изправност на ППС');