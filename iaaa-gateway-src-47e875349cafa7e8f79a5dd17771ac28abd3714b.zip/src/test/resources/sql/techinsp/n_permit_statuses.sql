INSERT INTO

techinsp.n_permit_statuses(code, description)

VALUES

('СЗ','СЪЗДАДЕН');