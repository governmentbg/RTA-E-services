INSERT INTO

techinsp.permit_lines(id, permit_id, valid_from, valid_to, is_valid, line_num)

VALUES 

(101,201,'2015-02-19',NULL,'Y',1),
(102,202,'2009-09-15','2014-09-15','Y',1),
(103,203,'2010-12-21','2015-12-21','Y',1);