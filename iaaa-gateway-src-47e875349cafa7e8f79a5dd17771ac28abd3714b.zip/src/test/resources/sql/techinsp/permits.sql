INSERT INTO

techinsp.permits(id, org_unit, permit_num, subj_id, doc_status, ktp_city_code, ktp_address, subj_ver_id, s_status)

VALUES

(201, 'РДАА16', 121,'22820', 'СЗ', '1','УЛ. КАДЕМЛИЯ № 16','11', 'A'),
(202, 'РДАА16', 122,'22103', 'СЗ', '2','УЛ. ТЪРГОВСКА № 112','22', 'A'),
(203, 'РДАА16', 123,'22104', 'СЗ', '3','ШЕСТА № 473','33', 'A');