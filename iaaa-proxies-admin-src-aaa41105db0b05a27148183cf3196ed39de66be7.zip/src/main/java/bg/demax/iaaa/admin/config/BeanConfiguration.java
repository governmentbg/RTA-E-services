package bg.demax.iaaa.admin.config;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.GregorianCalendar;

import javax.net.ssl.SSLContext;

import org.apache.catalina.LifecycleException;
import org.apache.catalina.LifecycleState;
import org.apache.catalina.valves.rewrite.RewriteValve;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.servlet.server.ServletWebServerFactory;
import org.springframework.context.ApplicationContextException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;

import bg.demax.iaaa.admin.config.property.RegDocSenderConfigurationPropertiesRepository;
import bg.demax.iaaa.admin.config.property.RestTemplateProperties;
import bg.demax.iaaa.admin.security.Sha1PasswordEncoder;

@Configuration
public class BeanConfiguration {

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_ADMIN_RT_PROPS)
	private RestTemplateProperties iaaaProxiesAdminRtProps;

	@Value("${reg.doc.sender.properties-file-path}")
	private String regDocSenderPropertiesFilePath;

	@Bean
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_ADMIN_RT_PROPS)
	@ConfigurationProperties("iaaa.proxies.admin.rt")
	public RestTemplateProperties rtProps() {
		return new RestTemplateProperties();
	}

	@Bean
	@Profile("!" + IaaaProxiesAdminWebConstants.SPRING_PROFILE_UNIT_TEST)
	public PasswordEncoder createPasswordEncoder() {
		return new Sha1PasswordEncoder();
	}

	@Bean
	@Primary
	public ObjectMapper defaultObjectMapper() {
		ObjectMapper om = new ObjectMapper();
		om.disable(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
		om.disable(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS);
		om.registerModule(new JavaTimeModule());
		return om;
	}

	@Bean
	@Qualifier(BeanQualifierConstants.POSTGRE_JSON_OBJECT_MAPPER)
	public ObjectMapper jsonMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.enableDefaultTyping();
		mapper.registerModule(new SimpleModule());
		mapper.registerSubtypes(GregorianCalendar.class);

		JavaTimeModule javaTimeModule = new JavaTimeModule();
		javaTimeModule.addDeserializer(LocalDateTime.class,
				new LocalDateTimeDeserializer(DateTimeFormatter.ISO_DATE_TIME));
		javaTimeModule.addDeserializer(LocalDate.class, new LocalDateDeserializer(DateTimeFormatter.ISO_DATE));

		mapper.registerModule(javaTimeModule);

		return mapper;
	}

	@Bean
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_ADMIN_REST_TEMPLATE_FOR_PROXY_APPS)
	@Profile("!" + IaaaProxiesAdminWebConstants.SPRING_PROFILE_UNIT_TEST)
	public RestTemplate iaaaProxiesAdminRtForProxyApps() throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException, Exception {

		return getGenericIaaaProxiesAdminRestTemplate();
	}

	@Bean
	public ServletWebServerFactory servletContainer() {
		TomcatServletWebServerFactory tomcat = new TomcatServletWebServerFactory();
		tomcat.addContextValves(new CpRewriteValve());

		return tomcat;
	}

	@Bean
	@Profile("!" + IaaaProxiesAdminWebConstants.SPRING_PROFILE_UNIT_TEST)
	public RegDocSenderConfigurationPropertiesRepository regDocSenderConfigurationPropertiesRepository() {
		return new RegDocSenderConfigurationPropertiesRepository(regDocSenderPropertiesFilePath);
	}

	private RestTemplate getGenericIaaaProxiesAdminRestTemplate() throws KeyManagementException,
		UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException, Exception {
		char[] keystorePass = iaaaProxiesAdminRtProps.getKeystorePassword().toCharArray();
		char[] truststorePass = iaaaProxiesAdminRtProps.getTruststorePassword().toCharArray();
		SSLContext sslContext = null;

		sslContext = SSLContextBuilder.create()
				.loadKeyMaterial(keyStore(iaaaProxiesAdminRtProps.getKeystore(), keystorePass, iaaaProxiesAdminRtProps.getKeystoreType()),
						keystorePass)
				.loadTrustMaterial(getClass().getResource(iaaaProxiesAdminRtProps.getTruststore()), truststorePass).build();

		if (sslContext == null) {
			throw new ApplicationContextException("Could not load SSL context.");
		}

		HttpClient client = HttpClients.custom().setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
				.setSSLContext(sslContext).build();

		RestTemplate restTemplate = new RestTemplateBuilder()
				.setConnectTimeout(Duration.ofSeconds(iaaaProxiesAdminRtProps.getConnectionTimeoutSeconds()))
				.setReadTimeout(Duration.ofSeconds(iaaaProxiesAdminRtProps.getReadTimeoutSeconds()))
				.requestFactory(() -> new HttpComponentsClientHttpRequestFactory(client)).build();

		return restTemplate;
	}

	private KeyStore keyStore(String file, char[] password, String keystoreType) throws Exception {
		KeyStore keyStore = KeyStore.getInstance(keystoreType);

		try (InputStream in = getClass().getResourceAsStream(file)) {
			keyStore.load(in, password);
		}
		return keyStore;
	}

	private class CpRewriteValve extends RewriteValve {

		@Override
		protected synchronized void startInternal() throws LifecycleException {
			setState(LifecycleState.STARTING);

			try (InputStream is = this.getClass().getResourceAsStream("/rewrite.config");
				InputStreamReader isr = new InputStreamReader(is, StandardCharsets.UTF_8);
				BufferedReader buffer = new BufferedReader(isr)) {
				parse(buffer);
			} catch (final Exception e) {
				throw new RuntimeException(e.getMessage());
			}
		}

	}
}
