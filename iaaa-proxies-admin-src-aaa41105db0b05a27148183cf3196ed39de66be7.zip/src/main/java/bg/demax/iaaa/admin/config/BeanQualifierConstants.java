package bg.demax.iaaa.admin.config;

public interface BeanQualifierConstants {
	//data sources
	String IAAA_PROXIES_DB_DATASOURCE = "iaaa-proxies-datasource";
	String IAAA_IMG_REPLICATION_DATASOURCE = "iaaa-img-replication-datasource";
	String IAAA_IMG_DATASOURCE = "iaaa-img-datasource";

	//session factories
	String IAAA_IMG_REPLICATION_SESSION_FACTORY = "iaaa-img-replication-session-factory";
	String IAAA_PROXIES_SESSION_FACTORY = "iaaa-proxies-session-factory";

	//generic repositories
	String IAAA_PROXIES_GENERIC_REPOSITORY = "iaaa-proxies-generic-repository";

	String IAAA_PROXIES_ADMIN_REST_TEMPLATE_FOR_PROXY_APPS = "iaaa-proxies-admin-rt-for-proxy-apps";

	String POSTGRE_JSON_OBJECT_MAPPER = "postgre-json-object-mapper";
	String DEFAULT_SPRING_BOOT_CONVERSION_SERVICE = "mvcConversionService";

	String IAAA_PROXIES_TRANSACTION_MANAGER = "iaaaProxiesTransactionManager";
	String IAAA_IMG_REPL_TRANSACTION_MANAGER = "iaaaImgReplTransactionManager";

	String IAAA_PROXIES_ADMIN_RT_PROPS = "iaaa-proxies-admin-rt-props";


}
