package bg.demax.iaaa.admin.config;

public interface IaaaProxiesAdminWebConstants {
	/**
	 * for test environment at drive.demax.bg
	 */
	String SPRING_PROFILE_TEST = "test";

	/**
	 * for unit tests.
	 */
	String SPRING_PROFILE_UNIT_TEST = "utest";

	/**
	 * for production.
	 */
	String SPRING_PROFILE_PRODUCTION = "production";

	String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm";

	String[] IAAA_PROXIES_ENTITY_PACKAGES_TO_SCAN = { "bg.demax.iaaa.admin.db.entity.iaaaproxies" };
	String[] IAAA_IMG_REPL_ENTITY_PACKAGES_TO_SCAN = { "bg.demax.iaaa.admin.db.entity.iaaaimgrepl" };

	int VEH_VERIFICATION_SUCCESS_RETURN_CODE = 0;
	int VEH_VERIFICATION_SYSTEM_ERROR_RETURN_CODE = 1;
	int VEH_VERIFICATION_NO_DATA_FOUND_RETURN_CODE = 2;

	int VEH_OWNER_ID_MATCH_VERIFICATION_CODE = 1;
	int VEH_OWNER_ID_NO_MATCH_VERIFICATION_CODE = 2;
	int VEH_OWNER_NO_REGISTERED_DATA_VERIFICATION_CODE = 3;

	String[] TEAM_SPIKE = {
		"i.rusev@demax.bg",
		"k.nacheva@demax.bg",
		"zg.ivanova@demax.bg",
		"s.dakova@demax.bg",
		"martin@demax.bg"
	};
}
