package bg.demax.iaaa.admin.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.logout.HttpStatusReturningLogoutSuccessHandler;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfTokenRepository;

import bg.demax.iaaa.admin.security.NoopAuthenticationSuccessHandler;
import bg.demax.iaaa.admin.security.SecurityGroups;
import bg.demax.iaaa.admin.security.UnauthorizedAuthenticationFailureHandler;
import bg.demax.iaaa.admin.security.UserDetailsServiceImpl;

@Configuration
@EnableWebSecurity
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {
	private static final String CSRF_TOKEN_COOKIE_NAME = "_csrf";
	private static final String ACCESS_TOKEN_HEADER_NAME = "X-CSRF-TOKEN";
	private static final String ACCESS_TOKEN_COOKIE_NAME = "access_token";

	public static final String USERNAME_PARAM_NAME = "username";
	public static final String PASSWORD_PARAM_NAME = "password";

	@Autowired
	private UserDetailsServiceImpl userService;

	public CsrfTokenRepository getCsrfTokenRepository() {
		CookieCsrfTokenRepository repository = new CookieCsrfTokenRepository();

		repository.setCookieHttpOnly(false);
		repository.setCookieName(CSRF_TOKEN_COOKIE_NAME);
		repository.setHeaderName(ACCESS_TOKEN_HEADER_NAME);

		return repository;
	}

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		super.configure(auth);
		auth.userDetailsService(userService);
	}

	@Override
	public void configure(WebSecurity web) {
		web.ignoring()
			.antMatchers(HttpMethod.OPTIONS, "/**")
			.antMatchers("/*.{js,html,css,png,ttf}");
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
		.cors()
		.and()
		.csrf()
		.csrfTokenRepository(getCsrfTokenRepository())
		.and()
		.formLogin()
		.usernameParameter(USERNAME_PARAM_NAME)
		.passwordParameter(PASSWORD_PARAM_NAME)
		.loginPage("/index.html")
		.loginProcessingUrl("/api/authentication")
		.successHandler(ajaxAuthenticationSuccessHandler())
		.failureHandler(ajaxAuthenticationFailureHandler())
		.permitAll()
		.and()
		.exceptionHandling().authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.FORBIDDEN));

		authRequestsAndAddMatchers(http);

		http.logout().logoutUrl("/api/logout/**")
		.logoutSuccessHandler((new HttpStatusReturningLogoutSuccessHandler(HttpStatus.OK))).invalidateHttpSession(true)
		.deleteCookies("JSESSIONID", CSRF_TOKEN_COOKIE_NAME, ACCESS_TOKEN_COOKIE_NAME).clearAuthentication(true)
		.permitAll();

		http.authorizeRequests().anyRequest().authenticated();
	}

	private AuthenticationSuccessHandler ajaxAuthenticationSuccessHandler() {
		return new NoopAuthenticationSuccessHandler();
	}

	private AuthenticationFailureHandler ajaxAuthenticationFailureHandler() {
		return new UnauthorizedAuthenticationFailureHandler();
	}

	private ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry authRequestsAndAddMatchers(
			HttpSecurity httpSecurity) throws Exception {
		return httpSecurity.authorizeRequests()
					.mvcMatchers("/index.html", "/", "/assets/**", "/api/csrf").permitAll()
					.mvcMatchers(HttpMethod.GET, "/api/vehicles").hasAnyRole(SecurityGroups.FULL_ACCESS.getRolesInGroup())
					.mvcMatchers(HttpMethod.GET, "/api/reg-docs/config-params").hasAnyRole(SecurityGroups.FULL_ACCESS.getRolesInGroup())
					.mvcMatchers(HttpMethod.PUT, "/api/reg-docs/**").hasAnyRole(SecurityGroups.FULL_ACCESS.getRolesInGroup())
					.mvcMatchers("/api/reports/**").hasAnyRole(SecurityGroups.FULL_ACCESS.getRolesInGroup())
					.mvcMatchers("/api/remote-server-call/**").hasAnyRole(SecurityGroups.FULL_ACCESS.getRolesInGroup())
					.mvcMatchers("/api/iaaa-gateway/proxy-requests/**").hasAnyRole(SecurityGroups.FULL_ACCESS.getRolesInGroup())
					.mvcMatchers("/api/iaaa-gateway/rest-template-config/**").hasAnyRole(SecurityGroups.FULL_ACCESS.getRolesInGroup())
					.mvcMatchers("/api/iaaa-gateway/update/**").hasAnyRole(SecurityGroups.FULL_ACCESS.getRolesInGroup())
					.mvcMatchers("/api/regix-proxy-request-info/**").hasAnyRole(SecurityGroups.FULL_ACCESS.getRolesInGroup())
					.mvcMatchers("/api/iaaa-gateway/request-info/**").hasAnyRole(SecurityGroups.FULL_ACCESS.getRolesInGroup());

	}
}
