package bg.demax.iaaa.admin.config.db;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.zaxxer.hikari.HikariDataSource;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;

@Configuration
@Profile("!" + IaaaProxiesAdminWebConstants.SPRING_PROFILE_UNIT_TEST)
public class DataSourceConfiguration {

	@Value("${jdbc.config.iaaa-proxies.url}")
	private String iaaaProxiesJdbcUrl;

	@Value("${jdbc.config.iaaa-proxies.username}")
	private String iaaaProxiesUsername;

	@Value("${jdbc.config.iaaa-proxies.password}")
	private String iaaaProxiesPassword;

	@Value("${jdbc.config.iaaa-img-repl.url}")
	private String iaaaImgReplJdbcUrl;

	@Value("${jdbc.config.iaaa-img-repl.username}")
	private String iaaaImgReplUsername;

	@Value("${jdbc.config.iaaa-img-repl.password}")
	private String iaaaImgReplPassword;

	@Value("${jdbc.config.iaaa-img.url}")
	private String iaaaImgJdbcUrl;

	@Value("${jdbc.config.iaaa-img.username}")
	private String iaaaImgUsername;

	@Value("${jdbc.config.iaaa-img.password}")
	private String iaaaImgPassword;

	private static final int MAX_POOL_SIZE = 2;
	private static final long CONNECTION_TIMEOUT = 2 * 60 * 1000;
	private static final long MAX_CONNECTION_IDLE_TIMEOUT = 3 * 60 * 1000;

	@Bean
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_DB_DATASOURCE)
	public DataSource dataSourceForIaaaProxiesCacheDb() {
		HikariDataSource dataSource = new HikariDataSource();

		dataSource.setJdbcUrl(iaaaProxiesJdbcUrl);
		dataSource.setUsername(iaaaProxiesUsername);
		dataSource.setPassword(iaaaProxiesPassword);
		dataSource.setMaximumPoolSize(MAX_POOL_SIZE);
		dataSource.setConnectionTimeout(CONNECTION_TIMEOUT);
		dataSource.setIdleTimeout(MAX_CONNECTION_IDLE_TIMEOUT);
		dataSource.setMinimumIdle(0);

		return dataSource;
	}

	@Bean
	@Qualifier(BeanQualifierConstants.IAAA_IMG_REPLICATION_DATASOURCE)
	public DataSource dataSourceForIaaaImgReplication() {
		HikariDataSource dataSource = new HikariDataSource();

		dataSource.setJdbcUrl(iaaaImgReplJdbcUrl);
		dataSource.setUsername(iaaaImgReplUsername);
		dataSource.setPassword(iaaaImgReplPassword);
		dataSource.setMaximumPoolSize(MAX_POOL_SIZE);
		dataSource.setConnectionTimeout(CONNECTION_TIMEOUT);
		dataSource.setIdleTimeout(MAX_CONNECTION_IDLE_TIMEOUT);
		dataSource.setMinimumIdle(0);

		return dataSource;
	}

	@Bean
	@Qualifier(BeanQualifierConstants.IAAA_IMG_DATASOURCE)
	public DataSource dataSourceForIaaImg() {
		HikariDataSource dataSource = new HikariDataSource();

		dataSource.setJdbcUrl(iaaaImgJdbcUrl);
		dataSource.setUsername(iaaaImgUsername);
		dataSource.setPassword(iaaaImgPassword);
		dataSource.setMaximumPoolSize(MAX_POOL_SIZE);
		dataSource.setConnectionTimeout(CONNECTION_TIMEOUT);
		dataSource.setIdleTimeout(MAX_CONNECTION_IDLE_TIMEOUT);
		dataSource.setMinimumIdle(0);

		return dataSource;
	}

}
