package bg.demax.iaaa.admin.config.db;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;
import bg.demax.iaaa.admin.db.mappers.JdbcJsonRowMapper;
import bg.demax.iaaa.admin.db.repository.GenericRepository;
import bg.demax.ictclient.db.workflows.BaseWorkflow;

@Configuration
@EnableJpaRepositories(
		basePackages = "bg.demax.iaaa.admin.db.repository.iaaaproxies",
		entityManagerFactoryRef = BeanQualifierConstants.IAAA_PROXIES_SESSION_FACTORY,
		transactionManagerRef = BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER
)
@EnableTransactionManagement
public class IaaaProxiesDbConfiguration {

	@Value("${hibernate.hbm2ddl.auto}")
	private String hbm2dll;

	@Value("${hibernate.show_sql}")
	private String showSql;

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_DB_DATASOURCE)
	private DataSource iaaaProxiesDataSource;

	@Bean(name = BeanQualifierConstants.IAAA_PROXIES_SESSION_FACTORY)
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_SESSION_FACTORY)
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(iaaaProxiesDataSource);
		sessionFactory.setPackagesToScan(IaaaProxiesAdminWebConstants.IAAA_PROXIES_ENTITY_PACKAGES_TO_SCAN);
		sessionFactory.setHibernateProperties(hibernateProperties());
		return sessionFactory;
	}

	@Bean(name = BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER)
	public PlatformTransactionManager iaaaProxiesTransactionManager() {
		JpaTransactionManager jpaTransactionManager = new JpaTransactionManager();
		jpaTransactionManager.setEntityManagerFactory(sessionFactory().getObject());
		return jpaTransactionManager;
	}

	@Bean
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_GENERIC_REPOSITORY)
	public GenericRepository iaaaProxiesGenericRepository() {
		return new GenericRepository(sessionFactory().getObject());
	}

	@Bean
	public NamedParameterJdbcTemplate getJdbcTemplate() {
		return new NamedParameterJdbcTemplate(iaaaProxiesDataSource);
	}

	@Bean
	public JdbcJsonRowMapper<BaseWorkflow> cacheWorkflowRowMapper() {
		return new JdbcJsonRowMapper<>("workflow", BaseWorkflow.class);
	}

	private Properties hibernateProperties() {
		Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty("hibernate.hbm2ddl.auto", hbm2dll);
		hibernateProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.PostgreSQL95Dialect");
		hibernateProperties.setProperty("hibernate.format_sql", "true");
		hibernateProperties.setProperty("hibernate.show_sql", showSql);
		hibernateProperties.setProperty("hibernate.temp.use_jdbc_metadata_defaults", "false");

		return hibernateProperties;
	}
}
