package bg.demax.iaaa.admin.config.property;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import bg.demax.iaaa.admin.controller.params.regdocsender.RegDocSenderFullServiceSettingsParams;
import bg.demax.iaaa.admin.controller.params.regdocsender.RegDocSenderServiceSettingsParams;

public class RegDocSenderConfigurationPropertiesRepository {

	private static final Logger logger = LogManager.getLogger(RegDocSenderConfigurationPropertiesRepository.class);

	public static final String PROPERTIES_FILE_NAME = "reg-doc-sender.properties";

	public static final String FIXED_DELAY_PROPERTY = "reg.doc.sender.fixed-delay";
	public static final String ERRORS_THRESHOLD_PROPERTY = "reg.doc.sender.errors-threshold";
	public static final String ERRORS_DELAY_BELOW_THRESHOLD_PROPERTY = "reg.doc.sender.errors-delay-below-threshold";
	public static final String ERRORS_DELAY_AFTER_THRESHOLD_PROPERTY = "reg.doc.sender.errors-delay-after-threshold";
	public static final String FROM_INSPECTION_DATE_PROPERTY = "reg.doc.sender.from-inspection-date";
	public static final String TO_INSPECTION_DATE_PROPERTY = "reg.doc.sender.to-inspection-date";
	public static final String IS_SERVICE_RUNNING_PROPERTY = "reg.doc.sender.is-service-running";

	private Properties prop = new Properties();

	private String propertiesFilePath;

	public RegDocSenderConfigurationPropertiesRepository() {
	}

	public RegDocSenderConfigurationPropertiesRepository(String propertiesFilePath) {
		this.propertiesFilePath = propertiesFilePath;
	}

	public synchronized RegDocSenderFullServiceSettingsParams loadParams() {
		RegDocSenderServiceSettingsParams params;

		try (InputStream input = new FileInputStream(propertiesFilePath + PROPERTIES_FILE_NAME)) {

			prop.load(input);

			params = new RegDocSenderServiceSettingsParams();

			params.setFixedDelay(Long.valueOf(prop.getProperty(FIXED_DELAY_PROPERTY)));
			params.setErrorsDelayBelowThreshold(Long.valueOf(prop.getProperty(ERRORS_DELAY_BELOW_THRESHOLD_PROPERTY)));
			params.setErrorsDelayAfterThreshold(Long.valueOf(prop.getProperty(ERRORS_DELAY_AFTER_THRESHOLD_PROPERTY)));
			params.setErrorsThreshold(Integer.valueOf(prop.getProperty(ERRORS_THRESHOLD_PROPERTY)));

			if (prop.getProperty(FROM_INSPECTION_DATE_PROPERTY).equals("null")) {
				params.setFromInspectionDate(null);
			} else {
				params.setFromInspectionDate(LocalDateTime.parse(prop.getProperty(FROM_INSPECTION_DATE_PROPERTY)));
			}

			if (prop.getProperty(TO_INSPECTION_DATE_PROPERTY).equals("null")) {
				params.setToInspectionDate(null);
			} else {
				params.setToInspectionDate(LocalDateTime.parse(prop.getProperty(TO_INSPECTION_DATE_PROPERTY)));
			}

			RegDocSenderFullServiceSettingsParams fullParams = new RegDocSenderFullServiceSettingsParams();
			fullParams.setRegDocSenderServiceSettingsParams(params);

			if (prop.getProperty(IS_SERVICE_RUNNING_PROPERTY).equals("null")) {
				fullParams.setIsServiceRunning(null);
			} else {
				fullParams.setIsServiceRunning(Boolean.valueOf(prop.getProperty(IS_SERVICE_RUNNING_PROPERTY)));
			}

			return fullParams;
		} catch (IOException e) {
			logger.debug("In " + RegDocSenderConfigurationPropertiesRepository.class.getSimpleName() + e.getMessage());
		}

		return null;
	}

	public synchronized void persistParams(RegDocSenderServiceSettingsParams params, boolean isServiceRunning) {

		try (OutputStream output = new FileOutputStream(propertiesFilePath + PROPERTIES_FILE_NAME)) {
			if ( params.getFixedDelay() != null) {
				prop.setProperty(FIXED_DELAY_PROPERTY, params.getFixedDelay().toString());
			}

			if (params.getErrorsThreshold() != null) {
				prop.setProperty(ERRORS_THRESHOLD_PROPERTY, params.getErrorsThreshold().toString());
			}

			if (params.getErrorsDelayBelowThreshold() != null) {
				prop.setProperty(ERRORS_DELAY_BELOW_THRESHOLD_PROPERTY, params.getErrorsDelayBelowThreshold().toString());
			}

			if (params.getErrorsDelayAfterThreshold() != null) {
				prop.setProperty(ERRORS_DELAY_AFTER_THRESHOLD_PROPERTY, params.getErrorsDelayAfterThreshold().toString());
			}

			if (params.getFromInspectionDate() != null) {
				prop.setProperty(FROM_INSPECTION_DATE_PROPERTY, params.getFromInspectionDate().toString());
			} else {
				prop.setProperty(FROM_INSPECTION_DATE_PROPERTY, "null");
			}

			if (params.getToInspectionDate() != null) {
				prop.setProperty(TO_INSPECTION_DATE_PROPERTY, params.getToInspectionDate().toString());
			} else {
				prop.setProperty(TO_INSPECTION_DATE_PROPERTY, "null");
			}

			prop.setProperty(IS_SERVICE_RUNNING_PROPERTY, String.valueOf(isServiceRunning));

			prop.store(output, null);
		} catch (Exception e) {
			logger.debug("In " + RegDocSenderConfigurationPropertiesRepository.class.getSimpleName() + e.getMessage());
		}
	}

	public void setPropertiesFilePath(String propertiesFilePath) {
		this.propertiesFilePath = propertiesFilePath;
	}
}
