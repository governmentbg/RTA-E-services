package bg.demax.iaaa.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.iaaa.admin.dto.RequestDetailsDto;
import bg.demax.iaaa.admin.service.IaaaGatewayRequestsInfoService;

@RestController
@RequestMapping("/api/iaaa-gateway/request-info")
public class IaaaGatewayRequestInfoController {

	@Autowired
	private IaaaGatewayRequestsInfoService iaaaGatewayRequestInfoService;

	@GetMapping
	public List<RequestDetailsDto> getAllIaaaGatewayRequestsInfo() {
		return iaaaGatewayRequestInfoService.getAllRequestDetails();
	}

}
