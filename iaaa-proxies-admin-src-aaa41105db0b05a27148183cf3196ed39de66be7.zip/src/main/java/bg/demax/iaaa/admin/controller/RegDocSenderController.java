package bg.demax.iaaa.admin.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.iaaa.admin.controller.params.regdocsender.RegDocSenderFullServiceSettingsParams;
import bg.demax.iaaa.admin.controller.params.regdocsender.RegDocSenderServiceSettingsParams;
import bg.demax.iaaa.admin.service.RegDocSenderService;

@RestController
@RequestMapping("/api/reg-doc-sender")
public class RegDocSenderController {

	@Autowired
	private RegDocSenderService regDocSenderService;

	@PutMapping("/service-start")
	public void startReportToIctService() {
		regDocSenderService.startService();
	}

	@PutMapping("/service-stop")
	public void stopReportToIctProxyService() {
		regDocSenderService.stopService();
	}

	@PutMapping("/service-settings")
	public void updateReportToIctProxyServiceSettings(@Valid @RequestBody RegDocSenderServiceSettingsParams params) {
		regDocSenderService.setServiceSettings(params);
	}

	@GetMapping("/service-settings")
	public RegDocSenderFullServiceSettingsParams getReportToIctProxyServiceConfigParams() {
		return regDocSenderService.getServiceCurrentConfigParams();
	}
}
