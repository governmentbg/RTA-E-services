package bg.demax.iaaa.admin.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.iaaa.admin.controller.params.VehicleInfoParam;
import bg.demax.iaaa.admin.service.VehicleInfoService;
import bg.demax.iaaa.admin.utils.pgjson.search.VehicleInfoSearch;

@RestController
@RequestMapping("/api/reports")
public class ReportsController {

	@Autowired
	private VehicleInfoService vehicleInfoService;

	@GetMapping
	public List<String> getVehicleInfoWorkflowMessageIds(@Valid VehicleInfoParam vehInfoSearchParams) {

		VehicleInfoSearch search = new VehicleInfoSearch();
		BeanUtils.copyProperties(vehInfoSearchParams, search);

		return vehicleInfoService.getVehicleInfoWorkflowMessageIds(search);
	}
}
