package bg.demax.iaaa.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.iaaa.admin.dto.VehicleResponseWithRequestCountDto;
import bg.demax.iaaa.admin.service.IctClientProxyService;
import bg.demax.ictclient.dtos.VehicleRequestDto;

@RestController
@RequestMapping("/api/vehicles")
public class VehicleRequestController {

	@Autowired
	private IctClientProxyService ictClientAdminService;

	@GetMapping
	public VehicleResponseWithRequestCountDto getVehicleResponseDto( VehicleRequestDto vehRequestDto) {
		VehicleResponseWithRequestCountDto responseDto = ictClientAdminService.getVehicleResponseDto(vehRequestDto);
		return responseDto;
	}
}
