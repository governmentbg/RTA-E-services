package bg.demax.iaaa.admin.controller.iaaagateway;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import bg.demax.iaaa.admin.controller.params.proxyrequests.RestTemplateConfigParams;
import bg.demax.iaaa.admin.dto.RestTemplateConfigDto;
import bg.demax.iaaa.admin.service.iaaagateway.IaaaGatewayRestTemplateConfigService;

@RestController
@RequestMapping("/api/iaaa-gateway/rest-template-config")
public class IaaaGatewayRestTemplateConfigController {
	@Autowired
	private IaaaGatewayRestTemplateConfigService iaaaGatewayRestTemplateConfigService;

	@GetMapping
	public List<RestTemplateConfigDto> getAllRestTemplateConfigs() {
		return iaaaGatewayRestTemplateConfigService.getAllRestTemplateConfigs();
	}

	@GetMapping("/{id}")
	public RestTemplateConfigDto getRestTemplateConfigById(@PathVariable("id") Integer restTemplateConfigId) {
		return iaaaGatewayRestTemplateConfigService.getRestTemplateConfig(restTemplateConfigId);
	}

	@PostMapping
	public Integer saveOrUpdateRestTemplateConfig(
			@RequestPart("restTemplateParams") @Valid RestTemplateConfigParams restTemplateConfigParams,
			@RequestPart(name = "keyStore", required = false) MultipartFile keyStore,
			@RequestPart(name = "trustStore", required = false) MultipartFile trustStore) {

		Integer rtId = iaaaGatewayRestTemplateConfigService.saveOrUpdate(restTemplateConfigParams, keyStore, trustStore).getId();

		return rtId;
	}

	@DeleteMapping("/{id}")
	public void deleteRestTemplateConfig(@PathVariable("id") Integer restTemplateConfigId) {
		iaaaGatewayRestTemplateConfigService.deleteRestTemplateConfig(restTemplateConfigId);
	}

	@GetMapping("/certificate/{id}")
	public ResponseEntity<byte[]> getCertificate(@PathVariable("id") int certificateId) {
		return iaaaGatewayRestTemplateConfigService.getCertificateForDownload(certificateId);
	}

}
