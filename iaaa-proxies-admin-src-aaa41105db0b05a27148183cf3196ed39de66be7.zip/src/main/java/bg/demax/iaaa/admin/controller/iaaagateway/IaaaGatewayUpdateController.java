package bg.demax.iaaa.admin.controller.iaaagateway;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.iaaa.admin.service.iaaagateway.IaaaGatewayUpdateService;

@RestController
@RequestMapping("/api/iaaa-gateway/update")
public class IaaaGatewayUpdateController {

	@Autowired
	private IaaaGatewayUpdateService iaaaGatewayUpdateService;

	@PutMapping("/proxy-request-details/{id}")
	public void updateIaaaGatewayProxyRequestDetails(@PathVariable("id") Integer configId) {
		iaaaGatewayUpdateService.updateIaaaGatewayRequestProxyDetails(configId);
	}

}
