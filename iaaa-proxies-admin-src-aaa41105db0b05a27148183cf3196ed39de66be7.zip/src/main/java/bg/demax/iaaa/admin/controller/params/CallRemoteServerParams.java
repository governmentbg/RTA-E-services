package bg.demax.iaaa.admin.controller.params;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class CallRemoteServerParams {

	@Pattern(regexp = "^/.*$")
	@NotNull
	private String endpoint;

	@NotNull
	private String method;

	@NotNull
	private String remoteApp;

	@Nullable
	@JsonInclude(Include.NON_NULL)
	private Integer id;

	@Nullable
	private String requestBody;

	@Nullable
	private String requestBodyType;

	@Nullable
	private List<HeaderEntry> headerEntries;

	public String getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getRemoteApp() {
		return remoteApp;
	}

	public void setRemoteApp(String remoteApp) {
		this.remoteApp = remoteApp;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}

	public String getRequestBodyType() {
		return requestBodyType;
	}

	public void setRequestBodyType(String requestBodyType) {
		this.requestBodyType = requestBodyType;
	}

	public List<HeaderEntry> getHeaderEntries() {
		return headerEntries;
	}

	public void setHeaderEntries(List<HeaderEntry> headerEntries) {
		this.headerEntries = headerEntries;
	}

}
