package bg.demax.iaaa.admin.controller.params;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;
import bg.demax.iaaa.admin.utils.validators.ValidDateRange;

@ValidDateRange(start = "requestTimeFrom", end = "requestTimeTo", unit = ChronoUnit.DAYS, maxPeriod = 10)
public class VehicleInfoParam {
	@NotNull
	@DateTimeFormat(pattern = IaaaProxiesAdminWebConstants.DATE_TIME_FORMAT)
	private LocalDateTime requestTimeFrom;

	@NotNull
	@DateTimeFormat(pattern = IaaaProxiesAdminWebConstants.DATE_TIME_FORMAT)
	private LocalDateTime requestTimeTo;

	private String vehOwnerId;

	private String vehDocumentNumber;

	private String vehRegistrationNumber;

	@Min(1)
	@Max(3)
	private Integer vehicleOwnerVerification;

	@Min(0)
	private Integer returnCode;

	public LocalDateTime getRequestTimeFrom() {
		return requestTimeFrom;
	}

	public void setRequestTimeFrom(LocalDateTime requestTimeFrom) {
		this.requestTimeFrom = requestTimeFrom;
	}

	public LocalDateTime getRequestTimeTo() {
		return requestTimeTo;
	}

	public void setRequestTimeTo(LocalDateTime requestTimeTo) {
		this.requestTimeTo = requestTimeTo;
	}

	public String getVehOwnerId() {
		return vehOwnerId;
	}

	public void setVehOwnerId(String vehOwnerId) {
		this.vehOwnerId = vehOwnerId;
	}

	public String getVehDocumentNumber() {
		return vehDocumentNumber;
	}

	public void setVehDocumentNumber(String vehDocumentNumber) {
		this.vehDocumentNumber = vehDocumentNumber;
	}

	public String getVehRegistrationNumber() {
		return vehRegistrationNumber;
	}

	public void setVehRegistrationNumber(String vehRegistrationNumber) {
		this.vehRegistrationNumber = vehRegistrationNumber;
	}

	public Integer getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(Integer returnCode) {
		this.returnCode = returnCode;
	}

	public Integer getVehicleOwnerVerification() {
		return vehicleOwnerVerification;
	}

	public void setVehicleOwnerVerification(Integer vehicleOwnerVerification) {
		this.vehicleOwnerVerification = vehicleOwnerVerification;
	}
}
