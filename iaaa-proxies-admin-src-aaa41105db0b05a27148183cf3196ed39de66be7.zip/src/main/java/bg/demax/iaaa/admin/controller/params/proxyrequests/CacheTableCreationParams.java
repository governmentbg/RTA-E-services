package bg.demax.iaaa.admin.controller.params.proxyrequests;

import javax.validation.constraints.NotBlank;

public class CacheTableCreationParams {

	@NotBlank
	private String tableName;

	@NotBlank
	private String description;

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
