package bg.demax.iaaa.admin.controller.params.proxyrequests;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class ProxyRequestParams {

	private Integer id;

	@NotBlank
	private String localPath;

	@NotBlank
	private String remoteUrl;

	@NotBlank
	private String httpMethod;

	@NotBlank
	private String cacheTableName;

	private String description;

	@NotNull
	private Boolean isEnabled;

	@NotNull
	private Integer restTemplateConfigId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLocalPath() {
		return localPath;
	}

	public void setLocalPath(String localPath) {
		this.localPath = localPath;
	}

	public String getRemoteUrl() {
		return remoteUrl;
	}

	public void setRemoteUrl(String remoteUrl) {
		this.remoteUrl = remoteUrl;
	}

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	public String getCacheTableName() {
		return cacheTableName;
	}

	public void setCacheTableName(String cacheTableName) {
		this.cacheTableName = cacheTableName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getIsEnabled() {
		return isEnabled;
	}

	public void setIsEnabled(Boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	public Integer getRestTemplateConfigId() {
		return restTemplateConfigId;
	}

	public void setRestTemplateConfigId(Integer restTemplateConfigId) {
		this.restTemplateConfigId = restTemplateConfigId;
	}
}
