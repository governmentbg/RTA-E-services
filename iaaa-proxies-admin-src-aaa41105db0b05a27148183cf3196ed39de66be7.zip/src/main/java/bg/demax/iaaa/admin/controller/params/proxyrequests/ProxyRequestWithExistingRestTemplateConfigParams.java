package bg.demax.iaaa.admin.controller.params.proxyrequests;

import javax.validation.constraints.NotNull;

public class ProxyRequestWithExistingRestTemplateConfigParams extends ProxyRequestParams {

	@NotNull
	private Integer restTemplateConfigId;

	public Integer getRestTemplateConfigId() {
		return restTemplateConfigId;
	}

	public void setRestTemplateConfigId(Integer restTemplateConfigId) {
		this.restTemplateConfigId = restTemplateConfigId;
	}

}
