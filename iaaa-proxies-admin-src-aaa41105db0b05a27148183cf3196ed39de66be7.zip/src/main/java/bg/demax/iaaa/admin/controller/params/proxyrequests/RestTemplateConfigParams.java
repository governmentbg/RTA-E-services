package bg.demax.iaaa.admin.controller.params.proxyrequests;

public class RestTemplateConfigParams {

	private Integer id;

	private String description;

	private SSLCertificateDetailsParams keyStore;

	private SSLCertificateDetailsParams trustStore;

	private Short readTimeout;

	private Short connectionTimeout;

	private String basicAuthUsername;

	private String basicAuthPassword;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public SSLCertificateDetailsParams getKeyStore() {
		return keyStore;
	}

	public void setKeyStore(SSLCertificateDetailsParams keyStore) {
		this.keyStore = keyStore;
	}

	public SSLCertificateDetailsParams getTrustStore() {
		return trustStore;
	}

	public void setTrustStore(SSLCertificateDetailsParams trustStore) {
		this.trustStore = trustStore;
	}

	public Short getReadTimeout() {
		return readTimeout;
	}

	public void setReadTimeout(Short readTimeout) {
		this.readTimeout = readTimeout;
	}

	public Short getConnectionTimeout() {
		return connectionTimeout;
	}

	public void setConnectionTimeout(Short connectionTimeout) {
		this.connectionTimeout = connectionTimeout;
	}

	public String getBasicAuthUsername() {
		return basicAuthUsername;
	}

	public void setBasicAuthUsername(String basicAuthUsername) {
		this.basicAuthUsername = basicAuthUsername;
	}

	public String getBasicAuthPassword() {
		return basicAuthPassword;
	}

	public void setBasicAuthPassword(String basicAuthPassword) {
		this.basicAuthPassword = basicAuthPassword;
	}

}