package bg.demax.iaaa.admin.controller.params.regdocsender;

public class RegDocSenderFullServiceSettingsParams {

	private RegDocSenderServiceSettingsParams regDocSenderServiceSettingsParams;
	private Boolean isServiceRunning;

	public RegDocSenderServiceSettingsParams getRegDocSenderServiceSettingsParams() {
		return regDocSenderServiceSettingsParams;
	}

	public void setRegDocSenderServiceSettingsParams(RegDocSenderServiceSettingsParams regDocSenderServiceSettingsParams) {
		this.regDocSenderServiceSettingsParams = regDocSenderServiceSettingsParams;
	}

	public Boolean getIsServiceRunning() {
		return isServiceRunning;
	}

	public void setIsServiceRunning(Boolean isServiceRunning) {
		this.isServiceRunning = isServiceRunning;
	}

}
