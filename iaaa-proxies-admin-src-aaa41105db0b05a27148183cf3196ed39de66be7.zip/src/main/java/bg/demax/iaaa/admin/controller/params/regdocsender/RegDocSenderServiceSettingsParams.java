package bg.demax.iaaa.admin.controller.params.regdocsender;

import java.time.LocalDateTime;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;

public class RegDocSenderServiceSettingsParams {
	@Min(0)
	@NotNull
	private Long fixedDelay;

	@DateTimeFormat(pattern = IaaaProxiesAdminWebConstants.DATE_TIME_FORMAT)
	private LocalDateTime fromInspectionDate;

	@DateTimeFormat(pattern = IaaaProxiesAdminWebConstants.DATE_TIME_FORMAT)
	private LocalDateTime toInspectionDate;

	@Min(0)
	@NotNull
	private Integer errorsThreshold;

	@Min(0)
	@NotNull
	private Long errorsDelayBelowThreshold;

	@Min(0)
	@NotNull
	private Long errorsDelayAfterThreshold;

	public Long getFixedDelay() {
		return fixedDelay;
	}

	public void setFixedDelay(Long fixedDelay) {
		this.fixedDelay = fixedDelay;
	}

	public LocalDateTime getFromInspectionDate() {
		return fromInspectionDate;
	}

	public void setFromInspectionDate(LocalDateTime fromInspectionDate) {
		this.fromInspectionDate = fromInspectionDate;
	}

	public LocalDateTime getToInspectionDate() {
		return toInspectionDate;
	}

	public void setToInspectionDate(LocalDateTime toInspectionDate) {
		this.toInspectionDate = toInspectionDate;
	}

	public Integer getErrorsThreshold() {
		return errorsThreshold;
	}

	public void setErrorsThreshold(Integer errorsThreshold) {
		this.errorsThreshold = errorsThreshold;
	}

	public Long getErrorsDelayBelowThreshold() {
		return errorsDelayBelowThreshold;
	}

	public void setErrorsDelayBelowThreshold(Long errorsDelayBelowThreshold) {
		this.errorsDelayBelowThreshold = errorsDelayBelowThreshold;
	}

	public Long getErrorsDelayAfterThreshold() {
		return errorsDelayAfterThreshold;
	}

	public void setErrorsDelayAfterThreshold(Long errorsDelayAfterThreshold) {
		this.errorsDelayAfterThreshold = errorsDelayAfterThreshold;
	}

}
