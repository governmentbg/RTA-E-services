package bg.demax.iaaa.admin.controller.remote;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.iaaa.admin.controller.params.CallRemoteServerParams;
import bg.demax.iaaa.admin.dto.security.RespWrp;
import bg.demax.iaaa.admin.exception.RemoteServerException;
import bg.demax.iaaa.admin.service.RemoteServersCallService;

@RestController
@RequestMapping("/api/remote-server-call")
public class RemoteServersCallController {

	@Autowired
	private RemoteServersCallService service;

	@PostMapping
	public RespWrp callRemoteServer(@Valid @RequestBody CallRemoteServerParams params) {
		try {
			ResponseEntity<String> resp = service.callRemoteServer(params);

			return new RespWrp(resp.getStatusCodeValue(), resp.getBody());
		} catch (RemoteServerException ex) {
			return new RespWrp(ex.getStatusCode(), ex.getResponseBody());
		}
	}

	@PostMapping("/params")
	public Integer saveOrUpdate(@Valid @RequestBody CallRemoteServerParams params) {
		return service.saveOrUpdate(params);
	}

	@GetMapping("/params")
	public List<CallRemoteServerParams> getAll() {
		return service.findAll();
	}

	@GetMapping("/params/{id}")
	public CallRemoteServerParams getById(@PathVariable("id") Integer id) {
		return service.findById(id);
	}

	@DeleteMapping("/params/{id}")
	public void delete(@PathVariable("id") Integer id) {
		service.delete(id);
	}
}