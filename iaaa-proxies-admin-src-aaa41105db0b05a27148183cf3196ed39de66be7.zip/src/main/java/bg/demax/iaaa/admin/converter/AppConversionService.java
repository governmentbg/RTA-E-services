package bg.demax.iaaa.admin.converter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.convert.support.GenericConversionService;
import org.springframework.stereotype.Service;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;

@Service
public class AppConversionService {
	@Autowired
	@Qualifier(BeanQualifierConstants.DEFAULT_SPRING_BOOT_CONVERSION_SERVICE)
	private GenericConversionService genericConversionService;

	public <FROM_SOURCE, TO_TYPE> TO_TYPE convert(FROM_SOURCE from, Class<TO_TYPE> toType) {
		return genericConversionService.convert(from, toType);
	}

	public <T, K> List<T> convertList(List<K> items, Class<T> toType) {
		List<T> toList = new ArrayList<>();
		convertCollection(items, toList, toType);
		return toList;
	}

	public <T, K> Set<T> convertSet(Set<K> items, Class<T> toType) {
		Set<T> toSet = new LinkedHashSet<>();
		convertCollection(items, toSet, toType);
		return toSet;
	}

	private <T, K> void convertCollection(Collection<K> items, Collection<T> toItems, Class<T> toType) {
		for (K item : items) {
			T convertedItem = convert(item, toType);
			toItems.add(convertedItem);
		}
	}
}
