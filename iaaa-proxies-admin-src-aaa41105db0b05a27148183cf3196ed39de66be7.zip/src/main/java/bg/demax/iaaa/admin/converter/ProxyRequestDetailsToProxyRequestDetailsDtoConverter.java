package bg.demax.iaaa.admin.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.admin.db.entity.iaaaproxies.ProxyRequestDetails;
import bg.demax.iaaa.admin.dto.ProxyRequestDetailsDto;

@Component
public class ProxyRequestDetailsToProxyRequestDetailsDtoConverter implements Converter<ProxyRequestDetails, ProxyRequestDetailsDto> {

	@Override
	public ProxyRequestDetailsDto convert(ProxyRequestDetails source) {
		ProxyRequestDetailsDto dto = new ProxyRequestDetailsDto();

		dto.setId(source.getId());
		dto.setLocalPath(source.getLocalPath());
		dto.setRemoteUrl(source.getRemoteUrl());
		dto.setHttpMethod(source.getHttpMethod());
		dto.setCacheTableName(source.getCacheTableName());
		dto.setIsEnabled(source.getIsEnabled());
		dto.setDescription(source.getDescription());
		dto.setRestTemplateConfigId(source.getRestTemplateConfig().getId());

		return dto;
	}

}
