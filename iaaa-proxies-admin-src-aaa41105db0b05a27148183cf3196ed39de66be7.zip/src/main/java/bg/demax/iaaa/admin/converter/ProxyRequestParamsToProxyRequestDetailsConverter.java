package bg.demax.iaaa.admin.converter;


import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.admin.controller.params.proxyrequests.ProxyRequestParams;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.ProxyRequestDetails;

@Component
public class ProxyRequestParamsToProxyRequestDetailsConverter implements Converter<ProxyRequestParams, ProxyRequestDetails> {

	@Override
	public ProxyRequestDetails convert(ProxyRequestParams source) {
		ProxyRequestDetails proxyRequestDetails = new ProxyRequestDetails();

		proxyRequestDetails.setId(source.getId());
		proxyRequestDetails.setLocalPath(source.getLocalPath());
		proxyRequestDetails.setRemoteUrl(source.getRemoteUrl());
		proxyRequestDetails.setHttpMethod(source.getHttpMethod());
		proxyRequestDetails.setCacheTableName(source.getCacheTableName());
		proxyRequestDetails.setDescription(source.getDescription());
		proxyRequestDetails.setIsEnabled(source.getIsEnabled());

		return proxyRequestDetails;
	}

}