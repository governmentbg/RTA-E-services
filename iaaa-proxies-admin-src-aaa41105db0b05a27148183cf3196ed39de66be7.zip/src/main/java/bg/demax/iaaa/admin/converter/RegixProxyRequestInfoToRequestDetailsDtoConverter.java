package bg.demax.iaaa.admin.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.admin.db.entity.iaaaproxies.RegixProxyRequestInfo;
import bg.demax.iaaa.admin.dto.RequestDetailsDto;

@Component
public class RegixProxyRequestInfoToRequestDetailsDtoConverter implements Converter<RegixProxyRequestInfo, RequestDetailsDto> {

	@Override
	public RequestDetailsDto convert(RegixProxyRequestInfo source) {
		RequestDetailsDto dto = new RequestDetailsDto();

		dto.setId(source.getId());
		dto.setName(source.getName());
		dto.setPath(source.getPath());
		dto.setHttpMethod(source.getHttpMethod());

		return dto;
	}

}
