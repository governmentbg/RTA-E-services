package bg.demax.iaaa.admin.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.admin.db.entity.iaaaproxies.RestTemplateConfig;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.SSLCertificateDetails;
import bg.demax.iaaa.admin.dto.RestTemplateConfigDto;
import bg.demax.iaaa.admin.dto.SSLCertificateDetailsDto;

@Component
public class RestTemplateConfigToRestTemplateConfigDtoConverter implements Converter<RestTemplateConfig, RestTemplateConfigDto> {

	@Autowired
	private AppConversionService conversionService;

	@Override
	public RestTemplateConfigDto convert(RestTemplateConfig source) {
		RestTemplateConfigDto configDto = new RestTemplateConfigDto();

		configDto.setId(source.getId());
		configDto.setDescription(source.getDescription());
		configDto.setReadTimeout(source.getReadTimeout());
		configDto.setConnectionTimeout(source.getConnectionTimeout());

		configDto.setBasicAuthPassword(source.getBasicAuthPassword());
		configDto.setBasicAuthUsername(source.getBasicAuthUsername());

		SSLCertificateDetails keyStore = source.getKeyStore();
		if (keyStore != null) {
			SSLCertificateDetailsDto keyStoreDto = conversionService.convert(keyStore, SSLCertificateDetailsDto.class);
			configDto.setKeyStore(keyStoreDto);
		}

		SSLCertificateDetails trustStore = source.getTrustStore();
		if (trustStore != null) {
			SSLCertificateDetailsDto trustStoreDto = conversionService.convert(trustStore, SSLCertificateDetailsDto.class);
			configDto.setTrustStore(trustStoreDto);
		}

		return configDto;
	}

}
