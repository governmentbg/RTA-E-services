package bg.demax.iaaa.admin.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.admin.db.entity.iaaaproxies.SSLCertificateDetails;
import bg.demax.iaaa.admin.dto.SSLCertificateDetailsDto;

@Component
public class SSLCertificateDetailsToSSLCertificateDetailsDtoConverter implements Converter<SSLCertificateDetails, SSLCertificateDetailsDto> {

	@Override
	public SSLCertificateDetailsDto convert(SSLCertificateDetails source) {
		SSLCertificateDetailsDto certDetailsDto = new SSLCertificateDetailsDto();
		certDetailsDto.setId(source.getId());
		certDetailsDto.setName(source.getName());
		certDetailsDto.setPassword(source.getPassword());
		certDetailsDto.setValidTo(source.getValidTo());
		certDetailsDto.setType(source.getType());
		certDetailsDto.setDescription(source.getDescription());

		certDetailsDto.setCertDataId(source.getCertData().getId());

		return certDetailsDto;
	}

}
