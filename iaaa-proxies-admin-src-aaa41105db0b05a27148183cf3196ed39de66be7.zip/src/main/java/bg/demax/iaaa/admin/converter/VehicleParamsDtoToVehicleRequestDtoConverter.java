package bg.demax.iaaa.admin.converter;

import java.math.BigInteger;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.admin.dto.VehicleParamsDto;
import bg.demax.ictclient.dtos.VehicleRequestDto;

@Component
public class VehicleParamsDtoToVehicleRequestDtoConverter implements Converter<VehicleParamsDto, VehicleRequestDto> {

	private static final String NEW_DOC_TYPE = "1";
	private static final String OLD_DOC_TYPE = "2";

	@Override
	public VehicleRequestDto convert(VehicleParamsDto source) {
		VehicleRequestDto vehicleRequestDto = new VehicleRequestDto();
		vehicleRequestDto.setOwnerId(source.getOwnerId());
		vehicleRequestDto.setVehicleDocumentNumber(source.getVehicleDocumentNumber());
		vehicleRequestDto.setVehicleRegistrationNumber(source.getVehicleRegistrationNumber());

		if (source.getVehicleDocumentNumber().matches("^[\\d]{9}$")) {
			vehicleRequestDto.setDocumentType(new BigInteger(NEW_DOC_TYPE));
		} else {
			vehicleRequestDto.setDocumentType(new BigInteger(OLD_DOC_TYPE));
		}

		return vehicleRequestDto;
	}
}
