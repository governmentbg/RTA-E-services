package bg.demax.iaaa.admin.db.entity.constants;

public interface DbSchemas {

	//iaaa db
	String PUBLIC = "public";
	String SECURITY = "security";
	String TECHINSP = "techinsp";

	//iaaa proxies db
	String IAAA_GATEWAY = "iaaa_gateway";
	String IAAA_PROXIES_ADMIN = "iaaa_proxies_admin";
}
