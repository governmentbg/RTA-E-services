package bg.demax.iaaa.admin.db.entity.constants;

public interface DbSequences {

	String USER_ID_SEQ = "seq_user_id";
	String INSPECTION_ID_SEQ = "seq_inspections_id";
	String RVS_VERSION_ID_SEQ = "seq_rvs_versions_id";
	String SUBJECT_ID_SEQ = "seq_subjects_id";
	String L_REG_DOC_NUM_ID_SEQ = "l_reg_doc_nums_seq";
}
