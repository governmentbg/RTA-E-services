package bg.demax.iaaa.admin.db.entity.constants;

public interface DbTables {

	//iaaa db
	String AUTHORITIES = "authorities";
	String USERS = "users";
	String USERS_AUTHORITIES = "users_authorities";
	String INSPECTIONS = "inspections";
	String RVS_VERSIONS = "rvs_versions";
	String SUBJECTS = "subjects";
	String L_REG_DOC_NUMS = "l_reg_doc_nums";

	//iaaa proxies db
	String SSL_CERTIFICATES_DATA = "ssl_certificates_data";
	String SSL_CERTIFICATE_DETAILS = "ssl_certificate_details";
	String REST_TEMPLATE_CONFIGS = "rest_template_configs";
	String PROXY_REQUEST_DETAILS = "proxy_request_details";
	String REGIX_PROXY_REQUESTS_INFO = "regix_proxy_requests_info";
	String IAAA_GATEWAY_REQUESTS_INFO = "iaaa_gateway_requests_info";
	String IAAA_PROXIES_ADMIN_PREPARED_REQUESTS = "prepared_requests";
}
