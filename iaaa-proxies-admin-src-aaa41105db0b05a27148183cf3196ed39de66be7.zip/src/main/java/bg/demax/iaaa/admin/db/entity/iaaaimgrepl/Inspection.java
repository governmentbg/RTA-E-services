package bg.demax.iaaa.admin.db.entity.iaaaimgrepl;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import bg.demax.iaaa.admin.db.entity.constants.DbSchemas;
import bg.demax.iaaa.admin.db.entity.constants.DbSequences;
import bg.demax.iaaa.admin.db.entity.constants.DbTables;

@Entity
@Table(schema = DbSchemas.TECHINSP, name = DbTables.INSPECTIONS)
public class Inspection {

	private static final String INSPECTION_ID_SEQ = "inspection_id_generator";

	@Id
	@Column(name = "id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = INSPECTION_ID_SEQ)
	@SequenceGenerator(name = INSPECTION_ID_SEQ, schema = DbSchemas.TECHINSP, sequenceName = DbSequences.INSPECTION_ID_SEQ, allocationSize = 1)
	private Long id;

	@ManyToOne
	@JoinColumn(name = "rvsver_id")
	private RvsVersion rvsVersion;

	@Column(name = "insp_datetime")
	private LocalDateTime inspectionDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public RvsVersion getRvsVersion() {
		return rvsVersion;
	}

	public void setRvsVersion(RvsVersion rvsVersion) {
		this.rvsVersion = rvsVersion;
	}

}
