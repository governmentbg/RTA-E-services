package bg.demax.iaaa.admin.db.entity.iaaaimgrepl;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import bg.demax.iaaa.admin.db.entity.constants.DbSchemas;
import bg.demax.iaaa.admin.db.entity.constants.DbSequences;
import bg.demax.iaaa.admin.db.entity.constants.DbTables;

@Entity
@Table(schema = DbSchemas.PUBLIC, name = DbTables.L_REG_DOC_NUMS)
public class RegDocNum {

	private static final String L_REG_DOC_NUM_ID_SEQ = "l_reg_doc_id_generator";

	@Id
	@Column(name = "id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = L_REG_DOC_NUM_ID_SEQ)
	@SequenceGenerator(name = L_REG_DOC_NUM_ID_SEQ, schema = DbSchemas.TECHINSP, sequenceName = DbSequences.L_REG_DOC_NUM_ID_SEQ, allocationSize = 1)
	private Long id;

	@ManyToOne
	@JoinColumn(name = "inspection_id")
	private Inspection inspection;

	@Column(name = "reg_doc_num")
	private String vehicleDocumentNumber;

	@Column(name = "last_ict_request")
	private LocalDateTime lastIctRequest;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Inspection getInspection() {
		return inspection;
	}

	public void setInspection(Inspection inspection) {
		this.inspection = inspection;
	}

	public String getVehicleDocumentNumber() {
		return vehicleDocumentNumber;
	}

	public void setVehicleDocumentNumber(String vehicleDocumentNumber) {
		this.vehicleDocumentNumber = vehicleDocumentNumber;
	}

	public LocalDateTime getLastIctRequest() {
		return lastIctRequest;
	}

	public void setLastIctRequest(LocalDateTime lastIctRequest) {
		this.lastIctRequest = lastIctRequest;
	}

}
