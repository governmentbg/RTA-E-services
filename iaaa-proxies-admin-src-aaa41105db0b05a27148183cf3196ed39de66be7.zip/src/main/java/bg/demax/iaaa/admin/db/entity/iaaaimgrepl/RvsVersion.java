package bg.demax.iaaa.admin.db.entity.iaaaimgrepl;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import bg.demax.iaaa.admin.db.entity.constants.DbSchemas;
import bg.demax.iaaa.admin.db.entity.constants.DbSequences;
import bg.demax.iaaa.admin.db.entity.constants.DbTables;

@Entity
@Table(schema = DbSchemas.PUBLIC, name = DbTables.RVS_VERSIONS)
public class RvsVersion {

	private static final String RVS_VERSION_ID_SEQ = "rvs_version_id_generator";

	@Id
	@Column(name = "id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = RVS_VERSION_ID_SEQ)
	@SequenceGenerator(name = RVS_VERSION_ID_SEQ, schema = DbSchemas.PUBLIC, sequenceName = DbSequences.RVS_VERSION_ID_SEQ, allocationSize = 1)
	private Long id;

	@Column(name = "a_reg_num")
	private String vehicleRegistrationNumber;

	@ManyToOne
	@JoinColumn(name = "c2_subj_owner")
	private Subject subject;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getVehicleRegistrationNumber() {
		return vehicleRegistrationNumber;
	}

	public void setVehicleRegistrationNumber(String vehicleRegistrationNumber) {
		this.vehicleRegistrationNumber = vehicleRegistrationNumber;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

}
