package bg.demax.iaaa.admin.db.entity.iaaaimgrepl;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import bg.demax.iaaa.admin.db.entity.constants.DbSchemas;
import bg.demax.iaaa.admin.db.entity.constants.DbSequences;
import bg.demax.iaaa.admin.db.entity.constants.DbTables;

@Entity
@Table(schema = DbSchemas.PUBLIC, name = DbTables.SUBJECTS)
public class Subject {

	private static final String SUBJECT_ID_SEQ = "subject_id_generator";

	@Id
	@Column(name = "id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = SUBJECT_ID_SEQ)
	@SequenceGenerator(name = SUBJECT_ID_SEQ, schema = DbSchemas.PUBLIC, sequenceName = DbSequences.SUBJECT_ID_SEQ, allocationSize = 1)
	private Long id;

	@Column(name = "ident_num")
	private String identityNumber;

}
