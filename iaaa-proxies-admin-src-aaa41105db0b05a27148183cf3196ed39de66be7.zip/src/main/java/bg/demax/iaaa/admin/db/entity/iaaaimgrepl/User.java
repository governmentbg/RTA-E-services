package bg.demax.iaaa.admin.db.entity.iaaaimgrepl;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import bg.demax.iaaa.admin.db.entity.constants.DbSchemas;
import bg.demax.iaaa.admin.db.entity.constants.DbSequences;
import bg.demax.iaaa.admin.db.entity.constants.DbTables;

@Entity
@Table(schema = DbSchemas.SECURITY, name = DbTables.USERS)
public class User {
	private static final String USER_ID_SEQ = "user_id_generator";

	@Id
	@Column(name = "user_id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = USER_ID_SEQ)
	@SequenceGenerator(name = USER_ID_SEQ, schema = DbSchemas.SECURITY, sequenceName = DbSequences.USER_ID_SEQ, allocationSize = 1)
	private Integer userId;

	@Column(name = "username", unique = true, nullable = false)
	private String username;

	@Column(name = "password", length = 255)
	private String password;

	@Column(name = "enabled", nullable = false)
	private Boolean enabled;

	@ManyToMany
	@JoinTable(schema = DbSchemas.SECURITY, name = DbTables.USERS_AUTHORITIES,
					joinColumns = { @JoinColumn(name = "user_id", nullable = false) },
					inverseJoinColumns = { @JoinColumn(name = "authority_id", nullable = false) })
	private Set<Authority> authorities;

	public User() {

	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	public Set<Authority> getAuthorities() {
		return authorities;
	}

	public void setAuthorities(Set<Authority> authorities) {
		this.authorities = authorities;
	}

	public static String getUserIdSeq() {
		return USER_ID_SEQ;
	}
}
