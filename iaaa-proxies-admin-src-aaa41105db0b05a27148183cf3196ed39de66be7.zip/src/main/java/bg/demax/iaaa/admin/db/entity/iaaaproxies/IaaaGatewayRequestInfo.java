package bg.demax.iaaa.admin.db.entity.iaaaproxies;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.iaaa.admin.db.entity.constants.DbSchemas;
import bg.demax.iaaa.admin.db.entity.constants.DbTables;

@Entity
@Table(schema = DbSchemas.IAAA_PROXIES_ADMIN, name = DbTables.IAAA_GATEWAY_REQUESTS_INFO)
public class IaaaGatewayRequestInfo {

	@Id
	@Column(name = "id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "name", nullable = false)
	private String name;

	@Column(name = "path", nullable = false)
	private String path;

	@Column(name = "http_method", nullable = false)
	private String httpMethod;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

}
