package bg.demax.iaaa.admin.db.entity.iaaaproxies;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.iaaa.admin.db.entity.constants.DbSchemas;
import bg.demax.iaaa.admin.db.entity.constants.DbTables;

@Entity
@Table(schema = DbSchemas.IAAA_GATEWAY, name = DbTables.PROXY_REQUEST_DETAILS)
public class ProxyRequestDetails {

	@Id
	@Column(name = "id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "local_path", nullable = false)
	private String localPath;

	@Column(name = "remote_url", nullable = false)
	private String remoteUrl;

	@Column(name = "http_method", nullable = false)
	private String httpMethod;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "rest_template_config_id", nullable = false)
	private RestTemplateConfig restTemplateConfig;

	@Column(name = "cache_table_name", nullable = false)
	private String cacheTableName;

	@Column(name = "is_enabled", nullable = false)
	private Boolean isEnabled;

	@Column(name = "description")
	private String description;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLocalPath() {
		return localPath;
	}

	public void setLocalPath(String localPath) {
		this.localPath = localPath;
	}

	public String getRemoteUrl() {
		return remoteUrl;
	}

	public void setRemoteUrl(String remoteUrl) {
		this.remoteUrl = remoteUrl;
	}

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	public RestTemplateConfig getRestTemplateConfig() {
		return restTemplateConfig;
	}

	public void setRestTemplateConfig(RestTemplateConfig restTemplateConfig) {
		this.restTemplateConfig = restTemplateConfig;
	}

	public String getCacheTableName() {
		return cacheTableName;
	}

	public void setCacheTableName(String cacheTableName) {
		this.cacheTableName = cacheTableName;
	}

	public Boolean getIsEnabled() {
		return isEnabled;
	}

	public void setIsEnabled(Boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}