package bg.demax.iaaa.admin.db.entity.iaaaproxies;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.iaaa.admin.db.entity.constants.DbSchemas;
import bg.demax.iaaa.admin.db.entity.constants.DbTables;

@Entity
@Table(schema = DbSchemas.IAAA_GATEWAY, name = DbTables.REST_TEMPLATE_CONFIGS)
public class RestTemplateConfig {

	@Id
	@Column(name = "id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "description", nullable = false)
	private String description;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "keystore_details_id")
	private SSLCertificateDetails keyStore;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "truststore_details_id")
	private SSLCertificateDetails trustStore;

	@Column(name = "read_timeout")
	private Short readTimeout;

	@Column(name = "connection_timeout")
	private Short connectionTimeout;

	@Column(name = "basic_auth_username")
	private String basicAuthUsername;

	@Column(name = "basic_auth_password")
	private String basicAuthPassword;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public SSLCertificateDetails getKeyStore() {
		return keyStore;
	}

	public void setKeyStore(SSLCertificateDetails keyStore) {
		this.keyStore = keyStore;
	}

	public SSLCertificateDetails getTrustStore() {
		return trustStore;
	}

	public void setTrustStore(SSLCertificateDetails trustStore) {
		this.trustStore = trustStore;
	}

	public Short getReadTimeout() {
		return readTimeout;
	}

	public void setReadTimeout(Short readTimeout) {
		this.readTimeout = readTimeout;
	}

	public Short getConnectionTimeout() {
		return connectionTimeout;
	}

	public void setConnectionTimeout(Short connectionTimeout) {
		this.connectionTimeout = connectionTimeout;
	}

	public String getBasicAuthUsername() {
		return basicAuthUsername;
	}

	public void setBasicAuthUsername(String basicAuthUsername) {
		this.basicAuthUsername = basicAuthUsername;
	}

	public String getBasicAuthPassword() {
		return basicAuthPassword;
	}

	public void setBasicAuthPassword(String basicAuthPassword) {
		this.basicAuthPassword = basicAuthPassword;
	}

}
