package bg.demax.iaaa.admin.db.mappers;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.RowMapper;

import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;

public final class JdbcJsonRowMapper<T> implements RowMapper<T> {

	private final String jsonWorkflowColumnName;

	private final Class<T> typeParameterClass;

	@Autowired
	@Qualifier(BeanQualifierConstants.POSTGRE_JSON_OBJECT_MAPPER)
	private ObjectMapper postgreJsonMapper;

	public JdbcJsonRowMapper(String jsonWorkflowColumnName, Class<T> typeParameterClass) {
		this.jsonWorkflowColumnName = jsonWorkflowColumnName;
		this.typeParameterClass = typeParameterClass;
	}

	@Override
	public T mapRow(ResultSet rs, int i) throws SQLException {
		T workflow = null;
		try {
			workflow = postgreJsonMapper.readValue(rs.getString(jsonWorkflowColumnName), typeParameterClass);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return workflow;
	}
}
