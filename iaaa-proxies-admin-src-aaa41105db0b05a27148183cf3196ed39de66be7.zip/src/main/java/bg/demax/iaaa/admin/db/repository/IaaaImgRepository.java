package bg.demax.iaaa.admin.db.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.dto.VehicleParamsDto;

@Repository
public class IaaaImgRepository {

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_IMG_REPLICATION_SESSION_FACTORY)
	private SessionFactory sessionFactory;

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_IMG_DATASOURCE)
	private DataSource iaaaImgDataSource;

	public VehicleParamsDto findOldestNotSentToIctProxyVehicleParamsDto(LocalDateTime fromInspectionDate, LocalDateTime toInspectionDate) {
		String hql =
				"SELECT new bg.demax.iaaa.admin.dto.VehicleParamsDto("
				+ "subj.identityNumber, rvsv.vehicleRegistrationNumber,"
				+ "rdn.vehicleDocumentNumber, rdn.id) "
				+ "FROM RegDocNum rdn "
				+ "INNER JOIN rdn.inspection ins "
				+ "INNER JOIN ins.rvsVersion rvsv "
				+ "INNER JOIN rvsv.subject subj "
				+ "WHERE rdn.lastIctRequest IS null ";

		if (fromInspectionDate != null) {
			hql += "AND ins.inspectionDate >= :fromInspectionDate ";
		}

		if (toInspectionDate != null) {
			hql += "AND ins.inspectionDate <= :toInspectionDate ";
		}

		hql += "ORDER BY rdn.id";

		Query<VehicleParamsDto> query = sessionFactory.getCurrentSession().createQuery(hql, VehicleParamsDto.class);

		if (fromInspectionDate != null) {
			query.setParameter("fromInspectionDate", fromInspectionDate);
		}

		if (toInspectionDate != null) {
			query.setParameter("toInspectionDate", toInspectionDate);
		}

		query.setMaxResults(1);
		return query.uniqueResult();
	}

	public int updateLastIctRequestDateForRegDocId(long regDocId) {
		String sql =
				"UPDATE public.l_reg_doc_nums "
				+ "SET last_ict_request = ? "
				+ "WHERE id = ?";

		Connection connection = null;
		String exceptionMsg = "Exception during executing sql query for updating the last ict request date for regDocId";
		try {
			connection = iaaaImgDataSource.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
			preparedStatement.setLong(2,  regDocId);

			return preparedStatement.executeUpdate();
		} catch (SQLException e) {
			throw new RuntimeException(exceptionMsg);
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					throw new RuntimeException(exceptionMsg);
				}
			}
		}
	}
}
