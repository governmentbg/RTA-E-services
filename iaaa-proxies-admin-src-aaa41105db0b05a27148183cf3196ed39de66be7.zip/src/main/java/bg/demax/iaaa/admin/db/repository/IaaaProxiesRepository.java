package bg.demax.iaaa.admin.db.repository;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.iaaa.admin.controller.params.CallRemoteServerParams;
import bg.demax.iaaa.admin.exception.ApplicationException;

@Repository
public class IaaaProxiesRepository {

	private static Logger log = LogManager.getLogger(IaaaProxiesRepository.class);

	private static String FIND_QUERY = "SELECT workflow FROM iaaa_proxies_admin.prepared_requests WHERE id = :id";
	private static String FIND_ALL_QUERY = "SELECT * FROM iaaa_proxies_admin.prepared_requests";
	private static String INSERT_QUERY = "INSERT INTO iaaa_proxies_admin.prepared_requests (workflow) VALUES (cast(:workflow AS JSON)) RETURNING id";
	private static String UPDATE_QUERY = "UPDATE iaaa_proxies_admin.prepared_requests SET workflow = (cast(:workflowJson AS JSON)) WHERE id = :id";
	private static String DELETE_QUERY = "DELETE FROM iaaa_proxies_admin.prepared_requests WHERE id = :id";
	private static String CREATE_CACHE_TABLE = "CREATE TABLE iaaa_gateway.%s"
		+   "("
		+	"    workflow jsonb NOT NULL,"
		+	"    id SERIAL PRIMARY KEY,"
		+	"    request_time timestamp without time zone"
		+	")";
	private static String ADD_INDEX_TO_TABLE = "CREATE INDEX iaaa_gateway_%s_idx ON iaaa_gateway.%s (request_time)";
	private static String GRANT_CACHE_TABLE_PERMISSIONS = "GRANT INSERT, SELECT, UPDATE ON TABLE iaaa_gateway.%s TO iaaa_gateway";
	private static String CREATE_CACHE_TABLE_COMMENT = "COMMENT ON TABLE iaaa_gateway.%s IS '%s'";
	private static String GRANT_USAGE_ON_SEQUENCE = "GRANT USAGE, SELECT ON SEQUENCE iaaa_gateway.%s TO iaaa_gateway";

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;

	public Integer save(CallRemoteServerParams params) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		serialize(params, parameters, "workflow");

		return jdbcTemplate.query(INSERT_QUERY, parameters, (res) -> {
			if (res.next()) {
				return res.getInt(1);
			}
			return null;
		});
	}

	public CallRemoteServerParams findById(Integer id) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("id", id);

		String result = jdbcTemplate.query(FIND_QUERY, parameters, (res) -> {
			if (res.next()) {
				return res.getString(1);
			}
			return null;
		});

		CallRemoteServerParams params = deserialize(result);
		params.setId(id);

		return params;
	}

	public List<CallRemoteServerParams> findAll() {
		List<CallRemoteServerParams> result = jdbcTemplate.query(FIND_ALL_QUERY, new RowMapper<CallRemoteServerParams>() {
			@Override
			public CallRemoteServerParams mapRow(ResultSet rs, int i) throws SQLException {
				String workflow = rs.getString("workflow");
				Integer id = rs.getInt("id");
				CallRemoteServerParams params = deserialize(workflow);
				params.setId(id);

				return params;
			}
		});

		return result;
	}

	public void update(CallRemoteServerParams params) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("id", params.getId());

		serialize(params, parameters, "workflowJson");

		jdbcTemplate.update(UPDATE_QUERY, parameters);
	}

	public void delete(Integer id) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("id", id);

		jdbcTemplate.update(DELETE_QUERY, parameters);
	}

	public void createCacheTable(String tableName, String description) {
		try {
			createCacheTable(tableName);
			createCacheTableComment(tableName, description);
		} catch (Exception e) {
			throw new ApplicationException(e.getMessage());
		}
	}

	private void createCacheTable(String tableName) {
		String createCacheTableQuery = String.format(CREATE_CACHE_TABLE, tableName);
		executeQuery(createCacheTableQuery, Collections.emptyMap());
		String addIndexQuery = String.format(ADD_INDEX_TO_TABLE, tableName, tableName);
		executeQuery(addIndexQuery, Collections.emptyMap());
		String grantCacheTablePermissionsQuery = String.format(GRANT_CACHE_TABLE_PERMISSIONS, tableName);
		executeQuery(grantCacheTablePermissionsQuery, Collections.emptyMap());
		String grantPermissionsOnSequenceQuery = String.format(GRANT_USAGE_ON_SEQUENCE, tableName + "_id_seq");
		executeQuery(grantPermissionsOnSequenceQuery, Collections.emptyMap());
	}

	private void createCacheTableComment(String tableName, String description) {
		String query = String.format(CREATE_CACHE_TABLE_COMMENT, tableName, description);
		executeQuery(query, Collections.emptyMap());
	}

	private void serialize(Object cache, Map<String, Object> parameters, String paramName) {
		try {
			String json = mapper.writeValueAsString(cache);
			parameters.put(paramName, json);
		} catch (JsonProcessingException e) {
			log.error(e.getMessage());
			throw new ApplicationException(e.getMessage());
		}
	}

	private CallRemoteServerParams deserialize(String result) {
		CallRemoteServerParams params = new CallRemoteServerParams();
		if (result == null) {
			return params;
		}
		try {
			params = (CallRemoteServerParams) mapper.readValue(result, CallRemoteServerParams.class);
		} catch (IOException e) {
			log.error(e.getMessage());
			throw new ApplicationException(e.getMessage());
		}
		return params;
	}

	private void executeQuery(String query, Map<String, Object> paramMap) {
		jdbcTemplate.execute(query, paramMap, new PreparedStatementCallback<Object>() {

			@Override
			public Object doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
				ps.execute();
				return null;
			}
		});
	}
}
