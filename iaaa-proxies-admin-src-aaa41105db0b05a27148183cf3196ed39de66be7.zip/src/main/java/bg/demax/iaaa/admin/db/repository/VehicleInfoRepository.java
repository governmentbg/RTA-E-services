package bg.demax.iaaa.admin.db.repository;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import bg.demax.iaaa.admin.db.mappers.JdbcJsonRowMapper;
import bg.demax.iaaa.admin.utils.MapAndList;
import bg.demax.iaaa.admin.utils.pgjson.JsonQuerySupport;
import bg.demax.ictclient.db.workflows.BaseWorkflow;

@Repository
public class VehicleInfoRepository {

	private static final String DEFAULT_QUERY_HEADER = "SELECT * FROM ict_proxy.logs_vehicle_info";
	private static final String DEFAULT_QUERY_FOOTER = "ORDER BY (workflow->>'requestTime')::timestamp DESC";

	@Autowired
	private JdbcJsonRowMapper<BaseWorkflow> baseWorkflowRowMapper;

	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;

	public List<BaseWorkflow> getWorkflows(MapAndList paramsMapAndFiltersList) {
		return getWorkflows(paramsMapAndFiltersList, DEFAULT_QUERY_HEADER, DEFAULT_QUERY_FOOTER);
	}

	private List<BaseWorkflow> getWorkflows(MapAndList paramsMapAndFiltersList, String queryHeader,
			String queryFooter) {
		Map<String, String> paramsMap = paramsMapAndFiltersList.getMap();
		List<String> filters = paramsMapAndFiltersList.getList();

		String query = JsonQuerySupport.process(filters, queryHeader, queryFooter);
		List<BaseWorkflow> queryResultList = jdbcTemplate.query(query, paramsMap, baseWorkflowRowMapper);

		if (queryResultList == null || queryResultList.isEmpty()) {
			return null;
		}
		return queryResultList;
	}

	public List<String> getMessageIds(MapAndList paramsMapAndFiltersList, String queryHeader) {

		Map<String, String> paramsMap = paramsMapAndFiltersList.getMap();
		List<String> filters = paramsMapAndFiltersList.getList();

		String query = JsonQuerySupport.process(filters, queryHeader, DEFAULT_QUERY_FOOTER);
		List<String> queryResultList = jdbcTemplate.queryForList(query, paramsMap, String.class);

		if (queryResultList == null || queryResultList.isEmpty()) {
			return null;
		}
		return queryResultList;
	}
}
