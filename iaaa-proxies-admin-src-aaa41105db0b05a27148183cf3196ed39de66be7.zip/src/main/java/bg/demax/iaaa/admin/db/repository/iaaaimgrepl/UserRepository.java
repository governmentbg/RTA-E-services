package bg.demax.iaaa.admin.db.repository.iaaaimgrepl;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.iaaa.admin.db.entity.iaaaimgrepl.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

	public User findUserByUsername(String username);
}
