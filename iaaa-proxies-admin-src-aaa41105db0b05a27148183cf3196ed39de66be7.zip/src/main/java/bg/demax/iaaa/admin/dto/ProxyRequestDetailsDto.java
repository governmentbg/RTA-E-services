package bg.demax.iaaa.admin.dto;

public class ProxyRequestDetailsDto {

	private Integer id;

	private String localPath;

	private String remoteUrl;

	private String httpMethod;

	private Integer restTemplateConfigId;

	private String cacheTableName;

	private Boolean isEnabled;

	private String description;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLocalPath() {
		return localPath;
	}

	public void setLocalPath(String localPath) {
		this.localPath = localPath;
	}

	public String getRemoteUrl() {
		return remoteUrl;
	}

	public void setRemoteUrl(String remoteUrl) {
		this.remoteUrl = remoteUrl;
	}

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	public String getCacheTableName() {
		return cacheTableName;
	}

	public void setCacheTableName(String cacheTableName) {
		this.cacheTableName = cacheTableName;
	}

	public Boolean getIsEnabled() {
		return isEnabled;
	}

	public void setIsEnabled(Boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getRestTemplateConfigId() {
		return restTemplateConfigId;
	}

	public void setRestTemplateConfigId(Integer restTemplateConfigId) {
		this.restTemplateConfigId = restTemplateConfigId;
	}

}