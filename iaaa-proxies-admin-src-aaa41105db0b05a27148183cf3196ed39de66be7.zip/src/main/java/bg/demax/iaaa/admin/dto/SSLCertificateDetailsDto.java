package bg.demax.iaaa.admin.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;

public class SSLCertificateDetailsDto {

	private Integer id;

	private String name;

	private Integer certDataId;

	private String password;

	@JsonFormat(pattern = IaaaProxiesAdminWebConstants.DATE_TIME_FORMAT)
	private LocalDateTime validTo;

	private String type;

	private String description;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LocalDateTime getValidTo() {
		return validTo;
	}

	public void setValidTo(LocalDateTime validTo) {
		this.validTo = validTo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getCertDataId() {
		return certDataId;
	}

	public void setCertDataId(Integer certDataId) {
		this.certDataId = certDataId;
	}
}
