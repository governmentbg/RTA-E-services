package bg.demax.iaaa.admin.dto;

import java.util.List;

import bg.demax.ictclient.db.workflows.VehicleInfoWorkflow;

public class VehicleInfoWorkflowDto {

	private List<VehicleInfoWorkflow> workflows;

	public VehicleInfoWorkflowDto() {
	}

	public VehicleInfoWorkflowDto(List<VehicleInfoWorkflow> workflows) {
		this.workflows = workflows;
	}

	public List<VehicleInfoWorkflow> getWorkflows() {
		return workflows;
	}

	public void setWorkflows(List<VehicleInfoWorkflow> workflows) {
		this.workflows = workflows;
	}
}
