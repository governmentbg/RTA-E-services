package bg.demax.iaaa.admin.dto;

public class VehicleParamsDto {
	private String ownerId;
	private String vehicleRegistrationNumber;
	private String vehicleDocumentNumber;
	private Long regDocId;

	public VehicleParamsDto(String ownerId, String vehicleRegistrationNumber, String vehicleDocumentNumber, Long regDocId) {
		this.ownerId = ownerId;
		this.vehicleRegistrationNumber = vehicleRegistrationNumber;
		this.vehicleDocumentNumber = vehicleDocumentNumber;
		this.regDocId = regDocId;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public String getVehicleRegistrationNumber() {
		return vehicleRegistrationNumber;
	}

	public String getVehicleDocumentNumber() {
		return vehicleDocumentNumber;
	}

	public Long getRegDocId() {
		return regDocId;
	}

	public void setRegDocId(Long regDocId) {
		this.regDocId = regDocId;
	}

}
