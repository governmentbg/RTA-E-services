package bg.demax.iaaa.admin.dto;

import bg.demax.ictclient.dtos.VehicleResponseDto;

public class VehicleResponseWithRequestCountDto {
	private VehicleResponseDto vehicleResponseDto;
	private int requestWithDiffOwnerIdCount;

	public VehicleResponseDto getVehicleResponseDto() {
		return vehicleResponseDto;
	}

	public void setVehicleResponseDto(VehicleResponseDto vehicleResponseDto) {
		this.vehicleResponseDto = vehicleResponseDto;
	}

	public int getRequestWithDiffOwnerIdCount() {
		return requestWithDiffOwnerIdCount;
	}

	public void setRequestWithDiffOwnerIdCount(int requestWithDiffOwnerIdCount) {
		this.requestWithDiffOwnerIdCount = requestWithDiffOwnerIdCount;
	}
}
