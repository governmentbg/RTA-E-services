package bg.demax.iaaa.admin.dto.security;

import javax.validation.constraints.NotNull;

import org.springframework.lang.Nullable;

public class RespWrp {
	@NotNull
	private Integer status;

	@Nullable
	private String message;

	public RespWrp() {
	}

	public RespWrp(int status, String message) {
		this.status = status;
		this.message = message;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
