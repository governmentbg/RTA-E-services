package bg.demax.iaaa.admin.enums;

import bg.demax.iaaa.admin.exception.ApplicationException;

public enum RemoteApp {

	IAAA_GATEWAY("IAAA_GATEWAY"), REGIX_PROXY("REGIX-PROXY");

	private final String value;

	RemoteApp(String value) {
		this.value = value;
	}

	public String value() {
		return value;
	}

	public static RemoteApp fromValue(String value) {
		for (RemoteApp type : RemoteApp.values()) {
			if (type.value.equals(value)) {
				return type;
			}
		}

		throw new ApplicationException("Undefined name for remote app: " + value);
	}

}
