package bg.demax.iaaa.admin.enums;

import bg.demax.iaaa.admin.exception.ApplicationException;

public enum SSLCertificateType {

	JKS("JKS"),
	PKCS12("PKCS12");

	private final String value;

	SSLCertificateType(String value) {
		this.value = value;
	}

	public String value() {
		return value;
	}

	public static SSLCertificateType fromValue(String value) {
		for (SSLCertificateType type : SSLCertificateType.values()) {
			if (type.value.equals(value)) {
				return type;
			}
		}

		throw new ApplicationException("Unsupported SSL certificate type " + value);
	}
}