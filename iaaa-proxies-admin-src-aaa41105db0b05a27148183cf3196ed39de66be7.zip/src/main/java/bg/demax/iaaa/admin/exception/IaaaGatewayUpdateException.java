package bg.demax.iaaa.admin.exception;

public class IaaaGatewayUpdateException extends ApplicationException {
	private static final long serialVersionUID = -7232174136693046024L;

	public IaaaGatewayUpdateException(Exception e) {
		super(e);
	}
}
