package bg.demax.iaaa.admin.exception;

public class IctClientProxyException extends ApplicationException {

	private static final long serialVersionUID = -5196615165316445730L;

	public IctClientProxyException(String message) {
		super(message);
	}
}
