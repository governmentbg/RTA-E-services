package bg.demax.iaaa.admin.exception;

public class InvalidCertificateStoreException extends ApplicationException {

	private static final long serialVersionUID = -7793719989952470592L;

	public InvalidCertificateStoreException(Exception e) {
		super(e);
	}
}
