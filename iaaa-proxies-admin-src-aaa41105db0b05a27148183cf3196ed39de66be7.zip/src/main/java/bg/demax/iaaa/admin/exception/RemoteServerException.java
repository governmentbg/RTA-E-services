package bg.demax.iaaa.admin.exception;

public class RemoteServerException extends ApplicationException {
	private static final String NEW_LINE = "\n";

	private String url;
	private String method;
	private Integer statusCode;
	private String responseBody;
	private String errorMsg;

	private static final long serialVersionUID = -5196615165316444230L;

	public RemoteServerException(String url, String method, Integer statusCode, String responseBody, String errorMsg) {
		super(buildErrorMsg(url, method, statusCode, responseBody, errorMsg));
		this.url = url;
		this.method = method;
		this.statusCode = statusCode;
		this.responseBody = responseBody;
		this.errorMsg = errorMsg;
	}

	private static String buildErrorMsg(String url, String method, Integer statusCode, String responseBody,
			String errorMsg) {
		StringBuilder sb = new StringBuilder("There was a problem making request to remote server.");
		sb.append(NEW_LINE).append("*URL*: ").append(url)
		.append(NEW_LINE).append("*Http method*: ").append(method)
		.append(NEW_LINE).append("*Remote status code*: ").append(statusCode)
		.append(NEW_LINE).append("*Response body*: ").append(responseBody)
		.append(NEW_LINE).append("*Exception message*: ").append(errorMsg);

		return sb.toString();
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	public String getResponseBody() {
		return responseBody;
	}

	public void setResponseBody(String responseBody) {
		this.responseBody = responseBody;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

}
