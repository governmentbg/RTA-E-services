package bg.demax.iaaa.admin.exception;

public class RequestsWithDifferentOwnerIdRetriesExceededException extends ApplicationException {

	private static final long serialVersionUID = -5196615165316365730L;

	public RequestsWithDifferentOwnerIdRetriesExceededException(String errorCode) {
		super(errorCode);
	}
}
