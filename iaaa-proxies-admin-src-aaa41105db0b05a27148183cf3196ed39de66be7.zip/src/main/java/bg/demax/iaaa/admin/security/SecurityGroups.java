package bg.demax.iaaa.admin.security;

public enum SecurityGroups {

	FULL_ACCESS(new String[] { SecurityRole.ALL_APPLICATIONS_SUPER_ADMIN, SecurityRole.IAAA_PROXIES_ADMIN }),
	VIEW_ONLY(new String[] { SecurityRole.CALL_CENTER }),
	NO_APP_ROLES_AUTHENTICATED(new String[] { SecurityRole.AUTHENTICATED_USER });

	private String[] rolesInGroup;

	private SecurityGroups(String[] rolesInGroup) {
		this.rolesInGroup = rolesInGroup;
	}

	public String[] getRolesInGroup() {
		return this.rolesInGroup;
	}
}
