package bg.demax.iaaa.admin.security;

public interface SecurityRole {

	/**
	 * Администраторски права за всички приложения, използвана от служители на Демакс и Скимпрот.
	 */
	String ALL_APPLICATIONS_SUPER_ADMIN = "ADMIN";

	/**
	 * Администраторски права специално за Iaaa Proxies Admin приложението.
	 */
	String IAAA_PROXIES_ADMIN = "IAAA_PROXIES_ADMIN";

	/**
	 * Роля, която значи че потребителя няма роля за Iaaa Proxies Admin приложението.
	 */
	String AUTHENTICATED_USER = "AUTHENTICATED_USER";

	/**
	 * Роля за потребител от Демакс Call Center.
	 */
	String CALL_CENTER = "CALL_CENTER";

}
