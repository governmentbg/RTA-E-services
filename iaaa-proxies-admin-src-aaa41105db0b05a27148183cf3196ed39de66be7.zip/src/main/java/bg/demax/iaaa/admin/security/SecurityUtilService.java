package bg.demax.iaaa.admin.security;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import bg.demax.iaaa.admin.dto.security.UserDto;
import bg.demax.iaaa.admin.exception.ApplicationException;

@Service
public class SecurityUtilService {
	public static final String ROLE_PREFFIX = "ROLE_";

	public UserDetailsImpl getCurrentUserDetails() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
			return (UserDetailsImpl) authentication.getPrincipal();
		}
		return null;
	}

	public UserDto getCurrentUser() {
		UserDetailsImpl userDetails = getCurrentUserDetails();
		if (userDetails == null) {
			throw new ApplicationException("There was a problem getting the currently logged in user");
		}


		UserDto userDto = new UserDto();
		userDto.setUserId(userDetails.getUserId());
		userDto.setUsername(userDetails.getUsername());
		userDto.setUserGroups(getCurrentUserGroups());

		return userDto;
	}

	private Set<String> getCurrentUserGroups() {
		UserDetails userDetails = getCurrentUserDetails();
		Set<String> userGroups = new HashSet<>();

		if (userDetails != null) {
			Set<String> userRoles = new HashSet<>();

			Collection<? extends GrantedAuthority> authorities = userDetails.getAuthorities();
			for (GrantedAuthority authority : authorities) {
				String strAuth = authority.getAuthority();
				String role = strAuth;
				if (role.startsWith(ROLE_PREFFIX)) {
					role = role.substring(ROLE_PREFFIX.length());
				}

				userRoles.add(role);
			}

			for (SecurityGroups sGroup : SecurityGroups.values()) {
				String[] rolesInGroup = sGroup.getRolesInGroup();
				for (String role : rolesInGroup) {
					if (userRoles.contains(role)) {
						userGroups.add(sGroup.name());
						break;
					}
				}
			}
			if (userGroups.isEmpty()) {
				userGroups.add(SecurityGroups.NO_APP_ROLES_AUTHENTICATED.name());
			}
		}

		return userGroups;
	}
}
