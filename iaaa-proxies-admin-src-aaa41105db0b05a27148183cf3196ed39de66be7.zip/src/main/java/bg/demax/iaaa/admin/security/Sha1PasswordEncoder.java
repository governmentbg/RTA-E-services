package bg.demax.iaaa.admin.security;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.security.crypto.password.PasswordEncoder;

public class Sha1PasswordEncoder implements PasswordEncoder {

	@Override
	public String encode(CharSequence rawPassword) {
		return hash(rawPassword.toString());
	}

	@Override
	public boolean matches(CharSequence rawPassword, String encodedPassword) {
		return encode(rawPassword.toString()).equals(encodedPassword);
	}

	private static String hash(String word) {
		return hash(word.getBytes());
	}

	private static String hash(byte[] bytes) {
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("SHA1");
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}

		md.update(bytes);

		String encodedWord = new BigInteger(1, md.digest()).toString(16);
		while (encodedWord.length() < 40) {
			encodedWord = "0" + encodedWord;
		}
		return encodedWord;
	}
}
