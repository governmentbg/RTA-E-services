package bg.demax.iaaa.admin.service;

import java.time.LocalDateTime;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.db.repository.IaaaImgRepository;
import bg.demax.iaaa.admin.dto.VehicleParamsDto;

@Service
public class IaaaImgService {

	@Autowired
	private IaaaImgRepository iaaaImgRepository;

	@Transactional(transactionManager = BeanQualifierConstants.IAAA_IMG_REPL_TRANSACTION_MANAGER, readOnly = true)
	public VehicleParamsDto getOldestNotSentToIctProxyVehicleParamsDto(LocalDateTime fromInspectionDate, LocalDateTime toInspectionDate) {
		VehicleParamsDto vehicleParamsDto = iaaaImgRepository.findOldestNotSentToIctProxyVehicleParamsDto(fromInspectionDate, toInspectionDate);

		if (vehicleParamsDto == null) {
			throw new EntityNotFoundException();
		}

		return vehicleParamsDto;
	}

	public void updateLastIctRequestDateForRegDocId(long regDocId) {
		iaaaImgRepository.updateLastIctRequestDateForRegDocId(regDocId);
	}
}
