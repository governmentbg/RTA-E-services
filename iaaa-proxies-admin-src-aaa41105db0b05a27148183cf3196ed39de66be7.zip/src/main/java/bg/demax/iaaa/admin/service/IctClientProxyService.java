package bg.demax.iaaa.admin.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContextException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.dto.VehicleResponseWithRequestCountDto;
import bg.demax.iaaa.admin.exception.IctClientProxyException;
import bg.demax.iaaa.admin.exception.RequestsWithDifferentOwnerIdRetriesExceededException;
import bg.demax.ictclient.dtos.VehicleRequestDto;
import bg.demax.ictclient.dtos.VehicleResponseDto;

@Service
public class IctClientProxyService {
	private static final Logger logger = LogManager.getLogger(IctClientProxyService.class);
	private static final String GET_VEHICLE_ADDRESS = "/ict-client-proxy/vehicle";
	private static final String REQUEST_WITH_DIFF_OWNER_ID_COUNT_HEADER_NAME = "Request-Count";
	private static final String ICT_CLIENT_PROXY_EXCEPTION = "Exception occurred while exchanging data with Ict Client Proxy! ";

	@Value("${ict.client.proxy.address}")
	private String ictClientProxyBaseAddress;

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_ADMIN_REST_TEMPLATE_FOR_PROXY_APPS)
	private RestTemplate restTemplate;

	public VehicleResponseWithRequestCountDto getVehicleResponseDto(VehicleRequestDto requestDto) {
		String address = ictClientProxyBaseAddress + GET_VEHICLE_ADDRESS;

		try {
			logger.trace("Attempting to get VehicleResponseDto. ");

			ResponseEntity<VehicleResponseDto> responseEntity = restTemplate.postForEntity(address, requestDto, VehicleResponseDto.class);
			HttpHeaders httpHeaders = responseEntity.getHeaders();
			int requestWithDiffOwnerIdCount = Integer.parseInt(httpHeaders.getFirst(REQUEST_WITH_DIFF_OWNER_ID_COUNT_HEADER_NAME));

			VehicleResponseWithRequestCountDto responseDto = new VehicleResponseWithRequestCountDto();
			responseDto.setRequestWithDiffOwnerIdCount(requestWithDiffOwnerIdCount);
			responseDto.setVehicleResponseDto(responseEntity.getBody());

			return responseDto;
		} catch (HttpClientErrorException | HttpServerErrorException httpEx) {
			if (httpEx.getStatusCode() == HttpStatus.TOO_MANY_REQUESTS) {
				logger.warn("There was a conflict getting VehicleResponseDtos. Message: " + httpEx.getResponseBodyAsString());
				throw new RequestsWithDifferentOwnerIdRetriesExceededException(httpEx.getResponseBodyAsString());
			} else {
				throw new IctClientProxyException(ICT_CLIENT_PROXY_EXCEPTION + httpEx.getResponseBodyAsString());
			}
		} catch (Exception e) {
			logger.warn("Could not get VehicleResponseDto." + e.getMessage());
			throw new ApplicationContextException(e.getMessage());
		}
	}
}
