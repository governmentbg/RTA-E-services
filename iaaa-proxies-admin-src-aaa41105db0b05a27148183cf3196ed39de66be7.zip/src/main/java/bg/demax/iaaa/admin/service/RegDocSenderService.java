package bg.demax.iaaa.admin.service;

import java.util.concurrent.atomic.AtomicBoolean;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;
import bg.demax.iaaa.admin.config.property.RegDocSenderConfigurationPropertiesRepository;
import bg.demax.iaaa.admin.controller.params.regdocsender.RegDocSenderFullServiceSettingsParams;
import bg.demax.iaaa.admin.controller.params.regdocsender.RegDocSenderServiceSettingsParams;
import bg.demax.iaaa.admin.converter.AppConversionService;
import bg.demax.iaaa.admin.dto.VehicleParamsDto;
import bg.demax.ictclient.dtos.VehicleRequestDto;

@Service
@Profile("!" + IaaaProxiesAdminWebConstants.SPRING_PROFILE_UNIT_TEST)
public class RegDocSenderService {

	private static final Logger logger = LogManager.getLogger(RegDocSenderService.class);
	private static final String SERVICE_THREAD_NAME = "REG_DOC_SENDER";
	public static final long FIXED_DELAY_DEFAULT = 30 * 1000;
	public static final int ERRORS_THRESHOLD_DEFAULT = 3;
	public static final long ERRORS_DELAY_BELOW_THRESHOLD_DEFAULT = 3 * 60 * 1000;
	public static final long ERRORS_DELAY_AFTER_THRESHOLD_DEFAULT = 5 * 60 * 1000;

	private Thread serviceThread;
	private final AtomicBoolean running = new AtomicBoolean();
	private RegDocSenderFullServiceSettingsParams serviceParams;
	private int errorsCount = 0;

	@Autowired
	private IaaaImgService iaaaImgService;

	@Autowired
	private IctClientProxyService ictClientAdminService;

	@Autowired
	private AppConversionService conversionService;

	@Autowired
	private RegDocSenderConfigurationPropertiesRepository regDocSenderConfigurationPropertiesRepository;

	@PostConstruct
	private void postConstruct() {
		serviceParams = regDocSenderConfigurationPropertiesRepository.loadParams();

		if (serviceParams == null) {
			applyDefaultSettingsParams();
		}

		onFullInitializationComplete();
	}

	protected void onFullInitializationComplete() {
		if (serviceParams.getIsServiceRunning()) {
			startService();
		}
	}

	public synchronized void startService() {
		if (!running.get()) {
			serviceThread = getNewServiceThread();
			serviceThread.setName(SERVICE_THREAD_NAME);
			running.set(true);
			serviceThread.start();
			regDocSenderConfigurationPropertiesRepository.persistParams(serviceParams.getRegDocSenderServiceSettingsParams(), running.get());
		}
	}

	public synchronized void stopService() {
		if (running.get()) {
			this.serviceThread.interrupt();
			running.set(false);
			regDocSenderConfigurationPropertiesRepository.persistParams(serviceParams.getRegDocSenderServiceSettingsParams(), running.get());

			try {
				this.serviceThread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public synchronized void setServiceSettings(RegDocSenderServiceSettingsParams params) {
		serviceParams.setRegDocSenderServiceSettingsParams(params);
		regDocSenderConfigurationPropertiesRepository.persistParams(params, running.get());
	}

	public synchronized RegDocSenderFullServiceSettingsParams getServiceCurrentConfigParams() {
		serviceParams.setIsServiceRunning(running.get());
		return serviceParams;
	}

	private Thread getNewServiceThread() {
		Thread newServiceThread = new Thread(new Runnable() {

			@Override
			public void run() {
				logger.info(RegDocSenderService.class.getSimpleName() + " service thread starting.");
				while (running.get()) {
					try {
						VehicleParamsDto vehicleParamsDto = iaaaImgService.getOldestNotSentToIctProxyVehicleParamsDto(
								serviceParams.getRegDocSenderServiceSettingsParams().getFromInspectionDate(),
								serviceParams.getRegDocSenderServiceSettingsParams().getToInspectionDate());
						VehicleRequestDto vehicleRequestDto = conversionService.convert(vehicleParamsDto, VehicleRequestDto.class);

						ictClientAdminService.getVehicleResponseDto(vehicleRequestDto);

						iaaaImgService.updateLastIctRequestDateForRegDocId(vehicleParamsDto.getRegDocId());

						Thread.sleep(serviceParams.getRegDocSenderServiceSettingsParams().getFixedDelay());
					} catch (InterruptedException e) {
						logger.debug(RegDocSenderService.class.getSimpleName() + " was interrupted.");
					} catch (Exception ex) {
						catchServiceThreadException(ex);
					}
				}

				logger.info(RegDocSenderService.class.getSimpleName() + " service thread shutting down.");
				running.set(false);
			}
		});

		newServiceThread.setDaemon(true);
		return newServiceThread;
	}

	private void catchServiceThreadException(Exception e) {
		String errorMsgTemplate = "There was an error in " + RegDocSenderService.class.getSimpleName() + " service thread:";
		logger.debug(errorMsgTemplate + e.getMessage());
		logger.debug("Sleeping service thread to delay retry");

		errorsCount++;
		Long sleepDuration = null;

		if (errorsCount >= serviceParams.getRegDocSenderServiceSettingsParams().getErrorsThreshold()) {
			sleepDuration = serviceParams.getRegDocSenderServiceSettingsParams().getErrorsDelayAfterThreshold();
		} else {
			sleepDuration = serviceParams.getRegDocSenderServiceSettingsParams().getErrorsDelayBelowThreshold();
		}

		try {
			Thread.sleep(sleepDuration);
		} catch (InterruptedException e1) {
			logger.debug(errorMsgTemplate + e1.getMessage());
		}
	}

	private void applyDefaultSettingsParams() {
		serviceParams = new RegDocSenderFullServiceSettingsParams();

		RegDocSenderServiceSettingsParams params = new RegDocSenderServiceSettingsParams();

		params.setFixedDelay(FIXED_DELAY_DEFAULT);
		params.setErrorsThreshold(ERRORS_THRESHOLD_DEFAULT);
		params.setErrorsDelayBelowThreshold(ERRORS_DELAY_BELOW_THRESHOLD_DEFAULT);
		params.setErrorsDelayAfterThreshold(ERRORS_DELAY_AFTER_THRESHOLD_DEFAULT);

		serviceParams.setRegDocSenderServiceSettingsParams(params);
		serviceParams.setIsServiceRunning(true);
	}

}
