package bg.demax.iaaa.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.converter.AppConversionService;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.RegixProxyRequestInfo;
import bg.demax.iaaa.admin.db.repository.GenericRepository;
import bg.demax.iaaa.admin.dto.RequestDetailsDto;

@Service
public class RegixProxyRequestsInfoService {

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_GENERIC_REPOSITORY)
	private GenericRepository iaaaProxiesGenericRepository;

	@Autowired
	private AppConversionService conversionService;

	@Transactional(transactionManager = BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER, readOnly = true)
	public List<RequestDetailsDto> getAllRegixProxyRequestsInfo() {
		List<RegixProxyRequestInfo> regixProxyRequestsInfo = iaaaProxiesGenericRepository.findAll(RegixProxyRequestInfo.class);

		return conversionService.convertList(regixProxyRequestsInfo, RequestDetailsDto.class);
	}
}
