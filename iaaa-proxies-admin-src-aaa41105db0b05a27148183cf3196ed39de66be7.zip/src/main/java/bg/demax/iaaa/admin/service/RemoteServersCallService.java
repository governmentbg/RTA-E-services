package bg.demax.iaaa.admin.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;
import bg.demax.iaaa.admin.controller.params.CallRemoteServerParams;
import bg.demax.iaaa.admin.db.repository.IaaaProxiesRepository;
import bg.demax.iaaa.admin.enums.RemoteApp;
import bg.demax.iaaa.admin.exception.ApplicationException;
import bg.demax.iaaa.admin.exception.RemoteServerException;
import bg.demax.iaaa.admin.utils.notifiers.NotificationService;

@Service
public class RemoteServersCallService {
	private static final Logger logger = LogManager.getLogger(RemoteServersCallService.class);

	private static final String NEW_LINE = "\n";

	@Value("${iaaa.gateway.address}")
	private String iaaaGatewayBaseAddress;

	@Value("${regix.client.proxy.address}")
	private String regixClientProxyBaseAddress;

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_ADMIN_REST_TEMPLATE_FOR_PROXY_APPS)
	private RestTemplate iaaaProxiesAdminRtForProxyApps;

	@Autowired
	private IaaaProxiesRepository iaaaProxiesRepository;

	@Autowired
	private NotificationService notificationService;

	@Autowired
	private ObjectMapper objectMapper;

	public CallRemoteServerParams findById(Integer id) {
		return iaaaProxiesRepository.findById(id);
	}

	public List<CallRemoteServerParams> findAll() {
		return iaaaProxiesRepository.findAll();
	}

	public Integer saveOrUpdate(CallRemoteServerParams params) {
		Integer id = params.getId();
		if (id != null) {
			iaaaProxiesRepository.update(params);
		} else {
			id = iaaaProxiesRepository.save(params);
		}
		return id;
	}

	public void delete(Integer id) {
		iaaaProxiesRepository.delete(id);
	}

	public ResponseEntity<String> callRemoteServer(CallRemoteServerParams params) {
		String baseAddress = getBaseAddress(params.getRemoteApp());

		String url = baseAddress + params.getEndpoint();

		HttpHeaders headers = new HttpHeaders();
		if (params.getHeaderEntries() != null) {
			params.getHeaderEntries().forEach(he -> {
				headers.set(he.getKey(), he.getValue());
			});
		}

		ResponseEntity<String> response = null;

		try {
			Object body = getRequestBody(params, headers);

			HttpMethod method = HttpMethod.valueOf(params.getMethod());

			HttpEntity<Object> httpEntity = new HttpEntity<Object>(body, headers);
			response = iaaaProxiesAdminRtForProxyApps.exchange(url, method, httpEntity, String.class);
		} catch (HttpStatusCodeException ex) {
			throw new RemoteServerException(url, params.getMethod(), ex.getRawStatusCode(),	ex.getResponseBodyAsString(), ex.getMessage());
		} catch (Exception ex) {
			throw new ApplicationException("url: " + url + ", msg: " + ex.getMessage());
		}

		return response;
	}

	@Scheduled(cron = "${cron.remote-servers-call}")
	@Profile("!" + IaaaProxiesAdminWebConstants.SPRING_PROFILE_TEST)
	public void executePreparedRequests() {
		List<CallRemoteServerParams> params = findAll();
		List<String> errorMggs = new ArrayList<String>();
		for (CallRemoteServerParams param : params) {
			try {
				ResponseEntity<String> res = callRemoteServer(param);
				if (!res.getStatusCode().is2xxSuccessful()) {
					String msg = buildErrorMsg(param.getEndpoint(), param.getMethod(), res.getStatusCode().value(), res.getBody(), "");
					errorMggs.add(msg);
				}
			} catch (RemoteServerException e) {
				errorMggs.add(e.getMessage());
			} catch (Exception e) {
				String msg = buildErrorMsg(param.getEndpoint(), param.getMethod(), null, "", e.getMessage());
				errorMggs.add(msg);
			}
		}
		notificationService.notify(errorMggs, Level.DEBUG);
	}

	private String getBaseAddress(String remoteAppStr) {
		RemoteApp ra = RemoteApp.fromValue(remoteAppStr);
		switch (ra) {
			case IAAA_GATEWAY:
				return iaaaGatewayBaseAddress;
			case REGIX_PROXY:
				return regixClientProxyBaseAddress;
			default:
				throw new ApplicationException("Unexpected remote app:" + ra);
		}

	}

	private Object getRequestBody(CallRemoteServerParams params, HttpHeaders headers) {
		String requestBodyParam = params.getRequestBody();
		Object requestBody;

		if (requestBodyParam == null) {
			return null;
		}

		String requestBodyType = params.getRequestBodyType();

		switch (requestBodyType) {
			case MediaType.APPLICATION_JSON_VALUE:
				validateRequestBodyJsonFormat(requestBodyParam);
				headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
				requestBody = requestBodyParam;
				break;

			case MediaType.APPLICATION_FORM_URLENCODED_VALUE:
				validateRequestBodyFormUrlEncodedFormat(requestBodyParam);
				headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
				requestBody = getFormUrlEncodedRequestBody(requestBodyParam);
				break;

			case MediaType.TEXT_PLAIN_VALUE:
				headers.setContentType(MediaType.TEXT_PLAIN);
				requestBody = requestBodyParam;
				break;

			default:
				throw new ApplicationException("Unsupported media type for remote request");
		}

		return requestBody;
	}

	private void validateRequestBodyJsonFormat(String requestBody) {
		try {
			objectMapper.writeValueAsString(requestBody);
		} catch (Exception ex) {
			String exMsg = "None json request body when calling remote service.";
			logger.warn(exMsg);
			throw new ApplicationException(exMsg);
		}
	}

	private void validateRequestBodyFormUrlEncodedFormat(String requestBody) {
		final String formatPattern = "^([\\w+]+=[\\w+]+&*)+$";

		if (!requestBody.matches(formatPattern)) {
			String exMsg = "None form url encoded request body when calling remote service.";
			logger.warn(exMsg);
			throw new ApplicationException(exMsg);
		}
	}

	private MultiValueMap<String, String> getFormUrlEncodedRequestBody(String requestBody) {
		String[] keyValuePairs = requestBody.split("&");
		MultiValueMap<String, String> keyValuePairsMap = new LinkedMultiValueMap<>();

		for (String keyValuePair : keyValuePairs) {
			String[] pairElements = keyValuePair.split("=");
			String key = pairElements[0];
			String value = pairElements[1];
			keyValuePairsMap.add(key, value);
		}

		return keyValuePairsMap;
	}

	private String buildErrorMsg(String url, String method, Integer statusCode, String responseBody, String errorMsg) {
		StringBuilder sb = new StringBuilder("There was a problem making request to remote server.");
		sb.append(NEW_LINE).append("*URL*: ").append(url)
		.append(NEW_LINE).append("*Http method*: ").append(method)
		.append(NEW_LINE).append("*Remote status code*: ").append(statusCode)
		.append(NEW_LINE).append("*Response body*: ").append(responseBody)
		.append(NEW_LINE).append("*Exception message*: ").append(errorMsg);

		return sb.toString();
	}
}
