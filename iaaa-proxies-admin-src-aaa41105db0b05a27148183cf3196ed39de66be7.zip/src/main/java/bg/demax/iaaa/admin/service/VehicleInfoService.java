package bg.demax.iaaa.admin.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bg.demax.iaaa.admin.db.repository.VehicleInfoRepository;
import bg.demax.iaaa.admin.utils.MapAndList;
import bg.demax.iaaa.admin.utils.pgjson.JsonQuerySupport;
import bg.demax.iaaa.admin.utils.pgjson.search.VehicleInfoSearch;
import bg.demax.ictclient.db.workflows.BaseWorkflow;
import bg.demax.ictclient.db.workflows.VehicleInfoWorkflow;

@Service
public class VehicleInfoService {

	public static final String ELEMENT_ALIAS = "el";
	public static final String TABLE_ALIAS = "ict";

	@Autowired
	private VehicleInfoRepository vehicleInfoRepository;

	public List<VehicleInfoWorkflow> getVehicleInfoWorkflow(VehicleInfoSearch search) {
		MapAndList paramsMapAndFiltersList = JsonQuerySupport.getMapAndList(search);
		List<BaseWorkflow> resultList = vehicleInfoRepository.getWorkflows(paramsMapAndFiltersList);

		if (resultList != null) {
			return resultList.stream().map(r -> (VehicleInfoWorkflow) r).collect(Collectors.toList());
		}

		return null;
	}

	public List<String> getVehicleInfoWorkflowMessageIds(VehicleInfoSearch search) {
		MapAndList paramsMapAndFiltersList = JsonQuerySupport.getMapAndList(search);
		String queryHeader = "SELECT workflow->'request'->'header'->>'messageID' AS messageId FROM ict_proxy.logs_vehicle_info AS "
				+ TABLE_ALIAS;
		if (search.getVehicleOwnerVerification() != null) {
			queryHeader += ", jsonb_array_elements(ict.workflow ->'response'->'response'->'results'#>'{result, 1}') AS "
					+ ELEMENT_ALIAS;
		}
		List<String> resultList = vehicleInfoRepository.getMessageIds(paramsMapAndFiltersList, queryHeader);

		if (resultList != null) {
			return resultList;
		}

		return null;
	}
}
