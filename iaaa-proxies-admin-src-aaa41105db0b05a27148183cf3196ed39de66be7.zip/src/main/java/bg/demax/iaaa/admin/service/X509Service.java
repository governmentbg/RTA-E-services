package bg.demax.iaaa.admin.service;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import org.springframework.stereotype.Service;

import bg.demax.iaaa.admin.exception.InvalidCertificateStoreException;

@Service
public class X509Service {

	public X509Certificate readCert(String keystoreType, byte[] data, String password) {
		return readCert(keystoreType, new ByteArrayInputStream(data), password);
	}

	public X509Certificate readCert(String keyStoreType, InputStream inputStream, String password) {
		try {
			KeyStore ks = KeyStore.getInstance(keyStoreType);
			ks.load(inputStream, password.toCharArray());
			Certificate cert = ks.getCertificate(ks.aliases().nextElement());
			CertificateFactory certificateFactory = CertificateFactory.getInstance("X509");
			X509Certificate x509Cert;
			try (InputStream certIs = new ByteArrayInputStream(cert.getEncoded())) {
				x509Cert = (X509Certificate) certificateFactory.generateCertificate(certIs);
			}

			return x509Cert;
		} catch (Exception e) {
			throw new InvalidCertificateStoreException(e);
		}
	}
}
