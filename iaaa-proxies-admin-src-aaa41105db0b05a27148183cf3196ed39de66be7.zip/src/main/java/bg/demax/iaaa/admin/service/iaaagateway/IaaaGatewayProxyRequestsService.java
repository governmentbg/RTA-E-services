package bg.demax.iaaa.admin.service.iaaagateway;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.controller.params.proxyrequests.CacheTableCreationParams;
import bg.demax.iaaa.admin.controller.params.proxyrequests.ProxyRequestParams;
import bg.demax.iaaa.admin.converter.AppConversionService;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.ProxyRequestDetails;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.RestTemplateConfig;
import bg.demax.iaaa.admin.db.repository.GenericRepository;
import bg.demax.iaaa.admin.db.repository.IaaaProxiesRepository;
import bg.demax.iaaa.admin.dto.ProxyRequestDetailsDto;

@Service
public class IaaaGatewayProxyRequestsService {

	@Autowired
	private AppConversionService conversionService;

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_GENERIC_REPOSITORY)
	private GenericRepository iaaaProxiesGenericRepository;

	@Autowired
	private IaaaProxiesRepository iaaaProxiesRepository;

	@Transactional(readOnly = true, transactionManager = BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER)
	public List<ProxyRequestDetailsDto> getAllProxyRequestDetails() {
		List<ProxyRequestDetails> proxyRequestsDetails = iaaaProxiesGenericRepository.findAll(ProxyRequestDetails.class);

		List<ProxyRequestDetailsDto> proxyRequestsDtos = conversionService.convertList(proxyRequestsDetails, ProxyRequestDetailsDto.class);

		return proxyRequestsDtos;
	}

	@Transactional(BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER)
	public Integer saveOrUpdateProxyRequestParams(ProxyRequestParams proxyRequestParams) {

		ProxyRequestDetails requestDetails = conversionService.convert(proxyRequestParams, ProxyRequestDetails.class);
		RestTemplateConfig restTemplateConfig = iaaaProxiesGenericRepository.findByIdOrThrow(RestTemplateConfig.class,
					proxyRequestParams.getRestTemplateConfigId());

		requestDetails.setRestTemplateConfig(restTemplateConfig);
		iaaaProxiesGenericRepository.saveOrUpdate(requestDetails);

		return requestDetails.getId();
	}

	@Transactional(BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER)
	public void delete(Integer paramsId) {
		iaaaProxiesGenericRepository.delete(ProxyRequestDetails.class, paramsId);
	}

	@Transactional(BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER)
	public void createCacheTable(CacheTableCreationParams params) {
		iaaaProxiesRepository.createCacheTable(params.getTableName(), params.getDescription());
	}

}
