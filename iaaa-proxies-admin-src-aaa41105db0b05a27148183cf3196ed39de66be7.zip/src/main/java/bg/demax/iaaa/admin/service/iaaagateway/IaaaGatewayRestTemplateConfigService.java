package bg.demax.iaaa.admin.service.iaaagateway;

import java.io.IOException;
import java.security.cert.X509Certificate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.controller.params.proxyrequests.RestTemplateConfigParams;
import bg.demax.iaaa.admin.controller.params.proxyrequests.SSLCertificateDetailsParams;
import bg.demax.iaaa.admin.converter.AppConversionService;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.RestTemplateConfig;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.SSLCertificateData;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.SSLCertificateDetails;
import bg.demax.iaaa.admin.db.repository.GenericRepository;
import bg.demax.iaaa.admin.dto.RestTemplateConfigDto;
import bg.demax.iaaa.admin.exception.ApplicationException;
import bg.demax.iaaa.admin.service.X509Service;

@Service
public class IaaaGatewayRestTemplateConfigService {
	private static final String COULD_NOT_GET_CERTIFICATE_CONTENTS = "Could not get file contents.";

	@Autowired
	private X509Service x509Service;

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_GENERIC_REPOSITORY)
	private GenericRepository iaaaProxiesGenericRepository;

	@Autowired
	private AppConversionService conversionService;

	@Transactional(transactionManager = BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER, readOnly = true)
	public List<RestTemplateConfigDto> getAllRestTemplateConfigs() {
		List<RestTemplateConfig> configs = iaaaProxiesGenericRepository.findAll(RestTemplateConfig.class);

		return conversionService.convertList(configs, RestTemplateConfigDto.class);
	}

	@Transactional(transactionManager = BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER, readOnly = true)
	public RestTemplateConfigDto getRestTemplateConfig(Integer restTemplateConfigId) {
		RestTemplateConfig restTemplateConfig = iaaaProxiesGenericRepository
				.findByIdOrThrow(RestTemplateConfig.class, restTemplateConfigId);

		return conversionService.convert(restTemplateConfig, RestTemplateConfigDto.class);
	}

	@Transactional(BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER)
	public RestTemplateConfig saveOrUpdate(RestTemplateConfigParams restTemplateConfigParams, MultipartFile keyStore, MultipartFile trustStore) {
		RestTemplateConfig restTemplateConfig = null;

		if (restTemplateConfigParams.getId() != null) {
			restTemplateConfig = iaaaProxiesGenericRepository.findById(RestTemplateConfig.class, restTemplateConfigParams.getId());
		} else {
			restTemplateConfig = new RestTemplateConfig();
		}

		saveOrUpdateCert(keyStore,
				restTemplateConfigParams.getKeyStore(),
				restTemplateConfig::getKeyStore, restTemplateConfig::setKeyStore);

		saveOrUpdateCert(trustStore,
				restTemplateConfigParams.getTrustStore(),
				restTemplateConfig::getTrustStore, restTemplateConfig::setTrustStore);


		restTemplateConfig.setReadTimeout(restTemplateConfigParams.getReadTimeout());
		restTemplateConfig.setConnectionTimeout(restTemplateConfigParams.getConnectionTimeout());
		restTemplateConfig.setDescription(restTemplateConfigParams.getDescription());

		restTemplateConfig.setBasicAuthPassword(restTemplateConfigParams.getBasicAuthPassword());
		restTemplateConfig.setBasicAuthUsername(restTemplateConfigParams.getBasicAuthUsername());

		iaaaProxiesGenericRepository.save(restTemplateConfig);
		return restTemplateConfig;
	}

	@Transactional(BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER)
	public void deleteRestTemplateConfig(Integer restTemplateConfigId) {
		RestTemplateConfig restTemplateConfig = iaaaProxiesGenericRepository.findByIdOrThrow(RestTemplateConfig.class, restTemplateConfigId);
		deleteCertDetails(restTemplateConfig.getKeyStore());
		deleteCertDetails(restTemplateConfig.getTrustStore());
		iaaaProxiesGenericRepository.delete(restTemplateConfig);
	}

	@Transactional(transactionManager = BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER, readOnly = true)
	public ResponseEntity<byte[]> getCertificateForDownload(int certificateId) {
		SSLCertificateDetails certDetails = iaaaProxiesGenericRepository.findByIdOrThrow(SSLCertificateDetails.class, certificateId);
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_DISPOSITION, String.format("attachment; filename=\"%s\"", certDetails.getName()));

		headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);

		ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(certDetails.getCertData().getData(), headers,
				HttpStatus.OK);
		return response;
	}

	private void saveOrUpdateCert(MultipartFile file, SSLCertificateDetailsParams certParams, Supplier<SSLCertificateDetails> certGetter,
			Consumer<SSLCertificateDetails> certSetter) {

		if (certParams.getId() != null) {
			if (certGetter.get() == null || certGetter.get().getId() != certParams.getId()) {
				throw new ApplicationException("One ssl certificate details can be used for only 1 rest template config.");
			} else {
				return;
			}
		}

		SSLCertificateDetails currentCertDetails = certGetter.get();
		certSetter.accept(null);
		deleteCertDetails(currentCertDetails);

		boolean hasAllRequiredInputsForNewSslCertDetails = file != null
														&& certParams != null
														&& certParams.getPassword() != null
														&& certParams.getPassword().trim().length() > 0;


		if (hasAllRequiredInputsForNewSslCertDetails) {
			SSLCertificateDetails sslCertificateData = createAndPersistSslCertificateDetails(file, certParams.getPassword());
			certSetter.accept(sslCertificateData);
		}

	}

	private SSLCertificateDetails createAndPersistSslCertificateDetails(MultipartFile file, String certPassword) {
		SSLCertificateDetails certDetails = new SSLCertificateDetails();
		SSLCertificateData sslCertificateData = new SSLCertificateData();

		byte[] certBytes = null;
		try {
			certBytes = file.getBytes();
		} catch (IOException e) {
			throw new ApplicationException(COULD_NOT_GET_CERTIFICATE_CONTENTS, e);
		}

		String storeType = getCertType(file);
		X509Certificate x509cert = x509Service.readCert(storeType, certBytes, certPassword);

		sslCertificateData.setData(certBytes);
		certDetails.setType(storeType);
		certDetails.setValidTo(convertToLocalDateTimeViaInstant(x509cert.getNotAfter()));
		certDetails.setName(file.getOriginalFilename());
		certDetails.setPassword(certPassword);
		String description = x509cert.getSubjectDN().toString();
		certDetails.setDescription(description);

		iaaaProxiesGenericRepository.save(sslCertificateData);
		certDetails.setCertData(sslCertificateData);
		iaaaProxiesGenericRepository.save(certDetails);

		return certDetails;
	}

	private String getCertType(MultipartFile cert) {
		switch (cert.getContentType()) {
			case "application/x-java-keystore":
				return "JKS";
			case "application/x-pkcs12":
				return "PKCS12";
			default:
				throw new ApplicationException("Unexpected keystore type");
		}
	}

	private LocalDateTime convertToLocalDateTimeViaInstant(Date dateToConvert) {
		return dateToConvert.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
	}

	private void deleteCertDetails(SSLCertificateDetails certDetails) {
		if (certDetails == null) {
			return;
		}

		SSLCertificateData data = certDetails.getCertData();
		iaaaProxiesGenericRepository.delete(certDetails);
		iaaaProxiesGenericRepository.delete(data);
	}
}
