package bg.demax.iaaa.admin.service.iaaagateway;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.exception.IaaaGatewayUpdateException;

@Service
public class IaaaGatewayUpdateService {
	private static final String UPDATE_REQUEST_PROXY_CONFIG_PATH = "/api/rest-proxying/config/";

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_ADMIN_REST_TEMPLATE_FOR_PROXY_APPS)
	private RestTemplate restTemplate;

	@Value("${iaaa.gateway.address}")
	private String iaaaGatewayBaseAddress;

	public void updateIaaaGatewayRequestProxyDetails(Integer id) {
		String fullUrl = iaaaGatewayBaseAddress + UPDATE_REQUEST_PROXY_CONFIG_PATH + id;

		try {
			restTemplate.put(fullUrl, null);
		} catch (Exception e) {
			throw new IaaaGatewayUpdateException(e);
		}

	}
}
