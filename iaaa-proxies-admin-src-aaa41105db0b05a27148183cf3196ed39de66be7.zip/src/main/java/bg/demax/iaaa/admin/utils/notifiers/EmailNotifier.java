package bg.demax.iaaa.admin.utils.notifiers;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.spi.StandardLevel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;

@Component
@Profile("!" + IaaaProxiesAdminWebConstants.SPRING_PROFILE_UNIT_TEST)
public class EmailNotifier implements IProjectSupportNotifier {

	private static final String DEFAULT_SUBJECT = "IAAA Proxies Admin - There was a problem";

	@Value("${project.mail.sender}")
	private String sender;

	@Value("${project.mail.level}")
	private Level level;

	@Autowired
	private JavaMailSender emailSender;

	@Override
	public void notify(String notification, Level notificationLevel) {
		if (notificationLevel.intLevel() <= level.intLevel() && notificationLevel.intLevel() > StandardLevel.OFF.intLevel()) {
			process(notification);
		}
	}

	private void process(String notification) {
		SimpleMailMessage message = new SimpleMailMessage();

		message.setFrom(sender);
		message.setTo(IaaaProxiesAdminWebConstants.TEAM_SPIKE);
		message.setSubject(DEFAULT_SUBJECT);
		message.setText(notification);

		emailSender.send(message);
	}
}
