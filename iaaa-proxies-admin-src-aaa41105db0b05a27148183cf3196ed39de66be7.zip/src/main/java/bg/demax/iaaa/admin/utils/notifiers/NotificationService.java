package bg.demax.iaaa.admin.utils.notifiers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {

	private static final String NEW_LINE = "\n";

	@Autowired(required = false)
	private List<IProjectSupportNotifier> notifiers = new ArrayList<>();

	@Autowired
	private Environment env;

	public void notify(String notification) {
		notify(notification, Level.INFO);
	}

	public void notify(String notification, Level level) {
		if (notification != null && !notification.trim().isEmpty()) {
			String message = NEW_LINE + "*Active spring profiles*: "
					+ Arrays.toString(env.getActiveProfiles()) + NEW_LINE + "*Message*: " + notification;
			notifiers.forEach(notifier -> notifier.notify(message, level));

		}
	}

	public void notify(List<String> notifications, Level level) {
		if (notifications != null && !notifications.isEmpty()) {
			StringBuilder sb = new StringBuilder(NEW_LINE).append(NEW_LINE);
			for (int i = 0; i < notifications.size(); i++) {
				sb.append("*").append(i + 1).append(":* ").append(notifications.get(i)).append(NEW_LINE).append(NEW_LINE);
			}
			notify(sb.toString(), level);
		}
	}
}
