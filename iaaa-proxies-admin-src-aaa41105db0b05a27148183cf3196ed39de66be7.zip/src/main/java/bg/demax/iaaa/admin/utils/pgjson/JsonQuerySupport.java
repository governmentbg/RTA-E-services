package bg.demax.iaaa.admin.utils.pgjson;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import bg.demax.iaaa.admin.exception.ApplicationException;
import bg.demax.iaaa.admin.utils.MapAndList;

public class JsonQuerySupport {
	private static final Logger logger = LogManager.getLogger(JsonQuerySupport.class);

	public static String process(List<String> filters, String queryHeader, String queryFooter) {
		StringBuilder sb = new StringBuilder();
		sb.append(queryHeader);
		if (!queryHeader.contains("WHERE")) {
			sb.append(" WHERE 1 = 1 ");
		}
		for (String jsonQueryFilter : filters) {
			sb.append(" AND ");
			sb.append(jsonQueryFilter);
		}
		sb.append(" ");
		sb.append(queryFooter);

		logger.trace("JSON Query: " + sb.toString());

		return sb.toString();
	}

	public static MapAndList getMapAndList(Object o) {
		MapAndList paramsMapAndFiltersList = new MapAndList();
		paramsMapAndFiltersList.setList(new ArrayList<>());
		paramsMapAndFiltersList.setMap(new HashMap<>());

		return getMapAndList(o, o.getClass(), paramsMapAndFiltersList);
	}

	private static MapAndList getMapAndList(Object o, Class<?> clazz, MapAndList paramsMapAndFiltersList) {
		Map<String, String> paramsMap = paramsMapAndFiltersList.getMap();
		List<String> filters = paramsMapAndFiltersList.getList();


		for (Field field : clazz.getDeclaredFields()) {
			if (!field.isAnnotationPresent(SearchConstraint.class)) {
				continue;
			}

			boolean originalAccessability = field.isAccessible();
			field.setAccessible(true);

			String fieldName = field.getName();
			String value = null;
			try {
				Object objVal = field.get(o);
				if (objVal != null) {
					value = objVal.toString();
				}
			} catch (IllegalArgumentException | IllegalAccessException e) {
				throw new ApplicationException("Invalid query parameter:" + field.getName());
			}

			if (value != null) {
				SearchConstraint annotation = field.getAnnotation(SearchConstraint.class);
				String filter = annotation.value();
				filters.add(filter);
				paramsMap.put(fieldName, value);
			}

			field.setAccessible(originalAccessability);
		}

		Class<?> objSuperClass = clazz.getSuperclass();
		if (objSuperClass != null && objSuperClass != Object.class) {
			getMapAndList(o, objSuperClass, paramsMapAndFiltersList);
		}

		return paramsMapAndFiltersList;
	}

}