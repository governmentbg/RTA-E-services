package bg.demax.iaaa.admin.utils.pgjson.search;

import java.time.LocalDateTime;

import bg.demax.iaaa.admin.service.VehicleInfoService;
import bg.demax.iaaa.admin.utils.pgjson.SearchConstraint;

public class VehicleInfoSearch {
	@SearchConstraint("(workflow->>'requestTime')::timestamp >= :requestTimeFrom::timestamp")
	private LocalDateTime requestTimeFrom;

	@SearchConstraint("(workflow->>'requestTime')::timestamp <= :requestTimeTo::timestamp")
	private LocalDateTime requestTimeTo;

	@SearchConstraint("workflow->'request'->'request'->'vehicleOwnerData'->>'vehOwnerId' = :vehOwnerId")
	private String vehOwnerId;

	@SearchConstraint("workflow->'request'->'request'->'vehicleRequestData'->'vehDocument'->>'vehDocumentNumber' = :vehDocumentNumber")
	private String vehDocumentNumber;

	@SearchConstraint("workflow->'request'->'request'->'vehicleRequestData'->>'vehRegistrationNumber' = :vehRegistrationNumber")
	private String vehRegistrationNumber;

	@SearchConstraint("workflow->'response'->'response'->'returnInformation'->>'returnCode' = :returnCode")
	private Integer returnCode;

	@SearchConstraint("(" + VehicleInfoService.ELEMENT_ALIAS + " -> 'vehicleOwnerVerification' ->> 'value'= :vehicleOwnerVerification AND "
			+ VehicleInfoService.ELEMENT_ALIAS + " -> 'vehicleDocumentResponseData' ->> 'vehDocumentIDNumber' = "
			+ "ict.workflow -> 'request' -> 'request' -> 'vehicleRequestData' -> 'vehDocument' ->> 'vehDocumentNumber')")
	private Integer vehicleOwnerVerification;

	public LocalDateTime getRequestTimeFrom() {
		return requestTimeFrom;
	}

	public void setRequestTimeFrom(LocalDateTime requestTimeFrom) {
		this.requestTimeFrom = requestTimeFrom;
	}

	public LocalDateTime getRequestTimeTo() {
		return requestTimeTo;
	}

	public void setRequestTimeTo(LocalDateTime requestTimeTo) {
		this.requestTimeTo = requestTimeTo;
	}

	public String getVehOwnerId() {
		return vehOwnerId;
	}

	public void setVehOwnerId(String vehOwnerId) {
		this.vehOwnerId = vehOwnerId;
	}

	public String getVehDocumentNumber() {
		return vehDocumentNumber;
	}

	public void setVehDocumentNumber(String vehDocumentNumber) {
		this.vehDocumentNumber = vehDocumentNumber;
	}

	public String getVehRegistrationNumber() {
		return vehRegistrationNumber;
	}

	public void setVehRegistrationNumber(String vehRegistrationNumber) {
		this.vehRegistrationNumber = vehRegistrationNumber;
	}

	public Integer getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(Integer returnCode) {
		this.returnCode = returnCode;
	}

	public Integer getVehicleOwnerVerification() {
		return vehicleOwnerVerification;
	}

	public void setVehicleOwnerVerification(Integer vehicleOwnerVerification) {
		this.vehicleOwnerVerification = vehicleOwnerVerification;
	}
}
