package bg.demax.iaaa.admin.utils.validators;

import java.lang.reflect.Field;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import bg.demax.iaaa.admin.exception.ApplicationException;

public class DateRangeValidator implements ConstraintValidator<ValidDateRange, Object> {
	private ChronoUnit unit;
	private int maxPeriod;
	private String startFieldName;
	private String endFieldName;

	public void initialize(ValidDateRange constraintAnnotation) {
		this.startFieldName = constraintAnnotation.start();
		this.endFieldName = constraintAnnotation.end();
		this.unit = constraintAnnotation.unit();
		this.maxPeriod = constraintAnnotation.maxPeriod();
	}

	@Override
	public boolean isValid(Object requestParam, ConstraintValidatorContext constraintValidatorContext) {
		LocalDateTime from = getLocalDateTime(requestParam, startFieldName);
		LocalDateTime to = getLocalDateTime(requestParam, endFieldName);;

		boolean result;

		if (from == null || to == null) {
			result = false;
		} else {
			Duration duration = Duration.between(from, to);
			Duration maxDuration =  Duration.of(this.maxPeriod, this.unit);
			result = duration.getSeconds() <= maxDuration.getSeconds() && duration.getSeconds() > 0;
		}

		return result;
	}

	private LocalDateTime getLocalDateTime(Object requestParam, String fieldName) {
		LocalDateTime value = null;
		try {
			Field field = requestParam.getClass().getDeclaredField(fieldName);
			boolean originalAccessability = field.isAccessible();
			field.setAccessible(true);
			LocalDateTime objVal = (LocalDateTime) field.get(requestParam);
			if (objVal != null) {
				value = objVal;
			}
			field.setAccessible(originalAccessability);

		} catch (NoSuchFieldException e1) {
			throw new ApplicationException("No such field with name: " + fieldName);
		} catch (SecurityException | IllegalArgumentException | IllegalAccessException e) {
			e.printStackTrace();
		}
		return value;

	}
}
