package bg.demax.iaaa.admin.utils.validators;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.time.temporal.ChronoUnit;

import javax.validation.Constraint;
import javax.validation.Payload;

@Documented
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = { DateRangeValidator.class })
public @interface ValidDateRange {

	public ChronoUnit unit() default ChronoUnit.DAYS;

	public int maxPeriod() default 1;

	public String start() default "";

	public String end() default "";

	String message() default "Date range must be less than or equal to expected";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};
}
