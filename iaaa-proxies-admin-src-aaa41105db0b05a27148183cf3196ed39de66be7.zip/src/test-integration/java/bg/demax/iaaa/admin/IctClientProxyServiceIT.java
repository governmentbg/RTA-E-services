package bg.demax.iaaa.admin;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.math.BigInteger;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import bg.demax.iaaa.admin.config.BeanConfiguration;
import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;
import bg.demax.iaaa.admin.dto.VehicleResponseWithRequestCountDto;
import bg.demax.iaaa.admin.service.IctClientProxyService;
import bg.demax.ictclient.dtos.VehicleRequestDto;

@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles(IaaaProxiesAdminWebConstants.SPRING_PROFILE_TEST)
@ContextConfiguration(classes = { IctClientProxyService.class, BeanConfiguration.class })
public class IctClientProxyServiceIT {

	@Autowired
	private IctClientProxyService ictClientProxyService;

	@Test
	public void testGetVehicleResponseDto() throws IOException {
		VehicleRequestDto requestDto = getVehicleRequestDto("В0753ВХ", "007376393", "7706015829");

		VehicleResponseWithRequestCountDto responseDto = ictClientProxyService.getVehicleResponseDto(requestDto);

		assertTrue(responseDto != null);
		assertEquals(IaaaProxiesAdminWebConstants.VEH_VERIFICATION_SUCCESS_RETURN_CODE,
				responseDto.getVehicleResponseDto().getReturnInformation().getReturnCode());
		assertEquals(1, responseDto.getRequestWithDiffOwnerIdCount());
	}

	//use when production profile is set
	@Test
	public void testGetVehicleResponseDtoProd() throws IOException {
		VehicleRequestDto requestDto = getVehicleRequestDto("A0177EK", "004006324", "102925390");

		VehicleResponseWithRequestCountDto responseDto = ictClientProxyService.getVehicleResponseDto(requestDto);

		assertTrue(responseDto != null);
		assertEquals(IaaaProxiesAdminWebConstants.VEH_VERIFICATION_SUCCESS_RETURN_CODE,
				responseDto.getVehicleResponseDto().getReturnInformation().getReturnCode());
		assertEquals(1, responseDto.getRequestWithDiffOwnerIdCount());
	}

	@Test
	public void testGetVehicleResponseDto_requests_with_diff_owner_id() throws IOException {
		VehicleRequestDto requestDto = getVehicleRequestDto("А0296Н", "007395274", "3905196960");

		/* Sending request with valid reg num, doc num and owner id */
		VehicleResponseWithRequestCountDto responseDto = ictClientProxyService.getVehicleResponseDto(requestDto);
		assertTrue(responseDto != null);
		assertEquals(IaaaProxiesAdminWebConstants.VEH_VERIFICATION_SUCCESS_RETURN_CODE,
				responseDto.getVehicleResponseDto().getReturnInformation().getReturnCode());
		assertEquals(IaaaProxiesAdminWebConstants.VEH_OWNER_ID_MATCH_VERIFICATION_CODE,
				responseDto.getVehicleResponseDto().getVehicleDtos().get(0).getVehOwnerVerification().intValue());
		assertEquals(1, responseDto.getRequestWithDiffOwnerIdCount());

		requestDto.setOwnerId("7503121645");

		/* Sending request with same reg num and doc num and different, wrong owner id */
		responseDto = ictClientProxyService.getVehicleResponseDto(requestDto);

		assertTrue(responseDto != null);
		assertEquals(IaaaProxiesAdminWebConstants.VEH_VERIFICATION_SUCCESS_RETURN_CODE,
				responseDto.getVehicleResponseDto().getReturnInformation().getReturnCode());
		assertEquals(IaaaProxiesAdminWebConstants.VEH_OWNER_ID_NO_MATCH_VERIFICATION_CODE,
				responseDto.getVehicleResponseDto().getVehicleDtos().get(0).getVehOwnerVerification().intValue());
		assertEquals(2, responseDto.getRequestWithDiffOwnerIdCount());
	}

	private VehicleRequestDto getVehicleRequestDto(String regNum, String docNum, String ownerId) {
		VehicleRequestDto requestDto = new VehicleRequestDto();

		requestDto.setVehicleRegistrationNumber(regNum);
		requestDto.setDocumentType(BigInteger.valueOf(1));
		requestDto.setVehicleDocumentNumber(docNum);
		requestDto.setOwnerId(ownerId);

		return requestDto;
	}
}
