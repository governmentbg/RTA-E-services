package bg.demax.iaaa.admin.config;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.web.client.RestTemplate;

import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;
import bg.demax.iaaa.admin.utils.TestUtils;

@Configuration
@Profile(IaaaProxiesAdminWebConstants.SPRING_PROFILE_TEST)
public class RegixConfig {

	@Bean
	@Qualifier(TestConstants.THEORETICAL_EXAMS_USER_DRIVE_ENV_REST_TEMPLATE)
	public RestTemplate regixRtRestTemplate() throws KeyManagementException, UnrecoverableKeyException,
			NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException, Exception {

		char[] keystorePass = "12345678".toCharArray();
		char[] truststorePass = "testdrive".toCharArray();

		String keyStoreFile = "regix/drive_theoretical_exams/keystore.jks";
		String trustStoreFile = "regix/drive_theoretical_exams/truststore.jks";

		return TestUtils.createRestTemplateWithSSL(keyStoreFile, trustStoreFile, keystorePass, truststorePass);
	}

	@Bean
	@Qualifier(TestConstants.TECHINSP_USER_25_ENV_REST_TEMPLATE)
	public RestTemplate techinspUserRestTemplate() throws KeyManagementException, UnrecoverableKeyException,
		NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException, Exception {
		return TestUtils.createRegixTemplateWithSsl("25_techinsp_motor_vehicle_reg_check");
	}

	@Bean
	@Qualifier(TestConstants.THEORETICAL_EXAMS_USER_IAAA_25_ENV_REST_TEMPLATE)
	public RestTemplate apacheClient25EnvRestTemplate() throws KeyManagementException, UnrecoverableKeyException,
		NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException, Exception {
		return TestUtils.createRegixTemplateWithSsl("25_theoretical_exams_user");
	}

	@Bean
	@Qualifier(TestConstants.ADR_25_ENV_REST_TEMPLATE)
	public RestTemplate apacheClientAdr25EnvRestTemplate() throws KeyManagementException, UnrecoverableKeyException,
		NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException, Exception {
		return TestUtils.createRegixTemplateWithSsl("25_adr");
	}

	@Bean
	@Qualifier(TestConstants.DQC_25_ENV_REST_TEMPLATE)
	public RestTemplate apacheClientDqc25EnvRestTemplate() throws KeyManagementException, UnrecoverableKeyException,
		NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException, Exception {
		return TestUtils.createRegixTemplateWithSsl("25_dqc");
	}

	@Bean
	@Qualifier(TestConstants.TACHONET_25_ENV_REST_TEMPLATE)
	public RestTemplate apacheClientTachonet25EnvRestTemplate() throws KeyManagementException, UnrecoverableKeyException,
		NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException, Exception {
		return TestUtils.createRegixTemplateWithSsl("25_tachonet");
	}
}
