package bg.demax.iaaa.admin.gateway;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.function.Supplier;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;

import bg.demax.iaaa.admin.config.BeanConfiguration;
import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;
import bg.demax.iaaa.admin.testutils.ObjectMapperUtils;

@SpringBootTest
@RunWith(SpringRunner.class)
//@ActiveProfiles(IaaaProxiesAdminWebConstants.SPRING_PROFILE_PRODUCTION)
@ActiveProfiles(IaaaProxiesAdminWebConstants.SPRING_PROFILE_TEST)
@ContextConfiguration(classes = { BeanConfiguration.class })
@EnableConfigurationProperties
public class IaaaGatewayIT {

	/*
	 * iaaa25 to localhost - when having to go through a jumphost when using VPN
	 * To forward execute:
	 *
	 * ssh -J backend@drive.demax.bg backend@192.168.168.25 -L10000:localhost:8443
	 *
	 * ---------------------
	 *
	 * change profile to PRODUCTION iaaa28 to localhost - when having to go through a jumphost when using VPN
	 * To forward execute:
	 *
	 * ssh -J backend@drive.demax.bg backend@192.168.168.28 -L10001:localhost:8443
	 */

	private static final String IAAA_GATEWAY_TEST_BASE_URL = "https://localhost:10000/iaaa-gateway";
	private static final String IAAA_GATEWAY_TEST_DEV_BASE_URL = "https://localhost:10000/iaaa-gateway-dev";

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_ADMIN_REST_TEMPLATE_FOR_PROXY_APPS)
	private RestTemplate restTemplate;

	@Test
	public void test_dqc_valid_card_check_auto_proxy() {
		String dqcValidCardCheckUrl = IAAA_GATEWAY_TEST_BASE_URL + "/api/proxy/auto/valid-card-check/persons/5903173260";
		executeHandleRestTemplateCall(() -> this.restTemplate.getForEntity(dqcValidCardCheckUrl, String.class));
	}

	@Test
	public void test_dqc_roster_check_auto_proxy() {
		String url = IAAA_GATEWAY_TEST_BASE_URL	+ "/api/proxy/auto/roster-check/persons/" + "5709077986";
		executeHandleRestTemplateCall(() -> restTemplate.getForEntity(url, String.class));
	}

	@Test
	public void test_inspections_all_endpoints() {
		test_iaaaGateway_Inspections_All_Endpoints(this.restTemplate, IAAA_GATEWAY_TEST_BASE_URL);
	}

	@Test
	public void test_road_service_valid_psycho_check() throws JsonProcessingException {
		HashMap<String, String> params = new HashMap<>();
		params.put("ident_num", "8904213887");
		InfoSystemsPsychCheck infoSystemsPsychCheck = new InfoSystemsPsychCheck();
		infoSystemsPsychCheck.setIdentNum("8904213887");
		System.out.println(ObjectMapperUtils.toJson(infoSystemsPsychCheck));

		executeHandleRestTemplateCall(() -> restTemplate.postForEntity(
				IAAA_GATEWAY_TEST_BASE_URL + "/api/proxy/auto/road-service/valid-psycho-cert-check",
				infoSystemsPsychCheck, String.class));
	}

	@Test
	public void test_grao_get_person_data() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		// headers.add("x-cache-first-period", "24");

		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add("egn", "6101047500");

		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, headers);

		executeHandleRestTemplateCall(() -> restTemplate.postForEntity(
				IAAA_GATEWAY_TEST_DEV_BASE_URL + "/api/proxy/auto/grao/person-data",
				request, String.class));
	}

	//**************************************************************************/

	private void test_iaaaGateway_Inspections_All_Endpoints(RestTemplate restTemplate, String baseUrl) {
		List<String> allEndpoints = new ArrayList<String>();
		allEndpoints.add("/api/vehicles/inspections/last/valid?vin=WF0WXXGCDW4S43465");
		allEndpoints.add("/api/vehicles/inspections/last?vin=WF0WXXGCDW4S43465");
		allEndpoints.add("/api/vehicles/inspections/history?vin=WF0WXXGCDW4S43465");

		for (String endpoint : allEndpoints) {
			executeHandleRestTemplateCall(() -> restTemplate.getForEntity(baseUrl + endpoint, String.class));
		}

	}

	private void executeHandleRestTemplateCall(Supplier<ResponseEntity<String>> supplier) {
		ResponseEntity<String> response = null;
		try {
			response = supplier.get();
		} catch (HttpStatusCodeException ex) {
			System.out.println(ex.getResponseBodyAsString());
			throw ex;
		}

		assertTrue(response.getStatusCode().is2xxSuccessful());
		assertNotNull(response.getBody());
		System.out.println(response.getBody());
	}

	private class InfoSystemsPsychCheck {
		@JsonProperty("ident_num")
		private String identNum;

		@SuppressWarnings("unused")
		public String getIdentNum() {
			return identNum;
		}

		public void setIdentNum(String identNum) {
			this.identNum = identNum;
		}
	}

}
