package bg.demax.iaaa.admin.regix;

import bg.demax.regixclient.mvr.bds.CallContextDto;

public enum CallContextDtos {

	IDENTITY_INFO_SEARCH(getIdentityInfoSearchCallContextDto()),
	MOTOR_VEHICLE_REGISTRATION_INFO_SEARCH(getMotorVehicleRegistrationInfoSearchCallContextDto()),
	EMPLOYMENT_CONTRACTS_INFO_SEARCH(getEmploymentContractsInfoSearchCallContextDto()),
	VALID_UIC_INFO_SEARCH(getUICValidationInfoSearchCallContextDto()),
	ACTUAL_STATE_V3(getActualStateV3CallContextDto());

	private final CallContextDto callContextDto;

	private CallContextDtos(CallContextDto callContextDto) {
		this.callContextDto = callContextDto;
	}

	public CallContextDto getDto() {
		return callContextDto;
	}

	private static CallContextDto getIdentityInfoSearchCallContextDto() {
		CallContextDto callContextDto = new CallContextDto();

		callContextDto.setServiceURI("65232:2019-12-23 14:24:30.916");
		callContextDto.setServiceType("За проверовъчна дейност");
		callContextDto.setAdministrationName("Изпълнителна агенция “Автомобилна администрация”");
		callContextDto.setAdministrationOId("2.16.100.1.1.9");
		callContextDto.setLawReason("Съгласно чл. 36, ал. 1, т. 3 от Наредба № 38 от 16.04.2004 г. се проверява"
				+ " самоличността на кандидатите, включени в протокола за изпит.");
		callContextDto.setEmployeeIdentifier("_sivanov@rta.government.bg_");
		callContextDto.setEmployeeNames("С Иванов");

		return callContextDto;
	}

	private static CallContextDto getMotorVehicleRegistrationInfoSearchCallContextDto() {
		CallContextDto callContextDto = new CallContextDto();

		callContextDto.setServiceURI("19682451");
		callContextDto.setServiceType("За проверовъчна дейност");
		callContextDto.setAdministrationName("Изпълнителна агенция “Автомобилна администрация”");
		callContextDto.setAdministrationOId("2.16.100.1.1.9");
		callContextDto.setLawReason("Проверка за регистрация на ППС в МВР съгласно чл. 34, ал. 6 от Наредба № Н-32 от 16.12.2011 г.");
		callContextDto.setEmployeeIdentifier("SYSTEM");
		callContextDto.setEmployeeNames("Информационна система за електронно регистриране на извършените периодични прегледи на ППС,"
				+ " по чл. 11, ал. 2 от Наредба № Н-32 от 16.12.2011 г."
				+ " за периодичните прегледи за проверка на техническата изправност на пътните превозни средства");

		return callContextDto;
	}

	private static CallContextDto getEmploymentContractsInfoSearchCallContextDto() {
		CallContextDto callContextDto = new CallContextDto();

		callContextDto.setServiceURI("41-02-16-7161");
		callContextDto.setServiceType("Административна услуга: 1160 Издаване на карта за квалификация на водача");
		callContextDto.setAdministrationName("Изпълнителна агенция “Автомобилна администрация”");
		callContextDto.setAdministrationOId("2.16.100.1.1.9");
		callContextDto.setLawReason("Съгласно  чл. 29, ал.1 от Наредба № 41 от 4.08.2008 г.");
		callContextDto.setEmployeeIdentifier("SYSTEM");
		callContextDto.setEmployeeNames("Информационна система, обслужваща дейността по издаването на карти за квалификация на водачите");

		return callContextDto;
	}

	private static CallContextDto getUICValidationInfoSearchCallContextDto() {
		CallContextDto callContextDto = new CallContextDto();

		callContextDto.setServiceURI("24-04-2020");
		callContextDto.setServiceType("Издаване на разрешение за обучение на кандидати за придобиване на правоспособност за управление на МПС");
		callContextDto.setAdministrationName("Изпълнителна агенция “Автомобилна администрация”");
		callContextDto.setAdministrationOId("2.16.100.1.1.9");
		callContextDto.setLawReason("Съгласно чл. 2 и чл. 26, ал. 1 от Наредба № 37 от 2.08.2002 г.");
		callContextDto.setEmployeeIdentifier("SYSTEM");
		callContextDto.setEmployeeNames("Информационна система, обслужваща дейността по обучението и изпитите за придобиване на правоспособност "
				+ "за управление на моторно превозно средство и проверочните изпити, по чл. 27, ал. 7 от Наредба № 37 от 2.08.2002 г. за условията"
				+ " и реда за обучение на кандидатите за придобиване на правоспособност за управление на моторно превозно средство и условията и "
				+ "реда за издаване на разрешение за тяхното обучение");

		return callContextDto;
	}

	private static CallContextDto getActualStateV3CallContextDto() {
		CallContextDto callContextDto = new CallContextDto();

		callContextDto.setServiceURI("1916:2020-04-28");
		callContextDto.setServiceType("Провеждане на изпити за придобиване на правоспособност за управление на МПС");
		callContextDto.setAdministrationName("Изпълнителна агенция “Автомобилна администрация”");
		callContextDto.setAdministrationOId("2.16.100.1.1.9");
		callContextDto.setLawReason("Съгласно чл. 29, ал. 3 от Наредба № 38 от 16.04.2004 г");
		callContextDto.setEmployeeIdentifier("SYSTEM");
		callContextDto.setEmployeeNames("Информационна система, обслужваща дейността по обучението и изпитите за придобиване на правоспособност "
				+ "за управление на моторно превозно средство и проверочните изпити, по чл. 27, ал. 7 от Наредба № 37 от 2.08.2002 г. за условията"
				+ " и реда за обучение на кандидатите за придобиване на правоспособност за управление на моторно превозно средство и условията и "
				+ "реда за издаване на разрешение за тяхното обучение");

		return callContextDto;
	}
}
