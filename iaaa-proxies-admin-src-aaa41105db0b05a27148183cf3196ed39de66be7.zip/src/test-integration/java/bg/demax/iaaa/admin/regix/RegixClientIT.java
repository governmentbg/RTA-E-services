package bg.demax.iaaa.admin.regix;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Arrays;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;
import bg.demax.iaaa.admin.config.RegixConfig;
import bg.demax.iaaa.admin.config.TestConstants;
import bg.demax.regixclient.av.tr.actualstatev3.ActualStateRequestDto;
import bg.demax.regixclient.av.tr.actualstatev3.ActualStateResponseDto;
import bg.demax.regixclient.av.tr.uicvalidation.ValidUICIdentifierDto;
import bg.demax.regixclient.av.tr.uicvalidation.ValidUICInfoDto;
import bg.demax.regixclient.mvr.bds.PersonalIdentityDto;
import bg.demax.regixclient.mvr.bds.PersonalResponseDto;
import bg.demax.regixclient.mvr.mpsv2.MotorVehicleIdentifierDto;
import bg.demax.regixclient.mvr.mpsv2.MotorVehicleRegistrationInfoDto;
import bg.demax.regixclient.nra.employmentcontracts.ContractsFilterTypeDto;
import bg.demax.regixclient.nra.employmentcontracts.EikTypeTypeDto;
import bg.demax.regixclient.nra.employmentcontracts.EmploymentContractsIdentifierDto;
import bg.demax.regixclient.nra.employmentcontracts.EmploymentContractsInfoDto;
import bg.demax.regixclient.nra.employmentcontracts.IdentityTypeRequestDto;


@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles(IaaaProxiesAdminWebConstants.SPRING_PROFILE_TEST)
@ContextConfiguration(classes = { RegixConfig.class})
public class RegixClientIT {
	private static final Logger logger = LogManager.getLogger(RegixClientIT.class);

	private static final String DRIVE_DEMAX_REGIX_URL = "https://drive.demax.bg:444/regix-client-proxy";
	private static final String IAAA_25_REGIX_URL = "https://192.168.168.25:8443/regix-client-proxy";
	private static final String LOCALHOST_REGIX_BASE_URL = "https://localhost:10000/regix-client-proxy";

	private static final String RETURN_INFORMATIONS_SUCCESS_CODE = "0000";

	@Autowired
	@Qualifier(TestConstants.THEORETICAL_EXAMS_USER_DRIVE_ENV_REST_TEMPLATE)
	private RestTemplate theoreticalExamsUserDriveEnvRestTemplate;

	@Autowired
	@Qualifier(TestConstants.THEORETICAL_EXAMS_USER_IAAA_25_ENV_REST_TEMPLATE)
	private RestTemplate theoreticalExamsUserIaaa25RestTemplate;

	@Autowired
	@Qualifier(TestConstants.ADR_25_ENV_REST_TEMPLATE)
	private RestTemplate adr25RestTemplate;

	@Autowired
	@Qualifier(TestConstants.TECHINSP_USER_25_ENV_REST_TEMPLATE)
	private RestTemplate techinspUserRestTemplate;

	@Autowired
	private ConfigurableApplicationContext applicationContext;

	//  drive.demax.bg
	@Test
	public void test_getPersonalIdentityInfo_drive_demax_env() {
		test_getPersonalIdentityInfo(this.theoreticalExamsUserDriveEnvRestTemplate, DRIVE_DEMAX_REGIX_URL + "/mvr/personal");
	}

	// ------------------


	//  iaaa25 - 192.168.168.25
	@Test
	public void test_getPersonalIdentityInfo_all_certs_iaaa25_env() {
		test_getPersonalIdentityInfo_all_certs(IAAA_25_REGIX_URL);
	}

	// ------------------

	// iaaa25 to localhost - when having to go through a jumphost when using vpn
	// to forward execute:
	// ssh -J backend@drive.demax.bg backend@192.168.168.25 -L10000:localhost:8443

	@Test
	public void test_getPersonalIdentityInfo_all_certs_localhost() {
		test_getPersonalIdentityInfo_all_certs(LOCALHOST_REGIX_BASE_URL);
	}

	@Test
	public void test_getEmploymentContractsInfo_all_certs_localhost() {
		test_getEmploymentContractsInfo_all_certs(LOCALHOST_REGIX_BASE_URL);
	}

	@Test
	public void test_getValidUICInfo_all_certs_localhost() {
		test_getValidUICInfo_all_certs(LOCALHOST_REGIX_BASE_URL);
	}

	@Test
	public void test_getActualState_all_certs_localhost() {
		test_getActualState_all_certs(LOCALHOST_REGIX_BASE_URL);
	}

	@Test
	public void test_getMotorVehicleRegistrationInfo_localhost() {
		test_getMotorVehicleRegistrationInfo(this.techinspUserRestTemplate, LOCALHOST_REGIX_BASE_URL + "/mvr/motor-vehicle");
	}

	private void test_getPersonalIdentityInfo_all_certs(String baseAddress) {

		Arrays.asList(
				TestConstants.THEORETICAL_EXAMS_USER_IAAA_25_ENV_REST_TEMPLATE,
				TestConstants.ADR_25_ENV_REST_TEMPLATE,
				TestConstants.DQC_25_ENV_REST_TEMPLATE,
				TestConstants.TACHONET_25_ENV_REST_TEMPLATE
				)
			.forEach(qualifier -> {
				RestTemplate rt = BeanFactoryAnnotationUtils.qualifiedBeanOfType(applicationContext.getBeanFactory(),
						RestTemplate.class, qualifier);

				logger.info("running test_getPersonalIdentityInfo with rt qualifier: " + qualifier);
				test_getPersonalIdentityInfo(rt, baseAddress + "/mvr/personal");
			});
	}

	private void test_getEmploymentContractsInfo_all_certs(String baseAddress) {

		Arrays.asList(
				TestConstants.THEORETICAL_EXAMS_USER_IAAA_25_ENV_REST_TEMPLATE,
				TestConstants.ADR_25_ENV_REST_TEMPLATE,
				TestConstants.DQC_25_ENV_REST_TEMPLATE,
				TestConstants.TACHONET_25_ENV_REST_TEMPLATE
				)
			.forEach(qualifier -> {
				RestTemplate rt = BeanFactoryAnnotationUtils.qualifiedBeanOfType(applicationContext.getBeanFactory(),
						RestTemplate.class, qualifier);

				logger.info("running test_getEmploymentContractsInfo with rt qualifier: " + qualifier);
				test_getEmploymentContractsInfo(rt, baseAddress + "/nra/employment-contracts");
			});
	}

	private void test_getValidUICInfo_all_certs(String baseAddress) {

		Arrays.asList(
				TestConstants.THEORETICAL_EXAMS_USER_IAAA_25_ENV_REST_TEMPLATE,
				TestConstants.ADR_25_ENV_REST_TEMPLATE,
				TestConstants.DQC_25_ENV_REST_TEMPLATE,
				TestConstants.TACHONET_25_ENV_REST_TEMPLATE
				)
			.forEach(qualifier -> {
				RestTemplate rt = BeanFactoryAnnotationUtils.qualifiedBeanOfType(applicationContext.getBeanFactory(),
						RestTemplate.class, qualifier);

				logger.info("running test_getValidUICInfo with rt qualifier: " + qualifier);
				test_getValidUICInfo(rt, baseAddress + "/av/uic-validation");
			});
	}

	private void test_getActualState_all_certs(String baseAddress) {

		Arrays.asList(
				TestConstants.THEORETICAL_EXAMS_USER_IAAA_25_ENV_REST_TEMPLATE,
				TestConstants.ADR_25_ENV_REST_TEMPLATE,
				TestConstants.DQC_25_ENV_REST_TEMPLATE,
				TestConstants.TACHONET_25_ENV_REST_TEMPLATE
				)
			.forEach(qualifier -> {
				RestTemplate rt = BeanFactoryAnnotationUtils.qualifiedBeanOfType(applicationContext.getBeanFactory(),
						RestTemplate.class, qualifier);

				logger.info("running test_getValidUICInfo with rt qualifier: " + qualifier);
				test_getActualState(rt, baseAddress + "/av/actual-state");
			});
	}

	private void test_getPersonalIdentityInfo(RestTemplate restTemplate, String personInfoCheckEndpoint) {

		PersonalIdentityDto personalIdentityDto = new PersonalIdentityDto();
		personalIdentityDto.setCallContext(CallContextDtos.IDENTITY_INFO_SEARCH.getDto());
		personalIdentityDto.setEgn("0051093067");
		personalIdentityDto.setIdentityDocumentNumber("111111111");

		ResponseEntity<PersonalResponseDto> resp = restTemplate.postForEntity(personInfoCheckEndpoint, personalIdentityDto,
				PersonalResponseDto.class);
		assertEquals(resp.getStatusCode(), HttpStatus.OK);
		PersonalResponseDto personalDto = resp.getBody();

		assertNotNull(personalDto);
		assertEquals(RETURN_INFORMATIONS_SUCCESS_CODE, personalDto.getReturnInformation().getReturnCode());
	}

	private void test_getMotorVehicleRegistrationInfo(RestTemplate restTemplate, String motorVehicleRegistrationCheckEndpoint) {

		MotorVehicleIdentifierDto motorVehicleIdentifierDto = new MotorVehicleIdentifierDto();
		motorVehicleIdentifierDto.setRegistrationNumber("test");
		motorVehicleIdentifierDto.setCallContext(CallContextDtos.MOTOR_VEHICLE_REGISTRATION_INFO_SEARCH.getDto());

		ResponseEntity<MotorVehicleRegistrationInfoDto> resp = restTemplate.postForEntity(motorVehicleRegistrationCheckEndpoint,
				motorVehicleIdentifierDto, MotorVehicleRegistrationInfoDto.class);
		assertEquals(resp.getStatusCode(), HttpStatus.OK);
		MotorVehicleRegistrationInfoDto motorVehicleRegistrationDto = resp.getBody();

		assertNotNull(motorVehicleRegistrationDto);
		assertEquals("N2", motorVehicleRegistrationDto.getResults().getResult().get(0).getVehicleData().getCategory());
	}

	private void test_getEmploymentContractsInfo(RestTemplate restTemplate, String employmentContractsCheckEndpoint) {

		EmploymentContractsIdentifierDto identifierDto = new EmploymentContractsIdentifierDto();
		identifierDto.setCallContext(CallContextDtos.EMPLOYMENT_CONTRACTS_INFO_SEARCH.getDto());
		identifierDto.setContractsFilter(ContractsFilterTypeDto.ALL);
		IdentityTypeRequestDto identityTypeRequestDto = new IdentityTypeRequestDto();
		identityTypeRequestDto.setId("test");
		identityTypeRequestDto.setType(EikTypeTypeDto.EGN);
		identifierDto.setIdentity(identityTypeRequestDto);

		ResponseEntity<EmploymentContractsInfoDto> resp = restTemplate.postForEntity(employmentContractsCheckEndpoint,
				identifierDto, EmploymentContractsInfoDto.class);
		assertEquals(resp.getStatusCode(), HttpStatus.OK);
		EmploymentContractsInfoDto infoDto = resp.getBody();

		assertNotNull(infoDto);
		assertEquals(0, infoDto.getStatus().getCode().intValue());
	}

	private void test_getValidUICInfo(RestTemplate restTemplate, String uicValidationCheckEndpoint) {

		ValidUICIdentifierDto identifierDto = new ValidUICIdentifierDto();
		identifierDto.setCallContext(CallContextDtos.VALID_UIC_INFO_SEARCH.getDto());
		identifierDto.setUic("test");

		ResponseEntity<ValidUICInfoDto> resp = restTemplate.postForEntity(uicValidationCheckEndpoint,
				identifierDto, ValidUICInfoDto.class);
		assertEquals(resp.getStatusCode(), HttpStatus.OK);
		ValidUICInfoDto infoDto = resp.getBody();

		assertNotNull(infoDto);
		assertEquals("201593301", infoDto.getUic());
	}

	private void test_getActualState(RestTemplate restTemplate, String actualStateEndpoint) {

		ActualStateRequestDto requestDto = new ActualStateRequestDto();
		requestDto.setCallContext(CallContextDtos.ACTUAL_STATE_V3.getDto());
		requestDto.setUIC("test");
		requestDto.setFieldList("001, 00020");

		ResponseEntity<ActualStateResponseDto> resp = restTemplate.postForEntity(actualStateEndpoint,
				requestDto, ActualStateResponseDto.class);
		assertEquals(resp.getStatusCode(), HttpStatus.OK);
		ActualStateResponseDto responseDto = resp.getBody();

		assertNotNull(responseDto);
		assertEquals("test", responseDto.getDeed().getUIC());
	}
}
