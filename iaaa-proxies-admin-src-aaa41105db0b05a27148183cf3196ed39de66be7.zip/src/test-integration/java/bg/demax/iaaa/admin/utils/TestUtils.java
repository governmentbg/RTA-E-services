package bg.demax.iaaa.admin.utils;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.time.Duration;
import java.util.Arrays;

import javax.net.ssl.SSLContext;

import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.ApplicationContextException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

public class TestUtils {

	public static RestTemplate createRegixTemplateWithSsl(String certsFolder)
			throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException,
			CertificateException, IOException, Exception {

		char[] keystorePass = "12345678".toCharArray();
		char[] truststorePass = "changeit".toCharArray();

		String keyStoreFile = "regix/" + certsFolder + "/keystore.jks";
		String trustStoreFile = "regix/" + certsFolder + "/truststore.jks";

		return createRestTemplateWithSSL(keyStoreFile, trustStoreFile, keystorePass, truststorePass);
	}

	public static RestTemplate createRestTemplateWithSSL(String keyStoreFile, String trustStoreFile, char[] keystorePass,
			char[] truststorePass) throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException,
			KeyStoreException, CertificateException, IOException, Exception {
		SSLContext sslContext = null;

		URL truststoreUrl = TestUtils.class.getClassLoader().getResource(trustStoreFile);

		sslContext = SSLContextBuilder.create().loadKeyMaterial(keyStore(keyStoreFile, keystorePass), keystorePass)
				.loadTrustMaterial(truststoreUrl, truststorePass).build();

		if (sslContext == null) {
			throw new ApplicationContextException("Could not load SSL context.");
		}

		HttpClient client = HttpClients.custom().setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
				.setSSLContext(sslContext).build();

		RestTemplate restTemplate = new RestTemplateBuilder().setConnectTimeout(Duration.ofSeconds(30))
				.setReadTimeout(Duration.ofSeconds(30))
				.requestFactory(() -> new HttpComponentsClientHttpRequestFactory(client)).build();

		restTemplate.getInterceptors().add(new ClientHttpRequestInterceptor() {

			@Override
			public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
					throws IOException {
				HttpHeaders headers = request.getHeaders();
				headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
				return execution.execute(request, body);
			}
		});

		return restTemplate;
	}

	private static KeyStore keyStore(String file, char[] password) throws Exception {
		KeyStore keyStore = KeyStore.getInstance("JKS");

		try (InputStream in = TestUtils.class.getClassLoader().getResourceAsStream(file)) {
			keyStore.load(in, password);
		}
		return keyStore;
	}

}
