for the instance at 192.168.168.25
with a user linked to the regix issued certificate for techinsp motor vehicle
check


CA is TestEnvironmentCA
