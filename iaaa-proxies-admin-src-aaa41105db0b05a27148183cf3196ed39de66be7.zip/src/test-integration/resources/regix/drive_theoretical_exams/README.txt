for the instance at drive.demax.bg
with a user linked to the regix issued certificate for theoretical exams
