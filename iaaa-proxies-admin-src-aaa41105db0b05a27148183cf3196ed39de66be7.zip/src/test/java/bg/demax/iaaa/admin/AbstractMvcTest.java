package bg.demax.iaaa.admin;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashSet;
import java.util.Set;

import org.assertj.core.util.Arrays;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.DefaultMockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import bg.demax.iaaa.admin.db.entity.iaaaimgrepl.Authority;
import bg.demax.iaaa.admin.db.entity.iaaaimgrepl.User;
import bg.demax.iaaa.admin.security.SecurityGroups;
import bg.demax.iaaa.admin.security.SecurityUtilService;
import bg.demax.iaaa.admin.security.UserDetailsImpl;
import bg.demax.iaaa.admin.testutils.SecurityTestUtil;

@WebAppConfiguration
public abstract class AbstractMvcTest extends AbstractRepositoryTest {
	@Autowired
	private WebApplicationContext webApplicationContext;

	protected MockMvc mockMvc;
	protected MvcObjectMapper mvcOm;

	@Before
	public void setup() {
		this.mockMvc = setupMockMvcBuilder(MockMvcBuilders.webAppContextSetup(webApplicationContext), true).build();
		this.mvcOm = new MvcObjectMapper(this.mockMvc);
	}

	protected DefaultMockMvcBuilder setupMockMvcBuilder(DefaultMockMvcBuilder builder, boolean withCsrf) {
		MockHttpServletRequestBuilder mockServletRequestBuilder = MockMvcRequestBuilders.get("/");
		if (withCsrf) {
			mockServletRequestBuilder.with(csrf());
		}

		return builder
				.defaultRequest(mockServletRequestBuilder.contentType(MediaType.APPLICATION_JSON_UTF8)
				.header("X-Requested-With", "XMLHttpRequest"))
				.apply(SecurityMockMvcConfigurers.springSecurity());
	}

	protected ResultActions performRequestWithRole(MockHttpServletRequestBuilder request, String role)
			throws Exception {
		if (!role.startsWith(SecurityUtilService.ROLE_PREFFIX)) {
			role = SecurityUtilService.ROLE_PREFFIX + role;
		}
		User user = new User();
		user.setUserId(1);
		user.setUsername("mock_poli");
		user.setEnabled(true);
		Authority authority = new Authority();
		authority.setAuthorityName(role);
		Set<Authority> authorities = new HashSet<Authority>();
		authorities.add(authority);
		user.setAuthorities(authorities);
		request.with(user(new UserDetailsImpl(user)));
		return mockMvc.perform(request);
	}

	protected void testRequestPermissions(MockHttpServletRequestBuilder request, SecurityGroups securityGroups,
			ResultMatcher whenHasPermissions, ResultMatcher whenNoPermissions) {

		try {
			mockMvc.perform(request).andExpect(status().isForbidden());
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		SecurityTestUtil.getAllRoles().forEach(role -> {
			boolean hasPermission = Arrays.asList(securityGroups.getRolesInGroup()).contains(role);
			ResultMatcher expectedResult = hasPermission ? whenHasPermissions : whenNoPermissions;

			try {
				performRequestWithRole(request, role).andExpect(expectedResult);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

}
