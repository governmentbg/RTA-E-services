package bg.demax.iaaa.admin;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;
import bg.demax.iaaa.admin.testutils.PostgreDbCleaner;
import bg.demax.iaaa.admin.testutils.SqlScriptExecutor;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles(IaaaProxiesAdminWebConstants.SPRING_PROFILE_UNIT_TEST)

//without this data source pools will NOT be closed after context reload and as a result will use up database connections
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public abstract class AbstractRepositoryTest {

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_IMG_REPLICATION_SESSION_FACTORY)
	protected SessionFactory iaaaImgReplSessionFactory;

	@Autowired
	protected SqlScriptExecutor sqlScriptExecutor;

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_IMG_REPLICATION_DATASOURCE)
	protected DataSource iaaaImgDataSource;

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_DB_DATASOURCE)
	protected DataSource iaaaProxiesCacheDbDataSource;

	@Before
	public void reintDatabase() throws SQLException {
		PostgreDbCleaner.trunkateAllAndResetSequences(iaaaImgDataSource.getConnection());
		PostgreDbCleaner.trunkateAllAndResetSequences(iaaaProxiesCacheDbDataSource.getConnection());
	}

	protected SessionFactory getIaaaImgReplSessionFactory() {
		return iaaaImgReplSessionFactory;
	}
}