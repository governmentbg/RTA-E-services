package bg.demax.iaaa.admin;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles(IaaaProxiesAdminWebConstants.SPRING_PROFILE_UNIT_TEST)
public class IaaaProxiesAdminApplicationTests {

	@Test
	public void contextLoads() {
	}

}
