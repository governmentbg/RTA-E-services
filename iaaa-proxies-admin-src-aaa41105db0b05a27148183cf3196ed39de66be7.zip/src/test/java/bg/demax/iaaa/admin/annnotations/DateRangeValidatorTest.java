package bg.demax.iaaa.admin.annnotations;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Method;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.util.List;

import org.junit.Test;

import bg.demax.iaaa.admin.controller.params.VehicleInfoParam;
import bg.demax.iaaa.admin.testutils.ValidatorsUtil;
import bg.demax.iaaa.admin.utils.validators.ValidDateRange;

public class DateRangeValidatorTest {

	private static String defaultErrorMsg;

	public DateRangeValidatorTest() {
		defaultErrorMsg = getDefaultErrorMsg();
	}

	@Test
	public void testDateRangeValidator_OK() throws Exception {

		VehicleInfoParam params = new VehicleInfoParam();
		LocalDateTime dt = LocalDateTime.of(LocalDate.of(2019, Month.JULY, 03), LocalTime.MIDNIGHT);
		params.setRequestTimeTo(dt.plusDays(1));
		params.setRequestTimeFrom(dt);

		List<String> result = ValidatorsUtil.getConstrainViolationMessages(params);
		assertEquals(0, result.size());
	}

	@Test
	public void testDateRangeValidator_Has_Error_Message_DurationIsBigger() throws Exception {

		VehicleInfoParam params = new VehicleInfoParam();
		LocalDateTime dt = LocalDateTime.of(LocalDate.of(2019, Month.JULY, 03), LocalTime.MIDNIGHT);
		params.setRequestTimeTo(dt.plusDays(13));
		params.setRequestTimeFrom(dt);

		List<String> result = ValidatorsUtil.getConstrainViolationMessages(params);
		String errorMsg = result.get(0);

		assertTrue(errorMsg.contains(defaultErrorMsg));
		assertEquals(1, result.size());
	}

	@Test
	public void testDateRangeValidator_Has_Error_Message_DurationIsNegative() throws Exception {

		VehicleInfoParam params = new VehicleInfoParam();
		LocalDateTime dt = LocalDateTime.of(LocalDate.of(2019, Month.JULY, 03), LocalTime.MIDNIGHT);
		params.setRequestTimeTo(dt.minusDays(3));
		params.setRequestTimeFrom(dt);

		List<String> result = ValidatorsUtil.getConstrainViolationMessages(params);
		String errorMsg = result.get(0);

		assertTrue(errorMsg.contains(defaultErrorMsg));
		assertEquals(1, result.size());
	}

	@Test
	public void testDateRangeValidator_Has_Error_Message_Param_Is_Null() throws Exception {

		VehicleInfoParam params = new VehicleInfoParam();
		LocalDateTime dt = LocalDateTime.of(LocalDate.of(2019, Month.JULY, 03), LocalTime.MIDNIGHT);
		params.setRequestTimeTo(null);
		params.setRequestTimeFrom(dt);

		List<String> errMessages = ValidatorsUtil.getConstrainViolationMessages(params);
		boolean hasPassedTest = false;
		for (String errMsg : errMessages) {
			if (errMsg.contains(defaultErrorMsg)) {
				hasPassedTest = true;
			}
		}
		assertTrue(hasPassedTest);
	}

	private String getDefaultErrorMsg() {
		Class<?> clazz = ValidDateRange.class;
		String result = null;
		try {
			Method method = clazz.getDeclaredMethod("message");
			result = (String) method.getDefaultValue();
		} catch (NoSuchMethodException | SecurityException e) {
			e.printStackTrace();
		}
		return result;
	}
}
