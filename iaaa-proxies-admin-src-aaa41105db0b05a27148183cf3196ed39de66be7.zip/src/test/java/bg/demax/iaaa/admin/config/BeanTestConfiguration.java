package bg.demax.iaaa.admin.config;

import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;
import bg.demax.iaaa.admin.config.property.RegDocSenderConfigurationPropertiesRepository;
import bg.demax.iaaa.admin.service.RegDocSenderService;
import bg.demax.iaaa.admin.testutils.SqlScriptExecutor;

@Profile(IaaaProxiesAdminWebConstants.SPRING_PROFILE_UNIT_TEST)
@Configuration
public class BeanTestConfiguration {

	@Bean
	public SqlScriptExecutor sqlScriptExecutor() {
		return new SqlScriptExecutor();
	}

	@Bean
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_ADMIN_REST_TEMPLATE_FOR_PROXY_APPS)
	public RestTemplate iaaaProxiesAdminRtForProxyApps() {
		return Mockito.mock(RestTemplate.class);
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new PasswordEncoder() {

			@Override
			public boolean matches(CharSequence rawPassword, String encodedPassword) {
				return rawPassword.toString().equals(encodedPassword);
			}

			@Override
			public String encode(CharSequence rawPassword) {
				return rawPassword.toString();
			}
		};
	}

	@Bean
	public RegDocSenderConfigurationPropertiesRepository regDocSenderConfigurationPropertiesRepository() {
		return new RegDocSenderConfigurationPropertiesRepository();
	}

	@Service
	@Profile(IaaaProxiesAdminWebConstants.SPRING_PROFILE_UNIT_TEST)
	public class RegDocSenderServiceForTest extends RegDocSenderService {
		@Override
		public void onFullInitializationComplete() {
		}
	}
}
