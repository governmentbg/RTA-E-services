package bg.demax.iaaa.admin.config.db;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.testcontainers.containers.PostgreSQLContainer;

import com.zaxxer.hikari.HikariDataSource;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.testutils.DockerContainerSingletons;

@Configuration
@SuppressWarnings("rawtypes")
public class DataSourceTestConfiguration {

	@Bean
	@Primary
	@Qualifier(BeanQualifierConstants.IAAA_IMG_REPLICATION_DATASOURCE)
	public DataSource iaaaDbReplicationDataSource() throws SQLException {
		PostgreSQLContainer pgContainer = DockerContainerSingletons.getIaaaImgPgContainer();
		HikariDataSource dataSource = new HikariDataSource();
		dataSource.setJdbcUrl(pgContainer.getJdbcUrl());
		dataSource.setPassword(pgContainer.getPassword());
		dataSource.setUsername(pgContainer.getUsername());

		return dataSource;
	}

	@Bean
	@Qualifier(BeanQualifierConstants.IAAA_IMG_DATASOURCE)
	public DataSource iaaaDbDataSource() throws SQLException {
		PostgreSQLContainer pgContainer = DockerContainerSingletons.getIaaaImgPgContainer();
		HikariDataSource dataSource = new HikariDataSource();
		dataSource.setJdbcUrl(pgContainer.getJdbcUrl());
		dataSource.setPassword(pgContainer.getPassword());
		dataSource.setUsername(pgContainer.getUsername());


		return dataSource;
	}

	@Bean
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_DB_DATASOURCE)
	public DataSource iaaaProxiesCacheDbDataSource() throws SQLException {
		PostgreSQLContainer pgContainer = DockerContainerSingletons.getIaaaProxiesCacheDbContainer();

		HikariDataSource dataSource = new HikariDataSource();
		dataSource.setJdbcUrl(pgContainer.getJdbcUrl());
		dataSource.setPassword(pgContainer.getPassword());
		dataSource.setUsername(pgContainer.getUsername());

		return dataSource;
	}
}
