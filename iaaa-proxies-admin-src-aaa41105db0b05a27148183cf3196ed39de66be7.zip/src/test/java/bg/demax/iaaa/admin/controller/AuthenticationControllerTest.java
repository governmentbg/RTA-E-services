package bg.demax.iaaa.admin.controller;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import javax.naming.AuthenticationException;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import bg.demax.iaaa.admin.AbstractMvcTest;
import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.config.WebSecurityConfiguration;
import bg.demax.iaaa.admin.dto.controlleradvice.ApplicationExceptionDto;
import bg.demax.iaaa.admin.testutils.IaaaImgTestScripts;

public class AuthenticationControllerTest extends AbstractMvcTest {

	private static final String AUTHENTICATION_PATH = "/api/authentication";

	@Before
	public void init() {
		sqlScriptExecutor.execute(
				Arrays.asList(IaaaImgTestScripts.INSERT_AUTHORITIES_SCRIPT, IaaaImgTestScripts.INSERT_USERS_SCRIPT,
						IaaaImgTestScripts.INSERT_USERS_AUTHORITIES_SCRIPT), BeanQualifierConstants.IAAA_IMG_REPLICATION_DATASOURCE);
	}

	@Test
	public void authenticate_with_valid_credentials() throws Exception {
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post(AUTHENTICATION_PATH)
				.param(WebSecurityConfiguration.USERNAME_PARAM_NAME, "mock_poli")
				.param(WebSecurityConfiguration.PASSWORD_PARAM_NAME, "password");

		mockMvc.perform(request).andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void authenticate_with_invalid_credentials() throws Exception {
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post(AUTHENTICATION_PATH)
				.param(WebSecurityConfiguration.USERNAME_PARAM_NAME, "wrong_user")
				.param(WebSecurityConfiguration.PASSWORD_PARAM_NAME, "password");

		ResultActions resultActions = mockMvc.perform(request);

		resultActions.andExpect(MockMvcResultMatchers.status().isUnauthorized());
		resultActions.andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE));
		ApplicationExceptionDto applicationExceptionDto = mvcOm.getResponseObjectFromResultActions(resultActions, ApplicationExceptionDto.class);

		assertEquals(AuthenticationException.class.getSimpleName(), applicationExceptionDto.getError());
	}
}
