package bg.demax.iaaa.admin.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.io.FileInputStream;
import java.io.InputStream;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

import org.hibernate.Session;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import bg.demax.iaaa.admin.AbstractMvcTest;
import bg.demax.iaaa.admin.config.property.RegDocSenderConfigurationPropertiesRepository;
import bg.demax.iaaa.admin.controller.params.regdocsender.RegDocSenderFullServiceSettingsParams;
import bg.demax.iaaa.admin.controller.params.regdocsender.RegDocSenderServiceSettingsParams;
import bg.demax.iaaa.admin.db.entity.iaaaimgrepl.RegDocNum;
import bg.demax.iaaa.admin.dto.VehicleResponseWithRequestCountDto;
import bg.demax.iaaa.admin.security.SecurityRole;
import bg.demax.iaaa.admin.service.IctClientProxyService;
import bg.demax.iaaa.admin.service.RegDocSenderService;
import bg.demax.iaaa.admin.testutils.IaaaImgTestScripts;
import bg.demax.iaaa.admin.testutils.ObjectMapperUtils;

public class RegDocSenderControllerTest extends AbstractMvcTest {

	private static final String CONTROLLER_ADDRESS = "/api/reg-doc-sender";
	private static final String SERVICE_SETTINGS_ENDPOINT = CONTROLLER_ADDRESS + "/service-settings";
	private static final String STOP_SERVICE_ENDPOINT = CONTROLLER_ADDRESS + "/service-stop";
	private static final String START_SERVICE_ENDPOINT = CONTROLLER_ADDRESS + "/service-start";

	private static final long TEST_DEFAULT_ERROR_DELAY = 2 * 10;

	@Rule
	public TemporaryFolder tempDir = new TemporaryFolder();

	@MockBean
	private IctClientProxyService ictClientAdminService;

	@Autowired
	private RegDocSenderService regDocSenderService;

	@Autowired
	private RegDocSenderConfigurationPropertiesRepository regDocSenderConfigurationPropertiesRepository;

	@Before
	public void initSetup() {
		regDocSenderConfigurationPropertiesRepository.setPropertiesFilePath(tempDir.getRoot().getAbsolutePath());
		VehicleResponseWithRequestCountDto mockVehResponseDto = new VehicleResponseWithRequestCountDto();
		Mockito.when(ictClientAdminService.getVehicleResponseDto(Mockito.any())).thenReturn(mockVehResponseDto);
		regDocSenderService.setServiceSettings(getDefaultRegDocToIctProxyServiceParams());
		regDocSenderService.startService();
	}

	@After
	public void afterSetup() {
		regDocSenderService.stopService();
	}

	@Test
	@WithMockUser(roles = { SecurityRole.ALL_APPLICATIONS_SUPER_ADMIN })
	public void getReportToIctProxyServiceConfigParams_test() throws Exception {
		MockHttpServletRequestBuilder request = get(SERVICE_SETTINGS_ENDPOINT);
		RegDocSenderFullServiceSettingsParams resParams = mvcOm.getResponseObjectFromRequest(request, RegDocSenderFullServiceSettingsParams.class);
		assertEquals(RegDocSenderService.FIXED_DELAY_DEFAULT, resParams.getRegDocSenderServiceSettingsParams().getFixedDelay().longValue());
	}

	@Test
	@WithMockUser(roles = { SecurityRole.ALL_APPLICATIONS_SUPER_ADMIN })
	public void updateReportToIctProxyServiceSettings_test_with_db() throws Exception {
		sqlScriptExecutor.execute(IaaaImgTestScripts.L_REG_DOC_NUMS_FULL_SCRIPT);

		RegDocSenderServiceSettingsParams params = getRegDocToIctProxyServiceParams();

		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.put(SERVICE_SETTINGS_ENDPOINT, params)
				.content(ObjectMapperUtils.toJson(params));

		mockMvc.perform(request);
		int expectedEntitiesToBeUpdated = 5;
		int delayMultiplier = 2;
		Thread.sleep(expectedEntitiesToBeUpdated * params.getFixedDelay() * delayMultiplier);

		RegDocSenderFullServiceSettingsParams serviceParams = regDocSenderService.getServiceCurrentConfigParams();
		assertEquals(params.getFixedDelay(), serviceParams.getRegDocSenderServiceSettingsParams().getFixedDelay());

		Session session = super.getIaaaImgReplSessionFactory().openSession();
		String hql = "SELECT regDocNum FROM RegDocNum regDocNum";

		List<RegDocNum> regDocNums = session.createQuery(hql, RegDocNum.class).getResultList();
		validateFixedDelay(regDocNums, params.getFixedDelay());
	}

	private void validateFixedDelay(List<RegDocNum> regDocNums, long fixedDelay) {
		List<RegDocNum> filtered = regDocNums
				.stream()
				.filter(rn -> (rn.getLastIctRequest() != null && rn.getLastIctRequest().isAfter(LocalDate.now().atStartOfDay())))
				.collect(Collectors.toList());

		long minFixedDelay = Integer.MAX_VALUE;

		for (int i = 1; i < filtered.size(); i++) {
			LocalDateTime prevLastIctRequest = filtered.get(i - 1).getLastIctRequest();
			LocalDateTime currentLastIctRequest = filtered.get(i).getLastIctRequest();

			Duration duration = Duration.between(currentLastIctRequest, prevLastIctRequest);
			long diff = Math.abs(duration.toMillis());

			if (diff < minFixedDelay) {
				minFixedDelay = diff;
			}
		}

		int tolerance = 30;
		assertTrue(minFixedDelay >= fixedDelay && minFixedDelay < fixedDelay + tolerance);
	}

	@Test
	@WithMockUser(roles = { SecurityRole.ALL_APPLICATIONS_SUPER_ADMIN })
	public void updateReportToIctProxyServiceSettings_test() throws Exception {
		sqlScriptExecutor.execute(IaaaImgTestScripts.L_REG_DOC_NUMS_FULL_SCRIPT);

		RegDocSenderServiceSettingsParams params = getRegDocToIctProxyServiceParams();

		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.put(SERVICE_SETTINGS_ENDPOINT)
				.content(ObjectMapperUtils.toJson(params));

		mockMvc.perform(request);

		RegDocSenderFullServiceSettingsParams serviceParams = regDocSenderService.getServiceCurrentConfigParams();

		assertEquals(params.getFixedDelay(), serviceParams.getRegDocSenderServiceSettingsParams().getFixedDelay());
		assertEquals(params.getErrorsThreshold(), serviceParams.getRegDocSenderServiceSettingsParams().getErrorsThreshold());
	}

	@Test
	@WithMockUser(roles = { SecurityRole.ALL_APPLICATIONS_SUPER_ADMIN })
	public void updateReportToIctProxyServiceSettings_test_if_persisted_to_properties_file() throws Exception {
		sqlScriptExecutor.execute(IaaaImgTestScripts.L_REG_DOC_NUMS_FULL_SCRIPT);
		RegDocSenderServiceSettingsParams params = getRegDocToIctProxyServiceParams();
		LocalDateTime fromInspectionDate = LocalDateTime.now();
		params.setFromInspectionDate(fromInspectionDate);

		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.put(SERVICE_SETTINGS_ENDPOINT)
				.content(ObjectMapperUtils.toJson(params));

		mockMvc.perform(request);

		String propertiesFilePathName = tempDir.getRoot().getAbsolutePath() + RegDocSenderConfigurationPropertiesRepository.PROPERTIES_FILE_NAME;
		Properties prop = new Properties();

		InputStream input = new FileInputStream(propertiesFilePathName);
		prop.load(input);

		assertEquals(fromInspectionDate.toLocalDate(),
				LocalDateTime.parse(prop.getProperty(RegDocSenderConfigurationPropertiesRepository.FROM_INSPECTION_DATE_PROPERTY)).toLocalDate());
	}

	@Test
	@WithMockUser(roles = { SecurityRole.ALL_APPLICATIONS_SUPER_ADMIN })
	public void stopReportToIctProxyService_test() throws Exception {
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.put(STOP_SERVICE_ENDPOINT);
		mockMvc.perform(request);

		RegDocSenderFullServiceSettingsParams serviceParams = regDocSenderService.getServiceCurrentConfigParams();
		assertEquals(false, serviceParams.getIsServiceRunning());
		regDocSenderService.stopService();
	}

	@Test
	@WithMockUser(roles = { SecurityRole.ALL_APPLICATIONS_SUPER_ADMIN })
	public void startReportToIctService_test() throws Exception {
		regDocSenderService.stopService();

		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.put(START_SERVICE_ENDPOINT);
		mockMvc.perform(request);

		RegDocSenderFullServiceSettingsParams serviceParams = regDocSenderService.getServiceCurrentConfigParams();
		assertEquals(true, serviceParams.getIsServiceRunning());
	}

	private RegDocSenderServiceSettingsParams getDefaultRegDocToIctProxyServiceParams() {
		RegDocSenderServiceSettingsParams serviceParams = new RegDocSenderServiceSettingsParams();
		serviceParams.setFixedDelay(RegDocSenderService.FIXED_DELAY_DEFAULT);
		serviceParams.setErrorsThreshold(RegDocSenderService.ERRORS_THRESHOLD_DEFAULT);
		serviceParams.setErrorsDelayBelowThreshold(TEST_DEFAULT_ERROR_DELAY);
		serviceParams.setErrorsDelayAfterThreshold(TEST_DEFAULT_ERROR_DELAY);

		return serviceParams;
	}

	private RegDocSenderServiceSettingsParams getRegDocToIctProxyServiceParams() {
		RegDocSenderServiceSettingsParams serviceParams = new RegDocSenderServiceSettingsParams();
		serviceParams.setFixedDelay(3500L);
		serviceParams.setErrorsThreshold(5);
		serviceParams.setErrorsDelayBelowThreshold(1000L);
		serviceParams.setErrorsDelayAfterThreshold(1000L);

		return serviceParams;
	}
}
