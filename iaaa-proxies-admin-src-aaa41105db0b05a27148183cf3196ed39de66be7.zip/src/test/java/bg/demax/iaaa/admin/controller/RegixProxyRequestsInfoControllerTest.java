package bg.demax.iaaa.admin.controller;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import bg.demax.iaaa.admin.AbstractMvcTest;
import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.dto.RequestDetailsDto;
import bg.demax.iaaa.admin.security.SecurityGroups;
import bg.demax.iaaa.admin.security.SecurityRole;
import bg.demax.iaaa.admin.testutils.IaaaProxiesDbTestScripts;

public class RegixProxyRequestsInfoControllerTest extends AbstractMvcTest {

	private static final String CONTROLLER_PATH = "/api/regix-proxy-request-info";

	@Before
	public void init() {
		sqlScriptExecutor.execute(IaaaProxiesDbTestScripts.INSERT_REGIX_PROXY_REQUEST_INFO, BeanQualifierConstants.IAAA_PROXIES_DB_DATASOURCE);
	}

	@Test
	public void test_permissions_getAllRegixProxyRequestsInfo() throws Exception {
		MockHttpServletRequestBuilder request = get(CONTROLLER_PATH);

		mockMvc.perform(request).andExpect(status().isForbidden());
		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().is2xxSuccessful(), status().isForbidden());
	}

	@Test
	public void test_getAllRegixProxyRequestsInfo() throws Exception {
		MockHttpServletRequestBuilder request = get(CONTROLLER_PATH);

		ResultActions ra = performRequestWithRole(request, SecurityRole.IAAA_PROXIES_ADMIN);
		ra.andExpect(status().isOk());

		List<RequestDetailsDto> regixProxyRequestInfoDtos = mvcOm.getListFromResultActions(ra, RequestDetailsDto.class);
		assertEquals(7, regixProxyRequestInfoDtos.size());
		assertEquals("Справка за лице по документ за самоличност V1", regixProxyRequestInfoDtos.get(0).getName());
	}
}
