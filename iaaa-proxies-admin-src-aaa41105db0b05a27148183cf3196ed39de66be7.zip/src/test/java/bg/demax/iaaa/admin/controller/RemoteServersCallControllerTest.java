package bg.demax.iaaa.admin.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import bg.demax.iaaa.admin.AbstractMvcTest;
import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.controller.params.CallRemoteServerParams;
import bg.demax.iaaa.admin.security.SecurityGroups;
import bg.demax.iaaa.admin.testutils.IaaaProxiesDbTestScripts;
import bg.demax.iaaa.admin.testutils.ObjectMapperUtils;

public class RemoteServersCallControllerTest extends AbstractMvcTest {

	private static final String CONTROLLER_ADDRESS = "/api/remote-server-call";
	private static final String REMOTE_SERVER_CALL_PARAMS_PATH = CONTROLLER_ADDRESS + "/params/";

	@Before
	public void initSetup() {
		sqlScriptExecutor.execute(IaaaProxiesDbTestScripts.IAAA_PROXIES_ADMIN_PREPARED_REQUESTS,
				BeanQualifierConstants.IAAA_PROXIES_DB_DATASOURCE);
	}

	@Test
	public void test_permissions_callRemoteServer() throws Exception {
		MockHttpServletRequestBuilder request = post(CONTROLLER_ADDRESS);

		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isBadRequest(), status().isForbidden());
	}

	@Test
	public void test_permissions_saveOrUpdate() throws Exception {
		MockHttpServletRequestBuilder request = post(REMOTE_SERVER_CALL_PARAMS_PATH);

		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isBadRequest(), status().isForbidden());
	}

	@Test
	public void test_permissions_getAll() throws Exception {
		MockHttpServletRequestBuilder request = get(REMOTE_SERVER_CALL_PARAMS_PATH);

		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isOk(), status().isForbidden());
	}

	@Test
	public void test_permissions_getById() throws Exception {
		MockHttpServletRequestBuilder request = get(REMOTE_SERVER_CALL_PARAMS_PATH + "8");

		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isOk(), status().isForbidden());
	}

	@Test
	public void test_permissions_delete() throws Exception {
		MockHttpServletRequestBuilder request = delete(REMOTE_SERVER_CALL_PARAMS_PATH + "8");

		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isOk(), status().isForbidden());
	}

	// TEST

	@Test
	public void testGetById_OK() throws Exception {
		MockHttpServletRequestBuilder request = get(REMOTE_SERVER_CALL_PARAMS_PATH + "1");
		ResultActions ra = performRequestWithRole(request, SecurityGroups.FULL_ACCESS.getRolesInGroup()[0]);
		CallRemoteServerParams params = mvcOm.getResponseObjectFromResultActions(ra, CallRemoteServerParams.class);

		assertNotNull(params);
		assertEquals(1, params.getId().intValue());
	}

	@Test
	public void testGetAll_OK() throws Exception {
		MockHttpServletRequestBuilder request = get(REMOTE_SERVER_CALL_PARAMS_PATH);
		ResultActions ra = performRequestWithRole(request, SecurityGroups.FULL_ACCESS.getRolesInGroup()[0]);
		List<CallRemoteServerParams> params = mvcOm.getListFromResultActions(ra, CallRemoteServerParams.class);

		assertNotNull(params);
		assertEquals(3, params.size());
	}

	@Test
	public void test_CRUD_Operations_Are_OK() throws Exception {

		// ************** GET ALL ********************** //

		MockHttpServletRequestBuilder request = get(REMOTE_SERVER_CALL_PARAMS_PATH);
		ResultActions ra = performRequestWithRole(request, SecurityGroups.FULL_ACCESS.getRolesInGroup()[0]);
		List<CallRemoteServerParams> params = mvcOm.getListFromResultActions(ra, CallRemoteServerParams.class);

		assertNotNull(params);
		assertEquals(3, params.size());

		// ************* CREATE ************************ //

		CallRemoteServerParams create = params.get(0);
		create.setId(null);

		request = post(REMOTE_SERVER_CALL_PARAMS_PATH);
		request.content(ObjectMapperUtils.toJson(create));

		ra = performRequestWithRole(request, SecurityGroups.FULL_ACCESS.getRolesInGroup()[0]);
		Integer newlyCreatedEntryId = mvcOm.getResponseObjectFromResultActions(ra, Integer.class);

		assertFalse(params.stream().anyMatch(p -> newlyCreatedEntryId == p.getId()));

		// ************* UPDATE ************************ //

		String updatedEndpoint = "/api/proxy/auto/updated";
		CallRemoteServerParams update = params.get(0);
		update.setEndpoint(updatedEndpoint);
		update.setId(newlyCreatedEntryId);
		request.content(ObjectMapperUtils.toJson(update));

		ra = performRequestWithRole(request, SecurityGroups.FULL_ACCESS.getRolesInGroup()[0]);
		Integer updateId = mvcOm.getResponseObjectFromResultActions(ra, Integer.class);

		assertEquals(newlyCreatedEntryId.intValue(), updateId.intValue());

		// ************* GET BY ID ********************* //

		request = get(REMOTE_SERVER_CALL_PARAMS_PATH + newlyCreatedEntryId);
		ra = performRequestWithRole(request, SecurityGroups.FULL_ACCESS.getRolesInGroup()[0]);
		CallRemoteServerParams updated = mvcOm.getResponseObjectFromResultActions(ra, CallRemoteServerParams.class);

		assertEquals(newlyCreatedEntryId.intValue(), updated.getId().intValue());
		assertEquals(updatedEndpoint, updated.getEndpoint());

		// ************* DELETE *********************** //

		request = delete(REMOTE_SERVER_CALL_PARAMS_PATH + newlyCreatedEntryId);
		performRequestWithRole(request, SecurityGroups.FULL_ACCESS.getRolesInGroup()[0]);

		// ************* GET ALL ********************** //

		request = get(REMOTE_SERVER_CALL_PARAMS_PATH);
		ra = performRequestWithRole(request, SecurityGroups.FULL_ACCESS.getRolesInGroup()[0]);
		params = mvcOm.getListFromResultActions(ra, CallRemoteServerParams.class);

		assertNotNull(params);
		assertEquals(3, params.size());
	}
}
