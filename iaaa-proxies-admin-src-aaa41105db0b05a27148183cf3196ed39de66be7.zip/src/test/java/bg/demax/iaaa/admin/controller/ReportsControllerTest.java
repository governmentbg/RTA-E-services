package bg.demax.iaaa.admin.controller;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.util.List;

import org.junit.Test;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import bg.demax.iaaa.admin.AbstractMvcTest;
import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.config.IaaaProxiesAdminWebConstants;
import bg.demax.iaaa.admin.controller.params.VehicleInfoParam;
import bg.demax.iaaa.admin.security.SecurityRole;
import bg.demax.iaaa.admin.testutils.IaaaProxiesDbTestScripts;
import bg.demax.iaaa.admin.testutils.ObjectMapperUtils;

public class ReportsControllerTest extends AbstractMvcTest {

	private static final String CONTROLLER_ADDRESS = "/api/reports";

	@Test
	@WithMockUser(roles = SecurityRole.ALL_APPLICATIONS_SUPER_ADMIN)
	public void testGetFiltered_All_With_Return_Code_1() throws Exception {
		sqlScriptExecutor.execute(IaaaProxiesDbTestScripts.LOGS_VEHICLE_INFO, BeanQualifierConstants.IAAA_PROXIES_DB_DATASOURCE);

		MockHttpServletRequestBuilder request = get(CONTROLLER_ADDRESS);
		VehicleInfoParam params = new VehicleInfoParam();
		params.setReturnCode(IaaaProxiesAdminWebConstants.VEH_VERIFICATION_SYSTEM_ERROR_RETURN_CODE);
		LocalDateTime dt = LocalDateTime.of(LocalDate.of(2019, Month.SEPTEMBER, 25), LocalTime.MIDNIGHT);
		params.setRequestTimeTo(dt);
		params.setRequestTimeFrom(dt.minusDays(1));

		request.params(ObjectMapperUtils.toParams(params));

		/* expected to get all VehicleInfoWorkflow with return Code 1 (error), total count 1 */

		List<String> res = mvcOm.getListFromRequest(request, String.class);
		assertEquals(1, res.size());
	}

	@Test
	@WithMockUser(roles = SecurityRole.ALL_APPLICATIONS_SUPER_ADMIN)
	public void testGetFiltered_All_With_Return_Code_0_and_vehicleOwnerVerification_2() throws Exception {
		sqlScriptExecutor.execute(IaaaProxiesDbTestScripts.LOGS_VEHICLE_INFO, BeanQualifierConstants.IAAA_PROXIES_DB_DATASOURCE);

		MockHttpServletRequestBuilder request = get(CONTROLLER_ADDRESS);
		VehicleInfoParam params = new VehicleInfoParam();
		params.setReturnCode(IaaaProxiesAdminWebConstants.VEH_VERIFICATION_SUCCESS_RETURN_CODE);
		params.setVehicleOwnerVerification(IaaaProxiesAdminWebConstants.VEH_OWNER_ID_NO_MATCH_VERIFICATION_CODE);
		LocalDateTime dt = LocalDateTime.of(LocalDate.of(2019, Month.JULY, 5), LocalTime.MIDNIGHT);

		params.setRequestTimeFrom(dt);
		params.setRequestTimeTo(dt.plusDays(1));
		request.params(ObjectMapperUtils.toParams(params));

		List<String> res = mvcOm.getListFromRequest(request, String.class);
		assertEquals(1, res.size());
	}

	@Test
	@WithMockUser(roles = SecurityRole.ALL_APPLICATIONS_SUPER_ADMIN)
	public void testGetFiltered_With_Null_RequestTimeFrom_Throws_Exception() throws Exception {
		sqlScriptExecutor.execute(IaaaProxiesDbTestScripts.LOGS_VEHICLE_INFO, BeanQualifierConstants.IAAA_PROXIES_DB_DATASOURCE);

		MockHttpServletRequestBuilder request = get(CONTROLLER_ADDRESS);

		VehicleInfoParam params = new VehicleInfoParam();
		LocalDateTime dt = LocalDateTime.of(LocalDate.of(2019, Month.JULY, 03), LocalTime.MIDNIGHT);
		params.setRequestTimeTo(dt.plusDays(1));
		params.setRequestTimeFrom(null);

		request.params(ObjectMapperUtils.toParams(params));

		/* expected to return HTTPStatuc.BAD_REQUEST */
		ResultActions resultActions = mockMvc.perform(request);
		resultActions.andExpect(status().isBadRequest());
	}

	@Test
	@WithMockUser(roles = SecurityRole.ALL_APPLICATIONS_SUPER_ADMIN)
	public void testGetFiltered_With_Negative_Return_Code_Throws_Exception() throws Exception {
		sqlScriptExecutor.execute(IaaaProxiesDbTestScripts.LOGS_VEHICLE_INFO, BeanQualifierConstants.IAAA_PROXIES_DB_DATASOURCE);

		MockHttpServletRequestBuilder request = get(CONTROLLER_ADDRESS);

		VehicleInfoParam params = new VehicleInfoParam();
		LocalDateTime dt = LocalDateTime.of(LocalDate.of(2019, Month.JULY, 03), LocalTime.MIDNIGHT);
		params.setRequestTimeTo(dt.plusDays(1));
		params.setRequestTimeFrom(dt);
		params.setReturnCode(-1);

		request.params(ObjectMapperUtils.toParams(params));

		/* expected to return HTTPStatuc.BAD_REQUEST */
		ResultActions resultActions = mockMvc.perform(request);
		resultActions.andExpect(status().isBadRequest());
	}
}
