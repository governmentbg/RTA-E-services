package bg.demax.iaaa.admin.controller;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import bg.demax.iaaa.admin.AbstractMvcTest;
import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.dto.security.UserDto;
import bg.demax.iaaa.admin.testutils.IaaaImgTestScripts;

public class UserControllerTest extends AbstractMvcTest {
	private static final String MOCK_POLI_USER = "mock_poli";

	private static final String GET_CURRENT_USER_URL = "/api/users/user";

	@Before
	public void init() {
		sqlScriptExecutor.execute(
				Arrays.asList(IaaaImgTestScripts.INSERT_AUTHORITIES_SCRIPT, IaaaImgTestScripts.INSERT_USERS_SCRIPT,
						IaaaImgTestScripts.INSERT_USERS_AUTHORITIES_SCRIPT), BeanQualifierConstants.IAAA_IMG_REPLICATION_DATASOURCE);
	}

	@Test
	public void getCurrentUser_test() throws Exception {

		MockHttpServletRequestBuilder request = get(GET_CURRENT_USER_URL);

		performRequestWithRole(request, "mock_authority");

		UserDto userDto = mvcOm.getResponseObjectFromRequest(request, UserDto.class);
		assertEquals(MOCK_POLI_USER, userDto.getUsername());
	}
}
