package bg.demax.iaaa.admin.controller;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import bg.demax.iaaa.admin.AbstractMvcTest;
import bg.demax.iaaa.admin.dto.VehicleResponseWithRequestCountDto;
import bg.demax.iaaa.admin.security.SecurityRole;
import bg.demax.iaaa.admin.service.IctClientProxyService;
import bg.demax.iaaa.admin.testutils.ObjectMapperUtils;
import bg.demax.ictclient.dtos.ReturnInformations;
import bg.demax.ictclient.dtos.VehicleRequestDto;
import bg.demax.ictclient.dtos.VehicleResponseDto;

public class VehicleRequestControllerTest extends AbstractMvcTest {

	private static final String CONTROLLER_ADDRESS = "/api/vehicles";

	@MockBean
	private IctClientProxyService ictClientAdminService;

	@Test
	@WithMockUser(roles = { SecurityRole.ALL_APPLICATIONS_SUPER_ADMIN })
	public void testgetVehicleResponseDto() throws Exception {
		VehicleRequestDto vehRequestDto = new VehicleRequestDto();
		MockHttpServletRequestBuilder request = get(CONTROLLER_ADDRESS);
		request.params(ObjectMapperUtils.toParams(vehRequestDto));

		VehicleResponseDto vehResponseDto = new VehicleResponseDto();
		ReturnInformations returnInformation = new ReturnInformations();
		returnInformation.setReturnCode((byte) 0);
		vehResponseDto.setReturnInformation(returnInformation);

		VehicleResponseWithRequestCountDto responseDto = new VehicleResponseWithRequestCountDto();
		responseDto.setVehicleResponseDto(vehResponseDto);

		Mockito.when(ictClientAdminService.getVehicleResponseDto(Mockito.any())).thenReturn(responseDto);
		VehicleResponseWithRequestCountDto res = mvcOm.getResponseObjectFromRequest(request, VehicleResponseWithRequestCountDto.class);

		assertEquals(vehResponseDto.getReturnInformation().getReturnCode(), res.getVehicleResponseDto().getReturnInformation().getReturnCode());
	}
}
