package bg.demax.iaaa.admin.controller.iaaagateway;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import bg.demax.iaaa.admin.AbstractMvcTest;
import bg.demax.iaaa.admin.controller.params.proxyrequests.CacheTableCreationParams;
import bg.demax.iaaa.admin.controller.params.proxyrequests.ProxyRequestParams;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.ProxyRequestDetails;
import bg.demax.iaaa.admin.dto.ProxyRequestDetailsDto;
import bg.demax.iaaa.admin.security.SecurityGroups;
import bg.demax.iaaa.admin.security.SecurityRole;
import bg.demax.iaaa.admin.service.iaaagateway.IaaaGatewayProxyRequestsService;
import bg.demax.iaaa.admin.testutils.ObjectMapperUtils;
import bg.demax.iaaa.admin.utils.DbImportService;
import bg.demax.iaaa.admin.utils.IaaaGatewayUtil;

public class IaaaGatewayProxyRequestsControllerTest extends AbstractMvcTest {

	private static final String CONTROLLER_PATH = "/api/iaaa-gateway/proxy-requests";
	private static final String DELETE_PROXY_REQUEST_DETAILS_PATH = CONTROLLER_PATH + "/{id}";
	private static final String CREATE_CACHE_TABLE_PATH = CONTROLLER_PATH + "/create-cache-table";

	private static final int PROXY_REQUEST_DETAILS_ENTRIES_IN_TEST_DB = 3;

	@Autowired
	private DbImportService dbImportService;

	@Autowired
	private IaaaGatewayProxyRequestsService iaaaGatewayProxyRequestsService;

	@Before
	public void init() throws IOException {
		ProxyRequestDetails proxyRequestDetailsWithTrustStore = getProxyRequestDetailsWithTrustStore();
		ProxyRequestDetails proxyRequestDetailsWithoutTrustStore = getProxyRequestDetailsWithoutTrustStore();
		ProxyRequestDetails proxyRequestDetailsWithoutSSL = getProxyRequestDetailsWithoutSSL();

		dbImportService.saveProxyRequestDetails(proxyRequestDetailsWithTrustStore);
		dbImportService.saveProxyRequestDetails(proxyRequestDetailsWithoutTrustStore);
		dbImportService.saveProxyRequestDetails(proxyRequestDetailsWithoutSSL);
	}

	@Test
	public void test_permissions_getAllProxyRequestDetails() throws Exception {
		MockHttpServletRequestBuilder request = get(CONTROLLER_PATH);

		mockMvc.perform(request).andExpect(status().isForbidden());
		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().is2xxSuccessful(), status().isForbidden());
	}

	@Test
	public void test_permissions_saveOrUpdateProxyRequestParams() throws Exception {
		MockHttpServletRequestBuilder request = post(CONTROLLER_PATH);
		request.contentType(MediaType.APPLICATION_JSON_UTF8);
		request.content(ObjectMapperUtils.toJson(proxyRequestParams("/api", HttpMethod.GET)));

		mockMvc.perform(request).andExpect(status().isForbidden());
		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().is2xxSuccessful(), status().isForbidden());
	}

	@Test
	public void test_permissions_deleteProxyRequestParams() throws Exception {
		String id = "1";
		MockHttpServletRequestBuilder request = delete(DELETE_PROXY_REQUEST_DETAILS_PATH, id);

		mockMvc.perform(request).andExpect(status().isForbidden());
		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().is2xxSuccessful(), status().isForbidden());
	}

	@Test
	public void test_permissions_createCacheTable() throws Exception {
		MockHttpServletRequestBuilder request = post(CREATE_CACHE_TABLE_PATH);
		request.contentType(MediaType.APPLICATION_JSON_UTF8);
		request.content(ObjectMapperUtils.toJson(cacheTableCreationParams("l_log_unit_test", "")));

		mockMvc.perform(request).andExpect(status().isForbidden());
		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isBadRequest(), status().isForbidden());
	}

	@Test
	public void test_getAllProxyRequestDetails_finds_all() throws Exception {
		MockHttpServletRequestBuilder request = get(CONTROLLER_PATH);

		ResultActions ra = performRequestWithRole(request, SecurityRole.IAAA_PROXIES_ADMIN);
		ra.andExpect(status().isOk());

		List<ProxyRequestDetailsDto> result = mvcOm.getListFromResultActions(ra, ProxyRequestDetailsDto.class);
		assertEquals(PROXY_REQUEST_DETAILS_ENTRIES_IN_TEST_DB, result.size());
	}

	@Test
	public void test_saveOrUpdateProxyRequestParams_save() throws Exception {
		MockHttpServletRequestBuilder request = post(CONTROLLER_PATH);
		request.contentType(MediaType.APPLICATION_JSON_UTF8);
		request.content(ObjectMapperUtils.toJson(proxyRequestParams("/i/am/new", HttpMethod.GET)));

		ResultActions ra = performRequestWithRole(request, SecurityRole.IAAA_PROXIES_ADMIN);
		ra.andExpect(status().isOk());

		Integer result = mvcOm.getResponseObjectFromResultActions(ra, Integer.class);
		assertEquals(PROXY_REQUEST_DETAILS_ENTRIES_IN_TEST_DB + 1, result.intValue());
	}

	@Test
	public void test_saveOrUpdateProxyRequestParams_update() throws Exception {
		Integer proxyRequestDetailsId = 1;
		String updatedLocalPath = "/api/test/updated";

		ProxyRequestParams params = proxyRequestParams(updatedLocalPath, HttpMethod.GET);
		params.setId(proxyRequestDetailsId);

		MockHttpServletRequestBuilder request = post(CONTROLLER_PATH);
		request.contentType(MediaType.APPLICATION_JSON_UTF8);
		request.content(ObjectMapperUtils.toJson(params));

		ResultActions ra = performRequestWithRole(request, SecurityRole.IAAA_PROXIES_ADMIN);
		ra.andExpect(status().isOk());

		Integer result = mvcOm.getResponseObjectFromResultActions(ra, Integer.class);
		assertEquals(proxyRequestDetailsId, result);

		List<ProxyRequestDetailsDto> requestDetailsDtos = iaaaGatewayProxyRequestsService.getAllProxyRequestDetails();
		assertEquals(PROXY_REQUEST_DETAILS_ENTRIES_IN_TEST_DB, requestDetailsDtos.size());

		ProxyRequestDetailsDto updatedRequestDetailsDto = requestDetailsDtos.stream()
					.filter(dto -> dto.getId().equals(proxyRequestDetailsId))
					.findAny()
					.get();
		assertEquals(updatedLocalPath, updatedRequestDetailsDto.getLocalPath());
	}

	@Test
	public void test_deleteProxyRequestParams() throws Exception {
		String id = "1";
		MockHttpServletRequestBuilder request = delete(DELETE_PROXY_REQUEST_DETAILS_PATH, id);

		ResultActions ra = performRequestWithRole(request, SecurityRole.IAAA_PROXIES_ADMIN);
		ra.andExpect(status().isOk());

		List<ProxyRequestDetailsDto> requestDetailsDtos = iaaaGatewayProxyRequestsService.getAllProxyRequestDetails();
		assertEquals(PROXY_REQUEST_DETAILS_ENTRIES_IN_TEST_DB - 1, requestDetailsDtos.size());
	}

	@Test
	public void test_createCacheTable_successful() throws Exception {
		MockHttpServletRequestBuilder request = post(CREATE_CACHE_TABLE_PATH);
		request.contentType(MediaType.APPLICATION_JSON_UTF8);
		request.content(ObjectMapperUtils.toJson(cacheTableCreationParams("l_log_unit_test_success", "unit testing")));

		ResultActions ra = performRequestWithRole(request, SecurityRole.IAAA_PROXIES_ADMIN);
		ra.andExpect(status().isOk());
	}

	@Test
	public void test_createCacheTable_unsuccessful() throws Exception {
		MockHttpServletRequestBuilder request = post(CREATE_CACHE_TABLE_PATH);
		request.contentType(MediaType.APPLICATION_JSON_UTF8);
		request.content(ObjectMapperUtils.toJson(cacheTableCreationParams("l_log_unit_test_not_success", "unit testing")));

		ResultActions ra = performRequestWithRole(request, SecurityRole.IAAA_PROXIES_ADMIN);
		ra.andExpect(status().isOk());
		ra = performRequestWithRole(request, SecurityRole.IAAA_PROXIES_ADMIN);
		ra.andExpect(status().isConflict());
	}

	private ProxyRequestParams proxyRequestParams(String localPath, HttpMethod httpMethod) {
		ProxyRequestParams params = new ProxyRequestParams();
		params.setCacheTableName("l_proxy_dqc_valid_card_check");
		params.setHttpMethod(httpMethod.toString());
		params.setIsEnabled(true);
		params.setLocalPath(localPath);
		params.setRemoteUrl("http://remote.server/test");
		params.setRestTemplateConfigId(1);
		return params;
	}

	private ProxyRequestDetails getProxyRequestDetailsWithTrustStore() throws IOException {
		return IaaaGatewayUtil.getSSLRequestDetails("/api/test", "http://remote.server/test",
				HttpMethod.GET, true, true);
	}

	private ProxyRequestDetails getProxyRequestDetailsWithoutTrustStore() throws IOException {
		return IaaaGatewayUtil.getSSLRequestDetails("/api/test/{id}", "http://remote.server/test",
				HttpMethod.GET, true, false);
	}

	private ProxyRequestDetails getProxyRequestDetailsWithoutSSL() throws IOException {
		return IaaaGatewayUtil.getSSLRequestDetails("/api/test/unit", "http://remote.server/test",
				HttpMethod.POST, false, false);
	}

	private CacheTableCreationParams cacheTableCreationParams(String tableName, String description) {
		CacheTableCreationParams params = new CacheTableCreationParams();
		params.setTableName(tableName);
		params.setDescription(description);
		return params;
	}
}
