package bg.demax.iaaa.admin.controller.iaaagateway;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import bg.demax.iaaa.admin.AbstractMvcTest;
import bg.demax.iaaa.admin.dto.RestTemplateConfigDto;
import bg.demax.iaaa.admin.security.SecurityGroups;
import bg.demax.iaaa.admin.utils.DbImportService;
import bg.demax.iaaa.admin.utils.IaaaGatewayUtil;

public class IaaaGatewayRestTemplateConfigControllerTest extends AbstractMvcTest {
	private static final String CONTROLLER_PATH = "/api/iaaa-gateway/rest-template-config/";

	@Autowired
	private DbImportService dbImportService;

	@Before
	public void init() {
		dbImportService.saveRestTemplateConfig(IaaaGatewayUtil.getRestTemplateConfig(true, true));
	}

	@Test
	public void testGetAllRestTemplateConfigs_permissions() {
		MockHttpServletRequestBuilder request = get(CONTROLLER_PATH);
		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().is2xxSuccessful(), status().isForbidden());
	}

	@Test
	public void testGetRestTemplateConfig_permissions() {
		MockHttpServletRequestBuilder request = get(CONTROLLER_PATH + 1);
		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().is2xxSuccessful(), status().isForbidden());
	}

	@Test
	public void testSaveOrUpdate_permissions() {
		MockHttpServletRequestBuilder request = post(CONTROLLER_PATH);
		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isBadRequest(), status().isForbidden());
	}

	@Test
	public void testDeleteRestTemplateConfig_permissions() {
		MockHttpServletRequestBuilder request = delete(CONTROLLER_PATH + 123123);
		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().is(409), status().isForbidden());
	}

	@Test
	public void test_downloadCertificate_permissions() {
		MockHttpServletRequestBuilder request = get(CONTROLLER_PATH + "certificate/" + 123123);
		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().is(409), status().isForbidden());
	}

	@Test
	public void testGetAllRestTemplateConfigs() throws Exception {
		MockHttpServletRequestBuilder request = get(CONTROLLER_PATH);
		ResultActions ra = performRequestWithRole(request, SecurityGroups.FULL_ACCESS.getRolesInGroup()[0]);
		List<RestTemplateConfigDto> rtConfigs = mvcOm.getListFromResultActions(ra, RestTemplateConfigDto.class);

		assertEquals(1, rtConfigs.size());
		assertEquals(IaaaGatewayUtil.DEFAULT_KEYSTORE_NAME, rtConfigs.get(0).getKeyStore().getName());
	}
}
