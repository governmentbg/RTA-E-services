package bg.demax.iaaa.admin.controller.iaaagateway;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.web.client.RestTemplate;

import bg.demax.iaaa.admin.AbstractMvcTest;
import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.dto.controlleradvice.ApplicationExceptionDto;
import bg.demax.iaaa.admin.exception.IaaaGatewayUpdateException;
import bg.demax.iaaa.admin.security.SecurityGroups;
import bg.demax.iaaa.admin.security.SecurityRole;

public class IaaaGatewayUpdateControllerTest extends AbstractMvcTest {

	private static final String CONTROLLER_PATH = "/api/iaaa-gateway/update";
	private static final String UPDATE_IAAA_GATEWAY_PROXY_REQUEST_DETAILS_PATH = CONTROLLER_PATH + "/proxy-request-details/{id}";

	@MockBean
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_ADMIN_REST_TEMPLATE_FOR_PROXY_APPS)
	private RestTemplate restTemplate;

	@Test
	public void test_permissions_updateIaaaGatewayProxyRequestDetails() throws Exception {
		Mockito.doNothing().when(restTemplate).put(Mockito.anyString(), Mockito.any());

		String id = "1";
		MockHttpServletRequestBuilder request = put(UPDATE_IAAA_GATEWAY_PROXY_REQUEST_DETAILS_PATH, id);

		mockMvc.perform(request).andExpect(status().isForbidden());
		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().is2xxSuccessful(), status().isForbidden());
	}

	@Test
	public void test_updateIaaaGatewayProxyRequestDetails_successfull() throws Exception {
		Mockito.doNothing().when(restTemplate).put(Mockito.anyString(), Mockito.any());

		String id = "1";
		MockHttpServletRequestBuilder request = put(UPDATE_IAAA_GATEWAY_PROXY_REQUEST_DETAILS_PATH, id);

		ResultActions ra = performRequestWithRole(request, SecurityRole.IAAA_PROXIES_ADMIN);
		ra.andExpect(status().isOk());
	}

	@Test
	public void test_updateIaaaGatewayProxyRequestDetails_throws_IaaaGatewayUpdateException() throws Exception {
		Mockito.doThrow(new RuntimeException("hohoho")).when(restTemplate).put(Mockito.anyString(), Mockito.any());

		String id = "1";
		MockHttpServletRequestBuilder request = put(UPDATE_IAAA_GATEWAY_PROXY_REQUEST_DETAILS_PATH, id);

		ResultActions ra = performRequestWithRole(request, SecurityRole.IAAA_PROXIES_ADMIN);
		ra.andExpect(status().isConflict());

		ApplicationExceptionDto result = mvcOm.getResponseObjectFromResultActions(ra, ApplicationExceptionDto.class);
		assertEquals(IaaaGatewayUpdateException.class.getSimpleName(), result.getError());
	}
}
