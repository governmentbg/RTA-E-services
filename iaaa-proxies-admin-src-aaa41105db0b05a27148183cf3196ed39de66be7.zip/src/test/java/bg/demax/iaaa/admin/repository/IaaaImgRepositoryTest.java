package bg.demax.iaaa.admin.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.time.LocalDateTime;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.iaaa.admin.AbstractRepositoryTest;
import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.db.repository.IaaaImgRepository;
import bg.demax.iaaa.admin.dto.VehicleParamsDto;
import bg.demax.iaaa.admin.testutils.IaaaImgTestScripts;

public class IaaaImgRepositoryTest extends AbstractRepositoryTest {

	@Autowired
	private IaaaImgRepository iaaaImgRepository;

	@Test
	@Transactional(transactionManager = BeanQualifierConstants.IAAA_IMG_REPL_TRANSACTION_MANAGER, readOnly = true)
	public void findOldestNotSentToIctProxyVehicleParamsDto_test_no_inspection_dates() {
		sqlScriptExecutor.execute(IaaaImgTestScripts.L_REG_DOC_NUMS_FULL_SCRIPT);
		VehicleParamsDto vehicleParamsDto = iaaaImgRepository.findOldestNotSentToIctProxyVehicleParamsDto(null, null);

		long oldestNotSentToIctProxyRegDocIdForExistingRvsVer = 2;
		assertEquals(oldestNotSentToIctProxyRegDocIdForExistingRvsVer, vehicleParamsDto.getRegDocId().longValue());

		String regDocNum = "123456789";
		assertEquals(regDocNum, vehicleParamsDto.getVehicleDocumentNumber());

		String ownerId = "1234567890";
		assertEquals(ownerId, vehicleParamsDto.getOwnerId());

		String regNum = "CA1234AC";
		assertEquals(regNum, vehicleParamsDto.getVehicleRegistrationNumber());
	}

	@Test
	@Transactional(transactionManager = BeanQualifierConstants.IAAA_IMG_REPL_TRANSACTION_MANAGER, readOnly = true)
	public void findOldestNotSentToIctProxyVehicleParams_test_with_fromInspectionDate() {
		sqlScriptExecutor.execute(IaaaImgTestScripts.L_REG_DOC_NUMS_FULL_SCRIPT);
		LocalDateTime fromInspectionDate = LocalDateTime.of(2019, 9, 15, 8, 0);
		VehicleParamsDto vehicleParamsDto = iaaaImgRepository.findOldestNotSentToIctProxyVehicleParamsDto(fromInspectionDate, null);

		long oldestNotSentToIctProxyRegDocIdForStartingInspectionDate = 4;
		assertEquals(oldestNotSentToIctProxyRegDocIdForStartingInspectionDate, vehicleParamsDto.getRegDocId().longValue());
	}

	@Test
	@Transactional(transactionManager = BeanQualifierConstants.IAAA_IMG_REPL_TRANSACTION_MANAGER, readOnly = true)
	public void findOldestNotSentToIctProxyVehicleParams_test_with_toInspectionDate() {
		sqlScriptExecutor.execute(IaaaImgTestScripts.L_REG_DOC_NUMS_FULL_SCRIPT);
		LocalDateTime toInspectionDate = LocalDateTime.of(2019, 9, 14, 12, 0);
		VehicleParamsDto vehicleParamsDto = iaaaImgRepository.findOldestNotSentToIctProxyVehicleParamsDto(toInspectionDate, null);

		long oldestNotSentToIctProxyRegDocIdForExistingRvsVer = 2;
		assertEquals(oldestNotSentToIctProxyRegDocIdForExistingRvsVer, vehicleParamsDto.getRegDocId().longValue());
	}

	@Test
	@Transactional(transactionManager = BeanQualifierConstants.IAAA_IMG_REPL_TRANSACTION_MANAGER, readOnly = true)
	public void findOldestNotSentToIctProxyVehicleParams_test_with_fromInspectionDate_and_toInspectionDate() {
		sqlScriptExecutor.execute(IaaaImgTestScripts.L_REG_DOC_NUMS_FULL_SCRIPT);
		LocalDateTime fromInspectionDate = LocalDateTime.of(2019, 9, 13, 8, 0);
		LocalDateTime toInspectionDate = LocalDateTime.of(2019, 9, 14, 12, 0);
		VehicleParamsDto vehicleParamsDto = iaaaImgRepository.findOldestNotSentToIctProxyVehicleParamsDto(fromInspectionDate,
																												toInspectionDate);

		long oldestNotSentToIctProxyRegDocIdForExistingRvsVer = 2;
		assertEquals(oldestNotSentToIctProxyRegDocIdForExistingRvsVer, vehicleParamsDto.getRegDocId().longValue());
	}

	@Test
	@Transactional(transactionManager = BeanQualifierConstants.IAAA_IMG_REPL_TRANSACTION_MANAGER, readOnly = true)
	public void findOldestNotSentToIctProxyVehicleParams_test_with_fromInspectionDate_and_toInspectionDate_no_result() {
		sqlScriptExecutor.execute(IaaaImgTestScripts.L_REG_DOC_NUMS_FULL_SCRIPT);
		LocalDateTime fromInspectionDate = LocalDateTime.of(2019, 9, 16, 8, 0);
		LocalDateTime toInspectionDate = LocalDateTime.of(2019, 9, 17, 12, 0);
		VehicleParamsDto vehicleParamsDto = iaaaImgRepository.findOldestNotSentToIctProxyVehicleParamsDto(fromInspectionDate,
																												toInspectionDate);

		assertNull(vehicleParamsDto);
	}

	@Test
	public void updateLastIctRequestDateForRegDocId_test_with_valid_regDocId() {
		sqlScriptExecutor.execute(IaaaImgTestScripts.L_REG_DOC_NUMS_FULL_SCRIPT);
		long regDocId = 1;
		int updatedRows = iaaaImgRepository.updateLastIctRequestDateForRegDocId(regDocId);

		int expectedRowsToBeUpdated = 1;
		assertEquals(expectedRowsToBeUpdated, updatedRows);
	}

	@Test
	public void updateLastIctRequestDateForRegDocId_test_with_invalid_regDocId() {
		sqlScriptExecutor.execute(IaaaImgTestScripts.L_REG_DOC_NUMS_FULL_SCRIPT);
		long regDocId = 8;
		int updatedRows = iaaaImgRepository.updateLastIctRequestDateForRegDocId(regDocId);

		int expectedRowsToBeUpdated = 0;
		assertEquals(expectedRowsToBeUpdated, updatedRows);
	}
}
