package bg.demax.iaaa.admin.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import bg.demax.iaaa.admin.AbstractRepositoryTest;
import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.db.repository.VehicleInfoRepository;
import bg.demax.iaaa.admin.testutils.IaaaProxiesDbTestScripts;
import bg.demax.iaaa.admin.utils.MapAndList;
import bg.demax.iaaa.admin.utils.pgjson.JsonQuerySupport;
import bg.demax.iaaa.admin.utils.pgjson.search.VehicleInfoSearch;
import bg.demax.ictclient.db.requests.EAAAVehicleDataResponse;
import bg.demax.ictclient.db.workflows.BaseWorkflow;
import bg.demax.ictclient.db.workflows.VehicleInfoWorkflow;

public class VehicleInfoRepositoryTest extends AbstractRepositoryTest {

	@Autowired
	private VehicleInfoRepository vehicleInfoRepository;

	@Test
	public void testGetFiltered() {
		sqlScriptExecutor.execute(IaaaProxiesDbTestScripts.LOGS_VEHICLE_INFO, BeanQualifierConstants.IAAA_PROXIES_DB_DATASOURCE);

		LocalDateTime dt = LocalDateTime.of(LocalDate.of(2019, Month.JULY, 4), LocalTime.MIDNIGHT);
		VehicleInfoSearch vehicleInfoSearch = new VehicleInfoSearch();
		vehicleInfoSearch.setRequestTimeTo(dt);
		vehicleInfoSearch.setRequestTimeFrom(dt.minusYears(2));
		vehicleInfoSearch.setVehOwnerId("6903087559");
		vehicleInfoSearch.setVehDocumentNumber("006825372");
		vehicleInfoSearch.setVehRegistrationNumber("СА5940АС");

		MapAndList mapAndList = JsonQuerySupport.getMapAndList(vehicleInfoSearch);
		List<BaseWorkflow> resultList = vehicleInfoRepository.getWorkflows(mapAndList);
		List<EAAAVehicleDataResponse> filteredResponses = new ArrayList<EAAAVehicleDataResponse>();
		if (resultList != null) {
			filteredResponses = resultList.stream().map(r -> ((VehicleInfoWorkflow) r).getResponse())
					.collect(Collectors.toList());
		}

		assertTrue(filteredResponses != null);
		assertEquals(2, filteredResponses.size());
	}
}
