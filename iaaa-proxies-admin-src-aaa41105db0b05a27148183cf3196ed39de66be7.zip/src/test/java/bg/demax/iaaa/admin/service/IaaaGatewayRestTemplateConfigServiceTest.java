package bg.demax.iaaa.admin.service;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.iaaa.admin.AbstractRepositoryTest;
import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.RestTemplateConfig;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.SSLCertificateData;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.SSLCertificateDetails;
import bg.demax.iaaa.admin.db.repository.GenericRepository;
import bg.demax.iaaa.admin.dto.RestTemplateConfigDto;
import bg.demax.iaaa.admin.exception.NoSuchEntityException;
import bg.demax.iaaa.admin.service.iaaagateway.IaaaGatewayRestTemplateConfigService;
import bg.demax.iaaa.admin.utils.DbImportService;
import bg.demax.iaaa.admin.utils.IaaaGatewayUtil;

public class IaaaGatewayRestTemplateConfigServiceTest extends AbstractRepositoryTest {
	@Autowired
	private IaaaGatewayRestTemplateConfigService rtService;

	@Autowired
	private DbImportService dbImportService;

	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_GENERIC_REPOSITORY)
	private GenericRepository genericProxiesRepository;

	@Before
	public void init() {
		dbImportService.saveRestTemplateConfig(IaaaGatewayUtil.getRestTemplateConfig(true, true));
	}

	@Test
	public void testGetAllRestTemplateConfigs() {
		List<RestTemplateConfigDto> dtos = rtService.getAllRestTemplateConfigs();
		assertEquals(1, dtos.size());

		assertEquals(dtos.get(0).getDescription(), IaaaGatewayUtil.DEFAULT_RT_DESCRIPTION);
	}

	@Test
	public void testGetRestTemplateConfig() {
		RestTemplateConfigDto dto = rtService.getRestTemplateConfig(1);

		assertEquals(dto.getKeyStore().getName(), IaaaGatewayUtil.DEFAULT_KEYSTORE_NAME);
	}

	@Test
	public void testGetRestTemplateConfig__whenNoSuchExists() {
		exceptionRule.expect(NoSuchEntityException.class);
		exceptionRule.expectMessage(Matchers.containsString(RestTemplateConfig.class.getSimpleName()));
		rtService.getRestTemplateConfig(2);
	}

	@Test
	@Transactional(BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER)
	public void testDeleteRestTemplateConfig() {
		int originalRtConfigCount = genericProxiesRepository.countAllInt(RestTemplateConfig.class);
		int originalSslCertsCount = genericProxiesRepository.countAllInt(SSLCertificateDetails.class);
		int originalSslCertDataCount = genericProxiesRepository.countAllInt(SSLCertificateData.class);

		rtService.deleteRestTemplateConfig(1);

		assertEquals(originalRtConfigCount - 1, genericProxiesRepository.countAllInt(RestTemplateConfig.class));
		assertEquals(originalSslCertsCount - 2, genericProxiesRepository.countAllInt(SSLCertificateDetails.class));
		assertEquals(originalSslCertDataCount - 2, genericProxiesRepository.countAllInt(SSLCertificateData.class));
	}

}
