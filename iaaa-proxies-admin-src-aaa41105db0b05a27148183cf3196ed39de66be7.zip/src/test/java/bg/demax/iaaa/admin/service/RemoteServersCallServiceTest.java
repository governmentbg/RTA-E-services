package bg.demax.iaaa.admin.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.header;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.Level;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.support.RestGatewaySupport;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import bg.demax.iaaa.admin.controller.params.CallRemoteServerParams;
import bg.demax.iaaa.admin.controller.params.HeaderEntry;
import bg.demax.iaaa.admin.db.repository.IaaaProxiesRepository;
import bg.demax.iaaa.admin.enums.RemoteApp;
import bg.demax.iaaa.admin.exception.RemoteServerException;
import bg.demax.iaaa.admin.testutils.ObjectMapperUtils;
import bg.demax.iaaa.admin.utils.notifiers.NotificationService;

@RunWith(MockitoJUnitRunner.class)
public class RemoteServersCallServiceTest {

	public static final String MOCK_SERVER_ADDRESS = "http://localhost:19088";
	public static final String MOCK_SERVER_ENDPOINT = "/api/controller/path";
	public static final String MOCK_SERVER_RESPONSE = "Some response here";
	public static final String REMOTE_HEADER_NAME = "HEADER_NAME";
	public static final String REMOTE_HEADER_VALUE = "HEADER_VALUE";

	@InjectMocks
	private RemoteServersCallService remoteServersCallService;

	@Mock
	private NotificationService notificationService;

	@Mock
	private IaaaProxiesRepository iaaaProxiesRepository;

	private MockRestServiceServer mockServer;

	@Before
	public void setUp() {
		RestGatewaySupport gateway = new RestGatewaySupport();
		RestTemplate restTemplate = new RestTemplate();
		gateway.setRestTemplate(restTemplate);
		mockServer = MockRestServiceServer.createServer(gateway);

		ReflectionTestUtils.setField(remoteServersCallService, "iaaaGatewayBaseAddress", MOCK_SERVER_ADDRESS);
		ReflectionTestUtils.setField(remoteServersCallService, "iaaaProxiesAdminRtForProxyApps", restTemplate);
		ReflectionTestUtils.setField(remoteServersCallService, "objectMapper", ObjectMapperUtils.getNewConfiguredObjectMapper());
	}

	@Test
	public void testCallRemoteServer_OK() throws Exception {

		CallRemoteServerParams params = new CallRemoteServerParams();
		params.setEndpoint(MOCK_SERVER_ENDPOINT);

		params.setMethod("GET");
		params.setRemoteApp(RemoteApp.IAAA_GATEWAY.value());
		TestRequestBody body = new TestRequestBody("Property one", "Property two");
		params.setRequestBody(ObjectMapperUtils.toJson(body));
		params.setRequestBodyType(MediaType.APPLICATION_JSON_VALUE);
		params.setHeaderEntries(Arrays.asList(new HeaderEntry(REMOTE_HEADER_NAME, REMOTE_HEADER_VALUE)));
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(MOCK_SERVER_ADDRESS + MOCK_SERVER_ENDPOINT)
				.build();

		URI uri = uriComponents.toUri();

		mockServer.expect(requestTo(uri))
				.andExpect(method(HttpMethod.valueOf(params.getMethod())))
				.andExpect(method(HttpMethod.valueOf(params.getMethod())))
				.andExpect(header(REMOTE_HEADER_NAME, REMOTE_HEADER_VALUE))
				.andRespond(withSuccess(MOCK_SERVER_RESPONSE, MediaType.APPLICATION_JSON));

		ResponseEntity<String> result = remoteServersCallService.callRemoteServer(params);

		mockServer.verify();
		assertNotNull(result);
		assertEquals(MOCK_SERVER_RESPONSE, result.getBody());
	}

	@Test(expected = RemoteServerException.class)
	public void testCallRemoteServer_throwsException() throws Exception {

		CallRemoteServerParams params = new CallRemoteServerParams();
		params.setEndpoint(MOCK_SERVER_ENDPOINT);
		params.setMethod("GET");
		params.setRemoteApp(RemoteApp.IAAA_GATEWAY.value());

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(MOCK_SERVER_ADDRESS + MOCK_SERVER_ENDPOINT).build();

		URI uri = uriComponents.toUri();

		mockServer.expect(requestTo(uri)).andRespond(withStatus(HttpStatus.FAILED_DEPENDENCY));

		remoteServersCallService.callRemoteServer(params);
	}

	@Test
	public void testExecutePreparedRequests_throwsException_SendNotification() {
		CallRemoteServerParams param = new CallRemoteServerParams();
		param.setEndpoint(MOCK_SERVER_ENDPOINT);
		param.setMethod("GET");
		param.setRemoteApp(RemoteApp.IAAA_GATEWAY.value());
		List<CallRemoteServerParams> params = new ArrayList<CallRemoteServerParams>();
		params.add(param);

		Mockito.when(iaaaProxiesRepository.findAll()).thenReturn(params);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(MOCK_SERVER_ADDRESS + MOCK_SERVER_ENDPOINT)
				.build();

		URI uri = uriComponents.toUri();

		mockServer.expect(requestTo(uri)).andRespond(withStatus(HttpStatus.FAILED_DEPENDENCY));

		remoteServersCallService.executePreparedRequests();

		@SuppressWarnings("unchecked")
		ArgumentCaptor<List<String>> errorMsgCaptor = ArgumentCaptor.forClass(List.class);

		Mockito.verify(notificationService, Mockito.times(1)).notify(errorMsgCaptor.capture(), Mockito.eq(Level.DEBUG));

		assertTrue(errorMsgCaptor.getValue().get(0).contains("424 Failed Dependency"));
	}

	@SuppressWarnings("unused")
	private class TestRequestBody {
		private String prop1;
		private String prop2;

		public TestRequestBody(String prop1, String prop2) {
			this.prop1 = prop1;
			this.prop2 = prop2;
		}

		public String getProp1() {
			return prop1;
		}

		public void setProp1(String prop1) {
			this.prop1 = prop1;
		}

		public String getProp2() {
			return prop2;
		}

		public void setProp2(String prop2) {
			this.prop2 = prop2;
		}
	}
}
