package bg.demax.iaaa.admin.testutils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.function.Consumer;

import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.testcontainers.containers.PostgreSQLContainer;

import com.github.dockerjava.api.command.CreateContainerCmd;

@SuppressWarnings("rawtypes")
public class DockerContainerSingletons {
	private static PostgreSQLContainer iaaaImgPgContainer = null;
	private static PostgreSQLContainer iaaaProxiesCacheDbPgContainer = null;

	public static synchronized PostgreSQLContainer getIaaaImgPgContainer() throws SQLException {

		if (iaaaImgPgContainer == null) {
			String iaaaImgReplicationVersion = "postgres:11.5";
			iaaaImgPgContainer = new PostgreSQLContainer<>(iaaaImgReplicationVersion);
			setContainerName(iaaaImgPgContainer, "iaaaImgPgContainer");
			iaaaImgPgContainer.start();

			Connection connection = DriverManager.getConnection(iaaaImgPgContainer.getJdbcUrl(),
																iaaaImgPgContainer.getUsername(),
																iaaaImgPgContainer.getPassword());
			ScriptUtils.executeSqlScript(connection, new ClassPathResource(IaaaImgTestScripts.INIT_SCRIPT));
			connection.close();
		}

		return iaaaImgPgContainer;
	}

	public static synchronized PostgreSQLContainer getIaaaProxiesCacheDbContainer() throws SQLException {
		if (iaaaProxiesCacheDbPgContainer == null) {
			String iaaaProxiesCacheDbVersion = "postgres:10.7";
			iaaaProxiesCacheDbPgContainer = new PostgreSQLContainer<>(iaaaProxiesCacheDbVersion);
			setContainerName(iaaaProxiesCacheDbPgContainer, "iaaaProxiesPgContainer");

			iaaaProxiesCacheDbPgContainer.withUsername("admin");
			iaaaProxiesCacheDbPgContainer.start();

			Connection connection = DriverManager.getConnection(iaaaProxiesCacheDbPgContainer.getJdbcUrl(),
																iaaaProxiesCacheDbPgContainer.getUsername(),
																iaaaProxiesCacheDbPgContainer.getPassword());
			ScriptUtils.executeSqlScript(connection, new ClassPathResource(IaaaProxiesDbTestScripts.INIT_SCRIPT));
			connection.close();
		}

		return iaaaProxiesCacheDbPgContainer;
	}

	@SuppressWarnings("unchecked")
	private static void setContainerName(PostgreSQLContainer pgContainer, String containerName) {
		pgContainer.withCreateContainerCmdModifier(new Consumer<CreateContainerCmd>() {
			@Override
			public void accept(CreateContainerCmd createContainerCmd) {
				createContainerCmd.withHostName(containerName);
				createContainerCmd.withName(containerName);
			}
		});
	}
}
