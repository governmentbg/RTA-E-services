package bg.demax.iaaa.admin.testutils;

import java.util.Arrays;
import java.util.List;

public interface IaaaImgTestScripts {
	String INIT_SCRIPT = "/sql/iaaa_img/init.sql";
	String INSERT_USERS_SCRIPT = "/sql/iaaa_img/insert_users.sql";
	String INSERT_AUTHORITIES_SCRIPT = "/sql/iaaa_img/insert_authorities.sql";
	String INSERT_USERS_AUTHORITIES_SCRIPT = "/sql/iaaa_img/insert_users_authorities.sql";
	String INSERT_INSPECTIONS_SCRIPT = "/sql/iaaa_img/insert_inspections.sql";
	String INSERT_L_REG_DOC_NUMS_SCRIPT = "/sql/iaaa_img/insert_l_reg_doc_nums.sql";
	String INSERT_RVS_VERSIONS_SCRIPT = "/sql/iaaa_img/insert_rvs_versions.sql";
	String INSERT_SUBJECTS_SCRIPT = "/sql/iaaa_img/insert_subjects.sql";

	List<String> L_REG_DOC_NUMS_FULL_SCRIPT = Arrays.asList(
			IaaaImgTestScripts.INSERT_SUBJECTS_SCRIPT, IaaaImgTestScripts.INSERT_RVS_VERSIONS_SCRIPT,
			IaaaImgTestScripts.INSERT_INSPECTIONS_SCRIPT, IaaaImgTestScripts.INSERT_L_REG_DOC_NUMS_SCRIPT);
}
