package bg.demax.iaaa.admin.testutils;

public interface IaaaProxiesDbTestScripts {
	String INIT_SCRIPT = "/sql/iaaa_proxies/init.sql";

	String LOGS_VEHICLE_INFO = "/sql/iaaa_proxies/ict_proxy/logs_vehicle_info.sql";

	String INSERT_REGIX_PROXY_REQUEST_INFO = "/sql/iaaa_proxies/iaaa_proxies_admin/insert_regix_proxy_requests_info.sql";

	String INSERT_IAAA_GATEWAY_REQUEST_INFO = "/sql/iaaa_proxies/iaaa_proxies_admin/insert_iaaa_gateway_requests_info.sql";

	String IAAA_PROXIES_ADMIN_PREPARED_REQUESTS = "sql/iaaa_proxies/iaaa_proxies_admin/prepared_requests.sql";
}
