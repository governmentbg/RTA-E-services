package bg.demax.iaaa.admin.testutils;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

public class ObjectMapperUtils {
	private static ObjectMapper om = getNewConfiguredObjectMapper();

	public static MultiValueMap<String, String> toParams(Object... objects)
			throws IllegalArgumentException, IllegalAccessException {
		MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<>();

		for (Object object : objects) {
			for (Field field : object.getClass().getDeclaredFields()) {
				if (!Modifier.isStatic(field.getModifiers())) {
					field.setAccessible(true);
					Object value = field.get(object);
					if (value != null) {
						paramMap.set(field.getName(), String.valueOf(value));
					}
				}
			}
		}
		return paramMap;
	}

	public static String toJson(Object from) throws JsonProcessingException {
		return om.writeValueAsString(from);
	}

	public static <T> T fromJson(String json, Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {
		return om.readValue(json, clazz);
	}

	public static ObjectMapper getNewConfiguredObjectMapper() {
		ObjectMapper newOm = new ObjectMapper();
		newOm.disable(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
		newOm.disable(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS);
		newOm.registerModule(new JavaTimeModule());
		return newOm;
	}
}
