package bg.demax.iaaa.admin.testutils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PostgreDbCleaner {

	public static synchronized void trunkateAllAndResetSequences(Connection connection)
			throws SQLException {

		List<String> userSchemas = getSingleColumnResult("SELECT schema_name FROM information_schema.schemata"
				+ " WHERE schema_name NOT like 'pg_%' AND schema_name != 'information_schema'", connection);

		for (String schemaName : userSchemas) {
			resetSchema(schemaName, connection);
		}

		connection.close();
	}

	private static void resetSchema(String schemaName, Connection connection) throws SQLException {
		List<String> tableNames = getTables(schemaName, connection);
		List<String> sequences = getSequences(schemaName, connection);

		trunkateTables(tableNames, schemaName, connection);
		resetSequences(sequences, schemaName, connection);
	}

	private static void trunkateTables(List<String> tableNames, String schemaName, Connection connection)
			throws SQLException {
		for (String tableName : tableNames) {
			Statement statement = connection.createStatement();
			String query = String.format("TRUNCATE TABLE %s.%s CASCADE;", schemaName, tableName);
			statement.executeUpdate(query);
			statement.close();
		}
	}

	private static void resetSequences(List<String> sequences, String schemaName, Connection connection)
			throws SQLException {
		for (String sequence : sequences) {
			Statement statement = connection.createStatement();
			statement.executeUpdate(String.format("alter SEQUENCE %s.%s restart;", schemaName, sequence));
			statement.close();
		}
	}

	private static List<String> getSequences(String schemaName, Connection connection) throws SQLException {
		String query = String.format(
				"select sequence_name from information_schema.sequences WHERE sequence_schema = '%s'", schemaName);
		List<String> sequences = getSingleColumnResult(query, connection);

		return sequences;
	}

	private static List<String> getTables(String schemaName, Connection connection) throws SQLException {
		String query = String.format("select table_name from information_schema.tables where table_schema = '%s'",
				schemaName);
		List<String> tables = getSingleColumnResult(query, connection);

		return tables;
	}

	private static List<String> getSingleColumnResult(String query, Connection connection) throws SQLException {
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery(query);
		List<String> column1Values = getColumnNumberValues(resultSet, 1);
		statement.close();

		return column1Values;
	}

	private static List<String> getColumnNumberValues(ResultSet resultSet, int columnNumber) throws SQLException {
		ArrayList<String> columnValues = new ArrayList<String>();
		while (resultSet.next()) {
			columnValues.add(resultSet.getString(columnNumber));
		}

		return columnValues;
	}

}
