package bg.demax.iaaa.admin.testutils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.test.util.ReflectionTestUtils;

import bg.demax.iaaa.admin.security.SecurityRole;

public class SecurityTestUtil {
	private static List<String> allRoles = null;

	public static List<String> getAllRoles() {
		if (allRoles == null) {
			allRoles = new ArrayList<>();

			Arrays.asList(SecurityRole.class.getFields()).forEach(field -> {
				Object fieldVal = ReflectionTestUtils.getField(SecurityRole.class, field.getName());

				if (fieldVal instanceof String) {
					allRoles.add((String) fieldVal);
				}
			});
		}

		return allRoles;
	}
}
