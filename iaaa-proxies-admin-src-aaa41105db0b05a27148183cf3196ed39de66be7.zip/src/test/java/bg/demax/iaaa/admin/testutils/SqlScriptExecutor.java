package bg.demax.iaaa.admin.testutils;

import java.sql.Connection;

import javax.sql.DataSource;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ScriptUtils;

public class SqlScriptExecutor implements ApplicationContextAware {
	@Autowired
	private ConfigurableApplicationContext applicationContext;

	public void execute(String script) {
		execute(script, null);
	}

	public void execute(String script, String dataSourceQualifier) {
		DataSource ds = null;
		if (dataSourceQualifier == null) {
			ds = applicationContext.getBean(DataSource.class);
		} else {
			ds = BeanFactoryAnnotationUtils.qualifiedBeanOfType(applicationContext.getBeanFactory(),
					DataSource.class, dataSourceQualifier);
		}

		try {
			Connection connection = ds.getConnection();
			ScriptUtils.executeSqlScript(connection, new ClassPathResource(script));
			connection.close();
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void execute(String[] scripts) {
		for (String script : scripts) {
			execute(script);
		}
	}

	public void execute(String[] scripts, String dataSourceQualifier) {
		for (String script : scripts) {
			execute(script, dataSourceQualifier);
		}
	}

	public void execute(Iterable<String> scripts) {
		for (String script : scripts) {
			execute(script);
		}
	}

	public void execute(Iterable<String> scripts, String dataSourceQualifier) {
		for (String script : scripts) {
			execute(script, dataSourceQualifier);
		}
	}

	@Override
	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		this.applicationContext = (ConfigurableApplicationContext) arg0;
	}

}
