package bg.demax.iaaa.admin.testutils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

public class ValidatorsUtil {

	private static final Validator VALIDATOR = Validation.buildDefaultValidatorFactory().getValidator();
	private static final String ERR_MSG_FORMAT = "Field: %s, FieldValue: %s, ErrorMsg: %s";

	public static List<String> getConstrainViolationMessages(Object object) {
		List<String> fullValidationMessage = new ArrayList<String>();

		Set<ConstraintViolation<Object>> c = VALIDATOR.validate(object);

		if (c.size() > 0) {
			for (ConstraintViolation<Object> constraintViolation : c) {
				String fieldErrorMsg = String.format(ERR_MSG_FORMAT,
						constraintViolation.getPropertyPath(),
						constraintViolation.getInvalidValue(),
						constraintViolation.getMessage());

				fullValidationMessage.add(fieldErrorMsg);
			}
		}

		return fullValidationMessage;
	}
}
