package bg.demax.iaaa.admin.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.iaaa.admin.config.BeanQualifierConstants;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.ProxyRequestDetails;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.RestTemplateConfig;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.SSLCertificateDetails;
import bg.demax.iaaa.admin.db.repository.GenericRepository;

@Service
public class DbImportService {

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_PROXIES_GENERIC_REPOSITORY)
	private GenericRepository genericRepository;

	@Transactional(value = BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER)
	public void saveToDb(Object obj) {
		if (obj != null) {
			genericRepository.saveOrUpdate(obj);
		}
	}

	@Transactional(value = BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER)
	public int saveProxyRequestDetails(ProxyRequestDetails proxyRequestDetails) {
		RestTemplateConfig rtConfig = proxyRequestDetails.getRestTemplateConfig();
		saveRestTemplateConfig(rtConfig);
		saveToDb(proxyRequestDetails);

		return proxyRequestDetails.getId();
	}

	@Transactional(value = BeanQualifierConstants.IAAA_PROXIES_TRANSACTION_MANAGER)
	public void saveRestTemplateConfig(RestTemplateConfig restTemplateConfig) {
		SSLCertificateDetails keyStoreDetails = restTemplateConfig.getKeyStore();
		SSLCertificateDetails trustStoreDetails = restTemplateConfig.getTrustStore();

		if (keyStoreDetails != null) {
			saveToDb(keyStoreDetails.getCertData());
		}

		if (trustStoreDetails != null) {
			saveToDb(trustStoreDetails.getCertData());
		}

		saveToDb(keyStoreDetails);
		saveToDb(trustStoreDetails);
		saveToDb(restTemplateConfig);
	}

}