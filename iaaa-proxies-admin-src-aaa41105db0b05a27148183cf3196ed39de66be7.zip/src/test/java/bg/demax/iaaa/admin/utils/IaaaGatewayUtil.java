package bg.demax.iaaa.admin.utils;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.compress.utils.IOUtils;
import org.springframework.http.HttpMethod;

import bg.demax.iaaa.admin.db.entity.iaaaproxies.ProxyRequestDetails;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.RestTemplateConfig;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.SSLCertificateData;
import bg.demax.iaaa.admin.db.entity.iaaaproxies.SSLCertificateDetails;
import bg.demax.iaaa.admin.enums.SSLCertificateType;

public class IaaaGatewayUtil {
	public static String DEFAULT_RT_DESCRIPTION = "config for testing";
	public static String DEFAULT_KEYSTORE_NAME = "dqc_keystore.jks";

	public static ProxyRequestDetails getSSLRequestDetails(
			String localPath, String remoteUrl, HttpMethod method, boolean hasKeyStore, boolean hasTrustStore)
					throws IOException {

		ProxyRequestDetails proxyRequestDetails = new ProxyRequestDetails();

		proxyRequestDetails.setLocalPath(localPath);
		proxyRequestDetails.setRemoteUrl(remoteUrl);
		proxyRequestDetails.setHttpMethod(method.toString());
		proxyRequestDetails.setIsEnabled(true);
		proxyRequestDetails.setCacheTableName("l_proxy_dqc_valid_card_check");

		RestTemplateConfig restTemplateConfig = getRestTemplateConfig(hasKeyStore, hasTrustStore);

		proxyRequestDetails.setRestTemplateConfig(restTemplateConfig);

		return proxyRequestDetails;
	}

	public static RestTemplateConfig getRestTemplateConfig(boolean hasKeyStore, boolean hasTrustStore) {
		RestTemplateConfig restTemplateConfig = new RestTemplateConfig();
		restTemplateConfig.setDescription(DEFAULT_RT_DESCRIPTION);

		if (hasKeyStore) {
			SSLCertificateDetails keyStore = createSslCertificateDetails(
					DEFAULT_KEYSTORE_NAME, "jks/dqc-rest-user-test.jks", "12345678", SSLCertificateType.JKS);

			restTemplateConfig.setKeyStore(keyStore);
		}

		if (hasTrustStore) {
			SSLCertificateDetails trustStore = createSslCertificateDetails(
					"truststore", "jks/gd_truststore.jks", "changeit", SSLCertificateType.JKS);
			restTemplateConfig.setTrustStore(trustStore);
		}

		return restTemplateConfig;
	}

	private static SSLCertificateDetails createSslCertificateDetails(
			String name,
			String certPath,
			String password,
			SSLCertificateType type) {

		try {
			SSLCertificateDetails certDetails = new SSLCertificateDetails();

			certDetails.setName(name);
			SSLCertificateData sslCertificateData = new SSLCertificateData();
			InputStream keyStoreStream = IaaaGatewayUtil.class.getClassLoader().getResourceAsStream(certPath);
			byte[] cert = IOUtils.toByteArray(keyStoreStream);
			sslCertificateData.setData(cert);
			certDetails.setCertData(sslCertificateData);
			certDetails.setType(type.value());
			certDetails.setPassword(password);

			return certDetails;
		} catch (IOException ex) {
			throw new RuntimeException(ex);
		}

	}
}
