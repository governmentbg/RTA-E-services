INSERT INTO security.authorities(authority_id, authority_name, description)
VALUES (1, 'mock_authority', 'some mock authoriry');