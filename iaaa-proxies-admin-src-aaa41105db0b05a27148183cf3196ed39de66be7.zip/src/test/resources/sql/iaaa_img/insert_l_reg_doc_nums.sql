INSERT INTO public.l_reg_doc_nums (id, inspection_id, reg_doc_num, last_ict_request)
VALUES
(1, 1, 'Х123456', null),
(2, 2, '123456789', null),
(3, 3, '987654321', '2019-09-27 10:00:00'),
(4, 4, '213456897', null),
(5, 5, '876213450', null),
(6, 6, '123450984', null),
(7, 7, '764323498', null);