INSERT INTO rvs_versions(id, a_reg_num, c2_subj_owner)
VALUES
(1, 'CA1234AC', 1),
(2, 'PB1234BA', 2),
(3, 'KM4444MA', 3),
(4, 'MH34521HM', 4),
(5, 'AX2223XA', 5),
(6, 'OP6677PO', 6);