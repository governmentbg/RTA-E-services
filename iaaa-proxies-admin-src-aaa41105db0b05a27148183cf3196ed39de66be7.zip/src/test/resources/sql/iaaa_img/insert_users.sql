INSERT INTO security.users (user_id, username, password, enabled)
VALUES (1, 'mock_poli', 'password', true);

