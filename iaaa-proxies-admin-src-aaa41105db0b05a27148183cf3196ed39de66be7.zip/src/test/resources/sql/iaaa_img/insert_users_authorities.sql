INSERT INTO security.users_authorities(user_id, authority_id)
VALUES (1,1);