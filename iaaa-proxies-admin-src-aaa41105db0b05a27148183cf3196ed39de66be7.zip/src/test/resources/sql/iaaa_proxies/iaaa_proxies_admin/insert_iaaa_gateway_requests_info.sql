INSERT INTO iaaa_proxies_admin.iaaa_gateway_requests_info(
	name, path, http_method)
	VALUES 
	('Справка за тест за гейтуей', '/api/example', 'GET');
