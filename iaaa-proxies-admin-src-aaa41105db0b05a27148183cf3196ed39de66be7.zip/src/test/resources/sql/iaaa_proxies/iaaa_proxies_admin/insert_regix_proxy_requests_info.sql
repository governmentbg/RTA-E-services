INSERT INTO iaaa_proxies_admin.regix_proxy_requests_info(
	name, path, http_method)
	VALUES 
	('Справка за лице по документ за самоличност V1', '/mvr/personal', 'POST'),
	('Справка за физическо лице – чужденец V1', '/mvr/foreigner', 'POST'),
	('Справка за лице по документ за самоличност V2', '/mvr/personal/v2', 'POST'),
	('Разширена справка за МПС по регистрационен номер V2', '/mvr/motor-vehicle/v2', 'POST'),
	('Справка за актуално състояние на всички / действащите трудови договори', '/nra/employment-contracts', 'POST'),
	('Справка за валидност на ЕИК номер', '/av/tr/uic-info', 'POST'),
	('Справка за актуално състояние за всички вписани обстоятелства по раздели V3', '/av/tr/actual-state/v3', 'POST');