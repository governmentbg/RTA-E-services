INSERT INTO iaaa_proxies_admin.prepared_requests(workflow)
VALUES 

(cast('{
   "method":"GET",
   "endpoint":"/api/proxy/auto/roster-check/persons/5903173260",
   "remoteApp":"IAAA_GATEWAY",
   "requestBody":"{\"testprop\":\"test prop here\",\"test2\":\"test 2 here\"}",
   "headerEntries":[
      { "key": "x-cache-first-period", "value": "24" }
   ]
}' AS JSON)),

(cast('{
	"method": "POST",
	"endpoint": "/api/proxy/auto/some/app",
	"remoteApp": "IAAA_GATEWAY",
	"requestBody": "{\"testprop\": \"test prop here\",\"test2\": \"test 2 here\"}",
	"headerEntries": [
		{ "key": "x-cache-first-period", "value": "24"}
	]
}' AS JSON)),

(cast('{
	"method": "PUT",
	"endpoint": "/api/proxy/auto/some/app",
	"remoteApp": "IAAA_GATEWAY",
	"requestBody": "{\"testprop\": \"test prop here\",\"test2\": \"test 2 here\"}",
	"headerEntries": [
		{ "key": "x-cache-first-period", "value": "24"}
	]
}' AS JSON));