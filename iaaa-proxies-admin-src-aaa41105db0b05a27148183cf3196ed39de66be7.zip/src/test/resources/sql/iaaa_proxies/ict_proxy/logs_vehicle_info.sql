INSERT INTO ict_proxy.logs_vehicle_info (workflow)
VALUES ('{
    "@type": "VehicleInfo",
    "request": {
        "header": {
            "dateTime": [
                "javax.xml.datatype.XMLGregorianCalendar",
                1562158728766
            ],
            "systemID": "eaaa-kat",
            "messageID": "dae372b9-b4ef-49e6-b3b5-8271cadbbf6c",
            "operation": "0001",
            "messageRefID": null
        },
        "request": {
            "vehicleOwnerData": {
                "vehOwnerId": "6903087559"
            },
            "vehicleRequestData": {
                "vehDocument": {
                    "vehDocumentType": {
                        "text": null,
                        "value": 1
                    },
                    "vehDocumentNumber": "006825372"
                },
                "vehRegistrationNumber": "СА5940АС"
            }
        }
    },
    "response": {
        "header": {
            "dateTime": [
                "javax.xml.datatype.XMLGregorianCalendar",
                1562158728848
            ],
            "systemID": "eaaa",
            "messageID": "89b44f14-a737-4772-872d-0ed0e7ea9ce9",
            "operation": "001",
            "messageRefID": "dae372b9-b4ef-49e6-b3b5-8271cadbbf6c"
        },
        "response": {
            "results": null,
            "returnInformation": {
                "returnCode": 2,
                "serviceInformation": null
            }
        }
    },
    "requestTime": "2019-07-03T15:58:48.766",
    "responseTime": "2019-07-03T15:58:48.878",
    "errorWorkflow": null
}');


INSERT INTO ict_proxy.logs_vehicle_info (workflow)
VALUES ('{
    "@type": "VehicleInfo",
    "request": {
        "header": {
            "dateTime": [
                "javax.xml.datatype.XMLGregorianCalendar",
                1562158803980
            ],
            "systemID": "eaaa-kat",
            "messageID": "86e33c92-0490-47dc-908e-11e1f52253f9",
            "operation": "0001",
            "messageRefID": null
        },
        "request": {
            "vehicleOwnerData": {
                "vehOwnerId": "6903087559"
            },
            "vehicleRequestData": {
                "vehDocument": {
                    "vehDocumentType": {
                        "text": null,
                        "value": 1
                    },
                    "vehDocumentNumber": "006825372"
                },
                "vehRegistrationNumber": "СА5940АС"
            }
        }
    },
    "response": {
        "header": {
            "dateTime": [
                "javax.xml.datatype.XMLGregorianCalendar",
                1562158804016
            ],
            "systemID": "eaaa",
            "messageID": "af8b3475-9ba2-40e5-8113-98bf1ac1db4e",
            "operation": "001",
            "messageRefID": "86e33c92-0490-47dc-908e-11e1f52253f9"
        },
        "response": {
            "results": null,
            "returnInformation": {
                "returnCode": 2,
                "serviceInformation": null
            }
        }
    },
    "requestTime": "2019-07-03T16:00:03.98",
    "responseTime": "2019-07-03T16:00:04.056",
    "errorWorkflow": null
}');

INSERT INTO ict_proxy.logs_vehicle_info (workflow)
VALUES ('{
    "@type": "VehicleInfo",
    "request": {
        "header": {
            "dateTime": [
                "javax.xml.datatype.XMLGregorianCalendar",
                1562159912314
            ],
            "systemID": "eaaa-kat",
            "messageID": "7f275bb4-4fda-4ac4-a18e-77d11d94fb9e",
            "operation": "0001",
            "messageRefID": null
        },
        "request": {
            "vehicleOwnerData": {
                "vehOwnerId": "9506197627"
            },
            "vehicleRequestData": {
                "vehDocument": {
                    "vehDocumentType": {
                        "text": null,
                        "value": 1
                    },
                    "vehDocumentNumber": "008436651"
                },
                "vehRegistrationNumber": "А1315К"
            }
        }
    },
    "response": {
        "header": {
            "dateTime": [
                "javax.xml.datatype.XMLGregorianCalendar",
                1562159912705
            ],
            "systemID": "eaaa",
            "messageID": "87b3358e-83da-4575-af70-59fc58d817f1",
            "operation": "001",
            "messageRefID": "7f275bb4-4fda-4ac4-a18e-77d11d94fb9e"
        },
        "response": {
            "results": {
                "result": [
                    "java.util.ArrayList",
                    [
                        {
                            "vehicleResponseData": {
                                "vehMake": "МОСКВИЧ 412",
                                "vehMass": null,
                                "vehType": "ЛЕК АВТОМОБИЛ",
                                "vehMassG": null,
                                "vehColour": "СВЕТЛО ЗЕЛЕН",
                                "vehEngine": {
                                    "vehFuel": null,
                                    "vehCapacity": null,
                                    "vehMaxPower": null,
                                    "vehRatedSpeed": null,
                                    "vehEngineNumber": "2562727"
                                },
                                "vehBodyType": null,
                                "vehCategory": null,
                                "vehWheelBase": null,
                                "vehNumOfAxles": null,
                                "vehSoundLevel": null,
                                "vehTrailerMass": null,
                                "vehMaximumSpeed": null,
                                "vehCommercialName": null,
                                "vehSeatingCapacity": null,
                                "vehExhaustEmmitions": null,
                                "vehMassDistribution": null,
                                "vehPowerWeightRatio": null,
                                "vehTypeApprovalData": null,
                                "vehRegistrationNumber": "А1315К",
                                "vehIdentificationNumber": "422763",
                                "vehFirstRegistrationDate": null
                            },
                            "vehicleOwnerVerification": {
                                "text": "НЯМА СЪВПАДЕНИЕ",
                                "value": 2
                            },
                            "vehicleDocumentResponseData": null
                        },
                        {
                            "vehicleResponseData": {
                                "vehMake": "ЯМАХА Х МАКС 400",
                                "vehMass": {
                                    "vehMassF1": 396,
                                    "vehMassF2": 396,
                                    "vehMassF3": null
                                },
                                "vehType": "МОТОЦИКЛЕТ",
                                "vehMassG": 214,
                                "vehColour": "ЧЕРЕН",
                                "vehEngine": {
                                    "vehFuel": "БЕНЗИН",
                                    "vehCapacity": 395,
                                    "vehMaxPower": "24.5",
                                    "vehRatedSpeed": 7000,
                                    "vehEngineNumber": "H339E000769"
                                },
                                "vehBodyType": null,
                                "vehCategory": {
                                    "vehEUCategory": "L3EA2",
                                    "vehOffRoadSymbol": null
                                },
                                "vehWheelBase": 1565,
                                "vehNumOfAxles": 2,
                                "vehSoundLevel": {
                                    "vehSoundLevelU1": 85,
                                    "vehSoundLevelU2": 3500,
                                    "vehSoundLevelU3": 74
                                },
                                "vehTrailerMass": null,
                                "vehMaximumSpeed": 150,
                                "vehCommercialName": "ХМАХ400",
                                "vehSeatingCapacity": {
                                    "vehNumberOfSeats": "1+1",
                                    "vehNumberOfStanding": null
                                },
                                "vehExhaustEmmitions": {
                                    "vehAbsorbtionCoefficient": null,
                                    "vehEnvironmentalCategory": "ЕВРО 4",
                                    "vehCombinedFuelConsumption": 4.18
                                },
                                "vehMassDistribution": {
                                    "vehMassN1": 162,
                                    "vehMassN2": 234,
                                    "vehMassN3": null,
                                    "vehMassN4": null,
                                    "vehMassN5": null
                                },
                                "vehPowerWeightRatio": 0.11,
                                "vehTypeApprovalData": {
                                    "vehTypeApprovalType": "SH11",
                                    "vehTypeApprovalNumber": "e13*168/2013*00079*00",
                                    "vehTypeApprovalVariant": "A",
                                    "vehTypeApprovalVersion": "01"
                                },
                                "vehRegistrationNumber": "А1315К",
                                "vehIdentificationNumber": "VG5SH111000000747",
                                "vehFirstRegistrationDate": [
                                    "javax.xml.datatype.XMLGregorianCalendar",
                                    1496696400000
                                ]
                            },
                            "vehicleOwnerVerification": {
                                "text": "СЪВПАДЕНИЕ",
                                "value": 1
                            },
                            "vehicleDocumentResponseData": {
                                "vehDocumentDate": [
                                    "javax.xml.datatype.XMLGregorianCalendar",
                                    1496696400000
                                ],
                                "vehDocumentIDNumber": "008436651"
                            }
                        }
                    ]
                ]
            },
            "returnInformation": {
                "returnCode": 0,
                "serviceInformation": null
            }
        }
    },
    "requestTime": "2019-07-05T16:18:32.315",
    "responseTime": "2019-07-05T16:18:32.739",
    "errorWorkflow": null
}');

INSERT INTO ict_proxy.logs_vehicle_info (workflow)
VALUES ('{
    "@type": "VehicleInfo",
    "request": {
        "header": {
            "dateTime": [
                "javax.xml.datatype.XMLGregorianCalendar",
                1569330835423
            ],
            "systemID": "eaaa-kat",
            "messageID": "8ac8f883-580d-4847-95a8-f9944b249f6b",
            "operation": "0001",
            "messageRefID": null
        },
        "request": {
            "vehicleOwnerData": {
                "vehOwnerId": "1"
            },
            "vehicleRequestData": {
                "vehDocument": {
                    "vehDocumentType": {
                        "text": null,
                        "value": 1
                    },
                    "vehDocumentNumber": "1"
                },
                "vehRegistrationNumber": "a`"
            }
        }
    },
    "response": {
        "header": {
            "dateTime": [
                "javax.xml.datatype.XMLGregorianCalendar",
                1569330835414
            ],
            "systemID": "eaaa",
            "messageID": "d5926cf2-ee43-494b-8e7c-dd3fcb42dc94",
            "operation": "001",
            "messageRefID": null
        },
        "response": {
            "results": null,
            "returnInformation": {
                "returnCode": 1,
                "serviceInformation": null
            }
        }
    },
    "requestTime": "2019-09-24T16:13:55.424",
    "responseTime": "2019-09-24T16:13:55.436",
    "errorWorkflow": null
}');

INSERT INTO ict_proxy.logs_vehicle_info (workflow)
VALUES ('{
    "@type": "VehicleInfo",
    "request": {
        "header": {
            "dateTime": [
                "javax.xml.datatype.XMLGregorianCalendar",
                1573478591287
            ],
            "systemID": "eaaa-kat",
            "messageID": "93281b5b-2d98-451a-b866-4d61089dcef0",
            "operation": "0001",
            "messageRefID": null
        },
        "request": {
            "vehicleOwnerData": {
                "vehOwnerId": "8311272820"
            },
            "vehicleRequestData": {
                "vehDocument": {
                    "vehDocumentType": {
                        "text": null,
                        "value": 1
                    },
                    "vehDocumentNumber": "009498511"
                },
                "vehRegistrationNumber": "КН3753ВС"
            }
        }
    },
    "response": {
        "header": {
            "dateTime": [
                "javax.xml.datatype.XMLGregorianCalendar",
                1573478591386
            ],
            "systemID": "eaaa",
            "messageID": "3685de9e-27a3-47c7-af4f-269e5d8fef62",
            "operation": "001",
            "messageRefID": "93281b5b-2d98-451a-b866-4d61089dcef0"
        },
        "response": {
            "results": {
                "result": [
                    "java.util.ArrayList",
                    [
                        {
                            "vehicleResponseData": {
                                "vehMake": "ФОЛКСВАГЕН ТУАРЕГ",
                                "vehMass": {
                                    "vehMassF1": 2945,
                                    "vehMassF2": 1945,
                                    "vehMassF3": 6445
                                },
                                "vehType": "ЛЕК АВТОМОБИЛ",
                                "vehMassG": 2421,
                                "vehColour": "СИВ МЕТАЛИК",
                                "vehEngine": {
                                    "vehFuel": "ДИЗЕЛ",
                                    "vehCapacity": 2967,
                                    "vehMaxPower": "165",
                                    "vehRatedSpeed": 4000,
                                    "vehEngineNumber": "BKS011073"
                                },
                                "vehBodyType": {
                                    "vehBodyTypeNum": null,
                                    "vehBodyTypeCode": "AC"
                                },
                                "vehCategory": {
                                    "vehEUCategory": "M1",
                                    "vehOffRoadSymbol": null
                                },
                                "vehWheelBase": null,
                                "vehNumOfAxles": 2,
                                "vehSoundLevel": {
                                    "vehSoundLevelU1": 81,
                                    "vehSoundLevelU2": 3000,
                                    "vehSoundLevelU3": null
                                },
                                "vehTrailerMass": {
                                    "vehMassO1": 3500,
                                    "vehMassO2": null
                                },
                                "vehMaximumSpeed": null,
                                "vehCommercialName": null,
                                "vehSeatingCapacity": {
                                    "vehNumberOfSeats": "4+1",
                                    "vehNumberOfStanding": null
                                },
                                "vehExhaustEmmitions": {
                                    "vehAbsorbtionCoefficient": null,
                                    "vehEnvironmentalCategory": "ЕВРО 4",
                                    "vehCombinedFuelConsumption": null
                                },
                                "vehMassDistribution": {
                                    "vehMassN1": 1460,
                                    "vehMassN2": 1610,
                                    "vehMassN3": null,
                                    "vehMassN4": null,
                                    "vehMassN5": null
                                },
                                "vehPowerWeightRatio": null,
                                "vehTypeApprovalData": null,
                                "vehRegistrationNumber": "КН3753ВС",
                                "vehIdentificationNumber": "WVGZZZ7LZ6D011399",
                                "vehFirstRegistrationDate": [
                                    "javax.xml.datatype.XMLGregorianCalendar",
                                    1123448400000
                                ]
                            },
                            "vehicleOwnerVerification": {
                                "text": "НЯМА СЪВПАДЕНИЕ",
                                "value": 2
                            },
                            "vehicleDocumentResponseData": {
                                "vehDocumentDate": [
                                    "javax.xml.datatype.XMLGregorianCalendar",
                                    1541455200000
                                ],
                                "vehDocumentIDNumber": "009498511"
                            }
                        }
                    ]
                ]
            },
            "returnInformation": {
                "returnCode": 0,
                "serviceInformation": null
            }
        }
    },
    "completed": true,
    "requestTime": "2019-07-05T16:18:32.315",
    "responseTime": "2019-07-05T16:18:32.739",
    "errorWorkflow": null
}');