--
-- PostgreSQL database dump
--

-- Dumped from database version 10.7 (Debian 10.7-1.pgdg90+1)
-- Dumped by pg_dump version 10.7 (Debian 10.7-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ict_proxy; Type: SCHEMA; Schema: -; Owner: admin
--

CREATE SCHEMA ict_proxy;


ALTER SCHEMA ict_proxy OWNER TO admin;

--
-- Name: regix_proxy; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA regix_proxy;


ALTER SCHEMA regix_proxy OWNER TO admin;

--
-- Name: SCHEMA regix_proxy; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA regix_proxy IS 'standard public schema';


CREATE SCHEMA IF NOT EXISTS iaaa_proxies_admin;

ALTER SCHEMA iaaa_proxies_admin OWNER TO admin;

CREATE TABLE iaaa_proxies_admin.prepared_requests (
    id integer PRIMARY KEY generated always as identity,
 	workflow jsonb NOT NULL
);


ALTER TABLE iaaa_proxies_admin.prepared_requests OWNER to admin;
    
--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: availability_log; Type: TABLE; Schema: ict_proxy; Owner: admin
--

CREATE TABLE ict_proxy.availability_log (
    "time" timestamp without time zone NOT NULL,
    available boolean
);


ALTER TABLE ict_proxy.availability_log OWNER TO admin;

--
-- Name: clients; Type: TABLE; Schema: regix_proxy; Owner: regix-proxy
--

CREATE TABLE regix_proxy.clients (
    name character varying(32) NOT NULL,
    certificate text NOT NULL,
    id integer NOT NULL
);


ALTER TABLE regix_proxy.clients OWNER TO admin;

--
-- Name: clients_if_seq; Type: SEQUENCE; Schema: regix_proxy; Owner: regix-proxy
--

CREATE SEQUENCE regix_proxy.clients_if_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE regix_proxy.clients_if_seq OWNER TO admin;

--
-- Name: clients_if_seq; Type: SEQUENCE OWNED BY; Schema: regix_proxy; Owner: regix-proxy
--

ALTER SEQUENCE regix_proxy.clients_if_seq OWNED BY regix_proxy.clients.id;


--
-- Name: clients; Type: TABLE; Schema: ict_proxy; Owner: regix-proxy
--

CREATE TABLE ict_proxy.clients (
    name character varying(32) NOT NULL,
    certificate text NOT NULL,
    id integer DEFAULT nextval('regix_proxy.clients_if_seq'::regclass) NOT NULL
);


ALTER TABLE ict_proxy.clients OWNER TO admin;

--
-- Name: logs_vehicle_info; Type: TABLE; Schema: ict_proxy; Owner: admin
--

CREATE TABLE ict_proxy.logs_vehicle_info (
    workflow jsonb NOT NULL
);


ALTER TABLE ict_proxy.logs_vehicle_info OWNER TO admin;

--
-- Name: logs_foreign_identity; Type: TABLE; Schema: regix_proxy; Owner: regix-proxy
--

CREATE TABLE regix_proxy.logs_foreign_identity (
    workflow jsonb NOT NULL
);


ALTER TABLE regix_proxy.logs_foreign_identity OWNER TO admin;

--
-- Name: logs_personal_identity; Type: TABLE; Schema: regix_proxy; Owner: regix-proxy
--

CREATE TABLE regix_proxy.logs_personal_identity (
    workflow jsonb NOT NULL
);


ALTER TABLE regix_proxy.logs_personal_identity OWNER TO admin;

--
-- Name: clients id; Type: DEFAULT; Schema: regix_proxy; Owner: regix-proxy
--

ALTER TABLE ONLY regix_proxy.clients ALTER COLUMN id SET DEFAULT nextval('regix_proxy.clients_if_seq'
::regclass);


--
-- Name: availability_log availability_log_pkey; Type: CONSTRAINT; Schema: ict_proxy; Owner: admin
--

ALTER TABLE ONLY ict_proxy.availability_log
    ADD CONSTRAINT availability_log_pkey PRIMARY KEY ("time");


--
-- Name: clients clients_if_key; Type: CONSTRAINT; Schema: ict_proxy; Owner: regix-proxy
--

ALTER TABLE ONLY ict_proxy.clients
    ADD CONSTRAINT clients_if_key UNIQUE (id);


--
-- Name: clients clients_string_pkey; Type: CONSTRAINT; Schema: ict_proxy; Owner: regix-proxy
--

ALTER TABLE ONLY ict_proxy.clients
    ADD CONSTRAINT clients_string_pkey PRIMARY KEY (certificate);


--
-- Name: clients clients_if_key; Type: CONSTRAINT; Schema: regix_proxy; Owner: regix-proxy
--

ALTER TABLE ONLY regix_proxy.clients
    ADD CONSTRAINT clients_if_key UNIQUE (id);


--
-- Name: clients clients_string_pkey; Type: CONSTRAINT; Schema: regix_proxy; Owner: regix-proxy
--

ALTER TABLE ONLY regix_proxy.clients
    ADD CONSTRAINT clients_string_pkey PRIMARY KEY (certificate);


--
-- Name: logs_foreign_identity_expr_expr1_idx; Type: INDEX; Schema: regix_proxy; Owner: regix-proxy
--

CREATE INDEX logs_foreign_identity_expr_expr1_idx ON regix_proxy.logs_foreign_identity USING btree ((
((workflow -> 'request'::text) ->> 'identifier'::text)), (((workflow -> 'request'::text) ->> 'identif
ierType'::text)));


--
-- Name: logs_personal_identity_expr_expr1_idx; Type: INDEX; Schema: regix_proxy; Owner: regix-proxy
--

CREATE INDEX logs_personal_identity_expr_expr1_idx ON regix_proxy.logs_personal_identity USING btree 
((((workflow -> 'request'::text) ->> 'egn'::text)), (((workflow -> 'request'::text) ->> 'identityDocu
mentNumber'::text)));

--
-- PostgreSQL database dump complete


CREATE SCHEMA iaaa_gateway;

CREATE ROLE iaaa_gateway;
--
