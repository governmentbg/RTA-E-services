package bg.demax.ictclient.db.workflows;

import static com.fasterxml.jackson.annotation.JsonTypeInfo.As.PROPERTY;
import static com.fasterxml.jackson.annotation.JsonTypeInfo.Id.NAME;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(use = NAME, include = PROPERTY)

@JsonSubTypes({ @JsonSubTypes.Type(value = VehicleInfoWorkflow.class, name = "VehicleInfo") })

@JsonIgnoreProperties({ "id" })
public class BaseWorkflow {

    // private String id;
    private ErrorWorkflow errorWorkflow;
    private LocalDateTime requestTime;
    private LocalDateTime responseTime;

    public BaseWorkflow() {

    }

    /**
     * @return ErrorWorkflow return the errorWorkflow
     */
    public ErrorWorkflow getErrorWorkflow() {
        return errorWorkflow;
    }

    /**
     * @param errorWorkflow the errorWorkflow to set
     */
    public void setErrorWorkflow(ErrorWorkflow errorWorkflow) {
        this.errorWorkflow = errorWorkflow;
    }

    /**
     * @return LocalDateTime return the requestTime
     */
    public LocalDateTime getRequestTime() {
        return requestTime;
    }

    /**
     * @param requestTime the requestTime to set
     */
    public void setRequestTime(LocalDateTime requestTime) {
        this.requestTime = requestTime;
    }

    /**
     * @return LocalDateTime return the responseTime
     */
    public LocalDateTime getResponseTime() {
        return responseTime;
    }

    /**
     * @param responseTime the responseTime to set
     */
    public void setResponseTime(LocalDateTime responseTime) {
        this.responseTime = responseTime;
    }
}
