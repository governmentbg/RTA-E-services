package bg.demax.ictclient.db.workflows;

import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("error")
public class ErrorWorkflow {
    private String errorMessage;
    private Boolean isFault;

    public ErrorWorkflow(){

    }

    public ErrorWorkflow(String errorMessage, Boolean isFault){
        this.errorMessage = errorMessage;
        this.isFault = isFault;
    }


    /**
     * @return String return the errorMessage
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * @param errorMessage the errorMessage to set
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    /**
     * @return Boolean return the isFault
     */
    public Boolean isIsFault() {
        return isFault;
    }

    /**
     * @param isFault the isFault to set
     */
    public void setIsFault(Boolean isFault) {
        this.isFault = isFault;
    }

}