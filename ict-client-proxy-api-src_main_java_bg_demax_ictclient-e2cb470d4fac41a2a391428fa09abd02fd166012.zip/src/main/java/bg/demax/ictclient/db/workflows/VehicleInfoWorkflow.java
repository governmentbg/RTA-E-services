package bg.demax.ictclient.db.workflows;

import java.time.LocalDateTime;

import bg.demax.ictclient.db.requests.EAAAVehicleDataRequest;
import bg.demax.ictclient.db.requests.EAAAVehicleDataResponse;

public class VehicleInfoWorkflow extends BaseWorkflow {

    private EAAAVehicleDataRequest request;
    private EAAAVehicleDataResponse response;
    private LocalDateTime requestTime;
    private LocalDateTime responseTime;
    private Boolean completed;

    public VehicleInfoWorkflow() {

    }

    public VehicleInfoWorkflow(EAAAVehicleDataRequest request, EAAAVehicleDataResponse response,
            LocalDateTime requestTime, LocalDateTime responseTime, Boolean completed) {
        this.request = request;
        this.response = response;
        this.requestTime = requestTime;
        this.responseTime = responseTime;
        this.completed = completed;
    }

    /**
     * @return EAAAVehicleDataRequest return the request
     */
    public EAAAVehicleDataRequest getRequest() {
        return request;
    }

    /**
     * @param request the request to set
     */
    public void setRequest(EAAAVehicleDataRequest request) {
        this.request = request;
    }

    /**
     * @return EAAAVehicleDataResponse return the response
     */
    public EAAAVehicleDataResponse getResponse() {
        return response;
    }

    /**
     * @param response the response to set
     */
    public void setResponse(EAAAVehicleDataResponse response) {
        this.response = response;
    }

    /**
     * @return LocalDateTime return the requestTime
     */
    public LocalDateTime getRequestTime() {
        return requestTime;
    }

    /**
     * @param requestTime the requestTime to set
     */
    public void setRequestTime(LocalDateTime requestTime) {
        this.requestTime = requestTime;
    }

    /**
     * @return LocalDateTime return the responseTime
     */
    public LocalDateTime getResponseTime() {
        return responseTime;
    }

    /**
     * @param responseTime the responseTime to set
     */
    public void setResponseTime(LocalDateTime responseTime) {
        this.responseTime = responseTime;
    }

    /**
     * @return Boolean return the completed
     */
    public Boolean isCompleted() {
        return completed;
    }

    /**
     * @param completed the completed to set
     */
    public void setCompleted(Boolean completed) {
        this.completed = completed;
    }

}