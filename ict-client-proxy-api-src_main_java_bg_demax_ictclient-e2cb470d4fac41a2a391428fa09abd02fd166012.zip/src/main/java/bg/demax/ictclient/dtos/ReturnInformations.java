package bg.demax.ictclient.dtos;

import java.io.Serializable;

public class ReturnInformations implements Serializable {
	
	private static final long serialVersionUID = 678041990886103613L;
	
	private byte returnCode;

    /**
     * @return byte return the returnCode
     */
    public byte getReturnCode() {
        return returnCode;
    }

    /**
     * @param returnCode the returnCode to set
     */
    public void setReturnCode(byte returnCode) {
        this.returnCode = returnCode;
    }

}