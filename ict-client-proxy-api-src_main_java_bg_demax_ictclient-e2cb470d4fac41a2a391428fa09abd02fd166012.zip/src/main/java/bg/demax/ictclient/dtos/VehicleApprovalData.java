package bg.demax.ictclient.dtos;

import java.io.Serializable;

public class VehicleApprovalData implements Serializable {

    private static final long serialVersionUID = 678047698034103613L;

    private String approvalType;

    private String approvalNumber;
    private String approvalVariant;
    private String approvalVersion;

    /**
     * @return String return the approvalType
     */
    public String getApprovalType() {
        return approvalType;
    }

    /**
     * @param approvalType the approvalType to set
     */
    public void setApprovalType(String approvalType) {
        this.approvalType = approvalType;
    }

    /**
     * @return String return the approvalNumber
     */
    public String getApprovalNumber() {
        return approvalNumber;
    }

    /**
     * @param approvalNumber the approvalNumber to set
     */
    public void setApprovalNumber(String approvalNumber) {
        this.approvalNumber = approvalNumber;
    }


    /**
     * @return String return the approvalVariant
     */
    public String getApprovalVariant() {
        return approvalVariant;
    }

    /**
     * @param approvalVariant the approvalVariant to set
     */
    public void setApprovalVariant(String approvalVariant) {
        this.approvalVariant = approvalVariant;
    }

    /**
     * @return String return the approvalVersion
     */
    public String getApprovalVersion() {
        return approvalVersion;
    }

    /**
     * @param approvalVersion the approvalVersion to set
     */
    public void setApprovalVersion(String approvalVersion) {
        this.approvalVersion = approvalVersion;
    }

}