package bg.demax.ictclient.dtos;

import java.io.Serializable;

public class VehicleBodyType implements Serializable {

    private static final long serialVersionUID = 678468521976483613L;
    private String typeCode;
    private String typeNumber;

    /**
     * @return String return the typeCode
     */
    public String getTypeCode() {
        return typeCode;
    }

    /**
     * @param typeCode the typeCode to set
     */
    public void setTypeCode(String typeCode) {
        this.typeCode = typeCode;
    }

    /**
     * @return String return the typeNumber
     */
    public String getTypeNumber() {
        return typeNumber;
    }

    /**
     * @param typeNumber the typeNumber to set
     */
    public void setTypeNumber(String typeNumber) {
        this.typeNumber = typeNumber;
    }

}