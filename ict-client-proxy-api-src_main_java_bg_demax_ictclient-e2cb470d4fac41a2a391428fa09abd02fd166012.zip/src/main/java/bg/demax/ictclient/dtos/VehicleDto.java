package bg.demax.ictclient.dtos;

import java.io.Serializable;
import java.math.BigInteger;

public class VehicleDto implements Serializable {
    private static final long serialVersionUID = 8539411774182078811L;

    private String vehicleDocumentIdNumber;

    private String vehIdentificationNumber;

    private String category;

    private String vehOffRoadSymbol;

    private String color;

    private String firstRegistrationDate;

    private String vehDocumentDate;

    private String make;

    private String type;

    private String vehCommercialName;

    private BigInteger vehOwnerVerification;

    private VehicleMassDistribution massDistribution;

    private String numberOfSeats;

    private BigInteger numberOfStanding;

    private VehicleMass vehMass;

    private VehicleApprovalData vehicleApproval;

    private BigInteger vehMassG;

    private BigInteger vehNumberOfAxles;

    private VehicleTrailerMass trailerMass;

    private VehicleSoundLevel soundLevel;

    private VehicleExhaustEmitions exhaustEmitions;

    private VehicleBodyType vehicleBodyType;

    private VehicleEngine engine;

    /**
     * @return String return the vehIdentificationNumber
     */
    public String getVehIdentificationNumber() {
        return vehIdentificationNumber;
    }

    public String getVehDocumentDate() {
        return vehDocumentDate;
    }

    public void setVehDocumentDate(String vehDocumentDate) {
        this.vehDocumentDate = vehDocumentDate;
    }

    public String getVehOffRoadSymbol() {
        return vehOffRoadSymbol;
    }

    public void setVehOffRoadSymbol(String vehOffRoadSymbol) {
        this.vehOffRoadSymbol = vehOffRoadSymbol;
    }

    /**
     * @param vehIdentificationNumber the vehIdentificationNumber to set
     */
    public void setVehIdentificationNumber(String vehIdentificationNumber) {
        this.vehIdentificationNumber = vehIdentificationNumber;
    }

    /**
     * @return String return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     * @return String return the color
     */
    public String getColor() {
        return color;
    }

    /**
     * @param color the color to set
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * @return String return the firstRegistrationDate
     */
    public String getFirstRegistrationDate() {
        return firstRegistrationDate;
    }

    /**
     * @param firstRegistrationDate the firstRegistrationDate to set
     */
    public void setFirstRegistrationDate(String firstRegistrationDate) {
        this.firstRegistrationDate = firstRegistrationDate;
    }

    /**
     * @return String return the make
     */
    public String getMake() {
        return make;
    }

    /**
     * @param make the make to set
     */
    public void setMake(String make) {
        this.make = make;
    }

    /**
     * @return String return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return String return the vehCommercialName
     */
    public String getVehCommercialName() {
        return vehCommercialName;
    }

    /**
     * @param vehCommercialName the vehCommercialName to set
     */
    public void setVehCommercialName(String vehCommercialName) {
        this.vehCommercialName = vehCommercialName;
    }

    /**
     * @return BigInteger return the vehOwnerVerification
     */
    public BigInteger getVehOwnerVerification() {
        return vehOwnerVerification;
    }

    /**
     * @param vehOwnerVerification the vehOwnerVerification to set
     */
    public void setVehOwnerVerification(BigInteger vehOwnerVerification) {
        this.vehOwnerVerification = vehOwnerVerification;
    }

    /**
     * @return VehicleMassDistribution return the massDistribution
     */
    public VehicleMassDistribution getMassDistribution() {
        return massDistribution;
    }

    /**
     * @param massDistribution the massDistribution to set
     */
    public void setMassDistribution(VehicleMassDistribution massDistribution) {
        this.massDistribution = massDistribution;
    }

    /**
     * @return String return the numberOfSeats
     */
    public String getNumberOfSeats() {
        return numberOfSeats;
    }

    /**
     * @param numberOfSeats the numberOfSeats to set
     */
    public void setNumberOfSeats(String numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    /**
     * @return BigInteger return the numberOfStanding
     */
    public BigInteger getNumberOfStanding() {
        return numberOfStanding;
    }

    /**
     * @param numberOfStanding the numberOfStanding to set
     */
    public void setNumberOfStanding(BigInteger numberOfStanding) {
        this.numberOfStanding = numberOfStanding;
    }

    /**
     * @return VehicleMass return the vehMass
     */
    public VehicleMass getVehMass() {
        return vehMass;
    }

    /**
     * @param vehMass the vehMass to set
     */
    public void setVehMass(VehicleMass vehMass) {
        this.vehMass = vehMass;
    }

    /**
     * @return VehicleApprovalData return the vehicleApproval
     */
    public VehicleApprovalData getVehicleApproval() {
        return vehicleApproval;
    }

    /**
     * @param vehicleApproval the vehicleApproval to set
     */
    public void setVehicleApproval(VehicleApprovalData vehicleApproval) {
        this.vehicleApproval = vehicleApproval;
    }

    /**
     * @return BigInteger return the vehMassG
     */
    public BigInteger getVehMassG() {
        return vehMassG;
    }

    /**
     * @param vehMassG the vehMassG to set
     */
    public void setVehMassG(BigInteger vehMassG) {
        this.vehMassG = vehMassG;
    }

    /**
     * @return BigInteger return the vehNumberOfAxles
     */
    public BigInteger getVehNumberOfAxles() {
        return vehNumberOfAxles;
    }

    /**
     * @param vehNumberOfAxles the vehNumberOfAxles to set
     */
    public void setVehNumberOfAxles(BigInteger vehNumberOfAxles) {
        this.vehNumberOfAxles = vehNumberOfAxles;
    }

    /**
     * @return VehicleTrailerMass return the trailerMass
     */
    public VehicleTrailerMass getTrailerMass() {
        return trailerMass;
    }

    /**
     * @param trailerMass the trailerMass to set
     */
    public void setTrailerMass(VehicleTrailerMass trailerMass) {
        this.trailerMass = trailerMass;
    }

    /**
     * @return VehicleSoundLevel return the soundLevel
     */
    public VehicleSoundLevel getSoundLevel() {
        return soundLevel;
    }

    /**
     * @param soundLevel the soundLevel to set
     */
    public void setSoundLevel(VehicleSoundLevel soundLevel) {
        this.soundLevel = soundLevel;
    }

    /**
     * @return VehicleExhaustEmitions return the exhaustEmitions
     */
    public VehicleExhaustEmitions getExhaustEmitions() {
        return exhaustEmitions;
    }

    /**
     * @param exhaustEmitions the exhaustEmitions to set
     */
    public void setExhaustEmitions(VehicleExhaustEmitions exhaustEmitions) {
        this.exhaustEmitions = exhaustEmitions;
    }

    /**
     * @return VehicleEngine return the engine
     */
    public VehicleEngine getEngine() {
        return engine;
    }

    /**
     * @param engine the engine to set
     */
    public void setEngine(VehicleEngine engine) {
        this.engine = engine;
    }

    /**
     * @return VehicleBodyType return the vehicleBodyType
     */
    public VehicleBodyType getVehicleBodyType() {
        return vehicleBodyType;
    }

    /**
     * @param vehicleBodyType the vehicleBodyType to set
     */
    public void setVehicleBodyType(VehicleBodyType vehicleBodyType) {
        this.vehicleBodyType = vehicleBodyType;
    }

    /**
     * @return String return the vehicleDocumentIdNumber
     */
    public String getVehicleDocumentIdNumber() {
        return vehicleDocumentIdNumber;
    }

    /**
     * @param vehicleDocumentIdNumber the vehicleDocumentIdNumber to set
     */
    public void setVehicleDocumentIdNumber(String vehicleDocumentIdNumber) {
        this.vehicleDocumentIdNumber = vehicleDocumentIdNumber;
    }

}