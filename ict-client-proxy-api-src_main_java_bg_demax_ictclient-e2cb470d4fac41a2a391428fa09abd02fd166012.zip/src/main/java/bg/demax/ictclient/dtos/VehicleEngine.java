package bg.demax.ictclient.dtos;

import java.io.Serializable;
import java.math.BigInteger;

public class VehicleEngine implements Serializable {
    private static final long serialVersionUID = 5749411774182078811L;

    private String engineNumber;
    private String vehFuel;
    private BigInteger capacity;
    private String maxPower;
    private BigInteger vehRatedSpeed;

    /**
     * @return String return the engineNumber
     */
    public String getEngineNumber() {
        return engineNumber;
    }

    /**
     * @param engineNumber the engineNumber to set
     */
    public void setEngineNumber(String engineNumber) {
        this.engineNumber = engineNumber;
    }

    /**
     * @return String return the vehFuel
     */
    public String getVehFuel() {
        return vehFuel;
    }

    /**
     * @param vehFuel the vehFuel to set
     */
    public void setVehFuel(String vehFuel) {
        this.vehFuel = vehFuel;
    }

    /**
     * @return BigInteger return the capacity
     */
    public BigInteger getCapacity() {
        return capacity;
    }

    /**
     * @param capacity the capacity to set
     */
    public void setCapacity(BigInteger capacity) {
        this.capacity = capacity;
    }

    /**
     * @return String return the maxPower
     */
    public String getMaxPower() {
        return maxPower;
    }

    /**
     * @param maxPower the maxPower to set
     */
    public void setMaxPower(String maxPower) {
        this.maxPower = maxPower;
    }


    /**
     * @return BigInteger return the VehRatedSpeed
     */
    public BigInteger getVehRatedSpeed() {
        return vehRatedSpeed;
    }

    /**
     * @param VehRatedSpeed the VehRatedSpeed to set
     */
    public void setVehRatedSpeed(BigInteger vehRatedSpeed) {
        this.vehRatedSpeed = vehRatedSpeed;
    }

}