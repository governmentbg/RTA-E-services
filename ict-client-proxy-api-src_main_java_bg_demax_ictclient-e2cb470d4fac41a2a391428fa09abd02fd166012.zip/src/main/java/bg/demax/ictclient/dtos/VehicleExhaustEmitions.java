package bg.demax.ictclient.dtos;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;

public class VehicleExhaustEmitions implements Serializable {

    private static final long serialVersionUID = 3627639573502950365L;

    private String environmentalCategory;
    private BigDecimal absorbtionCoefficient;

    /**
     * @return String return the environmentalCategory
     */
    public String getEnvironmentalCategory() {
        return environmentalCategory;
    }

    /**
     * @param environmentalCategory the environmentalCategory to set
     */
    public void setEnvironmentalCategory(String environmentalCategory) {
        this.environmentalCategory = environmentalCategory;
    }

    /**
     * @return BigDecimal return the absorbtionCoefficient
     */
    public BigDecimal getAbsorbtionCoefficient() {
        return absorbtionCoefficient;
    }

    /**
     * @param absorbtionCoefficient the absorbtionCoefficient to set
     */
    public void setAbsorbtionCoefficient(BigDecimal absorbtionCoefficient) {
        this.absorbtionCoefficient = absorbtionCoefficient;
    }

}