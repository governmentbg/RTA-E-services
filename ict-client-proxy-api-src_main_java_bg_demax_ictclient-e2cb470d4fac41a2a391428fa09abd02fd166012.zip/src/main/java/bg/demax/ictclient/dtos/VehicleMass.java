package bg.demax.ictclient.dtos;

import java.io.Serializable;
import java.math.BigInteger;

public class VehicleMass implements Serializable {

    private static final long serialVersionUID = -3627627467005473970L;

    private BigInteger massF1;
    private BigInteger massF2;
    private BigInteger massF3;


    /**
     * @return BigInteger return the massF1
     */
    public BigInteger getMassF1() {
        return massF1;
    }

    /**
     * @param massF1 the massF1 to set
     */
    public void setMassF1(BigInteger massF1) {
        this.massF1 = massF1;
    }

    /**
     * @return BigInteger return the massF2
     */
    public BigInteger getMassF2() {
        return massF2;
    }

    /**
     * @param massF2 the massF2 to set
     */
    public void setMassF2(BigInteger massF2) {
        this.massF2 = massF2;
    }

    /**
     * @return BigInteger return the massF3
     */
    public BigInteger getMassF3() {
        return massF3;
    }

    /**
     * @param massF3 the massF3 to set
     */
    public void setMassF3(BigInteger massF3) {
        this.massF3 = massF3;
    }

}