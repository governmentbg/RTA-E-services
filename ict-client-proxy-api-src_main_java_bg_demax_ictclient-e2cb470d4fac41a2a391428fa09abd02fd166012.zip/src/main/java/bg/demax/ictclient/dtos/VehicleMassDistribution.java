package bg.demax.ictclient.dtos;


import java.io.Serializable;
import java.math.BigInteger;

public class VehicleMassDistribution  implements Serializable {
    private static final long serialVersionUID = 8551432574186048811L;
    
    private BigInteger axle1;
    private BigInteger axle2;
    private BigInteger axle3;
    private BigInteger axle4;
    private BigInteger axle5;

    /**
     * @return BigInteger return the axle1
     */
    public BigInteger getAxle1() {
        return axle1;
    }

    /**
     * @param axle1 the axle1 to set
     */
    public void setAxle1(BigInteger axle1) {
        this.axle1 = axle1;
    }

    /**
     * @return BigInteger return the axle2
     */
    public BigInteger getAxle2() {
        return axle2;
    }

    /**
     * @param axle2 the axle2 to set
     */
    public void setAxle2(BigInteger axle2) {
        this.axle2 = axle2;
    }

    /**
     * @return BigInteger return the axle3
     */
    public BigInteger getAxle3() {
        return axle3;
    }

    /**
     * @param axle3 the axle3 to set
     */
    public void setAxle3(BigInteger axle3) {
        this.axle3 = axle3;
    }

    /**
     * @return BigInteger return the axle4
     */
    public BigInteger getAxle4() {
        return axle4;
    }

    /**
     * @param axle4 the axle4 to set
     */
    public void setAxle4(BigInteger axle4) {
        this.axle4 = axle4;
    }

    /**
     * @return BigInteger return the axle5
     */
    public BigInteger getAxle5() {
        return axle5;
    }

    /**
     * @param axle5 the axle5 to set
     */
    public void setAxle5(BigInteger axle5) {
        this.axle5 = axle5;
    }

}