package bg.demax.ictclient.dtos;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Objects;

public class VehicleRequestDto implements Serializable {

    private static final long serialVersionUID = 2682227161023909345L;

    private String ownerId;
    private String vehicleRegistrationNumber;
    private String vehicleDocumentNumber;
    private BigInteger documentType;

    /**
     * @return String return the ownerId
     */
    public String getOwnerId() {
        return ownerId;
    }

    /**
     * @param ownerId the ownerId to set
     */
    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    /**
     * @return String return the vehicleRegistrationNumber
     */
    public String getVehicleRegistrationNumber() {
        return vehicleRegistrationNumber;
    }

    /**
     * @param vehicleRegistrationNumber the vehicleRegistrationNumber to set
     */
    public void setVehicleRegistrationNumber(String vehicleRegistrationNumber) {
        this.vehicleRegistrationNumber = vehicleRegistrationNumber;
    }

    /**
     * @return String return the vehicleDocumentNumber
     */
    public String getVehicleDocumentNumber() {
        return vehicleDocumentNumber;
    }

    /**
     * @param vehicleDocumentNumber the vehicleDocumentNumber to set
     */
    public void setVehicleDocumentNumber(String vehicleDocumentNumber) {
        this.vehicleDocumentNumber = vehicleDocumentNumber;
    }

    /**
     * @return BigInteger return the documentType
     */
    public BigInteger getDocumentType() {
        return documentType;
    }

    /**
     * @param documentType the documentType to set
     */
    public void setDocumentType(BigInteger documentType) {
        this.documentType = documentType;
    }

    @Override
    public boolean equals(Object o) {

        if (o == this)
            return true;
        if (!(o instanceof VehicleRequestDto)) {
            return false;
        }
        VehicleRequestDto vehRequestDto = (VehicleRequestDto) o;
        return Objects.equals(ownerId, vehRequestDto.ownerId)
                && Objects.equals(vehicleRegistrationNumber, vehRequestDto.vehicleRegistrationNumber)
                && Objects.equals(vehicleDocumentNumber, vehRequestDto.vehicleDocumentNumber)
                && Objects.equals(documentType, vehRequestDto.documentType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ownerId, vehicleRegistrationNumber, vehicleDocumentNumber, documentType);
    }

}