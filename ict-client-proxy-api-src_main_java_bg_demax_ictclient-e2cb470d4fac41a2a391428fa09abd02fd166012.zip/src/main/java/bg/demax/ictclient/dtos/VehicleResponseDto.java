package bg.demax.ictclient.dtos;

import java.io.Serializable;
import java.util.ArrayList;

public class VehicleResponseDto implements Serializable {
	
	private static final long serialVersionUID = -3627653376005473970L;
	
	private ArrayList<VehicleDto> vehicleDtos;
    private ReturnInformations returnInformation;

    /**
     * @return List<VehicleDto> return the vehicleDtos
     */
    public ArrayList<VehicleDto> getVehicleDtos() {
        return vehicleDtos;
    }

    /**
     * @param vehicleDtos the vehicleDtos to set
     */
    public void setVehicleDtos(ArrayList<VehicleDto> vehicleDtos) {
        this.vehicleDtos = vehicleDtos;
    }

    /**
     * @return ReturnInformations return the returnInformation
     */
    public ReturnInformations getReturnInformation() {
        return returnInformation;
    }

    /**
     * @param returnInformation the returnInformation to set
     */
    public void setReturnInformation(ReturnInformations returnInformation) {
        this.returnInformation = returnInformation;
    }

}