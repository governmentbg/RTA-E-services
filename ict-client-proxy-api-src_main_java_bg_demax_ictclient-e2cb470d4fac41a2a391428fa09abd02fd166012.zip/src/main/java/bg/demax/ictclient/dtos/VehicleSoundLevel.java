package bg.demax.ictclient.dtos;

import java.io.Serializable;
import java.math.BigInteger;

public class VehicleSoundLevel implements Serializable {
    private static final long serialVersionUID = -3627699876542950365L;

    private BigInteger soundLevelU1;
    private BigInteger soundLevelU2;
    private BigInteger soundLevelU3;

    /**
     * @return BigInteger return the soundLevelU1
     */
    public BigInteger getSoundLevelU1() {
        return soundLevelU1;
    }

    /**
     * @param soundLevelU1 the soundLevelU1 to set
     */
    public void setSoundLevelU1(BigInteger soundLevelU1) {
        this.soundLevelU1 = soundLevelU1;
    }


    /**
     * @return BigInteger return the soundLevelU2
     */
    public BigInteger getSoundLevelU2() {
        return soundLevelU2;
    }

    /**
     * @param soundLevelU2 the soundLevelU2 to set
     */
    public void setSoundLevelU2(BigInteger soundLevelU2) {
        this.soundLevelU2 = soundLevelU2;
    }

    /**
     * @return BigInteger return the soundLevelU3
     */
    public BigInteger getSoundLevelU3() {
        return soundLevelU3;
    }

    /**
     * @param soundLevelU3 the soundLevelU3 to set
     */
    public void setSoundLevelU3(BigInteger soundLevelU3) {
        this.soundLevelU3 = soundLevelU3;
    }

}