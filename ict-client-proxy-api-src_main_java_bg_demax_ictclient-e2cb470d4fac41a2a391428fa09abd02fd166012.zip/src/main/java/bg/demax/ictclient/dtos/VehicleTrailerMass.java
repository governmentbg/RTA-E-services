package bg.demax.ictclient.dtos;

import java.io.Serializable;
import java.math.BigInteger;

public class VehicleTrailerMass implements Serializable {

    private static final long serialVersionUID = -3627653376002950365L;

    private BigInteger massO1;
    private BigInteger massO2;

    /**
     * @return BigInteger return the massO1
     */
    public BigInteger getMassO1() {
        return massO1;
    }

    /**
     * @param massO1 the massO1 to set
     */
    public void setMassO1(BigInteger massO1) {
        this.massO1 = massO1;
    }

    /**
     * @return BigInteger return the massO2
     */
    public BigInteger getMassO2() {
        return massO2;
    }

    /**
     * @param massO2 the massO2 to set
     */
    public void setMassO2(BigInteger massO2) {
        this.massO2 = massO2;
    }

}