package bg.demax.ictclient.utils;

import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;

import bg.demax.ictclient.db.requests.CodeType;
import bg.demax.ictclient.db.requests.EAAAVehicleDataRequest;
import bg.demax.ictclient.db.requests.EAAAVehicleDataRequest.Request;
import bg.demax.ictclient.db.requests.EAAAVehicleDataResponse;
import bg.demax.ictclient.db.requests.EAAAVehicleDataResponse.Response.Results.Result;
import bg.demax.ictclient.db.requests.Header;
import bg.demax.ictclient.db.requests.VehDocumentType;
import bg.demax.ictclient.db.requests.VehicleOwnerDataType;
import bg.demax.ictclient.db.requests.VehicleRequestDataType;
import bg.demax.ictclient.dtos.ReturnInformations;
import bg.demax.ictclient.dtos.VehicleApprovalData;
import bg.demax.ictclient.dtos.VehicleBodyType;
import bg.demax.ictclient.dtos.VehicleDto;
import bg.demax.ictclient.dtos.VehicleEngine;
import bg.demax.ictclient.dtos.VehicleExhaustEmitions;
import bg.demax.ictclient.dtos.VehicleMass;
import bg.demax.ictclient.dtos.VehicleMassDistribution;
import bg.demax.ictclient.dtos.VehicleRequestDto;
import bg.demax.ictclient.dtos.VehicleResponseDto;
import bg.demax.ictclient.dtos.VehicleSoundLevel;
import bg.demax.ictclient.dtos.VehicleTrailerMass;

public class Converter {

    // ----------------------------------------------------------------------------
    private static final Map<Character, String> typoTranslater = Stream
            .of(new SimpleEntry<>('A', "А"), new SimpleEntry<>('B', "В"), new SimpleEntry<>('E', "Е"),
                    new SimpleEntry<>('K', "К"), new SimpleEntry<>('M', "М"), new SimpleEntry<>('H', "Н"),
                    new SimpleEntry<>('O', "О"), new SimpleEntry<>('P', "Р"), new SimpleEntry<>('C', "С"),
                    new SimpleEntry<>('T', "Т"), new SimpleEntry<>('Y', "У"), new SimpleEntry<>('X', "Х"))
            .collect(Collectors.toMap(SimpleEntry::getKey, SimpleEntry::getValue));

    // ----------------------------------------------------------------------------
    public static VehicleResponseDto EAAAVehicleDataResponseToVehicleDto(EAAAVehicleDataResponse vehicleDataResponse) {
        ArrayList<VehicleDto> vehicleResponse = new ArrayList<>();

        vehicleDataResponse.getResponse().getReturnInformation().getReturnCode();
        if (vehicleDataResponse.getResponse().getResults() != null) {

            List<Result> results = vehicleDataResponse.getResponse().getResults().getResult();
            for (Result result : results) {
                VehicleDto vehicleDto = new VehicleDto();

                if (result.getVehicleResponseData().getVehCategory() != null)
                    vehicleDto.setCategory(result.getVehicleResponseData().getVehCategory().getVehEUCategory());

                vehicleDto.setColor(result.getVehicleResponseData().getVehColour());
                if (result.getVehicleResponseData().getVehEngine() != null) {
                    VehicleEngine vehicleEngine = new VehicleEngine();

                    vehicleEngine.setEngineNumber(result.getVehicleResponseData().getVehEngine().getVehEngineNumber());
                    vehicleEngine.setVehFuel(result.getVehicleResponseData().getVehEngine().getVehFuel());
                    vehicleEngine.setCapacity(result.getVehicleResponseData().getVehEngine().getVehCapacity());
                    vehicleEngine.setMaxPower(result.getVehicleResponseData().getVehEngine().getVehMaxPower());
                    vehicleEngine.setVehRatedSpeed(result.getVehicleResponseData().getVehEngine().getVehRatedSpeed());

                    vehicleDto.setEngine(vehicleEngine);
                }
                if (result.getVehicleResponseData().getVehFirstRegistrationDate() != null)
                    vehicleDto.setFirstRegistrationDate(
                            result.getVehicleResponseData().getVehFirstRegistrationDate().toString());

                if (result.getVehicleResponseData().getVehMassDistribution() != null) {
                    VehicleMassDistribution massDistribution = new VehicleMassDistribution();
                    massDistribution.setAxle1(result.getVehicleResponseData().getVehMassDistribution().getVehMassN1());
                    massDistribution.setAxle2(result.getVehicleResponseData().getVehMassDistribution().getVehMassN2());
                    massDistribution.setAxle3(result.getVehicleResponseData().getVehMassDistribution().getVehMassN3());
                    massDistribution.setAxle4(result.getVehicleResponseData().getVehMassDistribution().getVehMassN4());
                    massDistribution.setAxle5(result.getVehicleResponseData().getVehMassDistribution().getVehMassN5());
                    vehicleDto.setMassDistribution(massDistribution);
                }

                if (result.getVehicleResponseData().getVehMass() != null) {
                    VehicleMass vehicleMass = new VehicleMass();
                    vehicleMass.setMassF1(result.getVehicleResponseData().getVehMass().getVehMassF1());
                    vehicleMass.setMassF2(result.getVehicleResponseData().getVehMass().getVehMassF2());
                    vehicleMass.setMassF3(result.getVehicleResponseData().getVehMass().getVehMassF3());
                    vehicleDto.setVehMass(vehicleMass);
                }

                if (result.getVehicleResponseData().getVehTypeApprovalData() != null) {

                    VehicleApprovalData approvalData = new VehicleApprovalData();
                    approvalData.setApprovalType(
                            result.getVehicleResponseData().getVehTypeApprovalData().getVehTypeApprovalType());
                    approvalData.setApprovalNumber(
                            result.getVehicleResponseData().getVehTypeApprovalData().getVehTypeApprovalNumber());
                    approvalData.setApprovalVariant(
                            result.getVehicleResponseData().getVehTypeApprovalData().getVehTypeApprovalVariant());
                    approvalData.setApprovalVersion(
                            result.getVehicleResponseData().getVehTypeApprovalData().getVehTypeApprovalVersion());

                    vehicleDto.setVehicleApproval(approvalData);
                }

                if (result.getVehicleResponseData().getVehBodyType() != null) {
                    VehicleBodyType bodyType = new VehicleBodyType();

                    bodyType.setTypeCode(result.getVehicleResponseData().getVehBodyType().getVehBodyTypeCode());
                    bodyType.setTypeNumber(result.getVehicleResponseData().getVehBodyType().getVehBodyTypeNum());

                    vehicleDto.setVehicleBodyType(bodyType);
                }

                if (result.getVehicleResponseData().getVehSeatingCapacity() != null) {
                    vehicleDto.setNumberOfStanding(
                            result.getVehicleResponseData().getVehSeatingCapacity().getVehNumberOfStanding());
                    vehicleDto.setNumberOfSeats(
                            result.getVehicleResponseData().getVehSeatingCapacity().getVehNumberOfSeats());
                }

                if (result.getVehicleResponseData().getVehTrailerMass() != null) {
                    VehicleTrailerMass trailerMass = new VehicleTrailerMass();
                    trailerMass.setMassO1(result.getVehicleResponseData().getVehTrailerMass().getVehMassO1());
                    trailerMass.setMassO2(result.getVehicleResponseData().getVehTrailerMass().getVehMassO2());
                    vehicleDto.setTrailerMass(trailerMass);
                }

                if (result.getVehicleResponseData().getVehExhaustEmmitions() != null) {
                    VehicleExhaustEmitions exhaustEmitions = new VehicleExhaustEmitions();
                    exhaustEmitions.setEnvironmentalCategory(
                            result.getVehicleResponseData().getVehExhaustEmmitions().getVehEnvironmentalCategory());
                    exhaustEmitions.setAbsorbtionCoefficient(
                            result.getVehicleResponseData().getVehExhaustEmmitions().getVehAbsorbtionCoefficient());

                    vehicleDto.setExhaustEmitions(exhaustEmitions);
                }

                if (result.getVehicleDocumentResponseData() != null) {
                    vehicleDto.setVehicleDocumentIdNumber(
                            result.getVehicleDocumentResponseData().getVehDocumentIDNumber());
                }

                if (result.getVehicleResponseData().getVehSoundLevel() != null) {
                    VehicleSoundLevel soundLevel = new VehicleSoundLevel();
                    soundLevel.setSoundLevelU1(result.getVehicleResponseData().getVehSoundLevel().getVehSoundLevelU1());
                    soundLevel.setSoundLevelU2(result.getVehicleResponseData().getVehSoundLevel().getVehSoundLevelU2());
                    soundLevel.setSoundLevelU3(result.getVehicleResponseData().getVehSoundLevel().getVehSoundLevelU3());

                    vehicleDto.setSoundLevel(soundLevel);
                }

                vehicleDto.setVehNumberOfAxles(result.getVehicleResponseData().getVehNumOfAxles());
                vehicleDto.setVehMassG(result.getVehicleResponseData().getVehMassG());
                vehicleDto.setMake(result.getVehicleResponseData().getVehMake());
                vehicleDto.setType(result.getVehicleResponseData().getVehType());
                vehicleDto.setVehCommercialName(result.getVehicleResponseData().getVehCommercialName());
                vehicleDto.setVehIdentificationNumber(result.getVehicleResponseData().getVehIdentificationNumber());
                vehicleDto.setVehOwnerVerification(result.getVehicleOwnerVerification().getValue());
                vehicleResponse.add(vehicleDto);

            }
        }

        VehicleResponseDto responseDto = new VehicleResponseDto();
        responseDto.setVehicleDtos(vehicleResponse);

        ReturnInformations returnInfo = new ReturnInformations();
        returnInfo.setReturnCode(vehicleDataResponse.getResponse().getReturnInformation().getReturnCode());
        responseDto.setReturnInformation(returnInfo);

        return responseDto;

    }

    // ----------------------------------------------------------------------------
    public static EAAAVehicleDataRequest createRequest(VehicleRequestDto vehicleRequest,
            bg.demax.ictclient.db.requests.ObjectFactory vehicleObjectFactory) throws DatatypeConfigurationException {

        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        DatatypeFactory datatypeFactory = DatatypeFactory.newInstance();

        EAAAVehicleDataRequest request = vehicleObjectFactory.createEAAAVehicleDataRequest();

        Header requestHeader = vehicleObjectFactory.createHeader();

        Request requestObject = vehicleObjectFactory.createEAAAVehicleDataRequestRequest();
        VehicleOwnerDataType vehicleOwner = vehicleObjectFactory.createVehicleOwnerDataType();
        VehicleRequestDataType vehicleRequestData = vehicleObjectFactory.createVehicleRequestDataType();
        VehDocumentType documentType = vehicleObjectFactory.createVehDocumentType();
        CodeType codeType = vehicleObjectFactory.createCodeType();

        requestHeader.setDateTime(datatypeFactory.newXMLGregorianCalendar(gregorianCalendar));
        requestHeader.setMessageID(UUID.randomUUID().toString());
        requestHeader.setSystemID("eaaa-kat");
        requestHeader.setOperation("0001");

        codeType.setValue(vehicleRequest.getDocumentType());

        documentType.setVehDocumentType(codeType);
        documentType.setVehDocumentNumber(vehicleRequest.getVehicleDocumentNumber());

        vehicleRequestData.setVehRegistrationNumber(Converter.latToBgr(vehicleRequest.getVehicleRegistrationNumber()));
        vehicleRequestData.setVehDocument(documentType);

        vehicleOwner.setVehOwnerId(vehicleRequest.getOwnerId());

        requestObject.setVehicleOwnerData(vehicleOwner);
        requestObject.setVehicleRequestData(vehicleRequestData);

        request.setHeader(requestHeader);
        request.setRequest(requestObject);

        return request;
    }

    // ----------------------------------------------------------------------------
    public static String latToBgr(String stringToConvert) {
        StringBuilder builder = new StringBuilder();
        for (int iCnter = 0; iCnter < stringToConvert.length(); iCnter++) {
            if (typoTranslater.containsKey(stringToConvert.charAt(iCnter)))
                builder.append(typoTranslater.get(stringToConvert.charAt(iCnter)));
            else
                builder.append(stringToConvert.charAt(iCnter));
        }
        return builder.toString();
    }
    // ----------------------------------------------------------------------------

}