BEGIN;
--  check entire script for existing tables
-- on production these don't exist. do not mistake these with public.s_drums and public.s_cartridges which are old

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET search_path = public, pg_catalog;
SET default_tablespace = '';
SET default_with_oids = false;

-- create public.n_printer_consumable_statuses table
CREATE TABLE public.n_printer_consumable_statuses (
    code character varying(15) NOT NULL,
    description character varying(32) NOT NULL,
    CONSTRAINT n_printer_consumable_statuses_pkey PRIMARY KEY (code)
);

ALTER TABLE public.n_printer_consumable_statuses OWNER TO demax_admin;

    
-- insert data into public.n_printer_consumable_statuses
INSERT INTO public.n_printer_consumable_statuses VALUES ('SENT', 'sent');
INSERT INTO public.n_printer_consumable_statuses VALUES ('INSTALLED', 'installed');
INSERT INTO public.n_printer_consumable_statuses VALUES ('REPORTED', 'reported');
INSERT INTO public.n_printer_consumable_statuses VALUES ('RETURNED', 'returned');
--

-- create public.n_printer_consumable_types table
CREATE TABLE public.n_printer_consumable_types (
    code character varying(15) NOT NULL,
    description character varying(32) NOT NULL,
    CONSTRAINT n_printer_consumable_types_pkey PRIMARY KEY (code)
);

ALTER TABLE public.n_printer_consumable_types OWNER TO demax_admin;


-- insert data into public.n_printer_consumable_types
INSERT INTO public.n_printer_consumable_types VALUES ('CARTRIDGE', 'Тонер касета');
INSERT INTO public.n_printer_consumable_types VALUES ('DRUM', 'Барабан');   
    

-- create public.n_printer_consumable_report_statuses table
CREATE TABLE public.n_printer_consumable_report_statuses (
    code character varying(15) NOT NULL,
    description character varying(32) NOT NULL,
    CONSTRAINT n_printer_consumable_report_statuses_pkey PRIMARY KEY (code)
);

ALTER TABLE public.n_printer_consumable_report_statuses OWNER TO demax_admin;


-- insert data into public.n_printer_consumable_types
INSERT INTO public.n_printer_consumable_report_statuses VALUES ('REPORTED', 'Направен отчет');
INSERT INTO public.n_printer_consumable_report_statuses VALUES ('PAYMENT', 'Очаква плащане на листа');   
INSERT INTO public.n_printer_consumable_report_statuses VALUES ('PAYED', 'Платено');    

-- create public.printer_consumables table
CREATE TABLE public.printer_consumables (
    id SERIAL,
    sent_at timestamp without time zone,
    sent_to_permit_id integer,
    is_defective boolean DEFAULT false NOT NULL,
    returned_at date,
	returned_notes character varying(255),
	type_code character varying(15) NOT NULL,
	status_code character varying(15) NOT NULL,
    serial_number character varying(128),
    printer_id integer,
    percent_used integer,
    printed_pages integer,
    remaining_pages integer,
    first_installed_at timestamp without time zone,
    last_used_at timestamp without time zone,
    total_impressions integer,
    CONSTRAINT printer_consumables_pkey PRIMARY KEY (id),
    CONSTRAINT printer_consumable_serial_number_key UNIQUE (serial_number),
    CONSTRAINT printer_consumables_sent_to_permit_id_fkey FOREIGN KEY (sent_to_permit_id) REFERENCES techinsp.permits(id),
    CONSTRAINT printer_consumables_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES s_dev_store(id),
    CONSTRAINT printer_consumables_status_code_fkey FOREIGN KEY (status_code) REFERENCES n_printer_consumable_report_statuses(code),
    CONSTRAINT printer_consumables_type_code_fkey FOREIGN KEY (type_code) REFERENCES n_printer_consumable_types(code)
);

ALTER TABLE public.printer_consumables OWNER TO demax_admin;


GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,UPDATE ON TABLE printer_consumables TO techinsp;
GRANT SELECT,UPDATE ON SEQUENCE printer_consumables_id_seq TO techinsp;


GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,UPDATE ON TABLE printer_consumables TO techinsp;
--

-- create public.printer_cartridge_reports table
CREATE TABLE public.printer_consumable_reports (
    id serial NOT NULL,
    consumable_id integer NOT NULL,
    permit_line_id integer NOT NULL,
    printed_pages integer NOT NULL,
    inspection_needed_pages integer NOT NULL,
    pages_for_payment integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    status_code character varying(15) NOT NULL,
    CONSTRAINT printer_consumable_reports_pkey PRIMARY KEY (id),
    CONSTRAINT printer_consumable_reports_consumable_id_fkey FOREIGN KEY (consumable_id) REFERENCES printer_consumables(id),
    CONSTRAINT printer_consumables_status_code_fkey FOREIGN KEY (status_code) REFERENCES n_printer_consumable_statuses(code),
    CONSTRAINT printer_consumable_reports_permit_line_id_fkey FOREIGN KEY (permit_line_id) REFERENCES techinsp.permit_lines(id)
    
);

ALTER TABLE public.printer_consumable_reports OWNER TO demax_admin;

-- Name: consumable_transfer_bill_of_ladings; Type: TABLE; Schema: public; Owner: admin;
CREATE TABLE consumable_transfer_bill_of_ladings (
    id serial NOT NULL,
    permit_id integer NOT NULL,
    package_count integer NOT NULL,
    weight_kg numeric(14,2) NOT NULL,
    recipient_address character varying(255) NOT NULL,
    recipient_person_name character varying NOT NULL,
    recipient_person_phone character varying NOT NULL,
    cartridges_count smallint,
    drums_count smallint,
    CONSTRAINT consumable_transfer_bill_of_lading_pkey PRIMARY KEY (id),
    CONSTRAINT consumable_transfer_bill_of_lading_id_fkey FOREIGN KEY (id) REFERENCES bill_of_ladings(id),
    CONSTRAINT consumable_transfer_bill_of_lading_permit_id_fkey FOREIGN KEY (permit_id) REFERENCES techinsp.permits(id)
);

ALTER TABLE public.consumable_transfer_bill_of_ladings OWNER TO demax_admin;

-- FUNCTION: public.add_pages_for_payment_to_order()

DROP TRIGGER add_pages_payment_to_order ON public.orders;

DROP FUNCTION public.add_pages_for_payment_to_order();

CREATE FUNCTION public.add_pages_for_payment_to_order()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF 
AS $BODY$
DECLARE
	l_reports record;
	l_permit_id numeric;
	l_issuer_id numeric;
BEGIN
	SELECT permit_id INTO l_permit_id 
	FROM permit_lines 
	WHERE id=NEW.permit_line_id;

	IF FOUND
	THEN 
		SELECT issuer_id INTO l_issuer_id 
		FROM n_products 
		WHERE id=908;

		IF l_issuer_id=NEW.issuer_id
		THEN
			FOR l_reports IN SELECT CR.id,  CR.pages_for_payment 
						FROM printer_consumable_reports CR
						LEFT JOIN permit_lines PL ON (CR.permit_line_id = PL.id)
						LEFT JOIN printer_consumables PC ON (CR.consumable_id = PC.id)
						WHERE PL.permit_id=l_permit_id AND CR.status_code='REPORTED' AND PC.type_code='CARTRIDGE'

			LOOP
				IF l_reports.pages_for_payment > 0
				THEN
					INSERT INTO order_items (order_id, product_id, quantity, from_num, to_num)
					VALUES (NEW.id, '908', l_reports.pages_for_payment, -1, -1);
				
					UPDATE printer_consumable_reports SET status='PAYED' WHERE id = l_reports.id;
				END IF;
			END LOOP;
		END IF;
	END IF;
	RETURN NULL;
END;
$BODY$;

CREATE TRIGGER add_pages_payment_to_order AFTER INSERT ON public.orders FOR EACH ROW EXECUTE PROCEDURE add_pages_for_payment_to_order();

ALTER FUNCTION public.add_pages_for_payment_to_order()
    OWNER TO techinsp;

  
GRANT SELECT, UPDATE ON printer_consumable_reports TO techinsp;    
COMMIT;
