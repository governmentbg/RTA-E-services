BEGIN;

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = security, pg_catalog;

INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.accounting', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', '', 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.cc', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, '-----BEGIN CERTIFICATE----- MIIESDCCAzCgAwIBAgIITTSUo0NbtCcwDQYJKoZIhvcNAQELBQAwEDEOMAwGA1UE AwwFRVZQQ0EwHhcNMTYwNDExMDkxOTI0WhcNNDEwMjE1MTY1MDAyWjBSMRYwFAYD VQQDDA1OaWtvbGF5IFBvcG92MQswCQYDVQQLDAJJVDEOMAwGA1UECgwFRGVtYXgx DjAMBgNVBAcMBVNvZmlhMQswCQYDVQQGEwJCRzCCASIwDQYJKoZIhvcNAQEBBQAD ggEPADCCAQoCggEBANf7V/wud7yksgL0a197IOGLWjXijL2eUuaqk0pSu0Yd9xi/ Rgp3W6ARgWdKmsU4kSCpuqFmjgQ4B8xqSKrukt77ErmRiIxPMCSmJv0pwU0nEyYm hjr416uHmGyPLQupBuXv56AxXuu6HGiTyefw28HfqUDLnalo4t9tYQr/RLbJI00T 5lw5FeHFrg2d8YnMMaBQmHzKTa+zi3qndTZXZX+/fgZMhf83Tos5RYeU+XQG1Z3H ELqda2UpeegRPbCnKbuYNHriR6xUVHX1+xm7doBxyPOq32fr9t918B4OI37Cr5a8 rtRTVCbyOjOQ+BOWePpgwSNl24LzEpqS9rEQHqMCAwEAAaOCAWIwggFeMB0GA1Ud DgQWBBRL2ArwcySkkIcGTC+9eeQ1+W69izAMBgNVHRMBAf8EAjAAMB8GA1UdIwQY MBaAFNZxZvqAAYV6GOnrGImZCsZnHtgEMGYGA1UdLgRfMF0wW6BZoFeGVWh0dHA6 Ly9vY3NwLmVpZC5iZzo4MDgwL2VqYmNhL3B1YmxpY3dlYi93ZWJkaXN0L2NlcnRk aXN0P2NtZD1kZWx0YWNybCZpc3N1ZXI9Q049RVZQQ0EwdwYDVR0fBHAwbjBsoFSg UoZQaHR0cDovL29jc3AuZWlkLmJnOjgwODAvZWpiY2EvcHVibGljd2ViL3dlYmRp c3QvY2VydGRpc3Q/Y21kPWNybCZpc3N1ZXI9Q049RVZQQ0GiFKQSMBAxDjAMBgNV BAMMBUVWUENBMA4GA1UdDwEB/wQEAwIF4DAdBgNVHSUEFjAUBggrBgEFBQcDAgYI KwYBBQUHAwQwDQYJKoZIhvcNAQELBQADggEBAFnKAeoxPksBW5EL5KuqUPRKte4K nVZe8VIL1HuaFPF82AmixMuZHIDWo3EkwToxIgloHkeS8d5UhPytHxG4EaoGxIuA bCpTQcFn72ayvia9WmxenDro0dzbWAFjk0eoNeqXssOQQeJN1NnenpJQr3qp3Wjo wtULl5O0eUNl+TLeMZeiShmU9i0o4EZJeqkYjxOdF0Je9OHnrhvxfcGtv/xGekKA hdTbgMvUC8hKgbrVs7vXDodil+nc8mtbO9Kzt+ykBQK4uWYp0vu4dqVMro1OcFp0 I8VI6MdD1cYwKwS3/veh7SFcEGcpvF33vNFpxrjI4RinKS+p2/ohS2cDAUI= -----END CERTIFICATE-----', 'both', '', '', 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.packaging.vouchers', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', '', 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.packaging.inspections', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', '', 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.supervisor', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', NULL, 0);

--techinsp
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.techinsp.secondary.inspection', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', NULL, 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.techinsp.cemt.edit', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', NULL, 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.techinsp.cemt.view', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', NULL, 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.techinsp.cemt.reports', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', NULL, 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.techinsp.messages.view', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', NULL, 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.techinsp.messages.edit', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', NULL, 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.techinsp.insp.iaaa.reports', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', NULL, 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.techinsp.insp.search.all', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', NULL, 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.techinsp.insp.all.statistics', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', NULL, 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.techinsp.admin', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', NULL, 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.techinsp.video.downloader', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', NULL, 0);
INSERT INTO users VALUES (nextval('seq_user_id'::regclass), 'demax.admin.techinsp.iaaa', '3808769c91d6dd3cadddfcea2df029423658a34c', true, 0, NULL, 'form', '', NULL, 0);

INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.accounting'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_ACCOUNTING'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.cc'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_CALL_CENTER'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.packaging.vouchers'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_PACKAGING_VOUCHERS'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.packaging.inspections'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_PACKAGING_INSPECTIONS'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.supervisor'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_DEMAX_ADMIN_SUPERVISOR'));

--techinsp
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.techinsp.secondary.inspection'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_TECHINSP_SECONDARY_INSPECTION'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.techinsp.cemt.edit'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_TECHINSP_CEMT_EDIT'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.techinsp.cemt.view'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_TECHINSP_CEMT_VIEW'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.techinsp.cemt.reports'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_TECHINSP_CEMT_REPORTS'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.techinsp.messages.view'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_TECHINSP_MESSAGES_VIEW'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.techinsp.messages.edit'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_TECHINSP_MESSAGES_EDIT'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.techinsp.insp.iaaa.reports'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_TECHINSP_INSP_IAAA_REPORTS'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.techinsp.insp.search.all'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_TECHINSP_INSP_SEARCH_ALL'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.techinsp.insp.all.statistics'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_TECHINSP_INSP_ALL_STATISTICS'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.techinsp.admin'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_TECHINSP_ADMIN'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.techinsp.video.downloader'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_TECHINSP_VIDEO_DOWNLOADER'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.admin.techinsp.iaaa'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_TECHINSP_IAAA'));

COMMIT;
