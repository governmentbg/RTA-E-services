BEGIN;

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, techinsp, pg_catalog;
SET default_tablespace = '';
SET default_with_oids = false;


CREATE TABLE n_couriers (
		code character varying(6) NOT NULL PRIMARY KEY,
		name character varying(64) NOT NULL
	);

INSERT INTO n_couriers (code, name) VALUES ('SPEEDY', 'Спиди'),
						   ('ECONT', 'Еконт'), ('DEMAX', 'Доставка от страна на Демакс');

CREATE TABLE n_courier_service_types (
		code character varying(10) NOT NULL PRIMARY KEY,
		name character varying(64) NOT NULL
	);

INSERT INTO n_courier_service_types (code, name) VALUES ('STANDARD', 'Стандартна'),
						   ('EXPRESS', 'Експресна');

CREATE TABLE n_bill_of_lading_statuses (
		code character varying(10) NOT NULL PRIMARY KEY,
		name character varying(64) NOT NULL
	);

INSERT INTO n_bill_of_lading_statuses (code, name) VALUES ('REQUESTED', 'празна'),
		('NOT_SENT', 'неизпратена'),
		('EXPIRED', 'изтекла'),
		('SENT', 'изпратена'),
		('CANCELED', 'Отказана');


CREATE TABLE bill_of_ladings (
		id SERIAL NOT NULL,
		bill_of_lading_id_for_courier character varying(30) NOT NULL,
		courier_code character varying(6) NOT NULL REFERENCES public.n_couriers(code),
		courier_service_type character varying(10) NOT NULL REFERENCES public.n_courier_service_types(code),
		created_at timestamp without time zone,
		status character varying(10) NOT NULL  REFERENCES public.n_bill_of_lading_statuses(code),
		request_user int REFERENCES security.users(user_id),
		CONSTRAINT bill_of_lading_id_for_courier_courier_code UNIQUE(bill_of_lading_id_for_courier, courier_code),
		PRIMARY KEY (id)
	);


-- create table public.n_warehouses
CREATE TABLE public.n_warehouses (
	id integer NOT NULL,
	name character varying(40) NOT NULL,
	city_code character varying(5) NOT NULL
);

ALTER TABLE public.n_warehouses OWNER TO admin;

ALTER TABLE ONLY n_warehouses
	ADD CONSTRAINT n_warehouses_pkey PRIMARY KEY (id);

ALTER TABLE ONLY n_warehouses
	ADD CONSTRAINT n_warehouses_city_code_fkey FOREIGN KEY (city_code) REFERENCES n_cities(code);
--

-- insert data in table public.n_warehouses
INSERT INTO n_warehouses VALUES (1, 'София Кремиковци', '68134');
INSERT INTO n_warehouses VALUES (2, 'София Цариградско шосе голям склад', '68134');
INSERT INTO n_warehouses VALUES (3, 'София Цариградско шосе малък склад', '68134');
INSERT INTO n_warehouses VALUES (4, 'Бургас', '07079');
INSERT INTO n_warehouses VALUES (5, 'Варна', '10135');
INSERT INTO n_warehouses VALUES (6, 'Враца', '12259');
INSERT INTO n_warehouses VALUES (7, 'Плевен', '56722');
INSERT INTO n_warehouses VALUES (8, 'Пловдив', '56784');
INSERT INTO n_warehouses VALUES (9, 'Стара Загора', '68850');
--

-- create table public.warehouse_shipping_info
CREATE TABLE public.warehouse_shipping_info (
	id integer NOT NULL,
	warehouse_id integer NOT NULL,
	address character varying(255) NOT NULL,
	recipient_person_name character varying(255),
	recipient_person_phone character varying(20),
	speedy_office_address character varying(255) NOT NULL,
	company_name character varying(50)
);

ALTER TABLE public.warehouse_shipping_info OWNER TO admin;

CREATE SEQUENCE warehouse_shipping_info_id_seq
	START WITH 1
	INCREMENT BY 1
	NO MINVALUE
	NO MAXVALUE
	CACHE 1;

ALTER TABLE public.warehouse_shipping_info_id_seq OWNER TO admin;

ALTER SEQUENCE warehouse_shipping_info_id_seq OWNED BY warehouse_shipping_info.id;

ALTER TABLE ONLY warehouse_shipping_info ALTER COLUMN id SET DEFAULT nextval('warehouse_shipping_info_id_seq'::regclass);

ALTER TABLE ONLY warehouse_shipping_info
	ADD CONSTRAINT warehouse_shipping_info_pkey PRIMARY KEY (id);

ALTER TABLE ONLY warehouse_shipping_info
	ADD CONSTRAINT warehouse_shipping_info_warehouse_id_key UNIQUE (warehouse_id);

ALTER TABLE ONLY warehouse_shipping_info
	ADD CONSTRAINT warehouse_shipping_info_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES n_warehouses(id);
--

-- insert data into public.warehouse_shipping_info
INSERT INTO warehouse_shipping_info VALUES (1, 1, 'бул. Цариградско шосе', NULL, NULL, '-', NULL);
INSERT INTO warehouse_shipping_info VALUES (2, 2, 'бул. Цариградско шосе', NULL, NULL, '-', NULL);
INSERT INTO warehouse_shipping_info VALUES (3, 3, 'бул. Цариградско шосе', NULL, NULL, '-', NULL);
INSERT INTO warehouse_shipping_info VALUES (4, 4, 'Южна промишлена зона ул. Комлушка низина', 'Станимир Стоянов', '0879 663 861', '-', 'СИСКОМ ТРЕЙДИНГ ЕООД');
INSERT INTO warehouse_shipping_info VALUES (5, 5, 'ул. „Цани Калянджиев“  № 10', 'Стефан Ангелов', '0879 94 83 49', 'ул. ГЕН. ПАРЕНСОВ № 8', 'СИСКОМ ТРЕЙДИНГ ЕООД');
INSERT INTO warehouse_shipping_info VALUES (6, 6, 'ул. Ген.Леонов 26  офис 1', 'Стоян Иванов', '0879 94 83 52', 'ул. Кукленско Шосе № 15', 'СИСКОМ ТРЕЙДИНГ ЕООД');
INSERT INTO warehouse_shipping_info VALUES (7, 7, 'жк.Дружба 1 до бл.124', 'Сашо Иванов', '0879 66 54 12', 'бул.Христо Ботев 49', 'СИСКОМ ТРЕЙДИНГ ЕООД');
INSERT INTO warehouse_shipping_info VALUES (8, 8, 'жк.Южен ул. „Бугариево” № 24', 'Величко Вангелов', '0879 94 84 35', 'ул. КУКЛЕНСКО ШОСЕ № 15 ', 'СИСКОМ ТРЕЙДИНГ ЕООД');
INSERT INTO warehouse_shipping_info VALUES (9, 9, 'ул. Захари Княжевски 2', 'Димитър Държавов', '0879 948 359', '-', 'СИСКОМ ТРЕЙДИНГ ЕООД');
--

-- add warehouse_id column to public.s_dev_store and public.s_sim_store tables
ALTER TABLE public.s_dev_store
	ADD COLUMN warehouse_id integer;

COMMENT ON COLUMN public.s_dev_store.warehouse_id
	IS 'Склад';

ALTER TABLE ONLY public.s_dev_store
	ADD CONSTRAINT s_dev_store_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES n_warehouses(id);

ALTER TABLE public.s_sim_store
	ADD COLUMN warehouse_id integer;

COMMENT ON COLUMN public.s_sim_store.warehouse_id
	IS 'Склад';

ALTER TABLE ONLY public.s_sim_store
	ADD CONSTRAINT s_sim_store_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES n_warehouses(id);
--

-- create table public.n_device_statuses
CREATE TABLE public.n_device_statuses (
	id integer NOT NULL,
	name character varying(15) NOT NULL
);

ALTER TABLE public.n_device_statuses OWNER TO admin;
ALTER TABLE ONLY public.n_device_statuses
	ADD CONSTRAINT n_device_statuses_pkey PRIMARY KEY (id);
--

-- insert data into public.n_device_statuses
INSERT INTO n_device_statuses VALUES (1, 'new');
INSERT INTO n_device_statuses VALUES (2, 'available');
INSERT INTO n_device_statuses VALUES (3, 'scrapped');
INSERT INTO n_device_statuses VALUES (4, 'for_repair');
INSERT INTO n_device_statuses VALUES (5, 'stolen');
--

-- add status_id column to public.s_dev_store and public.s_sim_store tables
ALTER TABLE public.s_dev_store
	ADD COLUMN status_id integer;

COMMENT ON COLUMN public.s_dev_store.status_id
	IS 'status id';

ALTER TABLE ONLY public.s_dev_store
	ADD CONSTRAINT s_dev_store_status_id_fkey FOREIGN KEY (status_id) REFERENCES n_device_statuses(id);

ALTER TABLE public.s_sim_store
	ADD COLUMN status_id integer;

COMMENT ON COLUMN public.s_sim_store.status_id
	IS 'status id';

ALTER TABLE ONLY public.s_sim_store
	ADD CONSTRAINT s_sim_store_status_id_fkey FOREIGN KEY (status_id) REFERENCES n_device_statuses(id);
--

-- create public.device_scrap_reasons table
CREATE TABLE public.device_scrap_reasons (
	id SERIAL,
	description character varying(255) COLLATE pg_catalog."default" NOT NULL,
	CONSTRAINT device_scrap_reasons_pkey PRIMARY KEY (id)
);

ALTER TABLE public.device_scrap_reasons
	OWNER to admin;
--

-- add scrap reason id to public.s_dev_store table
ALTER TABLE public.s_dev_store
	ADD COLUMN scrap_reason_id integer;

COMMENT ON COLUMN public.s_dev_store.scrap_reason_id
	IS 'Device scrap reason id';

ALTER TABLE ONLY public.s_dev_store
	ADD CONSTRAINT s_dev_store_scrap_reason_id_fkey FOREIGN KEY (scrap_reason_id) REFERENCES public.device_scrap_reasons(id);
--

-- add scrap reason id to public.s_sim_store table
ALTER TABLE public.s_sim_store
	ADD COLUMN scrap_reason_id integer;

COMMENT ON COLUMN public.s_sim_store.scrap_reason_id
	IS 'Sim card scrap reason id';

ALTER TABLE ONLY public.s_sim_store
	ADD CONSTRAINT s_sim_store_scrap_reason_id_fkey FOREIGN KEY (scrap_reason_id) REFERENCES public.device_scrap_reasons(id);
--

-- create table public.hardware_device_transfer_bill_of_ladings
CREATE TABLE hardware_device_transfer_bill_of_ladings (
	id integer NOT NULL,
	warehouse_id integer NOT NULL,
	package_count integer NOT NULL,
	weight_kg numeric(14,2) NOT NULL,
	recipient_address character varying(255) NOT NULL,
	recipient_person_name character varying NOT NULL,
	recipient_person_phone character varying NOT NULL
);

ALTER TABLE public.hardware_device_transfer_bill_of_ladings OWNER TO admin;

ALTER TABLE ONLY hardware_device_transfer_bill_of_ladings
	ADD CONSTRAINT hardware_device_transfer_bill_of_lading_pkey PRIMARY KEY (id);

ALTER TABLE ONLY hardware_device_transfer_bill_of_ladings
	ADD CONSTRAINT hardware_device_transfer_bill_of_lading_id_fkey FOREIGN KEY (id) REFERENCES bill_of_ladings(id);

ALTER TABLE ONLY hardware_device_transfer_bill_of_ladings
	ADD CONSTRAINT hardware_device_transfer_bill_of_lading_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES n_warehouses(id);

-- create table public.hardware_device_transfer_protocols
CREATE TABLE public.hardware_device_transfer_protocols (
	id integer NOT NULL,
	bill_of_ladding_id integer NOT NULL,
	created_at timestamp without time zone NOT NULL
);

ALTER TABLE public.hardware_device_transfer_protocols OWNER TO admin;

CREATE SEQUENCE hardware_device_transfer_protocols_id_seq
	START WITH 1
	INCREMENT BY 1
	NO MINVALUE
	NO MAXVALUE
	CACHE 1;

ALTER TABLE public.hardware_device_transfer_protocols_id_seq OWNER TO admin;

ALTER SEQUENCE hardware_device_transfer_protocols_id_seq OWNED BY hardware_device_transfer_protocols.id;

ALTER TABLE ONLY hardware_device_transfer_protocols ALTER COLUMN id SET DEFAULT nextval('hardware_device_transfer_protocols_id_seq'::regclass);

ALTER TABLE ONLY hardware_device_transfer_protocols
	ADD CONSTRAINT hardware_device_transfer_protocols_pkey PRIMARY KEY (id);

ALTER TABLE ONLY hardware_device_transfer_protocols
	ADD CONSTRAINT hardware_device_transfer_protocols_bill_of_ladding_id_fkey FOREIGN KEY (bill_of_ladding_id) REFERENCES hardware_device_transfer_bill_of_ladings(id);
--

-- create table public.hardware_device_transfer_protocols_devices
CREATE TABLE public.hardware_device_transfer_protocols_devices (
	hardware_device_transfer_protocol_id integer NOT NULL,
	device_id integer NOT NULL
);

ALTER TABLE public.hardware_device_transfer_protocols_devices OWNER TO admin;

ALTER TABLE ONLY hardware_device_transfer_protocols_devices
	ADD CONSTRAINT hardware_device_transfer_protocols_devices_pkey PRIMARY KEY (hardware_device_transfer_protocol_id, device_id);

ALTER TABLE ONLY hardware_device_transfer_protocols_devices
	ADD CONSTRAINT hardware_device_transfer_prot_hardware_device_transfer_pro_fkey FOREIGN KEY (hardware_device_transfer_protocol_id) REFERENCES hardware_device_transfer_protocols(id);

ALTER TABLE ONLY hardware_device_transfer_protocols_devices
	ADD CONSTRAINT hardware_device_transfer_protocols_devices_device_id_fkey FOREIGN KEY (device_id) REFERENCES s_dev_store(id);
--

-- create table public.hardware_device_transfer_protocols_sim_cards
CREATE TABLE public.hardware_device_transfer_protocols_sim_cards (
	hardware_device_transfer_protocol_id integer NOT NULL,
	sim_card_id integer NOT NULL
);

ALTER TABLE public.hardware_device_transfer_protocols_sim_cards OWNER TO admin;

ALTER TABLE ONLY hardware_device_transfer_protocols_sim_cards
	ADD CONSTRAINT hardware_device_transfer_protocols_sim_cards_pkey PRIMARY KEY (hardware_device_transfer_protocol_id, sim_card_id);

ALTER TABLE ONLY hardware_device_transfer_protocols_sim_cards
	ADD CONSTRAINT hardware_device_transfer_pro_hardware_device_transfer_pro_fkey1 FOREIGN KEY (hardware_device_transfer_protocol_id) REFERENCES hardware_device_transfer_protocols(id);

ALTER TABLE ONLY hardware_device_transfer_protocols_sim_cards
	ADD CONSTRAINT hardware_device_transfer_protocols_sim_cards_sim_card_id_fkey FOREIGN KEY (sim_card_id) REFERENCES s_sim_store(id);
--

-- create table public.s_device_mac_addresses
CREATE TABLE public.s_device_mac_addresses (
	id integer NOT NULL,
	mac_address character varying(20) NOT NULL
);

ALTER TABLE public.s_device_mac_addresses OWNER TO admin;

ALTER TABLE ONLY s_device_mac_addresses
	ADD CONSTRAINT s_device_mac_addresses_pkey PRIMARY KEY (id);

ALTER TABLE ONLY s_device_mac_addresses
	ADD CONSTRAINT s_device_mac_addresses_id_fkey FOREIGN KEY (id) REFERENCES s_dev_store(id);
--

-- add is_sent_to_office column to public.bill_of_ladings
ALTER TABLE public.bill_of_ladings
	ADD COLUMN is_sent_to_office boolean NOT NULL DEFAULT false;
--

-- set warehouse_id to 2 for all devices that are not in inspection station
UPDATE public.s_dev_store SET warehouse_id = 2 WHERE (store_code = 'С' OR store_code = 'Р' OR store_code = 'О'); --TODO VERIFY old techinsp web compatibility
UPDATE public.s_sim_store SET warehouse_id = 2 WHERE (store_code = 'С' OR store_code = 'Р' OR store_code = 'О'); -- same as above

ALTER TABLE public.n_products
	ADD COLUMN has_small_box boolean NOT NULL DEFAULT false;

ALTER TABLE public.n_products
	ADD COLUMN single_unit_weight_offset double precision;

ALTER TABLE public.n_products
	ADD COLUMN has_intervals VARCHAR(1) DEFAULT 'N';
	COMMENT ON COLUMN public.n_products.has_intervals IS 'Съдържа ли интервали (Y/N)';


INSERT INTO n_application_types (code, description, is_valid) VALUES ('DXAN', 'Демакс админ', 'Y');

INSERT INTO s_variables VALUES ('DXAN', 'all', 'boxWeight', 'DOUBLE', '0.147', 'Y', '2018-03-07 15:07:18.309624', 'Weight of a box for inspection orders in kgs');
INSERT INTO s_variables VALUES ('DXAN', 'all', 'maxOrderWeightPercentOffset', 'DOUBLE', '1.7', 'y', '2018-06-19 12:51:22.823679', 'max offset percent for order weight to be valid');
INSERT INTO s_variables VALUES ('DXAN', 'all', 'smallBoxWeight', 'DOUBLE', '0.032', 'Y', '2018-06-18 16:13:21.591887', 'Weight in kgs of small box for holograms and such within the big order box.');

CREATE TABLE public.delivery_protocol (
		id SERIAL,
		creation_timestamp timestamp without time zone,
		bill_of_lading character varying(100),
		courier_name character varying(50)
	);
	COMMENT ON TABLE public.delivery_protocol IS 'Протоколи генерирани при предаването на поръчки за комплекти за технически преглед.';


ALTER TABLE ONLY public.delivery_protocol ALTER COLUMN id SET DEFAULT nextval('public.delivery_protocol_id_seq'::regclass);

ALTER TABLE ONLY public.delivery_protocol
	ADD CONSTRAINT delivery_protocol_pkey PRIMARY KEY (id);



INSERT INTO public.delivery_protocol SELECT DISTINCT(o.protocol_id) FROM public.orders o WHERE o.protocol_id IS NOT NULL;

ALTER TABLE public.orders
	ADD CONSTRAINT orders_delivery_protocol_id_fkey FOREIGN KEY (protocol_id) REFERENCES public.delivery_protocol(id);

SELECT setval('public.delivery_protocol_id_seq', (SELECT MAX(id) from public.delivery_protocol), true);

ALTER TABLE public.orders
	ADD COLUMN packaged_weight numeric(14,2);

ALTER TABLE public.order_items
	ADD COLUMN modified_by integer;

ALTER TABLE ONLY public.order_items
	ADD CONSTRAINT order_items_modified_by_fkey FOREIGN KEY (modified_by) REFERENCES security.users(user_id);

ALTER TABLE public.n_org_units
	ADD COLUMN phone_number character varying(30);

CREATE TABLE delivery_protocol_bill_of_ladings ( -- TODO rename to inspection_bill_of_ladings
		id int REFERENCES public.bill_of_ladings(id),
		destination_org_unit character varying(10) NOT NULL REFERENCES public.n_org_units(code),
		weight numeric(14,2) NOT NULL,
		package_count int NOT NULL,
		PRIMARY KEY (id)
	);

ALTER TABLE ONLY delivery_protocol DROP COLUMN IF EXISTS bill_of_lading; -- TODO Check why this is needed
ALTER TABLE ONLY delivery_protocol DROP COLUMN IF EXISTS courier_name; -- TODO check why this is needed
ALTER TABLE ONLY delivery_protocol ADD COLUMN bill_of_lading_id int;
ALTER TABLE ONLY delivery_protocol
		ADD CONSTRAINT fk_inspection_order_bill_of_ladings_bill_of_lading_id FOREIGN KEY (bill_of_lading_id) REFERENCES delivery_protocol_bill_of_ladings(id);

ALTER TABLE ONLY motor_exam_result.exam_orders DROP COLUMN IF EXISTS courier_name; --TODO check why the column is dropped
ALTER TABLE ONLY motor_exam_result.exam_orders ADD COLUMN bill_of_lading_id int;
ALTER TABLE ONLY motor_exam_result.exam_orders
		ADD CONSTRAINT fk_bill_of_ladings_bill_of_lading_id FOREIGN KEY (bill_of_lading_id) REFERENCES bill_of_ladings(id);

ALTER TABLE motor_exam_result.exam_order_items
	ADD COLUMN modified_by integer;

ALTER TABLE ONLY motor_exam_result.exam_order_items
	ADD CONSTRAINT exam_order_items_modified_by_fkey FOREIGN KEY (modified_by) REFERENCES security.users(user_id);

INSERT INTO public.bill_of_ladings (bill_of_lading_id_for_courier, courier_code, courier_service_type, created_at, status)
		SELECT DISTINCT ON (o.bill_of_lading) o.bill_of_lading, 'SPEEDY', 'STANDARD', o.order_datetime, 'SENT'
		FROM motor_exam_result.exam_orders o
		WHERE o.bill_of_lading IS NOT NULL AND o.bill_of_lading != '' ORDER BY o.bill_of_lading, o.order_datetime;

UPDATE motor_exam_result.exam_orders o SET bill_of_lading_id = --TODO check why this is needed again
		(SELECT id FROM public.bill_of_ladings b
		 WHERE b.bill_of_lading_id_for_courier = o.bill_of_lading);
	-- TODO drop column bill_of_lading if needed and not done (?)

UPDATE public.n_org_units SET phone_number = '088 68 86 203' WHERE code = 'РДАА01';
UPDATE public.n_org_units SET phone_number = '088 68 86 207' WHERE code = 'РДАА02';
UPDATE public.n_org_units SET phone_number = '088 68 86 208' WHERE code = 'РДАА03';
UPDATE public.n_org_units SET phone_number = '088 68 86 211' WHERE code = 'РДАА04';
UPDATE public.n_org_units SET phone_number = '088 68 86 215' WHERE code = 'РДАА05';
UPDATE public.n_org_units SET phone_number = '088 68 86 224' WHERE code = 'РДАА06';
UPDATE public.n_org_units SET phone_number = '088 68 86 260' WHERE code = 'РДАА07';
UPDATE public.n_org_units SET phone_number = '088 68 86 270' WHERE code = 'РДАА08';
UPDATE public.n_org_units SET phone_number = '088 68 86 272' WHERE code = 'РДАА09';
UPDATE public.n_org_units SET phone_number = '088 68 86 360' WHERE code = 'РДАА10';
UPDATE public.n_org_units SET phone_number = '088 78 87 009' WHERE code = 'РДАА11';
UPDATE public.n_org_units SET phone_number = '088 78 87 010' WHERE code = 'РДАА12';
UPDATE public.n_org_units SET phone_number = '088 78 87 011' WHERE code = 'РДАА13';
UPDATE public.n_org_units SET phone_number = '088 78 87 057' WHERE code = 'РДАА14';
UPDATE public.n_org_units SET phone_number = '088 78 87 060' WHERE code = 'РДАА15';
UPDATE public.n_org_units SET phone_number = '088 78 87 066' WHERE code = 'РДАА16';
UPDATE public.n_org_units SET phone_number = '088 99 55 562' WHERE code = 'РДАА17';
UPDATE public.n_org_units SET phone_number = '088 78 87 080' WHERE code = 'РДАА18';
UPDATE public.n_org_units SET phone_number = '088 78 87 701' WHERE code = 'РДАА19';
UPDATE public.n_org_units SET phone_number = '088 78 87 705' WHERE code = 'РДАА20';
UPDATE public.n_org_units SET phone_number = '088 78 87 712' WHERE code = 'РДАА21';
UPDATE public.n_org_units SET phone_number = '088 78 87 715' WHERE code = 'РДАА22';
UPDATE public.n_org_units SET phone_number = '088 78 87 727' WHERE code = 'РДАА23';
UPDATE public.n_org_units SET phone_number = '088 88 70 019' WHERE code = 'РДАА24';
UPDATE public.n_org_units SET phone_number = '088 88 70 020' WHERE code = 'РДАА25';
UPDATE public.n_org_units SET phone_number = '088 88 70 057' WHERE code = 'РДАА26';
UPDATE public.n_org_units SET phone_number = '088 88 59 743' WHERE code = 'РДАА27';

SET search_path = security, pg_catalog;

INSERT INTO authorities VALUES (nextval('seq_authority_id'::regclass), 'ROLE_ACCOUNTING', 0, 'Роля за счетоводството, създадена за системата demax-admin-backend.');
INSERT INTO authorities VALUES (nextval('seq_authority_id'::regclass), 'ROLE_CALL_CENTER', 0, 'Роля за кол центъра, създадена за приложението demax-admin-backend');
INSERT INTO authorities VALUES (nextval('seq_authority_id'::regclass), 'ROLE_PACKAGING_VOUCHERS', 0, 'Роля за пакетаторите на ваучери, създадена за приложението demax-admin-backend.');
INSERT INTO authorities VALUES (nextval('seq_authority_id'::regclass), 'ROLE_PACKAGING_INSPECTIONS', 0, 'Роля за пакетатори на комплекти за прегледи, създадена за приложението demax-admin-backend.');
INSERT INTO authorities VALUES (nextval('seq_authority_id'::regclass), 'ROLE_DEMAX_ADMIN_SUPERVISOR', 0, 'Роля за супервайзър в приложението Демакс Админ.');
INSERT INTO authorities VALUES (nextval('seq_authority_id'::regclass), 'ROLE_TECHINSP_IAAA', 0, 'Роля, обединяваща видеонаблюдение в цялата страна; търсене, справки, съмнителни прегледи и статистики на технически прегледи, както и преглед на протоколи в цялата страна.');

UPDATE public.n_products SET package_weight = '0', has_intervals = 'N',  has_small_box = 'FALSE' WHERE id = '908';
UPDATE public.n_products SET package_weight = '0.45', has_intervals = 'N',  has_small_box = 'FALSE' WHERE id = '907';
UPDATE public.n_products SET package_weight = NULL, has_intervals = 'N',  has_small_box = 'FALSE' WHERE id = '911';
UPDATE public.n_products SET package_weight = '0.754', has_intervals = 'Y',  has_small_box = 'TRUE' WHERE id = '905';
UPDATE public.n_products SET package_weight = '0.754', has_intervals = 'Y',  has_small_box = 'TRUE' WHERE id = '904';
UPDATE public.n_products SET package_weight = '0.754', has_intervals = 'Y',  has_small_box = 'TRUE' WHERE id = '903';
UPDATE public.n_products SET package_weight = '0.831', has_intervals = 'Y',  has_small_box = 'TRUE' WHERE id = '912';
UPDATE public.n_products SET package_weight = '0.45', has_intervals = 'N',  has_small_box = 'FALSE' WHERE id = '807';
UPDATE public.n_products SET package_weight = '0.463', has_intervals = 'N',  has_small_box = 'FALSE' WHERE id = '806';
UPDATE public.n_products SET package_weight = '0.463', has_intervals = 'N',  has_small_box = 'FALSE' WHERE id = '906';

CREATE TABLE public.courier_client_accounts (
	courier_code varchar REFERENCES public.n_couriers (code),
	username varchar,
	password varchar NOT NULL,
	client_id bigint,
	PRIMARY KEY(courier_code, username, client_id)
);


/* accounts production:
'SPEEDY', '993135', '2622887296'
'SPEEDY', '993134', '2732693756'
*/

/* accounts testing:
('ECONT', 'demo', 'demo'),
('SPEEDY', '999508', '8991356491');
*/

-- WARNING! CHECK PARAMETERS BEFORE EXECUTING
-- TODO verify parameters before production execution
INSERT INTO public.courier_client_accounts VALUES
	('ECONT', 'demo', 'demo', 0),
	('SPEEDY', '999508', '8991356491', 88888888888000);

CREATE TABLE public.users_courier_accounts (
	user_id integer REFERENCES security.users (user_id),
	courier_code varchar,
	courier_username varchar NOT NULL,
	courier_client_id bigint NOT NULL
);

CREATE OR REPLACE FUNCTION public.insert_courier_accounts(role_name varchar, usernames varchar[], client_ids bigint[]) RETURNS void AS $$

BEGIN

INSERT INTO public.users_courier_accounts (user_id, courier_code, courier_username, courier_client_id)

SELECT users.user_id, couriers.courier_code, couriers.username as courier_username, couriers.client_id as courier_client_id
FROM security.users users, public.courier_client_accounts couriers
WHERE users.user_id IN (
	SELECT user_id
	FROM users_authorities
	WHERE authority_id IN (
		SELECT authority_id
		FROM authorities
		WHERE authority_name = $1
	)
)
AND couriers.courier_code = ANY(ARRAY['SPEEDY', 'ECONT'])
AND couriers.username = ANY($2)
AND couriers.client_id = ANY($3);

END
$$ LANGUAGE plpgsql;

/* production:
SPEEDY - 993135 client ids:
175206054002 - гр. СОФИЯ кв. ГОРУБЛЯНЕ ул. АБАГАР No 16
175206054003 - гр. СОФИЯ бул. ЦАРИГРАДСКО ШОСЕ No 117

SPEEDY - 993134 client ids:
831453003000 - гр. СОФИЯ кв. ГОРУБЛЯНЕ ул. АБАГАР No 16
831453003002 - гр. СОФИЯ бул. ЦАРИГРАДСКО ШОСЕ No 117
*/

--WARNING! CHECK PARAMETERS BEFORE EXECUTING
SELECT public.insert_courier_accounts('ROLE_CALL_CENTER', ARRAY['999508', 'demo'], ARRAY[88888888888000, 0]);
SELECT public.insert_courier_accounts('ROLE_PACKAGING_VOUCHERS', ARRAY['999508', 'demo'], ARRAY[88888888888000, 0]);
SELECT public.insert_courier_accounts('ROLE_PACKAGING_INSPECTIONS', ARRAY['999508', 'demo'], ARRAY[88888888888000, 0]);
SELECT public.insert_courier_accounts('ROLE_DEMAX_ADMIN_SUPERVISOR', ARRAY['999508', 'demo'], ARRAY[88888888888000, 0]);
SELECT public.insert_courier_accounts('ROLE_ADMIN', ARRAY['999508', 'demo'], ARRAY[88888888888000, 0]);

DROP FUNCTION IF EXISTS public.insert_courier_accounts;

ALTER TABLE public.users_courier_accounts
	ADD CONSTRAINT fk FOREIGN KEY (courier_code, courier_username, courier_client_id) REFERENCES public.courier_client_accounts (courier_code, username, client_id),
	ADD CONSTRAINT pk PRIMARY KEY (user_id, courier_code);

ALTER TABLE public.bill_of_ladings
    ADD COLUMN delivery_time time without time zone
	
COMMIT;
