BEGIN;

-- update status new
UPDATE public.s_dev_store SET status_id = 1 WHERE status = 'N';
UPDATE public.s_sim_store SET status_id = 1 WHERE status = 'N';

-- update status available
UPDATE public.s_dev_store SET status_id = 2 WHERE status = 'FC' OR status = 'R';
UPDATE public.s_sim_store SET status_id = 2 WHERE status = 'FC' OR status = 'R';

-- update status scrapped
UPDATE public.s_dev_store SET status_id = 3 WHERE status = 'S';
UPDATE public.s_sim_store SET status_id = 3 WHERE status = 'S';

-- update status scrapped
UPDATE public.s_dev_store SET status_id = 4 WHERE status = 'FR';
UPDATE public.s_sim_store SET status_id = 4 WHERE status = 'FR';

-- update status scrapped
UPDATE public.s_dev_store SET status_id = 5 WHERE status = 'ST';
UPDATE public.s_sim_store SET status_id = 5 WHERE status = 'ST';

COMMIT;