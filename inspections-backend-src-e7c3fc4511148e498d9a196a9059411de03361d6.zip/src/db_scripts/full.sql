BEGIN;

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, techinsp, security, pg_catalog;
SET default_tablespace = '';
SET default_with_oids = false;


CREATE TABLE n_couriers (
		code character varying(6) NOT NULL PRIMARY KEY,
		name character varying(64) NOT NULL
	);

INSERT INTO n_couriers (code, name) VALUES ('SPEEDY', 'Спиди'),
						   ('ECONT', 'Еконт'), ('DEMAX', 'Доставка от страна на Демакс');

CREATE TABLE n_courier_service_types (
		code character varying(10) NOT NULL PRIMARY KEY,
		name character varying(64) NOT NULL
	);

INSERT INTO n_courier_service_types (code, name) VALUES ('STANDARD', 'Стандартна'),
						   ('EXPRESS', 'Експресна');

CREATE TABLE n_bill_of_lading_statuses (
		code character varying(10) NOT NULL PRIMARY KEY,
		name character varying(64) NOT NULL
	);

INSERT INTO n_bill_of_lading_statuses (code, name) VALUES ('REQUESTED', 'празна'),
		('NOT_SENT', 'неизпратена'),
		('EXPIRED', 'изтекла'),
		('SENT', 'изпратена'),
		('CANCELED', 'Отказана');


CREATE TABLE bill_of_ladings (
		id SERIAL NOT NULL,
		bill_of_lading_id_for_courier character varying(30) NOT NULL,
		courier_code character varying(6) NOT NULL REFERENCES public.n_couriers(code),
		courier_service_type character varying(10) NOT NULL REFERENCES public.n_courier_service_types(code),
		created_at timestamp without time zone,
		status character varying(10) NOT NULL  REFERENCES public.n_bill_of_lading_statuses(code),
		request_user int REFERENCES security.users(user_id),
		CONSTRAINT bill_of_lading_id_for_courier_courier_code UNIQUE(bill_of_lading_id_for_courier, courier_code),
		PRIMARY KEY (id)
	);


-- create table public.n_warehouses
CREATE TABLE public.n_warehouses (
	id integer NOT NULL,
	name character varying(40) NOT NULL,
	city_code character varying(5) NOT NULL
);

ALTER TABLE public.n_warehouses OWNER TO admin;

ALTER TABLE ONLY n_warehouses
	ADD CONSTRAINT n_warehouses_pkey PRIMARY KEY (id);

ALTER TABLE ONLY n_warehouses
	ADD CONSTRAINT n_warehouses_city_code_fkey FOREIGN KEY (city_code) REFERENCES n_cities(code);
--

-- insert data in table public.n_warehouses
INSERT INTO n_warehouses VALUES (1, 'София Кремиковци', '68134');
INSERT INTO n_warehouses VALUES (2, 'София Цариградско шосе голям склад', '68134');
INSERT INTO n_warehouses VALUES (3, 'София Цариградско шосе малък склад', '68134');
INSERT INTO n_warehouses VALUES (4, 'Бургас', '07079');
INSERT INTO n_warehouses VALUES (5, 'Варна', '10135');
INSERT INTO n_warehouses VALUES (6, 'Враца', '12259');
INSERT INTO n_warehouses VALUES (7, 'Плевен', '56722');
INSERT INTO n_warehouses VALUES (8, 'Пловдив', '56784');
INSERT INTO n_warehouses VALUES (9, 'Стара Загора', '68850');
--

-- create table public.warehouse_shipping_info
CREATE TABLE public.warehouse_shipping_info (
	id integer NOT NULL,
	warehouse_id integer NOT NULL,
	address character varying(255) NOT NULL,
	recipient_person_name character varying(255),
	recipient_person_phone character varying(20),
	speedy_office_address character varying(255) NOT NULL,
	company_name character varying(50)
);

ALTER TABLE public.warehouse_shipping_info OWNER TO admin;

CREATE SEQUENCE warehouse_shipping_info_id_seq
	START WITH 1
	INCREMENT BY 1
	NO MINVALUE
	NO MAXVALUE
	CACHE 1;

ALTER TABLE public.warehouse_shipping_info_id_seq OWNER TO admin;

ALTER SEQUENCE warehouse_shipping_info_id_seq OWNED BY warehouse_shipping_info.id;

ALTER TABLE ONLY warehouse_shipping_info ALTER COLUMN id SET DEFAULT nextval('warehouse_shipping_info_id_seq'::regclass);

ALTER TABLE ONLY warehouse_shipping_info
	ADD CONSTRAINT warehouse_shipping_info_pkey PRIMARY KEY (id);

ALTER TABLE ONLY warehouse_shipping_info
	ADD CONSTRAINT warehouse_shipping_info_warehouse_id_key UNIQUE (warehouse_id);

ALTER TABLE ONLY warehouse_shipping_info
	ADD CONSTRAINT warehouse_shipping_info_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES n_warehouses(id);
--

-- insert data into public.warehouse_shipping_info
INSERT INTO warehouse_shipping_info VALUES (1, 1, 'бул. Цариградско шосе', NULL, NULL, '-', NULL);
INSERT INTO warehouse_shipping_info VALUES (2, 2, 'бул. Цариградско шосе', NULL, NULL, '-', NULL);
INSERT INTO warehouse_shipping_info VALUES (3, 3, 'бул. Цариградско шосе', NULL, NULL, '-', NULL);
INSERT INTO warehouse_shipping_info VALUES (4, 4, 'Южна промишлена зона ул. Комлушка низина', 'Станимир Стоянов', '0879 663 861', '-', 'СИСКОМ ТРЕЙДИНГ ЕООД');
INSERT INTO warehouse_shipping_info VALUES (5, 5, 'ул. „Цани Калянджиев“  № 10', 'Стефан Ангелов', '0879 94 83 49', 'ул. ГЕН. ПАРЕНСОВ № 8', 'СИСКОМ ТРЕЙДИНГ ЕООД');
INSERT INTO warehouse_shipping_info VALUES (6, 6, 'ул. Ген.Леонов 26  офис 1', 'Стоян Иванов', '0879 94 83 52', 'ул. Кукленско Шосе № 15', 'СИСКОМ ТРЕЙДИНГ ЕООД');
INSERT INTO warehouse_shipping_info VALUES (7, 7, 'жк.Дружба 1 до бл.124', 'Сашо Иванов', '0879 66 54 12', 'бул.Христо Ботев 49', 'СИСКОМ ТРЕЙДИНГ ЕООД');
INSERT INTO warehouse_shipping_info VALUES (8, 8, 'жк.Южен ул. „Бугариево” № 24', 'Величко Вангелов', '0879 94 84 35', 'ул. КУКЛЕНСКО ШОСЕ № 15 ', 'СИСКОМ ТРЕЙДИНГ ЕООД');
INSERT INTO warehouse_shipping_info VALUES (9, 9, 'ул. Захари Княжевски 2', 'Димитър Държавов', '0879 948 359', '-', 'СИСКОМ ТРЕЙДИНГ ЕООД');
--

-- add warehouse_id column to public.s_dev_store and public.s_sim_store tables
ALTER TABLE public.s_dev_store
	ADD COLUMN warehouse_id integer;

COMMENT ON COLUMN public.s_dev_store.warehouse_id
	IS 'Склад';

ALTER TABLE ONLY public.s_dev_store
	ADD CONSTRAINT s_dev_store_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES n_warehouses(id);

ALTER TABLE public.s_sim_store
	ADD COLUMN warehouse_id integer;

COMMENT ON COLUMN public.s_sim_store.warehouse_id
	IS 'Склад';

ALTER TABLE ONLY public.s_sim_store
	ADD CONSTRAINT s_sim_store_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES n_warehouses(id);
--

-- create table public.n_device_statuses
CREATE TABLE public.n_device_statuses (
	id integer NOT NULL,
	name character varying(15) NOT NULL
);

ALTER TABLE public.n_device_statuses OWNER TO admin;
ALTER TABLE ONLY public.n_device_statuses
	ADD CONSTRAINT n_device_statuses_pkey PRIMARY KEY (id);
--

-- insert data into public.n_device_statuses
INSERT INTO n_device_statuses VALUES (1, 'new');
INSERT INTO n_device_statuses VALUES (2, 'available');
INSERT INTO n_device_statuses VALUES (3, 'scrapped');
INSERT INTO n_device_statuses VALUES (4, 'for_repair');
INSERT INTO n_device_statuses VALUES (5, 'stolen');
--

-- add status_id column to public.s_dev_store and public.s_sim_store tables
ALTER TABLE public.s_dev_store
	ADD COLUMN status_id integer;

COMMENT ON COLUMN public.s_dev_store.status_id
	IS 'status id';

ALTER TABLE ONLY public.s_dev_store
	ADD CONSTRAINT s_dev_store_status_id_fkey FOREIGN KEY (status_id) REFERENCES n_device_statuses(id);

ALTER TABLE public.s_sim_store
	ADD COLUMN status_id integer;

COMMENT ON COLUMN public.s_sim_store.status_id
	IS 'status id';

ALTER TABLE ONLY public.s_sim_store
	ADD CONSTRAINT s_sim_store_status_id_fkey FOREIGN KEY (status_id) REFERENCES n_device_statuses(id);
--

-- create public.device_scrap_reasons table
CREATE TABLE public.device_scrap_reasons (
	id SERIAL,
	description character varying(255) COLLATE pg_catalog."default" NOT NULL,
	CONSTRAINT device_scrap_reasons_pkey PRIMARY KEY (id)
);

ALTER TABLE public.device_scrap_reasons
	OWNER to admin;
--

-- add scrap reason id to public.s_dev_store table
ALTER TABLE public.s_dev_store
	ADD COLUMN scrap_reason_id integer;

COMMENT ON COLUMN public.s_dev_store.scrap_reason_id
	IS 'Device scrap reason id';

ALTER TABLE ONLY public.s_dev_store
	ADD CONSTRAINT s_dev_store_scrap_reason_id_fkey FOREIGN KEY (scrap_reason_id) REFERENCES public.device_scrap_reasons(id);
--

-- add scrap reason id to public.s_sim_store table
ALTER TABLE public.s_sim_store
	ADD COLUMN scrap_reason_id integer;

COMMENT ON COLUMN public.s_sim_store.scrap_reason_id
	IS 'Sim card scrap reason id';

ALTER TABLE ONLY public.s_sim_store
	ADD CONSTRAINT s_sim_store_scrap_reason_id_fkey FOREIGN KEY (scrap_reason_id) REFERENCES public.device_scrap_reasons(id);
--

-- create table public.hardware_device_transfer_bill_of_ladings
CREATE TABLE hardware_device_transfer_bill_of_ladings (
	id integer NOT NULL,
	warehouse_id integer NOT NULL,
	package_count integer NOT NULL,
	weight_kg numeric(14,2) NOT NULL,
	recipient_address character varying(255) NOT NULL,
	recipient_person_name character varying NOT NULL,
	recipient_person_phone character varying NOT NULL
);

ALTER TABLE public.hardware_device_transfer_bill_of_ladings OWNER TO admin;

ALTER TABLE ONLY hardware_device_transfer_bill_of_ladings
	ADD CONSTRAINT hardware_device_transfer_bill_of_lading_pkey PRIMARY KEY (id);

ALTER TABLE ONLY hardware_device_transfer_bill_of_ladings
	ADD CONSTRAINT hardware_device_transfer_bill_of_lading_id_fkey FOREIGN KEY (id) REFERENCES bill_of_ladings(id);

ALTER TABLE ONLY hardware_device_transfer_bill_of_ladings
	ADD CONSTRAINT hardware_device_transfer_bill_of_lading_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES n_warehouses(id);

-- create table public.hardware_device_transfer_protocols
CREATE TABLE public.hardware_device_transfer_protocols (
	id integer NOT NULL,
	bill_of_ladding_id integer NOT NULL,
	created_at timestamp without time zone NOT NULL
);

ALTER TABLE public.hardware_device_transfer_protocols OWNER TO admin;

CREATE SEQUENCE hardware_device_transfer_protocols_id_seq
	START WITH 1
	INCREMENT BY 1
	NO MINVALUE
	NO MAXVALUE
	CACHE 1;

ALTER TABLE public.hardware_device_transfer_protocols_id_seq OWNER TO admin;

ALTER SEQUENCE hardware_device_transfer_protocols_id_seq OWNED BY hardware_device_transfer_protocols.id;

ALTER TABLE ONLY hardware_device_transfer_protocols ALTER COLUMN id SET DEFAULT nextval('hardware_device_transfer_protocols_id_seq'::regclass);

ALTER TABLE ONLY hardware_device_transfer_protocols
	ADD CONSTRAINT hardware_device_transfer_protocols_pkey PRIMARY KEY (id);

ALTER TABLE ONLY hardware_device_transfer_protocols
	ADD CONSTRAINT hardware_device_transfer_protocols_bill_of_ladding_id_fkey FOREIGN KEY (bill_of_ladding_id) REFERENCES hardware_device_transfer_bill_of_ladings(id);
--

-- create table public.hardware_device_transfer_protocols_devices
CREATE TABLE public.hardware_device_transfer_protocols_devices (
	hardware_device_transfer_protocol_id integer NOT NULL,
	device_id integer NOT NULL
);

ALTER TABLE public.hardware_device_transfer_protocols_devices OWNER TO admin;

ALTER TABLE ONLY hardware_device_transfer_protocols_devices
	ADD CONSTRAINT hardware_device_transfer_protocols_devices_pkey PRIMARY KEY (hardware_device_transfer_protocol_id, device_id);

ALTER TABLE ONLY hardware_device_transfer_protocols_devices
	ADD CONSTRAINT hardware_device_transfer_prot_hardware_device_transfer_pro_fkey FOREIGN KEY (hardware_device_transfer_protocol_id) REFERENCES hardware_device_transfer_protocols(id);

ALTER TABLE ONLY hardware_device_transfer_protocols_devices
	ADD CONSTRAINT hardware_device_transfer_protocols_devices_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.s_dev_store(id);
--

-- create table public.hardware_device_transfer_protocols_sim_cards
CREATE TABLE public.hardware_device_transfer_protocols_sim_cards (
	hardware_device_transfer_protocol_id integer NOT NULL,
	sim_card_id integer NOT NULL
);

ALTER TABLE public.hardware_device_transfer_protocols_sim_cards OWNER TO admin;

ALTER TABLE ONLY hardware_device_transfer_protocols_sim_cards
	ADD CONSTRAINT hardware_device_transfer_protocols_sim_cards_pkey PRIMARY KEY (hardware_device_transfer_protocol_id, sim_card_id);

ALTER TABLE ONLY hardware_device_transfer_protocols_sim_cards
	ADD CONSTRAINT hardware_device_transfer_pro_hardware_device_transfer_pro_fkey1 FOREIGN KEY (hardware_device_transfer_protocol_id) REFERENCES hardware_device_transfer_protocols(id);

ALTER TABLE ONLY hardware_device_transfer_protocols_sim_cards
	ADD CONSTRAINT hardware_device_transfer_protocols_sim_cards_sim_card_id_fkey FOREIGN KEY (sim_card_id) REFERENCES s_sim_store(id);
--

-- create table public.s_device_mac_addresses
CREATE TABLE public.s_device_mac_addresses (
	id integer NOT NULL,
	mac_address character varying(20) NOT NULL
);

ALTER TABLE public.s_device_mac_addresses OWNER TO demax_admin;

ALTER TABLE ONLY s_device_mac_addresses
	ADD CONSTRAINT s_device_mac_addresses_pkey PRIMARY KEY (id);

ALTER TABLE ONLY s_device_mac_addresses
	ADD CONSTRAINT s_device_mac_addresses_id_fkey FOREIGN KEY (id) REFERENCES public.s_dev_store(id);
--

-- add is_sent_to_office column to public.bill_of_ladings
ALTER TABLE public.bill_of_ladings
	ADD COLUMN is_sent_to_office boolean NOT NULL DEFAULT false;
--

ALTER TABLE public.n_products
	ADD COLUMN has_small_box boolean NOT NULL DEFAULT false;


ALTER TABLE public.n_products
	ADD COLUMN has_intervals VARCHAR(1) DEFAULT 'N';
	COMMENT ON COLUMN public.n_products.has_intervals IS 'Съдържа ли интервали (Y/N)';


INSERT INTO n_application_types (code, description, is_valid) VALUES ('DXAN', 'Демакс админ', 'Y');

INSERT INTO s_variables VALUES ('DXAN', 'all', 'boxWeight', 'DOUBLE', '0.147', 'Y', '2018-03-07 15:07:18.309624', 'Weight of a box for inspection orders in kgs');
INSERT INTO s_variables VALUES ('DXAN', 'all', 'maxOrderWeightPercentOffset', 'DOUBLE', '1.7', 'y', '2018-06-19 12:51:22.823679', 'max offset percent for order weight to be valid');
INSERT INTO s_variables VALUES ('DXAN', 'all', 'smallBoxWeight', 'DOUBLE', '0.032', 'Y', '2018-06-18 16:13:21.591887', 'Weight in kgs of small box for holograms and such within the big order box.');
INSERT INTO s_variables VALUES ('DXAN', 'all', 'maxMessageAttachmentSizeKBVarKey', 'INTEGER', '2048', 'Y', '2018-10-29 10:30:00', 'Maximum size of message attachment in KB.');

CREATE TABLE delivery_protocol_bill_of_ladings ( 
		id int REFERENCES public.bill_of_ladings(id),
		destination_org_unit character varying(10) NOT NULL REFERENCES public.n_org_units(code),
		weight numeric(14,2) NOT NULL,
		package_count int NOT NULL,
		PRIMARY KEY (id)
	);

CREATE TABLE public.delivery_protocol (
		id SERIAL,
		creation_timestamp timestamp without time zone,
		bill_of_lading_id int
	);
	COMMENT ON TABLE public.delivery_protocol IS 'Протоколи генерирани при предаването на поръчки за комплекти за технически преглед.';

ALTER TABLE ONLY public.delivery_protocol ALTER COLUMN id SET DEFAULT nextval('public.delivery_protocol_id_seq'::regclass);

ALTER TABLE ONLY public.delivery_protocol
	ADD CONSTRAINT delivery_protocol_pkey PRIMARY KEY (id);

ALTER TABLE ONLY delivery_protocol
		ADD CONSTRAINT fk_inspection_order_bill_of_ladings_bill_of_lading_id FOREIGN KEY (bill_of_lading_id) REFERENCES delivery_protocol_bill_of_ladings(id);

INSERT INTO public.delivery_protocol SELECT DISTINCT(o.protocol_id) FROM public.orders o WHERE o.protocol_id IS NOT NULL;

ALTER TABLE public.orders
	ADD CONSTRAINT orders_delivery_protocol_id_fkey FOREIGN KEY (protocol_id) REFERENCES public.delivery_protocol(id);

SELECT setval('public.delivery_protocol_id_seq', (SELECT MAX(id) from public.delivery_protocol), true);

ALTER TABLE public.orders
	ADD COLUMN packaged_weight numeric(14,2);

ALTER TABLE public.order_items
	ADD COLUMN modified_by integer;

ALTER TABLE ONLY public.order_items
	ADD CONSTRAINT order_items_modified_by_fkey FOREIGN KEY (modified_by) REFERENCES security.users(user_id);

ALTER TABLE public.n_org_units
	ADD COLUMN phone_number character varying(30);



ALTER TABLE ONLY motor_exam_result.exam_orders ADD COLUMN bill_of_lading_id int;
ALTER TABLE ONLY motor_exam_result.exam_orders
		ADD CONSTRAINT fk_bill_of_ladings_bill_of_lading_id FOREIGN KEY (bill_of_lading_id) REFERENCES bill_of_ladings(id);

ALTER TABLE motor_exam_result.exam_order_items
	ADD COLUMN modified_by integer;

ALTER TABLE ONLY motor_exam_result.exam_order_items
	ADD CONSTRAINT exam_order_items_modified_by_fkey FOREIGN KEY (modified_by) REFERENCES security.users(user_id);

INSERT INTO public.bill_of_ladings (bill_of_lading_id_for_courier, courier_code, courier_service_type, created_at, status)
		SELECT DISTINCT ON (o.bill_of_lading) o.bill_of_lading, 'SPEEDY', 'STANDARD', o.order_datetime, 'SENT'
		FROM motor_exam_result.exam_orders o
		WHERE o.bill_of_lading IS NOT NULL AND o.bill_of_lading != '' ORDER BY o.bill_of_lading, o.order_datetime;

UPDATE motor_exam_result.exam_orders o SET bill_of_lading_id = 
		(SELECT id FROM public.bill_of_ladings b
		 WHERE b.bill_of_lading_id_for_courier = o.bill_of_lading);

ALTER TABLE ONLY motor_exam_result.exam_orders DROP COLUMN IF EXISTS bill_of_lading; 
		 
UPDATE public.n_org_units SET phone_number = '088 68 86 203' WHERE code = 'РДАА01';
UPDATE public.n_org_units SET phone_number = '088 68 86 207' WHERE code = 'РДАА02';
UPDATE public.n_org_units SET phone_number = '088 68 86 208' WHERE code = 'РДАА03';
UPDATE public.n_org_units SET phone_number = '088 68 86 211' WHERE code = 'РДАА04';
UPDATE public.n_org_units SET phone_number = '088 68 86 215' WHERE code = 'РДАА05';
UPDATE public.n_org_units SET phone_number = '088 68 86 224' WHERE code = 'РДАА06';
UPDATE public.n_org_units SET phone_number = '088 68 86 260' WHERE code = 'РДАА07';
UPDATE public.n_org_units SET phone_number = '088 68 86 270' WHERE code = 'РДАА08';
UPDATE public.n_org_units SET phone_number = '088 68 86 272' WHERE code = 'РДАА09';
UPDATE public.n_org_units SET phone_number = '088 68 86 360' WHERE code = 'РДАА10';
UPDATE public.n_org_units SET phone_number = '088 78 87 009' WHERE code = 'РДАА11';
UPDATE public.n_org_units SET phone_number = '088 78 87 010' WHERE code = 'РДАА12';
UPDATE public.n_org_units SET phone_number = '088 78 87 011' WHERE code = 'РДАА13';
UPDATE public.n_org_units SET phone_number = '088 78 87 057' WHERE code = 'РДАА14';
UPDATE public.n_org_units SET phone_number = '088 78 87 060' WHERE code = 'РДАА15';
UPDATE public.n_org_units SET phone_number = '088 78 87 066' WHERE code = 'РДАА16';
UPDATE public.n_org_units SET phone_number = '088 99 55 562' WHERE code = 'РДАА17';
UPDATE public.n_org_units SET phone_number = '088 78 87 080' WHERE code = 'РДАА18';
UPDATE public.n_org_units SET phone_number = '088 78 87 701' WHERE code = 'РДАА19';
UPDATE public.n_org_units SET phone_number = '088 78 87 705' WHERE code = 'РДАА20';
UPDATE public.n_org_units SET phone_number = '088 78 87 712' WHERE code = 'РДАА21';
UPDATE public.n_org_units SET phone_number = '088 78 87 715' WHERE code = 'РДАА22';
UPDATE public.n_org_units SET phone_number = '088 78 87 727' WHERE code = 'РДАА23';
UPDATE public.n_org_units SET phone_number = '088 88 70 019' WHERE code = 'РДАА24';
UPDATE public.n_org_units SET phone_number = '088 88 70 020' WHERE code = 'РДАА25';
UPDATE public.n_org_units SET phone_number = '088 88 70 057' WHERE code = 'РДАА26';
UPDATE public.n_org_units SET phone_number = '088 88 59 743' WHERE code = 'РДАА27';

-- create public.n_printer_consumable_statuses table
CREATE TABLE public.n_printer_consumable_statuses (
    code character varying(15) NOT NULL,
    description character varying(32) NOT NULL,
    CONSTRAINT n_printer_consumable_statuses_pkey PRIMARY KEY (code)
);

ALTER TABLE public.n_printer_consumable_statuses OWNER TO demax_admin;

    
-- insert data into public.n_printer_consumable_statuses
INSERT INTO public.n_printer_consumable_statuses VALUES ('SENT', 'sent');
INSERT INTO public.n_printer_consumable_statuses VALUES ('INSTALLED', 'installed');
INSERT INTO public.n_printer_consumable_statuses VALUES ('REPORTED', 'reported');
INSERT INTO public.n_printer_consumable_statuses VALUES ('RETURNED', 'returned');
--

-- create public.n_printer_consumable_types table
CREATE TABLE public.n_printer_consumable_types (
    code character varying(15) NOT NULL,
    description character varying(32) NOT NULL,
    CONSTRAINT n_printer_consumable_types_pkey PRIMARY KEY (code)
);

ALTER TABLE public.n_printer_consumable_types OWNER TO demax_admin;


-- insert data into public.n_printer_consumable_types
INSERT INTO public.n_printer_consumable_types VALUES ('CARTRIDGE', 'Тонер касета');
INSERT INTO public.n_printer_consumable_types VALUES ('DRUM', 'Барабан');   
    

-- create public.n_printer_consumable_report_statuses table
CREATE TABLE public.n_printer_consumable_report_statuses (
    code character varying(15) NOT NULL,
    description character varying(32) NOT NULL,
    CONSTRAINT n_printer_consumable_report_statuses_pkey PRIMARY KEY (code)
);

ALTER TABLE public.n_printer_consumable_report_statuses OWNER TO demax_admin;


-- insert data into public.n_printer_consumable_types
INSERT INTO public.n_printer_consumable_report_statuses VALUES ('REPORTED', 'Направен отчет');
INSERT INTO public.n_printer_consumable_report_statuses VALUES ('PAYMENT', 'Очаква плащане на листа');   
INSERT INTO public.n_printer_consumable_report_statuses VALUES ('PAYED', 'Платено');    

-- create public.printer_consumables table
CREATE TABLE public.printer_consumables (
    id SERIAL,
    sent_at timestamp without time zone,
    sent_to_permit_id integer,
    is_defective boolean DEFAULT false NOT NULL,
    returned_at date,
	returned_notes character varying(255),
	type_code character varying(15) NOT NULL,
	status_code character varying(15) NOT NULL,
    serial_number character varying(128),
    printer_id integer,
    percent_used integer,
    printed_pages integer,
    remaining_pages integer,
    first_installed_at timestamp without time zone,
    last_used_at timestamp without time zone,
    total_impressions integer,
    CONSTRAINT printer_consumables_pkey PRIMARY KEY (id),
    CONSTRAINT printer_consumable_serial_number_key UNIQUE (serial_number),
    CONSTRAINT printer_consumables_sent_to_permit_id_fkey FOREIGN KEY (sent_to_permit_id) REFERENCES techinsp.permits(id),
    CONSTRAINT printer_consumables_printer_id_fkey FOREIGN KEY (printer_id) REFERENCES public.s_dev_store(id),
    CONSTRAINT printer_consumables_status_code_fkey FOREIGN KEY (status_code) REFERENCES public.n_printer_consumable_statuses(code),
    CONSTRAINT printer_consumables_type_code_fkey FOREIGN KEY (type_code) REFERENCES n_printer_consumable_types(code)
);

ALTER TABLE public.printer_consumables OWNER TO demax_admin;


GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,UPDATE ON TABLE printer_consumables TO techinsp;
GRANT SELECT,UPDATE ON SEQUENCE printer_consumables_id_seq TO techinsp;


GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,UPDATE ON TABLE printer_consumables TO techinsp;
--

-- create public.printer_cartridge_reports table
CREATE TABLE public.printer_consumable_reports (
    id serial NOT NULL,
    consumable_id integer NOT NULL,
    permit_line_id integer NOT NULL,
    printed_pages integer NOT NULL,
    inspection_needed_pages integer NOT NULL,
    pages_for_payment integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    status_code character varying(15) NOT NULL,
    CONSTRAINT printer_consumable_reports_pkey PRIMARY KEY (id),
    CONSTRAINT printer_consumable_reports_consumable_id_fkey FOREIGN KEY (consumable_id) REFERENCES printer_consumables(id),
    CONSTRAINT printer_consumables_status_code_fkey FOREIGN KEY (status_code) REFERENCES n_printer_consumable_statuses(code),
    CONSTRAINT printer_consumable_reports_permit_line_id_fkey FOREIGN KEY (permit_line_id) REFERENCES techinsp.permit_lines(id)
    
);

ALTER TABLE public.printer_consumable_reports OWNER TO demax_admin;

-- Name: consumable_transfer_bill_of_ladings; Type: TABLE; Schema: public; Owner: admin;
CREATE TABLE consumable_transfer_bill_of_ladings (
    id serial NOT NULL,
    permit_id integer NOT NULL,
    package_count integer NOT NULL,
    weight_kg numeric(14,2) NOT NULL,
    recipient_address character varying(255) NOT NULL,
    recipient_person_name character varying NOT NULL,
    recipient_person_phone character varying NOT NULL,
    cartridges_count smallint,
    drums_count smallint,
    CONSTRAINT consumable_transfer_bill_of_lading_pkey PRIMARY KEY (id),
    CONSTRAINT consumable_transfer_bill_of_lading_id_fkey FOREIGN KEY (id) REFERENCES bill_of_ladings(id),
    CONSTRAINT consumable_transfer_bill_of_lading_permit_id_fkey FOREIGN KEY (permit_id) REFERENCES techinsp.permits(id)
);

ALTER TABLE public.consumable_transfer_bill_of_ladings OWNER TO demax_admin;

-- FUNCTION: public.add_pages_for_payment_to_order()

DROP TRIGGER add_pages_payment_to_order ON public.orders;

DROP FUNCTION public.add_pages_for_payment_to_order();

CREATE FUNCTION public.add_pages_for_payment_to_order()
    RETURNS trigger
    LANGUAGE 'plpgsql'
AS $BODY$
DECLARE
	l_reports record;
	l_permit_id numeric;
	l_issuer_id numeric;
BEGIN
	SELECT permit_id INTO l_permit_id 
	FROM permit_lines 
	WHERE id=NEW.permit_line_id;

	IF FOUND
	THEN 
		SELECT issuer_id INTO l_issuer_id 
		FROM n_products 
		WHERE id=908;

		IF l_issuer_id=NEW.issuer_id
		THEN
			FOR l_reports IN SELECT CR.id,  CR.pages_for_payment 
						FROM printer_consumable_reports CR
						LEFT JOIN permit_lines PL ON (CR.permit_line_id = PL.id)
						LEFT JOIN printer_consumables PC ON (CR.consumable_id = PC.id)
						WHERE PL.permit_id=l_permit_id AND CR.status_code='REPORTED' AND PC.type_code='CARTRIDGE'

			LOOP
				IF l_reports.pages_for_payment > 0
				THEN
					INSERT INTO order_items (order_id, product_id, quantity, from_num, to_num)
					VALUES (NEW.id, '908', l_reports.pages_for_payment, -1, -1);
				
					UPDATE printer_consumable_reports SET status='PAYED' WHERE id = l_reports.id;
				END IF;
			END LOOP;
		END IF;
	END IF;
	RETURN NULL;
END;
$BODY$;

CREATE TRIGGER add_pages_payment_to_order AFTER INSERT ON public.orders FOR EACH ROW EXECUTE PROCEDURE add_pages_for_payment_to_order();

ALTER FUNCTION public.add_pages_for_payment_to_order()
    OWNER TO techinsp;


UPDATE public.n_products SET package_weight = '0', has_intervals = 'N',  has_small_box = 'FALSE' WHERE id = '908';
UPDATE public.n_products SET package_weight = '0.45', has_intervals = 'N',  has_small_box = 'FALSE' WHERE id = '907';
UPDATE public.n_products SET package_weight = NULL, has_intervals = 'N',  has_small_box = 'FALSE' WHERE id = '911';
UPDATE public.n_products SET package_weight = '0.754', has_intervals = 'Y',  has_small_box = 'TRUE' WHERE id = '905';
UPDATE public.n_products SET package_weight = '0.754', has_intervals = 'Y',  has_small_box = 'TRUE' WHERE id = '904';
UPDATE public.n_products SET package_weight = '0.754', has_intervals = 'Y',  has_small_box = 'TRUE' WHERE id = '903';
UPDATE public.n_products SET package_weight = '0.831', has_intervals = 'Y',  has_small_box = 'TRUE' WHERE id = '912';
UPDATE public.n_products SET package_weight = '0.45', has_intervals = 'N',  has_small_box = 'FALSE' WHERE id = '807';
UPDATE public.n_products SET package_weight = '0.463', has_intervals = 'N',  has_small_box = 'FALSE' WHERE id = '806';
UPDATE public.n_products SET package_weight = '0.463', has_intervals = 'N',  has_small_box = 'FALSE' WHERE id = '906';

CREATE TABLE public.courier_client_accounts (
	courier_code varchar REFERENCES public.n_couriers (code),
	username varchar,
	password varchar NOT NULL,
	client_id bigint,
	PRIMARY KEY(courier_code, username, client_id)
);


CREATE TABLE public.users_courier_accounts (
	user_id integer REFERENCES security.users (user_id),
	courier_code varchar,
	courier_username varchar NOT NULL,
	courier_client_id bigint NOT NULL
);

ALTER TABLE public.users_courier_accounts
	ADD CONSTRAINT fk FOREIGN KEY (courier_code, courier_username, courier_client_id) REFERENCES public.courier_client_accounts (courier_code, username, client_id),
	ADD CONSTRAINT pk PRIMARY KEY (user_id, courier_code);

ALTER TABLE public.bill_of_ladings
    ADD COLUMN delivery_time time without time zone;
    
    
    
 -- ADD NEW PRINTER_CONSUMABLES
 
    
   
-- set warehouse_id to 2 for all devices that are not in inspection station
UPDATE public.s_dev_store SET warehouse_id = 2 WHERE (store_code = 'С' OR store_code = 'Р' OR store_code = 'О'); 
UPDATE public.s_sim_store SET warehouse_id = 2 WHERE (store_code = 'С' OR store_code = 'Р' OR store_code = 'О');  
    
 -- update status new
UPDATE public.s_dev_store SET status_id = 1 WHERE status = 'N';
UPDATE public.s_sim_store SET status_id = 1 WHERE status = 'N';

-- update status available
UPDATE public.s_dev_store SET status_id = 2 WHERE status = 'FC' OR status = 'R';
UPDATE public.s_sim_store SET status_id = 2 WHERE status = 'FC' OR status = 'R';

-- update status scrapped
UPDATE public.s_dev_store SET status_id = 3 WHERE status = 'S';
UPDATE public.s_sim_store SET status_id = 3 WHERE status = 'S';

-- update status scrapped
UPDATE public.s_dev_store SET status_id = 4 WHERE status = 'FR';
UPDATE public.s_sim_store SET status_id = 4 WHERE status = 'FR';

-- update status scrapped
UPDATE public.s_dev_store SET status_id = 5 WHERE status = 'ST';
UPDATE public.s_sim_store SET status_id = 5 WHERE status = 'ST';


-- message 2 script

CREATE TABLE public.n_message_recipient_types (
    code character varying(10) NOT NULL,
    PRIMARY KEY (code)
);

ALTER TABLE public.n_message_recipient_types
    OWNER to admin;

GRANT SELECT ON TABLE public.n_message_recipient_types TO demax_admin;

INSERT INTO public.n_message_recipient_types VALUES
('UNKNOWN'), ('ALL'), ('ORG_UNIT'), ('PERMIT');

ALTER TABLE public.messages
    ADD COLUMN recipient_type_code character varying(10) NULL;

ALTER TABLE public.messages
    ADD FOREIGN KEY (recipient_type_code)
    REFERENCES public.n_message_recipient_types (code) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION;

UPDATE public.messages SET recipient_type_code = 'UNKNOWN';

UPDATE public.messages SET recipient_type_code = 'ORG_UNIT'
WHERE id IN (
		SELECT DISTINCT m.id
		FROM public.messages m
		JOIN public.message_permits mp ON mp.message_id = m.id
		JOIN techinsp.permits p ON p.id = mp.permit_id
		GROUP BY m.id
		HAVING count(DISTINCT p.org_unit) = 1);

UPDATE public.messages SET recipient_type_code = 'ALL'
WHERE id IN ( 
		SELECT DISTINCT m.id
		FROM public.messages m
		JOIN public.message_permits mp ON mp.message_id = m.id
		JOIN techinsp.permits p ON p.id = mp.permit_id
		GROUP BY m.id
		HAVING count(DISTINCT p.org_unit) = 27 AND count(DISTINCT p.id) > 1);

UPDATE public.messages SET recipient_type_code = 'PERMIT'
WHERE id IN (
		SELECT DISTINCT m.id
		FROM public.messages m
		JOIN public.message_permits mp ON mp.message_id = m.id
		JOIN techinsp.permits p ON p.id = mp.permit_id
		GROUP BY m.id
		HAVING count(DISTINCT p.id) = 1);

ALTER TABLE public.messages ALTER COLUMN recipient_type_code SET NOT NULL;

GRANT ALL ON SEQUENCE public.messages_id_seq TO demax_admin;

-- ADD created ad column to public.messages
ALTER TABLE public.messages
	ADD COLUMN created_at timestamp without time zone NOT NULL DEFAULT now();

UPDATE public.messages SET created_at = now()
WHERE status = 'draft';

UPDATE public.messages SET created_at = date
WHERE date IS NOT NULL AND status = 'sent';

-- message attachments
CREATE TABLE public.message_attachments
(
    id serial NOT NULL,
    message_id integer NOT NULL,
    mime_type character varying(30) NOT NULL,
    filename character varying(256) NOT NULL,
    content bytea NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (message_id)
        REFERENCES public.messages (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

ALTER TABLE public.message_attachments
    OWNER to admin;

-- user permissions

INSERT INTO authorities VALUES (nextval('seq_authority_id'::regclass), 'ROLE_ACCOUNTING', 0, 'Роля за счетоводството, създадена за системата demax-admin-backend.');
INSERT INTO authorities VALUES (nextval('seq_authority_id'::regclass), 'ROLE_CALL_CENTER', 0, 'Роля за кол центъра, създадена за приложението demax-admin-backend');
INSERT INTO authorities VALUES (nextval('seq_authority_id'::regclass), 'ROLE_PACKAGING_VOUCHERS', 0, 'Роля за пакетаторите на ваучери, създадена за приложението demax-admin-backend.');
INSERT INTO authorities VALUES (nextval('seq_authority_id'::regclass), 'ROLE_PACKAGING_INSPECTIONS', 0, 'Роля за пакетатори на комплекти за прегледи, създадена за приложението demax-admin-backend.');
INSERT INTO authorities VALUES (nextval('seq_authority_id'::regclass), 'ROLE_DEMAX_ADMIN_SUPERVISOR', 0, 'Роля за супервайзър в приложението Демакс Админ.');
INSERT INTO authorities VALUES (nextval('seq_authority_id'::regclass), 'ROLE_TECHINSP_IAAA', 0, 'Роля, обединяваща видеонаблюдение в цялата страна; търсене, справки, съмнителни прегледи и статистики на технически прегледи, както и преглед на протоколи в цялата страна.');


--USERS - update r.chubanov missing password
UPDATE security.users SET password = 'f1a728e83ee4455fbb3f26969d19768f3183b4a3' where username = 'demax.r.chubanov';


--ROlES
--CALL_CENTER
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.l.cvetkov'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_CALL_CENTER'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.i.izatovski'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_CALL_CENTER'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.s.anakiev'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_CALL_CENTER'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.l.gurgov'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_CALL_CENTER'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.s.kostadinova'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_CALL_CENTER'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.e.ivanova'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_CALL_CENTER'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.m.galenkova'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_CALL_CENTER'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.z.mihailova'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_CALL_CENTER'));
--6th floor
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.r.chubanov'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_DEMAX_ADMIN_SUPERVISOR'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.a.metodieva'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_PACKAGING_VOUCHERS'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.d.kiradjieva'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_PACKAGING_VOUCHERS'));
--PACKAGING
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.a.shopova'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_PACKAGING_INSPECTIONS'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.s.shopov'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_PACKAGING_INSPECTIONS'));
--ACCOUNTING
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.d.bogateva'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_ACCOUNTING'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.s.djermanska'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_ACCOUNTING'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.e.sharova'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_ACCOUNTING'));
INSERT INTO users_authorities VALUES ((SELECT user_id FROM users WHERE username = 'demax.b.dimitrova'), (SELECT authority_id FROM authorities WHERE authority_name = 'ROLE_ACCOUNTING'));


/* accounts production:
'SPEEDY', '993135', '2622887296'
'SPEEDY', '993134', '2732693756'
*/

/* accounts testing:
('ECONT', 'demo', 'demo'),
('SPEEDY', '999508', '8991356491');
*/

-- WARNING! CHECK PARAMETERS BEFORE EXECUTING
INSERT INTO public.courier_client_accounts VALUES
	('ECONT', 'demo', 'demo', 0),
	('ECONT', 'demaxdpi', 'Zlatina2 ', 0),
	('ECONT', 'DemaxTrezor ', 'Stefan831453003', 0),
	('SPEEDY', '999508', '8991356491', 88888888888000),
	('SPEEDY', '993134', '2732693756', 831453003002), 
	('SPEEDY', '993135', '2622887296', 175206054003); 

CREATE OR REPLACE FUNCTION public.insert_courier_accounts(role_name varchar, usernames varchar[], client_ids bigint[]) RETURNS void AS $$

BEGIN

INSERT INTO public.users_courier_accounts (user_id, courier_code, courier_username, courier_client_id)

SELECT users.user_id, couriers.courier_code, couriers.username as courier_username, couriers.client_id as courier_client_id
FROM security.users users, public.courier_client_accounts couriers
WHERE users.user_id IN (
	SELECT user_id
	FROM users_authorities
	WHERE authority_id IN (
		SELECT authority_id
		FROM authorities
		WHERE authority_name = $1
	)
)
AND couriers.courier_code = ANY(ARRAY['SPEEDY', 'ECONT'])
AND couriers.username = ANY($2)
AND couriers.client_id = ANY($3);

END
$$ LANGUAGE plpgsql;

/* production:
SPEEDY - 993135 client ids:
175206054002 - гр. СОФИЯ кв. ГОРУБЛЯНЕ ул. АБАГАР No 16
175206054003 - гр. СОФИЯ бул. ЦАРИГРАДСКО ШОСЕ No 117

SPEEDY - 993134 client ids:
831453003000 - гр. СОФИЯ кв. ГОРУБЛЯНЕ ул. АБАГАР No 16
831453003002 - гр. СОФИЯ бул. ЦАРИГРАДСКО ШОСЕ No 117
*/

--WARNING! CHECK PARAMETERS BEFORE EXECUTING
SELECT public.insert_courier_accounts('ROLE_CALL_CENTER', ARRAY['999508', 'demo'], ARRAY[88888888888000, 0]);
SELECT public.insert_courier_accounts('ROLE_PACKAGING_VOUCHERS', ARRAY['993135', 'demaxdpi'], ARRAY[175206054003, 0]);
SELECT public.insert_courier_accounts('ROLE_PACKAGING_INSPECTIONS', ARRAY['993134', 'DemaxTrezor'], ARRAY[831453003002, 0]);
SELECT public.insert_courier_accounts('ROLE_DEMAX_ADMIN_SUPERVISOR', ARRAY['993134', 'DemaxTrezor'], ARRAY[831453003002, 0]);
SELECT public.insert_courier_accounts('ROLE_ADMIN', ARRAY['993134', 'DemaxTrezor'], ARRAY[831453003002, 0]);

DROP FUNCTION IF EXISTS public.insert_courier_accounts(varchar, varchar[], bigint[]);
    
GRANT USAGE ON SCHEMA "security" TO demax_admin;
GRANT USAGE ON SCHEMA techinsp TO demax_admin;
GRANT USAGE ON SCHEMA "motor_exam_result" TO demax_admin;
GRANT USAGE ON SCHEMA "motor_exam_permit" TO demax_admin;
GRANT USAGE ON SCHEMA "exams" TO demax_admin;
GRANT USAGE ON SCHEMA "vehicle_tax" TO demax_admin;	
	
GRANT SELECT ON TABLE public.n_cities TO demax_admin;
GRANT SELECT ON TABLE public.user_employee TO demax_admin;
GRANT SELECT ON TABLE public.employees TO demax_admin;
GRANT SELECT ON TABLE public.hardware_device_os_version TO demax_admin;
GRANT SELECT ON TABLE public.subj_versions TO demax_admin;
GRANT SELECT ON TABLE public.delivery_protocol_bill_of_ladings TO demax_admin;
GRANT SELECT ON TABLE public.n_regions TO demax_admin;
GRANT SELECT ON TABLE public.n_muns TO demax_admin;
GRANT SELECT ON TABLE public.n_products TO demax_admin;
GRANT SELECT ON TABLE public.n_countries TO demax_admin;
GRANT SELECT ON TABLE public.subjects TO demax_admin;
GRANT SELECT ON TABLE public.n_org_units TO demax_admin;
GRANT SELECT ON TABLE public.product_nums TO demax_admin;
GRANT SELECT ON TABLE public.subj_dictionary TO demax_admin ;
GRANT SELECT ON TABLE public.n_bill_of_lading_statuses TO demax_admin;
GRANT SELECT ON TABLE public.n_courier_service_types TO demax_admin;
GRANT SELECT ON TABLE public.n_couriers TO demax_admin ;
GRANT INSERT ON TABLE public.delivery_protocol_bill_of_ladings TO demax_admin;
GRANT SELECT ON TABLE public.consumable_transfer_bill_of_ladings TO demax_admin;
GRANT SELECT ON TABLE public.hardware_device_transfer_bill_of_ladings TO demax_admin;
GRANT SELECT ON TABLE public.n_warehouses TO demax_admin;
GRANT SELECT, UPDATE ON TABLE public.s_variables TO demax_admin;
GRANT SELECT ON TABLE public.n_application_types TO demax_admin;
GRANT SELECT ON TABLE public.s_event_log TO demax_admin;
GRANT INSERT ON TABLE public.s_event_log TO demax_admin;
GRANT SELECT ON TABLE public.n_order_status TO demax_admin;
GRANT SELECT ON TABLE public.order_issuers TO demax_admin;
GRANT SELECT ON TABLE public.n_product_order_quantities TO demax_admin;
GRANT SELECT ON TABLE public.s_installed_devs TO demax_admin;
GRANT SELECT ON TABLE public.s_installed_sims TO demax_admin;
GRANT SELECT, INSERT, UPDATE ON TABLE public.s_sim_logs TO demax_admin;
GRANT ALL ON TABLE public.s_dev_ips TO demax_admin;
GRANT SELECT, INSERT ON TABLE public.s_device_mac_addresses TO demax_admin;
GRANT SELECT ON TABLE public.n_devices TO demax_admin;
GRANT SELECT ON TABLE public.s_hardware TO demax_admin;
GRANT SELECT ON TABLE public.device_scrap_reasons TO demax_admin;
GRANT SELECT ON TABLE public.n_device_statuses TO demax_admin;
GRANT SELECT ON TABLE public.n_stores TO demax_admin;
GRANT SELECT ON TABLE public.user_subject TO demax_admin;
GRANT SELECT ON TABLE public.courier_client_accounts TO demax_admin;
GRANT SELECT ON TABLE public.s_active_hosts TO demax_admin;
GRANT SELECT ON TABLE public.users_courier_accounts TO demax_admin;
GRANT SELECT ON TABLE public.rvs TO demax_admin;
GRANT SELECT ON TABLE public.rvs_versions TO demax_admin;
GRANT SELECT, UPDATE ON TABLE public.warehouse_shipping_info TO demax_admin;
GRANT SELECT, UPDATE ON TABLE public.cam_requests TO demax_admin;
GRANT SELECT, INSERT ON TABLE public.delivery_protocol TO demax_admin;
GRANT SELECT, UPDATE ON TABLE public.orders TO demax_admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.s_sim_store TO demax_admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.hardware_device_transfer_protocols_sim_cards TO demax_admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.hardware_device_transfer_protocols TO demax_admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.hardware_device_transfer_protocols_devices TO demax_admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.s_dev_store TO demax_admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.order_items TO demax_admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.s_dev_logs TO demax_admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.s_installed_devs TO demax_admin;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.hardware_device_transfer_bill_of_ladings TO demax_admin;
GRANT SELECT, UPDATE, INSERT, DELETE ON TABLE public.bill_of_ladings TO demax_admin;
GRANT ALL ON TABLE public.n_vcategories TO demax_admin;
GRANT USAGE, SELECT ON SEQUENCE public.bill_of_ladings_id_seq TO demax_admin;
GRANT USAGE, SELECT ON SEQUENCE public.seq_s_dev_log_id TO demax_admin;
GRANT USAGE, SELECT ON SEQUENCE public.seq_s_sim_log_id TO demax_admin;
GRANT USAGE, SELECT ON SEQUENCE public.delivery_protocol_id_seq TO demax_admin;
GRANT USAGE, SELECT ON SEQUENCE public.seq_s_event_log_id TO demax_admin;
GRANT USAGE, SELECT ON SEQUENCE public.hardware_device_transfer_protocols_id_seq TO demax_admin;
GRANT USAGE, SELECT ON SEQUENCE public.messages_id_seq TO demax_admin;
GRANT USAGE ON SEQUENCE public.seq_order_items_id TO demax_admin;

GRANT SELECT, UPDATE ON printer_consumable_reports TO techinsp;    
GRANT ALL ON SEQUENCE public.seq_s_dev_store_id TO demax_admin;
GRANT ALL ON SEQUENCE public.seq_s_sim_store_id TO demax_admin;
GRANT ALL ON SEQUENCE security.user_modification_seq TO demax_admin;

GRANT SELECT, UPDATE ON TABLE security.users TO demax_admin;
GRANT SELECT ON TABLE security.users_authorities TO demax_admin;
GRANT SELECT ON TABLE security.authorities TO demax_admin;
GRANT SELECT ON TABLE motor_exam_result.exam_order_customer TO demax_admin;
GRANT SELECT ON TABLE motor_exam_result.n_exam_products TO demax_admin;
GRANT SELECT ON TABLE motor_exam_result.n_exam_order_status TO demax_admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE motor_exam_result.exam_order_items TO demax_admin;
GRANT SELECT, UPDATE ON TABLE motor_exam_result.exam_orders TO demax_admin;
GRANT SELECT ON TABLE motor_exam_permit.permits TO demax_admin;
GRANT USAGE ON SEQUENCE motor_exam_result.seq_exam_order_items_id TO demax_admin;

GRANT SELECT ON TABLE exams.vouchers TO demax_admin;
GRANT SELECT ON TABLE techinsp.permit_additional_info TO demax_admin;
GRANT SELECT ON TABLE techinsp.permits TO demax_admin;
GRANT SELECT ON TABLE techinsp.permit_inspectors TO demax_admin;
GRANT SELECT ON TABLE techinsp.permit_lines TO demax_admin;
GRANT SELECT ON TABLE techinsp.inspections TO demax_admin;
GRANT SELECT ON TABLE techinsp.cam_position TO demax_admin;
GRANT SELECT ON TABLE techinsp.n_insp_types TO demax_admin;;
GRANT SELECT ON TABLE techinsp.suspicious_inspections TO demax_admin;
GRANT SELECT ON TABLE techinsp.insp_values TO demax_admin;
GRANT SELECT ON TABLE techinsp.insp_checks TO demax_admin;
GRANT SELECT ON TABLE techinsp.n_insp_elements TO demax_admin;
GRANT SELECT ON TABLE techinsp.secondary_inspections TO demax_admin;
GRANT SELECT ON TABLE techinsp.n_secondary_inspection_reasons TO demax_admin;
GRANT SELECT ON TABLE techinsp.n_inspection_protocols TO demax_admin;
GRANT SELECT ON TABLE techinsp.n_protocol_types TO demax_admin;
GRANT SELECT ON TABLE techinsp.gas_systems TO demax_admin;
GRANT SELECT ON TABLE techinsp.n_gas_fuel_types TO demax_admin;
GRANT SELECT ON TABLE techinsp.insp_adr_protocols TO demax_admin;
GRANT SELECT ON TABLE techinsp.insp_cistern_protocols TO demax_admin;
GRANT SELECT ON TABLE techinsp.cisterns TO demax_admin;
GRANT SELECT ON TABLE techinsp.n_cistern_special_features TO demax_admin;
GRANT SELECT ON TABLE techinsp.n_dc_rvs_descriptions TO demax_admin;
GRANT USAGE ON SCHEMA vehicle_tax TO demax_admin;
GRANT SELECT ON TABLE vehicle_tax.checks TO demax_admin;
GRANT SELECT ON TABLE vehicle_tax.check_results TO demax_admin;
GRANT SELECT ON TABLE vehicle_tax.ministry_of_finance_errors TO demax_admin;
GRANT SELECT ON TABLE vehicle_tax.ministry_of_finance_responses TO demax_admin;
GRANT SELECT ON TABLE vehicle_tax.municipality_errors TO demax_admin; 
GRANT SELECT ON TABLE vehicle_tax.municipality_responses TO demax_admin;
GRANT SELECT ON TABLE vehicle_tax.n_ministry_of_finance_response_types TO demax_admin;
GRANT SELECT ON TABLE vehicle_tax.n_municipality_response_types TO demax_admin;
GRANT SELECT ON TABLE vehicle_tax.n_ministry_of_finance_error_types TO demax_admin;
GRANT SELECT ON TABLE vehicle_tax.mun_tax_extensions TO demax_admin;	

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.message_attachments TO demax_admin;
GRANT SELECT ON TABLE public.message_attachments TO techinsp;
GRANT ALL ON SEQUENCE public.message_attachments_id_seq TO demax_admin;

GRANT ALL ON TABLE techinsp.video_downloads TO demax_admin;
GRANT ALL ON TABLE techinsp.video_download_requests TO demax_admin;
GRANT ALL ON TABLE techinsp.video_download_request_status TO demax_admin;
GRANT USAGE, SELECT ON SEQUENCE techinsp.seq_video_downloads_id TO demax_admin;
GRANT USAGE, SELECT ON SEQUENCE techinsp.seq_video_download_requests_id TO demax_admin;
	
GRANT SELECT ON TABLE techinsp.permit_line_connectivity_statuses TO demax_admin;

GRANT SELECT ON techinsp.insp_protocol_data TO demax_admin;
GRANT SELECT ON techinsp.n_protocol_variables TO demax_admin;

GRANT SELECT ON public.n_vcategories TO demax_admin;

COMMIT;

