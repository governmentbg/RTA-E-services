BEGIN;

GRANT SELECT ON TABLE techinsp.terminated_inspections TO demax_admin;

GRANT SELECT ON TABLE techinsp.n_stop_reasons TO demax_admin;

COMMIT;