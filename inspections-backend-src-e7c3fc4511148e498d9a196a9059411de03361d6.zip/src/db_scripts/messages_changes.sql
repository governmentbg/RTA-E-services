BEGIN;

SET search_path = public;

CREATE TABLE n_message_statuses (
	   status character varying(6) NOT NULL PRIMARY KEY
);

INSERT INTO n_message_statuses VALUES ('sent'), ('draft');

ALTER TABLE n_message_statuses OWNER TO admin;

ALTER TABLE messages
ADD COLUMN status character varying(6) NOT NULL DEFAULT 'draft',
ADD CONSTRAINT message_status_fk FOREIGN KEY (status) REFERENCES n_message_statuses(status),
ALTER COLUMN sender SET NOT NULL,
ALTER COLUMN priority SET NOT NULL,
ALTER COLUMN type SET NOT NULL,
ALTER COLUMN body_id SET NOT NULL;

UPDATE messages SET status = 'sent' WHERE date is not null;

--message migration
CREATE TABLE public.message_permits (
    message_id integer REFERENCES public.messages (id),
    permit_id integer REFERENCES techinsp.permits (id),
    is_read boolean NOT NULL DEFAULT FALSE,
    PRIMARY KEY (message_id, permit_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.messages TO demax_admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.message_bodies TO demax_admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE public.message_permits TO demax_admin;
GRANT USAGE, SELECT ON SEQUENCE public.message_bodies_id_seq TO demax_admin;

GRANT SELECT, UPDATE ON TABLE public.message_permits TO techinsp;

COMMIT;

-- RUN MIGRATION PROGRAM

/* After migration program run, drop reduntant & unused columns
--ALTER TABLE public.messages DROP COLUMN permit_id, DROP COLUMN subject, DROP COLUMN text, DROP COLUMN is_read;
