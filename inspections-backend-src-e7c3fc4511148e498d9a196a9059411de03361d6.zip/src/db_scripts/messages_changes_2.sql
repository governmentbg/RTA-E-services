-- the first version of this script was run on production and it was made by vasko
-- this version was made by petio and was not run on production
BEGIN;

CREATE TABLE public.n_message_recipient_types (
    code character varying(10) NOT NULL,
    PRIMARY KEY (code)
);

ALTER TABLE public.n_message_recipient_types
    OWNER to admin;

GRANT SELECT ON TABLE public.n_message_recipient_types TO demax_admin;

INSERT INTO public.n_message_recipient_types VALUES
('UNKNOWN'), ('ALL'), ('ORG_UNIT'), ('PERMIT');

ALTER TABLE public.messages
    ADD COLUMN recipient_type_code character varying(10) NULL;

ALTER TABLE public.messages
    ADD FOREIGN KEY (recipient_type_code)
    REFERENCES public.n_message_recipient_types (code) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION;

UPDATE public.messages SET recipient_type_code = 'UNKNOWN';

UPDATE public.messages SET recipient_type_code = 'ORG_UNIT'
WHERE id IN (
		SELECT DISTINCT m.id
		FROM public.messages m
		JOIN public.message_permits mp ON mp.message_id = m.id
		JOIN techinsp.permits p ON p.id = mp.permit_id
		GROUP BY m.id
		HAVING count(DISTINCT p.org_unit) = 1);

UPDATE public.messages SET recipient_type_code = 'ALL'
WHERE id IN ( 
		SELECT DISTINCT m.id
		FROM public.messages m
		JOIN public.message_permits mp ON mp.message_id = m.id
		JOIN techinsp.permits p ON p.id = mp.permit_id
		GROUP BY m.id
		HAVING count(DISTINCT p.org_unit) = 27 AND count(DISTINCT p.id) > 1);

UPDATE public.messages SET recipient_type_code = 'PERMIT'
WHERE id IN (
		SELECT DISTINCT m.id
		FROM public.messages m
		JOIN public.message_permits mp ON mp.message_id = m.id
		JOIN techinsp.permits p ON p.id = mp.permit_id
		GROUP BY m.id
		HAVING count(DISTINCT p.id) = 1);

ALTER TABLE public.messages ALTER COLUMN recipient_type_code SET NOT NULL;

GRANT ALL ON SEQUENCE public.messages_id_seq TO demax_admin;

-- ADD created ad column to public.messages
ALTER TABLE public.messages
	ADD COLUMN created_at timestamp without time zone NOT NULL DEFAULT now();

UPDATE public.messages SET created_at = now()
WHERE status = 'draft';

UPDATE public.messages SET created_at = date
WHERE date IS NOT NULL AND status = 'sent';

-- message attachments
CREATE TABLE public.message_attachments
(
    id serial NOT NULL,
    message_id integer NOT NULL,
    mime_type character varying(30) NOT NULL,
    filename character varying(256) NOT NULL,
    content bytea NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (message_id)
        REFERENCES public.messages (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

ALTER TABLE public.message_attachments
    OWNER to admin;
    
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.message_attachments TO demax_admin;
GRANT SELECT ON TABLE public.message_attachments TO techinsp;
GRANT ALL ON SEQUENCE public.message_attachments_id_seq TO demax_admin;

COMMIT;
