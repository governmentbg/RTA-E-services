BEGIN;

-- create table public.n_os_image_types
CREATE TABLE public.n_os_image_types (
    id integer NOT NULL,
    description text NOT NULL,
    app_code character varying(5) NOT NULL,
    name character varying(64) NOT NULL
);

ALTER TABLE public.n_os_image_types OWNER TO admin;

COMMENT ON TABLE public.n_os_image_types IS 'OS image types that have md5 sums stored in the DB';

CREATE SEQUENCE public.n_os_image_types_description_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.n_os_image_types_description_seq OWNER TO admin;

ALTER SEQUENCE public.n_os_image_types_description_seq OWNED BY public.n_os_image_types.description;

CREATE SEQUENCE public.n_os_image_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.n_os_image_types_id_seq OWNER TO admin;
ALTER SEQUENCE public.n_os_image_types_id_seq OWNED BY public.n_os_image_types.id;
ALTER TABLE ONLY public.n_os_image_types ALTER COLUMN id SET DEFAULT nextval('public.n_os_image_types_id_seq'::regclass);

-- insert data in table public.n_os_image_types
INSERT INTO public.n_os_image_types (id, description, app_code, name) VALUES (1, 'Examiner OS image
HW: Dell
OS: Debian Stretch', 'ISTE', 'examiner');
INSERT INTO public.n_os_image_types (id, description, app_code, name) VALUES (2, 'Examinee OS image
HW: Intel, chinese PCs
OS: Debian Stretch', 'ISTE', 'examinee');
INSERT INTO public.n_os_image_types (id, description, app_code, name) VALUES (3, 'TechInsp OS image
HW: Dell
Os: Debian Stretch', 'ISTI', 'techinsp');

SELECT pg_catalog.setval('public.n_os_image_types_description_seq', 1, false);
SELECT pg_catalog.setval('public.n_os_image_types_id_seq', 34, true);

ALTER TABLE ONLY public.n_os_image_types
    ADD CONSTRAINT n_os_image_types_name_key UNIQUE (name);

ALTER TABLE ONLY public.n_os_image_types
    ADD CONSTRAINT n_os_image_types_pkey PRIMARY KEY (id);

ALTER TABLE ONLY public.n_os_image_types
    ADD CONSTRAINT n_os_image_types_app_code_fkey FOREIGN KEY (app_code) REFERENCES public.n_application_types(code) ON UPDATE CASCADE ON DELETE RESTRICT;
    
GRANT SELECT ON TABLE public.n_os_image_types TO demax_admin;
    

-- create table public.os_image_checksums
CREATE TABLE public.os_image_checksums (
    checksum character varying(32) NOT NULL,
    version_timestamp timestamp without time zone DEFAULT now() NOT NULL,
    description text,
    os_image_type integer DEFAULT 0 NOT NULL
);

ALTER TABLE public.os_image_checksums OWNER TO admin;

COMMENT ON TABLE public.os_image_checksums IS 'Версии на операционните системи на приложенията. История на версиите';
COMMENT ON COLUMN public.os_image_checksums.checksum IS 'md5 checksum за версията на ОС';
COMMENT ON COLUMN public.os_image_checksums.version_timestamp IS 'timestamp на добавяне на версията на ОС';
COMMENT ON COLUMN public.os_image_checksums.description IS 'Описание';

-- insert into table public.os_image_checksums
INSERT INTO public.os_image_checksums (checksum, version_timestamp, description, os_image_type) VALUES ('c62d6855af4cc79120b16b1e12938ba8', '2018-11-09 10:51:26.320943', 'Current stable version', 3);
INSERT INTO public.os_image_checksums (checksum, version_timestamp, description, os_image_type) VALUES ('c4d9cc9f15e1dcaa1a321e12d0cdedb2', '2018-11-09 11:11:35.337713', 'current stable version', 1);
INSERT INTO public.os_image_checksums (checksum, version_timestamp, description, os_image_type) VALUES ('8cf8d6c2d35e01fe207ca2c61cf1be4f', '2018-11-09 11:12:09.042946', 'current stable version', 2);

ALTER TABLE ONLY public.os_image_checksums
    ADD CONSTRAINT os_image_checksums_pkey PRIMARY KEY (checksum);

ALTER TABLE ONLY public.os_image_checksums
    ADD CONSTRAINT os_image_checksums_os_image_type_fkey FOREIGN KEY (os_image_type) REFERENCES public.n_os_image_types(id) ON UPDATE CASCADE ON DELETE RESTRICT;

REVOKE ALL ON TABLE public.os_image_checksums FROM PUBLIC;
REVOKE ALL ON TABLE public.os_image_checksums FROM admin;
GRANT ALL ON TABLE public.os_image_checksums TO admin;
GRANT SELECT ON TABLE public.os_image_checksums TO demax_admin;
    
COMMIT;