package bg.demax.inspections.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScans({
	@ComponentScan("bg.demax.inspections.backend")
})
@EnableJpaRepositories(
				transactionManagerRef = "transactionManager",
				basePackages = {
	"bg.demax.specialist.registry.common.repository",
	"bg.demax.inspections.backend.db.repository"
})
public class InspectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(InspectionApplication.class, args);
	}

}
