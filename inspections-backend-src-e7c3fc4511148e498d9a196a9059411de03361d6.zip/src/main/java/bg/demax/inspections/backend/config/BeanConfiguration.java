package bg.demax.inspections.backend.config;

import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.ws.client.core.WebServiceTemplate;

import bg.demax.courier.services.econt.web.EcontClient;
import bg.demax.courier.services.speedy.web.SpeedyClient;
import bg.demax.hibernate.GenericFinder;
import bg.demax.hibernate.GenericGateway;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.inspections.backend.export.orders.ExamOrderInvoicePrintFactory;
import bg.demax.inspections.backend.export.orders.InspectionDeliveryProtocolPrintFactory;
import bg.demax.inspections.backend.export.orders.InspectionOrderPrintFactory;
import bg.demax.inspections.backend.security.OrdersSecurityUtil;
import bg.demax.inspections.backend.security.SecurityUtil;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.ConversionServiceImpl;
import bg.demax.pub.entity.SystemVariable.SystemVariableId;
import bg.demax.pub.finder.AppliedDocumentTypeFinder;
import bg.demax.pub.finder.EmployeeFinder;
import bg.demax.pub.finder.SUserFinder;
import bg.demax.pub.finder.SubjectFinder;
import bg.demax.pub.finder.SystemVariableFinder;
import bg.demax.pub.finder.VehicleCategoryFinder;
import bg.demax.pub.service.SubjectService;
import bg.demax.security.finder.UserFinder;
import main01.wsdl.ObjectFactory;

@Configuration
@ImportResource("classpath:report.xml")
public class BeanConfiguration {

	@Value("${inspections.backend.econt.url}")
	private String econtUrl = null;

	@Value("${inspections.backend.speedy.url}")
	private String speedyUrl = null;

	@Value("${inspections.backend.inspectionFilesBasePath}")
	private String inspectionFilesBasePath = null;

	@Value("${inspections.backend.inspectionFilesServer}")
	private String inspectionFilesServer = null;
	
	@Bean
	public MappingJackson2HttpMessageConverter getMappingJackson2HttpMessageConverter() {
		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter(objectMapper());

		return converter;
	}

	@Bean
	public ObjectMapper objectMapper() {
		Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();

		builder.featuresToDisable(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS,
						DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);

		builder.modules(new JavaTimeModule());

		return builder.build();
	}

	@Bean
	@Qualifier("inspectionFilesServer")
	public String inspectionFilesServer() {
		return inspectionFilesServer;
	}

	@Bean
	@Qualifier("inspectionFilesBasePath")
	public String inspectionFilesBasePath() {
		return inspectionFilesBasePath;
	}

	@Bean
	public CommonsMultipartResolver multipartResolver() {
		return new CommonsMultipartResolver();
	}

	@Bean
	public LocalValidatorFactoryBean validator() {
		return new LocalValidatorFactoryBean();
	}

	@Bean
	public ConversionService getConversionService() {
		return new ConversionServiceImpl();
	}

	@Bean
	public UserFinder userFinder() {
		return new UserFinder();
	}

	@Bean
	public EmployeeFinder employeeFinder() {
		return new EmployeeFinder();
	}

	@Bean
	public SubjectFinder subjectFinder() {
		return new SubjectFinder();
	}

	@Bean
	public SUserFinder suserFinder() {
		return new SUserFinder();
	}

	@Bean
	@Qualifier("demaxAdminSubjectFinder")
	public bg.demax.inspections.backend.db.finder.SubjectFinder demaxAdminSubjectFinder() {
		return new bg.demax.inspections.backend.db.finder.SubjectFinder();
	}

	@Bean
	public GenericGateway getGenericGateway() {
		return new GenericGateway();
	}

	@Bean
	public GenericSearchSupport getGenericSearchSupport() {
		return new GenericSearchSupport();
	}

	@Bean
	public PagingAndSortingSupport getPagingAndSortingSupport() {
		return new PagingAndSortingSupport();
	}

	@Bean
	public EcontClient econtClient() {
		return new EcontClient(econtUrl);
	}

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	@Bean
	public WebServiceTemplate webServiceTemplate() {
		return new WebServiceTemplate();
	}
	
	@Bean
	public AppliedDocumentTypeFinder appliedDocumentTypeFinder() {
		return new AppliedDocumentTypeFinder();
	}

	@Bean
	public SpeedyClient speedyClient() throws JAXBException {
		return new SpeedyClient(speedyUrl);
	}

	@Bean
	public Marshaller marshaller() throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(ObjectFactory.class);
		Marshaller marshaller = jc.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		return marshaller;

	}

	@Bean
	public Unmarshaller unmarshaller() throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(ObjectFactory.class);
		Unmarshaller unmarshaller = jc.createUnmarshaller();
		return unmarshaller;
	}

	@Bean
	public ObjectFactory objectFactory() {
		return new ObjectFactory();
	}

	@Bean
	public SecurityUtil getSecurityUtil() {
		return new SecurityUtil();
	}

	@Bean
	public OrdersSecurityUtil getOrdersSecurityUtil() {
		return new OrdersSecurityUtil();
	}

	@Bean
	@Qualifier("boxWeightVarKey")
	public SystemVariableId getBoxWeightVarKey() {
		SystemVariableId sysVariable = new SystemVariableId();
		sysVariable.setApplicationCode("DXAN");
		sysVariable.setTableName("all");
		sysVariable.setName("boxWeight");

		return sysVariable;
	}

	@Bean
	@Qualifier("smallBoxWeightVarKey")
	public SystemVariableId getSmallBoxWeightVarKey() {
		SystemVariableId sysVariable = new SystemVariableId();
		sysVariable.setApplicationCode("DXAN");
		sysVariable.setTableName("all");
		sysVariable.setName("smallBoxWeight");

		return sysVariable;
	}

	@Bean
	@Qualifier("maxOrderWeightPercentOffsetVarKey")
	public SystemVariableId getMaxOrderWeightPercentOffsetVarKey() {
		SystemVariableId sysVariable = new SystemVariableId();
		sysVariable.setApplicationCode("DXAN");
		sysVariable.setTableName("all");
		sysVariable.setName("maxOrderWeightPercentOffset");

		return sysVariable;
	}

	@Bean
	@Qualifier("speedyBackDocumentsVarKey")
	public SystemVariableId getSpeedyBackDocumentsVarKey() {
		SystemVariableId sysVariable = new SystemVariableId();
		sysVariable.setApplicationCode("DXAN");
		sysVariable.setTableName("all");
		sysVariable.setName("speedy_return_documents");

		return sysVariable;
	}

	@Bean
	@Qualifier("maxMessageAttachmentSizeKBVarKey")
	public SystemVariableId getMaxMessageAttachmentSizeKBVarKey() {
		SystemVariableId sysVariable = new SystemVariableId();
		sysVariable.setApplicationCode("DXAN");
		sysVariable.setTableName("all");
		sysVariable.setName("maxMessageAttachmentSizeKBVarKey");

		return sysVariable;
	}
	
	@Bean
	@Qualifier("daysUntilExpiration")
	public SystemVariableId getDaysUntilExpirationVarKey() {
		SystemVariableId sysVariable = new SystemVariableId();
		sysVariable.setApplicationCode("DXAN");
		sysVariable.setTableName("all");
		sysVariable.setName("daysUntilExpiration");
		
		return sysVariable;
	}

	@Bean
	@Qualifier("isSettingExpiredEnabled")
	public SystemVariableId getIsSettingExpiredEnabledVarKey() {
		SystemVariableId sysVariable = new SystemVariableId();
		sysVariable.setApplicationCode("DXAN");
		sysVariable.setTableName("all");
		sysVariable.setName("isSettingExpiredEnabled");

		return sysVariable;
	}

	@Bean
	@Qualifier("firstExpirationMonthCount")
	public SystemVariableId getFirstExpirationMonthCountVarKey() {
		SystemVariableId sysVariable = new SystemVariableId();
		sysVariable.setApplicationCode("DXAN");
		sysVariable.setTableName("all");
		sysVariable.setName("firstExpirationMonthCount");

		return sysVariable;
	}

	@Bean
	@Qualifier("secondExpirationMonthCount")
	public SystemVariableId getSecondExpirationMonthCountVarKey() {
		SystemVariableId sysVariable = new SystemVariableId();
		sysVariable.setApplicationCode("DXAN");
		sysVariable.setTableName("all");
		sysVariable.setName("secondExpirationMonthCount");

		return sysVariable;
	}

	@Bean
	@Qualifier("demaxAdminSystemEmail")
	public SystemVariableId getDemaxAdminSystemEmail() {
		SystemVariableId sysVariable = new SystemVariableId();
		sysVariable.setApplicationCode("DXAN");
		sysVariable.setTableName("ALL");
		sysVariable.setName("demax_admin_system_email");

		return sysVariable;
	}
	
	@Bean
	@Qualifier("iaaaPermitNotificationEmails")
	public SystemVariableId getIaaaPermitNotificationEmails() {
		SystemVariableId sysVariable = new SystemVariableId();
		sysVariable.setApplicationCode("DXAN");
		sysVariable.setTableName("ALL");
		sysVariable.setName("iaaa_permit_notification_emails");

		return sysVariable;
	}

	@Bean
	public InspectionOrderPrintFactory getInspectionOrderLabelPrintFactory() {
		return new InspectionOrderPrintFactory();
	}
	
	@Bean
	public ExamOrderInvoicePrintFactory getExamOrderLabelPrintFactory() {
		return new ExamOrderInvoicePrintFactory();
	}

	@Bean
	public InspectionDeliveryProtocolPrintFactory getInspectionDeliveryProtocolPrintFactory() {
		return new InspectionDeliveryProtocolPrintFactory();
	}

	@Bean
	public SubjectService getSubjectService() {
		return new SubjectService();
	}
	
	@Bean
	public GenericFinder getGenericFinder() {
		return new GenericFinder();
	}
		
	@Bean
	public VehicleCategoryFinder getVehicleCategoryFinder() {
		return new VehicleCategoryFinder();
	}
	
	@Bean
	public SystemVariableFinder getSystemVariableFinder() {
		return new SystemVariableFinder();
	}

	@Bean
	public JavaMailSender getJavaMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost("smtp.demax.bg");
		mailSender.setPort(465);

		mailSender.setUsername("info@avtoizpit.com");
		mailSender.setPassword("Pn4c5ekug9JR");

		Properties properties = System.getProperties();
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.debug", "true");
		properties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		properties.put("mail.smtp.starttls.enable", "false");
		properties.put("mail.smtp.ssl.enable", "true");

		mailSender.setJavaMailProperties(properties);

		return mailSender;
	}

}
