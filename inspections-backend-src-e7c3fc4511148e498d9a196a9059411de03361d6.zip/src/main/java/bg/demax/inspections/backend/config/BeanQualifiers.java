package bg.demax.inspections.backend.config;

public interface BeanQualifiers {

	public static final String DATA_SOURCE_MASTER = "data-source-master";
	public static final String DATA_SOURCE_REPLICATION = "data-source-replication";

}
