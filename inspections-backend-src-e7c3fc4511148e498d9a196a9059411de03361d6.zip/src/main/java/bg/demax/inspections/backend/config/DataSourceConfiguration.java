package bg.demax.inspections.backend.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariDataSource;

import bg.demax.inspections.backend.config.properties.PostgreConfigProperties;

@Configuration
@EnableTransactionManagement(order = 100)
@Profile("!" + InspectionWebConstants.SPRING_PROFILE_TEST)
public class DataSourceConfiguration {

	@Autowired
	private PostgreConfigProperties postgreConfig;

	@Bean
	@Qualifier(BeanQualifiers.DATA_SOURCE_MASTER)
	public DataSource dataSourceMaster() {
		HikariDataSource dataSource = new HikariDataSource();
		dataSource.setJdbcUrl(postgreConfig.getMasterUrl());
		dataSource.setUsername(postgreConfig.getMasterUsername());
		dataSource.setPassword(postgreConfig.getMasterPassword());
		dataSource.setMaximumPoolSize(postgreConfig.getMasterMaximumPoolSize());
		dataSource.setConnectionTimeout(postgreConfig.getConnectionTimeout());
		dataSource.setIdleTimeout(postgreConfig.getIdleTimeout());
		dataSource.setMaxLifetime(60 * 1000);
		dataSource.setMinimumIdle(0);
		return dataSource;
	}

	@Bean
	@Qualifier(BeanQualifiers.DATA_SOURCE_REPLICATION)
	public DataSource dataSourceReplication() {
		HikariDataSource dataSource = new HikariDataSource();
		dataSource.setJdbcUrl(postgreConfig.getReplicationUrl());
		dataSource.setUsername(postgreConfig.getReplicationUsername());
		dataSource.setPassword(postgreConfig.getReplicationPassword());
		dataSource.setMaximumPoolSize(postgreConfig.getReplicationMaximumPoolSize());
		dataSource.setConnectionTimeout(postgreConfig.getConnectionTimeout());
		dataSource.setIdleTimeout(postgreConfig.getIdleTimeout());
		dataSource.setMaxLifetime(60 * 1000);
		dataSource.setMinimumIdle(0);
		return dataSource;
	}
}
