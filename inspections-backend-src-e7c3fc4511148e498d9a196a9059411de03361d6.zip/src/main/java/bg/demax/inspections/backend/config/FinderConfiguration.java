package bg.demax.inspections.backend.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class FinderConfiguration {

	
	
}
