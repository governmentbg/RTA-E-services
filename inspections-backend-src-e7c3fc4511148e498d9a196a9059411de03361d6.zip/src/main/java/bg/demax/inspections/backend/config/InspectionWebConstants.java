package bg.demax.inspections.backend.config;

import java.time.format.DateTimeFormatter;

import bg.demax.techinsp.entity.PermitStatus;

public interface InspectionWebConstants {
	
	final String SPRING_PROFILE_TEST = "test";
	final String SPRING_PROFILE_PRODUCTION = "production";
	final String SPRING_PROFILE_DEVELOPMENT = "dev";

	final String[] APPLICATION_ENTITY_PACKAGES_TO_SCAN = { 
		"bg.demax.security.entity",
		"bg.demax.inspections.backend.entity", 
		"bg.demax.pub.entity", 
		"bg.demax.inspections.backend.entity",
		"bg.demax.techinsp.entity", 
		"bg.demax.motor.exam.permit.entity", 
		"bg.demax.exams.entity",
		"bg.demax.specialist.registry.common.entity"
	};

	final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yyyy hh:mm");
	final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yyyy");
	final String EMAIL_PATTERN = "^['_a-z0-9-]+(\\.['_a-z0-9]+)*@[a-z0-9]+(\\.[a-z0-9]+)*\\.(([a-z]{2,3}))$";
	final String REGISTRATION_NUMBER_PATTERN = "^([ABEKMHOPCTYXАВЕКМНОРСТУХ]{1,2})([0-9]{4})([ABEKMHOPCTYXАВЕКМНОРСТУХ]{1,2})$";
	final String ALL_PERMIT_STATUSES_PATTERN = "^(" + PermitStatus.VALID_CODE + "|" + PermitStatus.CHANGED_CONDITIONS_AND_LISTS_CODE + "|" 
			+ PermitStatus.CHANGED_CONDITIONS_CODE + "|" + PermitStatus.CHANGED_STATUS_CODE + "|" 
			+ PermitStatus.CLOSED_CODE + "|" + PermitStatus.CREATED_CODE + "|" 
			+ PermitStatus.DRAFT_CODE + "|" + PermitStatus.EXPIRED_CODE + "|" 
			+ PermitStatus.INVALID_CODE + "|" + PermitStatus.PROCESSING_CODE + "|" 
			+ PermitStatus.REISSUED_CODE + "|" + PermitStatus.REJECTED_CODE + "|" 
			+ PermitStatus.REQUESTED_CODE + "|" + PermitStatus.REVOKED_CODE + "|" 
			+ PermitStatus.REVOKING_IN_PROCESS_CODE + ")$";
	final String ORG_UNIT_RDAA_PATTERN = "^РДАА(0[1-9]|1[0-9]|2[0-7])$";
}
