package bg.demax.inspections.backend.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import bg.demax.inspections.backend.config.DbContextHolder.DbType;

@Configuration
@EnableTransactionManagement(order = 100)
@Profile("!" + InspectionWebConstants.SPRING_PROFILE_TEST)
public class PostgreConfiguration {

	@Value("${hibernate.show_sql}")
	private String showSql;

	@Autowired
	@Qualifier(BeanQualifiers.DATA_SOURCE_MASTER)
	private DataSource dataSourceMaster;
	
	@Autowired
	@Qualifier(BeanQualifiers.DATA_SOURCE_REPLICATION)
	private DataSource dataSourceReplication;

	@Bean(name = "entityManagerFactory")
	public LocalSessionFactoryBean sessionFactory(@Autowired DataSource routingDataSource) {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(routingDataSource);
		sessionFactory.setPackagesToScan(InspectionWebConstants.APPLICATION_ENTITY_PACKAGES_TO_SCAN);
		sessionFactory.setHibernateProperties(hibernateProperties());

		return sessionFactory;
	}
	
	@Bean(name = "routingDataSource")
	public RoutingDataSource dataSource() {
		Map<Object, Object> targetDataSources = new HashMap<>();
		targetDataSources.put(DbType.MASTER, dataSourceMaster);
		targetDataSources.put(DbType.REPLICATION, dataSourceReplication);

		RoutingDataSource routingDataSource = new RoutingDataSource();
		routingDataSource.setTargetDataSources(targetDataSources);
		routingDataSource.setDefaultTargetDataSource(dataSourceMaster);
		return routingDataSource;
	}

	@Bean(name = "transactionManager")
	public HibernateTransactionManager getTransactionManager(@Autowired SessionFactory sessionFactory) {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager(sessionFactory);
		return transactionManager;
	}

	private Properties hibernateProperties() {
		Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.PostgreSQL95Dialect");
		hibernateProperties.setProperty("hibernate.format_sql", "true");
		hibernateProperties.setProperty("hibernate.show_sql", showSql);
		hibernateProperties.setProperty("hibernate.jdbc.lob.non_contextual_creation", "true");

		return hibernateProperties;
	}
}
