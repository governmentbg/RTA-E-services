package bg.demax.inspections.backend.config.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@Configuration
@ConfigurationProperties("datasource")
@Getter
@Setter
public class PostgreConfigProperties {
	
	private String masterUrl;
	private String masterUsername;
	private String masterPassword;
	private Integer masterMaximumPoolSize;
	
	private String replicationUrl;
	private String replicationUsername;
	private String replicationPassword;
	private Integer replicationMaximumPoolSize;
	
	private Integer maxStatements;
	private Integer idleConnectionTestPeriod;
	private Integer loginTimeout;
	private Integer connectionTimeout;
	private Integer idleTimeout;
}
