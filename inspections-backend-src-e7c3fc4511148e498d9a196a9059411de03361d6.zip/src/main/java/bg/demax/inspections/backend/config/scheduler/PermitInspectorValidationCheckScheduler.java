package bg.demax.inspections.backend.config.scheduler;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorCertificateValidityDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorExpiringDocumentDto;
import bg.demax.inspections.backend.service.permit.inspector.PermitInspectorService;

@Configuration
@EnableScheduling
public class PermitInspectorValidationCheckScheduler {

	private static final Logger logger = LogManager.getLogger(PermitInspectorValidationCheckScheduler.class);

	@Autowired
	private PermitInspectorService permitInspectorService;

	@Scheduled(cron = "${permit.inspector.validation.scheduler}", zone = "GMT+3")
	public void notifyKtpsAboutExpiringDcouments() {
		logger.info("PermitInspectorValidationCheckScheduler STARTING!");

		Map<Integer, List<PermitInspectorExpiringDocumentDto>> inspectorsDocumentValidities = permitInspectorService
				.getAllValidAndExpiringPermitInspectorPeriodicalDocuments();

		Map<Integer, List<PermitInspectorCertificateValidityDto>> inspectorsCertificationValidities = permitInspectorService
				.getAllValidAndExpiringPermitInspectorPeriodicalCertificates();

		Set<Integer> inspectorIds = new HashSet<>();

		inspectorIds.addAll(inspectorsDocumentValidities.keySet());

		inspectorIds.addAll(inspectorsCertificationValidities.keySet());

		for (Integer permitInspectorId : inspectorIds) {
			List<PermitInspectorExpiringDocumentDto> expiringDocumentsForInspector = inspectorsDocumentValidities
					.get(permitInspectorId);

			List<PermitInspectorCertificateValidityDto> expiringCertificationsForInspector = inspectorsCertificationValidities
					.get(permitInspectorId);

			String messageBody = permitInspectorService.sendMessagesForExpiringDocumentAndCertification(
					permitInspectorId, expiringDocumentsForInspector, expiringCertificationsForInspector);

			logger.info("Permit inspector id: " + permitInspectorId + " has expiring documents: " + messageBody);

		}
	}

}