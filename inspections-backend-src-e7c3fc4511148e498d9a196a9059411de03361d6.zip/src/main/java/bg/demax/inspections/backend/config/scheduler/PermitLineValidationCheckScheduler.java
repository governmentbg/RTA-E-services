package bg.demax.inspections.backend.config.scheduler;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

import bg.demax.inspections.backend.config.InspectionWebConstants;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineDocumentValiditionDto;
import bg.demax.inspections.backend.entity.techinsp.Message;
import bg.demax.inspections.backend.entity.techinsp.MessageBody;
import bg.demax.inspections.backend.entity.techinsp.MessageRecipientType;
import bg.demax.inspections.backend.entity.techinsp.enums.MessageStatus;
import bg.demax.inspections.backend.service.permit.line.PermitLineDocumentService;
import bg.demax.inspections.backend.service.techinsp.MessageService;
import bg.demax.techinsp.entity.Permit;

@Configuration
@EnableScheduling
public class PermitLineValidationCheckScheduler {

	private static final Logger logger = LogManager.getLogger(PermitInspectorValidationCheckScheduler.class);

	private static final String EXPIRING_PERMIT_LINE_DOCUMENT_MESSAGE = "Документ с номер %s на линия %d %s на %s";
	private static final String SUBJECT = "Изтичащи документ на линия";

	private static final String SENDER = "IAAA";

	@Autowired
	private PermitLineDocumentService permitLineDocumentService;

	@Autowired
	private MessageService messageService;
	

	// 0 0 1 ? * * - every day at 1 am - production
	//@Scheduled(cron = "${permit.line.validation.scheduler}", zone = "GMT+3")
	public void notifyKtpsAboutExpiringDcouments() {

		logger.info("PermitLineValidationCheckScheduler STARTING!");
		List<PermitLineDocumentValiditionDto> expiredDocumentDtos = permitLineDocumentService
				.getAllValidAndExpiringPermitLinePeriodicalDocuments();

		
		for (PermitLineDocumentValiditionDto permitLineDocumentValiditionDto : expiredDocumentDtos) {

			String expirationText = permitLineDocumentValiditionDto.getValidTo().isBefore(LocalDate.now()) ? "изтекъл" : "изтичащ";

			String messageString = String.format(EXPIRING_PERMIT_LINE_DOCUMENT_MESSAGE, 
				permitLineDocumentValiditionDto.getDocumentNumber(), permitLineDocumentValiditionDto.getPermitLineNumber(), 
					expirationText, permitLineDocumentValiditionDto.getValidTo().format(InspectionWebConstants.DATE_FORMATTER));
			
			logger.info("Permit Id: " + permitLineDocumentValiditionDto.getPermitId()
					+ " Line document expiration message: " + messageString);
			createExpiringMessage(Arrays.asList(permitLineDocumentValiditionDto.getPermitId()), SUBJECT, messageString);

		}
		
	}

	private void createExpiringMessage(List<Integer> expiringPermitIds, String subject, String message) {
		
		Message expiringMessage = new Message();

		MessageRecipientType type = new MessageRecipientType();
		type.setCode(MessageRecipientType.PERMIT_CODE);
		expiringMessage.setRecipientType(type);

		MessageBody body = new MessageBody();
		body.setSubject(subject);
		body.setBody(message);
		expiringMessage.setBody(body);

		for (Integer permitId : expiringPermitIds) {
			Permit permit = new Permit();
			permit.setId(permitId);
			expiringMessage.addPermit(permit);
		}

		expiringMessage.setSender(SENDER);

		MessageStatus status = new MessageStatus();
		status.setCode(MessageStatus.SENT);
		expiringMessage.setStatus(status);

		messageService.saveAndSendMessage(expiringMessage, null);

	}

}