package bg.demax.inspections.backend.config.scheduler;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitDocumentValidityDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitValidityDto;
import bg.demax.inspections.backend.entity.techinsp.Message;
import bg.demax.inspections.backend.entity.techinsp.MessageBody;
import bg.demax.inspections.backend.entity.techinsp.MessageRecipientType;
import bg.demax.inspections.backend.entity.techinsp.enums.MessageStatus;
import bg.demax.inspections.backend.service.EmailService;
import bg.demax.inspections.backend.service.SystemVariablesService;
import bg.demax.inspections.backend.service.permit.PermitDocumentService;
import bg.demax.inspections.backend.service.permit.PermitService;
import bg.demax.inspections.backend.service.techinsp.MessageService;
import bg.demax.techinsp.entity.Permit;

@Configuration
@EnableScheduling
public class PermitValidationCheckScheduler {

	private static final Logger logger = LogManager.getLogger(PermitValidationCheckScheduler.class);

	private static final String EXPIRING_PERMIT_MESSAGE_14_DAYS = "Разрешението ви изтича след 14 дена!";
	private static final String EXPIRING_PERMIT_MESSAGE_MONTH = "Разрешението ви изтича след 1 месец!";
	private static final String EXPIRING_PERMIT_DOCUMENT_MESSAGE = "%s изтича след 14 дена.";
	private static final String SUBJECT = "Валидност на Разрешение";

	private static final String SENDER = "Изпълнителна агенция \"Автомобилна администрация\"";

	@Autowired
	private PermitService permitService;

	@Autowired
	private EmailService emailService;

	@Autowired
	private PermitDocumentService permitDocumentService;

	@Autowired
	protected SystemVariablesService systemVariablesService; 

	@Autowired
	private MessageService messageService;

	protected void createExpiringMessage(List<Integer> expiringPermitIds, String subject, String message) {
		Message expiringMessage = new Message();

		MessageRecipientType type = new MessageRecipientType();
		type.setCode(MessageRecipientType.PERMIT_CODE);
		expiringMessage.setRecipientType(type);

		MessageBody body = new MessageBody();
		body.setSubject(subject);
		body.setBody(message);
		expiringMessage.setBody(body);

		for (Integer permitId : expiringPermitIds) {
			Permit permit = new Permit();
			permit.setId(permitId);
			expiringMessage.addPermit(permit);
		}

		expiringMessage.setSender(SENDER);

		MessageStatus status = new MessageStatus();
		status.setCode(MessageStatus.SENT);
		expiringMessage.setStatus(status);

		messageService.saveAndSendMessage(expiringMessage, null);

	}

	//0 0 1 ? * * - every day at 1 am - production
	@Scheduled(cron = "${permit.validation.scheduler}", zone = "GMT+3")
	public void notifyKtpsAboutExpiringDcouments() {
		logger.info("PermitValidationCheckScheduler STARTING!");
		LocalDate today = LocalDate.now();
		int daysUntilExpiration = systemVariablesService.getDaysUntilExpiration();
		int firstExpirationMonth = systemVariablesService.getFirstExpirationMonthCount();
		LocalDate fourteenDays = today.plusDays(daysUntilExpiration);
		LocalDate month = today.plusMonths(firstExpirationMonth);

		boolean isExpirationEnabled = systemVariablesService.isSettingExpiredEnabled();

		List<PermitValidityDto> permits = permitService.getAllValidPermitsAndExpiringForScheduler();

		List<PermitValidityDto> expiringPermitsIn14Days = new ArrayList<>();
		List<PermitValidityDto> expiringPermitsInMonth = new ArrayList<>();

		for (PermitValidityDto permit : permits) {
			if (permit.getValidTo().isEqual(today) || permit.getValidTo().isBefore(today)) {
				logger.info("PERMIT WITH ID: " + permit.getId() + " EXPIRED!");
				if (isExpirationEnabled) {
					permitService.updateExpiredPermit(permit);
				}
				//TODO ADD MAILSERVICE
			}

			if (permit.getValidTo().equals(fourteenDays)) {
				expiringPermitsIn14Days.add(permit);
				logger.info("PERMIT WITH ID: " + permit.getId() + " IS EXPIRING IN " + daysUntilExpiration + " DAYS");
			}

			if (permit.getValidTo().equals(month)) {
				expiringPermitsInMonth.add(permit);
				logger.info("PERMIT WITH ID: " + permit.getId() + " IS EXPIRING IN " + firstExpirationMonth + " MONTH");
			}

		}

		if (!expiringPermitsIn14Days.isEmpty()) {
			emailService.sendPermitExpirationEmails(expiringPermitsIn14Days, false);
			List<Integer> expiringPermitIds = expiringPermitsIn14Days.stream()
					.map(PermitValidityDto::getId).collect(Collectors.toList());
			
			createExpiringMessage(expiringPermitIds, SUBJECT, EXPIRING_PERMIT_MESSAGE_14_DAYS);
		}

		if (!expiringPermitsInMonth.isEmpty()) {
			emailService.sendPermitExpirationEmails(expiringPermitsInMonth, true);
			List<Integer> expiringPermitIds = expiringPermitsInMonth.stream()
					.map(PermitValidityDto::getId).collect(Collectors.toList());
			createExpiringMessage(expiringPermitIds, SUBJECT, EXPIRING_PERMIT_MESSAGE_MONTH);
		}

		List<PermitDocumentValidityDto> permitDocuments = permitDocumentService.getExpiringDoducmentsForValidPermits();

		for (PermitDocumentValidityDto permitDoc : permitDocuments) {
			if (permitDoc.getValidTo().isEqual(today)) {
				logger.info("PERMIT DOCUMENT WITH ID: " + permitDoc.getDocumentId() + " EXPIRED!");
				if (isExpirationEnabled) { 
					permitDocumentService.updateExpiredPermitDocument(permitDoc);
				}
				//TODO ADD MAILSERVICE
			}

			if (permitDoc.getValidTo().equals(fourteenDays)) {
				String message = String.format(EXPIRING_PERMIT_DOCUMENT_MESSAGE, permitDoc.getDocumentType());
				createExpiringMessage(Arrays.asList(permitDoc.getPermitId()), SUBJECT, message);
				logger.info("PERMIT DOCUMENT WITH ID: " + permitDoc.getDocumentId() + " " + message);
			}

		}
	}
}