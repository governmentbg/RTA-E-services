package bg.demax.inspections.backend.config.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.logout.HttpStatusReturningLogoutSuccessHandler;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfTokenRepository;

import bg.demax.inspections.backend.security.DemaxPasswordEncoder;
import bg.demax.inspections.backend.security.SecurityRoles;
import bg.demax.inspections.backend.security.UserAuthenticationService;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	private RestAuthenticationFailureHandler authenticationFailureHandler;
	private RestAuthenticationSuccessHandler authenticationSuccessHandler;
	private UserAuthenticationService userService;

	@Autowired
	public SecurityConfiguration(RestAuthenticationFailureHandler authenticationFailureHandler,
					RestAuthenticationSuccessHandler authenticationSuccessHandler, UserAuthenticationService userService) {
		this.authenticationFailureHandler = authenticationFailureHandler;
		this.authenticationSuccessHandler = authenticationSuccessHandler;
		this.userService = userService;
	}

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userService);
	}

	// @formatter:off
	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/v2/api-docs", 
						"/configuration/ui", 
						"/swagger-resources/**", 
						"/configuration/**", 
						"/monitoring/**", 
						"/swagger-ui.html",
						"/webjars/**", "/csrf", "/");
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.cors().and().csrf().ignoringAntMatchers("/login", "/logout").csrfTokenRepository(csrfTokenRepository()).and()
						.exceptionHandling().authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.FORBIDDEN)).and()
						.authorizeRequests()
						.antMatchers(HttpMethod.GET, 
								"/api/users/current/",
								"/api/org-units/without-iaaa",
								"/api/nomenclatures/**")
								.authenticated()
						.antMatchers(
								"/v2/api-docs",
								"/configuration/ui",
								"/swagger-resources",
								"/monitoring",
								"/configuration/security",
								"/swagger-ui.html",
								"/webjars/**")
								.permitAll()
						.antMatchers(HttpMethod.POST, 
								"/api/users/current/change-password")
								.authenticated()
						.antMatchers(
								"/api/inspection-orders/{id}/bank-statement/pdf",
								"/api/inspection-orders/{id}/invoice/pdf",
								"/api/exam-orders/{id}/invoice/pdf")
								.hasAnyAuthority(
										SecurityRoles.ROLE_ACCOUNTING.getName(), 
										SecurityRoles.ROLE_CALL_CENTER.getName())
						.antMatchers(
								"/api/inspections/finished-specific-role-search")
								.hasAnyAuthority(
										SecurityRoles.ROLE_ADMIN.getName(),
										SecurityRoles.ROLE_CALL_CENTER.getName(),
										SecurityRoles.ROLE_TECHINSP_INSP_SEARCH_ALL.getName(),
										SecurityRoles.ROLE_TECHINSP_SECONDARY_INSPECTION.getName())
						.antMatchers(
								"/api/inspections/finished-specific-search",
								"/api/inspections/finished")
								.hasAnyAuthority(
										SecurityRoles.ROLE_ADMIN.getName(),
										SecurityRoles.ROLE_CALL_CENTER.getName(),
										SecurityRoles.ROLE_TECHINSP_INSP_SEARCH_ALL.getName(),
										SecurityRoles.ROLE_TECHINSP_IAAA.getName(),
										SecurityRoles.ROLE_TECHINSP_INSP_RDAA.getName(),
										SecurityRoles.ROLE_TECHINSP_CHILD_ORG_UNIT_INSPECTOR.getName(),
										SecurityRoles.ROLE_TECHINSP_SECONDARY_INSPECTION.getName())
						.antMatchers(HttpMethod.GET, 
								"/api/exam-orders/{id}/bill-of-lading/pdf")
								.hasAnyAuthority(
										SecurityRoles.ROLE_PACKAGING_VOUCHERS.getName(),
										SecurityRoles.ROLE_SUPERVISOR.getName())
						.antMatchers(HttpMethod.POST, 
								"/api/exam-orders/{id}/bill-of-lading")
								.hasAnyAuthority(
										SecurityRoles.ROLE_PACKAGING_VOUCHERS.getName(),
										SecurityRoles.ROLE_SUPERVISOR.getName())
						.antMatchers(HttpMethod.GET, 
								"/api/exam-orders/{id}/bank-statement/pdf")
								.hasAnyAuthority(
										SecurityRoles.ROLE_ACCOUNTING.getName(), 
										SecurityRoles.ROLE_CALL_CENTER.getName())
						.antMatchers(HttpMethod.GET, 
								"/api/permits/{id}/pdf",
								"/api/permits/{id}/pdf-light",
								"/api/permits/{id}/pdf-light-duplicate",
								"/api/permits/{id}/inspectors/deprive-of-rights",
								"/api/reports/permits/html/**",
								"/api/reports/html/semt-certificates",
								"/api/reports/html/issued-semt",
								"/api/permits/{id}/inspectors/deprive-of-rights-check")
								.hasAuthority(SecurityRoles.ROLE_TECHINSP_IAAA.getName())
						.antMatchers(HttpMethod.PUT, 
								"/api/permits/{id}/approve", 
								"/api/permits/{id}/reject",
								"/api/permits/{id}/return",
								"/api/permits/{id}/status",
								"/api/permits/{id}/inspectors/{inspectorId}/stamps/{stampId}",
								"/api/permits/{id}/inspectors/deprive-of-rights")
								.hasAuthority(SecurityRoles.ROLE_TECHINSP_IAAA.getName())
						.antMatchers(HttpMethod.POST, 
								"/api/permits/{id}/inspectors/{inspectorId}/stamps")
								.hasAuthority(SecurityRoles.ROLE_TECHINSP_IAAA.getName())
						.antMatchers(HttpMethod.POST, 
								"/api/permits",
								"/api/permits/{id}",
								"/api/permits/{permitVersionId}/documents",
								"/api/permits/{permitVersionId}/lines",
								"/api/permits/{id}/inspectors",
								"/api/permits/{id}/inspectors/{inspectorId}/documents",
								"/api/permits/{id}/lines/{lineId}/documents",
								"/api/permits/{id}/inspections")
								.hasAuthority(SecurityRoles.ROLE_TECHINSP_INSP_RDAA.getName())
						.antMatchers(HttpMethod.PUT, 
								"/api/permits/{permitVersionId}/documents/{docVersionId}/new",
								"/api/permits/{permitVersionId}/documents/{docVersionId}/approved",
								"/api/permits/{id}/send-to-iaaa",
								"/api/permits/{id}/reissue",
								"/api/permits/{id}/inspectors/{inspectorId}",
								"/api/permits/{id}/inspectors/{inspectorId}/documents/{documentId}/new",
								"/api/permits/{id}/inspectors/{inspectorId}/documents/{documentId}/approved",
								"/api/permits/{permitVersionId}/lines/{permitLineId}",
								"/api/permits/{permitVersionId}/lines/{permitLineId}/documents/{permitLineDocumentId}/new",
								"/api/permits/{permitVersionId}/lines/{permitLineId}/documents/{permitLineDocumentId}/approved")
								.hasAuthority(SecurityRoles.ROLE_TECHINSP_INSP_RDAA.getName())
						.antMatchers(HttpMethod.PATCH, 
								"/api/permits/{id}/info", 
								"/api/permits/{id}/company")
								.hasAuthority(SecurityRoles.ROLE_TECHINSP_INSP_RDAA.getName())
						.antMatchers(HttpMethod.DELETE,
								"/api/permits/{permitVersionId}/lines/{permitLineId}",
								"/api/permits/{permitVersionId}/lines/{permitLineId}/documents/{permitLineDocumentId}",
								"/api/permits/{permitVersionId}/inspectors/{inspectorId}",
								"/api/permits/{id}",
								"/api/permits/{permitVersionId}/inspections/{permitInspectionId}",
								"/api/permits/{permitVersionId}/documents/{docVersionId}",
								"/api/permits/{id}/inspectors/{inspectorId}/documents/{documentId}")
								.hasAuthority(SecurityRoles.ROLE_TECHINSP_INSP_RDAA.getName())
						.antMatchers(HttpMethod.GET, 
								"/api/permits/by-number/{number}")
								.hasAnyAuthority(
												SecurityRoles.ROLE_CALL_CENTER.getName(),
												SecurityRoles.ROLE_TECHINSP_MESSAGES_EDIT.getName())
						.antMatchers(HttpMethod.GET, 
								"/api/permits/{id}/lines/{lineId}/hardware")
								.hasAuthority(SecurityRoles.ROLE_CALL_CENTER.getName())
						.antMatchers(HttpMethod.POST, 
								"/api/permits/{id}/subjects/{subjectId}/cards")
								.hasAuthority(SecurityRoles.ROLE_CALL_CENTER.getName())
						.antMatchers(HttpMethod.PUT, 
								"/api/permits/{id}/lines/{lineId}/hardware",
								"/api/permits/{id}/subjects/{subjectId}/cards/**")
								.hasAuthority(SecurityRoles.ROLE_CALL_CENTER.getName())
						.antMatchers(HttpMethod.PATCH, 
								"/api/inspection-orders/{id}/pay",
								"/api/inspection-orders/{id}/quantity/call-center",
								"/api/permits/{id}/additional-info",
								"/api/permits/{permitVersionId}/lines/{lineId}/hardware/{hardwareId}")
								.hasAuthority(SecurityRoles.ROLE_CALL_CENTER.getName())
						.antMatchers(
								"/api/org-units/inspection-orders")
								.hasAnyAuthority(
										SecurityRoles.ROLE_PACKAGING_INSPECTIONS.getName(),
										SecurityRoles.ROLE_SUPERVISOR.getName())
						.antMatchers(
								"/api/companies")
								.hasAnyAuthority(
										SecurityRoles.ROLE_TECHINSP_IAAA.getName(),
										SecurityRoles.ROLE_TECHINSP_CHILD_ORG_UNIT_INSPECTOR.getName(),
										SecurityRoles.ROLE_TECHINSP_INSP_RDAA.getName())
						.antMatchers(HttpMethod.GET, 
								"/api/reports/permits/orders",
								"/api/reports/permits/orders/**")
								.hasAnyAuthority(
										SecurityRoles.ROLE_CALL_CENTER.getName(),
										SecurityRoles.ROLE_ACCOUNTING.getName(),
										SecurityRoles.ROLE_TECHINSP_IAAA.getName(),
										SecurityRoles.ROLE_SUPERVISOR.getName())
						.antMatchers(HttpMethod.GET,
								"/api/reports/logs",
								"/api/reports/logs/**")
								.hasAnyAuthority(
										SecurityRoles.ROLE_CALL_CENTER.getName(),
										SecurityRoles.ROLE_TECHINSP_IAAA.getName())
						.antMatchers(
								"/api/exam-orders/**")
								.hasAnyAuthority(
										SecurityRoles.ROLE_PACKAGING_VOUCHERS.getName(),
										SecurityRoles.ROLE_SUPERVISOR.getName(),
										SecurityRoles.ROLE_ACCOUNTING.getName(), 
										SecurityRoles.ROLE_CALL_CENTER.getName())
						.antMatchers(
								"/api/inspection-bills-of-lading/**")
								.hasAnyAuthority(
										SecurityRoles.ROLE_PACKAGING_INSPECTIONS.getName(),
										SecurityRoles.ROLE_SUPERVISOR.getName())
						.antMatchers(
								"/api/inspections/reports/**")
								.hasAnyAuthority(
										SecurityRoles.ROLE_ADMIN.getName(),
										SecurityRoles.ROLE_CALL_CENTER.getName(),
										SecurityRoles.ROLE_TECHINSP_IAAA.getName())
						.antMatchers(
								"/api/inspections/{id}/semt",
								"/api/inspections/{id}/semt/reg-num",
								"/api/inspections/{id}/semt/approve",
								"/api/inspections/{id}/semt/decline")
								.hasAuthority(SecurityRoles.ROLE_TECHINSP_IAAA.getName())
						.antMatchers(
									"/api/inspections/{id}/secondary-inspection",
									"/api/inspections/{id}/cancel-secondary-inspection")
									.hasAuthority(SecurityRoles.ROLE_TECHINSP_SECONDARY_INSPECTION.getName())
						.antMatchers(
								"/api/inspections/{id}/odometer-history")
								.hasAnyAuthority(
										SecurityRoles.ROLE_ADMIN.getName(),
										SecurityRoles.ROLE_CALL_CENTER.getName(),
										SecurityRoles.ROLE_TECHINSP_IAAA.getName(),
										SecurityRoles.ROLE_TECHINSP_CHILD_ORG_UNIT_INSPECTOR.getName(),
										SecurityRoles.ROLE_TECHINSP_INSP_RDAA.getName())
						.antMatchers(
								"/api/inspections/**",
								"/api/video-download-requests/**",
								"/api/inspections/{id}/international-certificate")
								.hasAnyAuthority(
										SecurityRoles.ROLE_CALL_CENTER.getName(),
										SecurityRoles.ROLE_TECHINSP_INSP_RDAA.getName(),
										SecurityRoles.ROLE_TECHINSP_IAAA.getName(),
										SecurityRoles.ROLE_TECHINSP_INSP_SEARCH_ALL.getName(),
										SecurityRoles.ROLE_TECHINSP_CHILD_ORG_UNIT_INSPECTOR.getName(),
										SecurityRoles.ROLE_TECHINSP_SECONDARY_INSPECTION.getName())
						.antMatchers(
								"/api/bills-of-lading/**")
								.hasAnyAuthority(
										SecurityRoles.ROLE_PACKAGING_INSPECTIONS.getName(),
										SecurityRoles.ROLE_PACKAGING_VOUCHERS.getName(),
										SecurityRoles.ROLE_SUPERVISOR.getName(), 
										SecurityRoles.ROLE_CALL_CENTER.getName())
						.antMatchers(
								"/api/inspection-orders/**",
								"/api/inspection-protocols/**")
								.hasAnyAuthority(
										SecurityRoles.ROLE_PACKAGING_INSPECTIONS.getName(),
										SecurityRoles.ROLE_SUPERVISOR.getName(),
										SecurityRoles.ROLE_ACCOUNTING.getName(), 
										SecurityRoles.ROLE_CALL_CENTER.getName())
						.antMatchers(
								"/api/messages/**",
								"/api/message-attachments/**")
								.hasAnyAuthority(
									SecurityRoles.ROLE_CALL_CENTER.getName(),
									SecurityRoles.ROLE_TECHINSP_MESSAGES_EDIT.getName(),
									SecurityRoles.ROLE_TECHINSP_MESSAGES_VIEW.getName())
						.antMatchers(
								"/api/active-computers/**",
								"/api/hardware-devices/**",
								"/api/hardware-device-transfers/**",
								"/api/consumables/**",
								"/api/consumable-transfers/**",
								"/api/permit-lines/{id}/install-protocol",
								"/api/permit-lines/{id}/retrieve-protocol",
								"/api/permit-lines/**",
								"/api/warehouses/**",
								"/api/permit-problems", 
								"/api/permit-problems/**")
								.hasAuthority(SecurityRoles.ROLE_CALL_CENTER.getName())
						.antMatchers(HttpMethod.GET, 
								"/api/permits", 
								"/api/permits/**",
								"/api/permit-inspectors/**",
								"/api/reports",
								"/api/reports/**")
								.hasAnyAuthority(
										SecurityRoles.ROLE_CALL_CENTER.getName(),
										SecurityRoles.ROLE_TECHINSP_INSP_RDAA.getName(),
										SecurityRoles.ROLE_TECHINSP_CHILD_ORG_UNIT_INSPECTOR.getName(),
										SecurityRoles.ROLE_TECHINSP_IAAA.getName())
						.antMatchers(HttpMethod.GET,
								"/api/dashboard")
								.hasAnyAuthority(
										SecurityRoles.ROLE_TECHINSP_IAAA.getName(),
										SecurityRoles.ROLE_TECHINSP_INSP_RDAA.getName())
						.anyRequest().authenticated()
						.and()
							.formLogin()
								.loginProcessingUrl("/login").usernameParameter("username").passwordParameter("password")
								.successHandler(this.authenticationSuccessHandler)
								.failureHandler(this.authenticationFailureHandler)
						.and()
							.rememberMe()
							.userDetailsService(this.userService)
							.rememberMeCookieName("remember-me")
						.and()
							.logout()
								.logoutUrl("/logout")
								.logoutSuccessHandler((new HttpStatusReturningLogoutSuccessHandler(HttpStatus.OK)))
								.invalidateHttpSession(true).deleteCookies("JSESSIONID", "_csrf", "remember-me")
								.clearAuthentication(true);

	}
	// @formatter:on

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new DemaxPasswordEncoder();
	}

	private CsrfTokenRepository csrfTokenRepository() {
		CookieCsrfTokenRepository repository = new CookieCsrfTokenRepository();
		repository.setCookieHttpOnly(false);
		repository.setCookieName("_csrf");
		repository.setHeaderName("X-CSRF-TOKEN");

		return repository;
	}

}
