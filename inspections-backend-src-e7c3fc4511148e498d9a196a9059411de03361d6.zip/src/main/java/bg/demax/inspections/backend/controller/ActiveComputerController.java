package bg.demax.inspections.backend.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.inspections.backend.controller.param.ActiveComputerQueryParams;
import bg.demax.inspections.backend.dto.ActiveComputerDto;
import bg.demax.inspections.backend.entity.ActiveComputer;
import bg.demax.inspections.backend.search.ActiveComputerSearch;
import bg.demax.inspections.backend.service.ActiveComputerService;
import bg.demax.legacy.util.convert.ConversionService;

@RestController
@RequestMapping("/api/active-computers")
public class ActiveComputerController {

	@Autowired
	private ActiveComputerService activeComputerService;

	@Autowired
	private ConversionService conversionService;

	@GetMapping
	public List<ActiveComputerDto> getActiveComputers(@Valid ActiveComputerQueryParams queryParams) {
		ActiveComputerSearch search = conversionService.convert(queryParams, ActiveComputerSearch.class);
		List<ActiveComputer> activeComputers = activeComputerService.getBySearch(search);
		return conversionService.convertList(activeComputers, ActiveComputerDto.class);
	}
}

