package bg.demax.inspections.backend.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;

import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.PaginationQueryParams;
import bg.demax.inspections.backend.dto.DashboardInfoDto;
import bg.demax.inspections.backend.dto.DashboardStatusDto;
import bg.demax.inspections.backend.dto.techinsp.DashboardInspectorCertificationDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDocumentListItemDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorDocumentsReportListItemDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineDocumentReportListItemDto;
import bg.demax.inspections.backend.search.DashboardPermitAppliedDocumentsReportSearch;
import bg.demax.inspections.backend.search.DashboardPermitInspectorCertificationSearch;
import bg.demax.inspections.backend.search.DashboardPermitInspectorDocumentsReportSearch;
import bg.demax.inspections.backend.search.DashboardPermitLineDocumentsReportSearch;
import bg.demax.inspections.backend.search.PermitVersionSearch;
import bg.demax.inspections.backend.service.SystemVariablesService;
import bg.demax.inspections.backend.service.permit.PermitDocumentService;
import bg.demax.inspections.backend.service.permit.PermitService;
import bg.demax.inspections.backend.service.permit.inspector.SubjectVersionDocumentService;
import bg.demax.inspections.backend.service.permit.line.PermitLineDocumentService;
import bg.demax.techinsp.entity.PermitStatus;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

	@Autowired
	private PermitService permitService;

	@Autowired
	private PermitDocumentService permitDocumentService;

	@Autowired
	private SubjectVersionDocumentService subjectVersionDocumentService;
	
	@Autowired
	private PermitLineDocumentService permitLineDocumentService;

	@Autowired
	private SystemVariablesService systemVariablesService;

	@GetMapping
	public DashboardInfoDto getDashboardInfo() {
		DashboardInfoDto result = new DashboardInfoDto();

		PermitVersionSearch search = new PermitVersionSearch();
		search.setStatusCode(PermitStatus.REQUESTED_CODE);
		result.setRequestedPermitsCount(permitService.getPermitCountBySearch(search));

		search.setStatusCode(PermitStatus.PROCESSING_CODE);
		result.setProcessingPermitsCount(permitService.getPermitCountBySearch(search));

		result.setRemainingDaysBeforeExpirationCount(systemVariablesService.getDaysUntilExpiration());

		return result;
	}

	@GetMapping("/permits/documents")
	public PageResult<PermitDocumentListItemDto> getPermitDocumentsList(
					@Valid PaginationQueryParams paginationParams, @Valid DashboardStatusDto status) 
							throws JsonProcessingException {
		DashboardPermitAppliedDocumentsReportSearch search = new DashboardPermitAppliedDocumentsReportSearch();
		search.setStatusCode(status.getStatusCode());

		PageResult<PermitDocumentListItemDto> pageResult = permitDocumentService
			.getDashboardExpiredOrExpiringDocuments(search);
		
		return pageResult;
	}

	@GetMapping("/inspectors/documents")
	public PageResult<PermitInspectorDocumentsReportListItemDto> getPermitInspectorDocumentsList(
					@Valid PaginationQueryParams paginationParams, @Valid DashboardStatusDto status) 
							throws JsonProcessingException {
		DashboardPermitInspectorDocumentsReportSearch search = new DashboardPermitInspectorDocumentsReportSearch();
		search.setDocumentStatusCode(status.getStatusCode());

		PageResult<PermitInspectorDocumentsReportListItemDto> pageResult = subjectVersionDocumentService
				.getExpiringAndRequiredPermitInspectorDocuments(search, paginationParams.getPage(), paginationParams.getPageSize());
		
		return pageResult;
	}

	@GetMapping("/inspectors/certifications")
	public PageResult<DashboardInspectorCertificationDto> getPermitInspectorCertificationsList(
					@Valid PaginationQueryParams paginationParams, @Valid DashboardStatusDto status) 
							throws JsonProcessingException {
		DashboardPermitInspectorCertificationSearch search = new DashboardPermitInspectorCertificationSearch();
		search.setCertificationStatusCode(status.getStatusCode());

		PageResult<DashboardInspectorCertificationDto> pageResult = subjectVersionDocumentService
				.getExpiringPermitInspectorCertification(search, paginationParams.getPage(), paginationParams.getPageSize());
		
		return pageResult;
	}
	
	@GetMapping("/lines/documents")
	public PageResult<PermitLineDocumentReportListItemDto> getPermitLineDocumentsReportList(
			@Valid PaginationQueryParams paginationParams, @Valid DashboardStatusDto status)
			throws JsonProcessingException {
		DashboardPermitLineDocumentsReportSearch search = new DashboardPermitLineDocumentsReportSearch();
		search.setStatusCode(status.getStatusCode());

		PageResult<PermitLineDocumentReportListItemDto> pageResult = permitLineDocumentService
				.getPermitLineDocumentsForDashboardByStatus(search, paginationParams.getPage(), paginationParams.getPageSize());
		
		return pageResult;
	}

}