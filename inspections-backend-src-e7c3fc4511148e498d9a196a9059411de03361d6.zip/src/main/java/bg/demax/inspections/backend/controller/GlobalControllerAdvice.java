package bg.demax.inspections.backend.controller;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import bg.demax.inspections.backend.dto.ApplicationExceptionDto;
import bg.demax.inspections.backend.dto.ValidationErrorDto;
import bg.demax.inspections.backend.dto.equipment.HardwareDeviceExceptionDto;
import bg.demax.inspections.backend.dto.inspections.PermitInspectorExceptionDto;
import bg.demax.inspections.backend.dto.techinsp.messages.MessageAttachmentTooBigExceptionDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitErrorsExceptionDto;
import bg.demax.inspections.backend.exception.ApplicationException;
import bg.demax.inspections.backend.exception.BillOfLadingAlreadyExistsException;
import bg.demax.inspections.backend.exception.BillOfLadingCreationException;
import bg.demax.inspections.backend.exception.BillOfLadingPdfException;
import bg.demax.inspections.backend.exception.HardwareDeviceIsAlreadyInThisWarehouseException;
import bg.demax.inspections.backend.exception.HardwareDeviceIsAtInspectionStationException;
import bg.demax.inspections.backend.exception.HardwareDeviceIsNotAtWarehouseTsarigradskoShoseException;
import bg.demax.inspections.backend.exception.InspectionImageNotFoundException;
import bg.demax.inspections.backend.exception.InspectionShortVideoNotFoundException;
import bg.demax.inspections.backend.exception.InspectionSignatureNotFoundException;
import bg.demax.inspections.backend.exception.InspectorNotFoundForPermitException;
import bg.demax.inspections.backend.exception.InvalidHardwareDeviceLocationException;
import bg.demax.inspections.backend.exception.NoAuthorityException;
import bg.demax.inspections.backend.exception.NoRightsForOrgUnitException;
import bg.demax.inspections.backend.exception.NoSuchEntityException;
import bg.demax.inspections.backend.exception.PermitErrorsException;
import bg.demax.inspections.backend.exception.ValidationException;
import bg.demax.inspections.backend.exception.permit.inspector.PermitInspectorAlreadyHasDraftSnapshotException;
import bg.demax.inspections.backend.exception.permit.inspector.PermitInspectorIsInAnotherCompanyException;
import bg.demax.inspections.backend.service.techinsp.MessageAttachmentTooBigException;
import bg.demax.legacy.util.convert.ConversionService;

@RestControllerAdvice
public class GlobalControllerAdvice extends ResponseEntityExceptionHandler {

	private static final Logger logger = LogManager.getLogger(GlobalControllerAdvice.class);
	private static final String NO_MESSAGE = "_NO_MESSAGE_";

	@Autowired
	private ConversionService conversionService;

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers,
					HttpStatus status, WebRequest request) {
		BindingResult bindingResult = ex.getBindingResult();
		ValidationErrorDto dto = createValidationErrorDto(bindingResult, request.getLocale());
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		return handleExceptionInternal(ex, dto, headers, status, request);
	}

	@Override
	protected ResponseEntity<Object> handleBindException(BindException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
		BindingResult bindingResult = ex.getBindingResult();
		ValidationErrorDto dto = createValidationErrorDto(bindingResult, request.getLocale());
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		return handleExceptionInternal(ex, dto, headers, status, request);
	}
	
	@Override
	protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers, HttpStatus status,
					WebRequest request) {
		logger.debug("", ex);
		return super.handleExceptionInternal(ex, body, headers, status, request);
	}

	private ValidationErrorDto createValidationErrorDto(BindingResult bindingResult, Locale locale) {
		List<FieldError> fieldErrors = bindingResult.getFieldErrors();
		List<ObjectError> globalErrors = bindingResult.getGlobalErrors();
		ValidationErrorDto dto = new ValidationErrorDto();
		for (FieldError fieldError : fieldErrors) {
			String field = fieldError.getField();
			String message = fieldError.getDefaultMessage();
			if (fieldError.isBindingFailure()) {
				message = NO_MESSAGE;
			}
			dto.addError(field, message);
		}
		for (ObjectError globalError : globalErrors) {
			dto.addError(globalError.getObjectName(), globalError.getDefaultMessage());
		}
		return dto;
	}

	@ExceptionHandler(BillOfLadingCreationException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public ApplicationExceptionDto handleBillOfLadingCreationException(BillOfLadingCreationException ex, HttpServletRequest request) {
		return convertException(ex, request);
	}

	@ExceptionHandler(BillOfLadingPdfException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public ApplicationExceptionDto handleCourierServiceException(BillOfLadingPdfException ex, HttpServletRequest request) {
		return convertException(ex, request);
	}

	@ExceptionHandler(BillOfLadingAlreadyExistsException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public ApplicationExceptionDto handleBillOfLadingAlreadyExistsException(BillOfLadingAlreadyExistsException ex,
					HttpServletRequest request) {
		return convertException(ex, request);
	}

	@ExceptionHandler(ApplicationException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public ApplicationExceptionDto handleApplicationException(ApplicationException ex, HttpServletRequest request) {
		return convertException(ex, request);
	}

	@ExceptionHandler(HardwareDeviceIsAlreadyInThisWarehouseException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public HardwareDeviceExceptionDto handleHardwareDeviceIsAlreadyInThisWarehouseException(
					HardwareDeviceIsAlreadyInThisWarehouseException ex, HttpServletRequest request) {
		setResponseTypeToJson(request);
		return conversionService.convert(ex, HardwareDeviceExceptionDto.class);
	}

	@ExceptionHandler(HardwareDeviceIsAtInspectionStationException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public HardwareDeviceExceptionDto handleHardwareDeviceIsAtInspectionStationException(HardwareDeviceIsAtInspectionStationException ex,
					HttpServletRequest request) {
		setResponseTypeToJson(request);
		return conversionService.convert(ex, HardwareDeviceExceptionDto.class);
	}

	@ExceptionHandler(HardwareDeviceIsNotAtWarehouseTsarigradskoShoseException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public HardwareDeviceExceptionDto handleHardwareDeviceIsNotAtWarehouseTsarigradskoShoseException(
					HardwareDeviceIsNotAtWarehouseTsarigradskoShoseException ex, HttpServletRequest request) {
		setResponseTypeToJson(request);
		return conversionService.convert(ex, HardwareDeviceExceptionDto.class);
	}
	
	@ExceptionHandler(MessageAttachmentTooBigException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public MessageAttachmentTooBigExceptionDto handleHardwareDeviceIsNotAtWarehouseTsarigradskoShoseException(
					MessageAttachmentTooBigException ex, HttpServletRequest request) {
		setResponseTypeToJson(request);
		return conversionService.convert(ex, MessageAttachmentTooBigExceptionDto.class);
	}

	@ExceptionHandler(InvalidHardwareDeviceLocationException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public HardwareDeviceExceptionDto handleInvalidHardwareDeviceLocationException(InvalidHardwareDeviceLocationException ex,
					HttpServletRequest request) {
		setResponseTypeToJson(request);
		return conversionService.convert(ex, HardwareDeviceExceptionDto.class);
	}

	@ExceptionHandler(NoSuchEntityException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ApplicationExceptionDto handleNoSuchEntityException(NoSuchEntityException ex, HttpServletRequest request) {
		setResponseTypeToJson(request);
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError(ex.getClass().getSimpleName());
		dto.setMessage(ex.getMessage());
		return dto;
	}
	
	@ExceptionHandler(InspectorNotFoundForPermitException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ApplicationExceptionDto handleInspectorNotFoundForPermitException(InspectorNotFoundForPermitException ex,
					HttpServletRequest request) {
		setResponseTypeToJson(request);
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError(ex.getClass().getSimpleName());
		dto.setMessage(ex.getMessage());
		return dto;
	}

	@ExceptionHandler(InspectionSignatureNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ApplicationExceptionDto handleInspectionSignatureNotFoundException(InspectionSignatureNotFoundException ex,
					HttpServletRequest request) {
		setResponseTypeToJson(request);
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError(ex.getClass().getSimpleName());
		dto.setMessage(ex.getMessage());
		return dto;
	}

	@ExceptionHandler(InspectionImageNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ApplicationExceptionDto handleInspectionSignatureNotFoundException(InspectionImageNotFoundException ex,
					HttpServletRequest request) {
		setResponseTypeToJson(request);
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError(ex.getClass().getSimpleName());
		dto.setMessage(ex.getMessage());
		return dto;
	}

	@ExceptionHandler(InspectionShortVideoNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ApplicationExceptionDto handleInspectionSignatureNotFoundException(InspectionShortVideoNotFoundException ex,
					HttpServletRequest request) {
		setResponseTypeToJson(request);
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError(ex.getClass().getSimpleName());
		dto.setMessage(ex.getMessage());
		return dto;
	}

	@ExceptionHandler(NoAuthorityException.class)
	@ResponseStatus(HttpStatus.FORBIDDEN)
	public ApplicationExceptionDto handleNoAuthorityException(NoAuthorityException ex, HttpServletRequest request) {
		setResponseTypeToJson(request);
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError(ex.getClass().getSimpleName());
		dto.setMessage(ex.getMessage());
		return dto;
	}
	
	@ExceptionHandler(ValidationException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ApplicationExceptionDto handleValidationExceptions(ValidationException ex, HttpServletRequest request) {
		setResponseTypeToJson(request);
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError(ex.getClass().getSimpleName());
		dto.setMessage(ex.getMessage());
		return dto;
	}
	
	@ExceptionHandler(PermitErrorsException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public PermitErrorsExceptionDto handlePermitErrorsExceptions(PermitErrorsException ex, HttpServletRequest request) {
		setResponseTypeToJson(request);
		PermitErrorsExceptionDto dto = new PermitErrorsExceptionDto();
		dto.setErrors(ex.getErrorsDto());
		return dto;
	}

	@ExceptionHandler
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ApplicationExceptionDto handleUnhandledExceptions(Exception ex, HttpServletRequest request) {
		if (!ex.getClass().getCanonicalName().equals("org.apache.catalina.connector.ClientAbortException")) {
			logger.error("Caught unhandled exception: ", ex);
		}
		setResponseTypeToJson(request);
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError("Exception");
		return dto;
	}
	
	@ExceptionHandler(ConstraintViolationException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ApplicationExceptionDto handleConstraintViolationException(ConstraintViolationException ex, HttpServletRequest request) {
		setResponseTypeToJson(request);
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError(ex.getClass().getSimpleName());
		dto.setMessage(ex.getMessage());
		return dto;
	}

	@ExceptionHandler(PermitInspectorAlreadyHasDraftSnapshotException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public PermitInspectorExceptionDto handlePermitInspectorAlreadyHasDraftSnapshotException(
					PermitInspectorAlreadyHasDraftSnapshotException ex, HttpServletRequest request) {

		setResponseTypeToJson(request);
		PermitInspectorExceptionDto dto = new PermitInspectorExceptionDto();
		dto.setError(ex.getClass().getSimpleName());
		dto.setMessage(ex.getMessage());
		dto.setPermits(ex.getPermits());

		return dto;
	}

	@ExceptionHandler(PermitInspectorIsInAnotherCompanyException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public PermitInspectorExceptionDto handlePermitInspectorIsInAnotherCompanyException(PermitInspectorIsInAnotherCompanyException ex,
					HttpServletRequest request) {

		setResponseTypeToJson(request);
		PermitInspectorExceptionDto dto = new PermitInspectorExceptionDto();
		dto.setError(ex.getClass().getSimpleName());
		dto.setMessage(ex.getMessage());
		dto.setPermits(ex.getPermits());

		return dto;
	}

	@ExceptionHandler(NoRightsForOrgUnitException.class)
	@ResponseStatus(HttpStatus.FORBIDDEN)
	public ApplicationExceptionDto handleNoRightsForOrgUnitException(
			NoRightsForOrgUnitException ex, HttpServletRequest request) {
		return convertException(ex, request);
	}

	private void setResponseTypeToJson(HttpServletRequest request) {
		request.setAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE, Collections.singleton(MediaType.APPLICATION_JSON_UTF8));
	}

	private ApplicationExceptionDto convertException(ApplicationException ex, HttpServletRequest request) {
		setResponseTypeToJson(request);
		return conversionService.convert(ex, ApplicationExceptionDto.class);
	}
}
