package bg.demax.inspections.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.inspections.backend.dto.AppliedDocumentTypeDto;
import bg.demax.inspections.backend.dto.CityDto;
import bg.demax.inspections.backend.dto.CountryDto;
import bg.demax.inspections.backend.dto.KtpCategoryDto;
import bg.demax.inspections.backend.dto.OrgUnitLightDto;
import bg.demax.inspections.backend.dto.RegionDto;
import bg.demax.inspections.backend.dto.inspections.EducationLevelDto;
import bg.demax.inspections.backend.dto.orders.InspectionOrderStatusDto;
import bg.demax.inspections.backend.dto.techinsp.EcoCategoryDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypeDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineInspectionTypeDto;
import bg.demax.inspections.backend.service.AppliedDocumentTypesService;
import bg.demax.inspections.backend.service.CityService;
import bg.demax.inspections.backend.service.NomenclaturesService;
import bg.demax.inspections.backend.service.OrgUnitService;
import bg.demax.inspections.backend.service.RegionService;

@RestController
@RequestMapping("/api/nomenclatures")
public class NomenclaturesController {

	@Autowired
	private OrgUnitService orgUnitService;
	
	@Autowired
	private CityService cityService;
	
	@Autowired
	private RegionService regionService;
	
	@Autowired
	private AppliedDocumentTypesService documentService;
	
	@Autowired
	private NomenclaturesService nomenclaturesService;

	@GetMapping("/org-units")
	public List<OrgUnitLightDto> getValidOrgUnits() {
		List<OrgUnitLightDto> orgUnits = orgUnitService.getValidOrgUnits();
		return orgUnits;
	}
	
	@GetMapping("/permit-document-types")
	public List<AppliedDocumentTypeDto> getDocumentTypesForPermits() {
		return documentService.getDocumentTypesForPermits();
	}
	
	@GetMapping("/permit-document-types/inspectors")
	public List<AppliedDocumentTypeDto> getDocumentTypesForPermitInspectors() {
		return documentService.getDocumentTypesForPermitInspectors();
	}
	
	@GetMapping("/permit-document-types/lines")
	public List<AppliedDocumentTypeDto> getDocumentTypesForPermitLine() {
		return documentService.getDocumentTypesForPermitLines();
	}

	@GetMapping("/cities")
	public List<CityDto> getCitiesByOrgUnitCode(@RequestParam String orgUnitCode) {
		return cityService.getCitiesByOrgUnitCode(orgUnitCode);
	}
	
	@GetMapping("regions/{code}/cities")
	public List<CityDto> getCitiesByRegionCode(@PathVariable("code") String code) {
		return cityService.getCitiesByRegionCode(code);
	}
	
	@GetMapping("/regions")
	public List<RegionDto> getAllRegions() {
		return regionService.getAllRegions();
	}

	@GetMapping("/countries")
	public List<CountryDto> getCountries() {
		List<CountryDto> countries = nomenclaturesService.getCountries();
		return countries;
	}
	
	@GetMapping("/ktp-categories")
	public List<KtpCategoryDto> getAllKtpCategories() {
		return nomenclaturesService.getAllKtpCategories();
	}

	@GetMapping("/vehicle-categories/code")
	public List<String> getAllVehicleCategoryCodes() {
		return nomenclaturesService.getAllVehicleCategoryCodes();
	}
	
	@GetMapping("/inspection-types-categories")
	public List<PermitLineInspectionTypeDto> getAllInspectionTypesAndCategories() {
		return nomenclaturesService.getAllInspectionTypesAndCategories();
	}
	
	@GetMapping("/inspection-types")
	public List<InspectionTypeDto> getAllInspectionTypes() {
		return nomenclaturesService.getAllInspectionTypes();
	}
	
	@GetMapping("/inspection-orders-statuses")
	public List<InspectionOrderStatusDto> getInspectionOrderStatuses() {
		return nomenclaturesService.getInspectionOrderStatuses();
	}
	
	@GetMapping("/eco-categories")
	public List<EcoCategoryDto> getAllEcoCategories() {
		return nomenclaturesService.getEcoCategories();
	}
	
	@GetMapping("/education-levels")
	public List<EducationLevelDto> getAllEducationLevels() {
		return nomenclaturesService.getEducationLevels();
	}
}
