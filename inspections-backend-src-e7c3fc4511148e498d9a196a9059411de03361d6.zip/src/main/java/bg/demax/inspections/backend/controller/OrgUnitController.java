package bg.demax.inspections.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.inspections.backend.dto.OrgUnitInspectionOrdersLightDto;
import bg.demax.inspections.backend.dto.OrgUnitInspectionOrdersVo;
import bg.demax.inspections.backend.dto.OrgUnitLightDto;
import bg.demax.inspections.backend.service.OrgUnitService;
import bg.demax.legacy.util.convert.ConversionService;

@RestController
@RequestMapping("/api/org-units")
public class OrgUnitController {

	@Autowired
	private OrgUnitService orgUnitService;
	
	@Autowired
	private ConversionService conversionService;
	
	@GetMapping("without-iaaa")
	public List<OrgUnitLightDto> getValidOrgUnitsWithoutIaaa() {
		return orgUnitService.getOrgUnitUnderControlForUser();
	}
	
	@GetMapping("inspection-orders")
	public List<OrgUnitInspectionOrdersLightDto> getOrgUnitsInspectionOrders() {
		List<OrgUnitInspectionOrdersVo> voList = orgUnitService.getOrgUnitsInspectionOrders();
		List<OrgUnitInspectionOrdersLightDto> dtoList = conversionService.convertList(voList, OrgUnitInspectionOrdersLightDto.class);
		
		return dtoList;
	}
}
