package bg.demax.inspections.backend.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.inspections.backend.controller.param.CurrentUserPasswordChangeParams;
import bg.demax.inspections.backend.dto.UserDto;
import bg.demax.inspections.backend.service.UserService;

@RestController
@RequestMapping("/api/users")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@GetMapping("current")
	public UserDto getCurrentUser() {
		return userService.getCurrentUser();
	}
	
	@PostMapping("/current/change-password")
	public void changeCurrentUserPassword(@Valid @RequestBody CurrentUserPasswordChangeParams requestParams) {
		userService.changeCurrentUserPassword(requestParams);
	}
}
