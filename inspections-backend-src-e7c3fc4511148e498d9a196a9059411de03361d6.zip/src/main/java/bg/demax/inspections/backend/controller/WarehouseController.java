package bg.demax.inspections.backend.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.inspections.backend.dto.WarehouseShippingInfoDto;
import bg.demax.inspections.backend.dto.equipment.HardwareDevicesRequestDto;
import bg.demax.inspections.backend.service.WarehouseShippingInfoService;
import bg.demax.inspections.backend.service.equipment.HardwareDeviceService;
import bg.demax.inspections.backend.vo.HardwareDeviceVo;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.pub.entity.hardware.WarehouseShippingInfo;

@RestController
@RequestMapping("/api/warehouses")
public class WarehouseController {

	@Autowired
	private WarehouseShippingInfoService warehouseShippingInfoService;

	@Autowired
	private HardwareDeviceService hardwareDeviceService;

	@Autowired
	private ConversionService conversionService;

	@GetMapping("/{id}/shipping-info")
	public WarehouseShippingInfoDto getWarehouseShippingInfo(@PathVariable("id") int warehouseId) {
		WarehouseShippingInfo warehouseShippingInfo = warehouseShippingInfoService.getInitializedByWarehouseId(warehouseId);
		return conversionService.convert(warehouseShippingInfo, WarehouseShippingInfoDto.class);
	}

	@PutMapping("/{id}/hardware-devices")
	public void assignWarehouseToHardwareDevices(@PathVariable("id") int warehouseId,
					@Valid @RequestBody HardwareDevicesRequestDto requestDto) {
		List<HardwareDeviceVo> hardwareDeviceVos = conversionService.convertList(requestDto.getHardwareDevices(), HardwareDeviceVo.class);
		hardwareDeviceService.assignWarehouseToHardwareDevices(warehouseId, hardwareDeviceVos);
	}
}