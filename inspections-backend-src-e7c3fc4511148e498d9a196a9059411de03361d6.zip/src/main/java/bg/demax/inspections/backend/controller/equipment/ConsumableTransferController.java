package bg.demax.inspections.backend.controller.equipment;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.courier.services.dto.AccountDto;
import bg.demax.courier.services.dto.BillOfLadingRequestDto;
import bg.demax.courier.services.dto.BillOfLadingResponseDto;
import bg.demax.courier.services.econt.web.EcontClient;
import bg.demax.courier.services.exception.CourierServiceException;
import bg.demax.courier.services.speedy.web.SpeedyClient;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.equipment.ConsumableTransfersQueryParams;
import bg.demax.inspections.backend.dto.equipment.ConsumableTransferBillOfLadingDto;
import bg.demax.inspections.backend.dto.equipment.ConsumableTransferBillOfLadingRowDto;
import bg.demax.inspections.backend.dto.equipment.ConsumableTransferCreationRequestDto;
import bg.demax.inspections.backend.entity.Courier.Couriers;
import bg.demax.inspections.backend.exception.BillOfLadingCreationException;
import bg.demax.inspections.backend.search.equipment.ConsumableTransfersSearch;
import bg.demax.inspections.backend.service.BillOfLadingService;
import bg.demax.inspections.backend.service.equipment.ConsumableTransferBillOfLadingService;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.pub.entity.hardware.ConsumableTransferBillOfLading;

@RestController
@RequestMapping("/api/consumable-transfers")
public class ConsumableTransferController {

	@Autowired
	ConversionService conversionService;

	@Autowired
	ConsumableTransferBillOfLadingService consumableTransferBillOfLadingService;

	@Autowired
	BillOfLadingService billOfLadingService;

	@Autowired
	private SpeedyClient speedyClient;

	@Autowired
	private EcontClient econtClient;

	@GetMapping
	public PageResult<ConsumableTransferBillOfLadingRowDto> getConsumableTrasnfers(@Valid PageRequest pageRequest,
			@Valid ConsumableTransfersQueryParams queryParams) {
		ConsumableTransfersSearch search = new ConsumableTransfersSearch();
		BeanUtils.copyProperties(queryParams, search);

		PageResult<ConsumableTransferBillOfLading> transfers = consumableTransferBillOfLadingService
				.getTransfers(pageRequest, search);

		List<ConsumableTransferBillOfLadingRowDto> transfersDto = conversionService.convertList(transfers.getItems(),
				ConsumableTransferBillOfLadingRowDto.class);

		return new PageResult<ConsumableTransferBillOfLadingRowDto>(transfersDto, transfers.getTotalCount());
	}

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public void createTransfer(@Valid @RequestBody ConsumableTransferCreationRequestDto requestParamsDto) {
		ConsumableTransferBillOfLading billOfLading = conversionService.convert(requestParamsDto,
				ConsumableTransferBillOfLading.class);
		BillOfLadingRequestDto requestDto = consumableTransferBillOfLadingService
				.createBillOfLadingRequestDto(billOfLading);

		BillOfLadingResponseDto responseDto = new BillOfLadingResponseDto();

		String courierCode = billOfLading.getCourier().getCode();

		String billOfLadingIdString = null;
		try {

			if (!courierCode.equals(Couriers.DEMAX.getCode())) {
				AccountDto courierAccount = consumableTransferBillOfLadingService.getUserCourierAccounDto(courierCode);

				if (courierCode.equals(Couriers.SPEEDY.getCode())) {
					responseDto = speedyClient.createBillOfLading(requestDto, courierAccount);
				} else if (courierCode.equals(Couriers.ECONT.getCode())) {
					responseDto = econtClient.createBillOfLading(requestDto, courierAccount);
				}
				if (responseDto == null) {
					throw new CourierServiceException("BillOfLadingResponseDto is Null!");
				}

				billOfLadingIdString = String.valueOf(responseDto.getBillOfLadingId());
			}

			consumableTransferBillOfLadingService.saveConsumableTransferBillOfLading(billOfLading,
					billOfLadingIdString);
		} catch (CourierServiceException cse) {
			throw new BillOfLadingCreationException(cse.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	@GetMapping("/{id}")
	public ConsumableTransferBillOfLadingDto getBillOfLadingById(@PathVariable int id) {
		ConsumableTransferBillOfLading billOfLading = consumableTransferBillOfLadingService.getBillOfLadingById(id);
		return conversionService.convert(billOfLading, ConsumableTransferBillOfLadingDto.class);
	}

	@PostMapping("/bill-of-ladings/{id}/sent")
	public void setBillOfLadingStatusToSent(@PathVariable("id") int billOfLadingId) {
		consumableTransferBillOfLadingService.setBillOfLadingStatusToSent(billOfLadingId);
	}

	@PostMapping("/bill-of-ladings")
	public void setAllNotSentBillOfLadingsStatusesToSent() {
		consumableTransferBillOfLadingService.setAllNotSentBillOfLadingsStatusesToSent();
	}
}