package bg.demax.inspections.backend.controller.equipment;

import java.io.ByteArrayOutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.hibernate.paging.PageRequest;
import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.PaginationQueryParams;
import bg.demax.inspections.backend.controller.param.equipment.HardwareDeviceCreationRequestDto;
import bg.demax.inspections.backend.controller.param.equipment.HardwareDeviceQueryParams;
import bg.demax.inspections.backend.dto.equipment.HardwareBySerialNumberDto;
import bg.demax.inspections.backend.dto.equipment.HardwareDeviceDto;
import bg.demax.inspections.backend.dto.equipment.HardwareDeviceLightResponseDto;
import bg.demax.inspections.backend.dto.equipment.HardwareDeviceUpdateRequestDto;
import bg.demax.inspections.backend.entity.HardwareDevice;
import bg.demax.inspections.backend.exception.HardwareDeviceWithSerialNumberAlreadyExistsException;
import bg.demax.inspections.backend.export.equipment.HardwareDeviceReport;
import bg.demax.inspections.backend.export.equipment.HardwareDeviceReportExporter;
import bg.demax.inspections.backend.search.equipment.HardwareDeviceSearch;
import bg.demax.inspections.backend.service.equipment.HardwareDeviceService;
import bg.demax.inspections.backend.vo.HardwareDeviceReportVo;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.pub.entity.hardware.Device;
import bg.demax.pub.entity.hardware.DeviceType;
import bg.demax.pub.entity.hardware.SimCard;
import bg.demax.pub.entity.hardware.Store;

@RestController
@RequestMapping("/api/hardware-devices")
public class HardwareDeviceController {

	@Autowired
	private ConversionService conversionService;

	@Autowired
	private HardwareDeviceService hardwareDeviceService;

	@Autowired
	private HardwareDeviceReportExporter hardwareDeviceReportExporter;

	@GetMapping
	public PageResult<HardwareDeviceDto> getHardwareDevices(@Valid PaginationQueryParams paginationParams,
					@Valid HardwareDeviceQueryParams queryParams) {

		PageRequest pageRequest = new PageRequest();
		BeanUtils.copyProperties(paginationParams, pageRequest);
		HardwareDeviceSearch search = conversionService.convert(queryParams, HardwareDeviceSearch.class);
		return hardwareDeviceService.getPagedBySearch(pageRequest, search);
	}

	@GetMapping(value = "/xls", produces = "application/vnd.ms-excel")
	public byte[] getHardwareDevicesAsXlsFile(@Valid HardwareDeviceQueryParams queryParams, HttpServletResponse response) {
		response.setHeader("content-disposition", "attachment; filename=hardware-devices.xlsx");
		HardwareDeviceSearch search = conversionService.convert(queryParams, HardwareDeviceSearch.class);
		HardwareDeviceReportVo vo = hardwareDeviceService.getBySearch(search);
		HardwareDeviceReport report = new HardwareDeviceReport(vo.getDevices(), vo.getFiltersText());
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		hardwareDeviceReportExporter.exportXls(report, outputStream);
		return outputStream.toByteArray();
	}

	@PatchMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public void updateHardwareDevice(@PathVariable("id") int deviceId, @Valid @RequestBody HardwareDeviceUpdateRequestDto requestDto) {
		if (requestDto.getTypeCode().equals(DeviceType.VIVACOM_SIM_CARD_CODE)
						|| requestDto.getTypeCode().equals(DeviceType.GLOBUL_SIM_CARD_CODE)) {
			SimCard sim = conversionService.convert(requestDto, SimCard.class);
			sim.setId(deviceId);
			hardwareDeviceService.update(sim);
		} else {
			Device device = conversionService.convert(requestDto, Device.class);
			device.setId(deviceId);
			hardwareDeviceService.update(device);
		}
	}

	@GetMapping("/{id}/{code}")
	public HardwareDeviceLightResponseDto getHardwareDeviceById(@PathVariable("id") Integer id, @PathVariable("code") Short code) {

		if (code == DeviceType.GLOBUL_SIM_CARD_CODE || code == DeviceType.VIVACOM_SIM_CARD_CODE) {
			return hardwareDeviceService.getSimCardByIdAndTypeCode(id, code);
		} else {
			return hardwareDeviceService.getDeviceByIdAndTypeCode(id, code);
		}
	}

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public void addHardware(@RequestBody @Valid HardwareDeviceCreationRequestDto dto) {
		if (hardwareDeviceService.isHardwareDeviceAlreadyCreated(dto.getDeviceTypeCode(), dto.getSerialNumber())) {
			throw new HardwareDeviceWithSerialNumberAlreadyExistsException(
							"Hardware Device with serial number " + dto.getSerialNumber() + " already exists!");
		}
		if (dto.getDeviceTypeCode() == DeviceType.GLOBUL_SIM_CARD_CODE || dto.getDeviceTypeCode() == DeviceType.VIVACOM_SIM_CARD_CODE) {
			SimCard simCard = conversionService.convert(dto, SimCard.class);
			hardwareDeviceService.createSimCard(simCard);
		} else {
			Device device = conversionService.convert(dto, Device.class);
			hardwareDeviceService.createDevice(device);
		}
	}

	@GetMapping("/{serialNumber}")
	public PageResult<HardwareBySerialNumberDto> getHardwareBySerialNumber(@PathVariable("serialNumber") String serialNumber) {
		List<HardwareDevice> devices = hardwareDeviceService.getBySerialNumber(serialNumber);
		List<HardwareBySerialNumberDto> response = conversionService.convertList(devices, HardwareBySerialNumberDto.class);
		return new PageResult<>(response, response.size());
	}
	
	@GetMapping("/{serialNumber}/for-line")
	public PageResult<HardwareBySerialNumberDto> getHardwareBySerialNumberForLine(@PathVariable("serialNumber") String serialNumber) {
		List<HardwareBySerialNumberDto> response = hardwareDeviceService.getBySerialNumberAndStoreCode(serialNumber, Store.WAREHOUSE);
		return new PageResult<>(response, response.size());
	}
}