package bg.demax.inspections.backend.controller.equipment;

import java.io.ByteArrayOutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.hibernate.paging.PageRequest;
import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.equipment.HardwareDeviceTransfersQueryParams;
import bg.demax.inspections.backend.dto.IdentifierDto;
import bg.demax.inspections.backend.dto.equipment.HardwareDeviceTransferBillOfLadingDto;
import bg.demax.inspections.backend.dto.equipment.HardwareDeviceTransferBillOfLadingRowDto;
import bg.demax.inspections.backend.dto.equipment.HardwareDeviceTransferCreationRequestDto;
import bg.demax.inspections.backend.export.equipment.HardwareDeviceTransferProtocolReport;
import bg.demax.inspections.backend.export.equipment.HardwareDeviceTransferProtocolReportExporter;
import bg.demax.inspections.backend.search.equipment.HardwareDeviceTransfersSearch;
import bg.demax.inspections.backend.service.BillOfLadingService;
import bg.demax.inspections.backend.service.equipment.HardwareDeviceTransferBillOfLadingService;
import bg.demax.inspections.backend.service.equipment.HardwareDeviceTransferProtocolService;
import bg.demax.inspections.backend.service.equipment.HardwareDeviceTransferService;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.pub.entity.hardware.HardwareDeviceTransferBillOfLading;
import bg.demax.pub.entity.hardware.HardwareDeviceTransferProtocol;
import bg.demax.pub.entity.hardware.WarehouseShippingInfo;

@RestController
@RequestMapping("/api/hardware-device-transfers")
public class HardwareDeviceTransferController {

	@Autowired
	private HardwareDeviceTransferService hardwareDeviceTransferService;

	@Autowired
	private BillOfLadingService billOfLadingService;

	@Autowired
	private HardwareDeviceTransferProtocolService hardwareDeviceTransferProtocolService;

	@Autowired
	private HardwareDeviceTransferBillOfLadingService hardwareDeviceTransferBillOfLadingService;

	@Autowired
	private HardwareDeviceTransferProtocolReportExporter hardwareDeviceTransferProtocolReportExporter;

	@Autowired
	private ConversionService conversionService;

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public IdentifierDto createTransfer(@Valid @RequestBody HardwareDeviceTransferCreationRequestDto requestDto) {
		HardwareDeviceTransferProtocol protocol = conversionService.convert(requestDto, HardwareDeviceTransferProtocol.class);
		WarehouseShippingInfo warehouseShippingInfo = conversionService.convert(requestDto.getWarehouseShippingInfo(),
						WarehouseShippingInfo.class);
		protocol = hardwareDeviceTransferService.create(protocol, requestDto, warehouseShippingInfo);

		return new IdentifierDto(protocol.getId());
	}

	@GetMapping(value = "/{id}/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
	public byte[] getHardwareDeviceTransferPdf(@PathVariable("id") int protocolId, HttpServletResponse response) {
		HardwareDeviceTransferProtocol protocol = hardwareDeviceTransferProtocolService.getInitializedById(protocolId);
		HardwareDeviceTransferProtocolReport report = new HardwareDeviceTransferProtocolReport(protocol);

		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		hardwareDeviceTransferProtocolReportExporter.exportPdf(report, byteArrayOutputStream);

		response.setHeader("content-disposition", "attachment; filename=protocol.pdf");
		return byteArrayOutputStream.toByteArray();
	}

	@GetMapping
	public PageResult<HardwareDeviceTransferBillOfLadingRowDto> getHardwareDeviceTransfers(@Valid PageRequest pageRequest,
					@Valid HardwareDeviceTransfersQueryParams queryParams) {
		HardwareDeviceTransfersSearch search = new HardwareDeviceTransfersSearch();
		BeanUtils.copyProperties(queryParams, search);

		PageResult<HardwareDeviceTransferBillOfLading> transfers = hardwareDeviceTransferBillOfLadingService
						.getHardwareDeviceTransfers(pageRequest, search);

		List<HardwareDeviceTransferBillOfLadingRowDto> transfersDto = conversionService.convertList(transfers.getItems(),
						HardwareDeviceTransferBillOfLadingRowDto.class);
		
		return new PageResult<HardwareDeviceTransferBillOfLadingRowDto>(transfersDto, transfers.getTotalCount());
	}

	@GetMapping("/{id}")
	public HardwareDeviceTransferBillOfLadingDto getBillOfLadingById(@PathVariable int id) {
		HardwareDeviceTransferBillOfLading billOfLading = hardwareDeviceTransferBillOfLadingService.getBillOfLading(id);
		return conversionService.convert(billOfLading, HardwareDeviceTransferBillOfLadingDto.class);
	}

	@PostMapping("/bill-of-ladings/{id}/sent")
	public void setBillOfLadingStatusToSent(@PathVariable("id") int billOfLadingId) {
		billOfLadingService.setHardwareDeviceTransferBillOfLadingStatusToSent(billOfLadingId);
	}
}