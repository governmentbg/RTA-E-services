package bg.demax.inspections.backend.controller.equipment;

import java.io.ByteArrayOutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.hibernate.paging.PageRequest;
import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.PaginationQueryParams;
import bg.demax.inspections.backend.controller.param.equipment.PrinterCartridgeReportCreationParams;
import bg.demax.inspections.backend.controller.param.equipment.PrinterConsumableQueryParams;
import bg.demax.inspections.backend.controller.param.equipment.PrinterConsumableUpdateParams;
import bg.demax.inspections.backend.dto.equipment.PrinterConsumableDto;
import bg.demax.inspections.backend.dto.equipment.PrinterConsumableListItemDto;
import bg.demax.inspections.backend.export.equipment.PrinterConsumableReportData;
import bg.demax.inspections.backend.export.equipment.PrinterConsumableReportExporter;
import bg.demax.inspections.backend.search.equipment.PrinterConsumableSearch;
import bg.demax.inspections.backend.service.equipment.PrinterConsumableService;
import bg.demax.inspections.backend.vo.PrinterConsumableVo;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.pub.entity.hardware.PrinterConsumable;
import bg.demax.pub.entity.hardware.PrinterConsumableReport;

@RestController
@RequestMapping("/api/consumables")
public class PrinterConsumableController {

	@Autowired
	private PrinterConsumableService printerConsumableService;

	@Autowired
	private ConversionService conversionService;

	@Autowired
	private PrinterConsumableReportExporter printerConsumableReportExporter;

	@GetMapping
	public PageResult<PrinterConsumableListItemDto> getPrinterConsumables(@Valid PaginationQueryParams paginationParams,
					@Valid PrinterConsumableQueryParams queryParams) {
		PageRequest pageRequest = new PageRequest();
		BeanUtils.copyProperties(paginationParams, pageRequest);
		PrinterConsumableSearch search = conversionService.convert(queryParams, PrinterConsumableSearch.class);
		PageResult<PrinterConsumable> pageResult = printerConsumableService.getPaginated(pageRequest, search);
		List<PrinterConsumableListItemDto> consumableDtos = conversionService.convertList(pageResult.getItems(),
						PrinterConsumableListItemDto.class);
		return new PageResult<>(consumableDtos, pageResult.getTotalCount());
	}

	@GetMapping("/{id}")
	public PrinterConsumableDto getPrinterConsumableById(@PathVariable("id") int consumableId) {
		PrinterConsumableVo consumable = printerConsumableService.getInitializedById(consumableId);
		return conversionService.convert(consumable, PrinterConsumableDto.class);
	}

	@GetMapping(value = "/xls", produces = "application/vnd.ms-excel")
	public byte[] getPrinterConsumablesXls(@Valid PrinterConsumableQueryParams queryParams, HttpServletResponse response) {
		response.setHeader("content-disposition", "attachment; filename=printer-consumables.xlsx");
		PrinterConsumableSearch search = conversionService.convert(queryParams, PrinterConsumableSearch.class);
		List<PrinterConsumable> consumables = printerConsumableService.getBySearch(search);
		PrinterConsumableReportData report = new PrinterConsumableReportData(consumables);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		printerConsumableReportExporter.exportXls(report, outputStream);
		return outputStream.toByteArray();
	}
	
	@PatchMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public void updatePrinterConsumable(@PathVariable("id") int cartridgeId, 
					@Valid @RequestBody PrinterConsumableUpdateParams params) {
		printerConsumableService.updatePrinterConsumable(cartridgeId, params);
	}
	
	@PostMapping("/{id}/reports")
	@ResponseStatus(HttpStatus.CREATED)
	public void createReportForInstalledPrinterCartridge(@PathVariable("id") int consumableId,
					@RequestBody @Valid PrinterCartridgeReportCreationParams params) {
		PrinterConsumableReport report = createReportFromParameters(consumableId, params);
		printerConsumableService.createReportForInstalledPrinterConsumable(report);
	}
	
	private PrinterConsumableReport createReportFromParameters(int consumableId, PrinterCartridgeReportCreationParams params) {
		PrinterConsumableReport report = new PrinterConsumableReport();
		PrinterConsumable consumable = new PrinterConsumable();
		consumable.setId(consumableId);
		report.setConsumable(consumable);
		report.setPagesForPayment(params.getPagesForPayment());
		return report;
	}
}
