package bg.demax.inspections.backend.controller.orders;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.courier.services.dto.AccountDto;
import bg.demax.courier.services.dto.BillOfLadingRequestDto;
import bg.demax.courier.services.econt.enums.ShipmentType;
import bg.demax.courier.services.exception.CourierServiceException;
import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.CourierBillOfLadingRequestParams;
import bg.demax.inspections.backend.controller.param.orders.ExamOrderItemIntervalChangeParams;
import bg.demax.inspections.backend.controller.param.orders.ExamOrdersSearchParams;
import bg.demax.inspections.backend.controller.param.orders.OrderPageRequest;
import bg.demax.inspections.backend.dto.BillOfLadingDto;
import bg.demax.inspections.backend.dto.CityDto;
import bg.demax.inspections.backend.dto.orders.ExamOrderDto;
import bg.demax.inspections.backend.dto.orders.ExamOrderLightDto;
import bg.demax.inspections.backend.entity.Courier.Couriers;
import bg.demax.inspections.backend.entity.CourierServiceType.CourierServiceTypes;
import bg.demax.inspections.backend.entity.UserCourierAccount;
import bg.demax.inspections.backend.entity.motor.exam.result.ExamOrder;
import bg.demax.inspections.backend.exception.BillOfLadingCreationException;
import bg.demax.inspections.backend.exception.MissingCourierAccountForUser;
import bg.demax.inspections.backend.export.orders.ExamOrderInvoicePrintFactory;
import bg.demax.inspections.backend.pojo.orders.BankStatementPojo;
import bg.demax.inspections.backend.search.orders.ExamOrderSearch;
import bg.demax.inspections.backend.security.SecurityUtil;
import bg.demax.inspections.backend.service.BillOfLadingService;
import bg.demax.inspections.backend.service.UserCourierAccountService;
import bg.demax.inspections.backend.service.orders.ExamOrderService;
import bg.demax.inspections.backend.util.BillOfLadingRequestDtoParams;
import bg.demax.inspections.backend.util.CourierServiceUtils;
import bg.demax.inspections.backend.util.SenderDtoFactory;
import bg.demax.inspections.backend.vo.techinsp.ExamOrderInvoicePrintVo;
import bg.demax.legacy.util.convert.ConversionService;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;

@RestController
@RequestMapping("/api/exam-orders")
public class ExamOrderController {
	
	private static final Logger logger = LogManager.getLogger(ExamOrderController.class);

	@Autowired
	private ConversionService conversionService;
	
	@Autowired
	private ExamOrderService examOrderService;

	@Autowired
	private UserCourierAccountService userCourierAccountService;

	@Autowired
	private SecurityUtil securityUtil;
	
	@Autowired
	private BillOfLadingService billOfLadingService;
	
	@Autowired
	private ExamOrderInvoicePrintFactory examOrderLabelPrintFactory;

	@GetMapping({ "", "/" })
	public PageResult<ExamOrderLightDto> getExamOrders(@Valid ExamOrdersSearchParams searchParams,
			@Valid OrderPageRequest orderPageRequest) throws IllegalAccessException, InvocationTargetException {
		ExamOrderSearch examOrderSearch = new ExamOrderSearch();
		BeanUtils.copyProperties(searchParams, examOrderSearch);
		return examOrderService.getExamOrders(examOrderSearch, orderPageRequest);
	}

	@GetMapping("/{id}")
	public ExamOrderDto getExamOrder(@PathVariable("id") long id)
			throws IllegalAccessException, InvocationTargetException {
		return examOrderService.getExamOrderDto(id);
	}

	@PostMapping("/{id}/bill-of-lading")
	public BillOfLadingDto validateAndSetVouchersForExamOrder(@PathVariable("id") long id,
			@RequestBody @Valid CourierBillOfLadingRequestParams requestParams) {
		
		ExamOrder examOrder = examOrderService.getExamOrderValidateAndInitCity(id);

		String cityName = CourierServiceUtils.getCityNameWithoutPrefix(examOrder.getCity());
		String cityType = examOrder.getCity().getType().getValue();
		String billOfLadingId = null;

		String courierCode = requestParams.getCourierCode();

		if (!courierCode.equals(Couriers.DEMAX.getCode())) {
			UserCourierAccount courierAccount = userCourierAccountService.getCourierAccount(courierCode);
			if (courierAccount == null) {
				throw new MissingCourierAccountForUser(securityUtil.getCurrentUserDetails().getUsername());
			}

			BillOfLadingRequestDtoParams params = new BillOfLadingRequestDtoParams();
			params.setWeight(new BigDecimal(0.25));
			params.setPacketCount(1);
			params.setCourierServiceTypeCode(requestParams.getCourierServiceTypeCode());
			params.setCityName(cityName);
			params.setCityType(cityType);
			params.setCityRegion(examOrder.getCity().getRegion().getName());
			params.setAddress(examOrder.getAddress());
			params.setReceiverName(examOrder.getPersonName());
			params.setContactPerson(examOrder.getPersonName());
			params.setSenderDto(SenderDtoFactory
					.getSenderDto(courierAccount.getCourierClientAccount().getId().getClientId()));
			params.setPhoneNumber(examOrder.getPersonPhone());

			if (requestParams.getCourierServiceTypeCode().equals(CourierServiceTypes.EXPRESS.getCode())) {
				params.setFixedTimeDelivery(requestParams.getFixedTimeDelivery());
			}

			BillOfLadingRequestDto requestDto = CourierServiceUtils.createBillOfLadingRequestDto(params);
			requestDto.setDocuments(true);
			requestDto.getShipment().setShipmentType(ShipmentType.DOCUMENT);
			requestDto.getShipment().setDescription(ShipmentType.DOCUMENT.getValue());
			try {
				billOfLadingId = billOfLadingService.createBillOfLadingFromCourierServiceOrThrowException(requestDto,
						courierCode,
						conversionService.convert(courierAccount.getCourierClientAccount(), AccountDto.class));
			} catch (CourierServiceException cse) {
				logger.error(cse);
				throw new BillOfLadingCreationException(cse.getMessage());
			}
		} else {
			billOfLadingId = System.currentTimeMillis() + "";
		}

		try {
			
			BillOfLadingDto billOfLadingDto = examOrderService.saveBillOfLadingAndUpdateOrder(requestParams, id, billOfLadingId);
			return billOfLadingDto;
		} catch (Exception e) {
			if (!courierCode.equals(Couriers.DEMAX.getCode())) {
				billOfLadingService.cancelBillOfLadingInCourierService(courierCode, Integer.parseInt(billOfLadingId));
			}
			throw e;
		}
		
	}

	@GetMapping("/{id}/bank-statement/pdf")
	public ResponseEntity<byte[]> getBankStatement(@PathVariable("id") long orderId) {
		BankStatementPojo bankStatement = examOrderService.getOrderBankStatementPojo(orderId);
		String contentType = getContentTypeForFile(bankStatement.getName());
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_DISPOSITION,
				String.format("attachment; filename=\"%s\"", bankStatement.getName()));

		if (contentType != null) {
			headers.add(HttpHeaders.CONTENT_TYPE, contentType);
		}
		ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(bankStatement.getContent(), headers,
				HttpStatus.OK);
		return response;
	}
	
	@GetMapping(path = "/{id}/invoice/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
	public byte[] getInvoicePdf(@PathVariable("id") long id, HttpServletResponse response) throws JRException {
		ExamOrderInvoicePrintVo invoicePrintVo = examOrderService.getInvoicePrint(id);
		JasperPrint inspectionOrderInvoicePrint = examOrderLabelPrintFactory.getInvoicePrint(invoicePrintVo);

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		JasperExportManager.exportReportToPdfStream(inspectionOrderInvoicePrint, outputStream);

		response.setHeader("Content-disposition", String.format("attachment; filename=ExamOrderInvoice%s.pdf", id));
		return outputStream.toByteArray();
	}

	@PatchMapping("/{id}/intervals/supervisor")
	public void setExamOrderIntervals(@PathVariable("id") long orderId,
			@Valid @RequestBody ExamOrderItemIntervalChangeParams params) {
		examOrderService.setExamOrderIntervalsAsSupervisor(orderId, params.getIntervals(), params);
	}

	@GetMapping("/cities")
	public List<CityDto> getCities() throws IllegalAccessException, InvocationTargetException {
		return examOrderService.getExamOrderCities();
	}

	private String getContentTypeForFile(String fileName) {
		String contntType = null;
		int lastDotIndex = fileName.lastIndexOf(".");

		if (lastDotIndex < 0) {
			return null;
		}

		String fileExtension = fileName.substring(lastDotIndex);

		if (fileExtension.contains("png")) {
			contntType = MediaType.IMAGE_PNG_VALUE;
		} else if (fileExtension.contains("pdf")) {
			contntType = MediaType.APPLICATION_PDF_VALUE;
		} else if (fileExtension.contains("jpg")) {
			contntType = MediaType.IMAGE_JPEG_VALUE;
		} else if (fileExtension.contains("txt")) {
			contntType = MediaType.TEXT_PLAIN_VALUE;
		}

		return contntType;
	}

}
