package bg.demax.inspections.backend.controller.orders;

import java.util.Set;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.courier.services.dto.AccountDto;
import bg.demax.courier.services.dto.BillOfLadingRequestDto;
import bg.demax.courier.services.exception.CourierServiceException;
import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.BillOfLadingPageRequest;
import bg.demax.inspections.backend.controller.param.OrgUnitParams;
import bg.demax.inspections.backend.controller.param.orders.InspectionBillOfLadingRequestParams;
import bg.demax.inspections.backend.controller.param.orders.InspectionDeliveryProtocolBillOfLadingSearchParams;
import bg.demax.inspections.backend.dto.OrgUnitDto;
import bg.demax.inspections.backend.dto.orders.InspectionBillOfLadingDto;
import bg.demax.inspections.backend.dto.orders.InspectionDeliveryProtocolBillOfLadingLightDto;
import bg.demax.inspections.backend.dto.orders.WeightAndPackageCountDto;
import bg.demax.inspections.backend.entity.Courier.Couriers;
import bg.demax.inspections.backend.entity.CourierServiceType.CourierServiceTypes;
import bg.demax.inspections.backend.entity.UserCourierAccount;
import bg.demax.inspections.backend.exception.BillOfLadingAlreadyExistsException;
import bg.demax.inspections.backend.exception.BillOfLadingCreationException;
import bg.demax.inspections.backend.exception.MissingCourierAccountForUser;
import bg.demax.inspections.backend.search.orders.InspectionDeliveryProtocolBillOfLadingSearch;
import bg.demax.inspections.backend.security.SecurityUtil;
import bg.demax.inspections.backend.service.BillOfLadingService;
import bg.demax.inspections.backend.service.OrgUnitService;
import bg.demax.inspections.backend.service.UserCourierAccountService;
import bg.demax.inspections.backend.service.orders.InspectionOrderService;
import bg.demax.inspections.backend.util.CourierServiceUtils;
import bg.demax.legacy.util.convert.ConversionService;

@RestController
@RequestMapping("/api/inspection-bills-of-lading")
public class InspectionBillOfLadingController {

	private static final Logger logger = LogManager.getLogger(InspectionBillOfLadingController.class);

	@Autowired
	private BillOfLadingService billOfLadingService;

	@Autowired
	private InspectionOrderService inspectionOrderService;

	@Autowired
	private OrgUnitService orgUnitService;

	@Autowired
	private SecurityUtil securityUtil;

	@Autowired
	private UserCourierAccountService userCourierAccountService;

	@Autowired
	private ConversionService conversionService;

	@GetMapping({ "", "/" })
	public PageResult<InspectionDeliveryProtocolBillOfLadingLightDto> getBillOfLadings(
			@Valid InspectionDeliveryProtocolBillOfLadingSearchParams searchParams,
			@Valid BillOfLadingPageRequest pageRequest) {

		InspectionDeliveryProtocolBillOfLadingSearch search = new InspectionDeliveryProtocolBillOfLadingSearch();

		BeanUtils.copyProperties(searchParams, search);

		return billOfLadingService.getInspectionBillOfLadings(search, pageRequest);
	}

	@PostMapping("/daily")
	public void createDailyBillOfLadings() {
		billOfLadingService.checkForUnsentInspectionBillOfLading();

		Set<OrgUnitDto> orgUnits = inspectionOrderService.getAllOrgUnitsWithInspectionOrders();

		InspectionBillOfLadingRequestParams params = new InspectionBillOfLadingRequestParams();
		params.setCourierCode(Couriers.SPEEDY.getCode());
		params.setCourierServiceTypeCode(CourierServiceTypes.EXPRESS.getCode());

		orgUnits.forEach(orgUnit -> {

			if (!billOfLadingService.isInspectionBillOfLadingForOrgUnitFromTodayAlreadyCreated(orgUnit.getCode())) {

				WeightAndPackageCountDto weightDto = billOfLadingService
						.getOrgUnitExpcetedInspectionOrdersWeightAndPackageCount(orgUnit.getCode());

				params.setOrgUnitCode(orgUnit.getCode());
				params.setWeight(weightDto.getWeight());
				params.setPackageCount(weightDto.getPackageCount());

				UserCourierAccount courierAccount = userCourierAccountService
						.getCourierAccount(params.getCourierCode());
				if (courierAccount == null) {
					throw new MissingCourierAccountForUser(securityUtil.getCurrentUserDetails().getUsername());
				}

				BillOfLadingRequestDto requestDto = CourierServiceUtils
						.createBillOfLadingRequestDtoForInspectionBillOfLading(params, orgUnit,
								courierAccount.getCourierClientAccount().getId().getClientId());
				requestDto.setBackDocumentRequest(billOfLadingService.getSpeedyBackDocumentsValue());

				try {
					String billOfLadingId = billOfLadingService.createBillOfLadingFromCourierServiceOrThrowException(
							requestDto, params.getCourierCode(),
							conversionService.convert(courierAccount.getCourierClientAccount(), AccountDto.class));

					billOfLadingService.createAndSaveInspectionDeliveryProtocolBillOfLadingForOrgUnit(params,
							billOfLadingId);

				} catch (CourierServiceException cse) {
					logger.error(cse);
					throw new BillOfLadingCreationException(cse.getMessage());
				}

			}
		});
	}

	@PostMapping({ "", "/" })
	public void createBillOfLading(@Valid @RequestBody InspectionBillOfLadingRequestParams params) {
		billOfLadingService.checkForUnsentInspectionBillOfLading();

		if (!billOfLadingService.isInspectionBillOfLadingForOrgUnitFromTodayAlreadyCreated(params.getOrgUnitCode())) {

			OrgUnitDto orgUnit = orgUnitService.getOrgUnitByCode(params.getOrgUnitCode());

			if (params.getWeight() == null || params.getPackageCount() == null || params.getPackageCount() < 0) {
				WeightAndPackageCountDto weightDto = billOfLadingService
						.getOrgUnitExpcetedInspectionOrdersWeightAndPackageCount(params.getOrgUnitCode());

				params.setWeight(weightDto.getWeight());
				params.setPackageCount(weightDto.getPackageCount());
			}

			String billOfLadingIdForCourier = null;

			if (!params.getCourierCode().equals(Couriers.DEMAX.getCode())) {
				UserCourierAccount courierAccount = userCourierAccountService
						.getCourierAccount(params.getCourierCode());
				if (courierAccount == null) {
					throw new MissingCourierAccountForUser(securityUtil.getCurrentUserDetails().getUsername());
				}
				try {
					BillOfLadingRequestDto requestDto = CourierServiceUtils
							.createBillOfLadingRequestDtoForInspectionBillOfLading(params, orgUnit,
									courierAccount.getCourierClientAccount().getId().getClientId());
					requestDto.setBackDocumentRequest(billOfLadingService.getSpeedyBackDocumentsValue());
					billOfLadingIdForCourier = billOfLadingService.createBillOfLadingFromCourierServiceOrThrowException(
							requestDto, params.getCourierCode(),
							conversionService.convert(courierAccount.getCourierClientAccount(), AccountDto.class));
				} catch (CourierServiceException cse) {
					logger.error(cse);
					throw new BillOfLadingCreationException(cse.getMessage());
				}
			}

			billOfLadingService.createAndSaveInspectionDeliveryProtocolBillOfLadingForOrgUnit(params,
					billOfLadingIdForCourier);

		} else {
			throw new BillOfLadingAlreadyExistsException();
		}
	}

	@GetMapping("/{id}")
	public InspectionBillOfLadingDto getBillOfLadingById(@PathVariable int id) {
		return billOfLadingService.getInspectionBillOfLadingById(id);
	}

	@GetMapping("/expected-org-unit-weight-and-package-count")
	public WeightAndPackageCountDto getExpectedInspectionOrdersWeightAndPackageCount(
			@Valid OrgUnitParams orgUnitParam) {
		return billOfLadingService
				.getOrgUnitExpcetedInspectionOrdersWeightAndPackageCount(orgUnitParam.getOrgUnitCode());
	}

	@PutMapping("/{id}/send")
	public void setBillOfLadingStatusToSent(@PathVariable int id) {
		billOfLadingService.setBillOfLadingToSent(id);
	}
}
