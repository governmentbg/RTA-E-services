package bg.demax.inspections.backend.controller.orders;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.Base64;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.courier.services.dto.AccountDto;
import bg.demax.courier.services.dto.BillOfLadingRequestDto;
import bg.demax.courier.services.econt.enums.PaymentSide;
import bg.demax.courier.services.exception.CourierServiceException;
import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.SupervisorWeightParams;
import bg.demax.inspections.backend.controller.param.WeightParams;
import bg.demax.inspections.backend.controller.param.orders.InspectionBillOfLadingRequestExtParams;
import bg.demax.inspections.backend.controller.param.orders.InspectionOrderIntervalChangeParams;
import bg.demax.inspections.backend.controller.param.orders.InspectionOrderStatusPayParams;
import bg.demax.inspections.backend.controller.param.orders.InspectionOrdersSearchParams;
import bg.demax.inspections.backend.controller.param.orders.OrderPageRequest;
import bg.demax.inspections.backend.controller.param.orders.UpdateOrderProductQuantityParams;
import bg.demax.inspections.backend.dto.orders.InspectionOrderDto;
import bg.demax.inspections.backend.dto.orders.InspectionOrderLightDto;
import bg.demax.inspections.backend.dto.orders.InspectionOrderProtocolIdAndBIllOfLadingIdDto;
import bg.demax.inspections.backend.entity.Courier.Couriers;
import bg.demax.inspections.backend.entity.CourierServiceType.CourierServiceTypes;
import bg.demax.inspections.backend.entity.UserCourierAccount;
import bg.demax.inspections.backend.exception.BillOfLadingCreationException;
import bg.demax.inspections.backend.exception.MissingCourierAccountForUser;
import bg.demax.inspections.backend.export.orders.InspectionOrderPrintFactory;
import bg.demax.inspections.backend.search.orders.InspectionOrderSearch;
import bg.demax.inspections.backend.security.SecurityUtil;
import bg.demax.inspections.backend.service.BillOfLadingService;
import bg.demax.inspections.backend.service.UserCourierAccountService;
import bg.demax.inspections.backend.service.orders.InspectionOrderService;
import bg.demax.inspections.backend.service.orders.InspectionProtocolService;
import bg.demax.inspections.backend.util.CourierServiceUtils;
import bg.demax.inspections.backend.vo.techinsp.InspectionOrderInvoicePrintVo;
import bg.demax.inspections.backend.vo.techinsp.InspectionOrderLabelVo;
import bg.demax.legacy.util.convert.ConversionService;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;

@RestController
@RequestMapping("/api/inspection-orders")
public class InspectionOrderController {

	private static final Logger logger = LogManager.getLogger(InspectionOrderController.class);

	@Autowired
	private InspectionOrderService inspectionOrderService;
	
	@Autowired
	private InspectionOrderPrintFactory inspectionOrderLabelPrintFactory;
	
	@Autowired
	private InspectionProtocolService inspectionProtocolService;

	@Autowired
	private SecurityUtil securityUtil;

	@Autowired
	private UserCourierAccountService userCourierAccountService;

	@Autowired
	private BillOfLadingService billOfLadingService;

	@Autowired
	private ConversionService conversionService;

	@GetMapping({ "", "/" })
	public PageResult<InspectionOrderLightDto> getInspectionOrders(@Valid InspectionOrdersSearchParams searchParams,
			@Valid OrderPageRequest orderPageRequest) throws IllegalAccessException, InvocationTargetException {
		InspectionOrderSearch orderSearch = new InspectionOrderSearch();
		BeanUtils.copyProperties(searchParams, orderSearch);
		return inspectionOrderService.getOrders(orderSearch, orderPageRequest);
	}

	@GetMapping("/{id}")
	public InspectionOrderDto getInspectionOrder(@PathVariable("id") long id) {
		return inspectionOrderService.getOrderDto(id);
	}

	@GetMapping(value = "/{id}/bank-statement/pdf", produces = MediaType.IMAGE_PNG_VALUE)
	public ResponseEntity<byte[]> getBankStatement(@PathVariable("id") long orderId) {
		byte[] bankStatement = inspectionOrderService.getBankStatement(orderId);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentDispositionFormData("attachment", "bankStatement" + orderId + ".png");
		return new ResponseEntity<byte[]>(bankStatement, headers, HttpStatus.OK);
	}

	@PatchMapping("/{id}/set-status-to-label")
	public String setStatusToLabel(@PathVariable("id") long id, @Valid @RequestBody WeightParams weightParams) {
		return inspectionOrderService.setStatusToLabel(id, weightParams.getWeight(), null);
	}

	@PatchMapping("/{id}/set-status-to-label/supervisor")
	public String setStatusToLabelAsSupervisor(@PathVariable("id") long id, @Valid @RequestBody SupervisorWeightParams params) {
		return inspectionOrderService.setStatusToLabel(id, params.getWeight(), params);
	}

	@PatchMapping("/{id}/update-intervals/supervisor")
	public void updateInspectionOrderIntervals(@PathVariable("id") long orderId,
			@Valid @RequestBody InspectionOrderIntervalChangeParams intervalChangeParams) {

		inspectionOrderService.updateOrderIntervals(orderId, intervalChangeParams.getIntervals(),
				intervalChangeParams.getProductTypeId(), intervalChangeParams);
	}

	@PatchMapping("/{id}/quantity/call-center")
	public void updateOrderProductQuantity(@PathVariable("id") long orderId,
										@Valid @RequestBody UpdateOrderProductQuantityParams quantityParams) {
		inspectionOrderService.updateOrderProductQuantity(orderId, quantityParams.getProductTypeId(), quantityParams.getQuantity());
	}
	
	@GetMapping(path = "/{id}/get-label-pdf")
	public String getLabelPdf(@PathVariable("id") long id, HttpServletResponse response) throws JRException {
		InspectionOrderLabelVo vo = inspectionOrderService.getLabelPrintVo(id);
		JasperPrint inspectionOrderLabelPrint = inspectionOrderLabelPrintFactory.getLabelPrint(vo);

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		JasperExportManager.exportReportToPdfStream(inspectionOrderLabelPrint, outputStream);

		response.setHeader("Content-disposition", String.format("attachment; filename=InspectionOrderLabel%s.pdf", id));

		String base64Response =	Base64.getEncoder().encodeToString( outputStream.toByteArray());

		return base64Response;
	}
	
	@GetMapping(path = "/{id}/invoice/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
	public byte[] getInvoicePdf(@PathVariable("id") long id, HttpServletResponse response) throws JRException {
		InspectionOrderInvoicePrintVo vo = inspectionOrderService.getInvoicePrintVo(id);
		JasperPrint inspectionOrderInvoicePrint = inspectionOrderLabelPrintFactory.getInvoicePrint(vo);

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		JasperExportManager.exportReportToPdfStream(inspectionOrderInvoicePrint, outputStream);

		response.setHeader("Content-disposition", String.format("attachment; filename=InspectionOrderInvoice%s.pdf", id));
		return outputStream.toByteArray();
	}
	
	@PatchMapping("/{id}/pay")
	public void setOrderStatusToPayed(@PathVariable("id") long orderId,
			@Valid @RequestBody InspectionOrderStatusPayParams intervalParams) {

		inspectionOrderService.setStatusToPaid(orderId, intervalParams.getInvoiceNumber(),
				intervalParams.getInvoiceDate());
	}


	//EXCEPTION CASE FOR WHEN RDAA NOT WORKING
	@PostMapping("/{id}/bill-of-lading")
	public InspectionOrderProtocolIdAndBIllOfLadingIdDto createAndSendBillOfLading(@PathVariable("id") long id) {

		InspectionBillOfLadingRequestExtParams params = new InspectionBillOfLadingRequestExtParams();
		params.setCourierCode(Couriers.SPEEDY.getCode());
		params.setCourierServiceTypeCode(CourierServiceTypes.STANDARD.getCode());

		params = inspectionOrderService.createInspectionBillOfLadingDto(id, params);

		UserCourierAccount courierAccount = userCourierAccountService.getCourierAccount(params.getCourierCode());
		if (courierAccount == null) {
			throw new MissingCourierAccountForUser(securityUtil.getCurrentUserDetails().getUsername());
		}

		BillOfLadingRequestDto requestDto = CourierServiceUtils.createBillOfLadingRequestDtoForInspectionBillOfLadingForDirectSend(
				params, courierAccount.getCourierClientAccount().getId().getClientId());
		requestDto.setBackDocumentRequest(billOfLadingService.getSpeedyBackDocumentsValue());
		requestDto.setCashOnDeliveryAmount(new BigDecimal("1.4"));
		requestDto.getPayment().setPaymentSide(PaymentSide.RECEIVER);
		requestDto.getReceiver().setNamePerson(params.getKtpName());
		requestDto.getReceiver().setObjectName(params.getObjectName());

		if (courierAccount.getCourierClientAccount().getId().getUsername().equals("995352")) {
			requestDto.setServiceTypeId(505);
			// requestDto.setPickingDate(LocalDateTime.now().plusDays(1));
		}

		try {
			String billOfLadingId = billOfLadingService.createBillOfLadingFromCourierServiceOrThrowException(requestDto,
					params.getCourierCode(),
					conversionService.convert(courierAccount.getCourierClientAccount(), AccountDto.class));

			return inspectionProtocolService.createProtocolForSingleLabelOrderAndAddToBol(params, billOfLadingId, id);
		} catch (CourierServiceException cse) {
			logger.error(cse);
			throw new BillOfLadingCreationException(cse.getMessage());
		}
	}
}
