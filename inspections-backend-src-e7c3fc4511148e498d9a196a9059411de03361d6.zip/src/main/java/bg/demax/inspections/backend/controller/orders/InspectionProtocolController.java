package bg.demax.inspections.backend.controller.orders;

import java.io.ByteArrayOutputStream;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.OrgUnitParams;
import bg.demax.inspections.backend.controller.param.orders.InspectionDeliveryProtocolPageRequest;
import bg.demax.inspections.backend.controller.param.orders.InspectionDeliveryProtocolSearchParams;
import bg.demax.inspections.backend.dto.orders.InspectionDeliveryProtocolDto;
import bg.demax.inspections.backend.dto.orders.InspectionDeliveryProtocolMediumDto;
import bg.demax.inspections.backend.search.orders.InspectionDeliveryProtocolSearch;
import bg.demax.inspections.backend.service.orders.InspectionProtocolService;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;

@RestController
@RequestMapping("/api/inspection-protocols")
public class InspectionProtocolController {
	@Autowired
	private InspectionProtocolService inspectionProtocolService;
	
	@GetMapping({ "", "/" })
	public PageResult<InspectionDeliveryProtocolMediumDto> getDeliveryProtocols(
			@Valid InspectionDeliveryProtocolSearchParams searchParams,
			@Valid InspectionDeliveryProtocolPageRequest pageRequest) {
		InspectionDeliveryProtocolSearch search = new InspectionDeliveryProtocolSearch();
		BeanUtils.copyProperties(searchParams, search);

		return inspectionProtocolService.getDeliveryProtocols(search, pageRequest);
	}

	@GetMapping("/{id}")
	public InspectionDeliveryProtocolDto getInspectionDeliveryProtocol(@PathVariable("id") long id) {
		return inspectionProtocolService.getDeliveryProtocol(id);
	}
	
	@GetMapping(path = "/{id}/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
	public byte[] getInspectionProtocolPdf(@PathVariable("id") long id, HttpServletResponse response) throws JRException {
		JasperPrint protocolPrint = inspectionProtocolService.getDeliveryProtocolPrint(id);
		
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		JasperExportManager.exportReportToPdfStream(protocolPrint, outputStream);
		
		response.setHeader("Content-disposition", String.format("attachment; filename=InspectionDeliveryProtocol%s.pdf", id));
		return outputStream.toByteArray();
	}
	
	@PostMapping("/org-unit")
	public long createProtocolForOrgUnitLabelOrdersAndAddToBol(@Valid @RequestBody OrgUnitParams orgUnitParams) {
		return inspectionProtocolService.createProtocolForOrgUnitLabelOrdersAndAddToBol(orgUnitParams.getOrgUnitCode());
	}
}
