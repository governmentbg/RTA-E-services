package bg.demax.inspections.backend.controller.param;

public class ActiveComputerQueryParams {

	private Integer permitNumber = null;

	private String orgUnitCode = null;

	public Integer getPermitNumber() {
		return permitNumber;
	}

	public void setPermitNumber(Integer permitNumber) {
		this.permitNumber = permitNumber;
	}

	public String getOrgUnitCode() {
		return orgUnitCode;
	}

	public void setOrgUnitCode(String orgUnitCode) {
		this.orgUnitCode = orgUnitCode;
	}
}
