package bg.demax.inspections.backend.controller.param;

import java.time.LocalTime;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.springframework.format.annotation.DateTimeFormat;

import bg.demax.inspections.backend.validation.ValidCourierDeliveryTime;

@ValidCourierDeliveryTime
public class CourierBillOfLadingRequestParams {

	public static final String TIME_FORMAT = "HH:mm";
	
	@NotBlank
	@Pattern(regexp = "^(DEMAX|SPEEDY|ECONT)$")
	private String courierCode;
	
	@NotBlank
	@Pattern(regexp = "^(STANDARD|EXPRESS)$")
	private String courierServiceTypeCode;

	@DateTimeFormat(pattern = TIME_FORMAT)
	private LocalTime fixedTimeDelivery;
	
	public String getCourierCode() {
		return courierCode;
	}

	public void setCourierCode(String courierCode) {
		this.courierCode = courierCode;
	}

	public String getCourierServiceTypeCode() {
		return courierServiceTypeCode;
	}

	public void setCourierServiceTypeCode(String courierServiceTypeCode) {
		this.courierServiceTypeCode = courierServiceTypeCode;
	}

	public LocalTime getFixedTimeDelivery() {
		return fixedTimeDelivery;
	}

	public void setFixedTimeDelivery(LocalTime fixedTimeDelivery) {
		this.fixedTimeDelivery = fixedTimeDelivery;
	}
}
