package bg.demax.inspections.backend.controller.param;

import javax.validation.constraints.NotNull;

public class CurrentUserPasswordChangeParams {
	
	@NotNull
	private String newPassword;
	
	@NotNull
	private String oldPassword;
	
	public String getNewPassword() {
		return newPassword;
	}
	
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	
	public String getOldPassword() {
		return oldPassword;
	}
	
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}
}
