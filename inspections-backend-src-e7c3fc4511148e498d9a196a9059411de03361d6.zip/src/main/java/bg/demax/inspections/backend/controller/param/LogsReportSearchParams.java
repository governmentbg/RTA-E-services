package bg.demax.inspections.backend.controller.param;

import java.time.LocalDate;

import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import bg.demax.inspections.backend.validation.ValidateDateRange;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ValidateDateRange(startDate = "from", endDate = "to")
public class LogsReportSearchParams {

	@Pattern(regexp = "(^INSERT$|^UPDATE$)")
	@Length(max = 6)
	private String queryType;

	@Pattern(regexp = "(^permits$|^permit_inspectors$|^permit_lines$)")
	@Length(max = 17)
	private String objectType;

	@PastOrPresent
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate from;

	@PastOrPresent
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate to;
}
