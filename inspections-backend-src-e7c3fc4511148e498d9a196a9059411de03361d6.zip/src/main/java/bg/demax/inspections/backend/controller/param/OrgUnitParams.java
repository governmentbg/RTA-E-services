package bg.demax.inspections.backend.controller.param;

import javax.validation.constraints.NotEmpty;

public class OrgUnitParams {
	@NotEmpty
	private String orgUnitCode;

	public String getOrgUnitCode() {
		return orgUnitCode;
	}

	public void setOrgUnitCode(String orgUnitCode) {
		this.orgUnitCode = orgUnitCode;
	}
}
