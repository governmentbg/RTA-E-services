package bg.demax.inspections.backend.controller.param;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

public class PaginationQueryParams {

	@Min(1)
	private int page = 1;

	@Max(100)
	@Min(1)
	private int pageSize = 50;

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
}
