package bg.demax.inspections.backend.controller.param;

public class ParamsConstants {
	private ParamsConstants() {	
	}

	public static final String EMAIL_PATTERN = "^[a-zA-Z0-9.!#$%&*+=?^_{|}~-]+@[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])"
							+ "(\\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9]))+$";
	public static final String EGN_PATTERN = "^\\d{10}$";
	public static final String PHONE_PATTERN = "^[0-9+\\-\\/\\\\ ]+$";
	public static final String TWO_PHONES_PATTERN = "^[0-9+\\-\\/\\\\ .,;]+$";
	public static final String NAME_PATTERN = "^[^`~!@#$%^&*()_\\-+=\\[{\\]}'\";:\\\\|,<.>\\/?0-9]+$";
}
