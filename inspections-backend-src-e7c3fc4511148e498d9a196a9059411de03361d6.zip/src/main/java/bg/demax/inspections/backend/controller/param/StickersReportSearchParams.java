package bg.demax.inspections.backend.controller.param;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import bg.demax.inspections.backend.controller.param.permit.BaseReportSearchParams;
import bg.demax.inspections.backend.validation.ValidateDateRange;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ValidateDateRange(startDate = "from", endDate = "to", interval = 12)
public class StickersReportSearchParams extends BaseReportSearchParams {

	private Integer permitNumber;
	private Long orderNumber;
	private Long stickerNumber;
	private String status;

	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate from;

	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate to;

}
