package bg.demax.inspections.backend.controller.param;

import javax.validation.constraints.Size;

import org.springframework.lang.Nullable;

import bg.demax.inspections.backend.controller.param.permit.BaseReportSearchParams;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubjectCardsReportSearchParams extends BaseReportSearchParams {

	@Size(max = 10, min = 1)
	private String searchText;

	@Nullable
	private Boolean isActive;

}
