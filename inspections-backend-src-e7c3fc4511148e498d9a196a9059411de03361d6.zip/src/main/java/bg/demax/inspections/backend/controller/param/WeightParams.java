package bg.demax.inspections.backend.controller.param;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

public class WeightParams {
	@NotNull
	private BigDecimal weight;

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}
}
