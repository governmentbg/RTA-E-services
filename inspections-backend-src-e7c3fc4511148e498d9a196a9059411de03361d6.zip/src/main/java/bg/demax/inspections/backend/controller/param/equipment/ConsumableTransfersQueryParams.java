package bg.demax.inspections.backend.controller.param.equipment;

public class ConsumableTransfersQueryParams extends TransfersQueryParams {
	private String receiver = null;
	
	public String getReceiver() {
		return receiver;
	}
	
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
}