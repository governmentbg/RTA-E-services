package bg.demax.inspections.backend.controller.param.equipment;

import javax.validation.constraints.NotNull;

public class HardwareDeviceByIdRequestParams {
	
	@NotNull
	private Integer id;
	
	@NotNull
	private Short typeCode;
	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public Short getTypeCode() {
		return typeCode;
	}
	
	public void setTypeCode(Short typeCode) {
		this.typeCode = typeCode;
	}
}
