package bg.demax.inspections.backend.controller.param.equipment;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import bg.demax.inspections.backend.validation.equipment.ValidHardwareDeviceCreationRequestParams;

@ValidHardwareDeviceCreationRequestParams
public class HardwareDeviceCreationRequestDto {

	@NotNull
	private Short deviceTypeCode;

	@NotNull
	private Integer warehouseId;

	@NotNull
	@Size(max = 30)
	private String serialNumber;

	@Size(max = 20)
	@Pattern(regexp = "^([0-9a-fA-F][0-9a-fA-F]:){5}([0-9a-fA-F][0-9a-fA-F])$")
	private String macAddress;

	@Size(max = 15)
	@Pattern(regexp = "^\\b(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])" 
					+ "\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])" 
					+ "\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])"
					+ "\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\\b$")
	private String ipAddress;

	@Size(max = 30)
	private String msisdn;

	@Size(max = 30)
	private String imsi;

	public Short getDeviceTypeCode() {
		return deviceTypeCode;
	}

	public void setDeviceTypeCode(Short deviceTypeCode) {
		this.deviceTypeCode = deviceTypeCode;
	}

	public Integer getWarehouseId() {
		return warehouseId;
	}

	public void setWarehouseId(Integer warehouseId) {
		this.warehouseId = warehouseId;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getMacAddress() {
		return macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getImsi() {
		return imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}
}
