package bg.demax.inspections.backend.controller.param.equipment;

import bg.demax.inspections.backend.enums.DeviceLocationType;

public class HardwareDeviceQueryParams {

	private String searchText = null;
	private Short typeCode = null;
	private DeviceLocationType locationType = null;
	private Integer warehouseId = null;
	private Integer statusId = null;

	private String orgUnitCode = null;

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	public DeviceLocationType getLocationType() {
		return locationType;
	}

	public void setLocationType(DeviceLocationType locationType) {
		this.locationType = locationType;
	}

	public Short getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(Short typeCode) {
		this.typeCode = typeCode;
	}

	public Integer getWarehouseId() {
		return warehouseId;
	}

	public void setWarehouseId(Integer warehouseId) {
		this.warehouseId = warehouseId;
	}

	public Integer getStatusId() {
		return statusId;
	}

	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	public String getOrgUnitCode() {
		return orgUnitCode;
	}

	public void setOrgUnitCode(String orgUnitCode) {
		this.orgUnitCode = orgUnitCode;
	}
}
