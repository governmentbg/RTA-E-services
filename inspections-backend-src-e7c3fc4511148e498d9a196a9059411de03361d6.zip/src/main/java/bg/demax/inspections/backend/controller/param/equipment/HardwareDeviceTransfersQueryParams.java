package bg.demax.inspections.backend.controller.param.equipment;

public class HardwareDeviceTransfersQueryParams extends TransfersQueryParams {
	private Integer warehouseId = null;

	public Integer getWarehouseId() {
		return warehouseId;
	}

	public void setWarehouseId(Integer warehouseId) {
		this.warehouseId = warehouseId;
	}
}