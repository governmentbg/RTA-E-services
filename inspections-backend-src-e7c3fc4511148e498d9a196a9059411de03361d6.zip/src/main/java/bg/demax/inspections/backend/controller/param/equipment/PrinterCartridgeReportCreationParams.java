package bg.demax.inspections.backend.controller.param.equipment;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

public class PrinterCartridgeReportCreationParams {

	@NotNull
	@Min(0)
	private Integer pagesForPayment;

	public Integer getPagesForPayment() {
		return pagesForPayment;
	}

	public void setPagesForPayment(Integer pagesForPayment) {
		this.pagesForPayment = pagesForPayment;
	}
}
