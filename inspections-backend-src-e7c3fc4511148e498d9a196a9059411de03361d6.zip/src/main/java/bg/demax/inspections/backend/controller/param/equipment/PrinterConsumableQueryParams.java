package bg.demax.inspections.backend.controller.param.equipment;

import javax.validation.constraints.Size;

import bg.demax.inspections.backend.dto.equipment.PrinterConsumableStatusEnum;
import bg.demax.inspections.backend.dto.equipment.PrinterConsumableTypeEnum;

public class PrinterConsumableQueryParams {

	private String searchText = null;

	private PrinterConsumableTypeEnum type = null;

	@Size(min = 1)
	private PrinterConsumableStatusEnum[] statuses = null;

	private String orgUnitCode = null;

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	public PrinterConsumableTypeEnum getType() {
		return type;
	}

	public void setType(PrinterConsumableTypeEnum type) {
		this.type = type;
	}

	public PrinterConsumableStatusEnum[] getStatuses() {
		return statuses;
	}

	public void setStatuses(PrinterConsumableStatusEnum[] statuses) {
		this.statuses = statuses;
	}

	public String getOrgUnitCode() {
		return orgUnitCode;
	}

	public void setOrgUnitCode(String orgUnitCode) {
		this.orgUnitCode = orgUnitCode;
	}
}
