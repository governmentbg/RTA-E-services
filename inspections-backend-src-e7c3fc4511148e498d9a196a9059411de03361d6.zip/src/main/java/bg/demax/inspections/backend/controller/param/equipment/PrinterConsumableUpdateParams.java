package bg.demax.inspections.backend.controller.param.equipment;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;

public class PrinterConsumableUpdateParams {

	@NotNull
	private String statusCode;

	@NotNull
	private LocalDate returnedAt;

	private boolean isDefective;

	private String returnedNotes;

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public LocalDate getReturnedAt() {
		return returnedAt;
	}

	public void setReturnedAt(LocalDate returnedAt) {
		this.returnedAt = returnedAt;
	}

	public boolean isDefective() {
		return isDefective;
	}

	public void setDefective(boolean isDefective) {
		this.isDefective = isDefective;
	}

	public String getReturnedNotes() {
		return returnedNotes;
	}

	public void setReturnedNotes(String returnedNotes) {
		this.returnedNotes = returnedNotes;
	}
}
