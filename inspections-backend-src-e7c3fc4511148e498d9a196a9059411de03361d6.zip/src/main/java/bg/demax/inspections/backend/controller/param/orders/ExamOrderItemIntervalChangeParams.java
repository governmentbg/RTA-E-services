package bg.demax.inspections.backend.controller.param.orders;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import bg.demax.inspections.backend.controller.param.SupervisorParams;

public class ExamOrderItemIntervalChangeParams extends SupervisorParams {
	@NotNull
	@Valid
	private List<IntervalParam> intervals;

	public List<IntervalParam> getIntervals() {
		return intervals;
	}

	public void setIntervals(List<IntervalParam> intervals) {
		this.intervals = intervals;
	}
}
