package bg.demax.inspections.backend.controller.param.orders;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import bg.demax.inspections.backend.controller.param.CourierBillOfLadingRequestParams;

public class ExamOrdersCourierBillOfLadingRequestParams extends CourierBillOfLadingRequestParams {

	@NotEmpty
	private List<IntervalParam> intervals;

	public List<IntervalParam> getIntervals() {
		return intervals;
	}

	public void setIntervals(List<IntervalParam> intervals) {
		this.intervals = intervals;
	}
}