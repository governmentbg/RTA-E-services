package bg.demax.inspections.backend.controller.param.orders;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

public class ExamOrdersSearchParams {

	private String cityCode;
	private List<String> statusCodes;
	private String idFirmEikOrPermitNumber;

	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate exactDate;

	public LocalDate getExactDate() {
		return this.exactDate;
	}

	public void setExactDate(LocalDate exactDate) {
		this.exactDate = exactDate;
	}

	public List<String> getStatusCodes() {
		return this.statusCodes;
	}

	public void setStatusCodes(List<String> statusCodes) {
		this.statusCodes = statusCodes;
	}

	public String getCityCode() {
		return this.cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getIdFirmEikOrPermitNumber() {
		return idFirmEikOrPermitNumber;
	}

	public void setIdFirmEikOrPermitNumber(String idFirmEikOrPermitNumber) {
		this.idFirmEikOrPermitNumber = idFirmEikOrPermitNumber;
	}
}
