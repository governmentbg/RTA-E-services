package bg.demax.inspections.backend.controller.param.orders;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InspectionBillOfLadingRequestExtParams extends InspectionBillOfLadingRequestParams {

	private String recipientAddress;

	private String recipientPersonName;

	private String recipientPersonPhone;

	private String cityName;

	private String cityType;

	private String cityRegion;

	private String objectName;

	private String ktpName;

	private Integer postCode;
}