package bg.demax.inspections.backend.controller.param.orders;

import java.math.BigDecimal;

import javax.validation.constraints.NotBlank;

import bg.demax.inspections.backend.controller.param.CourierBillOfLadingRequestParams;

public class InspectionBillOfLadingRequestParams extends CourierBillOfLadingRequestParams {
	
	@NotBlank
	private String orgUnitCode;
	
	private BigDecimal weight;
	
	private Integer packageCount;

	public String getOrgUnitCode() {
		return orgUnitCode;
	}

	public void setOrgUnitCode(String orgUnitCode) {
		this.orgUnitCode = orgUnitCode;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public Integer getPackageCount() {
		return packageCount;
	}

	public void setPackageCount(Integer packageCount) {
		this.packageCount = packageCount;
	}
}
