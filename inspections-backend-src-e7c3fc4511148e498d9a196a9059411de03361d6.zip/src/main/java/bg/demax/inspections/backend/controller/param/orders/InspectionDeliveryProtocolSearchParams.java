package bg.demax.inspections.backend.controller.param.orders;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

public class InspectionDeliveryProtocolSearchParams {

	private Long protocolNumber;

	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate date;
	private String orgUnitCode;

	public Long getProtocolNumber() {
		return protocolNumber;
	}
	
	public void setProtocolNumber(Long protocolNumber) {
		this.protocolNumber = protocolNumber;
	}
	
	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getOrgUnitCode() {
		return orgUnitCode;
	}

	public void setOrgUnitCode(String orgUnitCode) {
		this.orgUnitCode = orgUnitCode;
	}
}
