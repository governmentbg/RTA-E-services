package bg.demax.inspections.backend.controller.param.orders;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import bg.demax.inspections.backend.controller.param.SupervisorParams;

public class InspectionOrderIntervalChangeParams extends SupervisorParams {
	@NotNull
	@Valid
	private List<IntervalParam> intervals;

	private long productTypeId;
	
	public List<IntervalParam> getIntervals() {
		return intervals;
	}

	public void setIntervals(List<IntervalParam> intervals) {
		this.intervals = intervals;
	}

	public long getProductTypeId() {
		return productTypeId;
	}

	public void setProductTypeId(long productTypeId) {
		this.productTypeId = productTypeId;
	}
}
