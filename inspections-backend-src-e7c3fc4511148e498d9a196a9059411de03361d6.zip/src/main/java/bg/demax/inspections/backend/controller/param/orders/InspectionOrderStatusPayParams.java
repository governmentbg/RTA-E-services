package bg.demax.inspections.backend.controller.param.orders;

import java.time.LocalDate;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;

public class InspectionOrderStatusPayParams {
	
	@NotNull
	@Min(1)
	private Long invoiceNumber = null;
	
	@NotNull
	@PastOrPresent
	private LocalDate invoiceDate = null;

	public Long getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(Long invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public LocalDate getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(LocalDate invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
}
