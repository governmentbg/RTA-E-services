package bg.demax.inspections.backend.controller.param.orders;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

public class InspectionOrdersSearchParams {

	private String orgUnitCode;
	private List<String> statusCodes;
	private String idFirmEikOrPermitNum;

	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate exactDate;

	public String getOrgUnitCode() {
		return orgUnitCode;
	}

	public void setOrgUnitCode(String orgUnitCode) {
		this.orgUnitCode = orgUnitCode;
	}

	public LocalDate getExactDate() {
		return this.exactDate;
	}

	public void setExactDate(LocalDate exactDate) {
		this.exactDate = exactDate;
	}

	public List<String> getStatusCodes() {
		return this.statusCodes;
	}

	public void setStatusCodes(List<String> statusCodes) {
		this.statusCodes = statusCodes;
	}

	public String getIdFirmEikOrPermitNum() {
		return idFirmEikOrPermitNum;
	}

	public void setIdFirmEikOrPermitNum(String idFirmEikOrPermitNum) {
		this.idFirmEikOrPermitNum = idFirmEikOrPermitNum;
	}


}
