package bg.demax.inspections.backend.controller.param.orders;

import javax.validation.constraints.Min;

import com.fasterxml.jackson.annotation.JsonIgnore;

import bg.demax.inspections.backend.dto.orders.IInterval;

public class IntervalParam implements IInterval {
	@Min(1)
	private long fromNum;
	private long toNum;

	@JsonIgnore
	@Min(1)
	public long getQuantity() {
		return toNum - fromNum + 1;
	}
	
	public long getFromNum() {
		return fromNum;
	}
	
	public void setFromNum(long fromNum) {
		this.fromNum = fromNum;
	}

	public long getToNum() {
		return toNum;
	}

	public void setToNum(long toNum) {
		this.toNum = toNum;
	}

}
