package bg.demax.inspections.backend.controller.param.orders;

import javax.validation.constraints.Min;

public class UpdateOrderProductQuantityParams {
	@Min(1)
	private long productTypeId;
	
	@Min(1)
	private long quantity;

	public long getProductTypeId() {
		return productTypeId;
	}

	public void setProductTypeId(long productTypeId) {
		this.productTypeId = productTypeId;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

}
