package bg.demax.inspections.backend.controller.param.permit;

import javax.validation.constraints.Pattern;

import bg.demax.inspections.backend.config.InspectionWebConstants;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseReportSearchParams {

	@Pattern(regexp = InspectionWebConstants.ORG_UNIT_RDAA_PATTERN)
	private String orgUnit;
}
