package bg.demax.inspections.backend.controller.param.permit;

import java.time.LocalDate;

import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import bg.demax.inspections.backend.validation.ValidateDateRange;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ValidateDateRange(startDate = "orderDateFrom", endDate = "orderDateTo")
public class InspectionOrdersReportSearchParams extends BaseReportSearchParams {

	@Size(max = 20)
	private String searchText;
	
	@Size(max = 15)
	private String orderStatus;
	
	private Boolean hasBankStatement;
	
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate orderDateFrom;
	
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate orderDateTo;
}
