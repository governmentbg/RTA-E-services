package bg.demax.inspections.backend.controller.param.permit;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IssuedSemtReportRequestParams {
	
	@NotNull
	private String semtStatus;
	@NotNull
	private String ecoCategory;
	@NotNull
	private String publishedBy;
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate fromDate;
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate toDate;
	private Boolean isValidByCurrentMoment;
}
