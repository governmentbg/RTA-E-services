package bg.demax.inspections.backend.controller.param.permit;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Range;

import bg.demax.inspections.backend.config.InspectionWebConstants;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitAdditionalInfoParams {

	@NotBlank
	private String contactPersonName;

	@NotBlank
	private String contactPersonPhone;
	
	@NotBlank
	private String ktpRealAddress;
	
	@Range(min = 1000, max = 9999)
	private Integer ktpPostCode;
	
	private String contactPersonStationaryPhone;
	
	@Pattern(regexp = InspectionWebConstants.EMAIL_PATTERN)
	private String contactPersonEmail;
	
	@Range(min = -90, max = 90)
	private Double gpsN;
	
	@Range(min = -180, max = 180)
	private Double gpsE;
	
	@NotNull
	private Boolean hasExteriorAntenna;
}
