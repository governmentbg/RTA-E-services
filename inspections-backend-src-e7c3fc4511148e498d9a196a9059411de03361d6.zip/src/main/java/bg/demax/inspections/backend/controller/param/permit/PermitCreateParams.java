package bg.demax.inspections.backend.controller.param.permit;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import bg.demax.inspections.backend.config.InspectionWebConstants;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitCreateParams {
	
	@Size(max = 20)
	@NotBlank
	private String applicationNumber;
	
	@NotNull
	private LocalDate applicationDate;
	
	@NotBlank
	private String ktpCityCode;
	
	@Size(max = 255)
	@NotBlank
	private String ktpAddress;

	@NotBlank
	@Size(max = 80) 
	private String contactKtpPhone;
	
	@Size(max = 80) 
	@Pattern(regexp = InspectionWebConstants.EMAIL_PATTERN)
	private String contactKtpEmail;

	@NotBlank
	private String companyEik;
}
