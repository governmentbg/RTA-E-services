package bg.demax.inspections.backend.controller.param.permit;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import bg.demax.inspections.backend.validation.ValidDocumentMimeType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitInspectionParams {
	
	@NotNull
	private LocalDate inspectionDate;
	
	@NotBlank
	private String inspectionProtocolNumber;
	
	@NotBlank
	private String inspectionPaymentNumber;
	
	@NotNull
	private LocalDate inspectionProtocolDate;
	
	@NotNull
	private Boolean conclusion;
	
	@NotNull
	@ValidDocumentMimeType
	private byte[] file;
}
