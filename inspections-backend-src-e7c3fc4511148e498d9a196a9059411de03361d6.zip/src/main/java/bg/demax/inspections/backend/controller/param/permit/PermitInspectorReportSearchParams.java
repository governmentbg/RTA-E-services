package bg.demax.inspections.backend.controller.param.permit;

import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitInspectorReportSearchParams extends BaseReportSearchParams {
	
	@Size(max = 12, min = 1)
	private String searchText;
	
	private Boolean isChairman;
	
	@Size(min = 1, max = 11)
	private String inspectionType;
	private Boolean hasCard;
	
	@Size(max = 1)
	private String statusCode;

}
