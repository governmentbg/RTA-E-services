package bg.demax.inspections.backend.controller.param.permit;

import java.util.List;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import bg.demax.inspections.backend.config.InspectionWebConstants;
import bg.demax.inspections.backend.validation.KtpCategories;

public class PermitListSearchParams {

	@Size(max = 12, min = 1)
	private String searchText;
	
	@KtpCategories
	private List<String> ktpCategories;
	
	@Pattern(regexp = InspectionWebConstants.ALL_PERMIT_STATUSES_PATTERN)
	private String statusCode;
	
	@Size(max = 30)
	private String orgUnit;
	
	private Boolean isListPrinted;

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	public List<String> getKtpCategories() {
		return ktpCategories;
	}

	public void setKtpCategories(List<String> ktpCategories) {
		this.ktpCategories = ktpCategories;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getOrgUnit() {
		return orgUnit;
	}

	public void setOrgUnit(String orgUnit) {
		this.orgUnit = orgUnit;
	}
	
	public Boolean getIsListPrinted() {
		return isListPrinted;
	}

	public void setIsListPrinted(Boolean isListPrinted) {
		this.isListPrinted = isListPrinted;
	}

}
