package bg.demax.inspections.backend.controller.param.permit;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import bg.demax.inspections.backend.validation.NotNullIfAnotherFieldHasValue;
import bg.demax.inspections.backend.validation.ValidDocumentMimeType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@NotNullIfAnotherFieldHasValue(dependFieldName = "filename", fieldName = "file")
public class PermitRejectionParams {

	@Size(max = 255)
	@NotBlank
	private String reason;
	
	@ValidDocumentMimeType
	@Size(max = 200 * 1024)
	private byte[] file;
	
	@Pattern(regexp = "^(?=.*\\S+.*).{1,256}$")
	private String filename;
	
	private Boolean sendMessage = false;
}
