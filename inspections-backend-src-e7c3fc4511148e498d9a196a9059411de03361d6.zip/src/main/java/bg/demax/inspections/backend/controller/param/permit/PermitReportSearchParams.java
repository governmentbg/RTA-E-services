package bg.demax.inspections.backend.controller.param.permit;


import java.time.LocalDate;
import java.util.List;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import bg.demax.inspections.backend.config.InspectionWebConstants;
import bg.demax.inspections.backend.validation.KtpCategories;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitReportSearchParams extends BaseReportSearchParams {

	@Length(max = 12, min = 1)
	private String searchText;
	
	@Pattern(regexp = InspectionWebConstants.ALL_PERMIT_STATUSES_PATTERN)
	private String statusCode;
	
	private Integer numberOfLines;

	@KtpCategories
	private List<String> ktpCategories;
	
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate validTo;

	private Integer numberFrom;

	private Integer numberTo;
	
}

