package bg.demax.inspections.backend.controller.param.permit;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitStatusChangeParams {

	@NotBlank
	private String statusChangeCode;
	
	private LocalDate closeDate;
	
	private String closeReason;
}
