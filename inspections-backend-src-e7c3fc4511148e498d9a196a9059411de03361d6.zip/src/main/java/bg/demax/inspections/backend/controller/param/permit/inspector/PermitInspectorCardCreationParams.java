package bg.demax.inspections.backend.controller.param.permit.inspector;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.lang.Nullable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitInspectorCardCreationParams {

	@NotNull
	private Integer cardNumber;
	
	@NotBlank
	@Size(max = 19)
	private String serialNumber;
	
	@NotBlank
	@Size(max = 100)
	@Pattern(regexp = "([A-Z\\s])+")
	private String commonName;
	
	@Nullable
	@Size(max = 250)
	private String remarks;
	
}
