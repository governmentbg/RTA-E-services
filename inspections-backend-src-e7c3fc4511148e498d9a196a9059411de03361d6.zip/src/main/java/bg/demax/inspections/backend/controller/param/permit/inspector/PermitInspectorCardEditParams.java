package bg.demax.inspections.backend.controller.param.permit.inspector;

import javax.validation.constraints.NotNull;

import bg.demax.inspections.backend.validation.NotNullIfAnotherFieldHasValue;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@NotNullIfAnotherFieldHasValue(fieldName = "isActive", fieldValue = "false", dependFieldName = "remarks")
public class PermitInspectorCardEditParams extends PermitInspectorCardCreationParams {

	@NotNull
	private Boolean isActive;
	
}
