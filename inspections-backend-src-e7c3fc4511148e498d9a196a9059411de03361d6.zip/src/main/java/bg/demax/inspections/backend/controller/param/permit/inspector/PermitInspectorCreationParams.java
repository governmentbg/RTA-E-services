package bg.demax.inspections.backend.controller.param.permit.inspector;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitInspectorCreationParams extends PermitInspectorEditParams {
	
	@NotNull
	private Long subjectId;
	
	@NotBlank
	@Size(max = 10)
	private String identityNumber;
	
	@NotEmpty
	private List<Integer> certificationIds;
	
}
