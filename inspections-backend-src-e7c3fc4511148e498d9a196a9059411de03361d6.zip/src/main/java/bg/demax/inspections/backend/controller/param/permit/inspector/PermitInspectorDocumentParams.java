package bg.demax.inspections.backend.controller.param.permit.inspector;

import java.time.LocalDate;

import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import bg.demax.inspections.backend.validation.ValidDocumentMimeType;
import bg.demax.inspections.backend.validation.ValidateDateRange;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ValidateDateRange(startDate = "issuedOn", endDate = "validTo", startDateIncluded = false)
public class PermitInspectorDocumentParams {
	
	@NotNull
	private String documentNumber;
	
	@NotNull
	private Short typeCode;
	
	@NotNull
	private String issuer;
	
	@Size(min = 1, max = 120)
	private String remarks;
	
	@NotNull
	private LocalDate issuedOn;

	@FutureOrPresent
	private LocalDate validTo;
	
	@ValidDocumentMimeType
	private byte[] image;

	private String statusCode;
}
