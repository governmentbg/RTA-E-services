package bg.demax.inspections.backend.controller.param.permit.inspector;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitInspectorEditParams {

	@NotNull
	private Boolean isIncluded;

	@NotNull
	private Boolean isChairman;

	@NotNull
	private String speciality;

	@Size(max = 250)
	private String remarks;
	
	@NotNull
	private LocalDate birthDate;
	
	@NotBlank
	@Size(max = 80)
	private String firstName;
	
	@Size(max = 80)
	private String surname;
	
	@NotBlank
	@Size(max = 80)
	private String familyName;
	
	@NotBlank
	@Size(max = 3)
	private String countryCode;
	
	@NotBlank
	@Size(max = 3)
	private String regionCode;
	
	@NotBlank
	@Size(max = 5)
	private String cityCode;
	
	@NotBlank
	@Size(max = 250)
	private String address;
	
	@NotNull
	private Short educationLevelCode;
}
