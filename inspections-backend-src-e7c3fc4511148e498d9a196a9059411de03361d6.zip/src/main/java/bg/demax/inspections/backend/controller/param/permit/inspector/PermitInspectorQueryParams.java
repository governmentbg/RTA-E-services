package bg.demax.inspections.backend.controller.param.permit.inspector;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class PermitInspectorQueryParams {

	@Size(min = 3)
	private String nameSearch = null;
	
	@NotNull
	private Boolean isChairman = null;

	public String getNameSearch() {
		return nameSearch;
	}

	public void setNameSearch(String nameSearch) {
		this.nameSearch = nameSearch;
	}
	
	public Boolean getIsChairman() {
		return isChairman;
	}

	public void setIsChairman(Boolean isChairman) {
		this.isChairman = isChairman;
	}
}
