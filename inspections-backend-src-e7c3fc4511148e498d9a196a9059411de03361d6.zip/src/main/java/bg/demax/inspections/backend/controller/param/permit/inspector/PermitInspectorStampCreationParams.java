package bg.demax.inspections.backend.controller.param.permit.inspector;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;
import org.springframework.lang.Nullable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitInspectorStampCreationParams {
	
	@Nullable
	private String stampNumber;

	@Range(min = 1, max = 3)
	private Short stampTypeId;
	
	@Size(max = 250)
	private String remarks;

}
