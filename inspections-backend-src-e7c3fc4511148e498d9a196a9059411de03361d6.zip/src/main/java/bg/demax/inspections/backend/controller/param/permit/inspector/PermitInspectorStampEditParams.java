package bg.demax.inspections.backend.controller.param.permit.inspector;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;

import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorStampStatus;
import bg.demax.inspections.backend.validation.NotNullIfAnotherFieldHasValue;
import bg.demax.inspections.backend.validation.ValidDocumentMimeType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@NotNullIfAnotherFieldHasValue(fieldName = "statusCode", fieldValue = PermitInspectorStampStatus.TAKEN_CODE, dependFieldName = "revokedOn")
public class PermitInspectorStampEditParams {

	@PastOrPresent
	private LocalDate revokedOn;
	
	@NotNull
	private String statusCode;
	
	@ValidDocumentMimeType
	private byte[] protocol;
}