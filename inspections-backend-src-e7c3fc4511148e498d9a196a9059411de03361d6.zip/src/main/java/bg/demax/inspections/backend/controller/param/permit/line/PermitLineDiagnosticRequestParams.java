package bg.demax.inspections.backend.controller.param.permit.line;

import bg.demax.inspections.backend.enums.DiagnosticSoftwareStatus;
import bg.demax.inspections.backend.validation.EnumValue;

public class PermitLineDiagnosticRequestParams {

	private Integer permitNumber;
	private String orgUnitCode;
	private Boolean isCameraInPosition;
	private Boolean connectivityStatus;
	
	@EnumValue(enumClass = DiagnosticSoftwareStatus.class, nullable = true)
	private String softwareStatus;

	public Integer getPermitNumber() {
		return permitNumber;
	}

	public void setPermitNumber(Integer permitNumber) {
		this.permitNumber = permitNumber;
	}

	public String getOrgUnitCode() {
		return orgUnitCode;
	}

	public void setOrgUnitCode(String orgUnitCode) {
		this.orgUnitCode = orgUnitCode;
	}

	public Boolean getIsCameraInPosition() {
		return isCameraInPosition;
	}
	
	public void setIsCameraInPosition(Boolean isCameraInPosition) {
		this.isCameraInPosition = isCameraInPosition;
	}
	
	public Boolean getConnectivityStatus() {
		return connectivityStatus;
	}

	public void setConnectivityStatus(Boolean connectivityStatus) {
		this.connectivityStatus = connectivityStatus;
	}
	
	public String getSoftwareStatus() {
		return softwareStatus;
	}
	
	public void setSoftwareStatus(String softwareStatus) {
		this.softwareStatus = softwareStatus;
	}
}
