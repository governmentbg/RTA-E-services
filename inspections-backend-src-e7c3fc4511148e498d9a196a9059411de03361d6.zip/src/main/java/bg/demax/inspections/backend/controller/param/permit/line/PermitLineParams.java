package bg.demax.inspections.backend.controller.param.permit.line;

import java.util.Set;

import javax.validation.constraints.NotEmpty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitLineParams {

	@NotEmpty
	private Set<String> categoryCodes;
	
	@NotEmpty
	private Set<String> inspectionTypeCodes;
	
}
