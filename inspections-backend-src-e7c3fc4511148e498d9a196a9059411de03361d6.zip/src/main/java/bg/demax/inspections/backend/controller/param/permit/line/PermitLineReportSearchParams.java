package bg.demax.inspections.backend.controller.param.permit.line;

import java.util.List;

import javax.validation.constraints.Size;

import bg.demax.inspections.backend.controller.param.permit.BaseReportSearchParams;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitLineReportSearchParams extends BaseReportSearchParams {

	@Size(max = 20)
	private String searchText;
	
	private List<String> categories;
	
	private List<String> inspectionTypes;
	
	public boolean isEmpty() {
		return (this.getSearchText() == null || this.getSearchText().trim().isEmpty())
						&& (this.getOrgUnit() == null || this.getOrgUnit().trim().isEmpty())
						&& (this.getCategories() == null || this.getCategories().isEmpty())
						&& (this.getInspectionTypes() == null || this.getInspectionTypes().isEmpty());
	}
}
