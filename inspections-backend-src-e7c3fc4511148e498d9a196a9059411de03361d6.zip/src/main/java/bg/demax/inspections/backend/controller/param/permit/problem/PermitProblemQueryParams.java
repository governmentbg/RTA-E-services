package bg.demax.inspections.backend.controller.param.permit.problem;

import java.time.LocalDate;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitProblemQueryParams {

	private String searchTerm;
	
	private String searchDescription;
	
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate dateCreated;
	
	@Min(1)
	@Max(2)
	private Integer status;
	
	private String orgUnitCode;
}
