package bg.demax.inspections.backend.controller.param.permit.problem;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitProblemUpdateDescriptionParams {
	
	@NotBlank
	@Size(min = 1, max = 250)
	private String problemDescription;
	
	@Size(min = 1, max = 250)
	private String checkDescription;

}
