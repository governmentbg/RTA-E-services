package bg.demax.inspections.backend.controller.param.permit.problem;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitProblemUpdateParams {
	
	@DateTimeFormat(iso = ISO.DATE)
	@NotNull
	private LocalDate checkedOn;
	
	@NotBlank
	@Size(min = 1, max = 50)
	private String checkedBy;
	
	@NotBlank
	@Size(min = 1, max = 250)
	private String checkDescription;
}
