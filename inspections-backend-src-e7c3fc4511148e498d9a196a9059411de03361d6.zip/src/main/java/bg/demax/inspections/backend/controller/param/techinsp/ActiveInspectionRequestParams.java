package bg.demax.inspections.backend.controller.param.techinsp;

public class ActiveInspectionRequestParams {
	private String orgUnitCode;
	private Integer ktpNum;
	private String regNum;

	public String getOrgUnitCode() {
		return orgUnitCode;
	}

	public void setOrgUnitCode(String orgUnitCode) {
		this.orgUnitCode = orgUnitCode;
	}

	public Integer getKtpNum() {
		return ktpNum;
	}

	public void setKtpNum(Integer ktpNum) {
		this.ktpNum = ktpNum;
	}

	public String getRegNum() {
		return regNum;
	}

	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}

}
