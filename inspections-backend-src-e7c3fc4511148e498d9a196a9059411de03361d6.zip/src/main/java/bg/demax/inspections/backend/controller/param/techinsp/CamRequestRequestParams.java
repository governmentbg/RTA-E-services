package bg.demax.inspections.backend.controller.param.techinsp;

import javax.validation.constraints.NotNull;

public class CamRequestRequestParams {
	@NotNull
	private Integer feedNum;
	@NotNull
	private Integer resolution;

	public Integer getFeedNum() {
		return feedNum;
	}

	public void setFeedNum(Integer feedNum) {
		this.feedNum = feedNum;
	}

	public Integer getResolution() {
		return resolution;
	}

	public void setResolution(Integer resolution) {
		this.resolution = resolution;
	}
}
