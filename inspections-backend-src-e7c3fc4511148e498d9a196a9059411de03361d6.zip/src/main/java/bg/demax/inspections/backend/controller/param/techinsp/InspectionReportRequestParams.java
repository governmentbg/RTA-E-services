package bg.demax.inspections.backend.controller.param.techinsp;

import java.time.LocalDate;

import javax.validation.constraints.Min;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import bg.demax.inspections.backend.enums.InspectionReportCompareOption;
import bg.demax.inspections.backend.validation.EnumValue;
import bg.demax.techinsp.entity.InspectionConclusion;


public class InspectionReportRequestParams {

	private Integer ktpNumber;
	private String orgUnitCode;
	
	@Min(3)
	private Integer inspectionsCount;
	
	@EnumValue(enumClass = InspectionReportCompareOption.class, nullable = true)
	private String inspectionsCountOption;

	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate fromDate;

	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate toDate;

	@EnumValue(enumClass = InspectionConclusion.class, nullable = true)
	private String conclusion;

	private String title;

	public Integer getKtpNumber() {
		return ktpNumber;
	}

	public void setKtpNumber(Integer ktpNumber) {
		this.ktpNumber = ktpNumber;
	}

	public String getOrgUnitCode() {
		return orgUnitCode;
	}

	public void setOrgUnitCode(String orgUnitCode) {
		this.orgUnitCode = orgUnitCode;
	}

	public Integer getInspectionsCount() {
		return inspectionsCount;
	}

	public void setInspectionsCount(Integer inspectionsCount) {
		this.inspectionsCount = inspectionsCount;
	}
	
	public String getInspectionsCountOption() {
		return inspectionsCountOption;
	}
	
	public void setInspectionsCountOption(String inspectionsCountOption) {
		this.inspectionsCountOption = inspectionsCountOption;
	}

	public LocalDate getFromDate() {
		return fromDate;
	}

	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}

	public LocalDate getToDate() {
		return toDate;
	}

	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}
	
	public String getConclusion() {
		return conclusion;
	}
	
	public void setConclusion(String conclusion) {
		this.conclusion = conclusion;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
}
