package bg.demax.inspections.backend.controller.param.techinsp;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import bg.demax.inspections.backend.validation.EnumValue;
import bg.demax.techinsp.entity.InspectionConclusion;
import bg.demax.techinsp.entity.InspectionStatus;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InspectionRequestParams {
	
	public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm";
	
	private Integer chairmanId;
	private Integer commissionMemberId;
	
	@NotNull
	@DateTimeFormat(pattern = DATE_TIME_FORMAT)
	private LocalDateTime fromDate;
	
	@NotNull
	@DateTimeFormat(pattern = DATE_TIME_FORMAT)
	private LocalDateTime toDate;
	
	private String orgUnitCode;
	
	@EnumValue(enumClass = InspectionConclusion.class, nullable = true)
	private String conclusion;
	
	private Boolean isSuspicious;

	private Boolean isSemt;
	
	private Integer ktpNum;
	
	private List<@EnumValue(enumClass = InspectionStatus.class, nullable = true) String> statuses;
	
	public String getFiltersText() {
		StringBuilder filtersText = new StringBuilder("Филтри: ");
		if (this.fromDate != null && this.toDate != null) {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy г.");
			filtersText.append(this.fromDate.format(formatter) + " - " + this.toDate.format(formatter));
		}
		if (this.ktpNum != null) {
			filtersText.append(", Ктп № " + this.ktpNum);
		}
		if (this.chairmanId != null) {
			filtersText.append(", Председател " + this.chairmanId);
		}
		if (this.commissionMemberId != null) {
			filtersText.append(", Член на комисията " + this.commissionMemberId);
		}
		if (this.orgUnitCode != null) {
			filtersText.append(", Код на орг. единица " + this.orgUnitCode);
		}
		if (this.conclusion != null) {
			filtersText.append(", Заключение - " );
			if (this.conclusion == "IA") {
				filtersText.append("Допуска се");
			} else if (this.conclusion == "TA") {
				filtersText.append("Временно се допуска");
			} else if (this.conclusion == "NA") {
				filtersText.append("Не се допуска");
			}
		}
		if (this.isSuspicious != null && this.isSuspicious == true) {
			filtersText.append(", Съмнителни - Да");
		}
		if (this.isSemt != null && this.isSemt == true) {
			filtersText.append(", СЕМТ - Да");
		}
		if (this.statuses != null && this.statuses.size() > 0) {
			filtersText.append(", Статус - ");
			if (this.getStatuses().size() == 1) {
				filtersText.append(InspectionStatus.fromCode(this.statuses.get(0)).getDescription());
			} else {
				filtersText.append("Всички завършени ");
			}
		}
		
		return filtersText.toString();
	}
}
