package bg.demax.inspections.backend.controller.param.techinsp;

import javax.validation.constraints.Size;

import bg.demax.inspections.backend.validation.techinsp.ValidInspectionSpecificRoleSearchRequestParams;

@ValidInspectionSpecificRoleSearchRequestParams
public class InspectionSpecificRoleSearchRequestParams {

	@Size(max = 13)
	private String ownerIdentityNumber = null;

	@Size(max = 10)
	private String inspectionPersonEgn = null;

	public String getOwnerIdentityNumber() {
		return ownerIdentityNumber;
	}

	public void setOwnerIdentityNumber(String ownerIdentityNumber) {
		this.ownerIdentityNumber = ownerIdentityNumber;
	}

	public String getInspectionPersonEgn() {
		return inspectionPersonEgn;
	}

	public void setInspectionPersonEgn(String inspectionPersonEgn) {
		this.inspectionPersonEgn = inspectionPersonEgn;
	}

	public String getFiltersText() {
		String filtersText = "Филтри: ";
		if (this.ownerIdentityNumber != null) {
			filtersText += "ЕГН/ЛНЧ на собственик " + this.ownerIdentityNumber;
		} else if (this.inspectionPersonEgn != null) {
			filtersText += "ЕГН на лице представило ППС " + this.inspectionPersonEgn;
		}
		return filtersText;
	}
}
