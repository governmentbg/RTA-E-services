package bg.demax.inspections.backend.controller.param.techinsp;

import bg.demax.inspections.backend.validation.techinsp.ValidInspectionSpecificSearchRequestParams;

@ValidInspectionSpecificSearchRequestParams
public class InspectionSpecificSearchRequestParams {

	private String regNum;
	private Long protocolNum;
	private Long hologram;
	private String vinOrRama;

	public String getRegNum() {
		return regNum;
	}

	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}

	public Long getProtocolNum() {
		return protocolNum;
	}

	public void setProtocolNum(Long protocolNum) {
		this.protocolNum = protocolNum;
	}

	public Long getHologram() {
		return hologram;
	}

	public void setHologram(Long hologram) {
		this.hologram = hologram;
	}

	public String getVinOrRama() {
		return vinOrRama;
	}

	public void setVinOrRama(String vinOrRama) {
		this.vinOrRama = vinOrRama;
	}
	
	public String getFilterText() {
		String filterText = "Филтри: ";
		if (this.hologram != null) {
			filterText += "Холограма - " + this.hologram;
		} else if (this.protocolNum != null) {
			filterText += "Номер на протокол - " + this.protocolNum;
		} else if (this.regNum != null) {
			filterText += "Регистрационен номер - " + this.regNum;
		} else if (this.vinOrRama != null) {
			filterText += "VIN или Рама - " + this.vinOrRama;
		}
		return filterText;
	}
}
