package bg.demax.inspections.backend.controller.param.techinsp;

import java.time.LocalDate;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

public class InspectionTypesCountByKtpReportRequestParams {

	@NotNull
	@Min(1)
	private Integer ktpNumber;

	@NotNull
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate fromDate;

	@NotNull
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate toDate;
	
	private String title;

	public Integer getKtpNumber() {
		return ktpNumber;
	}

	public void setKtpNumber(Integer ktpNumber) {
		this.ktpNumber = ktpNumber;
	}

	public LocalDate getFromDate() {
		return fromDate;
	}

	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}

	public LocalDate getToDate() {
		return toDate;
	}

	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
}
