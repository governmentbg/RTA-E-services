package bg.demax.inspections.backend.controller.param.techinsp;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.lang.Nullable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InspectionTypesCountReportRequestParams {

	@NotBlank
	private String orgUnitCode;

	@NotNull
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate fromDate;

	@NotNull
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate toDate;
	
	@Nullable
	private String vehicleCategoryCode;

	private String title;
}
