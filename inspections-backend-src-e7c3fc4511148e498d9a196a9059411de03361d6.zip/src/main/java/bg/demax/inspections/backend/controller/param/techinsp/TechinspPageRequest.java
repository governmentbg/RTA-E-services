package bg.demax.inspections.backend.controller.param.techinsp;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import bg.demax.hibernate.paging.OrderClause;
import bg.demax.hibernate.paging.OrderDirection;
import bg.demax.hibernate.paging.PageRequest;

public class TechinspPageRequest extends PageRequest {
	private static final String DIRECTION_ASCENDING = "asc";
	private static final String DIRECTION_DESCENDING = "desc";
	
	private static final String ORDER_BY_ID = "id";
	
	@Min(1)
	private int page;
	
	@Min(1)
	@Max(100)
	private int pageSize;
	
	@NotBlank
	@Pattern(regexp = "^(" + ORDER_BY_ID + ")$")
	private String orderBy = null;
	
	@NotBlank
	@Pattern(regexp = "^(" + DIRECTION_ASCENDING + "|" + DIRECTION_DESCENDING + ")$")
	private String direction = null;
	
	private boolean hasSetOrderClause = false;
	
	public int getPage() {
		return page;
	}
	
	@Override
	public PageRequest setPage(int page) {
		this.page = page;
		return this;
	}

	public int getPageSize() {
		return pageSize;
	}

	@Override
	public PageRequest setPageSize(int pageSize) {
		this.pageSize = pageSize;
		return this;
	}
	
	@Override
	public int getPageOffset() {
		return (page - 1) * pageSize;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
		setOrderByClauseIfDirectionAndOrderByAreNotNull();
	}

	public String getOrderBy() {
		return orderBy;
	}
	
	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
		setOrderByClauseIfDirectionAndOrderByAreNotNull();
	}
		
	private void setOrderByClauseIfDirectionAndOrderByAreNotNull() {
		if (this.direction == null || this.orderBy == null || this.hasSetOrderClause) {
			return;
		}
		
		OrderDirection orderDirection = null;
		if (this.direction.equals(DIRECTION_ASCENDING)) {
			orderDirection = OrderDirection.ASCENDING;
		} else {
			orderDirection = OrderDirection.DESCENDING;
		}
		
		String orderByQueryProp =  "insp.id";
		
		OrderClause orderClause = new OrderClause(orderByQueryProp, orderDirection);
		addOrderClause(orderClause);
		this.hasSetOrderClause = true;
	}
}