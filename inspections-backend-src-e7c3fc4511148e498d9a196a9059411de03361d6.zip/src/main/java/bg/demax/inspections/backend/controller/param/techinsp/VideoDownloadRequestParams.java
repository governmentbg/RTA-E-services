package bg.demax.inspections.backend.controller.param.techinsp;

public class VideoDownloadRequestParams {

	private String orgUnitCode;
	private Integer ktpNum;
	private String regNum;
	private Long protocolNum;
	private Long hologramNum;
	private Integer statusId;
	
	public String getOrgUnitCode() {
		return orgUnitCode;
	}
	
	public void setOrgUnitCode(String orgUnitCode) {
		this.orgUnitCode = orgUnitCode;
	}
	
	public Integer getKtpNum() {
		return ktpNum;
	}
	
	public void setKtpNum(Integer ktpNum) {
		this.ktpNum = ktpNum;
	}
	
	public String getRegNum() {
		return regNum;
	}
	
	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}
	
	public Long getProtocolNum() {
		return protocolNum;
	}
	
	public void setProtocolNum(Long protocolNum) {
		this.protocolNum = protocolNum;
	}
	
	public Long getHologramNum() {
		return hologramNum;
	}
	
	public void setHologramNum(Long hologramNum) {
		this.hologramNum = hologramNum;
	}

	public Integer getStatusId() {
		return statusId;
	}
	
	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}
}
