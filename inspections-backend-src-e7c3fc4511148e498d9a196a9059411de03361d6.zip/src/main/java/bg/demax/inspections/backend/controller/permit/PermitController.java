package bg.demax.inspections.backend.controller.permit;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.apache.tika.Tika;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;

import bg.demax.hibernate.paging.OrderClause;
import bg.demax.hibernate.paging.OrderDirection;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.InspectionApplication;
import bg.demax.inspections.backend.controller.param.PaginationQueryParams;
import bg.demax.inspections.backend.controller.param.permit.PermitAdditionalInfoParams;
import bg.demax.inspections.backend.controller.param.permit.PermitCreateParams;
import bg.demax.inspections.backend.controller.param.permit.PermitInspectionParams;
import bg.demax.inspections.backend.controller.param.permit.PermitListSearchParams;
import bg.demax.inspections.backend.controller.param.permit.PermitRejectionParams;
import bg.demax.inspections.backend.controller.param.permit.PermitStatusChangeParams;
import bg.demax.inspections.backend.controller.param.permit.inspector.PermitInspectorCardCreationParams;
import bg.demax.inspections.backend.controller.param.permit.inspector.PermitInspectorCardEditParams;
import bg.demax.inspections.backend.controller.param.permit.inspector.PermitInspectorCreationParams;
import bg.demax.inspections.backend.controller.param.permit.inspector.PermitInspectorDocumentParams;
import bg.demax.inspections.backend.controller.param.permit.inspector.PermitInspectorEditParams;
import bg.demax.inspections.backend.controller.param.permit.inspector.PermitInspectorStampCreationParams;
import bg.demax.inspections.backend.controller.param.permit.inspector.PermitInspectorStampEditParams;
import bg.demax.inspections.backend.controller.param.permit.line.PermitLineParams;
import bg.demax.inspections.backend.dto.InspectorCertificationLightWithCanEditFlagDto;
import bg.demax.inspections.backend.dto.SubjectCardDto;
import bg.demax.inspections.backend.dto.equipment.HardwareBySerialNumberDto;
import bg.demax.inspections.backend.dto.equipment.HardwareDeviceIdentifierDto;
import bg.demax.inspections.backend.dto.inspections.DepriveOfRightsVo;
import bg.demax.inspections.backend.dto.inspections.PermitInspectorIdWithReason;
import bg.demax.inspections.backend.dto.inspections.PermitInspectorWithPermitNumbersDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDetailsDocumentVersionDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDetailsDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDetailsPermitInspectorDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDetailsPermitLineDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDocumentDetailsDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDocumentDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitInfoDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitReportDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitShippingInfoDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitStatusAndNumberDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorDocumentLightDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorStampDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorStampVersionDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorVersionDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorWithEducationDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineDetailsDocumentVersionDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineDocumentDetailsDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineDocumentDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineRemoveHardwareParams;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineVersionDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitListItemDto;
import bg.demax.inspections.backend.dto.techinsp.permit.problem.PermitProblemDetailsDto;
import bg.demax.inspections.backend.entity.DocumentStatus;
import bg.demax.inspections.backend.enums.ReportTypeCode;
import bg.demax.inspections.backend.exception.UnableToGenerateJasperReportException;
import bg.demax.inspections.backend.export.permit.PermitReportParamsLight;
import bg.demax.inspections.backend.search.PermitVersionSearch;
import bg.demax.inspections.backend.service.EmailService;
import bg.demax.inspections.backend.service.ReportLogService;
import bg.demax.inspections.backend.service.permit.PermitDocumentService;
import bg.demax.inspections.backend.service.permit.PermitInspectionService;
import bg.demax.inspections.backend.service.permit.PermitService;
import bg.demax.inspections.backend.service.permit.inspector.PermitInspectorService;
import bg.demax.inspections.backend.service.permit.inspector.SubjectCardService;
import bg.demax.inspections.backend.service.permit.inspector.SubjectVersionDocumentService;
import bg.demax.inspections.backend.service.permit.line.PermitLineDocumentService;
import bg.demax.inspections.backend.service.permit.line.PermitLineService;
import bg.demax.inspections.backend.vo.ApprovePermitEmailsVo;
import bg.demax.lib.jasper.BeanReportParametersMapper;
import bg.demax.lib.jasper.ReportParametersMapper;
import bg.demax.specialist.registry.common.dto.certification.InspectorCertificationPreviewLightDto;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimplePdfExporterConfiguration;

@RestController
@RequestMapping("/api/permits")
public class PermitController {

	@Autowired
	private PermitService permitService;

	@Autowired
	private PermitDocumentService documentService;

	@Autowired
	private SubjectVersionDocumentService subjectVersionDocumentService;

	@Autowired
	private PermitInspectorService permitInspectorService;

	@Autowired
	private PermitLineService permitLineService;

	@Autowired
	private PermitLineDocumentService permitLineDocumentService;

	@Autowired
	private SubjectCardService subjectCardService;

	@Autowired
	private EmailService emailService;

	@Autowired
	private PermitInspectionService permitInspectionService;
	
	@Autowired
	private ReportLogService reportLogService;
		
	@Value("${inspections.backend.permitReportPath}")
	private String permitReportPath;
	@Value("${inspections.backend.permitReportLinesPath}")
	private String permitReportLinesPath;
	@Value("${inspections.backend.permitReportInspectorsPath}")
	private String permitReportInspectorsPath;
	@Value("${inspections.backend.permitReportLightPath}")
	private String permitReportLightPath;
	@Value("${inspections.backend.permitReportLightDuplicatePath}")
	private String permitReportLightDuplicatePath;

	private ReportParametersMapper reportParametersMapper = new BeanReportParametersMapper();

	// Permit

	@GetMapping
	public PageResult<PermitListItemDto> getPagedPermitsBySearch(@Valid PermitListSearchParams params,
			@Valid PaginationQueryParams paginationParams) throws JsonProcessingException {
		PermitVersionSearch search = new PermitVersionSearch();
		BeanUtils.copyProperties(params, search);
		if (params.getOrgUnit() != null) {
			search.setOrgUnit(Arrays.asList(params.getOrgUnit()));			
		}

		PageRequest pageRequest = new PageRequest();
		BeanUtils.copyProperties(paginationParams, pageRequest);
		OrderClause clause1 = new OrderClause("id", OrderDirection.DESCENDING);
		pageRequest.addOrderClause(clause1);

		PageResult<PermitListItemDto> pageResult = permitService.getPermitsBySearch(search, pageRequest);
		reportLogService.logReport(ReportTypeCode.PERMITS_SEARCH, params);
		
		return pageResult;
	}

	@GetMapping("/count-by-search")
	public int getPermitsCountBySearch(@Valid PermitListSearchParams params) {
		PermitVersionSearch search = new PermitVersionSearch();
		BeanUtils.copyProperties(params, search);
		return permitService.getPermitCountBySearch(search);
	}

	@GetMapping("/by-number/{number}")
	public PermitDto getPermitDtoByNumber(@PathVariable("number") int permitNumber) {
		return permitService.getPermitDtoByNumber(permitNumber);
	}

	@GetMapping("/by-number/{number}/problems")
	public PermitProblemDetailsDto getPermitByNumberForProblems(@PathVariable("number") int permitNumber) {
		return permitService.getPermitProblemDetailsDtoByPermitNumberUsingPermitLink(permitNumber);
	}

	@GetMapping("/{number}/shipping-info")
	public PermitShippingInfoDto getShippingInfoByNumber(@PathVariable("number") int permitNumber) {
		return permitService.getPermitShippingInfoDtoByNumber(permitNumber);
	}

	@GetMapping("/{id}/techinsp")
	public PermitDetailsDto getPermitDetailsByPermitId(@PathVariable("id") int permitId) {
		return permitService.getPermitDetailsDtoByTechinspPermitId(permitId);
	}

	@GetMapping("/{id}")
	public PermitDetailsDto getPermitDetailsById(@PathVariable("id") int permitVersionId) {
		return permitService.getPermitDetailsDtoById(permitVersionId);
	}

	@GetMapping("/{id}/status-number")
	public PermitStatusAndNumberDto getPermitStatusAndNumberDtoByPermitId(@PathVariable("id") int permitVersionId) {
		return permitService.getPermitStatusCodeAndNumberByPermitVersionId(permitVersionId);
	}

	@GetMapping("/{id}/documents")
	public PageResult<PermitDetailsDocumentVersionDto> getPermitDetailsDocumentVersionsPage(
			@PathVariable("id") int permitVersionId, @RequestParam("page") int page) {
		return permitService.getPermitDetailsDocumentVersionsPage(permitVersionId, page);
	}

	@GetMapping("/{id}/inspectors")
	public PageResult<PermitDetailsPermitInspectorDto> getPermitDetailsPermitInspectorsPage(
			@PathVariable("id") int permitVersionId, @RequestParam("page") int page) {
		return permitService.getPermitDetailsPermitInspectorVersionsPage(permitVersionId, page);
	}

	@GetMapping("/{id}/lines")
	public PageResult<PermitDetailsPermitLineDto> getPermitDetailsPermitLinesPage(
			@PathVariable("id") int permitVersionId, @RequestParam("page") int page) {
		return permitService.getPermitDetailsPermitLineVersionsPage(permitVersionId, page);
	}

	@PutMapping("/{id}/send-to-iaaa")
	public void sendPermitDetailsToIaaa(@PathVariable("id") int permitVersionId) {
		permitService.sendPermitToIaaa(permitVersionId);
	}

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public int createPermit(@Valid @RequestBody PermitCreateParams params) {
		return permitService.createNewPermitVersion(params);
	}

	@PostMapping("/{id}")
	@ResponseStatus(HttpStatus.CREATED)
	public int createDraft(@PathVariable("id") int permitVersionId) {
		return permitService.createDraft(permitVersionId);
	}

	@DeleteMapping("/{id}")
	public void deletePermit(@PathVariable("id") int permitVersionId) {
		permitService.deletePermitVersion(permitVersionId);
	}

	@PutMapping("/{id}/approve")
	public void approvePermit(@PathVariable("id") int permitId,
			@DateTimeFormat(iso = ISO.DATE) @RequestParam(required = false) LocalDate validFrom,
			@DateTimeFormat(iso = ISO.DATE) @RequestParam(required = false) LocalDate closeDate) {
		ApprovePermitEmailsVo vo = permitService.approvePermit(permitId, validFrom, closeDate);
		emailService.sendEmails(vo);
	}

	@PutMapping("/{id}/reject")
	public void rejectPermit(@PathVariable("id") int permitId, @Valid @RequestBody PermitRejectionParams dto) {
		permitService.rejectPermit(permitId, dto);
	}

	@GetMapping("/{permitVersionId}/rejection/file")
	public ResponseEntity<byte[]> getPermitRejectionPdf(@PathVariable("permitVersionId") int permitVersionId) {
		byte[] result = permitService.getPermitRejectionFile(permitVersionId);
		String contentType = getMimeType(result);
		HttpHeaders headers = new HttpHeaders();
		if (contentType != null) {
			headers.add(HttpHeaders.CONTENT_TYPE, contentType);
		}
		ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(result, headers, HttpStatus.OK);
		return response;
	}

	@PutMapping("/{id}/return")
	public void returnPermitForCorrection(@PathVariable("id") int permitId,
			@Valid @RequestBody PermitRejectionParams dto) {
		permitService.returnPermitForCorrection(permitId, dto);
	}

	@PatchMapping("/{id}/additional-info")
	public void updatePermitAdditionalInfo(@PathVariable("id") int permitId,
			@Valid @RequestBody PermitAdditionalInfoParams params) {
		permitService.updatePermitAdditionalInfo(permitId, params);
	}

	@PatchMapping("/{id}/company")
	public void changeCompany(@PathVariable("id") int permitId, @RequestBody @Valid @NotBlank String companyEik) {
		permitService.changeCompany(permitId, companyEik);
	}

	@PatchMapping("/{id}/info")
	public void updatePermitInfo(@Valid @RequestBody PermitInfoDto dto, @PathVariable("id") int permitId) {
		permitService.updatePermitInfo(dto, permitId);
	}

	@GetMapping(value = "/{id}/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<byte[]> getPermitListAsPdf(@PathVariable("id") int permitVersionId) {
		PermitReportDto dto = permitService.getPermitReportDtoByPermitVersionId(permitVersionId);
		ByteArrayOutputStream out = null;
		try {
			List<JasperPrint> jasperPrints = new ArrayList<JasperPrint>();

			JasperReport report1;
			try {
				report1 = JasperCompileManager
						.compileReport(InspectionApplication.class.getResourceAsStream(permitReportPath));
				JasperPrint print1 = JasperFillManager.fillReport(report1,
						reportParametersMapper.convertToParametersMap(dto.getPermitDetails()), new JREmptyDataSource());
				JasperReport report2 = JasperCompileManager
						.compileReport(InspectionApplication.class.getResourceAsStream(permitReportLinesPath));
				JasperPrint print2 = JasperFillManager.fillReport(report2, null,
						new JRBeanCollectionDataSource(dto.getPermitLines()));
				JasperReport report3 = JasperCompileManager
						.compileReport(InspectionApplication.class.getResourceAsStream(permitReportInspectorsPath));
				JasperPrint print3 = JasperFillManager.fillReport(report3, null,
						new JRBeanCollectionDataSource(dto.getPermitInspectors()));
				jasperPrints.add(print1);
				jasperPrints.add(print2);
				jasperPrints.add(print3);

				JRPdfExporter exporter = new JRPdfExporter();
				SimplePdfExporterConfiguration configuration = new SimplePdfExporterConfiguration();
				exporter.setConfiguration(configuration);
				out = new ByteArrayOutputStream();
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));
				exporter.setExporterInput(SimpleExporterInput.getInstance(jasperPrints));
				exporter.exportReport();
			} catch (JRException e) {
				throw new UnableToGenerateJasperReportException("");
			}

			byte[] bytes = out.toByteArray();
			HttpHeaders headers = new HttpHeaders();
			headers.add(HttpHeaders.CONTENT_DISPOSITION, String.format("attachment; filename=\"%s_%s_%s\"", "permit",
					dto.getPermitDetails().getPermitNumber(), "details.pdf"));
			ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(bytes, headers, HttpStatus.OK);
			return response;
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					throw new UnableToGenerateJasperReportException("");
				}
				permitService.setListPrintDate(permitVersionId, LocalDate.now());
			}
		}
	}

	@GetMapping(value = "/{id}/pdf-light", produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<byte[]> getPermitReportLightPdf(@PathVariable("id") int permitVersionId) {
		PermitReportParamsLight params = permitService.getPermitReportLightParamsByPermitVersionId(permitVersionId);

		ByteArrayOutputStream out = null;
		try {
			JasperPrint print = new JasperPrint();
			InputStream inputStream = InspectionApplication.class.getResourceAsStream(permitReportLightPath);
			try {
				JasperReport report = JasperCompileManager.compileReport(inputStream);
				print = JasperFillManager.fillReport(report, reportParametersMapper.convertToParametersMap(params),
						new JREmptyDataSource());
				out = new ByteArrayOutputStream();

				JRPdfExporter exporter = new JRPdfExporter();

				exporter.setExporterInput(new SimpleExporterInput(print));
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));
				SimplePdfExporterConfiguration configuration = new SimplePdfExporterConfiguration();
				exporter.setConfiguration(configuration);

				exporter.exportReport();
				byte[] bytes = out.toByteArray();
				HttpHeaders headers = new HttpHeaders();
				headers.add(HttpHeaders.CONTENT_DISPOSITION,
						String.format("attachment; filename=\"%s_%s.pdf\"", "permit", params.getPermitNumber()));
				ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(bytes, headers, HttpStatus.OK);
				return response;
			} catch (JRException e) {
				throw new UnableToGenerateJasperReportException("unable to generate jasper report");
			}
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					throw new UnableToGenerateJasperReportException("Unable to close byte array outputstream");
				}
			}
		}
	}

	@GetMapping(value = "/{id}/pdf-light-duplicate", produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<byte[]> getPermitReportLightDuplicatePdf(@PathVariable("id") int permitVersionId) {
		PermitReportParamsLight params = permitService.getPermitReportLightParamsByPermitVersionId(permitVersionId);

		ByteArrayOutputStream out = null;
		try {
			JasperPrint print = new JasperPrint();
			InputStream inputStream = InspectionApplication.class.getResourceAsStream(permitReportLightDuplicatePath);
			try {
				JasperReport report = JasperCompileManager.compileReport(inputStream);
				print = JasperFillManager.fillReport(report, reportParametersMapper.convertToParametersMap(params),
						new JREmptyDataSource());
				out = new ByteArrayOutputStream();

				JRPdfExporter exporter = new JRPdfExporter();

				exporter.setExporterInput(new SimpleExporterInput(print));
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));
				SimplePdfExporterConfiguration configuration = new SimplePdfExporterConfiguration();
				exporter.setConfiguration(configuration);

				exporter.exportReport();
				byte[] bytes = out.toByteArray();
				HttpHeaders headers = new HttpHeaders();
				headers.add(HttpHeaders.CONTENT_DISPOSITION,
						String.format("attachment; filename=\"%s_%s.pdf\"", "permit", params.getPermitNumber()));
				ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(bytes, headers, HttpStatus.OK);
				return response;
			} catch (JRException e) {
				throw new UnableToGenerateJasperReportException("unable to generate jasper report");
			}
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					throw new UnableToGenerateJasperReportException("Unable to close byte array outputstream");
				}
			}
		}
	}

	@PutMapping("/{id}/reissue")
	public int reissuePermit(@PathVariable("id") int permitVersionId,
			@Valid @NotBlank @RequestParam String applicationNumber,
			@Valid @NotNull @DateTimeFormat(iso = ISO.DATE) @RequestParam LocalDate applicationDate) {
		return permitService.reissuePermit(permitVersionId, applicationNumber, applicationDate);
	}

	@PutMapping("/{id}/status")
	public int changePermitStatus(@PathVariable("id") int permitVersionId,
			@RequestBody @Valid PermitStatusChangeParams params) {
		return permitService.changePermitStatus(permitVersionId, params);
	}

	// Permit Inspectors

	@GetMapping("/{versionId}/inspectors/{inspectorVersionId}")
	public PermitInspectorVersionDto getPermitInspectorVersion(@PathVariable("versionId") int permitVersionId,
			@PathVariable("inspectorVersionId") int inspectorVersionId) {
		return permitInspectorService.getPermitInspectorVersion(permitVersionId, inspectorVersionId);
	}

	@GetMapping("/{versionId}/inspectors/deprive-of-rights")
	public List<PermitInspectorWithPermitNumbersDto> getInspectorsForDepriveOfRights(
			@PathVariable("versionId") int permitVersionId) {
		return permitInspectorService.getInspectorsForDepriveOfRights(permitVersionId);
	}

	@PutMapping("/{versionId}/inspectors/deprive-of-rights")
	public int depriveInspectorsOfRights(@PathVariable("versionId") int permitVersionId,
			@RequestBody List<PermitInspectorIdWithReason> inspectorIdsWithReasons) {
		DepriveOfRightsVo vo = permitInspectorService.depriveInspectorsOfRights(permitVersionId, inspectorIdsWithReasons);
		
		emailService.sendPermitInvalidationEmails(vo);
		
		return vo.getPermitVersionIdToReturn();
	}
	
	@GetMapping("/{versionId}/inspectors/deprive-of-rights-check")
	public Set<Integer> checkDepriveInspectorsOfRights(@PathVariable("versionId") int permitVersionId,
			@RequestParam List<Integer> inspectorIds) {
		return permitInspectorService.getInvalidatedPermitNumbersCausedByInspectorRightsDeprivation(permitVersionId, inspectorIds);
	}

	@GetMapping("/{versionId}/inspectors/{inspectorVersionId}/subject-id")
	public long getPermitInspectorSubjectId(@PathVariable("versionId") int permitVersionId,
			@PathVariable("inspectorVersionId") int inspectorVersionId) {
		return permitInspectorService.getInspectorSubjectIdByPermitVersionIdAndInspectorVersionId(permitVersionId, inspectorVersionId);
	}

	@GetMapping("/{versionId}/inspectors/{inspectorVersionId}/education")
	public PermitInspectorWithEducationDto getPermitInspectorWithEducation(
			@PathVariable("versionId") int permitVersionId,
			@PathVariable("inspectorVersionId") int inspectorVersionId) {
		return permitInspectorService.findPermitInspectorWithEducationById(permitVersionId, inspectorVersionId);
	}

	@PostMapping("/{id}/inspectors")
	@ResponseStatus(HttpStatus.CREATED)
	public int createPermitInspectorVersion(@Valid @RequestBody PermitInspectorCreationParams params,
			@PathVariable("id") int permitVersionId) {
		return permitInspectorService.createNewPermitInspectorVersion(params, permitVersionId);
	}

	@PutMapping("/{versionId}/inspectors/{inspectorVersionId}")
	public int updatePermitInspectorVersion(@Valid @RequestBody PermitInspectorEditParams params,
			@PathVariable("versionId") int permitVersionId,
			@PathVariable("inspectorVersionId") int inspectorVersionId) {
		return permitInspectorService.updatePermitInspectorVersion(permitVersionId, inspectorVersionId, params);
	}

	@DeleteMapping("/{versionId}/inspectors/{inspectorVersionId}")
	public void deletePermitInspectorVersionForCreatedPermit(@PathVariable("versionId") int permitVersionId,
			@PathVariable("inspectorVersionId") int inspectorVersionId) {
		permitInspectorService.deletePermitInspectorVersion(permitVersionId, inspectorVersionId);
	}

	@GetMapping("/{versionId}/inspectors/{inspectorVersionId}/certifications")
	public PageResult<InspectorCertificationLightWithCanEditFlagDto> getPermitInspectorVersionCertifications(
			@PathVariable("versionId") int permitVersionId, @PathVariable("inspectorVersionId") int inspectorVersionId,
			@Valid PaginationQueryParams params) {
		return permitInspectorService.getPermitInspectorCertificationsByInpsectorVersionId(permitVersionId,
				inspectorVersionId, params);
	}

	@PostMapping("/{versionId}/inspectors/{inspectorVersionId}/certifications")
	public int addPermitInspectorVersionCertifications(@PathVariable("versionId") int permitVersionId,
			@PathVariable("inspectorVersionId") int inspectorVersionId, @RequestBody List<Integer> ids) {
		return permitInspectorService.addPermitInspectorCertificationsByInpsectorVersionId(permitVersionId, inspectorVersionId,
				ids);
	}

	@GetMapping("/{versionId}/inspectors/{inspectorVersionId}/certifications/{certId}")
	public InspectorCertificationPreviewLightDto getInspectorCertificationPreview(
			@PathVariable("versionId") int permitVersionId, @PathVariable("inspectorVersionId") int inspectorVersionId,
			@PathVariable("certId") int certId) {
		return permitInspectorService.getInspectorCertificationPreviewById(permitVersionId, inspectorVersionId, certId);
	}

	@DeleteMapping("/{versionId}/inspectors/{inspectorVersionId}/certifications/{certId}")
	public int deletePermitInspectorVersionCertification(@PathVariable("versionId") int permitVersionId,
			@PathVariable("inspectorVersionId") int inspectorVersionId, @PathVariable("certId") int certId) {
		return permitInspectorService.deletePermitInspectorCertificationById(permitVersionId, inspectorVersionId, certId);
	}

	// Permit Documents

	@GetMapping("/{permitVersionId}/documents/{docVersionId}")
	public PermitDocumentDetailsDto getPermitDocument(@PathVariable("docVersionId") int docVersionId,
			@PathVariable("permitVersionId") int permitVersionId) {
		return documentService.getPermitDocument(docVersionId, permitVersionId);
	}

	@GetMapping(value = "/{permitVersionId}/documents/{docVersionId}/pdf")
	public ResponseEntity<byte[]> getPermitDocumentPdf(@PathVariable("docVersionId") int docVersionId,
			@PathVariable("permitVersionId") int permitVersionId) {
		byte[] result = documentService.getPermitDocumentPdf(docVersionId, permitVersionId);

		
		String contentType = getMimeType(result);
		HttpHeaders headers = new HttpHeaders();
		if (contentType != null) {
			headers.add(HttpHeaders.CONTENT_TYPE, contentType);
		}
		ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(result, headers, HttpStatus.OK);
		return response;
	}

	@PostMapping("/{permitVersionId}/documents")
	@ResponseStatus(code = HttpStatus.CREATED)
	public void addPermitDocument(@Valid @RequestBody PermitDocumentDto dto,
			@PathVariable("permitVersionId") int permitVersionId) {
		documentService.addPermitDocument(dto, permitVersionId);
	}

	@PutMapping("/{permitVersionId}/documents/{docVersionId}/new")
	public void editNewPermitDocument(@PathVariable("docVersionId") int docVersionId,
			@Valid @RequestBody PermitDocumentDto dto, @PathVariable("permitVersionId") int permitVersionId) {
		documentService.editNewPermitDocument(docVersionId, permitVersionId, dto);
	}

	@PutMapping("/{permitVersionId}/documents/{docVersionId}/approved")
	public void editApprovedPermitDocument(@PathVariable("docVersionId") int docVersionId,
		@RequestParam @NotBlank
		@Pattern(regexp = "^(" 
			+ DocumentStatus.VALID_CODE + "|" 
			+ DocumentStatus.EXPIRED_CODE + "|" 
			+ DocumentStatus.INVALID_CODE + ")$") 
			String statusCode, 
		@PathVariable("permitVersionId") int permitVersionId) {
		documentService.editApprovedPermitDocument(docVersionId, permitVersionId, statusCode);
	}

	@DeleteMapping("/{permitVersionId}/documents/{docVersionId}")
	public void deleteNewPermitDocument(@PathVariable("docVersionId") int docVersionId,
			@PathVariable("permitVersionId") int permitVersionId) {
		documentService.deleteNewPermitDocument(docVersionId, permitVersionId);
	}

	// Permit Inspections

	@PostMapping("/{permitVersionId}/inspections")
	@ResponseStatus(code = HttpStatus.CREATED)
	public int addPermitInspection(@PathVariable("permitVersionId") int permitVersionId,
			@Valid @RequestBody PermitInspectionParams params) {
		return permitInspectionService.addPermitInspection(permitVersionId, params);
	}

	@DeleteMapping("/{permitVersionId}/inspections/{permitInspectionId}")
	public void deletePermitInspection(@PathVariable("permitVersionId") int permitVersionId,
			@PathVariable("permitInspectionId") int permitInspectionId) {
		permitInspectionService.deletePermitInspection(permitVersionId, permitInspectionId);
	}

	@GetMapping("/{permitVersionId}/inspections/{permitInspectionId}/file")
	public ResponseEntity<byte[]> getPermitInspectionFile(@PathVariable("permitVersionId") int permitVersionId,
			@PathVariable("permitInspectionId") int permitInspectionId) {

		byte[] result = permitInspectionService.getPermitInspectionFile(permitVersionId, permitInspectionId);
		String contentType = getMimeType(result);
		HttpHeaders headers = new HttpHeaders();
		if (contentType != null) {
			headers.add(HttpHeaders.CONTENT_TYPE, contentType);
		}
		ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(result, headers, HttpStatus.OK);
		return response;
	}

	// Permit Lines

	@GetMapping("/{permitVersionId}/lines/{permitLineId}")
	public PermitLineVersionDto getPermitLine(@PathVariable("permitVersionId") int permitVersionId,
			@PathVariable("permitLineId") int permitLineId) {
		return permitLineService.getPermitLineVersion(permitVersionId, permitLineId);
	}

	@PostMapping("/{permitVersionId}/lines")
	public void addPermitLine(@PathVariable("permitVersionId") int permitVersionId,
			@Valid @RequestBody PermitLineParams params) {
		permitLineService.addPermitLine(permitVersionId, params);
	}

	@PutMapping("/{permitVersionId}/lines/{permitLineId}")
	public int editPermitLine(@PathVariable("permitVersionId") int permitVersionId,
			@PathVariable("permitLineId") int permitLineId, @Valid @RequestBody PermitLineParams params) {
		return permitLineService.editPermitLineVersion(permitVersionId, permitLineId, params);
	}

	@DeleteMapping("/{permitVersionId}/lines/{permitLineId}")
	public void deletePermitLine(@PathVariable("permitVersionId") int permitVersionId,
			@PathVariable("permitLineId") int permitLineId) {
		permitLineService.deletePermitLineVersion(permitVersionId, permitLineId);
	}




	@GetMapping("/lines-count")
	public List<Integer> getMaxNumberOfLinesForAllPermits() {
		return permitLineService.getMaxNumberOfLinesForAllPermits();
	}

	// Permit Line Documents

	@GetMapping("/{permitVersionId}/lines/{permitLineId}/documents/{permitLineDocumentId}")
	public PermitLineDocumentDetailsDto getPermitLineDocument(@PathVariable("permitVersionId") int permitVersionId,
			@PathVariable("permitLineId") int permitLineId,
			@PathVariable("permitLineDocumentId") int permitLineDocumentId) {

		return permitLineDocumentService.getPermitLineDocument(permitVersionId, permitLineId, permitLineDocumentId);
	}

	@PostMapping("/{permitVersionId}/lines/{permitLineId}/documents")
	public int addPermitLineDocument(@PathVariable("permitVersionId") int permitVersionId,
			@PathVariable("permitLineId") int permitLineId, @Valid @RequestBody PermitLineDocumentDto dto) {

		return permitLineDocumentService.addDocumentToPermitLine(permitVersionId, permitLineId, dto);
	}

	@PutMapping("/{permitVersionId}/lines/{permitLineId}/documents/{permitLineDocumentId}/new")
	public void editNewPermitLineDocument(@PathVariable("permitVersionId") int permitVersionId,
			@PathVariable("permitLineId") int permitLineId,
			@PathVariable("permitLineDocumentId") int permitLineDocumentId,
			@Valid @RequestBody PermitLineDocumentDto dto) {

		permitLineDocumentService.editNewPermitLineDocument(permitVersionId, permitLineId, permitLineDocumentId, dto);
	}

	@PutMapping("/{permitVersionId}/lines/{permitLineId}/documents/{permitLineDocumentId}/approved")
	public int editApprovedPermitLineDocument(@PathVariable("permitVersionId") int permitVersionId,
			@PathVariable("permitLineId") int permitLineId,
			@PathVariable("permitLineDocumentId") int permitLineDocumentId, 
				@RequestParam 
				@NotBlank
				@Pattern(regexp = "^(" 
					+ DocumentStatus.VALID_CODE + "|" 
					+ DocumentStatus.EXPIRED_CODE + "|" 
					+ DocumentStatus.INVALID_CODE + ")$")  
				String statusCode) {

		return permitLineDocumentService.editApprovedPermitLineDocument(permitVersionId, permitLineId,
				permitLineDocumentId, statusCode);
	}

	@DeleteMapping("/{permitVersionId}/lines/{permitLineId}/documents/{permitLineDocumentId}")
	public void deletePermitLineDocument(@PathVariable("permitVersionId") int permitVersionId,
			@PathVariable("permitLineId") int permitLineId,
			@PathVariable("permitLineDocumentId") int permitLineDocumentId) {

		permitLineDocumentService.deleteNewPermitLineDocument(permitVersionId, permitLineId, permitLineDocumentId);
	}

	@GetMapping("/{permitVersionId}/lines/{permitLineId}/documents")
	public PageResult<PermitLineDetailsDocumentVersionDto> getPermitLineDocuments(
			@PathVariable("permitVersionId") int permitVersionId, @PathVariable("permitLineId") int permitLineId,
			@RequestParam("page") int page, @RequestParam("pageSize") int pageSize) {
		return permitLineDocumentService.getPermitLineDocumentsPage(permitVersionId, permitLineId, page, pageSize);
	}

	@GetMapping(value = "/{permitVersionId}/lines/{permitLineId}/documents/{permitLineDocumentId}/pdf")
	public ResponseEntity<byte[]> getPermitLineDocumentPdf(@PathVariable("permitVersionId") int permitVersionId,
			@PathVariable("permitLineId") int permitLineId,
			@PathVariable("permitLineDocumentId") int permitLineDocumentId) {
		byte[] result = permitLineDocumentService.getPermitLineDocumentPdf(permitVersionId, permitLineId,
				permitLineDocumentId);
		String contentType = getMimeType(result);
		HttpHeaders headers = new HttpHeaders();
		if (contentType != null) {
			headers.add(HttpHeaders.CONTENT_TYPE, contentType);
		}
		ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(result, headers, HttpStatus.OK);
		return response;
	}

	// Inspector Stamps

	@PostMapping("/{id}/inspectors/{inspectorId}/stamps")
	@ResponseStatus(code = HttpStatus.CREATED)
	public void addStampToPermitInspector(@PathVariable("id") int permitVersionId,
			@PathVariable("inspectorId") int inspectorVersionId,
			@Valid @RequestBody PermitInspectorStampCreationParams params) {
		permitInspectorService.addStampToPermitInspector(permitVersionId, inspectorVersionId, params);
	}

	@PutMapping("/{id}/inspectors/{inspectorId}/stamps/{stampId}")
	public int editStampForPermitInspector(@PathVariable("id") int permitVersionId,
			@PathVariable("inspectorId") int inspectorVersionId, @PathVariable("stampId") int stampId,
			@Valid @RequestBody PermitInspectorStampEditParams params) {
		return permitInspectorService.editStampForPermitInspector(permitVersionId, inspectorVersionId, stampId, params);
	}

	@GetMapping("/{id}/inspectors/{inspectorId}/stamps/{stampId}")
	public PermitInspectorStampDto getStampForPermitInspector(@PathVariable("id") int permitVersionId,
			@PathVariable("inspectorId") int inspectorVersionId, @PathVariable("stampId") int stampId) {
		return permitInspectorService.getStampForPermitInspector(permitVersionId, inspectorVersionId, stampId);
	}

	@GetMapping("/{id}/inspectors/{inspectorId}/stamps/{stampId}/history")
	public List<PermitInspectorStampVersionDto> getStampHistoryForStampId(@PathVariable("id") int permitVersionId,
			@PathVariable("inspectorId") int inspectorVersionId, @PathVariable("stampId") int stampId) {
		return permitInspectorService.getStampHistoryForPermitInspectorStampId(permitVersionId, inspectorVersionId, stampId);
	}


	@GetMapping("/{id}/inspectors/{inspectorId}/stamps/{stampId}/image")
	public ResponseEntity<byte[]> getStampProtocolForPermitInspector(@PathVariable("id") int permitVersionId,
			@PathVariable("inspectorId") int inspectorVersionId, @PathVariable("stampId") int stampId) {
		byte[] result = permitInspectorService.getStampWithProtocolForPermitInspector(permitVersionId, inspectorVersionId, stampId);
		
		String contentType = result != null ? new Tika().detect(result) : null;
		HttpHeaders headers = new HttpHeaders();
		
		if (contentType != null) {
			headers.add(HttpHeaders.CONTENT_TYPE, contentType);
		}

		ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(result, headers, HttpStatus.OK);
		return response;
	}

	// Inspector Documents

	@PostMapping("/{id}/inspectors/{inspectorId}/documents")
	@ResponseStatus(code = HttpStatus.CREATED)
	public int addDocumentToPermitInspector(@PathVariable("id") int permitVersionId,
			@PathVariable("inspectorId") int inspectorVersionId,
			@Valid @RequestBody PermitInspectorDocumentParams params) {
		return subjectVersionDocumentService.addSubjectVersionDocument(permitVersionId, inspectorVersionId, params);
	}

	@PutMapping("/{id}/inspectors/{inspectorId}/documents/{documentId}/new")
	public void editNewDocumentToPermitInspector(@PathVariable("id") int permitVersionId,
			@PathVariable("inspectorId") int inspectorVersionId, @PathVariable("documentId") int documentId,
			@Valid @RequestBody PermitInspectorDocumentParams params) {
		subjectVersionDocumentService.editNewSubjectVersionDocument(permitVersionId, inspectorVersionId, documentId,
				params);
	}

	@PutMapping("/{id}/inspectors/{inspectorId}/documents/{documentId}/approved")
	public int editApprovedDocumentToPermitInspector(@PathVariable("id") int permitVersionId,
			@PathVariable("inspectorId") int inspectorVersionId, @PathVariable("documentId") int documentId,
			@RequestParam
			@NotBlank
			@Pattern(regexp = "^(" 
			+ DocumentStatus.VALID_CODE + "|" 
			+ DocumentStatus.EXPIRED_CODE + "|" 
			+ DocumentStatus.INVALID_CODE + ")$")  
			String statusCode) {
		return subjectVersionDocumentService.editApprovedSubjectVersionDocument(permitVersionId, inspectorVersionId,
				documentId, statusCode);
	}

	@DeleteMapping("/{id}/inspectors/{inspectorId}/documents/{documentId}")
	public void deleteNewSubjectDocumentVersion(@PathVariable("id") int permitVersionId,
			@PathVariable("inspectorId") int inspectorVersionId, @PathVariable("documentId") int documentId) {
		subjectVersionDocumentService.deleteNewSubjectVersionDocument(permitVersionId, inspectorVersionId, documentId);
	}

	@GetMapping("/{id}/inspectors/{inspectorId}/documents")
	public PageResult<PermitInspectorDocumentLightDto> getInspectorDocumentsPageByInspectorVersionId(
			@PathVariable("id") int inspectorId, @RequestParam(value = "page") int page) {
		return subjectVersionDocumentService.getPermitInspectorDocumentsPageByInspectorId(inspectorId, page);
	}

	// Subject Cards

	@GetMapping(value = "/{id}/subjects/{subjectId}/cards/{cardId}")
	public SubjectCardDto getCardFromPermitInspector(@PathVariable("id") int permitVersionId,
			@PathVariable("subjectId") int subjectId, @PathVariable("cardId") int cardId) {
		return subjectCardService.getCard(permitVersionId, subjectId, cardId);
	}

	@PostMapping("/{id}/subjects/{subjectId}/cards")
	@ResponseStatus(code = HttpStatus.CREATED)
	public void addCardToPermitInspector(@PathVariable("id") int permitVersionId,
			@PathVariable("subjectId") int subjectId, @Valid @RequestBody PermitInspectorCardCreationParams params) {
		subjectCardService.addCard(permitVersionId, subjectId, params);
	}

	@PutMapping("/{id}/subjects/{subjectId}/cards/{cardId}")
	public void editCardToPermitInspector(@PathVariable("id") int permitVersionId,
			@PathVariable("subjectId") int subjectId, @PathVariable("cardId") int cardId,
			@Valid @RequestBody PermitInspectorCardEditParams params) {
		subjectCardService.editCard(permitVersionId, subjectId, cardId, params);
	}

	// Permit Line hardware

	@GetMapping("/{id}/lines/{lineId}/hardware")
	public PageResult<HardwareBySerialNumberDto> getPermitLineHardware(@PathVariable("id") int permitVersionId,
			@PathVariable("lineId") int permitLineVersionId, @Valid PaginationQueryParams paginationParams) {
		return permitLineService.getPermitLineHardwarePageByPermitVersionId(permitVersionId, permitLineVersionId,
				paginationParams);
	}

	@PutMapping("/{id}/lines/{lineId}/hardware")
	public void addExistingHardwareToPermitLine(@PathVariable("id") int permitVersionId,
			@PathVariable("lineId") int permitLineVersionId,
			@Valid @RequestBody @NotEmpty List<HardwareDeviceIdentifierDto> params) {
		permitLineService.addHardwareToPermitLine(permitVersionId, permitLineVersionId, params);
	}

	@PatchMapping("/{id}/lines/{lineId}/hardware/{hardwareId}")
	public void removeHardware(@PathVariable("id") int permitVersionId, @PathVariable("lineId") int lineVersionId,
			@PathVariable("hardwareId") int hardwareId, @RequestBody PermitLineRemoveHardwareParams params) {
		permitLineService.removeHardware(permitVersionId, lineVersionId, hardwareId, params);
	}

	// Private

	private String getMimeType(byte[] bytes) {
		return bytes != null ? new Tika().detect(bytes) : null;
	}
}
