package bg.demax.inspections.backend.controller.permit;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.hibernate.paging.PageRequest;
import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.PaginationQueryParams;
import bg.demax.inspections.backend.controller.param.permit.problem.PermitProblemQueryParams;
import bg.demax.inspections.backend.controller.param.permit.problem.PermitProblemUpdateDescriptionParams;
import bg.demax.inspections.backend.controller.param.permit.problem.PermitProblemUpdateParams;
import bg.demax.inspections.backend.dto.techinsp.permit.problem.PermitProblemCreationRequestDto;
import bg.demax.inspections.backend.dto.techinsp.permit.problem.PermitProblemEditDto;
import bg.demax.inspections.backend.dto.techinsp.permit.problem.PermitProblemListItemDto;
import bg.demax.inspections.backend.entity.permit.problem.PermitProblemStatus.PermitProblemStatuses;
import bg.demax.inspections.backend.search.PermitProblemSearch;
import bg.demax.inspections.backend.service.permit.PermitProblemService;

@RestController
@RequestMapping("/api/permit-problems")
public class PermitProblemController {

	@Autowired
	private PermitProblemService permitProblemService;

	@GetMapping
	public PageResult<PermitProblemListItemDto> getPagedPermitProblemsBySearch(@Valid PermitProblemQueryParams params,
			@Valid PaginationQueryParams paginationParams) {

		PermitProblemSearch search = new PermitProblemSearch();
		BeanUtils.copyProperties(params, search);

		PageRequest pageRequest = new PageRequest();
		BeanUtils.copyProperties(paginationParams, pageRequest);

		PageResult<PermitProblemListItemDto> pageResult = permitProblemService.getPermitProblemPageBySearch(search,
				pageRequest);
		return pageResult;
	}

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public void addNewProblem(@Valid @RequestBody PermitProblemCreationRequestDto dto) {
		permitProblemService.addNewProblem(dto);
	}

	@GetMapping("/count")
	public int getProblemsCount(@Valid PermitProblemQueryParams params) {
		PermitProblemSearch search = new PermitProblemSearch();
		BeanUtils.copyProperties(params, search);
		search.setStatus(PermitProblemStatuses.WAITING.getId());
		int count = permitProblemService.getProblemsCount(search);
		return count;
	}

	@PutMapping("/{id}")
	public void updatePermitProblem(@Valid @RequestBody PermitProblemUpdateParams params,
			@PathVariable("id") Integer id) {
		permitProblemService.updatePermitProblem(id, params);
	}

	@PatchMapping("/{id}")
	public void updatePermitDescriptions(@Valid @RequestBody PermitProblemUpdateDescriptionParams params,
			@PathVariable("id") Integer id) {
		permitProblemService.updatePermitProblemDescription(id, params);
	}

	@GetMapping("/{id}")
	public PermitProblemEditDto getPermitProblemById(@PathVariable("id") Integer id) {
		return permitProblemService.getProblemDetailsById(id);
	}

}
