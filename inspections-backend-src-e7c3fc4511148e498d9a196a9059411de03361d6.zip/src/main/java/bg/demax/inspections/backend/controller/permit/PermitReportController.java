package bg.demax.inspections.backend.controller.permit;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;

import bg.demax.hibernate.paging.PageRequest;
import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.InspectionApplication;
import bg.demax.inspections.backend.controller.param.LogsReportSearchParams;
import bg.demax.inspections.backend.controller.param.PaginationQueryParams;
import bg.demax.inspections.backend.controller.param.StickersReportSearchParams;
import bg.demax.inspections.backend.controller.param.SubjectCardsReportSearchParams;
import bg.demax.inspections.backend.controller.param.permit.InspectionOrdersReportSearchParams;
import bg.demax.inspections.backend.controller.param.permit.PermitDocumentsReportSearchParams;
import bg.demax.inspections.backend.controller.param.permit.PermitInspectorReportSearchParams;
import bg.demax.inspections.backend.controller.param.permit.PermitReportSearchParams;
import bg.demax.inspections.backend.controller.param.permit.inspector.PermitInspectorDocumentsReportSearchParams;
import bg.demax.inspections.backend.controller.param.permit.line.PermitLineDocumentsReportSearchParams;
import bg.demax.inspections.backend.controller.param.permit.line.PermitLineReportSearchParams;
import bg.demax.inspections.backend.dto.CategoryLPermitHtmlReportDto;
import bg.demax.inspections.backend.dto.CategoryVPermitHtmlReportDto;
import bg.demax.inspections.backend.dto.GasPermitHtmlReportDto;
import bg.demax.inspections.backend.dto.LogsReportListItemDto;
import bg.demax.inspections.backend.dto.SemtCertificateHtmlReportDto;
import bg.demax.inspections.backend.dto.SemtPermitHtmlReportDto;
import bg.demax.inspections.backend.dto.StickersReportListItemDto;
import bg.demax.inspections.backend.dto.SubjectCardsReportListItemDto;
import bg.demax.inspections.backend.dto.orders.InspectionOrderReportListItemDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDocumentListItemDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDocumentReportListItemDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitHtmlReportDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitReportListItemDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorDocumentsReportListItemDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorReportListItemDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineDocumentReportListItemDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineReportListItemDto;
import bg.demax.inspections.backend.enums.ReportTypeCode;
import bg.demax.inspections.backend.exception.UnableToGenerateJasperReportException;
import bg.demax.inspections.backend.export.permit.PermitInquiryReportRow;
import bg.demax.inspections.backend.export.permit.PermitInspectorDocumentsReportRow;
import bg.demax.inspections.backend.export.permit.PermitLineDocumentsReportRow;
import bg.demax.inspections.backend.export.permit.PermitLinesReportRow;
import bg.demax.inspections.backend.export.report.SubjectCardsReportRow;
import bg.demax.inspections.backend.export.report.order.InspectionOrderReportRow;
import bg.demax.inspections.backend.search.PermitInspectorDocumentsReportSearch;
import bg.demax.inspections.backend.service.PermitsLinesInspectorsLogService;
import bg.demax.inspections.backend.service.ReportLogService;
import bg.demax.inspections.backend.service.orders.InspectionOrderService;
import bg.demax.inspections.backend.service.permit.PermitDocumentService;
import bg.demax.inspections.backend.service.permit.PermitService;
import bg.demax.inspections.backend.service.permit.inspector.PermitInspectorService;
import bg.demax.inspections.backend.service.permit.inspector.SubjectCardService;
import bg.demax.inspections.backend.service.permit.inspector.SubjectVersionDocumentService;
import bg.demax.inspections.backend.service.permit.line.PermitLineDocumentService;
import bg.demax.inspections.backend.service.permit.line.PermitLineService;
import bg.demax.inspections.backend.service.techinsp.InspectionService;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxExporterConfiguration;

@RestController
@RequestMapping("/api/reports")
public class PermitReportController {
	
	@Autowired
	private PermitService permitService;
	
	@Autowired
	private PermitDocumentService permitDocumentService;
	
	@Autowired
	private SubjectVersionDocumentService subjectDocumentService;
	
	@Autowired
	private PermitLineService permitLineService;

	@Autowired
	private PermitLineDocumentService permitLineDocumentService;
	
	@Autowired
	private InspectionOrderService inspectionOrderService;
	
	@Autowired
	private SubjectCardService subjectCardService;

	@Autowired
	private PermitInspectorService permitInspectorService;
	
	@Autowired
	private InspectionService inspectionService;
	
	@Autowired
	private PermitsLinesInspectorsLogService logService;
	
	@Autowired
	private ReportLogService reportLogService;

	@Value("${inspections.backend.permitInquiryReportPath}")
	private String permitInquiryReportPath;
	
	@Value("${inspections.backend.permitDocumentsInquiryReportPath}")
	private String permitDocumentsInquiryReportPath;
	
	@Value("${inspections.backend.permitLineDocumentsInquiryReportPath}")
	private String permitLineDocumentsInquiryReportPath;
	
	@Value("${inspections.backend.subjectCardsInquiryReportPath}")
	private String subjectCardsInquiryReportPath;

	@Value("${inspections.backend.permitInspectorsInquiryReportPath}")
	private String permitInspectorsInquiryReportPath;
	
	@Value("${inspections.backend.permitInspectorsDocumentsInquiryReportPath}")
	private String permitInspectorsDocumentsInquiryReportPath;
	
	// Permit Reports
	@Value("${inspections.backend.inspectionOrderInquiryReportPath}")
	private String inspectionOrderInquiryReportPath;
	
	@Value("${inspections.backend.permitLinesInquiryReportPath}")
	private String permitLinesInquiryReportPath;

	@Value("${inspections.backend.stickersInquiryReportPath}")
	private String stickersInquiryReportPath;

	@Value("${inspections.backend.logsInquiryReportPath}")
	private String logsInquiryReportPath;

	// Permit Reports

	@GetMapping("/permits")
	public PageResult<PermitReportListItemDto> getPermitReportListPage(@Valid PermitReportSearchParams params,
					@Valid PaginationQueryParams paginationParams) throws JsonProcessingException {

		PageResult<PermitReportListItemDto> pageResult = permitService.getPermitReportListPage(params, paginationParams);
		reportLogService.logReport(ReportTypeCode.PERMITS_REPORT, params);
		
		return pageResult;
	}

	@GetMapping(value = "/permits/xlsx", produces = "application/vnd.ms-excel")
	public ResponseEntity<byte[]> getPermitReportListXlsx(@Valid PermitReportSearchParams params) throws JsonProcessingException {

		List<PermitInquiryReportRow> rows = permitService.getPermitInquiryReportRows(params);
		ResponseEntity<byte[]> response = exportJrxlsx(permitInquiryReportPath, rows, null, 
				String.format("attachment; filename=\"%s.xlsx\"", "permits_report"));
		
		reportLogService.logReport(ReportTypeCode.PERMITS_REPORT, params);
		
		return response;
	}
	
	@GetMapping("/permits/html/valid")
	public List<PermitHtmlReportDto> getPermitHtmlReport() throws JsonProcessingException {

		List<PermitHtmlReportDto> list = permitService.getPermitHtmlReportDtos();
		reportLogService.logReport(ReportTypeCode.HTML_VALID_PERMITS_REPORT);
		
		return list;
	}
	
	@GetMapping("/permits/html/gas")
	public List<GasPermitHtmlReportDto> getGasPermitHtmlReport() throws JsonProcessingException {

		List<GasPermitHtmlReportDto> list = permitService.getGasPermitHtmlReportDtos();
		reportLogService.logReport(ReportTypeCode.HTML_GAS_PERMITS_REPORT);
		
		return list;
	}
	
	@GetMapping("/permits/html/category-v")
	public List<CategoryVPermitHtmlReportDto> getCategoryVPermitHtmlReport() throws JsonProcessingException {

		List<CategoryVPermitHtmlReportDto> list = permitService.getCategoryVPermitHtmlReportDtos();
		reportLogService.logReport(ReportTypeCode.HTML_CATEGORY_V_PERMITS_REPORT);
		
		return list;
	}
	
	@GetMapping("/permits/html/category-l")
	public List<CategoryLPermitHtmlReportDto> getCategoryLPermitHtmlReport() throws JsonProcessingException {

		List<CategoryLPermitHtmlReportDto> list = permitService.getCategoryLPermitHtmlReportDtos();
		reportLogService.logReport(ReportTypeCode.HTML_CATEGORY_L_PERMITS_REPORT);
		
		return list;
	}
	
	@GetMapping("/permits/html/semt")
	public List<SemtPermitHtmlReportDto> getSemtPermitHtmlReport() throws JsonProcessingException {

		List<SemtPermitHtmlReportDto> list = permitService.getSemtPermitHtmlReportDtos();
		reportLogService.logReport(ReportTypeCode.HTML_SEMT_PERMITS_REPORT);
		
		return list;
	}
	
	@GetMapping("/html/semt-certificates")
	public List<SemtCertificateHtmlReportDto> getSemtCertificateHtmlReport() throws JsonProcessingException {

		List<SemtCertificateHtmlReportDto> list = inspectionService.getSemtCertificateHtmlReportDtos();
		reportLogService.logReport(ReportTypeCode.HTML_SEMT_CERTIFICATES_REPORT);
		
		return list;
	}

	// Permit Documents

	@GetMapping("/permits/documents")
	public PageResult<PermitDocumentListItemDto> getPermitDocumentsReportListPage(@Valid PermitDocumentsReportSearchParams params,
					@Valid PaginationQueryParams paginationParams) throws JsonProcessingException {

		PageResult<PermitDocumentListItemDto> pageResult = permitDocumentService.getPermitDocumentsReportListPage(params, paginationParams);
		reportLogService.logReport(ReportTypeCode.PERMIT_DOCUMENTS_REPORT, params);
		
		return pageResult;
	}

	@GetMapping(value = "/permits/documents/xlsx", produces = "application/vnd.ms-excel")
	public ResponseEntity<byte[]> getPermitDocumentsReportListXlsx(@Valid PermitDocumentsReportSearchParams params) 
			throws JsonProcessingException {

		List<PermitDocumentReportListItemDto> rows = permitDocumentService.getPermitDocumentReportRows(params);
		String headerValue = String.format("attachment; filename=\"%s.xlsx\"", "permits_documents_report");

		ResponseEntity<byte[]> response = exportJrxlsx(permitDocumentsInquiryReportPath, rows, null, headerValue);
		reportLogService.logReport(ReportTypeCode.PERMIT_DOCUMENTS_REPORT, params);
		
		return response;
	}

	// Permit Lines

	@GetMapping("/permits/lines")
	public PageResult<PermitLineReportListItemDto> getPermitLinesReportList(@Valid PermitLineReportSearchParams params,
					@Valid PaginationQueryParams paginationParams) throws JsonProcessingException {
		PageResult<PermitLineReportListItemDto> pageResult = permitLineService.getPermitLinesReportListPage(params, paginationParams);
		reportLogService.logReport(ReportTypeCode.PERMIT_LINES_REPORT, params);
		
		return pageResult;
	}

	@GetMapping(value = "/permits/lines/xlsx", produces = "application/vnd.ms-excel")
	public ResponseEntity<byte[]> getPermitLinesReportListXlsx(@Valid PermitLineReportSearchParams params) throws JsonProcessingException {
		List<PermitLinesReportRow> rows = permitLineService.getReportRows(params);

		ResponseEntity<byte[]> response = exportJrxlsx(permitLinesInquiryReportPath, rows, null,
						String.format("attachment; filename=\"%s.xlsx\"", "permit_lines_report"));
		reportLogService.logReport(ReportTypeCode.PERMIT_LINES_REPORT, params);
		
		return response;
	}

	// Permit Line Documents

	@GetMapping("/permits/lines/documents")
	public PageResult<PermitLineDocumentReportListItemDto> getPermitLinesDocumentsReportList(
					@Valid PermitLineDocumentsReportSearchParams params, @Valid PaginationQueryParams paginationParams) 
							throws JsonProcessingException {

		PageResult<PermitLineDocumentReportListItemDto> pageResult = 
				permitLineDocumentService.getPermitLineDocumentsReportListPage(params, paginationParams);
		reportLogService.logReport(ReportTypeCode.PERMIT_LINE_DOCUMENTS_REPORT, params);
		
		return pageResult;
	}

	@GetMapping(value = "/permits/lines/documents/xlsx", produces = "application/vnd.ms-excel")
	public ResponseEntity<byte[]> getPermitLinesDocumentsReportListXslx(@Valid PermitDocumentsReportSearchParams params) 
			throws JsonProcessingException {

		List<PermitLineDocumentsReportRow> rows = permitLineDocumentService.getPermitLineDocumentsReportListPage(params);
		String headerValue = String.format("attachment; filename=\"%s.xlsx\"", "permits_lines_documents_report");

		ResponseEntity<byte[]> response = exportJrxlsx(permitLineDocumentsInquiryReportPath, rows, null, headerValue);
		reportLogService.logReport(ReportTypeCode.PERMIT_LINE_DOCUMENTS_REPORT, params);
		
		return response;
	}

	// Permit Inspectors

	@GetMapping("/permits/inspectors")
	public PageResult<PermitInspectorReportListItemDto> getPermitInspectorsReportList(@Valid PermitInspectorReportSearchParams params,
					@Valid PaginationQueryParams paginationParams) throws JsonProcessingException {

		PageResult<PermitInspectorReportListItemDto> pageResult = 
				permitInspectorService.getPermitInspectorReportListBySearch(params, paginationParams);
		reportLogService.logReport(ReportTypeCode.PERMIT_INSPECTORS_REPORT, params);
		
		return pageResult;
	}

	@GetMapping(value = "/permits/inspectors/xlsx", produces = "application/vnd.ms-excel")
	public ResponseEntity<byte[]> getPermitInspectorsRerportListXslx(@Valid PermitInspectorReportSearchParams params) 
			throws JsonProcessingException {

		List<PermitInspectorReportListItemDto> rows = permitInspectorService.getPermitInspectorReportListBySearch(params);
		String headerValue = String.format("attachment; filename=\"%s.xlsx\"", "permits_inspectors_report");

		ResponseEntity<byte[]> response = exportJrxlsx(permitInspectorsInquiryReportPath, rows, null, headerValue);
		reportLogService.logReport(ReportTypeCode.PERMIT_INSPECTORS_REPORT, params);
		
		return response;
	}

	// Permit Inspector Documents Reports

	@GetMapping("/permits/inspectors/documents")
	public PageResult<PermitInspectorDocumentsReportListItemDto> getPermitInspectorDocumentsReportListPage(
					@Valid PermitInspectorDocumentsReportSearchParams params, @Valid PaginationQueryParams paginationParams) 
							throws JsonProcessingException {
		PermitInspectorDocumentsReportSearch search = new PermitInspectorDocumentsReportSearch();
		BeanUtils.copyProperties(params, search);

		PageResult<PermitInspectorDocumentsReportListItemDto> pageResult = subjectDocumentService
				.getPermitInspectorDocumentsReportListPage(search, paginationParams.getPage(), paginationParams.getPageSize());
		reportLogService.logReport(ReportTypeCode.PERMIT_INSPECTOR_DOCUMENTS_REPORT, params);
		
		return pageResult;
	}
	
	@GetMapping(value = "/permits/inspectors/documents/xlsx", produces = "application/vnd.ms-excel")
	public ResponseEntity<byte[]> getPermitInspectorDocumentsRerportListXlsx(@Valid PermitInspectorDocumentsReportSearchParams params) 
			throws JsonProcessingException {
		PermitInspectorDocumentsReportSearch search = new PermitInspectorDocumentsReportSearch();
		BeanUtils.copyProperties(params, search);

		List<PermitInspectorDocumentsReportRow> rows = subjectDocumentService.getPermitInspectorDocumentsReportRows(search);
		
		Map<String, Object> parameters =  new HashMap<>();
		parameters.put("permitInspectorDocumentsDataSource", new JRBeanCollectionDataSource(rows));

		ResponseEntity<byte[]> response = exportJrxlsx(permitInspectorsDocumentsInquiryReportPath, rows,  parameters,
			String.format("attachment; filename=\"%s.xlsx\"", "permit_inspector_documents_report"));
		reportLogService.logReport(ReportTypeCode.PERMIT_INSPECTOR_DOCUMENTS_REPORT, params);
		
		return response;
	}

	// Inspection Orders

	@GetMapping("/permits/orders")
	public PageResult<InspectionOrderReportListItemDto> getInspectionOrdersReportListPage(@Valid InspectionOrdersReportSearchParams params,
					@Valid PaginationQueryParams paginationParams) {

		PageRequest pageRequest = new PageRequest();
		BeanUtils.copyProperties(paginationParams, pageRequest);

		return inspectionOrderService.getInspectionOrdersReportListPage(params, pageRequest);
	}
	
	@GetMapping(value = "/permits/orders/xlsx", produces = "application/vnd.ms-excel")
	public ResponseEntity<byte[]> getInspectionOrdersReportListXlsx(@Valid InspectionOrdersReportSearchParams params) {
		List<InspectionOrderReportRow> rows = inspectionOrderService.getReportRows(params);

		return exportJrxlsx(inspectionOrderInquiryReportPath, rows, null,
						String.format("attachment; filename=\"%s.xlsx\"", "orders_report"));
	}

	// Subject Cards

	@GetMapping("/subjects/cards")
	public PageResult<SubjectCardsReportListItemDto> getSubjectCardsReportList(@Valid SubjectCardsReportSearchParams params,
					@Valid PaginationQueryParams paginationParams) {

		return subjectCardService.getReportListPage(params, paginationParams);
	}

	@GetMapping(value = "/subjects/cards/xlsx", produces = "application/vnd.ms-excel")
	public ResponseEntity<byte[]> getSubjectCardsReportListXlsx(@Valid SubjectCardsReportSearchParams params) {
		List<SubjectCardsReportRow> rows = subjectCardService.getReportRows(params);

		return exportJrxlsx(subjectCardsInquiryReportPath, rows, null, String.format("attachment; filename=\"%s.xlsx\"", "cards_report"));
	}

	// Stickers

	@GetMapping("/permits/orders/stickers")
	public PageResult<StickersReportListItemDto> getStickersReportList(@Valid StickersReportSearchParams params,
					@Valid PaginationQueryParams paginationParams) {

		return inspectionOrderService.getStickersReportListPage(params, paginationParams);
	}

	@GetMapping(value = "/permits/orders/stickers/xlsx", produces = "application/vnd.ms-excel")
	public ResponseEntity<byte[]> getStickersReportListXlsx(@Valid StickersReportSearchParams params) {
		List<StickersReportListItemDto> rows = inspectionOrderService.getStickersReportRows(params);

		return exportJrxlsx(stickersInquiryReportPath, rows, null, String.format("attachment; filename=\"%s.xlsx\"", "stickers_report"));
	}

	// Logs

	@GetMapping("/logs")
	public PageResult<LogsReportListItemDto> getLogsReportList(@Valid LogsReportSearchParams params,
					@Valid PaginationQueryParams paginationParams) throws JsonProcessingException {
		PageRequest pageRequest = new PageRequest();
		BeanUtils.copyProperties(paginationParams, pageRequest);
		
		PageResult<LogsReportListItemDto> pageResult = logService.getLogsReportListPage(params, pageRequest);
		reportLogService.logReport(ReportTypeCode.LOGS_REPORT, params);
		
		return pageResult;
	}

	@GetMapping(value = "/logs/xlsx", produces = "application/vnd.ms-excel")
	public ResponseEntity<byte[]> getLogsReportListXlsx(@Valid LogsReportSearchParams params) throws JsonProcessingException {
		List<LogsReportListItemDto> rows = logService.getLogsReportRows(params);

		ResponseEntity<byte[]> response = exportJrxlsx(logsInquiryReportPath, rows, null, 
				String.format("attachment; filename=\"%s.xlsx\"", "logs_report"));
		reportLogService.logReport(ReportTypeCode.LOGS_REPORT, params);
		
		return response;
	}

	// Private
	
	private <T> ResponseEntity<byte[]> exportJrxlsx(String jrxmlPath, List<T> rows, Map<String, Object> parameters, String headerValue) {
		ByteArrayOutputStream outputStream = null;
		try {
			JasperPrint print = new JasperPrint();
			InputStream inputStream = InspectionApplication.class.getResourceAsStream(jrxmlPath);
			try {
				JasperReport report = JasperCompileManager
								.compileReport(inputStream);
				if (parameters != null) {
					print = JasperFillManager.fillReport(report, parameters, new JREmptyDataSource());			
				} else if (parameters == null && rows != null) {
					print = JasperFillManager.fillReport(report, null, new JRBeanCollectionDataSource(rows));
				}
				outputStream = new ByteArrayOutputStream();

				JRXlsxExporter exporter = new JRXlsxExporter();

				exporter.setExporterInput(new SimpleExporterInput(print));
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(outputStream));
				SimpleXlsxExporterConfiguration configuration = new SimpleXlsxExporterConfiguration();
				exporter.setConfiguration(configuration);

				exporter.exportReport();
				byte[] bytes = outputStream.toByteArray();
				HttpHeaders headers = new HttpHeaders();
				headers.add(HttpHeaders.CONTENT_DISPOSITION, headerValue);
				ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(bytes, headers, HttpStatus.OK);
				return response;
			} catch (JRException e) {
				throw new UnableToGenerateJasperReportException(e.getMessage() + "unable to generate jasper report");
			}
		} finally {
			if (outputStream != null) {
				try {
					outputStream.close();
				} catch (IOException e) {
					throw new UnableToGenerateJasperReportException("Unable to close byte array outputstream");
				}
			}
		}
	}
}
