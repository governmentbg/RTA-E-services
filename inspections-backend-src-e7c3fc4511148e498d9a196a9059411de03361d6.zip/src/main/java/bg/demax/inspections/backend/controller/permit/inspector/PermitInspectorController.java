package bg.demax.inspections.backend.controller.permit.inspector;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import javax.validation.Valid;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.tika.Tika;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.PaginationQueryParams;
import bg.demax.inspections.backend.controller.param.permit.inspector.PermitInspectorQueryParams;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorDocumentDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorDocumentLightDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorLightDto;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectWithPersonalInfoDto;
import bg.demax.inspections.backend.search.PermitInspectorSearch;
import bg.demax.inspections.backend.service.permit.inspector.PermitInspectorService;
import bg.demax.inspections.backend.service.permit.inspector.SubjectVersionDocumentService;
import bg.demax.inspections.backend.validation.IdentityNumber;
import bg.demax.specialist.registry.common.dto.certification.InspectorCertificationLightDto;
import bg.demax.specialist.registry.common.dto.certification.InspectorCertificationPreviewLightDto;

@RestController
@RequestMapping("/api/permit-inspectors")
@Validated
public class PermitInspectorController {

	@Autowired
	private PermitInspectorService permitInspectorService;
	
	@Autowired
	private SubjectVersionDocumentService subjectVersionDocumentService;

	@GetMapping
	public List<PermitInspectorLightDto> getPermitInspectorByParams(@Valid PermitInspectorQueryParams params)
					throws IllegalAccessException, InvocationTargetException {
		PermitInspectorSearch search = new PermitInspectorSearch();
		BeanUtils.copyProperties(search, params);

		return permitInspectorService.getPermitInspectorsBySearch(search);
	}
	
	@GetMapping("/specialities")
	public List<String> getPermitInspectorSpecialities() {
		return permitInspectorService.getInspectorSpecialities();
	}

	@GetMapping("/search/with-education")
	public SubjectWithPersonalInfoDto getPermitInspectorWithEducation(@RequestParam @IdentityNumber String identityNumber) {
		return permitInspectorService.getSubjectWithPersonalInfoDto(identityNumber);
	}
	
	@GetMapping("/subjects/{id}/certificates")
	public List<InspectorCertificationLightDto> getSubjectVersionCertificationsFromSpecialistRegistry(
					@PathVariable("id") long subjectId) {
		return permitInspectorService.getPermitInspectorCertificationsBySubjectId(subjectId);
	}
	
	@GetMapping("/subjects/{id}/certificates/paged")
	public PageResult<InspectorCertificationLightDto> getSubjectVersionCertificationsFromSpecialistRegistry(
					@PathVariable("id") long subjectId, @Valid PaginationQueryParams paginationParams) {
		return permitInspectorService.getPermitInspectorCertificationsBySubjectIdPaged(subjectId, paginationParams);
	}
	
	@GetMapping("/subjects/{id}/certificates/{certId}")
	public InspectorCertificationPreviewLightDto getInspectorCertificationPreviewFromSpecialistRegistry(
					@PathVariable("id") long subjectId,
					@PathVariable("certId") int certificateId) {
		return permitInspectorService.getInspectorCertificationPreviewBySubjectIdAndCertificationId(subjectId, certificateId);
	}
	
	@GetMapping("/subjects/{subjectId}/documents/{documentId}")
	public PermitInspectorDocumentDto getDocumentToPermitInspector(
					@PathVariable("subjectId") long subjectId, @PathVariable("documentId") int documentId) {
		return subjectVersionDocumentService.getDocumentForPermitInspector(subjectId, documentId);
	}
	
	@GetMapping(value = "/subjects/{subjectId}/documents/{documentId}/image", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<byte[]> getInspectorDocumentImage(
					@PathVariable("subjectId") long subjectId, @PathVariable("documentId") int documentId) {
		byte[] result = subjectVersionDocumentService.getDocumentImage(subjectId, documentId);
		String contentType = result != null ? new Tika().detect(result) : null;
		HttpHeaders headers = new HttpHeaders();
		if (contentType != null) {
			headers.add(HttpHeaders.CONTENT_TYPE, contentType);
		}
		ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(result, headers, HttpStatus.OK);
		return response;
	}
	
	@GetMapping("/subjects/{subjectId}/documents")
	public PageResult<PermitInspectorDocumentLightDto> getInspectorDocumentsPage(@PathVariable("subjectId") int subjectId, 
					@RequestParam(value = "page") int page) {
		
		return subjectVersionDocumentService.getPermitInspectorDocumentsPage(subjectId, page);
	}
}
