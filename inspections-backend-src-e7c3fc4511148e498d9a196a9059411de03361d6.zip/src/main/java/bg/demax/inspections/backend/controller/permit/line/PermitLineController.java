package bg.demax.inspections.backend.controller.permit.line;

import java.io.ByteArrayOutputStream;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.hibernate.paging.PageRequest;
import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.PaginationQueryParams;
import bg.demax.inspections.backend.controller.param.permit.line.PermitLineDiagnosticRequestParams;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineDiagnosticLightDto;
import bg.demax.inspections.backend.export.equipment.HardwareDeviceTransferProtocolForPermitLineReport;
import bg.demax.inspections.backend.export.equipment.HardwareDeviceTransferProtocolForPermitLineReportExporter;
import bg.demax.inspections.backend.search.PermitLineDiagnosticSearch;
import bg.demax.inspections.backend.service.permit.line.PermitLineService;

@RestController
@RequestMapping("/api/permit-lines")
public class PermitLineController {
	@Autowired
	private PermitLineService permitLineService;

	@Autowired
	private HardwareDeviceTransferProtocolForPermitLineReportExporter exporter;

	@GetMapping("/diagnostics")
	public PageResult<PermitLineDiagnosticLightDto> getPagedDiagnosticsBySearch(
			@Valid PermitLineDiagnosticRequestParams params, @Valid PaginationQueryParams paginationParams) {

		PermitLineDiagnosticSearch search = new PermitLineDiagnosticSearch();
		BeanUtils.copyProperties(params, search);

		PageRequest pageRequest = new PageRequest();
		BeanUtils.copyProperties(paginationParams, pageRequest);

		PageResult<PermitLineDiagnosticLightDto> permitLinesPageResult = permitLineService
				.getPermitLinesConnectivityBySearch(search, pageRequest);

		return permitLinesPageResult;
	}

	@GetMapping(value = "/{id}/install-protocol", produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<byte[]> getInstallationTransferProtocol(@PathVariable("id") int pemitLineId) {

		ResponseEntity<byte[]> response = createTransferProtocol(pemitLineId, false);

		return response;
	}

	@GetMapping(value = "/{id}/retrieve-protocol", produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<byte[]> getRetrieveTransferProtocol(@PathVariable("id") int pemitLineId) {

		ResponseEntity<byte[]> response = createTransferProtocol(pemitLineId, true);

		return response;
	}

	private ResponseEntity<byte[]> createTransferProtocol(int pemitLineId, boolean isReturn) {

		HardwareDeviceTransferProtocolForPermitLineReport report = permitLineService
				.getHardwareDeviceTransferProtocolForPermitLinePdf(pemitLineId, isReturn);

		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		exporter.exportPdf(report, byteArrayOutputStream);

		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=TransferProtocolForPermitLine.pdf");
		ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(byteArrayOutputStream.toByteArray(), headers,
				HttpStatus.OK);
		return response;
	}

}
