package bg.demax.inspections.backend.controller.techinsp;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.inspections.backend.controller.param.techinsp.CamRequestRequestParams;
import bg.demax.inspections.backend.dto.techinsp.CamRequestLightDto;
import bg.demax.inspections.backend.service.techinsp.CamRequestService;

@RestController
@RequestMapping("/api/cam-requests")
public class CamRequestController {
	@Autowired
	private CamRequestService camRequestService;
	
	@GetMapping
	public CamRequestLightDto getCamRequest(@Valid CamRequestRequestParams requestParams) {
		return camRequestService.getCamRequest(requestParams.getResolution(), requestParams.getFeedNum());
	}
	
	@PutMapping("reduce-connections-and-close-if-zero")
	public void reduceConnectionsCountAndCloseIfZero(@Valid @RequestBody CamRequestRequestParams requestParams) {
		camRequestService.reduceCamRequestConnectionsCountAndCloseIfZero(requestParams.getResolution(), requestParams.getFeedNum());
	}
	
	@PutMapping("{inspectionId}/reduce-connections-and-close-if-zero")
	public void reduceConnectionsCountAndCloseIfZero(@PathVariable("inspectionId") long inspectionId) {
		camRequestService.reduceCamRequestConnectionsCountAndCloseIfZero(inspectionId);
	}
	
	@PutMapping("ping")
	public void pingCamRequest(@Valid @RequestBody CamRequestRequestParams requestParams) {
		camRequestService.pingCamRequest(requestParams);
	}
}
