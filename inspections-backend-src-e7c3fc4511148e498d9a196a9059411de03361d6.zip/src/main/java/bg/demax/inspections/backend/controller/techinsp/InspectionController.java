package bg.demax.inspections.backend.controller.techinsp;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;

import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.techinsp.ActiveInspectionRequestParams;
import bg.demax.inspections.backend.controller.param.techinsp.InspectionRequestParams;
import bg.demax.inspections.backend.controller.param.techinsp.InspectionSpecificRoleSearchRequestParams;
import bg.demax.inspections.backend.controller.param.techinsp.InspectionSpecificSearchRequestParams;
import bg.demax.inspections.backend.controller.param.techinsp.TechinspPageRequest;
import bg.demax.inspections.backend.dto.techinsp.FinishedInspectionLightDto;
import bg.demax.inspections.backend.dto.techinsp.InProgressInspectionLightDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionLiveStreamSetupResponseDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionSignatureDto;
import bg.demax.inspections.backend.dto.techinsp.OdometerHistoricalEntryDto;
import bg.demax.inspections.backend.dto.techinsp.SemtRegistrationNumberDto;
import bg.demax.inspections.backend.dto.techinsp.SemtUpdateRequestDto;
import bg.demax.inspections.backend.enums.ReportTypeCode;
import bg.demax.inspections.backend.export.techinsp.InspectionInternationalCertificateReportExporter;
import bg.demax.inspections.backend.search.techinsp.ActiveInspectionSearch;
import bg.demax.inspections.backend.search.techinsp.InspectionSearch;
import bg.demax.inspections.backend.search.techinsp.InspectionSpecificRoleSearch;
import bg.demax.inspections.backend.search.techinsp.InspectionSpecificSearch;
import bg.demax.inspections.backend.service.ReportLogService;
import bg.demax.inspections.backend.service.techinsp.InspectionService;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.techinsp.entity.SemtStatus;

@RestController
@RequestMapping("/api/inspections")
public class InspectionController {

	@Autowired
	private InspectionService inspectionService;

	@Autowired
	private ConversionService conversionService;

	@Autowired
	private ReportLogService reportLogService;

	@Autowired
	private InspectionInternationalCertificateReportExporter inspectionInternationalCertificateReportExporter;

	@GetMapping("finished")
	public PageResult<FinishedInspectionLightDto> getFinishedInspections(@Valid InspectionRequestParams queryParams,
			@Valid TechinspPageRequest pageRequest)
			throws IllegalAccessException, InvocationTargetException, JsonProcessingException {

		InspectionSearch search = conversionService.convert(queryParams, InspectionSearch.class);

		PageResult<FinishedInspectionLightDto> pageResult = inspectionService.getInspections(search, pageRequest);
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_SEARCH, queryParams);

		return pageResult;
	}

	@GetMapping("finished-specific-search")
	public PageResult<FinishedInspectionLightDto> getSpecificFinishedInspections(
			@Valid InspectionSpecificSearchRequestParams queryParams, @Valid TechinspPageRequest pageRequest)
			throws IllegalAccessException, InvocationTargetException, JsonProcessingException {

		InspectionSpecificSearch search = new InspectionSpecificSearch();
		BeanUtils.copyProperties(search, queryParams);

		PageResult<FinishedInspectionLightDto> pageResult = inspectionService.getInspections(search, pageRequest);
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_SEARCH, queryParams);

		return pageResult;
	}

	@GetMapping("finished-specific-role-search")
	public PageResult<FinishedInspectionLightDto> getSpecificRoleFinishedInspections(
			@Valid TechinspPageRequest pageRequest, @Valid InspectionSpecificRoleSearchRequestParams queryParams)
			throws IllegalAccessException, InvocationTargetException, JsonProcessingException {

		InspectionSpecificRoleSearch search = new InspectionSpecificRoleSearch();
		BeanUtils.copyProperties(search, queryParams);

		PageResult<FinishedInspectionLightDto> pageResult = inspectionService
				.getInspections(queryParams.getOwnerIdentityNumber(), search, pageRequest);
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_SEARCH, queryParams);

		return pageResult;
	}

	@GetMapping(value = "finished/xls", produces = "application/vnd.ms-excel")
	public byte[] getFinishedInspectionsXls(@Valid InspectionRequestParams queryParams, HttpServletResponse response)
			throws IllegalAccessException, InvocationTargetException, JsonProcessingException {
		response.setHeader("content-disposition", "attachment; filename=finished-inspections.xlsx");

		InspectionSearch search = new InspectionSearch();
		BeanUtils.copyProperties(search, queryParams);
		byte[] file = inspectionService.getFinishedInspectionsXls(search, queryParams);
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_SEARCH, queryParams);

		return file;
	}

	@GetMapping(value = "finished-specific-search/xls", produces = "application/vnd.ms-excel")
	public byte[] getSpecificFinishedInspectionsXls(@Valid InspectionSpecificSearchRequestParams queryParams,
			HttpServletResponse response)
			throws IllegalAccessException, InvocationTargetException, JsonProcessingException {
		response.setHeader("content-disposition", "attachment; filename=finished-inspections.xlsx");

		InspectionSpecificSearch search = new InspectionSpecificSearch();
		BeanUtils.copyProperties(search, queryParams);

		byte[] file = inspectionService.getSpecificFinishedInspectionsXls(search, queryParams);
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_SEARCH, queryParams);

		return file;
	}

	@GetMapping(value = "finished-specific-role-search/xls", produces = "application/vnd.ms-excel")
	public byte[] getSpecificRoleFinishedInspectionsXls(@Valid InspectionSpecificRoleSearchRequestParams queryParams,
			HttpServletResponse response)
			throws IllegalAccessException, InvocationTargetException, JsonProcessingException {
		response.setHeader("content-disposition", "attachment; filename=finished-inspections.xlsx");

		InspectionSpecificRoleSearch search = new InspectionSpecificRoleSearch();
		BeanUtils.copyProperties(search, queryParams);

		byte[] file = inspectionService.getSpecificRoleFinishedInspectionsXls(search, queryParams);
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_SEARCH, queryParams);

		return file;
	}

	@GetMapping("inprogress")
	public PageResult<InProgressInspectionLightDto> getActiveInspections(
			@Valid ActiveInspectionRequestParams queryParams, @Valid TechinspPageRequest pageRequest)
			throws IllegalAccessException, InvocationTargetException, JsonProcessingException {

		ActiveInspectionSearch search = new ActiveInspectionSearch();
		BeanUtils.copyProperties(search, queryParams);

		if (queryParams != null && queryParams.getOrgUnitCode() != null) {
			search.setOrgUnitCodes(Arrays.asList(queryParams.getOrgUnitCode()));
		}

		PageResult<InProgressInspectionLightDto> pageResult = inspectionService.getActiveInspectionsForPage(search,
				pageRequest);
		reportLogService.logReport(ReportTypeCode.SURVEILLANCE, queryParams);

		return pageResult;
	}

	@PutMapping("{id}/setup-live-stream")
	public InspectionLiveStreamSetupResponseDto setupLiveStream(@PathVariable("id") long id) {
		return inspectionService.setupLiveStream(id);
	}

	@GetMapping("{id}/light")
	public InProgressInspectionLightDto getInspectionLight(@PathVariable("id") long id) {
		return inspectionService.getInProgressInspectionLight(id);
	}

	@GetMapping("/{id}")
	public InspectionDto getInspectionById(@PathVariable("id") long inspectionId) {
		return inspectionService.getByIdWithProtocolsContainingFaultsOnly(inspectionId);
	}

	@GetMapping("/{id}/odometer-history")
	public List<OdometerHistoricalEntryDto> getOdometerHistoryByInspectionId(@PathVariable("id") long inspectionId) {
		return inspectionService.getOdometerHistoryByInspectionId(inspectionId);
	}

	@PostMapping("/{id}/secondary-inspection")
	@ResponseStatus(HttpStatus.CREATED)
	public void createSecondaryInspectionForId(@PathVariable("id") long inspectionId) {
		inspectionService.createSecondaryInspectionForInspectionId(inspectionId);
	}

	@PatchMapping("/{id}/cancel-secondary-inspection")
	public void cancelSecondaryInspectionForId(@PathVariable("id") long inspectionId) {
		inspectionService.cancelSecondaryInspectionForInspectionId(inspectionId);
	}

	@GetMapping(value = "/{id}/protocol/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
	public byte[] getInspectionProtocolById(@PathVariable("id") long inspectionId) {
		return inspectionService.getInspectionProtocolByteArrayById(inspectionId);
	}

	@GetMapping(value = "/{id}/gas-protocol/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
	public byte[] getInspectionGasProtocolById(@PathVariable("id") long inspectionId) {
		return inspectionService.getInspectionGasProtocolByteArrayById(inspectionId);
	}

	@GetMapping(value = "/{id}/adr-protocol/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
	public byte[] getInspectionAdrProtocolById(@PathVariable("id") long inspectionId) {
		return inspectionService.getAdrProtocolPdfByteById(inspectionId);
	}

	@GetMapping(value = "/{id}/cistern-protocol/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
	public byte[] getInspectionCisternProtocolById(@PathVariable("id") long inspectionId) {
		return inspectionService.getCisterPdfByteById(inspectionId);
	}

	@GetMapping(value = "/{id}/certificate/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
	public byte[] getInspectionCertificateById(@PathVariable("id") long inspectionId) {
		return inspectionService.getInspectionCertificationByteArrayById(inspectionId);
	}

	@GetMapping(value = "/{id}/gas-certificate/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
	public byte[] getInspectionGasCertificateById(@PathVariable("id") long inspectionId) {
		return inspectionService.getInspectionGasCertificateByteArrayById(inspectionId);
	}

	@PutMapping("/{id}/semt")
	public void editInspectionSemtByInspId(@PathVariable("id") long inspectionId,
			@Valid @RequestBody SemtUpdateRequestDto requestDto) {
		inspectionService.updateInspectionSemt(inspectionId, requestDto);
	}

	@PatchMapping("/{id}/semt/reg-num")
	public void patchInspectionSemtRegNum(@PathVariable("id") long inspectionId,
			@RequestBody  @Valid SemtRegistrationNumberDto registrationNumberParams) {
		inspectionService.patchInspectionSemtRegNumber(inspectionId, registrationNumberParams.getRegistrationNumber());
	}

	@PatchMapping("/{id}/semt/reissue")
	public void patchInspectionSemtReissue(@PathVariable("id") long inspectionId) {
		inspectionService.reissueSemtCertificate(inspectionId);
	}

	@PatchMapping("/{id}/semt/approve")
	public void approveInspectionSemtStatusByInspId(@PathVariable("id") long inspectionId) {
		inspectionService.updateInspectionSemtStatus(inspectionId, SemtStatus.APPROVED);
	}

	@PatchMapping("/{id}/semt/decline")
	public void declineInspectionSemtStatusByInspId(@PathVariable("id") long inspectionId) {
		inspectionService.updateInspectionSemtStatus(inspectionId, SemtStatus.DECLINED);
	}

	@GetMapping(value = "/{id}/international-certificate", produces = MediaType.APPLICATION_PDF_VALUE)
	public byte[] getInspectionInternationalCertificateById(@PathVariable("id") long inspectionId) {

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		inspectionInternationalCertificateReportExporter
				.exportPdf(inspectionService.getInspectionInternationalCertificateReport(inspectionId), outputStream);
		return outputStream.toByteArray();
	}

	@GetMapping(value = "/{id}/semt/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
	public byte[] getInspectionSemt(@PathVariable("id") long inspectionId) {
		return inspectionService.getInspectionSemtByteArrayById(inspectionId);
	}

	@GetMapping("/{id}/signature")
	public InspectionSignatureDto getInspectionSignature(@PathVariable("id") long inspectionId) {
		InspectionDto inspection = inspectionService.getInspectionDtoById(inspectionId);
		String signatureSha1 = inspectionService.getInspectionSignature(inspection);
		return new InspectionSignatureDto(signatureSha1);
	}

	@GetMapping(value = "/{id}/short-video")
	public ResponseEntity<StreamingResponseBody> getShortVideoStream(@PathVariable("id") long inspectionId) {
		InspectionDto inspection = inspectionService.getInspectionDtoById(inspectionId);
		StreamingResponseBody stream = inspectionService.getInspectionShortVideoStream(inspection);

		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_TYPE, "video/mp4");
		headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + inspectionId + ".mp4");

		ResponseEntity<StreamingResponseBody> responseEntity = new ResponseEntity<StreamingResponseBody>(stream,
				headers, HttpStatus.OK);

		return responseEntity;
	}
}
