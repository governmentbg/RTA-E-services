package bg.demax.inspections.backend.controller.techinsp;

import java.io.ByteArrayOutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;

import bg.demax.inspections.backend.controller.param.permit.IssuedSemtReportRequestParams;
import bg.demax.inspections.backend.controller.param.techinsp.InspectionReportRequestParams;
import bg.demax.inspections.backend.controller.param.techinsp.InspectionTypesCountByKtpReportRequestParams;
import bg.demax.inspections.backend.controller.param.techinsp.InspectionTypesCountReportRequestParams;
import bg.demax.inspections.backend.dto.IssuedSemtHtmlReportDto;
import bg.demax.inspections.backend.dto.orders.InspectionOrderUnusedStickersReportDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionCountForVehicleReport;
import bg.demax.inspections.backend.dto.techinsp.InspectionCountForVehicleReportLightDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionIssuesCountReportDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionIssuesCountReportLightDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionIssuesCountReportRequestDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionPassedAfterIssuesCountLightDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountByKtpNumberReportRequestDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountByKtpNumberReportRowDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountByKtpReportLightDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountByKtpReportRequestDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountByKtpResult;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountReportLightDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountReportRequestDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountResponseDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountResult;
import bg.demax.inspections.backend.dto.techinsp.InspectionsCountForVehicleReportRequestDto;
import bg.demax.inspections.backend.enums.ReportTypeCode;
import bg.demax.inspections.backend.export.report.InspectionIssuesCountReport;
import bg.demax.inspections.backend.export.report.InspectionIssuesCountReportExporter;
import bg.demax.inspections.backend.export.report.InspectionIssuesCountReportRow;
import bg.demax.inspections.backend.export.report.InspectionTypesCountByKtpReport;
import bg.demax.inspections.backend.export.report.InspectionTypesCountByKtpReportExporter;
import bg.demax.inspections.backend.export.report.InspectionTypesCountByKtpReportRow;
import bg.demax.inspections.backend.export.report.InspectionTypesCountReport;
import bg.demax.inspections.backend.export.report.InspectionTypesCountReportExporter;
import bg.demax.inspections.backend.export.report.InspectionTypesCountReportRow;
import bg.demax.inspections.backend.export.report.InspectionsCountForVehicleReport;
import bg.demax.inspections.backend.export.report.InspectionsCountForVehicleReportExporter;
import bg.demax.inspections.backend.export.report.InspectionsCountForVehicleReportRow;
import bg.demax.inspections.backend.export.techinsp.IssuedSemtsReportData;
import bg.demax.inspections.backend.export.techinsp.IssuedSemtsReportExporter;
import bg.demax.inspections.backend.search.techinsp.InspectionReportSearch;
import bg.demax.inspections.backend.search.techinsp.InspectionTypesCountByKtpNumberReportSearch;
import bg.demax.inspections.backend.search.techinsp.InspectionTypesCountByOrgUnitReportSearch;
import bg.demax.inspections.backend.service.ReportLogService;
import bg.demax.inspections.backend.service.techinsp.InspectionReportService;
import bg.demax.legacy.util.convert.ConversionService;

@RestController
@RequestMapping("/api/inspections/reports")
public class InspectionReportController {

	@Autowired
	private ConversionService conversionService;

	@Autowired
	InspectionReportService inspectionReportService;

	@Autowired
	private InspectionTypesCountByKtpReportExporter inspectionTypesCountByKtpReportExporter;

	@Autowired
	private InspectionTypesCountReportExporter inspectionTypesCountReportExporter;

	@Autowired
	private InspectionIssuesCountReportExporter inspectionIssuesCountReportExporter;

	@Autowired
	private InspectionsCountForVehicleReportExporter inspectionsCountForVehicleReportExporter;
	
	@Autowired
	private ReportLogService reportLogService;
	
	@Autowired
	private IssuedSemtsReportExporter issuedSemtsReportExporter;
	

	@GetMapping("types-count-by-ktp-number")
	public InspectionTypesCountResponseDto getInspectionTypesCountByKtpNumberReport(
					@Valid InspectionTypesCountByKtpReportRequestParams params) throws JsonProcessingException {
		InspectionTypesCountByKtpNumberReportSearch search = conversionService.convert(params,
						InspectionTypesCountByKtpNumberReportSearch.class);
		List<InspectionTypesCountByKtpResult> inspectionTypesByKtp = inspectionReportService
						.getInspectionTypesCountByKtpReportForKtpNumber(search);
		List<InspectionTypesCountResult> inspectionTypeCountResults = inspectionReportService.getInspectionTypesCountReport(search);

		InspectionTypesCountResponseDto responseDto = new InspectionTypesCountResponseDto();
		responseDto.setInspectionTypesCountByKtpDtos(
						conversionService.convertList(inspectionTypesByKtp, InspectionTypesCountByKtpReportLightDto.class));
		responseDto.setInspectionTypesCountDtos(
						conversionService.convertList(inspectionTypeCountResults, InspectionTypesCountReportLightDto.class));
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_TYPES_COUNT_BY_KTP_REPORT, params);
		
		return responseDto;
	}

	@GetMapping("types-count")
	public InspectionTypesCountResponseDto getInspectionTypesCountReport(@Valid InspectionTypesCountReportRequestParams params) 
			throws JsonProcessingException {
		InspectionTypesCountByOrgUnitReportSearch search = conversionService.convert(params,
						InspectionTypesCountByOrgUnitReportSearch.class);
		List<InspectionTypesCountByKtpResult> inspectionTypesByKtp = inspectionReportService.getInspectionTypesCountByKtpReport(search);
		List<InspectionTypesCountResult> inspectionTypeCountResults = inspectionReportService.getInspectionTypesCountReport(search);

		InspectionTypesCountResponseDto responseDto = new InspectionTypesCountResponseDto();
		responseDto.setInspectionTypesCountByKtpDtos(
						conversionService.convertList(inspectionTypesByKtp, InspectionTypesCountByKtpReportLightDto.class));
		responseDto.setInspectionTypesCountDtos(
						conversionService.convertList(inspectionTypeCountResults, InspectionTypesCountReportLightDto.class));
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_TYPES_COUNT_REPORT, params);
		
		return responseDto;
	}

	@GetMapping(value = "types-count-by-ktp-number-extended/xls", produces = "application/vnd.ms-excel")
	public byte[] getInspectionTypesCountByKtpNumberReportAsXlsFile(
			@Valid InspectionTypesCountByKtpReportRequestParams params,
					HttpServletResponse response) throws JsonProcessingException {
		response.setHeader("content-disposition", "attachment; filename=types-count-report-by-ktp-number.xlsx");
		InspectionTypesCountByKtpNumberReportSearch search = conversionService.convert(params,
				InspectionTypesCountByKtpNumberReportSearch.class);
		
		List<InspectionTypesCountByKtpResult> inspectionTypesByKtp = inspectionReportService
				.getInspectionTypesCountByKtpReportForKtpNumber(search);

		InspectionTypesCountByKtpNumberReportRequestDto dto = new InspectionTypesCountByKtpNumberReportRequestDto();
		dto.setRows(conversionService.convertList(inspectionTypesByKtp, InspectionTypesCountByKtpNumberReportRowDto.class));
		dto.setTitle(params.getTitle());
		
		List<InspectionTypesCountByKtpReportRow> reportRows = conversionService.convertList(dto.getRows(),
						InspectionTypesCountByKtpReportRow.class);
		InspectionTypesCountByKtpReport report = new InspectionTypesCountByKtpReport(reportRows, dto.getTitle());
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		inspectionTypesCountByKtpReportExporter.exportXls(report, outputStream);
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_TYPES_COUNT_BY_KTP_REPORT, dto);
		
		return outputStream.toByteArray();
	}

	@GetMapping(value = "types-count-by-ktp-number/xls", produces = "application/vnd.ms-excel")
	public byte[] getInspectionTypesCountByKtpNumberExtendedReportAsXlsFile(
			@Valid InspectionTypesCountByKtpReportRequestParams params,
					HttpServletResponse response) throws JsonProcessingException {
		response.setHeader("content-disposition", "attachment; filename=types-count-report-by-ktp-number.xlsx");
		InspectionTypesCountByKtpNumberReportSearch search = conversionService.convert(params,
				InspectionTypesCountByKtpNumberReportSearch.class);
		
		List<InspectionTypesCountResult> inspectionTypeCountResults = inspectionReportService.getInspectionTypesCountReport(search);

		InspectionTypesCountReportRequestDto dto = new InspectionTypesCountReportRequestDto();
		dto.setRows(conversionService.convertList(inspectionTypeCountResults, InspectionTypesCountReportRow.class));
		dto.setTitle(params.getTitle());
		InspectionTypesCountReport report = new InspectionTypesCountReport(dto.getRows(), dto.getTitle());
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		inspectionTypesCountReportExporter.exportXls(report, outputStream);
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_TYPES_COUNT_BY_KTP_REPORT, dto);
		
		return outputStream.toByteArray();
	}

	@GetMapping(value = "types-count-by-ktp/xls", produces = "application/vnd.ms-excel")
	public byte[] getInspectionTypesCountByKtpReportAsXlsFile(@Valid InspectionTypesCountReportRequestParams params, 
			HttpServletResponse response) throws JsonProcessingException {
		response.setHeader("content-disposition", "attachment; filename=types-count-report-by-ktp.xlsx");

		InspectionTypesCountByOrgUnitReportSearch search = conversionService.convert(params,
						InspectionTypesCountByOrgUnitReportSearch.class);
		List<InspectionTypesCountByKtpResult> inspectionTypesByKtp = inspectionReportService.getInspectionTypesCountByKtpReport(search);
		InspectionTypesCountByKtpReportRequestDto dto = new InspectionTypesCountByKtpReportRequestDto();
		
		dto.setRows(conversionService.convertList(inspectionTypesByKtp, InspectionTypesCountByKtpReportRow.class));
		dto.setTitle(params.getTitle());
		
		InspectionTypesCountByKtpReport report = new InspectionTypesCountByKtpReport(dto.getRows(), dto.getTitle());
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		inspectionTypesCountByKtpReportExporter.exportXls(report, outputStream);
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_TYPES_COUNT_BY_ORG_UNIT_REPORT, dto);
		
		return outputStream.toByteArray();
	}

	@GetMapping(value = "types-count/xls", produces = "application/vnd.ms-excel")
	public byte[] getInspectionTypesCountReportAsXlsFile(@Valid InspectionTypesCountReportRequestParams params, 
			HttpServletResponse response) 
			throws JsonProcessingException {
		response.setHeader("content-disposition", "attachment; filename=types-count-report.xlsx");

		InspectionTypesCountReportRequestDto dto = new InspectionTypesCountReportRequestDto();
		InspectionTypesCountByOrgUnitReportSearch search = conversionService.convert(params,
				InspectionTypesCountByOrgUnitReportSearch.class);
		
		List<InspectionTypesCountResult> inspectionTypeCountResults = inspectionReportService.getInspectionTypesCountReport(search);
		dto.setRows(conversionService.convertList(inspectionTypeCountResults, InspectionTypesCountReportRow.class));
		dto.setTitle(params.getTitle());
		
		InspectionTypesCountReport report = new InspectionTypesCountReport(dto.getRows(), dto.getTitle());
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		inspectionTypesCountReportExporter.exportXls(report, outputStream);
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_TYPES_COUNT_REPORT, params);
		
		return outputStream.toByteArray();
	}

	@GetMapping("issues-count")
	public List<InspectionIssuesCountReportLightDto> getInspectionIssuesCount(@Valid InspectionReportRequestParams params) 
			throws JsonProcessingException {
		InspectionReportSearch search = conversionService.convert(params, InspectionReportSearch.class);
		List<InspectionIssuesCountReportDto> reportRows = inspectionReportService.getInspectionIssuesCount(search);
		List<InspectionIssuesCountReportLightDto> list = conversionService.convertList(reportRows, 
				InspectionIssuesCountReportLightDto.class);
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_ISSUES_COUNT_REPORT, params);
		
		return list;
	}

	@GetMapping(value = "issues-count/xls", produces = "application/vnd.ms-excel")
	public byte[] getInspectionIssuesCountReportAsXlsFile(@Valid InspectionReportRequestParams params, HttpServletResponse response) 
			throws JsonProcessingException {
		response.setHeader("content-disposition", "attachment; filename=issues-count-report.xlsx");
		
		InspectionReportSearch search = conversionService.convert(params, InspectionReportSearch.class);
		List<InspectionIssuesCountReportDto> reportRows = inspectionReportService.getInspectionIssuesCount(search);

		InspectionIssuesCountReportRequestDto dto = new InspectionIssuesCountReportRequestDto();
		dto.setRows(conversionService.convertList(reportRows, InspectionIssuesCountReportRow.class));
		dto.setTitle(params.getTitle());

		InspectionIssuesCountReport report = new InspectionIssuesCountReport(dto.getRows(), dto.getTitle());
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		inspectionIssuesCountReportExporter.exportXls(report, outputStream);
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_ISSUES_COUNT_REPORT, dto);
		
		return outputStream.toByteArray();
	}

	@GetMapping("passed-after-issues-count")
	public InspectionPassedAfterIssuesCountLightDto getInspectionPassedAfterIssuesCount(@Valid InspectionReportRequestParams params) 
			throws JsonProcessingException {
		InspectionReportSearch search = conversionService.convert(params, InspectionReportSearch.class);
		InspectionPassedAfterIssuesCountLightDto dto = inspectionReportService.getInspectionPassedAfterIssuesCount(search);
		reportLogService.logReport(ReportTypeCode.INSPECTIONS_PASSED_AFTER_ISSUES_COUNT_REPORT, params);
		
		return dto;
	}

	@GetMapping("vehicle-inspections-count")
	public List<InspectionCountForVehicleReportLightDto> getVehicleInspectionsCountReport(@Valid InspectionReportRequestParams params) 
			throws JsonProcessingException {
		InspectionReportSearch search = conversionService.convert(params, InspectionReportSearch.class);
		List<InspectionCountForVehicleReport> reportRows = inspectionReportService.getVehicleInspectionsCountReport(search);
		List<InspectionCountForVehicleReportLightDto> dtos = 
				conversionService.convertList(reportRows, InspectionCountForVehicleReportLightDto.class);
		reportLogService.logReport(ReportTypeCode.VEHICLE_INSPECTIONS_COUNT_REPORT, params);
		
		return dtos;
	}

	@GetMapping(value = "vehicle-inspections-count/xls", produces = "application/vnd.ms-excel")
	public byte[] getVehicleInspectionsCountReportAsXlsFile(@Valid InspectionReportRequestParams params, HttpServletResponse response) 
			throws JsonProcessingException {
		response.setHeader("content-disposition", "attachment; filename=vehicle-inspections-count-report.xlsx");

		InspectionReportSearch search = conversionService.convert(params, InspectionReportSearch.class);
		InspectionsCountForVehicleReportRequestDto dto = new InspectionsCountForVehicleReportRequestDto();
		List<InspectionCountForVehicleReport> reportRows = inspectionReportService.getVehicleInspectionsCountReport(search);
		dto.setRows(conversionService.convertList(reportRows, InspectionsCountForVehicleReportRow.class));
		dto.setTitle(params.getTitle());

		InspectionsCountForVehicleReport report = new InspectionsCountForVehicleReport(dto.getRows(), dto.getTitle());
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		inspectionsCountForVehicleReportExporter.exportXls(report, outputStream);
		reportLogService.logReport(ReportTypeCode.VEHICLE_INSPECTIONS_COUNT_REPORT, dto);
		
		return outputStream.toByteArray();
	}
	
	@GetMapping("unused-stickers-report")
	public InspectionOrderUnusedStickersReportDto getOrdersUnusedStickersReportByKtp(@RequestParam("ktpNumber") int ktpNumber) 
			throws JsonProcessingException {
		InspectionOrderUnusedStickersReportDto dto = inspectionReportService.getUnusedStickersReportByKtp(ktpNumber);
		reportLogService.logReport(ReportTypeCode.UNUSED_STICKERS_REPORT, ktpNumber);
		
		return dto;
	}
	
	@GetMapping("/issued-semt-count")
	public List<IssuedSemtHtmlReportDto> getIssuedSemtHtmlReport(IssuedSemtReportRequestParams params) throws JsonProcessingException {

		List<IssuedSemtHtmlReportDto> list = inspectionReportService.getIssuedSemtHtmlReportDtos(params);
		reportLogService.logReport(ReportTypeCode.HTML_SEMT_CERTIFICATES_REPORT, params);
		
		return list;
	}

	@GetMapping(value = "/issued-semts/xls", produces = "application/vnd.ms-excel")
	public byte[] getIssuedSemtItemsReportAsXlsFile(@Valid IssuedSemtReportRequestParams queryParams,
			HttpServletResponse response) throws JsonProcessingException {
		response.setHeader("content-disposition", "attachment; filename=issued-semts.xlsx");
		List<IssuedSemtHtmlReportDto> semts = inspectionReportService.getIssuedSemtHtmlReportDtos(queryParams);
		IssuedSemtsReportData report = new IssuedSemtsReportData(queryParams, semts);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		issuedSemtsReportExporter.exportXls(report, outputStream);
		reportLogService.logReport(ReportTypeCode.HTML_SEMT_CERTIFICATES_REPORT, queryParams);
		return outputStream.toByteArray();
	}
	
}
