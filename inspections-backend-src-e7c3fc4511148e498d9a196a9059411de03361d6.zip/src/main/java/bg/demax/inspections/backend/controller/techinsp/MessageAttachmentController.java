package bg.demax.inspections.backend.controller.techinsp;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.inspections.backend.entity.techinsp.MessageAttachment;
import bg.demax.inspections.backend.exception.techinsp.InvalidAttachmentFileTypeException;
import bg.demax.inspections.backend.service.techinsp.MessageAttachmentService;

@RestController
@RequestMapping("/api/message-attachments")
public class MessageAttachmentController {

	@Autowired
	private MessageAttachmentService messageAttachmentService;

	@GetMapping("/{id}")
	public ResponseEntity<byte[]> getMessageAttachmentContent(@PathVariable("id") int messageAttachmentId, HttpServletResponse response) {
		MessageAttachment messageAttachment = messageAttachmentService.getById(messageAttachmentId);
		HttpHeaders headers = new HttpHeaders();
		if (MediaType.APPLICATION_PDF_VALUE.equals(messageAttachment.getMimeType())) {
			headers.setContentType(MediaType.APPLICATION_PDF);
		} else if (MediaType.IMAGE_JPEG_VALUE.equals(messageAttachment.getMimeType())) {
			headers.setContentType(MediaType.IMAGE_JPEG);
		} else if (MediaType.IMAGE_PNG_VALUE.equals(messageAttachment.getMimeType())) {
			headers.setContentType(MediaType.IMAGE_PNG);
		} else {
			throw new InvalidAttachmentFileTypeException("Invalid attachment mime type fount in the database.");
		}
		return new ResponseEntity<byte[]>(messageAttachment.getContent(), headers, HttpStatus.OK);
	}
}
