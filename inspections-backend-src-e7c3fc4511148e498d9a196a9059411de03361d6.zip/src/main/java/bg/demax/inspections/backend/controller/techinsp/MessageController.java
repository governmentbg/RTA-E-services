package bg.demax.inspections.backend.controller.techinsp;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import bg.demax.hibernate.paging.PageRequest;
import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.techinsp.messages.MessageRequestParams;
import bg.demax.inspections.backend.dto.techinsp.messages.MessageDto;
import bg.demax.inspections.backend.dto.techinsp.messages.MessageLightDto;
import bg.demax.inspections.backend.dto.techinsp.messages.MessageRequestDto;
import bg.demax.inspections.backend.dto.techinsp.messages.MessageStatusRequestDto;
import bg.demax.inspections.backend.entity.techinsp.Message;
import bg.demax.inspections.backend.entity.techinsp.MessageAttachment;
import bg.demax.inspections.backend.entity.techinsp.enums.MessageStatus;
import bg.demax.inspections.backend.search.techinsp.MessageSearch;
import bg.demax.inspections.backend.service.techinsp.MessageService;
import bg.demax.legacy.util.convert.ConversionService;

@RestController
@RequestMapping("/api/messages")
public class MessageController {

	// private static final Logger logger = LogManager.getLogger(MessageController.class);

	@Autowired
	private MessageService messageService;

	@Autowired
	private ConversionService conversionService;

	@GetMapping("/sent")
	public PageResult<MessageLightDto> getSentMessages(@Valid MessageRequestParams requestParams, @Valid PageRequest pageRequest) {
		MessageSearch search = conversionService.convert(requestParams, MessageSearch.class);
		PageResult<MessageLightDto> pageResult = messageService.getSentMessages(search, pageRequest);
		
		return pageResult;
	}

	@GetMapping("/draft")
	public PageResult<MessageLightDto> getDraftMessages(@Valid MessageRequestParams requestParams, @Valid PageRequest pageRequest) {
		MessageSearch search = conversionService.convert(requestParams, MessageSearch.class);
		PageResult<MessageLightDto> pageResult = messageService.getDraftMessages(search, pageRequest);
		
		return pageResult;
	}

	@GetMapping("/{id}")
	public MessageDto getMessageById(@PathVariable("id") int messageId) {
		return messageService.getMessageById(messageId);
	}

	@PostMapping(value = "/sent", consumes = "multipart/form-data")
	@ResponseStatus(HttpStatus.OK)
	public void saveAndSendMessage(@Valid @RequestPart(name = "message", required = true) MessageRequestDto requestDto,
					@Valid @RequestPart(name = "attachments", required = false) List<MultipartFile> attachmentFiles) {
		Message message = conversionService.convert(requestDto, Message.class);
		if (attachmentFiles != null && !attachmentFiles.isEmpty()) {
			List<MessageAttachment> attachments = conversionService.convertList(attachmentFiles, MessageAttachment.class);
			message.getAttachments().addAll(attachments);
		}

		messageService.saveAndSendMessage(message, requestDto.getOrgUnitCode());
	}

	@PostMapping(value = "/draft", consumes = "multipart/form-data")
	@ResponseStatus(HttpStatus.OK)
	public void saveMessageAsDraft(@Valid @RequestPart(name = "message", required = true) MessageRequestDto requestDto,
					@Valid @RequestPart(name = "attachments", required = false) List<MultipartFile> attachmentFiles) {
		Message message = conversionService.convert(requestDto, Message.class);
		if (attachmentFiles != null && !attachmentFiles.isEmpty()) {
			List<MessageAttachment> attachments = conversionService.convertList(attachmentFiles, MessageAttachment.class);
			message.getAttachments().addAll(attachments);
		}
		messageService.saveMessageAsDraft(message, requestDto.getOrgUnitCode());
	}

	@PutMapping(value = "/{id}/draft", consumes = "multipart/form-data")
	@ResponseStatus(HttpStatus.OK)
	public void updateDraftMessage(@PathVariable("id") int messageId, 
					@Valid @RequestPart(name = "message", required = true) MessageRequestDto requestDto,
					@Valid @RequestPart(name = "attachments", required = false) List<MultipartFile> attachmentFiles) {
		Message message = conversionService.convert(requestDto, Message.class);
		if (attachmentFiles != null && !attachmentFiles.isEmpty()) {
			List<MessageAttachment> attachments = conversionService.convertList(attachmentFiles, MessageAttachment.class);
			message.getAttachments().addAll(attachments);
		}
		messageService.updateDraftMessage(messageId, message, requestDto.getOrgUnitCode());
	}
	
	@PatchMapping("/{id}/draft/status")
	@ResponseStatus(HttpStatus.OK)
	public void updateDraftMessageStatus(@PathVariable("id") int messageId, @Valid @RequestBody MessageStatusRequestDto requestDto) {
		MessageStatus status = conversionService.convert(requestDto, MessageStatus.class);
		messageService.updateDraftMessageStatus(messageId, status);
	}
	
	@DeleteMapping(value = "/draft")
	@ResponseStatus(HttpStatus.OK)
	public void deleteDraftMessages(@Valid MessageDeletionRequestParams params) {
		messageService.deleteDraftMessages(params.getMessageIds());
	}
}