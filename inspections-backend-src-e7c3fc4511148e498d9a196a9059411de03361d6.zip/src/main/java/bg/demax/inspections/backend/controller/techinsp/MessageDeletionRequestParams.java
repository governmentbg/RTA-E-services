package bg.demax.inspections.backend.controller.techinsp;

import javax.validation.constraints.NotEmpty;

public class MessageDeletionRequestParams {

	@NotEmpty
	private int[] messageIds = null;

	public int[] getMessageIds() {
		return messageIds;
	}

	public void setMessageIds(int[] messageIds) {
		this.messageIds = messageIds;
	}
}
