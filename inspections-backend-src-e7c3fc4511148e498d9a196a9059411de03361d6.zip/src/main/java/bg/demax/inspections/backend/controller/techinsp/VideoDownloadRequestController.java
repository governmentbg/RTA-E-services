package bg.demax.inspections.backend.controller.techinsp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;

import bg.demax.hibernate.paging.PageResult;
import bg.demax.inspections.backend.controller.param.techinsp.TechinspPageRequest;
import bg.demax.inspections.backend.controller.param.techinsp.VideoDownloadRequestParams;
import bg.demax.inspections.backend.dto.techinsp.InspectionDto;
import bg.demax.inspections.backend.dto.techinsp.VideoDownloadRequestLightDto;
import bg.demax.inspections.backend.enums.ReportTypeCode;
import bg.demax.inspections.backend.exception.techinsp.VideoNotFoundException;
import bg.demax.inspections.backend.search.techinsp.VideoDownloadRequestSearch;
import bg.demax.inspections.backend.service.ReportLogService;
import bg.demax.inspections.backend.service.techinsp.InspectionService;
import bg.demax.inspections.backend.service.techinsp.VideoDownloadRequestService;
import bg.demax.inspections.backend.util.InspectionPathUtil;

@RestController
@RequestMapping("/api/video-download-requests")
public class VideoDownloadRequestController {

	private static final Logger logger = LogManager.getLogger(VideoDownloadRequestController.class);
	
	@Autowired
	private VideoDownloadRequestService videoDownloadRequestService;

	@Autowired
	private InspectionService inspectionService;

	@Autowired
	private InspectionPathUtil inspectionUtil;
	
	@Autowired
	private ReportLogService reportLogService;

	@GetMapping
	public PageResult<VideoDownloadRequestLightDto> getVideoDownloadRequestsBySearch(
			@Valid VideoDownloadRequestParams queryParams, @Valid TechinspPageRequest pageRequest)
			throws IllegalAccessException, InvocationTargetException, JsonProcessingException {
		VideoDownloadRequestSearch search = new VideoDownloadRequestSearch();
		BeanUtils.copyProperties(queryParams, search);
		PageResult<VideoDownloadRequestLightDto> videoRequests = videoDownloadRequestService
				.getVideoDownloadRequests(search, pageRequest);
		reportLogService.logReport(ReportTypeCode.VIDEOS_SEARCH, queryParams);

		return videoRequests;
	}

	@PostMapping("/{protocolNumber}")
	@ResponseStatus(HttpStatus.CREATED)
	public void requestFullVideoForInspection(@PathVariable("protocolNumber") long protocolNumber) throws JsonProcessingException {
		videoDownloadRequestService.requestFullVideoForInspection(protocolNumber);
		reportLogService.logReport(ReportTypeCode.VIDEOS_REQUEST, protocolNumber);
	}

	@GetMapping("/{inspectionId}/zip")
	public @ResponseBody ResponseEntity<byte[]> getVideosZip(@PathVariable("inspectionId") Long inspectionId) {

		InspectionDto inspection = inspectionService.getInspectionDtoById(inspectionId);

		LocalDateTime inspectionDateTime = inspection.getStartedAt();

		Path fileDir = Paths.get(inspectionUtil.getInspectionLongVideoPath(inspectionDateTime));
		
		logger.info("downloading zip for inspection: " + inspectionId + " path: " + fileDir.toString());
		
		ByteArrayOutputStream baos = null;
		try {
			baos = new ByteArrayOutputStream();

			try (ZipOutputStream zipOutputStream = new ZipOutputStream(baos)) {

				Files.walk(fileDir).filter(path -> !Files.isDirectory(path)).forEach(path -> {
					if (!path.toString().contains(inspectionId + "")) {
						return;
					}

					ZipEntry zipEntry = new ZipEntry(fileDir.relativize(path).toString());
					try {
						zipOutputStream.putNextEntry(zipEntry);
						zipOutputStream.write(Files.readAllBytes(path));
						zipOutputStream.closeEntry();
					} catch (Exception e) {
						System.err.println(e);
					}
				});
			}

			HttpHeaders headers = new HttpHeaders();
			headers.add(HttpHeaders.CONTENT_TYPE, "applicatoin/zip");
			headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + inspectionId + ".zip");

			ResponseEntity<byte[]> responseEntity = new ResponseEntity<byte[]>(baos.toByteArray(), headers,
					HttpStatus.OK);
			baos.close();
			return responseEntity;
		} catch (IOException e) {
			throw new VideoNotFoundException(inspectionId);
		}
	}
}
