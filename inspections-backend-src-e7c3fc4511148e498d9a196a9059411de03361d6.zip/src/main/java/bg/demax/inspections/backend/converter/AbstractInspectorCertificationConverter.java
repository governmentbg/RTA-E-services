package bg.demax.inspections.backend.converter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Supplier;

import bg.demax.pub.entity.VehicleCategory;
import bg.demax.specialist.registry.common.entity.InspectorCertification;
import bg.demax.techinsp.entity.InspectionType;

public abstract class AbstractInspectorCertificationConverter {

	public static final String INITICAL_CERTIFICATION = "Удостоверение за допълнително начално обучение";
	public static final String PERIODICAL_CERTIFICATION = "Удостоверение за допълнително периодично обучение";

	public static final String INITICAL_ADR_CERTIFICATION = "Свидетелство за начална проф. квалификация (ADR)";
	public static final String PERIODICAL_ADR_CERTIFICATION = "Удостоверение за периодично обучение (ADR)";

	public static final String INITICAL_GAS_CERTIFICATION = "Свидетелство за начална проф. квалификация (ВНГ/СПГ)";
	public static final String PERIODICAL_GAS_CERTIFICATION = "Удостоверение за периодично обучение (ВНГ/СПГ)";

	protected String getCategoriesString(List<InspectorCertification> certifications) {
		if (certifications != null && !certifications.isEmpty()) {
			Set<String> categories = new TreeSet<String>();
			for (InspectorCertification certification : certifications) {
				List<VehicleCategory> vehicleCategories = certification.getCourse().getEducationCategory()
						.getVehicleCategories();
				for (VehicleCategory vehicleCategory : vehicleCategories) {
					categories.add(vehicleCategory.getCode());
				}
			}
			return buildResultString(categories);
		}
		return null;
	}

	protected String getInspectionTypesString(List<InspectorCertification> certifications) {
		if (certifications != null && !certifications.isEmpty()) {
			Set<String> inspectionTypes = new TreeSet<String>();
			for (InspectorCertification certification : certifications) {
				List<InspectionType> certificationInspectionTypes = certification.getCourse().getEducationCategory()
						.getInspectionTypes();
				for (InspectionType inspType : certificationInspectionTypes) {
					inspectionTypes.add(inspType.getTiiaDescription());
				}
			}
			return buildResultString(inspectionTypes);
		}
		return null;
	}

	protected String getCertificationDocTypeByInspectionType(String inspectionType, String docType) {
		if (inspectionType.equals("GAS")) {
			if (docType.equals("INITIAL")) {
				return INITICAL_GAS_CERTIFICATION;
			} else {
				return PERIODICAL_GAS_CERTIFICATION;
			}
		} else if (inspectionType.equals("АДР")) {
			if (docType.equals("INITIAL")) {
				return INITICAL_ADR_CERTIFICATION;
			} else {
				return PERIODICAL_ADR_CERTIFICATION;
			}
		} else {
			if (docType.equals("INITIAL")) {
				return INITICAL_CERTIFICATION;
			} else {
				return PERIODICAL_CERTIFICATION;
			}
		}

	}

	protected <T> T opt(Supplier<T> statement) {
		try {
			return statement.get();
		} catch (NullPointerException exc) {
			return null;
		}
	}

	private static String buildResultString(Set<String> strings) {
		StringBuilder builder = new StringBuilder();
		List<String> inspectionTypesList = new ArrayList<>(strings);
		Collections.sort(inspectionTypesList);
		builder.append(String.join(", ", strings));

		return builder.toString();
	}

}
