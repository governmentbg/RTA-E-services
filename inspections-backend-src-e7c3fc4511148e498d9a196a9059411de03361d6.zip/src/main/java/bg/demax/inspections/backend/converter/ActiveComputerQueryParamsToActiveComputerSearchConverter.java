package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.controller.param.ActiveComputerQueryParams;
import bg.demax.inspections.backend.search.ActiveComputerSearch;
import bg.demax.legacy.util.convert.Converter;

@Component
public class ActiveComputerQueryParamsToActiveComputerSearchConverter
				implements Converter<ActiveComputerQueryParams, ActiveComputerSearch> {

	@Override
	public ActiveComputerSearch convert(ActiveComputerQueryParams params) {
		ActiveComputerSearch search = new ActiveComputerSearch();
		if (params.getOrgUnitCode() != null) {
			search.setOrgUnitCode(params.getOrgUnitCode().trim());
		}
		search.setPermitNumber(params.getPermitNumber());
		return search;
	}
}
