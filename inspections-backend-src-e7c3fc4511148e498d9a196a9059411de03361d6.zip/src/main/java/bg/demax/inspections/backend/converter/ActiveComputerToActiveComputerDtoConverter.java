package bg.demax.inspections.backend.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.ActiveComputerDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineDto;
import bg.demax.inspections.backend.entity.ActiveComputer;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.Device;
import bg.demax.techinsp.entity.PermitLine;

@Component
public class ActiveComputerToActiveComputerDtoConverter implements Converter<ActiveComputer, ActiveComputerDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public ActiveComputerDto convert(ActiveComputer activeComputer) {
		Device device = activeComputer.getDevice();
		ActiveComputerDto dto = new ActiveComputerDto();
		dto.setId(activeComputer.getId());
		// TODO: after the apache config is fixed on the inspection PCs use the ip of the active computer
		// dto.setServiceMenuUrl("https://" + activeComputer.getIpAddress() + "/inspections-station-config-web");
		dto.setServiceMenuUrl("https://localhost:8443/inspections-station-config-web");
		dto.setLastActiveAt(activeComputer.getLastActiveAt());
		dto.setIpAddress(activeComputer.getIpAddress());

		PermitLine devicePermitLine = null;
		if (device != null && device.getPermitLineHardware() != null && device.getPermitLineHardware().getPermitLine() != null
						&& device.getPermitLineHardware().getPermitLine().getPermit() != null) {
			devicePermitLine = device.getPermitLineHardware().getPermitLine();
		}

		if (devicePermitLine != null) {
			dto.setPermitLine(conversionService.convert(devicePermitLine, PermitLineDto.class));
		}
		return dto;
	}
}
