package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.ApplicationExceptionDto;
import bg.demax.inspections.backend.exception.ApplicationException;
import bg.demax.legacy.util.convert.Converter;

@Component
public class ApplicationExceptionToApplicationExceptionDtoConverter implements Converter<ApplicationException, ApplicationExceptionDto> {

	@Override
	public ApplicationExceptionDto convert(ApplicationException ex) {
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError(ex.getError());
		String message = ex.getMessage();
		dto.setMessage(message);
		return dto;
	}
}
