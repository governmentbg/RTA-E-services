package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.AppliedDocumentTypeDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.AppliedDocumentType;

@Component
public class AppliedDocumentTypeToAppliedDocumentTypeDtoConverter implements Converter<AppliedDocumentType, AppliedDocumentTypeDto> {

	@Override
	public AppliedDocumentTypeDto convert(AppliedDocumentType from) {
		AppliedDocumentTypeDto dto = new AppliedDocumentTypeDto();
		dto.setCode(from.getCode());
		dto.setDescription(from.getDescription());
		dto.setHasValidFromDate(from.getHasValidFromDate());
		dto.setHasValidToDate(from.getHasValidToDate());
		dto.setHasIssueDate(from.getHasIssueDate());
		dto.setHasBrandModel(from.getHasBrandModel());
		dto.setIsOptional(from.isOptional());
		dto.setValidityLength(from.getValidityLength());
		return dto;
	}

}
