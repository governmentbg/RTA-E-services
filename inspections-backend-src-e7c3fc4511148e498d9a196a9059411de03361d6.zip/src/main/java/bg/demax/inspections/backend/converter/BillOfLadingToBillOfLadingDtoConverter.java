package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.BillOfLadingDto;
import bg.demax.inspections.backend.entity.BillOfLading;
import bg.demax.legacy.util.convert.Converter;

@Component
public class BillOfLadingToBillOfLadingDtoConverter
				implements Converter<BillOfLading, BillOfLadingDto> {
	
	@Override
	public BillOfLadingDto convert(BillOfLading billOfLading) {
		BillOfLadingDto dto = new BillOfLadingDto();
		convert(billOfLading, dto);

		return dto;
	}
	
	public void convert(BillOfLading billOfLading, BillOfLadingDto dto) {
		dto.setId(billOfLading.getId());

		dto.setBillOfLadingIdForCourier(billOfLading.getBillOfLadingIdForCourier());
		dto.setCourierCode(billOfLading.getCourier() != null ? billOfLading.getCourier().getCode() : null);
		dto.setCourierServiceTypeCode(billOfLading.getCourierServiceType() != null ? billOfLading.getCourierServiceType().getCode() : null);
		dto.setCreatedAt(billOfLading.getCreatedAt());
		dto.setStatusCode(billOfLading.getStatus() != null ? billOfLading.getStatus().getCode() : null);
		dto.setFixedTimeDelivery(billOfLading.getDeliveryTime());
	}
}
