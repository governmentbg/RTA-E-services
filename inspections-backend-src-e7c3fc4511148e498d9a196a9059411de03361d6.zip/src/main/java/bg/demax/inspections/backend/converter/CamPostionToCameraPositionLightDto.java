package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CameraPositionLightDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.CamPosition;

@Component
public class CamPostionToCameraPositionLightDto implements Converter<CamPosition, CameraPositionLightDto> {

	@Override
	public CameraPositionLightDto convert(CamPosition from) {
		CameraPositionLightDto dto = new CameraPositionLightDto();

		dto.setId(from.getId());
		dto.setCamIndex(from.getCamIndex());
		dto.setIsInPlace(from.getIsInPlace());
		dto.setLastUpdate(from.getLastUpdate());
		return dto;
	}

}
