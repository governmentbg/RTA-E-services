package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CityDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.City;

@Component
public class CityToCityDtoConverter implements Converter<City, CityDto> {

	@Override
	public CityDto convert(City city) {
		CityDto dto = new CityDto();
		dto.setCode(city.getCode());
		dto.setName(city.getName());
		return dto;
	}
}
