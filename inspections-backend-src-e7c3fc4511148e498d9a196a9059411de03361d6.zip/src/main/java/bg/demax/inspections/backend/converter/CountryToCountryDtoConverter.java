package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CountryDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.Country;

@Component
public class CountryToCountryDtoConverter implements Converter<Country, CountryDto> {

	@Override
	public CountryDto convert(Country country) {
		CountryDto dto = new CountryDto();
		dto.setCode(country.getCode());
		dto.setName(country.getName());
		return dto;
	}
}
