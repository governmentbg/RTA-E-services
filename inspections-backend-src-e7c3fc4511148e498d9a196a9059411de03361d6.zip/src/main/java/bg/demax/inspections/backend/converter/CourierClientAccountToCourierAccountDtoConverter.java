package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.courier.services.dto.AccountDto;
import bg.demax.inspections.backend.entity.CourierClientAccount;
import bg.demax.legacy.util.convert.Converter;

@Component
public class CourierClientAccountToCourierAccountDtoConverter implements Converter<CourierClientAccount, AccountDto> {

	@Override
	public AccountDto convert(CourierClientAccount courierClientAccount) {
		AccountDto dto = new AccountDto();
		dto.setUsername(courierClientAccount.getId().getUsername());
		dto.setPassword(courierClientAccount.getPassword());
		return dto;
	}

}
