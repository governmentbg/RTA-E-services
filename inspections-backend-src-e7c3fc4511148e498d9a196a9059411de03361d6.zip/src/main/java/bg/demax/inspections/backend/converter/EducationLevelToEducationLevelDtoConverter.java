package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.inspections.EducationLevelDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.EducationLevel;

@Component
public class EducationLevelToEducationLevelDtoConverter implements Converter<EducationLevel, EducationLevelDto> {

	@Override
	public EducationLevelDto convert(EducationLevel from) {
		EducationLevelDto newEducationLevelDto = new EducationLevelDto();
		newEducationLevelDto.setCode(from.getCode());
		newEducationLevelDto.setDescription(from.getDescription());
		newEducationLevelDto.setIsValid(from.getIsValid());
		
		return newEducationLevelDto;
	}

}
