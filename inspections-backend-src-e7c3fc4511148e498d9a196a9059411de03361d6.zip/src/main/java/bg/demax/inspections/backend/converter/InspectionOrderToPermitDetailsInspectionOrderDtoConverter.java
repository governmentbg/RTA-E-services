package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitDetailsInspectionOrderDto;
import bg.demax.inspections.backend.entity.inspection.InspectionOrder;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionOrderToPermitDetailsInspectionOrderDtoConverter
				implements Converter<InspectionOrder, PermitDetailsInspectionOrderDto> {
	@Override
	public PermitDetailsInspectionOrderDto convert(InspectionOrder from) {
		PermitDetailsInspectionOrderDto dto = new PermitDetailsInspectionOrderDto();

		dto.setId(from.getId());
		if (from.getOrderDatetime() != null) {
			dto.setOrderDatetime(from.getOrderDatetime().toLocalDate());
		}
		if (from.getActivationDatetime() != null) {
			dto.setActivationDatetime(from.getActivationDatetime().toLocalDate());
		}
		dto.setInvoiceNumber(from.getInvoiceNum());
		if (from.getInvoiceDate() != null) {
			dto.setInvoiceDate(from.getInvoiceDate().toLocalDate());
		}
		if (from.getOrderStatus() != null) {
			dto.setStatus(from.getOrderStatus().getCode());
		}

		return dto;
	}

}
