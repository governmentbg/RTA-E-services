package bg.demax.inspections.backend.converter;

import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineInspectionTypeDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.InspectionType;

@Component
public class InspectionTypeToPermitLineInspectionTypeDtoConverter implements Converter<InspectionType, PermitLineInspectionTypeDto> {

	@Override
	public PermitLineInspectionTypeDto convert(InspectionType from) {
		PermitLineInspectionTypeDto dto = new PermitLineInspectionTypeDto();
		dto.setInspectionTypeCode(from.getCode());
		dto.setCategoryCodes(
			from.getVehicleCategories().stream()
				.map(vc -> vc.getCode())
				.collect(Collectors.toList())
		);
		
		return dto;
	}

}
