package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.InspectorSpecialityDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.InspectorSpecialty;

@Component
public class InspectorSpecialityToInspectorSpecialityDtoConverter implements Converter<InspectorSpecialty, InspectorSpecialityDto> {

	@Override
	public InspectorSpecialityDto convert(InspectorSpecialty from) {
		InspectorSpecialityDto dto = new InspectorSpecialityDto(from.getCode());
		return dto;
	}

}
