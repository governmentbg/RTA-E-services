package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.KtpCategoryDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.KtpCategory;

@Component
public class KtpCategoryToKtpCategoryDtoConverter implements Converter<KtpCategory, KtpCategoryDto> {

	@Override
	public KtpCategoryDto convert(KtpCategory from) {
		KtpCategoryDto dto = new KtpCategoryDto();
		dto.setCode(from.getCode());
		dto.setLabel(from.getLabel());
		
		return dto;
	}

}
