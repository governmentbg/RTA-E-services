package bg.demax.inspections.backend.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.OrgUnitInspectionOrdersLightDto;
import bg.demax.inspections.backend.dto.OrgUnitInspectionOrdersVo;
import bg.demax.inspections.backend.dto.OrgUnitLightDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;

@Component
public class OrgUnitInspectionOrdersVoToDto implements Converter<OrgUnitInspectionOrdersVo, OrgUnitInspectionOrdersLightDto>  {

	@Autowired
	private ConversionService conversionService;
	
	@Override
	public OrgUnitInspectionOrdersLightDto convert(OrgUnitInspectionOrdersVo from) {
		
		OrgUnitInspectionOrdersLightDto dto = new OrgUnitInspectionOrdersLightDto();
		dto.setOrgUnit(conversionService.convert(from.getOrgUnit(), OrgUnitLightDto.class));
		dto.setPaidInspectionOrdersCount(from.getPaidInspectionOrdersCount());
		dto.setLabelInspectionOrdersCount(from.getLabelInspectionOrdersCount());
		
		return dto;
	}
}
