package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.OrgUnitDto;
import bg.demax.inspections.backend.util.CourierServiceUtils;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.OrgUnit;

@Component
public class OrgUnitToOrgUnitDtoConverter implements Converter<OrgUnit, OrgUnitDto> {

	@Override
	public OrgUnitDto convert(OrgUnit orgUnit) {
		OrgUnitDto dto = new OrgUnitDto();
		dto.setCode(orgUnit.getCode());
		dto.setName(orgUnit.getShortName());
		dto.setCityName(CourierServiceUtils.getCityNameWithoutPrefix(orgUnit.getCity()));
		dto.setCityType(orgUnit.getCity().getType().getValue().replaceAll("\\.", ""));
		dto.setCityRegion(orgUnit.getCity().getRegion().getName());
		dto.setAddress(orgUnit.getAddress());
		dto.setPhoneNumber(orgUnit.getPhoneNumber());
		return dto;
	}

}
