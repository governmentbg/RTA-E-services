package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.OrgUnitLightDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.OrgUnit;

@Component
public class OrgUnitToOrgUnitLightDtoConverter implements Converter<OrgUnit, OrgUnitLightDto> {

	@Override
	public OrgUnitLightDto convert(OrgUnit orgUnit) {
		OrgUnitLightDto dto = new OrgUnitLightDto();
		OrgUnitToOrgUnitLightDtoConverter.convert(orgUnit, dto);
		return dto;
	}
	
	public static OrgUnitLightDto convert(OrgUnit orgUnit, OrgUnitLightDto dto) {
		dto.setCode(orgUnit.getCode());
		dto.setName(orgUnit.getShortName());
		return dto;
	}
}
