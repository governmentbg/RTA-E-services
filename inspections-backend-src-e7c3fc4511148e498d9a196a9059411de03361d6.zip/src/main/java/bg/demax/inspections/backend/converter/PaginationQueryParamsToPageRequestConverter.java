package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.controller.param.PaginationQueryParams;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PaginationQueryParamsToPageRequestConverter implements Converter<PaginationQueryParams, PageRequest> {

	@Override
	public PageRequest convert(PaginationQueryParams params) {
		PageRequest pageRequest = new PageRequest();
		pageRequest.setPage(params.getPage());
		pageRequest.setPageSize(params.getPageSize());
		return pageRequest;
	}
}