package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.LogsReportListItemDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.PermitsLinesInspectorsLog;

@Component
public class PermitsLinesInspectorsLogToLogsReportListItemDtoConverter
				implements Converter<PermitsLinesInspectorsLog, LogsReportListItemDto> {

	@Override
	public LogsReportListItemDto convert(PermitsLinesInspectorsLog from) {
		LogsReportListItemDto dto = new LogsReportListItemDto();
		dto.setDate(from.getLogDate());
		dto.setMessage(from.getLogMessage());
		return dto;
	}

}
