package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.RegionDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.Region;

@Component
public class RegionToRegionDto implements Converter<Region, RegionDto> {

	@Override
	public RegionDto convert(Region from) {
		RegionDto dto = new RegionDto();
		dto.setCode(from.getCode());
		dto.setName(from.getName());
		
		return dto;
	}

}
