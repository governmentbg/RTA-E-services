package bg.demax.inspections.backend.converter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.StickersReportListItemDto;
import bg.demax.inspections.backend.entity.inspection.InspectionOrder;
import bg.demax.inspections.backend.entity.inspection.InspectionOrderItem;
import bg.demax.inspections.backend.entity.inspection.InspectionOrderItemProduct;
import bg.demax.inspections.backend.vo.StickerVo;
import bg.demax.legacy.util.convert.Converter;

@Component
public class StickerVoToStickersReportListItemDtoConverter implements Converter<StickerVo, StickersReportListItemDto> {

	@Override
	public StickersReportListItemDto convert(StickerVo from) {
		InspectionOrder order = from.getInspectionOrder();
		List<InspectionOrderItemProduct> stickers = from.getStickers();
		InspectionOrderItem inspectionOrderItem = stickers.get(0).getOrderItem();

		Long currentOiId = inspectionOrderItem.getId();
		Long fromNumber = inspectionOrderItem.getFromNum();
		Long toNumber = inspectionOrderItem.getToNum();

		StickersReportListItemDto dto = new StickersReportListItemDto();
		dto.setOrderNumber(order.getId());
		dto.setPermitNumber(order.getPermitLine().getPermit().getPermitNumber());
		dto.setOrgUnit(order.getPermitLine().getPermit().getOrgUnit().getShortName());
		dto.setCompanyName(order.getSubjectVersion().getFullNameIfMissingCyr());
		dto.setActivationDate(order.getActivationDatetime());

		List<Long> activatedNumbers = new ArrayList<Long>();
		List<Long> usedNumbers = new ArrayList<Long>();
		List<Long> scrappedNumbers = new ArrayList<Long>();

		for (InspectionOrderItemProduct sticker : stickers) {
			InspectionOrderItem currentInspectionOrderItem = sticker.getOrderItem();
			if (!currentOiId.equals(currentInspectionOrderItem.getId())) {
				if (toNumber.compareTo(currentInspectionOrderItem.getToNum()) < 0) {
					toNumber = currentInspectionOrderItem.getToNum();
				}
			}
			if (InspectionOrderItemProduct.STATE_CODE_ACTIVATED.equals(sticker.getDocumentState())) {
				activatedNumbers.add(sticker.getDocumentNumber());
			} else if (InspectionOrderItemProduct.STATE_CODE_USED.equals(sticker.getDocumentState())) {
				usedNumbers.add(sticker.getDocumentNumber());
			} else {
				scrappedNumbers.add(sticker.getDocumentNumber());
			}
		}

		dto.setFromNumber(fromNumber);
		dto.setToNumber(toNumber);
		dto.setQuantity(toNumber - fromNumber + 1);

		dto.setActivatedIntervals(getIntervals(activatedNumbers));
		dto.setUsedIntervals(getIntervals(usedNumbers));
		dto.setScrappedIntervals(getIntervals(scrappedNumbers));

		dto.setActivatedIntervalsCount(activatedNumbers.size());
		dto.setUsedIntervalsCount(usedNumbers.size());
		dto.setScrappedIntervalsCount(scrappedNumbers.size());

		return dto;
	}

	private String getIntervals(List<Long> numbers) {
		Collections.sort(numbers);

		// Results in 3005 - 3010, 3051, 4056, 4100 - 4112
		StringBuilder builder = new StringBuilder();
		int length = numbers.size();
		int i = 0;
		while (i < length) {
			long low = numbers.get(i);
			while (i < length - 1 && numbers.get(i) + 1 == numbers.get(i + 1)) {
				i += 1;
			}
			long high = numbers.get(i);
			if (high - low >= 1) {
				builder.append(String.format("%d - %d", low, high));
			} else if (high - low == 1) {
				builder.append(low);
				builder.append(", ");
				builder.append(high);
			} else {
				builder.append(low);
			}

			if (length != i + 1) {
				builder.append(", ");
			}

			i += 1;
		}
		return builder.toString().isEmpty() ? null : builder.toString();
	}

}
