package bg.demax.inspections.backend.converter;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.SubjectCardsReportListItemDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitOrgUnitDto;
import bg.demax.inspections.backend.entity.permit.PermitVersion;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectCard;
import bg.demax.inspections.backend.vo.SubjectCardWithPermitVersionsVo;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.SubjectVersion;
import bg.demax.specialist.registry.common.dto.user.SubjectLightDto;

@Component
public class SubjectCardWithPermitVersionsVoToSubjectCardsReportListItemDtoConverter
				implements Converter<SubjectCardWithPermitVersionsVo, SubjectCardsReportListItemDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public SubjectCardsReportListItemDto convert(SubjectCardWithPermitVersionsVo from) {
		SubjectCardsReportListItemDto dto = new SubjectCardsReportListItemDto();
		SubjectCard card = from.getSubjectCard();
		List<PermitVersion> permitVersions = from.getPermitVersions();

		dto.setCardNumber(card.getCardNumber());
		dto.setSerialNumber(card.getSerialNumber());

		SubjectLightDto subject = new SubjectLightDto();
		subject.setId(card.getSubject().getId());
		subject.setFullName(card.getSubject().getCurrentVersion().getFullName());
		subject.setIdentityNumber(card.getSubject().getIdentityNumber());
		dto.setSubject(subject);

		dto.setIsActive(card.getIsActive());

		if (permitVersions.size() > 0) {
			SubjectVersion company = permitVersions.get(0).getSubjectVersion();
			SubjectLightDto companyDto = new SubjectLightDto();
			companyDto.setId(company.getSubject().getId());
			companyDto.setFullName(company.getFullName());
			companyDto.setIdentityNumber(company.getSubject().getIdentityNumber());
			dto.setCompany(companyDto);
		}
		dto.setPermits(conversionService.convertList(permitVersions, PermitOrgUnitDto.class));

		return dto;
	}

}
