package bg.demax.inspections.backend.converter;

import java.util.List;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.entity.permit.PermitVersion;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectCard;
import bg.demax.inspections.backend.export.report.SubjectCardsReportRow;
import bg.demax.inspections.backend.vo.SubjectCardWithPermitVersionsVo;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.SubjectVersion;

@Component
public class SubjectCardWithPermitVersionsVoToSubjectCardsReportRowConverter
				implements Converter<SubjectCardWithPermitVersionsVo, SubjectCardsReportRow> {

	@Override
	public SubjectCardsReportRow convert(SubjectCardWithPermitVersionsVo from) {
		SubjectCardsReportRow dto = new SubjectCardsReportRow();
		SubjectCard card = from.getSubjectCard();
		List<PermitVersion> permitVersions = from.getPermitVersions();

		dto.setCardNumber(String.valueOf(card.getCardNumber()));
		dto.setSerialNumber(card.getSerialNumber());
		dto.setStatus(card.getIsActive() ? "активирана" : "деактивирана");
		dto.setSubjectName(card.getSubject().getCurrentVersion().getFullName());
		dto.setSubjectIdentityNumber(card.getSubject().getIdentityNumber());

		if (permitVersions.size() > 0) {
			SubjectVersion company = permitVersions.get(0).getSubjectVersion();
			dto.setCompanyIdentityNumberAndName(String.format("%s / %s", company.getSubject().getIdentityNumber(), company.getFullName()));
			StringBuilder builder = new StringBuilder();
			for (int i = 0; i < permitVersions.size(); i++) {
				Integer permitNumber = permitVersions.get(i).getPermitInfo().getPermitNumber();
				String orgUnit = permitVersions.get(i).getPermitInfo().getOrgUnit().getShortName();
				builder.append(String.format("%s - %s", permitNumber, orgUnit));
				if (i != permitVersions.size() - 1) {
					builder.append("\n");
				}
			}
			dto.setPermitsNumberAndOrgUnit(builder.toString());
		}
		return dto;
	}

}
