package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CompanySubjectLightDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.Subject;
import bg.demax.pub.entity.SubjectVersion;

@Component
public class SubjectToCompanySubjectLightDtoConverter implements Converter<Subject, CompanySubjectLightDto> {

	@Override
	public CompanySubjectLightDto convert(Subject subject) {
		CompanySubjectLightDto dto = new CompanySubjectLightDto();
		dto.setId(subject.getId());
		dto.setEik(subject.getIdentityNumber());
		SubjectVersion currentVersion = subject.getCurrentVersion();
		if (currentVersion != null) {
			dto.setName(currentVersion.getFullName());
		}
		return dto;
	}
}