package bg.demax.inspections.backend.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CityDto;
import bg.demax.inspections.backend.dto.CountryDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitCompanyDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.Subject;
import bg.demax.pub.entity.SubjectVersion;
import bg.demax.pub.entity.enums.SubjectVatRegistration;

@Component
public class SubjectToPermitCompanyDtoConverter implements Converter<Subject, PermitCompanyDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public PermitCompanyDto convert(Subject from) {
		SubjectVersion currentVersion = from.getCurrentVersion();
		PermitCompanyDto dto = new PermitCompanyDto();
		dto.setAddress(currentVersion.getBaseAddress());
		if (currentVersion.getCity() != null) {
			dto.setCity(conversionService.convert(currentVersion.getCity(), CityDto.class));
			if (currentVersion.getCity().getRegion() != null) {
				dto.setRegionCode(currentVersion.getCity().getRegion().getCode());
			}
		}
		dto.setCountry(conversionService.convert(from.getCountry(), CountryDto.class));
		dto.setEik(from.getIdentityNumber());
		if (currentVersion.getVatRegistration() != null && currentVersion.getVatRegistration() != SubjectVatRegistration.UNKNOWN) {
			if (currentVersion.getVatRegistration() == SubjectVatRegistration.YES) {
				dto.setHasVatRegistration(true);
			} else if (currentVersion.getVatRegistration() == SubjectVatRegistration.NO) {
				dto.setHasVatRegistration(false);
			}
		} else {
			dto.setHasVatRegistration(null);
		}
		dto.setManagerEgn(currentVersion.getManagerIdentityNumber());
		dto.setManagerName(currentVersion.getManagerName());
		dto.setName(currentVersion.getFullName());
		dto.setPhoneNumber(currentVersion.getPhoneNumber());
		dto.setEmail(currentVersion.getEmail());
		return dto;
	}
}
