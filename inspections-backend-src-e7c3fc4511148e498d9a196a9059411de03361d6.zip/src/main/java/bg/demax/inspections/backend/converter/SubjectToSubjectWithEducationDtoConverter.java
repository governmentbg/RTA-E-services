package bg.demax.inspections.backend.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.inspections.EducationLevelDto;
import bg.demax.inspections.backend.dto.inspections.SubjectWithEducationDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.Subject;

@Component
public class SubjectToSubjectWithEducationDtoConverter implements Converter<Subject, SubjectWithEducationDto> {
	
	@Autowired
	private ConversionService conversionService;

	@Override
	public SubjectWithEducationDto convert(Subject source) {
		SubjectWithEducationDto dto = new SubjectWithEducationDto();
		dto.setId(source.getId());
		dto.setIdentityNumber(source.getIdentityNumber());
		dto.setFullName(source.getCurrentVersion().getFullNameIfMissingCyr());
		if (source.getCurrentVersion().getEducationLevel() != null) {
			dto.setEducationLevel(conversionService.convert(source.getCurrentVersion().getEducationLevel(), EducationLevelDto.class));
		}
		dto.setSubjectVersionId(source.getCurrentVersion().getId());
		return dto;
	}
}
