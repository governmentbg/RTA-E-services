package bg.demax.inspections.backend.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CityDto;
import bg.demax.inspections.backend.dto.CountryDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitCompanyDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.Subject;
import bg.demax.pub.entity.SubjectVersion;
import bg.demax.pub.entity.enums.SubjectVatRegistration;

@Component
public class SubjectVersionToPermitCompanyDtoConverter implements Converter<SubjectVersion, PermitCompanyDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public PermitCompanyDto convert(SubjectVersion from) {
		Subject subject = from.getSubject();
		PermitCompanyDto dto = new PermitCompanyDto();
		dto.setAddress(from.getBaseAddress());
		if (from.getCity() != null) {
			dto.setCity(conversionService.convert(from.getCity(), CityDto.class));
			if (from.getCity().getRegion() != null) {
				dto.setRegionCode(from.getCity().getRegion().getCode());
			}
		}
		
		dto.setCountry(conversionService.convert(subject.getCountry(), CountryDto.class));
		dto.setEik(subject.getIdentityNumber());
		if (from.getVatRegistration() != null && from.getVatRegistration() != SubjectVatRegistration.UNKNOWN) {
			if (from.getVatRegistration() == SubjectVatRegistration.YES) {
				dto.setHasVatRegistration(true);
			} else if (from.getVatRegistration() == SubjectVatRegistration.NO) {
				dto.setHasVatRegistration(false);
			}
		} else {
			dto.setHasVatRegistration(null);
		}
		dto.setManagerEgn(from.getManagerIdentityNumber());
		dto.setManagerName(from.getManagerName());
		dto.setName(from.getFullName());
		dto.setPhoneNumber(from.getPhoneNumber());
		dto.setEmail(from.getEmail());
		return dto;
	}
}
