package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitCompanyVersionDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.SubjectVersion;
import bg.demax.pub.entity.enums.SubjectVatRegistration;

@Component
public class SubjectVersionToPermitCompanyVersionDtoConverter implements Converter<SubjectVersion, PermitCompanyVersionDto> {

	@Override
	public PermitCompanyVersionDto convert(SubjectVersion from) {
		PermitCompanyVersionDto dto = new PermitCompanyVersionDto();
		dto.setAddress(from.getBaseAddress());
		dto.setCompanyName(from.getFullName());
		if (from.getVatRegistration() != null && from.getVatRegistration() != SubjectVatRegistration.UNKNOWN) {
			if (from.getVatRegistration() == SubjectVatRegistration.YES) {
				dto.setHasVatRegistration(true);
			} else if (from.getVatRegistration() == SubjectVatRegistration.NO) {
				dto.setHasVatRegistration(false);
			}
		} else {
			dto.setHasVatRegistration(null);
		}
		dto.setManagerName(from.getManagerName());
		dto.setManagerIdentityNumber(from.getManagerIdentityNumber());
		if (from.getCity() != null) {
			dto.setCity(from.getCity().getName());
			if (from.getCity().getMunicipality() != null) {
				dto.setMunicipality(from.getCity().getMunicipality().getName());
			}
		}
		dto.setPhoneNumber(from.getPhoneNumber());
		if (from.getEmail() != null) {
			dto.setEmail(from.getEmail());
		}
		if (from.getVersionDate() != null) {
			dto.setVersionDate(from.getVersionDate().toLocalDate());
		}
		
		return dto;
	}

}
