package bg.demax.inspections.backend.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CityDto;
import bg.demax.inspections.backend.dto.OrgUnitLightDto;
import bg.demax.inspections.backend.dto.TechinspPermitAdditionalInfoDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.City;
import bg.demax.techinsp.entity.PermitAdditionalInfo;

@Component
public class TechinspPermitAdditionalInfoToPermitAdditionalInfoDtoConverter 
	implements Converter<PermitAdditionalInfo, TechinspPermitAdditionalInfoDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public TechinspPermitAdditionalInfoDto convert(PermitAdditionalInfo info) {
		TechinspPermitAdditionalInfoDto dto = new TechinspPermitAdditionalInfoDto();
		dto.setContactPersonName(info.getContactPersonName());
		dto.setContactPersonPhone(info.getContactPersonPhone());
		dto.setContactPersonStationaryPhone(info.getContactPersonStationaryPhone());
		dto.setContactPersonEmail(info.getContactPersonEmail());
		dto.setSigningPersonName(info.getSigningPersonName());
		dto.setSigningPersonEgn(info.getSigningPersonEgn());
		dto.setSigningPersonPhone(info.getSigningPersonPhone());
		dto.setSigningPersonStationaryPhone(info.getSigningPersonStationaryPhone());
		dto.setSigningPersonEmail(info.getSigningPersonEmail());
		dto.setGpsE(info.getGpsE());
		dto.setGpsN(info.getGpsN());
		if (info.getKtpRealAddress() != null) {
			dto.setKtpAddress(info.getKtpRealAddress());
		} else {
			dto.setKtpAddress(info.getPermit().getKtpAddress());
		}
		dto.setPermitNumber(info.getPermit().getPermitNumber());
		dto.setPermitOrgUnit(conversionService.convert(info.getPermit().getOrgUnit(), OrgUnitLightDto.class));
		City city = info.getPermit().getKtpCity();
		if (city != null) {
			dto.setKtpCity(conversionService.convert(info.getPermit().getKtpCity(), CityDto.class));
			if (city.getRegion() != null) {
				dto.setRegion(city.getRegion().getName());
			}
		}
		dto.setUmtsCellFrequency(info.getUmtsCellFrequency());
		dto.setUmtsSpeed(info.getUmtsSpeed());
		return dto;
	}
}