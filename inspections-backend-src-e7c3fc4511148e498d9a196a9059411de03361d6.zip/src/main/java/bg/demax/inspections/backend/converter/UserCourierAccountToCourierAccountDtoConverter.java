package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.courier.services.dto.AccountDto;
import bg.demax.inspections.backend.entity.UserCourierAccount;
import bg.demax.legacy.util.convert.Converter;

@Component
public class UserCourierAccountToCourierAccountDtoConverter implements Converter<UserCourierAccount, AccountDto> {

	@Override
	public AccountDto convert(UserCourierAccount from) {
		AccountDto dto = new AccountDto();
		dto.setUsername(from.getCourierClientAccount().getId().getUsername());
		dto.setPassword(from.getCourierClientAccount().getPassword());
		return dto;
	}

}
