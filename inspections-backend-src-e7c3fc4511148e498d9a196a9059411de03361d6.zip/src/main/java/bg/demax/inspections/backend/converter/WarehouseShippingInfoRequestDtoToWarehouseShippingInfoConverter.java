package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.WarehouseShippingInfoRequestDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.Warehouse;
import bg.demax.pub.entity.hardware.WarehouseShippingInfo;

@Component
public class WarehouseShippingInfoRequestDtoToWarehouseShippingInfoConverter
				implements Converter<WarehouseShippingInfoRequestDto, WarehouseShippingInfo> {

	@Override
	public WarehouseShippingInfo convert(WarehouseShippingInfoRequestDto from) {
		WarehouseShippingInfo info = new WarehouseShippingInfo();
		info.setAddress(from.getAddress());
		info.setRecipientPersonName(from.getRecipientPersonName());
		info.setRecipientPersonPhone(from.getRecipientPersonPhone());

		Warehouse warehouse = new Warehouse();
		warehouse.setId(from.getWarehouseId());
		info.setWarehouse(warehouse);
		return info;
	}
}
