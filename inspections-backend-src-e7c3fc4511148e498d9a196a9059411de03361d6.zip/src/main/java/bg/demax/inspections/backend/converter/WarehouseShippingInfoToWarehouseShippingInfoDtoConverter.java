package bg.demax.inspections.backend.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CityDto;
import bg.demax.inspections.backend.dto.WarehouseDto;
import bg.demax.inspections.backend.dto.WarehouseShippingInfoDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.Warehouse;
import bg.demax.pub.entity.hardware.WarehouseShippingInfo;

@Component
public class WarehouseShippingInfoToWarehouseShippingInfoDtoConverter
				implements Converter<WarehouseShippingInfo, WarehouseShippingInfoDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public WarehouseShippingInfoDto convert(WarehouseShippingInfo info) {
		Warehouse warehouse = info.getWarehouse();

		WarehouseShippingInfoDto dto = new WarehouseShippingInfoDto();
		dto.setWarehouse(conversionService.convert(warehouse, WarehouseDto.class));
		dto.setCity(conversionService.convert(warehouse.getCity(), CityDto.class));

		dto.setAddress(info.getAddress());
		dto.setRecipientPersonName(info.getRecipientPersonName());
		dto.setRecipientPersonPhone(info.getRecipientPersonPhone());
		dto.setSpeedyOfficeAddress(info.getSpeedyOfficeAddress());
		return dto;
	}
}
