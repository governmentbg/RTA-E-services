package bg.demax.inspections.backend.converter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.WarehouseDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.Warehouse;

@Component
public class WarehouseToWarehouseDtoConverter implements Converter<Warehouse, WarehouseDto> {

	@Override
	public WarehouseDto convert(Warehouse from) {
		WarehouseDto dto = new WarehouseDto();
		dto.setId(from.getId());
		dto.setName(from.getName());
		return dto;
	}
}
