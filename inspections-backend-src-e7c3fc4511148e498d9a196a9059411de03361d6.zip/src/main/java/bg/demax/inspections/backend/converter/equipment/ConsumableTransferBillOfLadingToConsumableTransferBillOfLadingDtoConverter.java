package bg.demax.inspections.backend.converter.equipment;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.ConsumableTransferBillOfLadingDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.ConsumableTransferBillOfLading;

@Component
public class ConsumableTransferBillOfLadingToConsumableTransferBillOfLadingDtoConverter
				implements Converter<ConsumableTransferBillOfLading, ConsumableTransferBillOfLadingDto> {
	
	@Override
	public ConsumableTransferBillOfLadingDto convert(ConsumableTransferBillOfLading from) {
		ConsumableTransferBillOfLadingDto dto = new ConsumableTransferBillOfLadingDto();
		
		dto.setId(from.getId());
		dto.setBillOfLadingIdForCourier(from.getBillOfLadingIdForCourier());
		dto.setCourierCode(from.getCourier().getCode());
		if (from.getCourierServiceType() != null) {
			dto.setCourierServiceTypeCode(from.getCourierServiceType().getCode());
		}
		dto.setCreatedAt(from.getCreatedAt());
		dto.setFixedTimeDelivery(from.getDeliveryTime());
		dto.setStatusCode(from.getStatus().getCode());
		
		dto.setPermitNumber(from.getPermit().getPermitNumber());
		dto.setContactPersonName(from.getRecipientPersonName());
		dto.setContactPersonPhoneNumber(from.getRecipientPersonPhone());
		dto.setShippingAddress(from.getRecipientAddress());
		dto.setCartridgesCount(from.getCartridgesCount());
		dto.setDrumsCount(from.getDrumsCount());
		dto.setPackageCount(from.getPackageCount());
		dto.setWeight(from.getWeightKg());
		
		return dto;
	}

}
