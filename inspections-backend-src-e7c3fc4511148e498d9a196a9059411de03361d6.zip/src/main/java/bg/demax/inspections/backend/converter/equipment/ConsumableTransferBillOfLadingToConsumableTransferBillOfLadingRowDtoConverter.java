package bg.demax.inspections.backend.converter.equipment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.ConsumableTransferBillOfLadingRowDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitLightWithCityNameDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.ConsumableTransferBillOfLading;

@Component
public class ConsumableTransferBillOfLadingToConsumableTransferBillOfLadingRowDtoConverter implements
				Converter<ConsumableTransferBillOfLading, ConsumableTransferBillOfLadingRowDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public ConsumableTransferBillOfLadingRowDto convert(ConsumableTransferBillOfLading from) {
		
		ConsumableTransferBillOfLadingRowDto dto = new ConsumableTransferBillOfLadingRowDto();

		dto.setId(from.getId());
		dto.setCourierName(from.getCourier().getCode());
		dto.setBillOfLadingIdForCourier(from.getBillOfLadingIdForCourier());
		dto.setCreatedAt(from.getCreatedAt());
		dto.setPermit(conversionService.convert(from.getPermit(), PermitLightWithCityNameDto.class));
		dto.setCartridgesCount(from.getCartridgesCount());
		dto.setDrumsCount(from.getDrumsCount());
		dto.setStatusCode(from.getStatus().getCode());
		return dto;
	}
}