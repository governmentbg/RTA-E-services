package bg.demax.inspections.backend.converter.equipment;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.ConsumableTransferCreationRequestDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitShippingInfoRequestDto;
import bg.demax.inspections.backend.entity.Courier;
import bg.demax.inspections.backend.entity.CourierServiceType;
import bg.demax.inspections.backend.entity.CourierServiceType.CourierServiceTypes;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.ConsumableTransferBillOfLading;
import bg.demax.techinsp.entity.Permit;

@Component
public class ConsumableTransferCreationRequestDtoToConsumableTransferBillOfLading
				implements Converter<ConsumableTransferCreationRequestDto, ConsumableTransferBillOfLading> {

	@Override
	public ConsumableTransferBillOfLading convert(ConsumableTransferCreationRequestDto from) {
		ConsumableTransferBillOfLading billOfLading = new ConsumableTransferBillOfLading();

		Courier courier = new Courier();
		courier.setCode(from.getCourierCode());
		billOfLading.setCourier(courier);

		CourierServiceType courierServiceType = new CourierServiceType();
		courierServiceType.setCode(from.getCourierServiceTypeCode());
		billOfLading.setCourierServiceType(courierServiceType);

		if (billOfLading.getCourierServiceType().getCode().equals(CourierServiceTypes.EXPRESS.getCode())) {
			billOfLading.setDeliveryTime(from.getFixedTimeDelivery());
		}

		billOfLading.setCartridgesCount(from.getCartridgesCount());
		billOfLading.setDrumsCount(from.getDrumsCount());

		Permit permit = new Permit();
		permit.setId(from.getPermitShippingInfo().getPermitId());
		billOfLading.setPermit(permit);

		billOfLading.setPackageCount(from.getPacketsCount());
		billOfLading.setWeightKg(from.getWeightKg());

		PermitShippingInfoRequestDto permitShippingInfo = from.getPermitShippingInfo();

		billOfLading.setRecipientPersonName(permitShippingInfo.getRecipientPersonName());
		billOfLading.setRecipientAddress(permitShippingInfo.getAddress());
		billOfLading.setRecipientPersonPhone(permitShippingInfo.getRecipientPersonPhone());

		return billOfLading;
	}

}
