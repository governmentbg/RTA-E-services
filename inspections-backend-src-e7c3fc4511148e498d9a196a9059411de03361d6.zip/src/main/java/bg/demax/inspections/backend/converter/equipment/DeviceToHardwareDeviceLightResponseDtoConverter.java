package bg.demax.inspections.backend.converter.equipment;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.StoreDto;
import bg.demax.inspections.backend.dto.WarehouseDto;
import bg.demax.inspections.backend.dto.equipment.DeviceScrapReasonDto;
import bg.demax.inspections.backend.dto.equipment.DeviceStatusDto;
import bg.demax.inspections.backend.dto.equipment.DeviceTypeDto;
import bg.demax.inspections.backend.dto.equipment.HardwareDeviceLightResponseDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDto;
import bg.demax.inspections.backend.util.PermitValidationUtil;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.Device;
import bg.demax.pub.entity.hardware.DeviceStatus;
import bg.demax.pub.entity.hardware.PermitLineHardware;
import bg.demax.pub.entity.hardware.Store;
import bg.demax.techinsp.entity.Permit;
import bg.demax.techinsp.entity.PermitLine;

@Component
public class DeviceToHardwareDeviceLightResponseDtoConverter implements Converter<Device, HardwareDeviceLightResponseDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public HardwareDeviceLightResponseDto convert(Device from) {
		HardwareDeviceLightResponseDto responseDto = new HardwareDeviceLightResponseDto();

		responseDto.setId(from.getId());
		responseDto.setSerialNumber(from.getSerialNumber());

		PermitLineHardware permitLineHardware = from.getPermitLineHardware();
		PermitLine permitLine = null;
		if (permitLineHardware != null) {
			permitLine = permitLineHardware.getPermitLine();
		}
		if (permitLine != null && permitLine.getPermit() != null) {
			Permit permit = permitLine.getPermit();
			if (from.getStore().getCode().equals(Store.INSPECTION_STATION)) {
				responseDto.setPermit(conversionService.convert(permit, PermitDto.class));
			} else if (PermitValidationUtil.isPermitValid(permit)) {
				responseDto.setPermit(conversionService.convert(permit, PermitDto.class));
			}
		}

		if (from.getIpAddress() != null && from.getType().isANetworkDevice()) {
			responseDto.setIpAddress(from.getIpAddress().getValue());
		}

		if (from.getMacAddress() != null) {
			responseDto.setMacAddress(from.getMacAddress().getValue());
		}

		StoreDto store = new StoreDto();
		store.setCode(from.getStore().getCode());
		store.setDescription(from.getStore().getDescription());
		responseDto.setStore(store);

		DeviceTypeDto typeDto = new DeviceTypeDto();
		typeDto.setCode(from.getType().getCode());
		typeDto.setDescription(from.getType().getDescription());
		responseDto.setType(typeDto);

		if (from.getWarehouse() != null) {
			WarehouseDto warehouseDto = new WarehouseDto();
			warehouseDto.setId(from.getWarehouse().getId());
			warehouseDto.setName(from.getWarehouse().getName());
			responseDto.setWarehouse(warehouseDto);
		}

		DeviceStatus status = from.getStatus();
		DeviceStatusDto statusDto = new DeviceStatusDto();
		BeanUtils.copyProperties(status, statusDto);
		responseDto.setStatus(statusDto);

		if (from.getScrapReason() != null) {
			DeviceScrapReasonDto scrapReason = new DeviceScrapReasonDto();
			scrapReason.setId(from.getScrapReason().getId());
			scrapReason.setDescription(from.getScrapReason().getDescription());
			responseDto.setScrapReason(scrapReason);
		}

		return responseDto;
	}

}
