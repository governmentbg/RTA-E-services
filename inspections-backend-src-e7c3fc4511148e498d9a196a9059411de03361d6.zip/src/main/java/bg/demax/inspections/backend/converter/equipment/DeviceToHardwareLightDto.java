package bg.demax.inspections.backend.converter.equipment;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.HardwareLightDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.Device;

@Component
public class DeviceToHardwareLightDto implements Converter<Device, HardwareLightDto> {

	@Override
	public HardwareLightDto convert(Device from) {
		HardwareLightDto dto = new HardwareLightDto();
		dto.setSerialNumber(from.getSerialNumber());
		dto.setDeviceType(from.getType().getDescription());
		return dto;
	}

}
