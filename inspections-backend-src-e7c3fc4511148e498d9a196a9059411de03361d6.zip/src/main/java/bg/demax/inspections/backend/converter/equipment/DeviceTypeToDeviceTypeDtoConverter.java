package bg.demax.inspections.backend.converter.equipment;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.DeviceTypeDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.DeviceType;

@Component
public class DeviceTypeToDeviceTypeDtoConverter implements Converter<DeviceType, DeviceTypeDto> {

	@Override
	public DeviceTypeDto convert(DeviceType from) {
		DeviceTypeDto dto = new DeviceTypeDto();
		dto.setCode(from.getCode());
		dto.setDescription(from.getDescription());
		return dto;
	}
}
