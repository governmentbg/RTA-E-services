package bg.demax.inspections.backend.converter.equipment;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.controller.param.equipment.HardwareDeviceCreationRequestDto;
import bg.demax.inspections.backend.exception.HardwareDeviceCreationException;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.Device;
import bg.demax.pub.entity.hardware.DeviceIpAddress;
import bg.demax.pub.entity.hardware.DeviceMacAddress;
import bg.demax.pub.entity.hardware.DeviceType;
import bg.demax.pub.entity.hardware.Warehouse;

@Component
public class HardwareCreationRequestDtoToDeviceConverter
				implements Converter<HardwareDeviceCreationRequestDto, Device> {
	@Override
	public Device convert(HardwareDeviceCreationRequestDto from) {
		Device device = new Device();

		DeviceType deviceType = new DeviceType();
		deviceType.setCode(from.getDeviceTypeCode());
		
		Warehouse warehouse = new Warehouse();
		warehouse.setId(from.getWarehouseId());

		if (deviceType.isANetworkDevice() && from.getIpAddress() != null
						&& !from.getIpAddress().isEmpty()) {
			DeviceIpAddress ipAddress = new DeviceIpAddress();
			ipAddress.setValue(from.getIpAddress());
			device.setIpAddress(ipAddress);
		}

		if (!deviceType.isANetworkDevice() && from.getIpAddress() != null
						&& !from.getIpAddress().isEmpty()) {
			throw new HardwareDeviceCreationException("Device with type code "
							+ deviceType.getCode() + " can not have ip address.");
		}

		if (from.getMacAddress() != null && !from.getMacAddress().trim().isEmpty()) {
			DeviceMacAddress macAddress = new DeviceMacAddress();
			macAddress.setValue(from.getMacAddress().trim());
			device.setMacAddress(macAddress);
		}
		
		device.setType(deviceType);
		device.setWarehouse(warehouse);
		device.setSerialNumber(from.getSerialNumber());

		return device;
	}

}
