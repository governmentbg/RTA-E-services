package bg.demax.inspections.backend.converter.equipment;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.controller.param.equipment.HardwareDeviceCreationRequestDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.DeviceType;
import bg.demax.pub.entity.hardware.SimCard;
import bg.demax.pub.entity.hardware.Warehouse;

@Component
public class HardwareCreationRequestDtoToSimCardConverter
				implements Converter<HardwareDeviceCreationRequestDto, SimCard> {

	@Override
	public SimCard convert(HardwareDeviceCreationRequestDto from) {
		SimCard simCard = new SimCard();

		DeviceType deviceType = new DeviceType();
		deviceType.setCode(from.getDeviceTypeCode());
		
		Warehouse warehouse = new Warehouse();
		warehouse.setId(from.getWarehouseId());
		
		simCard.setType(deviceType);
		simCard.setWarehouse(warehouse);
		simCard.setIpAddress(from.getIpAddress());
		simCard.setIccId(from.getSerialNumber());
		simCard.setMsisdn(from.getMsisdn());
		simCard.setImsi(from.getImsi());
		return simCard;
	}

}
