package bg.demax.inspections.backend.converter.equipment;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.HardwareDeviceIdentifierDto;
import bg.demax.inspections.backend.vo.HardwareDeviceVo;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.Device;
import bg.demax.pub.entity.hardware.DeviceType;
import bg.demax.pub.entity.hardware.SimCard;

@Component
public class HardwareDeviceIdentifierDtoToHardwareDeviceVoConverter implements Converter<HardwareDeviceIdentifierDto, HardwareDeviceVo> {

	@Override
	public HardwareDeviceVo convert(HardwareDeviceIdentifierDto from) {
		HardwareDeviceVo vo = null;
		if (from.getTypeCode().equals(DeviceType.GLOBUL_SIM_CARD_CODE) || from.getTypeCode().equals(DeviceType.VIVACOM_SIM_CARD_CODE)) {
			SimCard simCard = new SimCard();
			simCard.setId(from.getId());

			DeviceType type = new DeviceType();
			type.setCode(from.getTypeCode());
			simCard.setType(type);

			vo = new HardwareDeviceVo(simCard);
		} else {
			Device device = new Device();
			device.setId(from.getId());
			DeviceType type = new DeviceType();
			type.setCode(from.getTypeCode());
			device.setType(type);

			vo = new HardwareDeviceVo(device);
		}
		return vo;
	}
}