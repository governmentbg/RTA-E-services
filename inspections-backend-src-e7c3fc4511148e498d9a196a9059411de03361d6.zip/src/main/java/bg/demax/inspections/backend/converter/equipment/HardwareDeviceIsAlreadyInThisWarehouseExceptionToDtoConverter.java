package bg.demax.inspections.backend.converter.equipment;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.HardwareDeviceIsAlreadyInThisWarehouseExceptionDto;
import bg.demax.inspections.backend.exception.HardwareDeviceIsAlreadyInThisWarehouseException;
import bg.demax.legacy.util.convert.Converter;

@Component
public class HardwareDeviceIsAlreadyInThisWarehouseExceptionToDtoConverter
				implements Converter<HardwareDeviceIsAlreadyInThisWarehouseException, HardwareDeviceIsAlreadyInThisWarehouseExceptionDto> {

	@Override
	public HardwareDeviceIsAlreadyInThisWarehouseExceptionDto convert(HardwareDeviceIsAlreadyInThisWarehouseException ex) {
		HardwareDeviceIsAlreadyInThisWarehouseExceptionDto dto = new HardwareDeviceIsAlreadyInThisWarehouseExceptionDto();
		dto.setError(ex.getError());
		String message = ex.getMessage();
		dto.setMessage(message);
		dto.setDeviceId(ex.getDeviceId());
		dto.setSimId(ex.getSimId());
		dto.setSerialNumber(ex.getSerialNumber());
		return dto;
	}
}
