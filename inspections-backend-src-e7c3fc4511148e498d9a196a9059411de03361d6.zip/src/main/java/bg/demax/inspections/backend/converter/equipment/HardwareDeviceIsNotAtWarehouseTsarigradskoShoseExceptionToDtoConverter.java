package bg.demax.inspections.backend.converter.equipment;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.HardwareDeviceExceptionDto;
import bg.demax.inspections.backend.exception.HardwareDeviceIsNotAtWarehouseTsarigradskoShoseException;
import bg.demax.legacy.util.convert.Converter;

@Component
public class HardwareDeviceIsNotAtWarehouseTsarigradskoShoseExceptionToDtoConverter
				implements Converter<HardwareDeviceIsNotAtWarehouseTsarigradskoShoseException, HardwareDeviceExceptionDto> {

	@Override
	public HardwareDeviceExceptionDto convert(HardwareDeviceIsNotAtWarehouseTsarigradskoShoseException ex) {
		HardwareDeviceExceptionDto dto = new HardwareDeviceExceptionDto();
		dto.setError(ex.getError());
		String message = ex.getMessage();
		dto.setMessage(message);
		dto.setDeviceId(ex.getDeviceId());
		dto.setSimCardId(ex.getSimCardId());
		dto.setSerialNumber(ex.getSerialNumber());
		return dto;
	}
}
