package bg.demax.inspections.backend.converter.equipment;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.controller.param.equipment.HardwareDeviceQueryParams;
import bg.demax.inspections.backend.search.equipment.HardwareDeviceSearch;
import bg.demax.legacy.util.convert.Converter;

@Component
public class HardwareDeviceQueryParamsToHardwareDeviceSearchConverter
				implements Converter<HardwareDeviceQueryParams, HardwareDeviceSearch> {

	@Override
	public HardwareDeviceSearch convert(HardwareDeviceQueryParams from) {
		HardwareDeviceSearch search = new HardwareDeviceSearch();
		if (from.getSearchText() != null && !from.getSearchText().isEmpty()) {
			search.setSearchText(from.getSearchText().trim());
		}

		if (from.getStatusId() != null) {
			search.setStatus(from.getStatusId());
		}

		if (from.getOrgUnitCode() != null && !from.getOrgUnitCode().isEmpty()) {
			search.setOrgUnitCode(from.getOrgUnitCode());
		}
		
		search.setLocationType(from.getLocationType());
		search.setWarehouseId(from.getWarehouseId());
		search.setTypeCode(from.getTypeCode());
		return search;
	}
}
