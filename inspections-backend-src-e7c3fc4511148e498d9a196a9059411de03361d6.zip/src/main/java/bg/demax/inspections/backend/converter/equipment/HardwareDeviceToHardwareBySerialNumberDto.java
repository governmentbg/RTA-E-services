package bg.demax.inspections.backend.converter.equipment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.DeviceTypeDto;
import bg.demax.inspections.backend.dto.equipment.HardwareBySerialNumberDto;
import bg.demax.inspections.backend.entity.HardwareDevice;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;

@Component
public class HardwareDeviceToHardwareBySerialNumberDto implements Converter<HardwareDevice, HardwareBySerialNumberDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public HardwareBySerialNumberDto convert(HardwareDevice from) {
		HardwareBySerialNumberDto dto = new HardwareBySerialNumberDto();

		if (from.getDevice() != null) {
			dto.setId(from.getDevice().getId());
			dto.setSerialNumber(from.getDevice().getSerialNumber());
			if (from.getDevice().getIpAddress() != null) {				
				dto.setIp(from.getDevice().getIpAddress().getValue());
			}
			dto.setType(conversionService.convert(from.getDevice().getType(), DeviceTypeDto.class));
		} else if (from.getSimCard() != null) {
			dto.setId(from.getSimCard().getId());
			dto.setSerialNumber(from.getSimCard().getIccId());
			if (from.getSimCard().getIpAddress() != null) {				
				dto.setIp(from.getSimCard().getIpAddress());
			}
			dto.setType(conversionService.convert(from.getSimCard().getType(), DeviceTypeDto.class));
		}

		return dto;
	}
}
