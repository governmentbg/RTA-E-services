package bg.demax.inspections.backend.converter.equipment;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.WarehouseDto;
import bg.demax.inspections.backend.dto.equipment.DeviceStatusDto;
import bg.demax.inspections.backend.dto.equipment.DeviceTypeDto;
import bg.demax.inspections.backend.dto.equipment.HardwareDeviceDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDto;
import bg.demax.inspections.backend.entity.HardwareDevice;
import bg.demax.inspections.backend.util.PermitValidationUtil;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.Device;
import bg.demax.pub.entity.hardware.DeviceStatus;
import bg.demax.pub.entity.hardware.PermitLineHardware;
import bg.demax.pub.entity.hardware.SimCard;
import bg.demax.pub.entity.hardware.Store;
import bg.demax.techinsp.entity.Permit;
import bg.demax.techinsp.entity.PermitLine;

@Component
public class HardwareDeviceToHardwareDeviceDtoConverter implements Converter<HardwareDevice, HardwareDeviceDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public HardwareDeviceDto convert(HardwareDevice from) {
		HardwareDeviceDto dto = new HardwareDeviceDto();
		Device device = from.getDevice();
		SimCard sim = from.getSimCard();

		if (device != null) {
			PermitLineHardware permitLineHardware = device.getPermitLineHardware();
			PermitLine permitLine = null;
			if (permitLineHardware != null) {
				permitLine = permitLineHardware.getPermitLine();
			}
			if (permitLine != null && permitLine.getPermit() != null) {
				Permit permit = permitLine.getPermit();
				if (device.getStore().getCode().equals(Store.INSPECTION_STATION)) {
					dto.setPermit(conversionService.convert(permit, PermitDto.class));
				} else if (PermitValidationUtil.isPermitValid(permit)) {
					dto.setPermit(conversionService.convert(permit, PermitDto.class));
				}
			}
			if (device.getWarehouse() != null) {
				dto.setWarehouse(conversionService.convert(device.getWarehouse(), WarehouseDto.class));
			}
			dto.setId(device.getId());
			dto.setSerialNumber(device.getSerialNumber());
			DeviceStatus status = from.getDevice().getStatus();
			
			DeviceStatusDto statusDto = new DeviceStatusDto();
			BeanUtils.copyProperties(status, statusDto);
			dto.setStatus(statusDto);
			
			if (device.getType() != null) {
				dto.setType(conversionService.convert(device.getType(), DeviceTypeDto.class));
			}
			if (device.getScrapReason() != null) {
				dto.setScrapReason(device.getScrapReason().getDescription());
			}
		} else if (sim != null) {
			PermitLineHardware permitLineHardware = sim.getPermitLineHardware();
			PermitLine permitLine = null;
			if (permitLineHardware != null) {
				permitLine = permitLineHardware.getPermitLine();
			}
			if (permitLine != null && permitLine.getPermit() != null) {
				dto.setPermit(conversionService.convert(permitLine.getPermit(), PermitDto.class));
			}
			if (sim.getWarehouse() != null) {
				dto.setWarehouse(conversionService.convert(sim.getWarehouse(), WarehouseDto.class));
			}
			dto.setId(sim.getId());
			dto.setSerialNumber(sim.getIccId());
			DeviceStatus status = from.getSimCard().getStatus();
			
			DeviceStatusDto statusDto = new DeviceStatusDto();
			BeanUtils.copyProperties(status, statusDto);
			dto.setStatus(statusDto);
			
			if (sim.getType() != null) {
				dto.setType(conversionService.convert(sim.getType(), DeviceTypeDto.class));
			}
			if (sim.getScrapReason() != null) {
				dto.setScrapReason(sim.getScrapReason().getDescription());
			}
		}
		return dto;
	}
}
