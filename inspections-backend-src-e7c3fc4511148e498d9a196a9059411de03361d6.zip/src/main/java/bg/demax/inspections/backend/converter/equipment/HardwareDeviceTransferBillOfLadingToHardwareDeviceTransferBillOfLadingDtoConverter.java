package bg.demax.inspections.backend.converter.equipment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.HardwareDeviceTransferBillOfLadingDto;
import bg.demax.inspections.backend.dto.equipment.HardwareDeviceTransferProtocolDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.HardwareDeviceTransferBillOfLading;

@Component
public class HardwareDeviceTransferBillOfLadingToHardwareDeviceTransferBillOfLadingDtoConverter
				implements Converter<HardwareDeviceTransferBillOfLading, HardwareDeviceTransferBillOfLadingDto> {
	
	@Autowired
	private ConversionService conversionService;
	
	@Override
	public HardwareDeviceTransferBillOfLadingDto convert(HardwareDeviceTransferBillOfLading from) {
		HardwareDeviceTransferBillOfLadingDto dto = new HardwareDeviceTransferBillOfLadingDto();
		
		dto.setId(from.getId());
		dto.setBillOfLadingIdForCourier(from.getBillOfLadingIdForCourier());
		dto.setCourierCode(from.getCourier().getCode());
		if (from.getCourierServiceType() != null) {
			dto.setCourierServiceTypeCode(from.getCourierServiceType().getCode());
		}
		dto.setCreatedAt(from.getCreatedAt());
		dto.setStatusCode(from.getStatus().getCode());
		dto.setRecipient(from.getWarehouse().getName());
		
		dto.setProtocols(conversionService.convertList(from.getProtocols(), HardwareDeviceTransferProtocolDto.class));
		
		dto.setContactPersonName(from.getRecipientPersonName());
		dto.setContactPersonPhoneNumber(from.getRecipientPersonPhone());
		dto.setShippingAddress(from.getRecipientAddress());
		dto.setPackageCount(from.getPackageCount());
		dto.setWeight(from.getWeightKg());
		
		dto.setFixedTimeDelivery(from.getDeliveryTime());
		
		return dto;
	}

}
