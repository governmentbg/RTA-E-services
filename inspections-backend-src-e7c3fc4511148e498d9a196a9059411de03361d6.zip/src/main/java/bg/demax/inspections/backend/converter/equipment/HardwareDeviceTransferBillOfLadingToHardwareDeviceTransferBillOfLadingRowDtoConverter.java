package bg.demax.inspections.backend.converter.equipment;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.WarehouseDto;
import bg.demax.inspections.backend.dto.equipment.HardwareDeviceTransferBillOfLadingRowDto;
import bg.demax.inspections.backend.service.equipment.HardwareDeviceTransferProtocolService;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.HardwareDeviceTransferBillOfLading;
import bg.demax.pub.entity.hardware.HardwareDeviceTransferProtocol;

@Component
public class HardwareDeviceTransferBillOfLadingToHardwareDeviceTransferBillOfLadingRowDtoConverter implements
				Converter<HardwareDeviceTransferBillOfLading, HardwareDeviceTransferBillOfLadingRowDto> {

	@Autowired
	private ConversionService conversionService;

	@Autowired
	private HardwareDeviceTransferProtocolService hardwareDeviceTransferProtocolService;

	@Override
	public HardwareDeviceTransferBillOfLadingRowDto convert(
					HardwareDeviceTransferBillOfLading from) {
		HardwareDeviceTransferBillOfLadingRowDto dto = new HardwareDeviceTransferBillOfLadingRowDto();

		dto.setId(from.getId());
		dto.setCourierName(from.getCourier().getCode());
		dto.setBillOfLadingId(from.getBillOfLadingIdForCourier());
		dto.setCreatedAt(from.getCreatedAt());
		dto.setWarehouse(conversionService.convert(from.getWarehouse(), WarehouseDto.class));

		List<Integer> protocolIds = null;
		if (from.getProtocols() != null) {
			protocolIds = from.getProtocols().stream().map(HardwareDeviceTransferProtocol::getId)
							.collect(Collectors.toList());
		}
		dto.setHardwareItemsCount(getHardwareDevicesCount(from.getProtocols()));
		dto.setProtocolsIds(protocolIds);
		dto.setPackageCount(from.getPackageCount());
		dto.setWeightKg(from.getWeightKg());
		dto.setStatusCode(from.getStatus().getCode());
		return dto;
	}

	private Short getHardwareDevicesCount(List<HardwareDeviceTransferProtocol> protocols) {
		int count = 0;
		for (HardwareDeviceTransferProtocol protocol : protocols) {
			count += hardwareDeviceTransferProtocolService.getDevicesCountForProtocolById(protocol.getId());
		}
		return (short) count;
	}
}