package bg.demax.inspections.backend.converter.equipment;

import java.util.HashSet;
import java.util.Set;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.HardwareDeviceIdentifierDto;
import bg.demax.inspections.backend.dto.equipment.HardwareDeviceTransferCreationRequestDto;
import bg.demax.inspections.backend.entity.Courier;
import bg.demax.inspections.backend.entity.CourierServiceType;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.Device;
import bg.demax.pub.entity.hardware.DeviceType;
import bg.demax.pub.entity.hardware.HardwareDeviceTransferBillOfLading;
import bg.demax.pub.entity.hardware.HardwareDeviceTransferProtocol;
import bg.demax.pub.entity.hardware.SimCard;
import bg.demax.pub.entity.hardware.Warehouse;

@Component
public class HardwareDeviceTransferCreationRequestDtoToHardwareDeviceTransferProtocolConverter
				implements Converter<HardwareDeviceTransferCreationRequestDto, HardwareDeviceTransferProtocol> {

	@Override
	public HardwareDeviceTransferProtocol convert(HardwareDeviceTransferCreationRequestDto dto) {
		HardwareDeviceTransferProtocol protocol = new HardwareDeviceTransferProtocol();
		HardwareDeviceTransferBillOfLading billOfLading = createBillOfLading(dto);
		protocol.setBillOfLading(billOfLading);

		Set<Device> devices = new HashSet<>();
		Set<SimCard> simCards = new HashSet<>();
		for (HardwareDeviceIdentifierDto deviceIdDto : dto.getDevices()) {
			if (deviceIdDto.getTypeCode().equals(DeviceType.VIVACOM_SIM_CARD_CODE)
							|| deviceIdDto.getTypeCode().equals(DeviceType.GLOBUL_SIM_CARD_CODE)) {
				SimCard sim = new SimCard();
				sim.setId(deviceIdDto.getId());
				simCards.add(sim);
			} else {
				Device device = new Device();
				device.setId(deviceIdDto.getId());
				devices.add(device);
			}
		}
		protocol.setDevices(devices);
		protocol.setSimCards(simCards);

		return protocol;
	}

	private HardwareDeviceTransferBillOfLading createBillOfLading(HardwareDeviceTransferCreationRequestDto dto) {
		HardwareDeviceTransferBillOfLading billOfLading = new HardwareDeviceTransferBillOfLading();
		Courier courier = new Courier();
		courier.setCode(dto.getCourierCode());
		billOfLading.setCourier(courier);

		CourierServiceType courierServiceType = new CourierServiceType();
		courierServiceType.setCode(dto.getCourierServiceTypeCode());
		billOfLading.setCourierServiceType(courierServiceType);

		Warehouse warehouse = new Warehouse();
		warehouse.setId(dto.getWarehouseShippingInfo().getWarehouseId());
		billOfLading.setWarehouse(warehouse);

		billOfLading.setPackageCount(dto.getPacketsCount());
		billOfLading.setWeightKg(dto.getWeightKg());
		return billOfLading;
	}
}