package bg.demax.inspections.backend.converter.equipment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.HardwareDeviceTransferProtocolDto;
import bg.demax.inspections.backend.dto.equipment.HardwareLightDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.HardwareDeviceTransferProtocol;

@Component
public class HardwareDeviceTransferProtocolToHardwareDeviceTransferProtocolDtoConverter
				implements Converter<HardwareDeviceTransferProtocol, HardwareDeviceTransferProtocolDto> {

	@Autowired
	private ConversionService conversionService;
	
	@Override
	public HardwareDeviceTransferProtocolDto convert(HardwareDeviceTransferProtocol from) {
		HardwareDeviceTransferProtocolDto dto = new HardwareDeviceTransferProtocolDto();
		dto.setId(from.getId());
		dto.setBillOfLadingId(from.getBillOfLading().getId());
		dto.setCreatedAt(from.getCreatedAt());
		dto.setDevices(conversionService.convertSet(from.getDevices(), HardwareLightDto.class));
		dto.setSimCards(conversionService.convertSet(from.getSimCards(), HardwareLightDto.class));
		return dto;
	}

}
