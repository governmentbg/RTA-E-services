package bg.demax.inspections.backend.converter.equipment;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.HardwareDeviceUpdateRequestDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.Device;
import bg.demax.pub.entity.hardware.DeviceIpAddress;
import bg.demax.pub.entity.hardware.DeviceMacAddress;
import bg.demax.pub.entity.hardware.DeviceScrapReason;
import bg.demax.pub.entity.hardware.DeviceStatus;
import bg.demax.pub.entity.hardware.DeviceType;
import bg.demax.pub.entity.hardware.Warehouse;

@Component
public class HardwareDeviceUpdateRequestDtoToDeviceConverter implements Converter<HardwareDeviceUpdateRequestDto, Device> {

	@Override
	public Device convert(HardwareDeviceUpdateRequestDto from) {
		Device device = new Device();
		if (from.getMacAddress() != null && !from.getMacAddress().trim().isEmpty()) {
			DeviceMacAddress deviceMacAddress = new DeviceMacAddress();
			deviceMacAddress.setValue(from.getMacAddress().trim());
			device.setMacAddress(deviceMacAddress);
		}
		if (from.getIpAddress() != null && !from.getIpAddress().trim().isEmpty()) {
			DeviceIpAddress deviceIp = new DeviceIpAddress();
			deviceIp.setValue(from.getIpAddress().trim());
			device.setIpAddress(deviceIp);
		}
		if (from.getStatusId() != null) {
			DeviceStatus status = new DeviceStatus();
			status.setId(from.getStatusId());
			device.setStatus(status);
		}
		
		device.setSerialNumber(from.getSerialNumber());
		
		DeviceType type = new DeviceType();
		type.setCode(from.getTypeCode());
		device.setType(type);

		Warehouse warehouse = new Warehouse();
		warehouse.setId(from.getWarehouseId());
		device.setWarehouse(warehouse);
		
		if (from.getScrapReason() != null && !from.getScrapReason().isEmpty()) {
			device.setScrapReason(new DeviceScrapReason());
			device.getScrapReason().setDescription(from.getScrapReason());
		}
		return device;
	}
}
