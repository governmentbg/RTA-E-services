package bg.demax.inspections.backend.converter.equipment;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.HardwareDeviceUpdateRequestDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.DeviceScrapReason;
import bg.demax.pub.entity.hardware.DeviceStatus;
import bg.demax.pub.entity.hardware.DeviceType;
import bg.demax.pub.entity.hardware.SimCard;
import bg.demax.pub.entity.hardware.Warehouse;

@Component
public class HardwareDeviceUpdateRequestDtoToSimCardConverter implements Converter<HardwareDeviceUpdateRequestDto, SimCard> {

	@Override
	public SimCard convert(HardwareDeviceUpdateRequestDto from) {
		SimCard sim = new SimCard();

		sim.setIpAddress(from.getIpAddress());
		if (from.getStatusId() != null) {
			DeviceStatus status = new DeviceStatus();
			status.setId(from.getStatusId());
			sim.setStatus(status);
		}

		DeviceType type = new DeviceType();
		type.setCode(from.getTypeCode());
		sim.setType(type);

		Warehouse warehouse = new Warehouse();
		warehouse.setId(from.getWarehouseId());
		sim.setWarehouse(warehouse);
		
		if (from.getScrapReason() != null && !from.getScrapReason().isEmpty()) {
			sim.setScrapReason(new DeviceScrapReason());
			sim.getScrapReason().setDescription(from.getScrapReason());
		}
		
		sim.setIccId(from.getSerialNumber());
		return sim;
	}
}
