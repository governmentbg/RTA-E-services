package bg.demax.inspections.backend.converter.equipment;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.PrinterCartridgeReportDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.PrinterConsumableReport;

@Component
public class PrinterCartridgeReportToPrinterCartridgeReportDtoConverter
				implements Converter<PrinterConsumableReport, PrinterCartridgeReportDto> {

	@Override
	public PrinterCartridgeReportDto convert(PrinterConsumableReport report) {
		PrinterCartridgeReportDto dto = new PrinterCartridgeReportDto();
		dto.setId(report.getId());
		dto.setCreatedAt(report.getCreatedAt());
		dto.setInspectionNeededPages(report.getInspectionNeededPages());
		dto.setPagesForPayment(report.getPagesForPayment());
		dto.setPrintedPages(report.getPrintedPages());
		return dto;
	}
}
