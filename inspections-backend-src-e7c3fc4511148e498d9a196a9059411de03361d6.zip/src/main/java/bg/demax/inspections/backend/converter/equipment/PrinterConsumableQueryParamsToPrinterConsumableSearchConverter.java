package bg.demax.inspections.backend.converter.equipment;

import java.util.Arrays;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.controller.param.equipment.PrinterConsumableQueryParams;
import bg.demax.inspections.backend.search.equipment.PrinterConsumableSearch;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PrinterConsumableQueryParamsToPrinterConsumableSearchConverter
				implements Converter<PrinterConsumableQueryParams, PrinterConsumableSearch> {

	@Override
	public PrinterConsumableSearch convert(PrinterConsumableQueryParams params) {
		PrinterConsumableSearch search = new PrinterConsumableSearch();
		if (params.getSearchText() != null && !params.getSearchText().isEmpty()) {
			search.setSearchText(params.getSearchText().trim());
		}
		search.setType(params.getType());
		if (params.getStatuses() != null && params.getStatuses().length > 0) {
			search.setStatuses(Arrays.asList(params.getStatuses()));
		}
		if (params.getOrgUnitCode() != null && !params.getOrgUnitCode().trim().isEmpty()) {
			search.setOrgUnitCode(params.getOrgUnitCode());
		}
		return search;
	}
}
