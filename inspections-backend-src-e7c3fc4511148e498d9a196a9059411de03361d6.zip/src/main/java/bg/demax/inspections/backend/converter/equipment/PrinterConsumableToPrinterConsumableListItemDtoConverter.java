package bg.demax.inspections.backend.converter.equipment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.PrinterConsumableListItemDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDto;
import bg.demax.inspections.backend.util.PrintConsumableUtil;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.PrinterConsumable;
import bg.demax.techinsp.entity.Permit;

@Component
public class PrinterConsumableToPrinterConsumableListItemDtoConverter
				implements Converter<PrinterConsumable, PrinterConsumableListItemDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public PrinterConsumableListItemDto convert(PrinterConsumable from) {
		PrinterConsumableListItemDto dto = new PrinterConsumableListItemDto();
		dto.setId(from.getId());
		dto.setSentAt(from.getSentAt());

		dto.setFirstInstalledAt(from.getFirstInstalledAt());
		dto.setLastUsedAt(from.getLastUsedAt());
		dto.setPercentUsed(from.getPercentUsed());
		Permit cartridgePermit = null;
		if (from.getPrinter() != null && from.getPrinter().getPermitLineHardware() != null
						&& from.getPrinter().getPermitLineHardware().getPermitLine() != null
						&& from.getPrinter().getPermitLineHardware().getPermitLine().getPermit() != null) {
			cartridgePermit = from.getPrinter().getPermitLineHardware().getPermitLine().getPermit();
		} else {
			cartridgePermit = from.getSentToPermit();
		}
		if (cartridgePermit != null) {
			dto.setPermit(conversionService.convert(cartridgePermit, PermitDto.class));
		}
		dto.setPrintedPages(from.getPrintedPages());
		dto.setRemainingPages(from.getRemainingPages());
		dto.setSerialNumber(from.getSerialNumber());
		dto.setStatus(PrintConsumableUtil.convertPrinterConsumbleStatusToConsumableStatus(from.getStatus()));
		dto.setTotalImpressions(from.getTotalImpressions());
		dto.setType(PrintConsumableUtil.convertPrinterConsumableTypeToConsumableType(from.getType()));
		return dto;
	}
}