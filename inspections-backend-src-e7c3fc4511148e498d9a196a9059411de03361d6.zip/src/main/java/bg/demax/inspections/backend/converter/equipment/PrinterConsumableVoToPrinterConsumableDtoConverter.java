package bg.demax.inspections.backend.converter.equipment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.PrinterCartridgeReportDto;
import bg.demax.inspections.backend.dto.equipment.PrinterConsumableDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDto;
import bg.demax.inspections.backend.util.PrintConsumableUtil;
import bg.demax.inspections.backend.vo.PrinterConsumableVo;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.Device;
import bg.demax.pub.entity.hardware.PrinterConsumable;
import bg.demax.techinsp.entity.Permit;

@Component
public class PrinterConsumableVoToPrinterConsumableDtoConverter
		implements Converter<PrinterConsumableVo, PrinterConsumableDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public PrinterConsumableDto convert(PrinterConsumableVo vo) {
		PrinterConsumable consumable = vo.getConsumable();

		PrinterConsumableDto dto = new PrinterConsumableDto();
		dto.setId(consumable.getId());
		dto.setInspectionNeededPages(vo.getInspectionNeededPages());
		dto.setSentAt(consumable.getSentAt());

		dto.setFirstInstalledAt(consumable.getFirstInstalledAt());
		dto.setLastUsedAt(consumable.getLastUsedAt());
		dto.setPercentUsed(consumable.getPercentUsed());
		dto.setPrintedPages(consumable.getPrintedPages());
		Device cartridgePrinter = consumable.getPrinter();
		if (cartridgePrinter != null) {
			dto.setPrinterSerialNumber(cartridgePrinter.getSerialNumber());
		}
		dto.setRemainingPages(consumable.getRemainingPages());
		dto.setSerialNumber(consumable.getSerialNumber());
		dto.setTotalImpressions(consumable.getTotalImpressions());

		Permit cartridgePermit = null;
		if (consumable.getPrinter() != null && consumable.getPrinter().getPermitLineHardware() != null
				&& consumable.getPrinter().getPermitLineHardware().getPermitLine() != null
				&& consumable.getPrinter().getPermitLineHardware().getPermitLine().getPermit() != null) {
			cartridgePermit = consumable.getPrinter().getPermitLineHardware().getPermitLine().getPermit();
		} else {
			cartridgePermit = consumable.getSentToPermit();
		}
		if (cartridgePermit != null) {
			dto.setPermit(conversionService.convert(cartridgePermit, PermitDto.class));
		}
		if (vo.getLatestReport() != null) {
			dto.setLatestReport(conversionService.convert(vo.getLatestReport(), PrinterCartridgeReportDto.class));
		}
		dto.setStatus(PrintConsumableUtil.convertPrinterConsumbleStatusToConsumableStatus(consumable.getStatus()));
		dto.setType(PrintConsumableUtil.convertPrinterConsumableTypeToConsumableType(consumable.getType()));
		dto.setIsDefective(consumable.isDefective());
		dto.setReturnedAt(consumable.getReturnedAt());
		dto.setReturnedNotes(consumable.getReturnedNotes());
		return dto;
	}
}
