package bg.demax.inspections.backend.converter.equipment;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.equipment.HardwareLightDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.hardware.SimCard;

@Component
public class SimCardToHardwareLightDto implements Converter<SimCard, HardwareLightDto> {

	@Override
	public HardwareLightDto convert(SimCard from) {
		HardwareLightDto dto = new HardwareLightDto();
		dto.setSerialNumber(from.getIccId());
		dto.setDeviceType(from.getType().getDescription());
		return dto;
	}

}
