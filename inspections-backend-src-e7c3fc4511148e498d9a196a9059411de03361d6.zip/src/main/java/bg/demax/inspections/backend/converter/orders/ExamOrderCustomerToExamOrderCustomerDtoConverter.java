package bg.demax.inspections.backend.converter.orders;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.orders.ExamOrderCustomerDto;
import bg.demax.inspections.backend.entity.motor.exam.result.ExamOrderCustomer;
import bg.demax.legacy.util.convert.Converter;

@Component
public class ExamOrderCustomerToExamOrderCustomerDtoConverter
		implements Converter<ExamOrderCustomer, ExamOrderCustomerDto> {

	@Override
	public ExamOrderCustomerDto convert(ExamOrderCustomer from) {
		ExamOrderCustomerDto dto = new ExamOrderCustomerDto();
		
		StringBuilder stringBuilder = new StringBuilder();
		
		stringBuilder.append(from.getCity().getRegion().getName()).append(", ")
						.append(from.getCity().getMunicipality().getName()).append(", ")
						.append(from.getCity().getName()).append(", ")
						.append(from.getAddress());
		
		dto.setAddress(stringBuilder.toString());
		dto.setCityName(from.getCity().getName());
		dto.setCompanyName(from.getName());
		dto.setEik(from.getEik());
		dto.setMol(from.getMol());
		dto.setMunicipality(from.getCity().getMunicipality().getName());
		dto.setVatNumber(from.getVatNumber());
		dto.setPhoneNumber(from.getPhoneNum());
		return dto;
	}

}
