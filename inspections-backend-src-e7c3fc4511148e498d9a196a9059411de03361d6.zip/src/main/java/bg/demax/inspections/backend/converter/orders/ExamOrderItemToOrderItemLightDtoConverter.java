package bg.demax.inspections.backend.converter.orders;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.orders.OrderItemLightDto;
import bg.demax.inspections.backend.entity.motor.exam.result.ExamOrderItem;
import bg.demax.legacy.util.convert.Converter;

@Component
public class ExamOrderItemToOrderItemLightDtoConverter implements Converter<ExamOrderItem, OrderItemLightDto> {

	@Override
	public OrderItemLightDto convert(ExamOrderItem from) {
		OrderItemLightDto dto = new OrderItemLightDto();
		
		if (from.getFromNum() != null && from.getFromNum() > 0) {
			dto.setFromNum(from.getFromNum());
		}
		
		if (from.getToNum() != null && from.getToNum() > 0) {
			dto.setToNum(from.getToNum());
		}
		
		dto.setQuantity(from.getQuantity());
		return dto;
	}
}
