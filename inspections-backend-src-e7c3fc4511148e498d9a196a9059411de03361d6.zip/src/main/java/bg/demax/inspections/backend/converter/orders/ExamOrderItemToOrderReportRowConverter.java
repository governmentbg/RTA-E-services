package bg.demax.inspections.backend.converter.orders;

import java.math.BigDecimal;
import java.text.DecimalFormat;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.entity.motor.exam.result.ExamOrderItem;
import bg.demax.inspections.backend.export.report.order.OrderInvoiceReportRow;
import bg.demax.legacy.util.convert.Converter;

@Component
public class ExamOrderItemToOrderReportRowConverter implements Converter<ExamOrderItem, OrderInvoiceReportRow> {

	@Override
	public OrderInvoiceReportRow convert(ExamOrderItem from) {
		DecimalFormat df = new DecimalFormat("0.00"); 
		
		OrderInvoiceReportRow row = new OrderInvoiceReportRow();
		row.setItemCipher(String.valueOf(from.getExamProduct().getId()));
		row.setItemMeasure("бр.");
		row.setItemName(from.getExamProduct().getProductName());
		row.setItemPrice(new BigDecimal(df.format(from.getExamProduct().getPrice())));
		row.setItemQuantity(from.getQuantity());
		row.setItemValue(new BigDecimal(df.format(row.getItemPrice().multiply(new BigDecimal(row.getItemQuantity())))));
		return row;
	}

}
