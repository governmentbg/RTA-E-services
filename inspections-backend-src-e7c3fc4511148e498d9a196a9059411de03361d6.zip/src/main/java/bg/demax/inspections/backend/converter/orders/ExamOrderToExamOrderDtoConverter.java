package bg.demax.inspections.backend.converter.orders;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.BillOfLadingDto;
import bg.demax.inspections.backend.dto.orders.ExamOrderCustomerDto;
import bg.demax.inspections.backend.dto.orders.ExamOrderDto;
import bg.demax.inspections.backend.dto.orders.OrderItemDto;
import bg.demax.inspections.backend.entity.BillOfLading;
import bg.demax.inspections.backend.entity.motor.exam.result.ExamOrder;
import bg.demax.inspections.backend.entity.motor.exam.result.ExamOrderCustomer;
import bg.demax.inspections.backend.entity.motor.exam.result.ExamOrderItem;
import bg.demax.inspections.backend.entity.motor.exam.result.ExamProduct.ExamProducts;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;

@Component
public class ExamOrderToExamOrderDtoConverter implements Converter<ExamOrder, ExamOrderDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public ExamOrderDto convert(ExamOrder examOrder) {
		ExamOrderDto dto = new ExamOrderDto();
		ExamOrderCustomer orderCustomer = examOrder.getExamOrderCustomer();
		
		dto.setId(examOrder.getId());
		dto.setOrderCreationDate(examOrder.getOrderDatetime());
		dto.setStatusCode(examOrder.getOrderStatus().getCode());
		
		StringBuilder stringBuilder = new StringBuilder();
		
		stringBuilder.append(examOrder.getCity().getRegion().getName()).append(", ")
						.append(examOrder.getCity().getMunicipality().getName()).append(", ")
						.append(examOrder.getCity().getName()).append(", ")
						.append(examOrder.getAddress());
		
		
		dto.setReceptionAddress(stringBuilder.toString());
		dto.setReceptionCityName(examOrder.getCity().getName());
		dto.setReceptionCityType(examOrder.getCity().getType().getValue());
		dto.setReceptionPersonName(examOrder.getPersonName());
		dto.setReceptionPersonPhoneNumber(examOrder.getPersonPhone());
		BillOfLading bol = examOrder.getBillOfLading();
		dto.setBillOfLadingDto(bol != null ? conversionService.convert(bol, BillOfLadingDto.class) : null);
		
		dto.setAccountantName(examOrder.getAccountantName());
		dto.setAccountantCode(examOrder.getAccountantCode());
		dto.setInvoiceDateTime(examOrder.getInvoiceDate());
		dto.setInvoiceNumber(examOrder.getInvoiceNum() != null ? examOrder.getInvoiceNum().toString() : null);
		
		dto.setHasBankStatement(examOrder.getHasBankStatment() != null  ? examOrder.getHasBankStatment() : false);
		
		dto.setExamOrderCustomerDto(conversionService.convert(orderCustomer, ExamOrderCustomerDto.class));
		
		List<ExamOrderItem> examOrderItems = getExamOrderItemsForProductType(examOrder, ExamProducts.VOUCHERS_FOR_PRACTICAL_EXAMS);
		dto.setExamOrderItemDtos(conversionService.convertList(examOrderItems, OrderItemDto.class));
		return dto;
	}
	
	private List<ExamOrderItem> getExamOrderItemsForProductType(ExamOrder examOrder, ExamProducts examProductEnum) {
		List<ExamOrderItem> orderItemsForProduct = new ArrayList<ExamOrderItem>();
		examOrder.getExamOrderItems().forEach(eoi -> {
			if (eoi.getExamProduct().getId() == examProductEnum.getId()) {
				orderItemsForProduct.add(eoi);
			}
		});
		
		return orderItemsForProduct;
	}

}
