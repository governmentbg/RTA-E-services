package bg.demax.inspections.backend.converter.orders;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.entity.motor.exam.result.ExamOrder;
import bg.demax.inspections.backend.vo.techinsp.ExamOrderInvoicePrintVo;
import bg.demax.legacy.util.convert.Converter;

@Component
public class ExamOrderToExamOrderInvoicePrintVoConverter implements Converter<ExamOrder, ExamOrderInvoicePrintVo> {

	@Override
	public ExamOrderInvoicePrintVo convert(ExamOrder from) {
		ExamOrderInvoicePrintVo vo = new ExamOrderInvoicePrintVo();
		
		vo.setAccountantName(from.getAccountantName());
		vo.setInvoiceNum(from.getInvoiceNum().toString());
		vo.setOrderDatetime(from.getOrderDatetime());
		vo.setExamOrderCustomerName(from.getExamOrderCustomer().getName());
		vo.setCityName(from.getCity().getName());
		vo.setAddress(from.getAddress());
		vo.setExamOrderCustomerEik(from.getExamOrderCustomer().getEik());
		vo.setExamOrderCustomerVatNumber(from.getExamOrderCustomer().getVatNumber());
		
		vo.setExamOrderIssuerName(from.getExamOrderIssuer().getName());
		vo.setExamOrderIssuerAddress(from.getExamOrderIssuer().getAddress());
		vo.setExamOrderIssuerEik(from.getExamOrderIssuer().getEik());
		vo.setExamOrderIssuerVatNumber(from.getExamOrderIssuer().getVatNumber());
		vo.setExamOrderIssuerBankName(from.getExamOrderIssuer().getBank());
		vo.setExamOrderIssuerIban(from.getExamOrderIssuer().getIban());
		vo.setExamOrderIssuerBic(from.getExamOrderIssuer().getBic());
		
		return vo;
	}

}
