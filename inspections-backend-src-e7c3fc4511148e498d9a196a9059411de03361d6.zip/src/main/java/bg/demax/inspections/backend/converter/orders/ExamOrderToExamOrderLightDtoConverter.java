package bg.demax.inspections.backend.converter.orders;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.orders.ExamOrderLightDto;
import bg.demax.inspections.backend.dto.orders.OrderItemLightDto;
import bg.demax.inspections.backend.entity.motor.exam.result.ExamOrder;
import bg.demax.inspections.backend.entity.motor.exam.result.ExamOrderCustomer;
import bg.demax.inspections.backend.entity.motor.exam.result.ExamOrderItem;
import bg.demax.inspections.backend.entity.motor.exam.result.ExamProduct.ExamProducts;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;

@Component
public class ExamOrderToExamOrderLightDtoConverter implements Converter<ExamOrder, ExamOrderLightDto> {
	
	@Autowired
	private ConversionService conversionService;
	
	@Override
	public ExamOrderLightDto convert(ExamOrder from) {
		ExamOrderCustomer examCustomer = from.getExamOrderCustomer();
		
		ExamOrderLightDto dto = new ExamOrderLightDto();
		dto.setId(from.getId());
		dto.setCreatedAt(from.getOrderDatetime());
		dto.setReceptionCityName(from.getCity().getName());
		dto.setStatusCode(from.getOrderStatus().getCode());
		
		StringBuilder stringBuilder = new StringBuilder();
		
		stringBuilder.append(from.getCity().getRegion().getName()).append(", ")
					.append(from.getCity().getMunicipality().getName()).append(", ")
					.append(from.getCity().getName()).append(", ")
					.append(from.getAddress());
		
		
		dto.setReceptionAddress(stringBuilder.toString());
		
		dto.setCompanyName(examCustomer.getName());
		dto.setEik(examCustomer.getEik());
		
		dto.setPermitNumber(from.getPermit().getNumber());
		List<OrderItemLightDto> orderLightDtos = new ArrayList<>();
		
		for (ExamOrderItem item : from.getExamOrderItems()) {
			if (item.getExamProduct().getId() != (ExamProducts.DELIVERY.getId())) {
				OrderItemLightDto itemLight = conversionService.convert(item, OrderItemLightDto.class);
				orderLightDtos.add(itemLight);
			}
		}
		
		dto.setOrderItems(orderLightDtos);
		
		return dto;
	}

}
