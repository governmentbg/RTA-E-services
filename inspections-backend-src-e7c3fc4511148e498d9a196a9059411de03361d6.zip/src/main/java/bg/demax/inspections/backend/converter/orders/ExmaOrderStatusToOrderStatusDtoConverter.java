package bg.demax.inspections.backend.converter.orders;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.orders.OrderStatusDto;
import bg.demax.inspections.backend.entity.motor.exam.result.ExamOrderStatus;
import bg.demax.legacy.util.convert.Converter;

@Component
public class ExmaOrderStatusToOrderStatusDtoConverter implements Converter<ExamOrderStatus, OrderStatusDto> {

	@Override
	public OrderStatusDto convert(ExamOrderStatus status) {
		OrderStatusDto dto = new OrderStatusDto();
		dto.setCode(status.getCode());
		dto.setDesctiption(status.getShortDescription());
		return dto;
	}
}
