package bg.demax.inspections.backend.converter.orders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.converter.BillOfLadingToBillOfLadingDtoConverter;
import bg.demax.inspections.backend.dto.OrgUnitLightDto;
import bg.demax.inspections.backend.dto.orders.InspectionBillOfLadingDto;
import bg.demax.inspections.backend.dto.orders.InspectionDeliveryProtocolLightDto;
import bg.demax.inspections.backend.entity.inspection.InspectionDeliveryProtocolBillOfLading;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionDeliveryProtocolBillOfLadingToInspectionBillOfLadingDtoConverter
				implements Converter<InspectionDeliveryProtocolBillOfLading, InspectionBillOfLadingDto> {

	@Autowired
	private ConversionService converionService;
	
	@Autowired
	private BillOfLadingToBillOfLadingDtoConverter bolConverter;
	
	@Override
	public InspectionBillOfLadingDto convert(InspectionDeliveryProtocolBillOfLading billOfLading) {
		InspectionBillOfLadingDto dto = new InspectionBillOfLadingDto();

		bolConverter.convert(billOfLading, dto);
	
		dto.setContactPersonName("Служител");
		dto.setContactPersonPhoneNumber(billOfLading.getDestinationOrgUnit().getPhoneNumber());
		dto.setShippingAddress(billOfLading.getDestinationOrgUnit().getAddress());
		dto.setRecipient(billOfLading.getDestinationOrgUnit().getShortName());
		dto.setOrgUnit(converionService.convert(billOfLading.getDestinationOrgUnit(), OrgUnitLightDto.class));
		dto.setProtocols(converionService.convertList(billOfLading.getProtocols(), InspectionDeliveryProtocolLightDto.class));
		dto.setPackageCount(billOfLading.getPackageCount());
		dto.setWeight(billOfLading.getWeight());
	
		return dto;
	}

}
