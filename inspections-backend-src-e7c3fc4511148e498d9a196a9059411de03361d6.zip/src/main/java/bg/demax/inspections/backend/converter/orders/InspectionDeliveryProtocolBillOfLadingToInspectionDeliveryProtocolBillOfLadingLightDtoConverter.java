package bg.demax.inspections.backend.converter.orders;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.converter.BillOfLadingToBillOfLadingDtoConverter;
import bg.demax.inspections.backend.dto.OrgUnitLightDto;
import bg.demax.inspections.backend.dto.orders.InspectionDeliveryProtocolBillOfLadingLightDto;
import bg.demax.inspections.backend.entity.inspection.InspectionDeliveryProtocol;
import bg.demax.inspections.backend.entity.inspection.InspectionDeliveryProtocolBillOfLading;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionDeliveryProtocolBillOfLadingToInspectionDeliveryProtocolBillOfLadingLightDtoConverter
		implements Converter<InspectionDeliveryProtocolBillOfLading, InspectionDeliveryProtocolBillOfLadingLightDto> {

	@Autowired
	private ConversionService conversionService;
	
	@Autowired
	private BillOfLadingToBillOfLadingDtoConverter billOfLadingToBillOfLadingDtoConverter;
	
	@Override
	public InspectionDeliveryProtocolBillOfLadingLightDto convert(InspectionDeliveryProtocolBillOfLading from) {
		InspectionDeliveryProtocolBillOfLadingLightDto dto = new InspectionDeliveryProtocolBillOfLadingLightDto();
		
		billOfLadingToBillOfLadingDtoConverter.convert(from, dto);
		
		dto.setOrgUnit(conversionService.convert(from.getDestinationOrgUnit(), OrgUnitLightDto.class));

		List<Long> protocolIds = null;
		
		if (from.getProtocols() != null) {
			protocolIds = from.getProtocols().stream().map(InspectionDeliveryProtocol::getId).collect(Collectors.toList());
		}
		
		dto.setProtocols(protocolIds);
		dto.setPackageCount(from.getPackageCount());
		dto.setWeight(from.getWeight());

		return dto;
	}
	

}
