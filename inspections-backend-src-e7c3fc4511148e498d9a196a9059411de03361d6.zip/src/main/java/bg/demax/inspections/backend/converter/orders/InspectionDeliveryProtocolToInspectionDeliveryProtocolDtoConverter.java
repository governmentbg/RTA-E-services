package bg.demax.inspections.backend.converter.orders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.orders.InspectionDeliveryProtocolDto;
import bg.demax.inspections.backend.dto.orders.InspectionOrderLightDto;
import bg.demax.inspections.backend.entity.inspection.InspectionDeliveryProtocol;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionDeliveryProtocolToInspectionDeliveryProtocolDtoConverter
		implements Converter<InspectionDeliveryProtocol, InspectionDeliveryProtocolDto> {

	@Autowired
	private ConversionService converionService;
	
	@Autowired
	private InspectionDeliveryProtocolToInspectionDeliveryProtocolMediumDtoConverter mediumConverter;
	
	@Override
	public InspectionDeliveryProtocolDto convert(InspectionDeliveryProtocol from) {
		
		InspectionDeliveryProtocolDto dto = new InspectionDeliveryProtocolDto();
		mediumConverter.convert(from, dto);
		
		dto.setOrders(converionService.convertList(from.getInspectionOrders(), InspectionOrderLightDto.class));
		return dto;
	}
}
