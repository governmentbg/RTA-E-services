package bg.demax.inspections.backend.converter.orders;

import java.math.BigDecimal;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.orders.InspectionDeliveryProtocolLightDto;
import bg.demax.inspections.backend.entity.inspection.InspectionDeliveryProtocol;
import bg.demax.inspections.backend.entity.inspection.InspectionOrder;
import bg.demax.inspections.backend.entity.inspection.InspectionOrderItem;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionDeliveryProtocolToInspectionDeliveryProtocolLightDtoConverter
		implements Converter<InspectionDeliveryProtocol, InspectionDeliveryProtocolLightDto> {
	private static final Logger logger = LogManager
			.getLogger(InspectionDeliveryProtocolToInspectionDeliveryProtocolLightDtoConverter.class);

	@Override
	public InspectionDeliveryProtocolLightDto convert(InspectionDeliveryProtocol from) {
		InspectionDeliveryProtocolLightDto dto = new InspectionDeliveryProtocolLightDto();

		convert(from, dto);

		return dto;
	}
	
	public void convert(InspectionDeliveryProtocol from, InspectionDeliveryProtocolLightDto dto) {
		dto = dto != null ? dto : new InspectionDeliveryProtocolLightDto();
		
		if (from.getBillOfLading() != null) {
			dto.setBillOfLadingIdForCourier(from.getBillOfLading().getBillOfLadingIdForCourier());
		}
		
		dto.setCreationTimestamp(from.getCreationTimestamp());
		dto.setId(from.getId());

		if (from.getInspectionOrders().size() > 0) {
			setWeight(from, dto);
			setItemsCount(from, dto);
		} else {
			dto.setWeight(null);
			dto.setItemsCount(null);
			logger.debug("InspectionDeliveryProtocol " + from.getId() + " has no orders.");
		}

	}

	private void setItemsCount(InspectionDeliveryProtocol from, InspectionDeliveryProtocolLightDto dto) {
		long itemsCount = 0;
		for (InspectionOrder order : from.getInspectionOrders()) {
			List<InspectionOrderItem> orderItems = order.getOrderItems();
			if (orderItems == null || orderItems.size() < 0) {
				logger.debug("InspectionOrder with id " + order.getId() + " has no order items."
						+ "Skipping items counting for InspectionDeliveryProtocol with id " + from.getId());
				return;
			}
			for (InspectionOrderItem inspectionOrderItem : orderItems) {
				Long itemQuantity = inspectionOrderItem.getQuantity();
				if (itemQuantity == null || itemQuantity < 0) {
					logger.debug(
							String.format("InspectionOrderItem with id %s has %s item quantity."
									+ " Skipping items counting for InspectionDeliveryProtocol with id %s."),
							inspectionOrderItem.getId(), itemQuantity, from.getId());
				}
				itemsCount += itemQuantity;
			}
		}
		dto.setItemsCount(itemsCount);
	}

	private void setWeight(InspectionDeliveryProtocol from, InspectionDeliveryProtocolLightDto dto) {
		BigDecimal weight = new BigDecimal("0");

		for (InspectionOrder order : from.getInspectionOrders()) {
			if (order.getPackagedWeight() != null) {
				weight = weight.add(order.getPackagedWeight());
			} else {
				logger.debug("InspectionOrder " + order.getId() + " has no weight set"
						+ "Cannot calculate weight for InspectionDeliveryProtocol with id " + from.getId());
				return;
			}
		}

		dto.setWeight(weight);
	}

}
