package bg.demax.inspections.backend.converter.orders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.orders.InspectionDeliveryProtocolMediumDto;
import bg.demax.inspections.backend.entity.inspection.InspectionDeliveryProtocol;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionDeliveryProtocolToInspectionDeliveryProtocolMediumDtoConverter
				implements Converter<InspectionDeliveryProtocol, InspectionDeliveryProtocolMediumDto> {

	@Autowired
	private InspectionDeliveryProtocolToInspectionDeliveryProtocolLightDtoConverter lightConverter;

	@Override
	public InspectionDeliveryProtocolMediumDto convert(InspectionDeliveryProtocol from) {
		InspectionDeliveryProtocolMediumDto dto = new InspectionDeliveryProtocolMediumDto();

		convert(from, dto);

		return dto;
	}

	public void convert(InspectionDeliveryProtocol from, InspectionDeliveryProtocolMediumDto dto) {
		dto = dto != null ? dto : new InspectionDeliveryProtocolMediumDto();

		lightConverter.convert(from, dto);

		if (from.getBillOfLading() != null) {
			dto.setOrdersCount(from.getInspectionOrders().size());
			dto.setOrgUnitName(from.getInspectionOrders().get(0).getPermitLine().getPermit().getOrgUnit().getShortName());
		} else {
			dto.setOrdersCount(null);
			dto.setOrgUnitName(null);
		}

	}

}
