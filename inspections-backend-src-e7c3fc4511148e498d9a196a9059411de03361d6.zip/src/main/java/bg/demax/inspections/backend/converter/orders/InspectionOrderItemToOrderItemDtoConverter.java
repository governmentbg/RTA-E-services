package bg.demax.inspections.backend.converter.orders;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.orders.OrderItemDto;
import bg.demax.inspections.backend.entity.inspection.InspectionOrderItem;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionOrderItemToOrderItemDtoConverter implements Converter<InspectionOrderItem, OrderItemDto> {

	@Override
	public OrderItemDto convert(InspectionOrderItem orderItem) {
		OrderItemDto dto = new OrderItemDto();
		
		if (orderItem.getFromNum() != null && orderItem.getFromNum() > 0) {
			dto.setFromNum(orderItem.getFromNum());
		}
		
		if (orderItem.getToNum() != null && orderItem.getToNum() > 0) {
			dto.setToNum(orderItem.getToNum());
		}
		
		dto.setId(orderItem.getId());
		dto.setQuantity(orderItem.getQuantity());
		dto.setProductId(orderItem.getProduct().getId());
		dto.setProductName(orderItem.getProduct().getProductName());
		return dto;
	}
}
