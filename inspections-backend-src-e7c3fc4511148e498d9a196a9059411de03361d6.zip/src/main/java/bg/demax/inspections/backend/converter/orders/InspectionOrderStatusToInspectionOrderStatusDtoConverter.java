package bg.demax.inspections.backend.converter.orders;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.orders.InspectionOrderStatusDto;
import bg.demax.inspections.backend.entity.inspection.InspectionOrderStatus;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionOrderStatusToInspectionOrderStatusDtoConverter 
	implements Converter<InspectionOrderStatus, InspectionOrderStatusDto> {

	@Override
	public InspectionOrderStatusDto convert(InspectionOrderStatus from) {
		InspectionOrderStatusDto dto = new InspectionOrderStatusDto();
		
		dto.setCode(from.getCode());
		dto.setDescription(from.getShortDescription());
		
		return dto;
	}

}
