package bg.demax.inspections.backend.converter.orders;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.orders.OrderStatusDto;
import bg.demax.inspections.backend.entity.inspection.InspectionOrderStatus;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionOrderStatusToOrderStatusDtoConverter implements Converter<InspectionOrderStatus, OrderStatusDto> {

	@Override
	public OrderStatusDto convert(InspectionOrderStatus status) {
		OrderStatusDto dto = new OrderStatusDto();
		dto.setCode(status.getCode());
		dto.setDesctiption(status.getShortDescription());
		return dto;
	}
}
