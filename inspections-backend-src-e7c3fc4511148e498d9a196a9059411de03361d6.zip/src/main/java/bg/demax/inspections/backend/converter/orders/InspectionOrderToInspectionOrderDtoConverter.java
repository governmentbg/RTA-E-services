package bg.demax.inspections.backend.converter.orders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.BillOfLadingDto;
import bg.demax.inspections.backend.dto.orders.InspectionOrderDto;
import bg.demax.inspections.backend.dto.orders.OrderItemDto;
import bg.demax.inspections.backend.entity.inspection.InspectionDeliveryProtocolBillOfLading;
import bg.demax.inspections.backend.entity.inspection.InspectionOrder;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.City;
import bg.demax.pub.entity.OrgUnit;
import bg.demax.pub.entity.SubjectVersion;

@Component
public class InspectionOrderToInspectionOrderDtoConverter implements Converter<InspectionOrder, InspectionOrderDto> {
	private static final String INVOID_ADDRESS_PARTS_SEPARATOR = ", ";

	@Autowired
	private ConversionService conversionService;

	@Override
	public InspectionOrderDto convert(InspectionOrder from) {
		InspectionOrderDto dto = new InspectionOrderDto();

		InspectionOrderToInspectionOrderLightDtoConverter.convert(from, dto);

		SubjectVersion subjectVersion = from.getSubjectVersion();
		InspectionDeliveryProtocolBillOfLading billOfLading = null;
		if (from.getDeliveryProtocol() != null && from.getDeliveryProtocol().getBillOfLading() != null) {
			billOfLading = from.getDeliveryProtocol().getBillOfLading();			
		}

		boolean hasDeliveryProtocol = from.getDeliveryProtocol() != null;
		InspectionDeliveryProtocolBillOfLading bol = hasDeliveryProtocol ? from.getDeliveryProtocol().getBillOfLading()
				: null;
		OrgUnit orgUnit = from.getPermitLine().getPermit().getOrgUnit();

		City city = from.getCity();
		StringBuilder invoiceAddresBuilder = new StringBuilder();
		invoiceAddresBuilder.append(city.getRegion().getName())
					.append(INVOID_ADDRESS_PARTS_SEPARATOR)
					.append(city.getMunicipality().getName())
					.append(INVOID_ADDRESS_PARTS_SEPARATOR)
					.append(city.getName())
					.append(INVOID_ADDRESS_PARTS_SEPARATOR)
					.append(from.getSubjectVersion().getBaseAddress());

		String invoiceAddress = invoiceAddresBuilder.toString().toUpperCase();

		dto.setAccountantCode(from.getAccountantCode());
		dto.setAccountantName(from.getAccountantName());
		dto.setActivationCode(from.getActivationCode());
		dto.setHasBankStatement(from.getHasBankStatment());
		dto.setInvoiceAddress(invoiceAddress);
		dto.setInvoiceDateTime(from.getInvoiceDate());
		dto.setInvoiceNumber(from.getInvoiceNum());
		dto.setManagerName(subjectVersion.getManagerName());
		dto.setManagerPhoneNumber(subjectVersion.getPhoneNumber());
		if (billOfLading != null && billOfLading.getRecipientAddress() != null && billOfLading.getRecipientPersonPhone() != null) {
			dto.setReceptionAddress(billOfLading.getRecipientAddress());
			dto.setReceptionPhone(billOfLading.getRecipientPersonPhone());	
		} else {
			dto.setReceptionAddress(orgUnit.getAddress());
			dto.setReceptionPhone(orgUnit.getPhoneNumber());		
		}
		dto.setVatNumber(subjectVersion.getVatNumber());

		if (bol != null) {
			BillOfLadingDto bolDto = conversionService.convert(bol, BillOfLadingDto.class);
			dto.setBillOfLadingDto(bolDto);
		}

		dto.setOrderItems(conversionService.convertList(from.getOrderItems(), OrderItemDto.class));
		return dto;
	}

}
