package bg.demax.inspections.backend.converter.orders;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.entity.inspection.InspectionOrder;
import bg.demax.inspections.backend.export.report.order.OrderInvoiceReportRow;
import bg.demax.inspections.backend.vo.techinsp.InspectionOrderInvoicePrintVo;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionOrderToInspectionOrderInvoicePrintVoConverter implements Converter<InspectionOrder, InspectionOrderInvoicePrintVo> {

	@Autowired
	private ConversionService conversionService;
	
	@Override
	public InspectionOrderInvoicePrintVo convert(InspectionOrder from) {
		InspectionOrderInvoicePrintVo vo = new InspectionOrderInvoicePrintVo();
		
		vo.setAccountantName(from.getAccountantName());
		vo.setInvoiceNum(from.getInvoiceNum().toString());
		vo.setOrderDatetime(from.getOrderDatetime());
		vo.setSubjectVersionName(from.getSubjectVersion().getFullNameIfMissingCyr());
		vo.setCityName(from.getCity().getName());
		vo.setSubjectVersionAddress(from.getSubjectVersion().getBaseAddress());
		vo.setSubjectVersionIdentityNumber(from.getSubjectVersion().getSubject().getIdentityNumber());
		vo.setSubjectVersionVatNumber(from.getSubjectVersion().getVatNumber());
		
		vo.setOrderIssuerName(from.getOrderIssuer().getSubjectVersion().getFullNameIfMissingCyr());
		vo.setOrderIssuerAddress(from.getOrderIssuer().getSubjectVersion().getBaseAddress());
		vo.setOrderIssuerIdentityNumber(from.getOrderIssuer().getSubjectVersion().getSubject().getIdentityNumber());
		vo.setOrderIssuerVatNumber(from.getOrderIssuer().getSubjectVersion().getVatNumber());
		vo.setOrderIssuerBankName(from.getOrderIssuer().getBankName());
		vo.setOrderIssuerIban(from.getOrderIssuer().getIban());
		vo.setOrderIssuerBic(from.getOrderIssuer().getBic());
		vo.setLogo(from.getOrderIssuer().getLogo());
		
		List<OrderInvoiceReportRow> rows = conversionService.convertList(from.getOrderItems(), OrderInvoiceReportRow.class);
		vo.setRows(rows);
		
		return vo;
	}

}
