package bg.demax.inspections.backend.converter.orders;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.entity.inspection.InspectionOrder;
import bg.demax.inspections.backend.vo.techinsp.InspectionOrderLabelVo;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionOrderToInspectionOrderLabelVoConverter implements Converter<InspectionOrder, InspectionOrderLabelVo> {

	@Override
	public InspectionOrderLabelVo convert(InspectionOrder from) {
		InspectionOrderLabelVo vo = new InspectionOrderLabelVo();
		
		vo.setOrderId(Long.toString(from.getId()));
		vo.setOrgUnitName(from.getPermitLine().getPermit().getOrgUnit().getShortName());
		vo.setKtpName(from.getPermitLine().getPermit().getKtpName());
		vo.setPermitNumber(Integer.toString(from.getPermitLine().getPermit().getPermitNumber()));
		vo.setActivationCode(from.getActivationCode());
		vo.setSubjectVersionName(from.getSubjectVersion().getFullNameIfMissingCyr());
		vo.setSubjectVersionIdentityNumber(from.getSubjectVersion().getSubject().getIdentityNumber());
		vo.setSubjectVersionManagerName(from.getSubjectVersion().getManagerName());
		vo.setSubjectVersionPhoneNumber(from.getSubjectVersion().getPhoneNumber());
		vo.setOrderIssuerName(from.getOrderIssuer().getSubjectVersion().getFullNameIfMissingCyr());
		vo.setOrderIssuerAddress(from.getOrderIssuer().getSubjectVersion().getBaseAddress());
		vo.setOrderIssuerPhoneNumber(from.getOrderIssuer().getSubjectVersion().getPhoneNumber());
		
		return vo;
	}

}
