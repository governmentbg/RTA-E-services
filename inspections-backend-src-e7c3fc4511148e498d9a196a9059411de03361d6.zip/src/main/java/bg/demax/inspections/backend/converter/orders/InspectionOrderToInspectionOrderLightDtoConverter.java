package bg.demax.inspections.backend.converter.orders;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.orders.InspectionOrderLightDto;
import bg.demax.inspections.backend.dto.orders.OrderItemDto;
import bg.demax.inspections.backend.entity.inspection.InspectionDeliveryProtocolBillOfLading;
import bg.demax.inspections.backend.entity.inspection.InspectionOrder;
import bg.demax.inspections.backend.entity.inspection.InspectionOrderItem;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.OrgUnit;

@Component
public class InspectionOrderToInspectionOrderLightDtoConverter implements Converter<InspectionOrder, InspectionOrderLightDto> {
	private static final Logger logger = LogManager
			.getLogger(InspectionOrderToInspectionOrderLightDtoConverter.class);
	
	@Autowired
	private ConversionService conversionService;

	@Override
	public InspectionOrderLightDto convert(InspectionOrder from) {
		
		InspectionOrderLightDto dto = new InspectionOrderLightDto();
		convert(from, dto);
		
		dto.setOrderItems(conversionService.convertList(from.getOrderItems(), OrderItemDto.class));
		return dto;
	}

	public static void convert(InspectionOrder from, InspectionOrderLightDto dto) {

		OrgUnit orgUnit = from.getPermitLine().getPermit().getOrgUnit();
		dto.setId(from.getId());
		dto.setCreatedAt(from.getOrderDatetime());
		
		InspectionDeliveryProtocolBillOfLading billOfLading = null;
		if (from.getDeliveryProtocol() != null && from.getDeliveryProtocol().getBillOfLading() != null) {
			billOfLading = from.getDeliveryProtocol().getBillOfLading();			
		}
		
		if (billOfLading != null && billOfLading.getRecipientPersonName() != null) {
			dto.setReceptionName(billOfLading.getRecipientPersonName());
		} else {
			dto.setReceptionName(orgUnit.getShortName());
		}
		
		dto.setStatusCode(from.getOrderStatus().getCode());
		
		dto.setCompanyName(from.getSubjectVersion().getFullName());
		dto.setEik(from.getSubjectVersion().getSubject().getIdentityNumber());
		
		dto.setPermitNumber(from.getPermitLine().getPermit().getPermitNumber());
		dto.setManagerPhoneNumber(from.getSubjectVersion().getPhoneNumber());
		
		Long totalQuantity = new Long(0);
		
		for (InspectionOrderItem item : from.getOrderItems()) {
			if (item.getQuantity() != null && item.getQuantity() > 0) {
				totalQuantity += item.getQuantity();
			} else {
				logger.debug(String.format("Skipping item quantity calculations for order %s as item %s has no quantity.",
							from.getId(), item.getId()));
				totalQuantity = null;
				break;
			}
			
		}
		
		dto.setQuantity(totalQuantity);
		dto.setWeight(from.getPackagedWeight());
	}

}
