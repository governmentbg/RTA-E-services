package bg.demax.inspections.backend.converter.orders;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.orders.InspectionOrderReportListItemDto;
import bg.demax.inspections.backend.entity.inspection.InspectionOrder;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Permit;

@Component
public class InspectionOrderToInspectionOrderReportListItemDtoConverter 
	implements Converter<InspectionOrder, InspectionOrderReportListItemDto> {

	@Override
	public InspectionOrderReportListItemDto convert(InspectionOrder from) {
		InspectionOrderReportListItemDto dto = new InspectionOrderReportListItemDto();
		Permit permit = from.getPermitLine().getPermit();
		
		dto.setId(from.getId());
		dto.setPermitNumber(permit.getPermitNumber());
		if (permit.getSubjectVersion() != null) {
			dto.setCompanyName(permit.getSubjectVersion().getFullName());
		}
		if (permit.getOrgUnit() != null) {
			dto.setOrgUnit(permit.getOrgUnit().getShortName());
		}
		dto.setOrderDateTime(from.getOrderDatetime());
		dto.setActivationDateTime(from.getActivationDatetime());
		dto.setInvoiceNumber(from.getInvoiceNum());
		if (from.getInvoiceDate() != null ) {
			dto.setInvoiceDate(from.getInvoiceDate().toLocalDate());
		}
		if (from.getOrderStatus() != null) {
			dto.setStatus(from.getOrderStatus().getShortDescription());
		}
		dto.setHasBankStatement(from.getHasBankStatment());
		
		return dto;
	}

}
