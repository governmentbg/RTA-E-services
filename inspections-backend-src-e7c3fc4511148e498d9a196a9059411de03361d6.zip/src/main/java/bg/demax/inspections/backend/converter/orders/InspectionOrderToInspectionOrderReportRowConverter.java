package bg.demax.inspections.backend.converter.orders;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.config.InspectionWebConstants;
import bg.demax.inspections.backend.entity.inspection.InspectionOrder;
import bg.demax.inspections.backend.export.report.order.InspectionOrderReportRow;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Permit;

@Component
public class InspectionOrderToInspectionOrderReportRowConverter implements Converter<InspectionOrder, InspectionOrderReportRow> {

	@Override
	public InspectionOrderReportRow convert(InspectionOrder from) {
		InspectionOrderReportRow row = new InspectionOrderReportRow();
		Permit permit = from.getPermitLine().getPermit();
		row.setPermitNumber(String.valueOf(permit.getPermitNumber()));
		row.setCompanyName(from.getSubjectVersion().getFullName());
		row.setOrgUnit(permit.getOrgUnit().getShortName());
		row.setOrderDate(from.getOrderDatetime().format(InspectionWebConstants.DATE_TIME_FORMATTER));
		row.setActivationDate(from.getActivationDatetime() != null
						? from.getActivationDatetime().format(InspectionWebConstants.DATE_TIME_FORMATTER)
						: "-");
		String invoiceDate = from.getInvoiceDate() != null ? from.getInvoiceDate().format(InspectionWebConstants.DATE_FORMATTER) : "-";
		String invoiceNumberAndDate = String.format("%s/ %s", from.getInvoiceNum(), invoiceDate);
		row.setInvoiceNumberAndDate(invoiceNumberAndDate);
		row.setStatus(from.getOrderStatus().getShortDescription());
		row.setHasBankStatement(from.getHasBankStatment() ? "Да" : "Не");
		return row;
	}

}
