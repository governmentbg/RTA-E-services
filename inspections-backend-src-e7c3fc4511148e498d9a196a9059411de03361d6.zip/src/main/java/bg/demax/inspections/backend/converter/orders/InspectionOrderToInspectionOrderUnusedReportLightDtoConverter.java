package bg.demax.inspections.backend.converter.orders;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.orders.InspectionOrderUnusedReportLightDto;
import bg.demax.inspections.backend.entity.inspection.InspectionOrder;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionOrderToInspectionOrderUnusedReportLightDtoConverter 
		implements Converter<InspectionOrder, InspectionOrderUnusedReportLightDto> {
	
	@Override
	public InspectionOrderUnusedReportLightDto convert(InspectionOrder from) {
		
		InspectionOrderUnusedReportLightDto dto = new InspectionOrderUnusedReportLightDto();
		dto.setId(from.getId());
		dto.setCreatedAt(from.getOrderDatetime());
		dto.setActivatedAt(from.getActivationDatetime());
		
		return dto;
	}
}
