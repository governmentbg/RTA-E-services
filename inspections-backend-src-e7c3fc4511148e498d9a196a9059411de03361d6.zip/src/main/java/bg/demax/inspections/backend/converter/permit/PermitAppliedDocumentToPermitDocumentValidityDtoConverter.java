package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitDocumentValidityDto;
import bg.demax.inspections.backend.entity.permit.PermitAppliedDocumentExt;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitAppliedDocumentToPermitDocumentValidityDtoConverter 
	implements Converter<PermitAppliedDocumentExt, PermitDocumentValidityDto> {


	@Override
	public PermitDocumentValidityDto convert(PermitAppliedDocumentExt from) {
		PermitDocumentValidityDto dto = new PermitDocumentValidityDto();
		dto.setDocNumber(from.getDocument().getNumber());
		dto.setDocTypeId(from.getDocument().getType().getCode());
		dto.setDocumentType(from.getDocument().getType().getDescription());
		dto.setDocumentId(from.getDocument().getId());
		dto.setPermitId(from.getDocument().getPermit().getId());
		dto.setValidFrom(from.getDocument().getValidFrom());
		dto.setValidTo(from.getDocument().getValidTo());

		return dto;
	}
}
