package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitDetailsDocumentVersionDto;
import bg.demax.inspections.backend.entity.permit.PermitDocumentVersion;
import bg.demax.inspections.backend.util.PermitReportUtil;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.PermitAppliedDocument;

@Component
public class PermitDocumentVersionToPermitDetailsDocumentVersionDtoConverter 
	implements Converter<PermitDocumentVersion, PermitDetailsDocumentVersionDto> {

	@Override
	public PermitDetailsDocumentVersionDto convert(PermitDocumentVersion from) {
		PermitDetailsDocumentVersionDto dto = new PermitDetailsDocumentVersionDto();
		PermitAppliedDocument document = from.getDocument();
		
		dto.setId(from.getId());
		dto.setType(document.getType().getDescription());
		if (document.getValidTo() != null) {
			dto.setStatus(PermitReportUtil.getDocumentStatus(from.getStatus().getCode(), document.getValidTo()));
		} else {
			dto.setStatus(from.getStatus().getCode());
		}
		dto.setValidTo(document.getValidTo());
		dto.setIssuedOn(document.getIssuedDate());
		dto.setIsApproved(document.getIsApproved());
		
		return dto;
	}

}
