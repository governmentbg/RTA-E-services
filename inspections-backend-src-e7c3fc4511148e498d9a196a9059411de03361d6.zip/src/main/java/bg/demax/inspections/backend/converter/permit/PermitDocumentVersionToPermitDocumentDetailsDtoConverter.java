package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitDocumentDetailsDto;
import bg.demax.inspections.backend.entity.permit.PermitDocumentVersion;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.PermitAppliedDocument;

@Component
public class PermitDocumentVersionToPermitDocumentDetailsDtoConverter 
	implements Converter<PermitDocumentVersion, PermitDocumentDetailsDto> {
	
	@Override
	public PermitDocumentDetailsDto convert(PermitDocumentVersion from) {
		
		PermitAppliedDocument doc = from.getDocument();
		PermitDocumentDetailsDto dto = new PermitDocumentDetailsDto();
		dto.setDocNumber(doc.getNumber());
		dto.setDocTypeId(doc.getType().getCode());
		dto.setDocTypeName(doc.getType().getDescription());
		dto.setIssuedOn(doc.getIssuedDate());
		dto.setIssuer(doc.getIssuer());
		dto.setRemarks(doc.getRemark());
		dto.setValidFrom(doc.getValidFrom());
		dto.setValidTo(doc.getValidTo());
		dto.setStatus(from.getStatus().getCode());
		
		dto.setIsApproved(doc.getIsApproved());
				
		return dto;
	}
}
