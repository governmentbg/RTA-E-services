package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.inspections.PermitInspectionDto;
import bg.demax.inspections.backend.entity.permit.PermitInspection;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitInspectionToPermitInspectionDtoConverter implements Converter<PermitInspection, PermitInspectionDto> {

	@Override
	public PermitInspectionDto convert(PermitInspection from) {
		PermitInspectionDto dto = new PermitInspectionDto();
		
		dto.setId(from.getId());
		dto.setInspectionDate(from.getInspectionDate());
		dto.setInspectionProtocolNumber(from.getInspectionProtocolNumber());
		dto.setInspectionPaymentNumber(from.getInspectionPaymentNumber());
		dto.setInspectionProtocolDate(from.getInspectionProtocolDate());
		dto.setConclusion(from.getConclusion());
		
		return dto;
	}

}
