package bg.demax.inspections.backend.converter.permit;

import java.util.TreeSet;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CategoryLPermitHtmlReportDto;
import bg.demax.inspections.backend.entity.permit.PermitInfo;
import bg.demax.inspections.backend.entity.permit.PermitLink;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Permit;
import bg.demax.techinsp.entity.PermitLine;

@Component
public class PermitLinkToCategoryLPermitHtmlReportDtoConverter implements Converter<PermitLink, CategoryLPermitHtmlReportDto> {

	@Override
	public CategoryLPermitHtmlReportDto convert(PermitLink from) {
		CategoryLPermitHtmlReportDto dto = new CategoryLPermitHtmlReportDto();
		Permit permit = from.getPermit();
		PermitInfo info = from.getLastApprovedVersion().getPermitInfo();
		
		dto.setPermitNumber(permit.getPermitNumber());
		
		if (permit.getSubjectVersion() != null) {
			dto.setCompanyName(permit.getSubjectVersion().getFullName());
		}
		
		dto.setAddress(permit.getKtpAddress());
		dto.setPhoneNumber(info.getContactKtpPhone());
		
		if (permit.getKtpCity() != null) {
			dto.setCity(permit.getKtpCity().getName());
			
			if (permit.getKtpCity().getRegion() != null) {
				dto.setRegion(permit.getKtpCity().getRegion().getName());
			}
		}
		
		if (permit.getKtpCategory() != null) {
			dto.setKtpCategory(permit.getKtpCategory().getCode());
		}
		
		TreeSet<String> categories = new TreeSet<>();
		dto.setCategories(categories);
		for (PermitLine line : permit.getPermitLines().stream()
				.filter(l -> l.getIsValid() != null && l.getIsValid()).collect(Collectors.toList())) {
			categories.addAll(line.getCategories().stream()
					.filter(c -> c.getVehicleCategory() != null)
					.map(c -> c.getVehicleCategory().getCode())
					.collect(Collectors.toList()));
		}
		
		return dto;
	}

}
