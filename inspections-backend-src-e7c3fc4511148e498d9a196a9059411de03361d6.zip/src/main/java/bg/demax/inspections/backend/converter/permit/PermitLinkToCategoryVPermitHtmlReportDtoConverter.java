package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CategoryVPermitHtmlReportDto;
import bg.demax.inspections.backend.entity.permit.PermitInfo;
import bg.demax.inspections.backend.entity.permit.PermitLink;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Permit;

@Component
public class PermitLinkToCategoryVPermitHtmlReportDtoConverter implements Converter<PermitLink, CategoryVPermitHtmlReportDto> {

	@Override
	public CategoryVPermitHtmlReportDto convert(PermitLink from) {
		CategoryVPermitHtmlReportDto dto = new CategoryVPermitHtmlReportDto();
		Permit permit = from.getPermit();
		PermitInfo permitInfo = from.getLastApprovedVersion().getPermitInfo();
		
		dto.setPermitNumber(permit.getPermitNumber());
		
		if (permit.getSubjectVersion() != null) {
			dto.setCompanyName(permit.getSubjectVersion().getFullName());
		}
		
		dto.setAddress(permit.getKtpAddress());
		dto.setPhoneNumber(permitInfo.getContactKtpPhone());
		
		if (permit.getKtpCity() != null) {
			dto.setCity(permit.getKtpCity().getName());
			
			if (permit.getKtpCity().getRegion() != null) {
				dto.setRegion(permit.getKtpCity().getRegion().getName());
			}
		}
		
		return dto;
	}

}
