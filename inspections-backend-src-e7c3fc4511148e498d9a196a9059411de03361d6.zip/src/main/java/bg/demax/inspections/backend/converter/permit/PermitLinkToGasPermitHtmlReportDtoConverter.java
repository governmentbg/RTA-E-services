package bg.demax.inspections.backend.converter.permit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CategoryLPermitHtmlReportDto;
import bg.demax.inspections.backend.dto.GasPermitHtmlReportDto;
import bg.demax.inspections.backend.entity.permit.PermitLink;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitLinkToGasPermitHtmlReportDtoConverter implements Converter<PermitLink, GasPermitHtmlReportDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public GasPermitHtmlReportDto convert(PermitLink from) {
		return (GasPermitHtmlReportDto) conversionService.convert(from, CategoryLPermitHtmlReportDto.class);
	}

}
