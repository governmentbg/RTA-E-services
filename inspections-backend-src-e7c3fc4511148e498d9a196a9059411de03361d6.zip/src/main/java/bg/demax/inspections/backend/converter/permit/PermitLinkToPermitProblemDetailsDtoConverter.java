package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.problem.PermitProblemDetailsDto;
import bg.demax.inspections.backend.entity.permit.PermitAdditionalInfoVersion;
import bg.demax.inspections.backend.entity.permit.PermitLink;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Permit;

@Component
public class PermitLinkToPermitProblemDetailsDtoConverter implements Converter<PermitLink, PermitProblemDetailsDto> {

	@Override
	public PermitProblemDetailsDto convert(PermitLink from) {
		Permit permit = from.getPermit();
		PermitProblemDetailsDto dto = new PermitProblemDetailsDto();
		dto.setId(permit.getId());

		if (from.getPermit() != null && from.getPermit().getKtpCity() != null
				&& from.getPermit().getKtpCity().getName() != null) {
			dto.setCity(from.getPermit().getKtpCity().getName());
		}
		dto.setCompanyName(permit.getSubjectVersion().getFullName());
		dto.setIdentityNumber(permit.getSubject().getIdentityNumber());

		if (from.getLastApprovedVersion() != null && from.getLastApprovedVersion().getAdditionalInfo() != null) {
			PermitAdditionalInfoVersion permitAdditionalInfo = from.getLastApprovedVersion().getAdditionalInfo();
			if (permitAdditionalInfo.getContactPersonPhone() != null) {
				dto.setContactNumber(permitAdditionalInfo.getContactPersonPhone());
				if (permitAdditionalInfo.getContactPersonStationaryPhone() != null) {
					dto.setContactNumber(
							dto.getContactNumber() + ", " + permitAdditionalInfo.getContactPersonStationaryPhone());
				}
			} else {
				if (permitAdditionalInfo.getContactPersonStationaryPhone() != null) {
					dto.setContactNumber(permitAdditionalInfo.getContactPersonStationaryPhone());
				}
			}

			if (permitAdditionalInfo.getContactPersonName() != null) {
				dto.setContactPerson(permitAdditionalInfo.getContactPersonName());
			}

			if (permitAdditionalInfo.getKtpRealAddress() != null) {
				dto.setAddress(permitAdditionalInfo.getKtpRealAddress());
			}
		}
		return dto;
	}

}
