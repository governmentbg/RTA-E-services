package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.SemtPermitHtmlReportDto;
import bg.demax.inspections.backend.entity.permit.PermitInfo;
import bg.demax.inspections.backend.entity.permit.PermitLink;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Permit;

@Component
public class PermitLinkToSemtPermitHtmlReportDtoConverter implements Converter<PermitLink, SemtPermitHtmlReportDto> {

	@Override
	public SemtPermitHtmlReportDto convert(PermitLink from) {
		SemtPermitHtmlReportDto dto = new SemtPermitHtmlReportDto();
		Permit permit = from.getPermit();
		PermitInfo info = from.getLastApprovedVersion().getPermitInfo();
		
		dto.setPermitNumber(permit.getPermitNumber());
		
		if (permit.getSubjectVersion() != null) {
			dto.setCompanyName(permit.getSubjectVersion().getFullName());
		}
		
		if (info != null) {
			dto.setPhoneNumber(info.getContactKtpPhone());			
		}

		dto.setAddress(permit.getKtpAddress());
		
		if (permit.getKtpCity() != null) {
			dto.setCity(permit.getKtpCity().getName());
			
			if (permit.getKtpCity().getRegion() != null) {
				dto.setRegion(permit.getKtpCity().getRegion().getName());
			}
		}
		
		return dto;
	}

}
