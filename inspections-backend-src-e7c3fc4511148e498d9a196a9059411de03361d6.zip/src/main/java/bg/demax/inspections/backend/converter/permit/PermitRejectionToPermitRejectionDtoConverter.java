package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.inspections.PermitRejectionDto;
import bg.demax.inspections.backend.entity.permit.PermitRejection;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitRejectionToPermitRejectionDtoConverter implements Converter<PermitRejection, PermitRejectionDto> {

	@Override
	public PermitRejectionDto convert(PermitRejection from) {
		PermitRejectionDto dto = new PermitRejectionDto();
		
		dto.setReason(from.getReason());
		dto.setDate(from.getDate());
		dto.setFilename(from.getFilename());
		
		return dto;
	}

}
