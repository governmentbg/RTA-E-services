package bg.demax.inspections.backend.converter.permit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.OrgUnitLightDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Permit;

@Component
public class PermitToPermitDtoConverter implements Converter<Permit, PermitDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public PermitDto convert(Permit from) {
		PermitDto dto = new PermitDto();
		dto.setId(from.getId());
		dto.setNumber(from.getPermitNumber());
		dto.setOrgUnit(conversionService.convert(from.getOrgUnit(), OrgUnitLightDto.class));
		return dto;
	}
}
