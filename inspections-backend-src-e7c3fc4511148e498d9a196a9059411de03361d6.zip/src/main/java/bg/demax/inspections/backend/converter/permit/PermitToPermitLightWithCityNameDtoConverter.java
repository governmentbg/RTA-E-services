package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitLightWithCityNameDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Permit;

@Component
public class PermitToPermitLightWithCityNameDtoConverter implements Converter<Permit, PermitLightWithCityNameDto> {

	@Override
	public PermitLightWithCityNameDto convert(Permit from) {
		PermitLightWithCityNameDto dto = new PermitLightWithCityNameDto();
		dto.setId(from.getId());
		dto.setNumber(from.getPermitNumber());
		dto.setPermitCityName(from.getKtpCity().getName());
		return dto;
	}
}
