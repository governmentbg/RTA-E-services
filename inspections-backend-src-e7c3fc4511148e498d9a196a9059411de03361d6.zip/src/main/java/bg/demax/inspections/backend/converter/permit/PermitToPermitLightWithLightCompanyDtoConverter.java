package bg.demax.inspections.backend.converter.permit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CompanySubjectLightDto;
import bg.demax.inspections.backend.dto.OrgUnitLightDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitLightWithLightCompanyDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Permit;

@Component
public class PermitToPermitLightWithLightCompanyDtoConverter implements Converter<Permit, PermitLightWithLightCompanyDto> {

	@Autowired
	private ConversionService conversionService;
	
	@Override
	public PermitLightWithLightCompanyDto convert(Permit permit) {
		PermitLightWithLightCompanyDto dto = new PermitLightWithLightCompanyDto();
		dto.setId(permit.getId());
		dto.setNumber(permit.getPermitNumber());
		if (permit.getSubject() != null) {
			dto.setCompany(conversionService.convert(permit.getSubject(), CompanySubjectLightDto.class));
		}
		dto.setOrgUnit(conversionService.convert(permit.getOrgUnit(), OrgUnitLightDto.class));
		return dto;
	}
}