package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitShippingInfoDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Permit;
import bg.demax.techinsp.entity.PermitAdditionalInfo;

@Component
public class PermitToPermitShippingInfoDtoConverter implements Converter<Permit, PermitShippingInfoDto> {

	@Override
	public PermitShippingInfoDto convert(Permit from) {
		PermitShippingInfoDto dto = new PermitShippingInfoDto();
		PermitAdditionalInfo info = from.getLatestAdditionalInfo();
		
		dto.setId(from.getId());
		dto.setAddress(info.getKtpRealAddress());
		dto.setRecipientPersonName(info.getContactPersonName());
		dto.setRecipientPersonPhone(info.getContactPersonPhone());
		dto.setKtpCityName(from.getKtpCity().getName());
		return dto;
	}
}
