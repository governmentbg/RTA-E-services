package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitValidityDto;
import bg.demax.inspections.backend.enums.OrgUnigControlEmails;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Permit;

@Component
public class PermitToPermitValidityDtoConverter implements Converter<Permit, PermitValidityDto> {

	@Override
	public PermitValidityDto convert(Permit from) {
		PermitValidityDto dto = new PermitValidityDto();
		dto.setId(from.getId());
		dto.setNumber(from.getPermitNumber());
		dto.setValidFrom(from.getValidFrom());
		dto.setValidTo(from.getValidTo());
		dto.setOrgUnitShortName(from.getOrgUnit().getShortName());

		dto.setExpirationEmailRecipient(
				OrgUnigControlEmails.getEmailByCode(from.getOrgUnit().getParentOrgUnit().getCode()));

		return dto;
	}
}
