package bg.demax.inspections.backend.converter.permit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CityDto;
import bg.demax.inspections.backend.dto.OrgUnitLightDto;
import bg.demax.inspections.backend.dto.UserDto;
import bg.demax.inspections.backend.dto.inspections.PermitInspectionDto;
import bg.demax.inspections.backend.dto.inspections.PermitRejectionDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitAdditionalInfoDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitCompanyDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDetailsDto;
import bg.demax.inspections.backend.entity.permit.PermitAdditionalInfoVersion;
import bg.demax.inspections.backend.entity.permit.PermitInfo;
import bg.demax.inspections.backend.entity.permit.PermitVersion;
import bg.demax.inspections.backend.service.UserService;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.City;
import bg.demax.techinsp.entity.PermitStatus;

@Component
public class PermitVersionToPermitDetailsDtoConverter implements Converter<PermitVersion, PermitDetailsDto> {
	
	@Autowired
	private ConversionService conversionService;
	
	@Autowired
	private UserService userService;
	
	@Override
	public PermitDetailsDto convert(PermitVersion from) {
		PermitDetailsDto dto = new PermitDetailsDto();
		
		PermitInfo info = from.getPermitInfo();
		
		dto.setId(from.getId());

		dto.setDraftId(from.getPermitLink().getDraftId());
		dto.setOrgUnit(conversionService.convert(info.getOrgUnit(), OrgUnitLightDto.class));
		dto.setApplicationNumber(info.getApplicationNumber());
		dto.setKtpAddress(info.getKtpAddress());
		dto.setContactKtpPhone(info.getContactKtpPhone());
		dto.setContactKtpEmail(info.getContactKtpEmail());
		if (info.getApplicationDate() != null) {
			dto.setApplicationDate(info.getApplicationDate());
		}
		dto.setPermitNumber(from.getPermitVersionNumber());
		dto.setVersionNumber(from.getVersionNumber());
		dto.setStatusCode(from.getStatus().getCode());
		if (from.getPermitLink().getIssuedOn() != null) {
			dto.setIssuedOn(from.getPermitLink().getIssuedOn());
		}
		if (info.getValidFrom() != null) {
			dto.setValidFrom(info.getValidFrom());
		}
		if (info.getValidTo() != null) {
			dto.setValidTo(info.getValidTo());
		}
		if (info.getKtpCategory() != null) {
			dto.setKtpCategory(info.getKtpCategory().getLabel());
		}
		if (info.getCloseDate() != null) {
			dto.setCloseDate(info.getCloseDate());
		}
		if (info.getStatusChange() != null) {
			dto.setStatusChangeCode(info.getStatusChange().getCode());
		}
		dto.setCloseReason(info.getCloseReason());
		if (from.getLastChangeDate() != null) {
			dto.setLastChangeDate(from.getLastChangeDate());
		}
		if (from.getListChangeDate() != null) {
			dto.setListChangeDate(from.getListChangeDate());
		}
		
		if (from.getPermitInspections() != null && !from.getPermitInspections().isEmpty()) {
			dto.setInspections(conversionService.convertList(from.getPermitInspections(), PermitInspectionDto.class));
		}
		
		if (from.getPermitLink() != null && from.getPermitLink().getPermit() != null 
			&& from.getPermitLink().getPermit().getRemarks() != null) {
			dto.setRemarks(from.getPermitLink().getPermit().getRemarks());
		}
		
		dto.setCompany(conversionService.convert(from.getSubjectVersion(), PermitCompanyDto.class));
		if (from.getAdditionalInfo() != null) {
			PermitAdditionalInfoVersion additionalInfo = from.getAdditionalInfo();
			
			PermitAdditionalInfoDto additionalInfoDto = new PermitAdditionalInfoDto();
			additionalInfoDto.setContactPersonName(additionalInfo.getContactPersonName());
			additionalInfoDto.setContactPersonPhone(additionalInfo.getContactPersonPhone());
			additionalInfoDto.setContactPersonStationaryPhone(additionalInfo.getContactPersonStationaryPhone());
			additionalInfoDto.setContactPersonEmail(additionalInfo.getContactPersonEmail());
			additionalInfoDto.setGpsE(additionalInfo.getGpsE());
			additionalInfoDto.setGpsN(additionalInfo.getGpsN());
			additionalInfoDto.setHasExteriorAntenna(additionalInfo.hasExteriorAntenna());
			additionalInfoDto.setKtpRealAddress(additionalInfo.getKtpRealAddress());
			additionalInfoDto.setKtpPostCode(additionalInfo.getKtpPostCode());
			
			City city = info.getKtpCity();
			if (city != null) {
				dto.setKtpCity(conversionService.convert(city, CityDto.class));
			}
			
			dto.setAdditionalInfo(additionalInfoDto);
		}
		
		String permitStatusCode = from.getStatus().getCode();
		
		if ((permitStatusCode.equals(PermitStatus.CREATED_CODE) 
				|| permitStatusCode.equals(PermitStatus.DRAFT_CODE)
				|| permitStatusCode.equals(PermitStatus.REJECTED_CODE)) && from.getRejection() != null) {
			dto.setRejection(conversionService.convert(from.getRejection(), PermitRejectionDto.class));
		}
		
		UserDto user = null;
		if (permitStatusCode.equals(PermitStatus.REQUESTED_CODE)) {
			user = userService.getUser(from.getPermitLink().getCreatedBy());
		} else if (permitStatusCode.equals(PermitStatus.PROCESSING_CODE)) {
			user = userService.getUser(from.getModifiedBy());
		}

		if (user != null) {
			dto.setSentToIaaaBy(user.getName());
		}

		return dto;
	}

}
