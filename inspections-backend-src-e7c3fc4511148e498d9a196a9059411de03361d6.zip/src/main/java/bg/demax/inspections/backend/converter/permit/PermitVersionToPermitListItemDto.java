package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitListItemDto;
import bg.demax.inspections.backend.entity.permit.PermitInfo;
import bg.demax.inspections.backend.entity.permit.PermitVersion;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.SubjectVersion;

@Component
public class PermitVersionToPermitListItemDto implements Converter<PermitVersion, PermitListItemDto> {

	@Override
	public PermitListItemDto convert(PermitVersion from) {
		PermitListItemDto dto = new PermitListItemDto();
		PermitInfo info = from.getPermitInfo();
		
		dto.setId(from.getId());
		dto.setApplicationDate(info.getApplicationDate());
		dto.setApplicationNum(info.getApplicationNumber());
		
		SubjectVersion companyVersion = from.getSubjectVersion();
		if (companyVersion != null) {
			dto.setCompanyName(companyVersion.getFullName());
		}
		if (companyVersion.getSubject() != null) {
			dto.setIdentityNum(companyVersion.getSubject().getIdentityNumber());
		}
		if (info.getOrgUnit() != null) {
			dto.setOrgUnit(info.getOrgUnit().getShortName());
		}
		dto.setPermitNum(from.getPermitVersionNumber());
		if (from.getStatus() != null) {
			dto.setStatus(from.getStatus().getCode());
		}	
		dto.setValidTo(info.getValidTo());
		if (from.getListChangeDate() != null && from.getListPrintDate() != null) {
			dto.setIsListPrinted(from.getListChangeDate().isBefore(from.getListPrintDate()));
		} else if (from.getListPrintDate() == null) {
			dto.setIsListPrinted(false);
		} else {
			dto.setIsListPrinted(true);
		}
		return dto;
	}
}
