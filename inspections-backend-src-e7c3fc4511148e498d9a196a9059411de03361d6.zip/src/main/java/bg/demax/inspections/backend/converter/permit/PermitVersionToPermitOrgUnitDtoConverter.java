package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitOrgUnitDto;
import bg.demax.inspections.backend.entity.permit.PermitVersion;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitVersionToPermitOrgUnitDtoConverter implements Converter<PermitVersion, PermitOrgUnitDto> {

	@Override
	public PermitOrgUnitDto convert(PermitVersion from) {
		PermitOrgUnitDto result = new PermitOrgUnitDto();
		result.setId(from.getId());
		result.setNumber(from.getPermitInfo().getPermitNumber());
		result.setOrgUnit(from.getPermitInfo().getOrgUnit().getShortName());
		return result;
	}

}
