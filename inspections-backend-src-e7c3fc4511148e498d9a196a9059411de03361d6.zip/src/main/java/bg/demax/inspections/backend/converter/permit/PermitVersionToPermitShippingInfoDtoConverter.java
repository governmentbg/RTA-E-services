package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitShippingInfoDto;
import bg.demax.inspections.backend.entity.permit.PermitAdditionalInfoVersion;
import bg.demax.inspections.backend.entity.permit.PermitVersion;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitVersionToPermitShippingInfoDtoConverter implements Converter<PermitVersion, PermitShippingInfoDto> {

	@Override
	public PermitShippingInfoDto convert(PermitVersion from) {
		PermitShippingInfoDto dto = new PermitShippingInfoDto();
		PermitAdditionalInfoVersion info = from.getAdditionalInfo();
		
		dto.setId(from.getId());
		dto.setAddress(info.getKtpRealAddress());
		dto.setRecipientPersonName(info.getContactPersonName());
		dto.setRecipientPersonPhone(info.getContactPersonPhone());
		dto.setKtpCityName(from.getPermitInfo().getKtpCity().getName());
		return dto;
	}
}
