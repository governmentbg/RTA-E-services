package bg.demax.inspections.backend.converter.permit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.SubjectWithEducationLightDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.Subject;

@Component
public class SubjectToSubjectWithEducationLightDtoConverter implements Converter<Subject, SubjectWithEducationLightDto> {

	@Override
	public SubjectWithEducationLightDto convert(Subject source) {
		SubjectWithEducationLightDto dto = new SubjectWithEducationLightDto();
		dto.setId(source.getId());
		dto.setIdentityNumber(source.getIdentityNumber());
		dto.setFullName(source.getCurrentVersion().getFullNameIfMissingCyr());
		if (source.getCurrentVersion().getEducationLevel() != null) {
			dto.setEducation(source.getCurrentVersion().getEducationLevel().getDescription());
		}
		return dto;
	}

}
