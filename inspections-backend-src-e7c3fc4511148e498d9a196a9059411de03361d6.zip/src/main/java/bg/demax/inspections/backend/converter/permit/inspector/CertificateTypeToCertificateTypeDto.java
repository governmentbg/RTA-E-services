package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.stereotype.Component;

import bg.demax.legacy.util.convert.Converter;
import bg.demax.specialist.registry.common.dto.certification.EducationTypeDto;
import bg.demax.specialist.registry.common.entity.EducationType;

@Component
public class CertificateTypeToCertificateTypeDto implements Converter<EducationType, EducationTypeDto> {

	@Override
	public EducationTypeDto convert(EducationType source) {
		EducationTypeDto dto = new EducationTypeDto();
		dto.setCode(source.getCode());
		dto.setDescription(source.getDescription());
		return dto;
	}

}
