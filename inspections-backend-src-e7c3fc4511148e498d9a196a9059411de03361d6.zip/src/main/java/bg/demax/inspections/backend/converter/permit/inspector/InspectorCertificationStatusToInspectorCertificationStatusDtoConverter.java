package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.stereotype.Component;

import bg.demax.legacy.util.convert.Converter;
import bg.demax.specialist.registry.common.dto.certification.InspectorCertificationStatusDto;
import bg.demax.specialist.registry.common.entity.InspectorCertificationStatus;

@Component
public class InspectorCertificationStatusToInspectorCertificationStatusDtoConverter
				implements Converter<InspectorCertificationStatus, InspectorCertificationStatusDto> {

	@Override
	public InspectorCertificationStatusDto convert(InspectorCertificationStatus from) {
		InspectorCertificationStatusDto result = new InspectorCertificationStatusDto();
		result.setCode(from.getCode());
		result.setDescription(from.getDescription());
		return result;
	}

}
