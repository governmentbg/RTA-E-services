package bg.demax.inspections.backend.converter.permit.inspector;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.converter.AbstractInspectorCertificationConverter;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.specialist.registry.common.dto.certification.InspectorCertificationLightDto;
import bg.demax.specialist.registry.common.dto.certification.InspectorCertificationStatusDto;
import bg.demax.specialist.registry.common.entity.InspectorCertification;

@Component
public class InspectorCertificationToInspectorCertificationLightDtoConverter extends AbstractInspectorCertificationConverter
				implements Converter<InspectorCertification, InspectorCertificationLightDto> {
	@Autowired
	private ConversionService conversionService;

	@Override
	public InspectorCertificationLightDto convert(InspectorCertification source) {
		InspectorCertificationLightDto dto = new InspectorCertificationLightDto();
		dto.setId(source.getId());
		dto.setDocNumber(source.getDocumentNumber());
		dto.setStatus(conversionService.convert(source.getStatus(), InspectorCertificationStatusDto.class));
		dto.setValidityText(source.getValidityInfo().getText());
		dto.setIssuedOn(source.getIssuedOn());
		dto.setReissuedOn(source.getReissueOn());
		dto.setCategories(getCategoriesString(Arrays.asList(source)));
		dto.setInspectionTypes(getInspectionTypesString(Arrays.asList(source)));

		dto.setDocType(getCertificationDocTypeByInspectionType(dto.getInspectionTypes(), 
				source.getCourse().getEducationCategory().getType().getCode()));
		return dto;
	}

}
