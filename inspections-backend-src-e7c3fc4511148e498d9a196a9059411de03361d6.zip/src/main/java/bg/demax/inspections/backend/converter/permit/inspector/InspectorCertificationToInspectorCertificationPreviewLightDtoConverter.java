package bg.demax.inspections.backend.converter.permit.inspector;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.converter.AbstractInspectorCertificationConverter;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.specialist.registry.common.dto.certification.InspectorCertificationPreviewLightDto;
import bg.demax.specialist.registry.common.dto.certification.InspectorCertificationStatusDto;
import bg.demax.specialist.registry.common.entity.InspectorCertification;

@Component
public class InspectorCertificationToInspectorCertificationPreviewLightDtoConverter extends AbstractInspectorCertificationConverter
				implements Converter<InspectorCertification, InspectorCertificationPreviewLightDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public InspectorCertificationPreviewLightDto convert(InspectorCertification source) {
		InspectorCertificationPreviewLightDto dto = new InspectorCertificationPreviewLightDto();

		dto.setDocNumber(source.getDocumentNumber());
		dto.setIdentityNumber(source.getSubjectVersion().getSubject().getIdentityNumber());
		dto.setEducation(opt(() -> source.getSubjectVersion().getEducationLevel().getDescription()));
		dto.setIssuedOn(source.getIssuedOn());
		dto.setIssuer(source.getSchool().getIaaaDisplayName());
		dto.setName(source.getSubjectVersion().getFullNameIfMissingCyr());
		dto.setStatus(conversionService.convert(source.getStatus(), InspectorCertificationStatusDto.class));
		dto.setValidityText(source.getValidityInfo().getText());
		
		dto.setCategories(getCategoriesString(Arrays.asList(source)));
		dto.setInspectionTypes(getInspectionTypesString(Arrays.asList(source)));
		
		dto.setCertificateType(getCertificationDocTypeByInspectionType(dto.getInspectionTypes(), 
			source.getCourse().getEducationCategory().getType().getCode()));

		return dto;
	}
}
