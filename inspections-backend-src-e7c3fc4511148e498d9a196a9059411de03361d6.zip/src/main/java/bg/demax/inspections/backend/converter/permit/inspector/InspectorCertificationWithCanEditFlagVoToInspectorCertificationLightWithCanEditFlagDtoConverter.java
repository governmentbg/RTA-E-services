package bg.demax.inspections.backend.converter.permit.inspector;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.converter.AbstractInspectorCertificationConverter;
import bg.demax.inspections.backend.dto.InspectorCertificationLightWithCanEditFlagDto;
import bg.demax.inspections.backend.vo.InspectorCertificationWithCanEditFlagVo;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.specialist.registry.common.dto.certification.InspectorCertificationStatusDto;
import bg.demax.specialist.registry.common.entity.InspectorCertification;

@Component
public class InspectorCertificationWithCanEditFlagVoToInspectorCertificationLightWithCanEditFlagDtoConverter
				extends AbstractInspectorCertificationConverter
				implements Converter<InspectorCertificationWithCanEditFlagVo, InspectorCertificationLightWithCanEditFlagDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public InspectorCertificationLightWithCanEditFlagDto convert(InspectorCertificationWithCanEditFlagVo source) {
		InspectorCertificationLightWithCanEditFlagDto dto = new InspectorCertificationLightWithCanEditFlagDto();
		InspectorCertification certification = source.getCertification();

		dto.setId(certification.getId());
		dto.setDocNumber(certification.getDocumentNumber());
		dto.setStatus(conversionService.convert(certification.getStatus(), InspectorCertificationStatusDto.class));
		dto.setValidityText(certification.getValidityInfo().getText());
		dto.setIssuedOn(certification.getIssuedOn());
		dto.setReissuedOn(certification.getReissueOn());
		dto.setCategories(getCategoriesString(Arrays.asList(certification)));
		dto.setInspectionTypes(getInspectionTypesString(Arrays.asList(certification)));
		dto.setCanEdit(source.getCanEdit());
		
		
		dto.setDocType(getCertificationDocTypeByInspectionType(dto.getInspectionTypes(), 
			certification.getCourse().getEducationCategory().getType().getCode()));
			
		return dto;
	}

}
