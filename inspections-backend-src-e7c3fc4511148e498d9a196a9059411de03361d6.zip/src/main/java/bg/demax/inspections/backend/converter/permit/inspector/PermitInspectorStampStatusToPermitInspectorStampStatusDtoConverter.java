package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorStampStatusDto;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorStampStatus;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitInspectorStampStatusToPermitInspectorStampStatusDtoConverter
				implements Converter<PermitInspectorStampStatus, PermitInspectorStampStatusDto> {

	@Override
	public PermitInspectorStampStatusDto convert(PermitInspectorStampStatus from) {
		PermitInspectorStampStatusDto dto = new PermitInspectorStampStatusDto();
		dto.setCode(from.getCode());
		dto.setDescription(from.getDescription());
		return dto;
	}

}
