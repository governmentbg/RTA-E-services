package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorStampTypeDto;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorStampType;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitInspectorStampTypeToPermitInspectorStampTypeDtoConverter
				implements Converter<PermitInspectorStampType, PermitInspectorStampTypeDto> {
	
	@Override
	public PermitInspectorStampTypeDto convert(PermitInspectorStampType from) {
		PermitInspectorStampTypeDto dto = new PermitInspectorStampTypeDto();
		dto.setId(from.getId());
		dto.setDescription(from.getDescription());
		return dto;
	}
}
