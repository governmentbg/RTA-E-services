package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorStampDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorStampStatusDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorStampTypeDto;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorStampVersion;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitInspectorStampVersionToPermitInspectorStampDtoConverter
				implements Converter<PermitInspectorStampVersion, PermitInspectorStampDto> {

	@Autowired
	private ConversionService conversionService;
	
	@Override
	public PermitInspectorStampDto convert(PermitInspectorStampVersion from) {
		PermitInspectorStampDto dto = new PermitInspectorStampDto();
		dto.setId(from.getId());
		dto.setIssuedOn(from.getIssuedOn());
		dto.setRevokedOn(from.getRevokedOn());
		dto.setRemarks(from.getRemarks());
		dto.setStampNumber(from.getStampNumber());
		dto.setStatus(conversionService.convert(from.getStatus(), PermitInspectorStampStatusDto.class));
		dto.setType(conversionService.convert(from.getType(), PermitInspectorStampTypeDto.class));
		return dto;
	}

}
