package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorStampStatusDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorStampTypeDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorStampVersionDto;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorStampVersion;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitInspectorStampVersionToPermitInspectorStampVersionDtoConverter
				implements Converter<PermitInspectorStampVersion, PermitInspectorStampVersionDto> {

	@Autowired
	private ConversionService conversionService;
	
	@Override
	public PermitInspectorStampVersionDto convert(PermitInspectorStampVersion from) {
		PermitInspectorStampVersionDto dto = new PermitInspectorStampVersionDto();
		dto.setId(from.getId());
		dto.setIssuedOn(from.getIssuedOn());
		dto.setRevokedOn(from.getRevokedOn());
		dto.setStampNumber(from.getStampNumber());
		dto.setStatus(conversionService.convert(from.getStatus(), PermitInspectorStampStatusDto.class));
		dto.setType(conversionService.convert(from.getType(), PermitInspectorStampTypeDto.class));
		dto.setModifiedOn(from.getModifiedOn());
		return dto;
	}

}
