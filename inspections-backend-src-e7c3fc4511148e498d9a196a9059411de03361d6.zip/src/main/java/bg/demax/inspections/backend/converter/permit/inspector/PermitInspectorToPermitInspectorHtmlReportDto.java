package bg.demax.inspections.backend.converter.permit.inspector;

import java.util.Optional;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorHtmlReportDto;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorStampType;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.PermitInspector;
import bg.demax.techinsp.entity.PermitInspectorStamp;

@Component
public class PermitInspectorToPermitInspectorHtmlReportDto
		implements Converter<PermitInspector, PermitInspectorHtmlReportDto> {

	@Override
	public PermitInspectorHtmlReportDto convert(PermitInspector from) {
		PermitInspectorHtmlReportDto dto = new PermitInspectorHtmlReportDto();

		if (from.getSubjectVersion() != null) {
			dto.setName(from.getSubjectVersion().getFullName());
		}

		Optional<PermitInspectorStamp> stamp = from.getStamps().stream()
				.filter(s -> s.getStampType() == PermitInspectorStampType.ADR_STAMP_ID).findFirst();
		if (stamp.isPresent()) {
			dto.setStamp(stamp.get().getStampNumber());
		}

		return dto;
	}

}
