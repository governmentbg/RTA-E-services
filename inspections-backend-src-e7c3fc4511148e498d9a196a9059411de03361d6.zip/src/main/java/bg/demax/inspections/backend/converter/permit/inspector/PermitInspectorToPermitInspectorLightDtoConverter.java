package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorLightDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.PermitInspector;

@Component
public class PermitInspectorToPermitInspectorLightDtoConverter
		implements Converter<PermitInspector, PermitInspectorLightDto> {

	@Override
	public PermitInspectorLightDto convert(PermitInspector permitInspector) {
		PermitInspectorLightDto dto = new PermitInspectorLightDto();
		dto.setId(permitInspector.getId());
		dto.setName(permitInspector.getSubjectVersion().getFullNameIfMissingCyr());
		dto.setKtpName(permitInspector.getPermit().getKtpName());
		return dto;
	}

}
