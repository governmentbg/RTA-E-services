package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitDetailsPermitInspectorDto;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorInfo;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorVersion;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.SubjectVersion;

@Component
public class PermitInspectorVersionToPermitDetailsPermitInspectorDtoConverter 
	implements Converter<PermitInspectorVersion, PermitDetailsPermitInspectorDto> {

	@Override
	public PermitDetailsPermitInspectorDto convert(PermitInspectorVersion from) {
		PermitDetailsPermitInspectorDto dto = new PermitDetailsPermitInspectorDto();
		PermitInspectorInfo info = from.getPermitInspectorInfo();
		
		dto.setId(from.getId());
		
		SubjectVersion subjectVersion = from.getSubjectVersion();
		if (subjectVersion != null) {
			dto.setFullName(subjectVersion.getFullNameIfMissingCyr());
			
			if (subjectVersion.getSubject() != null) {
				dto.setIdentityNumber(subjectVersion.getSubject().getIdentityNumber());
			}
		}

		boolean isNewInspector = from.getPermits().size() == 1;
		
		if (isNewInspector && from.getPermitInspector() == null) {
			dto.setNewInspector(true);
		} else {
			dto.setNewInspector(false);
		}
		
		dto.setIsChairman(info.getIsChairman());
		dto.setStatusCode(from.getCurrentStatus());
		dto.setOrderNumber(info.getOrderNumber());
		
		return dto;
	}

}
