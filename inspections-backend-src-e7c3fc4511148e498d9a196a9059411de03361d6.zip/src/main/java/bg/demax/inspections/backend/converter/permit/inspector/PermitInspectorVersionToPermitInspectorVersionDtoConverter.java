package bg.demax.inspections.backend.converter.permit.inspector;

import static java.util.Collections.reverseOrder;
import static java.util.Comparator.comparing;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.converter.AbstractInspectorCertificationConverter;
import bg.demax.inspections.backend.dto.CityDto;
import bg.demax.inspections.backend.dto.CountryDto;
import bg.demax.inspections.backend.dto.RegionDto;
import bg.demax.inspections.backend.dto.inspections.EducationLevelDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorInfoDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorStampLightDto;
import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorVersionDto;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorInfo;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorVersion;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectWithPersonalInfoDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.SubjectVersion;
import bg.demax.specialist.registry.common.entity.InspectorCertification;

@Component
public class PermitInspectorVersionToPermitInspectorVersionDtoConverter extends AbstractInspectorCertificationConverter
		implements Converter<PermitInspectorVersion, PermitInspectorVersionDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public PermitInspectorVersionDto convert(PermitInspectorVersion from) {
		PermitInspectorVersionDto dto = new PermitInspectorVersionDto();
		PermitInspectorInfoDto infoDto = new PermitInspectorInfoDto();
		SubjectWithPersonalInfoDto subject = new SubjectWithPersonalInfoDto();

		dto.setId(from.getId());

		PermitInspectorInfo info = from.getPermitInspectorInfo();
		SubjectVersion subjectVersion = from.getSubjectVersion();

		infoDto.setId(info.getId());
		infoDto.setIsChairman(info.getIsChairman());
		infoDto.setOrderNumber(info.getOrderNumber());
		infoDto.setRemarks(info.getRemarks());
		infoDto.setSpecialityCode(info.getSpecialty().getCode());
		infoDto.setChairmanDesignationDate(info.getChairmanDesignationDate());

		subject.setId(subjectVersion.getSubject().getId());
		subject.setFullName(subjectVersion.getFullNameIfMissingCyr());
		subject.setFirstName(subjectVersion.getFirstNameCyr().getOriginal());
		if (subjectVersion.getSurnameCyr() != null) {
			subject.setSurname(subjectVersion.getSurnameCyr().getOriginal());
		}
		subject.setFamilyName(subjectVersion.getFamilyNameCyr().getOriginal());
		subject.setIdentityNumber(subjectVersion.getSubject().getIdentityNumber());
		subject.setSubjectVersionId(subjectVersion.getId());
		subject.setBirthDate(subjectVersion.getSubject().getBirthDate());
		subject.setAddress(subjectVersion.getBaseAddress());
		subject.setCountry(conversionService.convert(subjectVersion.getSubject().getCountry(), CountryDto.class));
		if (subjectVersion.getCity() != null) {
			subject.setRegion(conversionService.convert(subjectVersion.getCity().getRegion(), RegionDto.class));
			subject.setCity(conversionService.convert(subjectVersion.getCity(), CityDto.class));
		}

		if (subjectVersion.getEducationLevel() == null) {
			subject.setEducationLevel(null);
		} else {
			subject.setEducationLevel(
					conversionService.convert(subjectVersion.getEducationLevel(), EducationLevelDto.class));
		}

		dto.setInfo(infoDto);
		dto.setSubjectWithEducation(subject);
		dto.setLastModifiedOn(from.getChangeDate());
		dto.setIncludedOn(from.getIncludedOn());
		dto.setExcludedOn(from.getExcludedOn());
		dto.setStatusCode(from.getCurrentStatus());

		List<PermitInspectorStampLightDto> stampDtos = conversionService.convertList(from.getStamps(),
				PermitInspectorStampLightDto.class);

		Comparator<PermitInspectorStampLightDto> comparator = comparing(PermitInspectorStampLightDto::getIssuedOn).reversed()
				.thenComparing(reverseOrder(comparing(PermitInspectorStampLightDto::getModifiedOn)));

		stampDtos.sort(comparator);

		Map<String, List<PermitInspectorStampLightDto>> mappedStampNumberToStampVersionDtos = stampDtos.stream()
				.collect(Collectors.groupingBy(PermitInspectorStampLightDto::getStampNumber));

		List<PermitInspectorStampLightDto> lastStampsDtos = new ArrayList<>();

		mappedStampNumberToStampVersionDtos.forEach((k, v) -> {
			lastStampsDtos.add(v.get(0));
		});

		lastStampsDtos.sort(comparator);

		dto.setStamps(lastStampsDtos);

		List<InspectorCertification> certifications = from.getCertifications();

		dto.setCategories(getCategoriesString(certifications));
		dto.setInspectionTypes(getInspectionTypesString(certifications));

		return dto;
	}
}