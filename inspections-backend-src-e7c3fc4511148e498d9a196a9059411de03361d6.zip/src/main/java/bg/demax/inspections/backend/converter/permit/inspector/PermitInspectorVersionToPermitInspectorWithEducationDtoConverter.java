package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorWithEducationDto;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorVersion;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitInspectorVersionToPermitInspectorWithEducationDtoConverter
				implements Converter<PermitInspectorVersion, PermitInspectorWithEducationDto> {

	@Override
	public PermitInspectorWithEducationDto convert(PermitInspectorVersion from) {
		PermitInspectorWithEducationDto dto = new PermitInspectorWithEducationDto();
		dto.setId(from.getId());
		dto.setSubjectId(from.getSubjectVersion().getSubject().getId());
		dto.setIdentityNumber(from.getSubjectVersion().getSubject().getIdentityNumber());
		dto.setFullName(from.getSubjectVersion().getFullNameIfMissingCyr());
		
		if (from.getSubjectVersion().getEducationLevel() == null) {
			dto.setEducation(null);
		} else {
			dto.setEducation(from.getSubjectVersion().getEducationLevel().getDescription());
		}
		
		return dto;
	}

}
