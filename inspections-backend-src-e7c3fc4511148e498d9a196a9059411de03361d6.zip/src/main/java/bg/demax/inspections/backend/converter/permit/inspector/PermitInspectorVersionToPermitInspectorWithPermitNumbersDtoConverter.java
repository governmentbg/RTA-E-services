package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.inspections.PermitInspectorWithPermitNumbersDto;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorVersion;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitInspectorVersionToPermitInspectorWithPermitNumbersDtoConverter
				implements Converter<PermitInspectorVersion, PermitInspectorWithPermitNumbersDto> {

	@Override
	public PermitInspectorWithPermitNumbersDto convert(PermitInspectorVersion from) {
		PermitInspectorWithPermitNumbersDto dto = new PermitInspectorWithPermitNumbersDto();
		dto.setId(from.getId());
		dto.setFullName(from.getSubjectVersion().getFullNameIfMissingCyr());
		dto.setIdentityNumber(from.getSubjectVersion().getSubject().getIdentityNumber());
		dto.setIsChairman(from.getPermitInspectorInfo().getIsChairman());
		dto.setStatusCode(from.getCurrentStatus());
		dto.setPermitNumbers(null); // set outside of converter
		return dto;
	}

}
