package bg.demax.inspections.backend.converter.permit.inspector;

import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.entity.DocumentStatus;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorStampStatus;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorStampType;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorStampVersion;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorVersion;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectDocumentVersion;
import bg.demax.inspections.backend.exception.permit.inspector.PermitInspectorInvalidOrMissingStampException;
import bg.demax.inspections.backend.export.permit.PermitInspectorsReportRow;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.AppliedDocumentType;
import bg.demax.pub.entity.SubjectAppliedDocument;
import bg.demax.pub.entity.VehicleCategory;
import bg.demax.specialist.registry.common.entity.EducationType;
import bg.demax.specialist.registry.common.entity.InspectorCertification;
import bg.demax.techinsp.entity.InspectionType;

@Component
public class PermitInspectorVersionToPermitInspectorsReportRowConverter
		implements Converter<PermitInspectorVersion, PermitInspectorsReportRow> {

	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy г.");

	@Override
	public PermitInspectorsReportRow convert(PermitInspectorVersion from) {
		PermitInspectorsReportRow row = new PermitInspectorsReportRow();
		row.setFullName(from.getSubjectVersion().getFullNameIfMissingCyr());
		row.setIdentityNumber(from.getSubjectVersion().getSubject().getIdentityNumber());
		if (from.getSnapshot() != null) {
			List<SubjectDocumentVersion> documents = from.getSnapshot().getDocumentVersions();
			row.setDriverLicenceInfo(getDocumentInfoString(documents, AppliedDocumentType.DRIVING_LICENCE_CODE));
			row.setDiplomInfo(getDocumentInfoString(documents, AppliedDocumentType.DIPLOMA_CODE));
			row.setProfetionalQualificationInfo(
					getDocumentInfoString(documents, AppliedDocumentType.PROFESSIONAL_QUALIFICATION_CERTIFICATE));
		}
		if (from.getPermitInspector().getSubjectVersion().getEducationLevel() != null) {
			row.setEducation(from.getPermitInspector().getSubjectVersion().getEducationLevel().getDescription());
		} else {
			row.setEducation("");
		}
		row.setInitialCertificationInfo(
				getCertificateInfoStringByCertificateTypeExclundingInspetionTypes(from.getCertifications(),
						EducationType.INITIAL_CODE, InspectionType.CODE_ADR, InspectionType.CODE_GAS));
		row.setPeriodicalCertificationInfo(
				getCertificateInfoStringByCertificateTypeExclundingInspetionTypes(from.getCertifications(),
						EducationType.PERIODICAL_CODE, InspectionType.CODE_ADR, InspectionType.CODE_GAS));
		row.setVehiclesFromCat1(checkIfInspectorHasVehicleCategories(from.getCertifications(),
				VehicleCategory.INSPECTOR_CATEGORY1_CODES));
		row.setVehiclesFromCat2(checkIfInspectorHasVehicleCategories(from.getCertifications(),
				VehicleCategory.INSPECTOR_CATEGORY2_CODES));
		row.setCheckTaxi(checkIfInspectorHasInspectionType(from.getCertifications(), InspectionType.CODE_TAXI));
		row.setCheckBus(checkIfInspectorHasInspectionType(from.getCertifications(), InspectionType.CODE_BUS));
		row.setCheckBusChildren(
				checkIfInspectorHasInspectionType(from.getCertifications(), InspectionType.CODE_BUSCHILDREN));
		row.setCheckSemt(checkIfInspectorHasInspectionType(from.getCertifications(), InspectionType.CODE_SEMT));
		row.setCheckTrolley(checkIfInspectorHasInspectionType(from.getCertifications(), InspectionType.CODE_TROL));
		row.setCheckTram(checkIfInspectorHasInspectionType(from.getCertifications(), InspectionType.CODE_TRAM));
		row.setCheckTractor(checkIfInspectorHasVehicleCategory(from.getCertifications(), VehicleCategory.T_CODE));
		row.setAdrInitialCertificationInfo(getCertificateInfoStringByInspectionTypeAndCertificationType(
				from.getCertifications(), InspectionType.CODE_ADR, EducationType.INITIAL_CODE));
		row.setAdrPeriodicalCertificationInfo(getCertificateInfoStringByInspectionTypeAndCertificationType(
				from.getCertifications(), InspectionType.CODE_ADR, EducationType.PERIODICAL_CODE));
		row.setSpgInitialCertificationInfo(getCertificateInfoStringByInspectionTypeAndCertificationType(
				from.getCertifications(), InspectionType.CODE_GAS, EducationType.INITIAL_CODE));
		row.setSpgPeriodicalCertificationInfo(getCertificateInfoStringByInspectionTypeAndCertificationType(
				from.getCertifications(), InspectionType.CODE_GAS, EducationType.PERIODICAL_CODE));
		row.setIsChairman(from.getPermitInspectorInfo().getIsChairman().booleanValue() ? "Да" : "Не");

		List<PermitInspectorStampVersion> stamps = from.getStamps();
		getInspectorStampNumberByStampType(row, stamps, PermitInspectorStampType.ADR_STAMP_ID);
		getInspectorStampNumberByStampType(row, stamps, PermitInspectorStampType.INSPECTION_STAMP_ID);
		extractStampOrderNumber(row, stamps, PermitInspectorStampType.INSPECTION_STAMP_ID);

		return row;
	}

	private String getCertificateInfoStringByCertificateTypeExclundingInspetionTypes(
			List<InspectorCertification> certifications, String inspectionTypeCode, String... excludeCodes) {
		List<String> codesToIgnore = Arrays.asList(excludeCodes);
		for (InspectorCertification certification : certifications) {
			List<String> inspTypeCodes = certification.getCourse().getEducationCategory().getInspectionTypes().stream()
					.map(type -> type.getCode()).collect(Collectors.toList());
			if (certification.getCourse().getEducationCategory().getType().getCode().equals(inspectionTypeCode)
					&& !codesToIgnore.stream().anyMatch(inspTypeCodes::contains)) {
				if (certification.isValid()) {
					StringBuilder builder = new StringBuilder();
					if (certification.getDocumentNumber() != null) {
						builder.append(certification.getDocumentNumber());
					}
					if (certification.getSchool() != null) {
						if (builder.length() > 1) {
							builder.append(", ");
						}
						builder.append(certification.getSchool().getName());
					}
					return builder.append("; ").toString();
				}
			}
		}
		return "";
	}

	private void extractStampOrderNumber(PermitInspectorsReportRow row,
			List<PermitInspectorStampVersion> stamps, Short stampType) {
		PermitInspectorStampVersion stamp;
		stamps.sort(getStampComparator());
		stamp = stamps.stream()
				.filter(st -> st.getType().getId().equals(stampType)
						&& st.getStatus().getCode().equals(PermitInspectorStampStatus.VALID_CODE))
				.findFirst().orElse(null);
		if (stamp != null) {
			String stampNumber = stamp.getStampNumber();
			row.setStampOrderNumber(Short.parseShort(stampNumber.substring(stampNumber.indexOf("-") + 1)));
		} else {
			throw new PermitInspectorInvalidOrMissingStampException(row.getIdentityNumber());
		}
	}

	private void getInspectorStampNumberByStampType(PermitInspectorsReportRow row,
			List<PermitInspectorStampVersion> stamps, Short stampType) {
		PermitInspectorStampVersion stamp;
		stamps.sort(getStampComparator());
		stamp = stamps.stream()
				.filter(st -> st.getType().getId().equals(stampType)
						&& st.getStatus().getCode().equals(PermitInspectorStampStatus.VALID_CODE))
				.findFirst().orElse(null);
		if (stamp != null) {
			if (row.getStampNumber() != null) {
				row.setStampNumber(row.getStampNumber() + ", " + stamp.getStampNumber());
			} else {
				row.setStampNumber(stamp.getStampNumber());
			}
		}
	}

	private String getDocumentInfoString(List<SubjectDocumentVersion> documents, Short statusCode) {
		SubjectAppliedDocument document = documents.stream()
			.filter(docVer -> docVer.getStatus().getCode().equals(DocumentStatus.VALID_CODE))
			.map(docVer -> docVer.getDocument())
			.filter(doc -> doc.getType().getCode().equals(statusCode) && doc.getIsValid())
			.findFirst()
			.orElse(null);
		if (document != null) {
			StringBuilder builder = new StringBuilder();
			builder.append(document.getNumber());
			if (document.getIssuedDate() != null) {
				builder.append(", ");
				builder.append(document.getIssuedDate().format(formatter));
			}
			if (document.getIssuer() != null) {
				builder.append(", ");
				builder.append(document.getIssuer());
			}
			return builder.toString();
		} else {
			return "";
		}
	}

	private String getCertificateInfoStringByInspectionTypeAndCertificationType(
			List<InspectorCertification> certifications, String inspTypeCode, String certTypeCode) {
		for (InspectorCertification certification : certifications) {

			List<String> inspTypeCodes = certification.getCourse().getEducationCategory().getInspectionTypes().stream()
					.map(type -> type.getCode()).collect(Collectors.toList());
			if (certification.getCourse().getEducationCategory().getType().getCode().equals(certTypeCode)
					&& inspTypeCodes.contains(inspTypeCode)) {
				if (certification.isValid()) {
					StringBuilder builder = new StringBuilder();
					if (certification.getDocumentNumber() != null) {
						builder.append(certification.getDocumentNumber());
					}
					if (certification.getIssuedOn() != null) {
						if (builder.length() > 1) {
							builder.append(", ");
						}
						builder.append(certification.getIssuedOn().format(formatter));
					}
					if (certification.getSchool() != null) {
						builder.append(", ");
						builder.append(certification.getSchool().getName());
					}
					return builder.toString();
				}
			}
		}
		return "";
	}

	private String checkIfInspectorHasInspectionType(List<InspectorCertification> certifications, String typeCode) {
		certifications.sort(getCertificationComparator());
		if (!certifications.isEmpty()) {
			for (InspectorCertification cert : certifications) {
				for (InspectionType type : cert.getCourse().getEducationCategory().getInspectionTypes()) {
					if (typeCode.equals(type.getCode())) {
						if (cert.isValid()) {
							return "Да";
						}
					}
				}
			}
		}
		return "Не";
	}

	private String checkIfInspectorHasVehicleCategory(List<InspectorCertification> certifications,
			String categoryCode) {
		certifications.sort(getCertificationComparator());
		if (!certifications.isEmpty()) {
			for (InspectorCertification cert : certifications) {
				for (VehicleCategory category : cert.getCourse().getEducationCategory().getVehicleCategories()) {
					if (categoryCode.equals(category.getCode()) && cert.isValid()) {
						if (cert.isValid()) {
							return "Да";
						}
					}
				}
			}
		}
		return "Не";
	}

	private String checkIfInspectorHasVehicleCategories(List<InspectorCertification> certifications,
			List<String> categories) {
		for (InspectorCertification cert : certifications) {
			for (VehicleCategory cat : cert.getCourse().getEducationCategory().getVehicleCategories()) {
				if (categories.contains(cat.getCode()) && cert.isValid()) {
					if (cert.isValid()) {
						return "Да";
					}
				}
			}
		}
		return "Не";
	}

	private Comparator<PermitInspectorStampVersion> getStampComparator() {
		return new Comparator<PermitInspectorStampVersion>() {
			@Override
			public int compare(PermitInspectorStampVersion o1, PermitInspectorStampVersion o2) {
				return o2.getModifiedOn().compareTo(o1.getModifiedOn());
			}
		};
	}

	private Comparator<InspectorCertification> getCertificationComparator() {
		return new Comparator<InspectorCertification>() {
			@Override
			public int compare(InspectorCertification o1, InspectorCertification o2) {
				return o2.getIssuedOn().compareTo(o1.getIssuedOn());
			}
		};
	}
}
