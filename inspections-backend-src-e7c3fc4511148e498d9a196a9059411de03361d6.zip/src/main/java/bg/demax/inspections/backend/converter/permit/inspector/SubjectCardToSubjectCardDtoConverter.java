package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.SubjectCardDto;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectCard;
import bg.demax.legacy.util.convert.Converter;

@Component
public class SubjectCardToSubjectCardDtoConverter implements Converter<SubjectCard, SubjectCardDto> {

	@Override
	public SubjectCardDto convert(SubjectCard from) {
		SubjectCardDto dto = new SubjectCardDto();
		dto.setCardNumber(from.getCardNumber());
		dto.setCommonName(from.getCommonName());
		dto.setId(from.getId());
		dto.setIsActive(from.getIsActive());
		dto.setIssuedOn(from.getIssuedOn());
		dto.setRemarks(from.getRemarks());
		dto.setSerialNumber(from.getSerialNumber());
		return dto;
	}

}
