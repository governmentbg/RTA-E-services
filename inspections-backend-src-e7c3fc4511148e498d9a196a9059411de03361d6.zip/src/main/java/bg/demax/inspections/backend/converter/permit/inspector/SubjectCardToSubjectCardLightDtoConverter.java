package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.SubjectCardLightDto;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectCard;
import bg.demax.legacy.util.convert.Converter;

@Component
public class SubjectCardToSubjectCardLightDtoConverter implements Converter<SubjectCard, SubjectCardLightDto> {

	@Override
	public SubjectCardLightDto convert(SubjectCard from) {
		SubjectCardLightDto dto = new SubjectCardLightDto();
		dto.setId(from.getId());
		dto.setSerialNumber(from.getSerialNumber());
		dto.setCardNumber(from.getCardNumber());
		dto.setIsActive(from.getIsActive());
		return dto;
	}

}
