package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorDocumentDto;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectDocumentVersion;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.SubjectAppliedDocument;

@Component
public class SubjectDocumentVersionToPermitInspectorDocumentDtoConverter
				implements Converter<SubjectDocumentVersion, PermitInspectorDocumentDto> {

	@Override
	public PermitInspectorDocumentDto convert(SubjectDocumentVersion from) {
		PermitInspectorDocumentDto dto = new PermitInspectorDocumentDto();
		SubjectAppliedDocument doc = from.getDocument();

		dto.setDocumentNumber(doc.getNumber());
		dto.setDocumentTypeCode(doc.getType().getCode());
		dto.setId(from.getId());

		if (doc.getIssuedDate() != null) {
			dto.setIssuedOn(doc.getIssuedDate());
		} else {
			dto.setIssuedOn(doc.getValidFrom());
		}

		dto.setIssuer(doc.getIssuer());
		dto.setRemarks(doc.getRemark());
		dto.setValidTo(doc.getValidTo());
		dto.setStatus(from.getStatus().getCode());
		dto.setIsApproved(doc.getIsApproved());

		return dto;
	}

}
