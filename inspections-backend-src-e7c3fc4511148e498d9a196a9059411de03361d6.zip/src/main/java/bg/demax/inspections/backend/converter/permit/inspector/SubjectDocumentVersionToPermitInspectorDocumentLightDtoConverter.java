package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorDocumentLightDto;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectDocumentVersion;
import bg.demax.inspections.backend.util.PermitReportUtil;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.SubjectAppliedDocument;

@Component
public class SubjectDocumentVersionToPermitInspectorDocumentLightDtoConverter
				implements Converter<SubjectDocumentVersion, PermitInspectorDocumentLightDto> {

	@Override
	public PermitInspectorDocumentLightDto convert(SubjectDocumentVersion from) {
		PermitInspectorDocumentLightDto dto = new PermitInspectorDocumentLightDto();
		SubjectAppliedDocument document = from.getDocument();
		
		dto.setId(from.getId());
		dto.setDocumentNumber(document.getNumber());
		dto.setDocumentType(document.getType().getDescription());
		
		if (document.getIssuedDate() != null) {
			dto.setIssuedOn(document.getIssuedDate());
		} else {
			dto.setIssuedOn(document.getValidFrom());
		}

		if (document.getValidTo() != null) {
			dto.setValidTo(document.getValidTo());
		}
		dto.setIssuer(document.getIssuer());

		if (document.getValidTo() != null) {
			dto.setStatus(PermitReportUtil.getDocumentStatus(from.getStatus().getCode(), document.getValidTo()));
		} else {
			dto.setStatus(from.getStatus().getCode());
		}
		dto.setIsApproved(document.getIsApproved());
		
		return dto;
	}

}
