package bg.demax.inspections.backend.converter.permit.inspector;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CityDto;
import bg.demax.inspections.backend.dto.CountryDto;
import bg.demax.inspections.backend.dto.RegionDto;
import bg.demax.inspections.backend.dto.inspections.EducationLevelDto;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectWithPersonalInfoDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.Subject;

@Component
public class SubjectToSubjectWithPersonalInfoDtoConverter
	implements Converter<Subject, SubjectWithPersonalInfoDto> {

	@Autowired
	private ConversionService conversionService;
	
	@Override
	public SubjectWithPersonalInfoDto convert(Subject from) {
		SubjectWithPersonalInfoDto dto = new SubjectWithPersonalInfoDto();
		dto.setId(from.getId());
		dto.setIdentityNumber(from.getIdentityNumber());
		if (from.getCurrentVersion().getFirstNameCyr() != null) {		
			dto.setFullName(from.getCurrentVersion().getFullNameIfMissingCyr());
		}
		dto.setFirstName(from.getCurrentVersion().getFirstNameCyr().getOriginal());
		if (from.getCurrentVersion().getSurnameCyr() != null) {			
			dto.setSurname(from.getCurrentVersion().getSurnameCyr().getOriginal());
		}
		if (from.getCurrentVersion().getFamilyNameCyr() != null) {		
			dto.setFamilyName(from.getCurrentVersion().getFamilyNameCyr().getOriginal());
		}
		if (from.getCurrentVersion().getEducationLevel() != null) {
			dto.setEducationLevel(conversionService.convert(from.getCurrentVersion().getEducationLevel(), EducationLevelDto.class));
		}
		dto.setSubjectVersionId(from.getCurrentVersion().getId());
		if (from.getCountry() != null) {
			dto.setCountry(conversionService.convert(from.getCountry(), CountryDto.class));
		}
		dto.setBirthDate(from.getBirthDate());				
		if (from.getCurrentVersion().getCity() != null) {
			dto.setRegion(conversionService.convert(from.getCurrentVersion().getCity().getRegion(), RegionDto.class));
			dto.setCity(conversionService.convert(from.getCurrentVersion().getCity(), CityDto.class));
		}
		dto.setAddress(from.getCurrentVersion().getBaseAddress());

		return dto;
	}

}
