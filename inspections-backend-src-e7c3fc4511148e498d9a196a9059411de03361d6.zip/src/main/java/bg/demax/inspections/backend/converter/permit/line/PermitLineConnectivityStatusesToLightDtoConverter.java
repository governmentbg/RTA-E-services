package bg.demax.inspections.backend.converter.permit.line;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineConnectivityStatusesLightDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.PermitLineConnectivityStatuses;

@Component
public class PermitLineConnectivityStatusesToLightDtoConverter
		implements Converter<PermitLineConnectivityStatuses, PermitLineConnectivityStatusesLightDto> {

	@Override
	public PermitLineConnectivityStatusesLightDto convert(PermitLineConnectivityStatuses from) {
		PermitLineConnectivityStatusesLightDto dto = new PermitLineConnectivityStatusesLightDto();
		dto.setId(from.getId());
		dto.setConnectivityCode(from.getConnectivity().getCode());
		dto.setLastCheck(from.getLastCheck());
		dto.setIsSuccessful(from.getIsSuccessful());

		return dto;
	}

}
