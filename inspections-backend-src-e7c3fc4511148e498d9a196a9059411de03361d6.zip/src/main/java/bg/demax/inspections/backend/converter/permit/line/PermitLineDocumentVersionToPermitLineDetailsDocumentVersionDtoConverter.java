package bg.demax.inspections.backend.converter.permit.line;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineDetailsDocumentVersionDto;
import bg.demax.inspections.backend.entity.permit.line.PermitLineDocumentVersion;
import bg.demax.inspections.backend.util.PermitReportUtil;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.PermitLineDocument;

@Component
public class PermitLineDocumentVersionToPermitLineDetailsDocumentVersionDtoConverter 
	implements Converter<PermitLineDocumentVersion, PermitLineDetailsDocumentVersionDto> {

	@Override
	public PermitLineDetailsDocumentVersionDto convert(PermitLineDocumentVersion from) {
		PermitLineDetailsDocumentVersionDto dto = new PermitLineDetailsDocumentVersionDto();
		PermitLineDocument document = from.getDocument();
		
		dto.setId(from.getId());
		dto.setDocNumber(document.getNumber());
		dto.setIsApproved(document.getIsApproved());
		dto.setIssueDate(document.getIssuedDate());

		if (document.getValidTo() != null) {
			dto.setStatus(PermitReportUtil.getDocumentStatus(from.getStatus().getCode(), document.getValidTo()));
		} else {
			dto.setStatus(from.getStatus().getCode());
		}
		dto.setType(document.getType().getDescription());
		dto.setValidFrom(document.getValidFrom());
		dto.setValidTo(document.getValidTo());
		return dto;
	}
}
