package bg.demax.inspections.backend.converter.permit.line;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineDocumentDetailsDto;
import bg.demax.inspections.backend.entity.permit.line.PermitLineDocumentVersion;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.PermitLineDocument;

@Component
public class PermitLineDocumentVersionToPermitLineDocumentDetailsDtoConverter 
	implements Converter<PermitLineDocumentVersion, PermitLineDocumentDetailsDto> {

	@Override
	public PermitLineDocumentDetailsDto convert(PermitLineDocumentVersion from) {
		PermitLineDocumentDetailsDto dto = new PermitLineDocumentDetailsDto();
		PermitLineDocument doc = from.getDocument();
		
		dto.setDocNumber(doc.getNumber());
		dto.setDocTypeId(doc.getType().getCode());
		dto.setIssuedOn(doc.getIssuedDate());
		dto.setIssuer(doc.getIssuer());
		dto.setRemarks(doc.getRemark());
		dto.setValidFrom(doc.getValidFrom());
		dto.setValidTo(doc.getValidTo());
		dto.setStatus(from.getStatus().getCode());
		dto.setIsApproved(doc.getIsApproved());
		dto.setBrand(doc.getBrand());
		dto.setModel(doc.getModel());
		dto.setDeviceType(doc.getDeviceType());
		dto.setSerialNumber(doc.getSerialNumber());
		
		return dto;
	}

}
