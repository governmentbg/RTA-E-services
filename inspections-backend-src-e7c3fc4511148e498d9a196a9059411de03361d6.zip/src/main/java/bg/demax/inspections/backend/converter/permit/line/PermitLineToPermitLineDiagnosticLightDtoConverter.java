package bg.demax.inspections.backend.converter.permit.line;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.CameraPositionLightDto;
import bg.demax.inspections.backend.dto.OrgUnitLightDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineConnectivityStatusesLightDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineDiagnosticLightDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.PermitLine;

@Component
public class PermitLineToPermitLineDiagnosticLightDtoConverter 
	implements Converter<PermitLine, PermitLineDiagnosticLightDto> {

	@Autowired
	private ConversionService conversionService;
	
	@Override
	public PermitLineDiagnosticLightDto convert(PermitLine from) {
		PermitLineDiagnosticLightDto dto = new PermitLineDiagnosticLightDto();
		dto.setId(from.getId());
		dto.setPermitNumber(from.getPermit().getPermitNumber());
		dto.setOrgUnit(conversionService.convert(from.getPermit().getOrgUnit(), OrgUnitLightDto.class));
		dto.setPermitLineNumber(from.getNumber());
		dto.setCameraPositions(conversionService.convertList(from.getCamPositions(), CameraPositionLightDto.class));
		dto.setConnectivityStatuses(conversionService.convertList(from.getConnectivityStatuses(),
				PermitLineConnectivityStatusesLightDto.class));
		
		return dto;
	}

}
