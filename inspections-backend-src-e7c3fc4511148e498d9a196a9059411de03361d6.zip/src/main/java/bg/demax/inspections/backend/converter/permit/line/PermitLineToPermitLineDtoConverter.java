package bg.demax.inspections.backend.converter.permit.line;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitLightWithLightCompanyDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.PermitLine;

@Component
public class PermitLineToPermitLineDtoConverter implements Converter<PermitLine, PermitLineDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public PermitLineDto convert(PermitLine line) {
		PermitLineDto dto = new PermitLineDto();
		dto.setId(line.getId());
		dto.setNumber(line.getNumber());
		if (line.getPermit() != null) {
			dto.setPermit(conversionService.convert(line.getPermit(), PermitLightWithLightCompanyDto.class));
		}
		return dto;
	}
}
