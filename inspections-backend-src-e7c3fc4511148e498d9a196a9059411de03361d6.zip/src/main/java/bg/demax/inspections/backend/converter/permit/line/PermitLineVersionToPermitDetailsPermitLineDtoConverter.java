package bg.demax.inspections.backend.converter.permit.line;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitDetailsPermitLineDto;
import bg.demax.inspections.backend.entity.permit.line.PermitLineVersion;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitLineVersionToPermitDetailsPermitLineDtoConverter implements Converter<PermitLineVersion, PermitDetailsPermitLineDto> {

	@Override
	public PermitDetailsPermitLineDto convert(PermitLineVersion from) {
		PermitDetailsPermitLineDto dto = new PermitDetailsPermitLineDto();
		
		dto.setId(from.getId());
		dto.setNumber(from.getNumber());
		dto.setAddedOn(from.getAddedOn());
		
		return dto;
	}

}
