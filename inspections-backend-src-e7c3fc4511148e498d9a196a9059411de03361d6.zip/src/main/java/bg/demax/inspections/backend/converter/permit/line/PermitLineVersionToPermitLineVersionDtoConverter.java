package bg.demax.inspections.backend.converter.permit.line;

import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineVersionDto;
import bg.demax.inspections.backend.entity.permit.line.PermitLineVersion;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitLineVersionToPermitLineVersionDtoConverter implements Converter<PermitLineVersion, PermitLineVersionDto> {
	
	@Override
	public PermitLineVersionDto convert(PermitLineVersion from) {
		PermitLineVersionDto dto = new PermitLineVersionDto();
		dto.setAddedOn(from.getAddedOn());
		dto.setModifiedOn(from.getModifiedOn());
		dto.setNumber(from.getNumber());
		dto.setVehicleCategoryCodes(from.getCategories().stream().map(c -> c.getCode()).collect(Collectors.toList()));
		dto.setInspectionTypeCodes(from.getInspectionTypes().stream().map(t -> t.getCode()).collect(Collectors.toList()));
		
		return dto;
	}

}
