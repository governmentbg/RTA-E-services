package bg.demax.inspections.backend.converter.permit.line;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.entity.permit.line.PermitLineVersion;
import bg.demax.inspections.backend.export.permit.PermitLinesReportRow;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Permit;

@Component
public class PermitLineVersionToPermitLinesReportRowConverter implements Converter<PermitLineVersion, PermitLinesReportRow> {

	@Override
	public PermitLinesReportRow convert(PermitLineVersion from) {
		PermitLinesReportRow row = new PermitLinesReportRow();
		Permit permit = from.getPermitLine().getPermit();
		row.setPermitNumber(String.valueOf(permit.getPermitNumber()));
		row.setOrgUnit(permit.getOrgUnit().getShortName());
		row.setLineNumber(String.format("Линия %d", from.getNumber()));
		List<String> it = new ArrayList<String>();
		from.getInspectionTypes().forEach(x -> {
			it.add(x.getTiiaDescription());
		});
		row.setInspectionTypes(String.join(", ", it));
		List<String> vc = new ArrayList<String>();
		from.getCategories().forEach(x -> {
			vc.add(x.getCode());
		});
		row.setCategories(String.join(", ", vc));
		row.setCompanyIdentityNumberAndName(String.format("%s / %s", permit.getSubjectVersion().getSubject().getIdentityNumber(),
						permit.getSubjectVersion().getFullName()));
		return row;
	}

}
