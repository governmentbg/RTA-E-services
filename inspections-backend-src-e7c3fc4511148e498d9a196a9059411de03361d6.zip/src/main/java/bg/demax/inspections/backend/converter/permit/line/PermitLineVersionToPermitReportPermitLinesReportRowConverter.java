package bg.demax.inspections.backend.converter.permit.line;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.entity.permit.line.PermitLineVersion;
import bg.demax.inspections.backend.export.permit.PermitReportPermitLinesReportRow;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.VehicleCategory;
import bg.demax.techinsp.entity.InspectionType;

@Component
public class PermitLineVersionToPermitReportPermitLinesReportRowConverter
				implements Converter<PermitLineVersion, PermitReportPermitLinesReportRow> {

	@Override
	public PermitReportPermitLinesReportRow convert(PermitLineVersion from) {
		PermitReportPermitLinesReportRow row = new PermitReportPermitLinesReportRow();
		row.setLineNumber(from.getNumber().intValue());
		List<String> stringList = new ArrayList<String>();
		for (VehicleCategory category : from.getCategories()) {
			stringList.add(category.getCode());
		}
		row.setChecksForVehicleOfCategory(String.join(", ", stringList));
		stringList.clear();
		for (InspectionType type : from.getInspectionTypes()) {
			stringList.add(type.getTiiaDescription());
		}
		row.setChecksForPurpose(String.join(", ", stringList));
		row.setMatchForVehicleCategory(null);
		if (from.getCategories() != null && from.getInspectionTypes() != null) {
			
			List<String> lineCategoriesList = new ArrayList<>();
			List<String> lineCategories = from.getCategories().stream().map(VehicleCategory::getCode).collect(Collectors.toList());
			List<String> lineInspectionTypes = from.getInspectionTypes().stream().map(InspectionType::getCode).collect(Collectors.toList());
			
			if (!Collections.disjoint(lineCategories, VehicleCategory.KTP_CATEGORY_I_CODES)) {
				lineCategoriesList.add("I");
			}
			
			if (!Collections.disjoint(lineCategories, VehicleCategory.KTP_CATEGORY_II_CODES)) {
				lineCategoriesList.add("II");
			}
			
			if (!Collections.disjoint(lineCategories, VehicleCategory.KTP_CATEGORY_III_CODES)) {
				lineCategoriesList.add("III");
			} 

			if (lineInspectionTypes.contains(InspectionType.CODE_TROL)) {
				lineCategoriesList.add("IV ТБ");
			}
			
			if (lineInspectionTypes.contains(InspectionType.CODE_TRAM)) {
				lineCategoriesList.add("IV ТМ");
			}

			if (lineInspectionTypes.contains(InspectionType.CODE_ADR)) {
				lineCategoriesList.add("V");
			}

			row.setMatchForVehicleCategory(String.join(", ", lineCategoriesList));
		}
		return row;
	}

}
