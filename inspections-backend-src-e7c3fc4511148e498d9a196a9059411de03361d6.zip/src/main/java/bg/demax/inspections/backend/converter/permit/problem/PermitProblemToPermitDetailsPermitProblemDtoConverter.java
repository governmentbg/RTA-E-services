package bg.demax.inspections.backend.converter.permit.problem;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitDetailsPermitProblemDto;
import bg.demax.inspections.backend.entity.permit.problem.PermitProblem;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitProblemToPermitDetailsPermitProblemDtoConverter implements Converter<PermitProblem, PermitDetailsPermitProblemDto> {

	@Override
	public PermitDetailsPermitProblemDto convert(PermitProblem from) {
		PermitDetailsPermitProblemDto dto = new PermitDetailsPermitProblemDto();
		
		dto.setId(from.getId());
		dto.setCreatedOn(from.getCreatedOn());
		dto.setDescription(from.getProblmeDescription());
		dto.setStatusId(from.getStatus().getId());
		
		return dto;
	}

}
