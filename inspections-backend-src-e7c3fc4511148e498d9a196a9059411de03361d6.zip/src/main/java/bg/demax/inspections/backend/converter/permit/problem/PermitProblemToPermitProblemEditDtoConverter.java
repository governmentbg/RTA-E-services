package bg.demax.inspections.backend.converter.permit.problem;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.problem.PermitProblemEditDto;
import bg.demax.inspections.backend.dto.techinsp.permit.problem.PermitProblemListItemDto;
import bg.demax.inspections.backend.entity.permit.problem.PermitProblem;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitProblemToPermitProblemEditDtoConverter implements Converter<PermitProblem, PermitProblemEditDto> {
	
	@Autowired
	private ConversionService conversionService;

	@Override
	public PermitProblemEditDto convert(PermitProblem from) {
		PermitProblemListItemDto lightDto = conversionService.convert(from, PermitProblemListItemDto.class);
		PermitProblemEditDto dto = new PermitProblemEditDto();
		BeanUtils.copyProperties(lightDto, dto);
		if (from.getCreatedBy().getCurrentVersion() != null) {
			dto.setOperatorName(from.getCreatedBy().getCurrentVersion().getFullNameIfMissingCyr());			
		}
		dto.setCheckDescription(from.getCheckDescription());
		dto.setCheckedBy(from.getCheckedBy());
		dto.setCheckedOn(from.getCheckedOn());
		dto.setExpectedCheckDate(from.getExpectedCheckOn());
		return dto;
	}
	

}
