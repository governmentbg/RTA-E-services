package bg.demax.inspections.backend.converter.permit.problem;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.problem.PermitProblemListItemDto;
import bg.demax.inspections.backend.entity.permit.PermitAdditionalInfoVersion;
import bg.demax.inspections.backend.entity.permit.PermitLink;
import bg.demax.inspections.backend.entity.permit.problem.PermitProblem;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitProblemToPermitProblemListItemDtoConverter implements Converter<PermitProblem, PermitProblemListItemDto> {

	@Override
	public PermitProblemListItemDto convert(PermitProblem from) {
		PermitProblemListItemDto dto = new PermitProblemListItemDto();
		dto.setId(from.getId());
		dto.setPermitNum(from.getPermitLink().getPermit().getPermitNumber());
		dto.setPermitVersionId(from.getPermitLink().getLastApprovedVersion().getId());
		dto.setDateCreated(from.getCreatedOn());
		dto.setProblemDesc(from.getProblmeDescription());
		dto.setStatus(from.getStatus().getId());
		dto.setOrgUnit(from.getPermitLink().getPermit().getOrgUnit().getShortName());
		
		PermitLink permitLink = from.getPermitLink();
		
		if (permitLink.getPermit().getSubject() != null) {
			dto.setIdentityNum(from.getPermitLink().getPermit().getSubject().getIdentityNumber());
		}
		
		if (permitLink.getPermit().getKtpCity() != null
				&& permitLink.getPermit().getKtpCity().getName() != null) {
			dto.setCity(permitLink.getPermit().getKtpCity().getName());				
		}
		
		if (permitLink.getPermit().getSubjectVersion() != null) {
			dto.setCompanyName(permitLink.getPermit().getSubjectVersion().getFullName());
		}
		
		if (permitLink.getLastApprovedVersion() != null && permitLink.getLastApprovedVersion().getAdditionalInfo() != null) {
			PermitAdditionalInfoVersion permitAdditionalInfo = permitLink.getLastApprovedVersion().getAdditionalInfo();
			if (permitAdditionalInfo.getContactPersonPhone() != null) {
				dto.setContactNum(permitAdditionalInfo.getContactPersonPhone());
				if (permitAdditionalInfo.getContactPersonStationaryPhone() != null) {
					dto.setContactNum(dto.getContactNum() + ", " + permitAdditionalInfo.getContactPersonStationaryPhone());
				}
			} else {
				if (permitAdditionalInfo.getContactPersonStationaryPhone() != null) {
					dto.setContactNum(permitAdditionalInfo.getContactPersonStationaryPhone());
				}
			}
			
			if (permitAdditionalInfo.getContactPersonName() != null) {
				dto.setContactName(permitAdditionalInfo.getContactPersonName());
			}
			
			if (permitAdditionalInfo.getKtpRealAddress() != null) {
				dto.setAddress(permitAdditionalInfo.getKtpRealAddress());
			}
		}
		return dto;
	}

}
