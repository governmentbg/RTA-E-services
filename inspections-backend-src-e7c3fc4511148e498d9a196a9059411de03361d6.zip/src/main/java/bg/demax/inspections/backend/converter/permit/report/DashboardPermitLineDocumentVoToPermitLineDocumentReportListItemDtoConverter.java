package bg.demax.inspections.backend.converter.permit.report;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineDocumentReportListItemDto;
import bg.demax.inspections.backend.entity.permit.PermitVersion;
import bg.demax.inspections.backend.entity.permit.line.PermitLineDocumentVersion;
import bg.demax.inspections.backend.entity.permit.line.PermitLineVersion;
import bg.demax.inspections.backend.util.PermitReportUtil;
import bg.demax.inspections.backend.vo.DashboardPermitLineDocumentVo;
import bg.demax.legacy.util.convert.Converter;

@Component
public class DashboardPermitLineDocumentVoToPermitLineDocumentReportListItemDtoConverter
				implements Converter<DashboardPermitLineDocumentVo, PermitLineDocumentReportListItemDto> {

	@Override
	public PermitLineDocumentReportListItemDto convert(DashboardPermitLineDocumentVo from) {
		PermitVersion lastApprovedVersion = from.getPermitVersion();
		PermitLineDocumentVersion document = from.getPermitLineDocumentVersion();

		PermitLineDocumentReportListItemDto dto = new PermitLineDocumentReportListItemDto();
		for (PermitLineVersion lineVersion : lastApprovedVersion.getPermitLines()) {
			if (lineVersion.getPermitLine().getId().equals(document.getDocument().getPermitLine().getId())) {
				dto.setLineVersionId(lineVersion.getId());
				for (PermitLineDocumentVersion docVersion : lineVersion.getDocumentVersions()) {
					if (docVersion.getDocument().getId().equals(document.getDocument().getId())) {
						dto.setId(docVersion.getId());
					}
				}
			}
		}
		if (document.getDocument().getPermitLine().getPermit() != null) {
			dto.setPermitNumber(document.getDocument().getPermitLine().getPermit().getPermitNumber());
			dto.setOrgUnit(document.getDocument().getPermitLine().getPermit().getOrgUnit().getShortName());
		}
		dto.setPermitVersionId(lastApprovedVersion.getId());
		dto.setDocType(document.getDocument().getType().getDescription());
		if (document.getDocument().getPermitLine().getNumber() != null) {
			dto.setLineNumber(document.getDocument().getPermitLine().getNumber().intValue());
		}

		if (document.getDocument().getValidTo() != null) {
			dto.setStatus(PermitReportUtil.getDocumentStatus(document.getStatus().getCode(), 
				document.getDocument().getValidTo()));
		} else {
			dto.setStatus(document.getStatus().getCode());
		}

		dto.setValidFrom(document.getDocument().getValidFrom());
		dto.setValidTo(document.getDocument().getValidTo());

		return dto;
	}
}
