package bg.demax.inspections.backend.converter.permit.report;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.DashboardInspectorCertificationDto;
import bg.demax.inspections.backend.util.PermitReportUtil;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.VehicleCategory;
import bg.demax.specialist.registry.common.entity.InspectorCertification;
import bg.demax.techinsp.entity.InspectionType;

@Component
public class InspectorCertificationToDashboardInspectorCertificationDtoConverter
		
		implements Converter<InspectorCertification, DashboardInspectorCertificationDto> {

	@Override
	public DashboardInspectorCertificationDto convert(InspectorCertification from) {
		DashboardInspectorCertificationDto dto = new DashboardInspectorCertificationDto();

		dto.setId(from.getId());
		dto.setDocNumber(from.getDocumentNumber());
		dto.setDocType(from.getCourse().getEducationCategory().getType().getCode());
		dto.setReissueOn(from.getReissueOn());
		
		List<String> inspectionTypesList = from.getCourse().getEducationCategory().getInspectionTypes()
			.stream()
			.map(InspectionType::getTiiaDescription).collect(Collectors.toList());
		dto.setInspectionTypes(buildResultString(inspectionTypesList));

		List<String> catergoriesList = from.getCourse().getEducationCategory().getVehicleCategories()
			.stream()
			.map(VehicleCategory::getCode).collect(Collectors.toList());
		dto.setCategories(buildResultString(catergoriesList));


		dto.setSubjectFullName(from.getSubjectVersion().getFullNameIfMissingCyr());
		dto.setSubjectIdentityNumber(from.getSubjectVersion().getSubject().getIdentityNumber());
		dto.setStatusCode(PermitReportUtil.getDocumentStatus(from.getStatus().getCode(), from.getReissueOn()));

		return dto;
	}

	private static String buildResultString(List<String> strings) {
		StringBuilder builder = new StringBuilder();
		builder.append(String.join(", ", strings));

		return builder.toString();
	}
}
