package bg.demax.inspections.backend.converter.permit.report;

import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitDocumentReportListItemDto;
import bg.demax.inspections.backend.entity.permit.PermitAppliedDocumentExt;
import bg.demax.inspections.backend.util.PermitReportUtil;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.PermitAppliedDocument;

@Component
public class PermitAppliedDocumentToPermitDocumentReportListItemDtoConverter
				implements Converter<PermitAppliedDocumentExt, PermitDocumentReportListItemDto> {

	private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy г.");

	@Override
	public PermitDocumentReportListItemDto convert(PermitAppliedDocumentExt from) {
		PermitDocumentReportListItemDto dto = new PermitDocumentReportListItemDto();
		PermitAppliedDocument doc = from.getDocument();

		if (doc.getPermit().getPermitNumber() != null) {
			dto.setPermitNumber(doc.getPermit().getPermitNumber().toString());			
		}
		dto.setOrgUnit(doc.getPermit().getOrgUnit().getShortName());
		dto.setEik(doc.getPermit().getSubject().getIdentityNumber());
		if (doc.getPermit().getSubjectVersion() != null) {
			dto.setCompanyName(doc.getPermit().getSubjectVersion().getFullNameIfMissingCyr());			
		}
		dto.setDocumentType(doc.getType().getDescription());
		if (doc.getValidFrom() != null) {
			dto.setValidFrom(doc.getValidFrom().format(dateFormatter));
		}
		if (doc.getValidTo() != null) {
			dto.setValidTo(doc.getValidTo().format(dateFormatter));
		}
		
		dto.setStatus(PermitReportUtil.getDocumentStatus(from.getLastVersion().getStatus().getCode(), 
			doc.getValidTo()));
		
		return dto;
	}

}
