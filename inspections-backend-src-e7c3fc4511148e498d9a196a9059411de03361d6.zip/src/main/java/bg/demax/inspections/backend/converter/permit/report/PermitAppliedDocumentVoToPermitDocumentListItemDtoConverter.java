package bg.demax.inspections.backend.converter.permit.report;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitDocumentListItemDto;
import bg.demax.inspections.backend.util.PermitReportUtil;
import bg.demax.inspections.backend.vo.PermitAppliedDocumentVo;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.PermitAppliedDocument;

@Component
public class PermitAppliedDocumentVoToPermitDocumentListItemDtoConverter
				implements Converter<PermitAppliedDocumentVo, PermitDocumentListItemDto> {

	@Override
	public PermitDocumentListItemDto convert(PermitAppliedDocumentVo from) {
		PermitDocumentListItemDto dto = new PermitDocumentListItemDto();
		dto.setPermitVersionId(from.getPermitVersion().getId());

		PermitAppliedDocument document = from.getPermitAppliedDocumentExt().getDocument();

		dto.setId(document.getId());
		if (document.getPermit().getSubjectVersion() != null) {
			dto.setCompanyName(document.getPermit().getSubjectVersion().getFullNameIfMissingCyr());
		}
		dto.setIdentityNum(document.getPermit().getSubject().getIdentityNumber());
		dto.setOrgUnit(document.getPermit().getOrgUnit().getShortName());
		if (document.getPermit().getPermitNumber() != null) {
			dto.setPermitNumber(document.getPermit().getPermitNumber().toString());
		}
		dto.setDocumentType(document.getType().getDescription());
		
		dto.setStatus(PermitReportUtil.getDocumentStatus(from.getPermitAppliedDocumentExt().getLastVersion().getStatus().getCode(), 
				document.getValidTo()));

		dto.setValidFrom(document.getValidFrom());
		dto.setValidTo(document.getValidTo());

		return dto;
	}
}
