package bg.demax.inspections.backend.converter.permit.report;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitDocumentListItemDto;
import bg.demax.inspections.backend.entity.permit.PermitDocumentVersion;
import bg.demax.inspections.backend.util.PermitReportUtil;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.PermitAppliedDocument;

@Component
public class PermitDocumentVersionToPermitDocumentListItemDtoConverter
				implements Converter<PermitDocumentVersion, PermitDocumentListItemDto> {

	@Override
	public PermitDocumentListItemDto convert(PermitDocumentVersion from) {
		PermitDocumentListItemDto dto = new PermitDocumentListItemDto();

		PermitAppliedDocument document = from.getDocument();

		dto.setId(document.getId());
		if (document.getPermit().getSubjectVersion() != null) {
			dto.setCompanyName(document.getPermit().getSubjectVersion().getFullNameIfMissingCyr());
		}
		dto.setIdentityNum(document.getPermit().getSubject().getIdentityNumber());
		dto.setOrgUnit(document.getPermit().getOrgUnit().getShortName());
		if (document.getPermit().getPermitNumber() != null) {
			dto.setPermitNumber(document.getPermit().getPermitNumber().toString());
		}
		dto.setDocumentType(document.getType().getDescription());
		
		dto.setStatus(PermitReportUtil.getDocumentStatus(from.getStatus().getCode(), 
				document.getValidTo()));

		dto.setValidFrom(document.getValidFrom());
		dto.setValidTo(document.getValidTo());

		return dto;
	}
}
