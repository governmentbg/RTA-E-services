package bg.demax.inspections.backend.converter.permit.report;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.inspector.PermitInspectorReportListItemDto;
import bg.demax.inspections.backend.entity.permit.PermitVersion;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorVersion;
import bg.demax.inspections.backend.vo.PermitInspectorReportListItemVo;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.specialist.registry.common.entity.Course;
import bg.demax.specialist.registry.common.entity.EducationCategory;
import bg.demax.specialist.registry.common.entity.InspectorCertification;
import bg.demax.techinsp.entity.InspectionType;
import bg.demax.techinsp.entity.PermitInspectorStatus;

@Component
public class PermitInspectorReportListItemVoToPermitInspectorReportListItemDtoConverter
		implements Converter<PermitInspectorReportListItemVo, PermitInspectorReportListItemDto> {

	@Override
	public PermitInspectorReportListItemDto convert(PermitInspectorReportListItemVo from) {
		PermitInspectorReportListItemDto dto = new PermitInspectorReportListItemDto();

		dto.setId(from.getPermitInspectorVersion().getId());
		dto.setInspectorIdentityNum(
				from.getPermitInspectorVersion().getSubjectVersion().getSubject().getIdentityNumber());
		dto.setInspectorName(from.getPermitInspectorVersion().getSubjectVersion().getFullNameIfMissingCyr());
		dto.setIsChairman(from.getPermitInspectorVersion().getPermitInspectorInfo().getIsChairman());

		String currentStatus = null;
		if (from.getPermitInspectorVersion().getCurrentStatus() != null) {
			currentStatus = from.getPermitInspectorVersion().getCurrentStatus();
			dto.setStatus(currentStatus);
			
		}
		dto.setHasCard(from.getHasCard());

		if (currentStatus != null && currentStatus.equals(PermitInspectorStatus.INCLUDED.getCode())) {
			dto.setDateOfStatus(from.getPermitInspectorVersion().getIncludedOn());
		} else {
			dto.setDateOfStatus(from.getPermitInspectorVersion().getExcludedOn());
		}

		PermitInspectorVersion inspectorVersion = from.getPermitInspectorVersion();
		PermitVersion permitVersion = from.getPermitVersion();

		dto.setCompanyIdentNum(permitVersion.getSubjectVersion().getSubject().getIdentityNumber());
		dto.setCompanyName(permitVersion.getSubjectVersion().getFullNameIfMissingCyr());
		dto.setOrgUnit(permitVersion.getPermitInfo().getOrgUnit().getShortName());
		dto.setPermitNum(permitVersion.getPermitVersionNumber());

		if (permitVersion.getStatus() != null) {
			dto.setPermitStatus(permitVersion.getStatus().getCode());
		}	

		List<InspectionType> inspectionTypes = inspectorVersion.getCertifications().stream()
				.map(InspectorCertification::getCourse)
				.map(Course::getEducationCategory)
				.map(EducationCategory::getInspectionTypes)
				.flatMap(List::stream)
				.collect(Collectors.toList());


		dto.setInspectionType(String.join(", ",
				inspectionTypes.stream().map(InspectionType::getTiiaDescription).collect(Collectors.toList())));
		
		dto.setPermitVersionId(permitVersion.getId());

		return dto;
	}

}
