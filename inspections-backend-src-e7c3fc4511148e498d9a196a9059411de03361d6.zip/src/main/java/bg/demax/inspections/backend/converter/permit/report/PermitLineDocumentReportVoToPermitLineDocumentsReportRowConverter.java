package bg.demax.inspections.backend.converter.permit.report;

import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.entity.permit.line.PermitLineDocumentExt;
import bg.demax.inspections.backend.export.permit.PermitLineDocumentsReportRow;
import bg.demax.inspections.backend.util.PermitReportUtil;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitLineDocumentReportVoToPermitLineDocumentsReportRowConverter
				implements Converter<PermitLineDocumentExt, PermitLineDocumentsReportRow> {

	private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yy г.");

	@Override
	public PermitLineDocumentsReportRow convert(PermitLineDocumentExt from) {
		PermitLineDocumentsReportRow row = new PermitLineDocumentsReportRow();

		if (from.getDocument().getPermitLine().getPermit() != null) {
			if (from.getDocument().getPermitLine().getPermit().getPermitNumber() != null) {
				row.setPermitNumber(from.getDocument().getPermitLine().getPermit().getPermitNumber().toString());
			}
			row.setOrgUnit(from.getDocument().getPermitLine().getPermit().getOrgUnit().getShortName());
		}
		row.setDocType(from.getDocument().getType().getDescription());
		if (from.getDocument().getPermitLine().getNumber() != null) {
			row.setLineNumber(from.getDocument().getPermitLine().getNumber().toString());
		}
		
		row.setStatus(PermitReportUtil.translateDocumentStatusCode(
						PermitReportUtil.getDocumentStatus(from.getLastVersion().getStatus().getCode(), 
							from.getDocument().getValidTo())));
		
		if (from.getDocument().getValidFrom() != null) {
			row.setValidFrom(from.getDocument().getValidFrom().format(formatter));
		}
		if (from.getDocument().getValidTo() != null) {
			row.setValidTo(from.getDocument().getValidTo().format(formatter));
		}
		return row;
	}

}
