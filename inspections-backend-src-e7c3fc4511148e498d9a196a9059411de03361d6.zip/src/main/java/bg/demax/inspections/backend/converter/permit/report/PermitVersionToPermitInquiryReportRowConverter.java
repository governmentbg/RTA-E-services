package bg.demax.inspections.backend.converter.permit.report;

import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.entity.permit.PermitVersion;
import bg.demax.inspections.backend.export.permit.PermitInquiryReportRow;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitVersionToPermitInquiryReportRowConverter implements Converter<PermitVersion, PermitInquiryReportRow> {
	
	private final DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd.MM.yy г.");

	@Override
	public PermitInquiryReportRow convert(PermitVersion from) {
		PermitInquiryReportRow row = new PermitInquiryReportRow();
		row.setOrgUnit(from.getPermitInfo().getOrgUnit().getShortName());
		if (from.getPermitInfo().getPermitNumber() != null) {
			row.setStampNumber(from.getPermitInfo().getPermitNumber().toString());			
		}
		row.setApplicationNumber(from.getPermitInfo().getApplicationNumber());
		if (from.getPermitInfo().getApplicationDate() != null) {
			row.setApplicationDate(from.getPermitInfo().getApplicationDate().format(dateFormat));			
		}
		if (from.getPermitInfo().getPermitNumber() != null) {
			row.setPermitNumber(from.getPermitInfo().getPermitNumber().toString());			
		}
		row.setCurrentStatus(from.getStatus().getDescription());
		row.setCompanyName(from.getSubjectVersion().getFullNameIfMissingCyr());
		row.setEik(from.getSubjectVersion().getSubject().getIdentityNumber());
		if (from.getSubjectVersion().getCity() != null) {
			row.setCompanyCity(from.getSubjectVersion().getCity().getName());			
		}
		row.setCompanyAddress(from.getSubjectVersion().getBaseAddress());
		if (from.getPermitLink().getPermit() != null) {
			if (from.getPermitLink().getPermit().getKtpName() != null) {
				row.setKtpName(from.getPermitLink().getPermit().getKtpName());			
			} else {
				row.setKtpName(from.getSubjectVersion().getFullNameIfMissingCyr());
			}
			if (from.getPermitLink().getPermit().getLastChangeDate() != null) {
				row.setChangeInCircumstancesDate(from.getPermitLink().getPermit().getLastChangeDate().format(dateFormat));			
			}
			if (from.getPermitLink().getPermit().getListChangeDate() != null) {
				row.setListChangeDate(from.getPermitLink().getPermit().getListChangeDate().format(dateFormat));			
			}
			if (from.getPermitLink().getPermit().getInspectionDate() != null) {
				row.setCheckDate(from.getPermitLink().getPermit().getInspectionDate().format(dateFormat));			
			}
			if (from.getPermitLink().getPermit().getInspectionProts() != null) {
				row.setNumberOfProtocols(from.getPermitLink().getPermit().getInspectionProts());			
			}
			if (from.getPermitLink().getPermit().getCloseDate() != null) {
				row.setRevokeDate(from.getPermitLink().getPermit().getCloseDate().format(dateFormat));			
			}
			if (from.getPermitLink().getPermit().getCloseReason() != null) {
				row.setRevokeReason(from.getPermitLink().getPermit().getCloseReason());			
			}
			if (from.getPermitLink().getPermit().getFirstRegDate() != null ) {
				row.setIssueDate(from.getPermitLink().getPermit().getFirstRegDate().format(dateFormat));			
			}
			row.setRemarks(from.getPermitLink().getPermit().getRemarks());
			
		}
		row.setNumberOfLines(from.getPermitLines().size());
		if (from.getPermitInfo().getKtpCategory() != null) {
			row.setKtpCategory(from.getPermitInfo().getKtpCategory().getCode());			
		}
		if (from.getPermitInfo().getKtpCity() != null) {
			row.setKtpCity(from.getPermitInfo().getKtpCity().getName());			
		}
		row.setKtpAddress(from.getPermitInfo().getKtpAddress());
		if (from.getPermitInfo().getValidFrom() != null) {
			row.setValidFrom(from.getPermitInfo().getValidFrom().format(dateFormat));			
		}
		if (from.getPermitInfo().getValidTo() != null) {
			row.setValidTo(from.getPermitInfo().getValidTo().format(dateFormat));			
		}
		
		return row;
	}

}
