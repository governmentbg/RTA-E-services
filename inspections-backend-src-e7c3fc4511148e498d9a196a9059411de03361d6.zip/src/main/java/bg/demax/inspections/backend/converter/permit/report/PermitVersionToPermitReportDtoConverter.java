package bg.demax.inspections.backend.converter.permit.report;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitReportDto;
import bg.demax.inspections.backend.entity.permit.PermitVersion;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorVersion;
import bg.demax.inspections.backend.export.permit.PermitInspectorsReportRow;
import bg.demax.inspections.backend.export.permit.PermitReportParams;
import bg.demax.inspections.backend.export.permit.PermitReportPermitLinesReportRow;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.PermitInspectorStatus;

@Component
public class PermitVersionToPermitReportDtoConverter implements Converter<PermitVersion, PermitReportDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public PermitReportDto convert(PermitVersion from) {
		PermitReportDto dto = new PermitReportDto();
		dto.setPermitDetails(conversionService.convert(from, PermitReportParams.class));
		List<PermitInspectorVersion> activeInspectors = from.getInspectors().stream()
				.filter(inspector -> inspector.getCurrentStatus().equals(PermitInspectorStatus.INCLUDED.getCode()))
				.collect(Collectors.toList());
		dto.setPermitLines(
				conversionService.convertList(from.getPermitLines(), PermitReportPermitLinesReportRow.class));
		dto.setPermitInspectors(conversionService.convertList(activeInspectors, PermitInspectorsReportRow.class));

		Collections.sort(dto.getPermitLines(), (l1, l2) -> l1.getLineNumber().compareTo(l2.getLineNumber()));

		Comparator<PermitInspectorsReportRow> comparator = Comparator
				.comparing(PermitInspectorsReportRow::getIsChairman)
				.thenComparing(PermitInspectorsReportRow::getStampOrderNumber);

		Collections.sort(dto.getPermitInspectors(), comparator);

		Set<String> ktpCategories = new HashSet<String>();
		for (PermitReportPermitLinesReportRow row : dto.getPermitLines()) {
			ktpCategories.addAll(Arrays.asList(row.getMatchForVehicleCategory().split(", ")));
		}

		List<String> sortedCategories = new ArrayList<>(ktpCategories);
		Collections.sort(sortedCategories);

		dto.getPermitDetails().setKtpCategories(String.join(", ", sortedCategories));

		return dto;
	}

}
