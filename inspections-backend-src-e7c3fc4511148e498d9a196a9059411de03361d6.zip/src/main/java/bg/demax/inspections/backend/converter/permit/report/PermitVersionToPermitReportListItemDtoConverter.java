package bg.demax.inspections.backend.converter.permit.report;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitReportListItemDto;
import bg.demax.inspections.backend.entity.permit.PermitVersion;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitVersionToPermitReportListItemDtoConverter implements Converter<PermitVersion, PermitReportListItemDto> {

	@Override
	public PermitReportListItemDto convert(PermitVersion from) {
		PermitReportListItemDto dto = new PermitReportListItemDto();
		dto.setId(from.getId());
		dto.setApplicationDate(from.getPermitInfo().getApplicationDate());
		dto.setApplicationNum(from.getPermitInfo().getApplicationNumber());
		if (from.getPermitLink().getPermit() != null) {
			dto.setCompanyName(from.getPermitLink().getPermit().getSubjectVersion().getFullNameIfMissingCyr());			
		}
		dto.setNumberOfInspectors(from.getInspectors().size());
		dto.setNumberOfLines(from.getPermitLines().size());
		dto.setOrgUnit(from.getPermitInfo().getOrgUnit().getShortName());
		if (from.getPermitInfo().getPermitNumber() != null) {
			dto.setPermitNum(from.getPermitInfo().getPermitNumber().toString());			
		}
		dto.setValidFrom(from.getPermitInfo().getValidFrom());
		dto.setValidTo(from.getPermitInfo().getValidTo());
		dto.setStatus(from.getStatus().getCode());
		dto.setIdentityNum(from.getSubjectVersion().getSubject().getIdentityNumber());
		if (from.getPermitInfo().getKtpCategory() != null) {
			dto.setKtpCategory(from.getPermitInfo().getKtpCategory().getLabel());			
		}
		return dto;
	}

}
