package bg.demax.inspections.backend.converter.permit.report;

import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.entity.permit.PermitVersion;
import bg.demax.inspections.backend.export.permit.PermitReportParams;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitVersionToPermitReportParamsConverter implements Converter<PermitVersion, PermitReportParams> {
	
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy г.");

	@Override
	public PermitReportParams convert(PermitVersion from) {
		PermitReportParams params = new PermitReportParams();
		PermitVersionToPermitReportParamsLightConverter.convertFromPermitVersionToParamsLight(from, params);
		if (from.getLastChangeDate() != null) {
			params.setChangeDate(from.getLastChangeDate().format(formatter));			
		}

		if (from.getListChangeDate() != null && from.getListChangeDate().isAfter(from.getLastChangeDate())) {
			params.setLastChangeDate(from.getListChangeDate().format(formatter));			
		} else if (from.getLastChangeDate() != null) {
			params.setLastChangeDate(from.getLastChangeDate().format(formatter));
		}

		if (from.getPermitInfo() != null && from.getPermitInfo().getValidFrom() != null) {
			params.setValidFrom(from.getPermitInfo().getValidFrom().format(formatter));			
		}
		params.setNumberOfLines(from.getPermitLines().size());
		if (from.getPermitInfo() != null && from.getPermitInfo().getKtpCategory() != null) {
			params.setKtpCategories(from.getPermitInfo().getKtpCategory().getCode());
		}
		
		return params;
	}

}
