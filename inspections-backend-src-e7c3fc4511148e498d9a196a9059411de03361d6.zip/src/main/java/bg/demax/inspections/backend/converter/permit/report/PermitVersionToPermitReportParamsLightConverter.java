package bg.demax.inspections.backend.converter.permit.report;

import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.entity.permit.PermitVersion;
import bg.demax.inspections.backend.export.permit.PermitReportParamsLight;
import bg.demax.legacy.util.convert.Converter;

@Component
public class PermitVersionToPermitReportParamsLightConverter implements Converter<PermitVersion, PermitReportParamsLight> {
	
	static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy г.");

	@Override
	public PermitReportParamsLight convert(PermitVersion from) {
		PermitReportParamsLight params = new PermitReportParamsLight();
		convertFromPermitVersionToParamsLight(from, params);
		return params;
	}
	
	public static void convertFromPermitVersionToParamsLight(PermitVersion from, PermitReportParamsLight params) {
		if (from.getPermitLink().getIssuedOn() != null) {			
			params.setIssueDate(from.getPermitLink().getIssuedOn().format(formatter));
		} else {
			params.setIssueDate("");
		}
		params.setValidTo(from.getPermitInfo().getValidTo().format(formatter));
		params.setPermitNumber(from.getPermitInfo().getPermitNumber());
		params.setCompanyName(from.getSubjectVersion().getFullName());
		params.setEik(from.getSubjectVersion().getSubject().getIdentityNumber());
		if (from.getSubjectVersion().getCity() != null) {
			params.setAddress(from.getSubjectVersion().getCity().getName() + ",  " + from.getSubjectVersion().getBaseAddress());			
		} else {
			params.setAddress(from.getSubjectVersion().getBaseAddress());
		}
		if (from.getPermitInfo().getKtpCity() != null) {
			params.setKtpAddress(from.getPermitInfo().getKtpCity().getName() + ",  " + from.getPermitInfo().getKtpAddress());			
		} else {
			params.setKtpAddress(from.getPermitInfo().getKtpAddress());
		}
	}

}
