package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.CamRequestLightDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.CamRequest;

@Component
public class CamRequestToCamRequestLightDtoConverter implements Converter<CamRequest, CamRequestLightDto> {

	@Override
	public CamRequestLightDto convert(CamRequest from) {
		CamRequestLightDto dto = new CamRequestLightDto();
		dto.setFeedNum(from.getId().getFeedNum());
		dto.setResolution(from.getId().getResolution());
		dto.setStatusCode(from.getReqCode().getCode());
		return dto;
	}

}
