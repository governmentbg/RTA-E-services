package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.EcoCategoryDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.EcoCategory;

@Component
public class EcoCategoryToEcoCategoryDtoConverter implements Converter<EcoCategory, EcoCategoryDto> {

	@Override
	public EcoCategoryDto convert(EcoCategory from) {
		EcoCategoryDto dto = new EcoCategoryDto();
		dto.setCode(from.getCode());
		dto.setDescription(from.getDescriptionCyrillic());
		return dto;
	}

}
