package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.InspectionCountForVehicleReport;
import bg.demax.inspections.backend.dto.techinsp.InspectionCountForVehicleReportLightDto;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionCountForVehicleReportToLightDto  
			implements Converter<InspectionCountForVehicleReport, InspectionCountForVehicleReportLightDto> {
	
	@Override
	public InspectionCountForVehicleReportLightDto convert(InspectionCountForVehicleReport from) {
		InspectionCountForVehicleReportLightDto dto = new InspectionCountForVehicleReportLightDto();
		
		dto.setRegistrationNumber(from.getRegistrationNumber());
		dto.setMakeAndModel(from.getMakeAndModel());
		dto.setConclusion(from.getConclusion());
		dto.setInspectionsCount(from.getInspectionsCount().intValue());
		
		return dto;
	}

}
