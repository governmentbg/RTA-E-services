package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.InspectionCountForVehicleReport;
import bg.demax.inspections.backend.export.report.InspectionsCountForVehicleReportRow;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionCountForVehicleReportToReportRow 
		implements Converter<InspectionCountForVehicleReport, InspectionsCountForVehicleReportRow> {

	@Override
	public InspectionsCountForVehicleReportRow convert(InspectionCountForVehicleReport from) {
		InspectionsCountForVehicleReportRow dto = new InspectionsCountForVehicleReportRow();
		
		if (from.getRegistrationNumber() != null) {
			dto.setRegistrationNumber(from.getRegistrationNumber());
		}
		if (from.getMakeAndModel() != null) {
			dto.setMakeAndModel(from.getMakeAndModel());			
		}
		if (from.getConclusion() != null && from.getConclusion().getDescription() != null) {
			dto.setConclusion(from.getConclusion().getDescription());			
		}
		dto.setInspectionsCount(from.getInspectionsCount());
		
		return dto;
	}

}
