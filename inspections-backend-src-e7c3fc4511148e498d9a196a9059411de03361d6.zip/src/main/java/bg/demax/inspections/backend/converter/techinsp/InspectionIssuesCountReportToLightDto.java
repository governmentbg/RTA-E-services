package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.InspectionIssuesCountReportDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionIssuesCountReportLightDto;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionIssuesCountReportToLightDto implements Converter<InspectionIssuesCountReportDto,
		InspectionIssuesCountReportLightDto> {

	@Override
	public InspectionIssuesCountReportLightDto convert(InspectionIssuesCountReportDto from) {
		InspectionIssuesCountReportLightDto dto = new InspectionIssuesCountReportLightDto();
		
		dto.setInspectionElementDescription(from.getInspectionElementDescription());
		if (from.getInspectionCheckValue() != null) {
			dto.setInspectionCheckValue(from.getInspectionCheckValue().getDescription());
		}
		if (from.getInspectionElementCardinality() != null) {
			dto.setInspectionElementCardinality(from.getInspectionElementCardinality().getCardinality());
		}
		dto.setInspectionsCount(from.getInspectionsCount());
		
		return dto;
	}

}
