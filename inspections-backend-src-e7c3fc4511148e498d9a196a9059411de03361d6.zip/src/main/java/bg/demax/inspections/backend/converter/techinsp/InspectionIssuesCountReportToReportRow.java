package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.InspectionIssuesCountReportDto;
import bg.demax.inspections.backend.export.report.InspectionIssuesCountReportRow;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionIssuesCountReportToReportRow implements Converter<InspectionIssuesCountReportDto,
	InspectionIssuesCountReportRow> {

	@Override
	public InspectionIssuesCountReportRow convert(InspectionIssuesCountReportDto from) {
		InspectionIssuesCountReportRow dto = new InspectionIssuesCountReportRow();
		
		dto.setInspectionElementDescription(from.getInspectionElementDescription());
		if (from.getInspectionCheckValue() != null) {
			dto.setInspectionCheckValue(from.getInspectionCheckValue().getDescription());
		}
		if (from.getInspectionElementCardinality() != null && from.getInspectionElementCardinality().getDescription() != null) {
			dto.setInspectionElementCardinality(from.getInspectionElementCardinality().getDescription());
		} else {
			dto.setInspectionElementCardinality("Не е отбелязана");
		}
		dto.setInspectionsCount(from.getInspectionsCount());
		
		return dto;
	}

}
