package bg.demax.inspections.backend.converter.techinsp;

import java.math.BigDecimal;
import java.text.DecimalFormat;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.entity.inspection.InspectionOrderItem;
import bg.demax.inspections.backend.export.report.order.OrderInvoiceReportRow;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionOrderItemToOrderReportRowConverter implements Converter<InspectionOrderItem, OrderInvoiceReportRow> {

	@Override
	public OrderInvoiceReportRow convert(InspectionOrderItem from) {
		DecimalFormat df = new DecimalFormat("0.00"); 
		
		OrderInvoiceReportRow row = new OrderInvoiceReportRow();
		row.setItemCipher(String.valueOf(from.getProduct().getId()));
		row.setItemMeasure("бр.");
		row.setItemName(from.getProduct().getProductName());
		row.setItemPrice(new BigDecimal(df.format(from.getProduct().getPrice())));
		row.setItemQuantity(from.getQuantity());
		row.setItemValue(new BigDecimal(df.format(row.getItemPrice().multiply(new BigDecimal(row.getItemQuantity())))));
		return row;
	}

}
