package bg.demax.inspections.backend.converter.techinsp;

import java.time.LocalTime;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.controller.param.techinsp.InspectionReportRequestParams;
import bg.demax.inspections.backend.enums.InspectionReportCompareOption;
import bg.demax.inspections.backend.search.techinsp.InspectionReportSearch;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.InspectionConclusion;

@Component
public class InspectionReportRequestParamsToInspectionReportSearch
		implements Converter<InspectionReportRequestParams, InspectionReportSearch> {

	@Override
	public InspectionReportSearch convert(InspectionReportRequestParams from) {
		InspectionReportSearch search = new InspectionReportSearch();

		search.setKtpNumber(from.getKtpNumber());
		search.setOrgUnitCode(from.getOrgUnitCode());
		search.setInspectionsCount(from.getInspectionsCount());
		if (from.getInspectionsCountOption() != null) {
			search.setInspectionsCountOption(InspectionReportCompareOption.valueOf(from.getInspectionsCountOption()));
		}
		if (from.getFromDate() != null) {
			search.setFromDate(from.getFromDate().atStartOfDay());
		}
		if (from.getToDate() != null) {
			search.setToDate(from.getToDate().atTime(LocalTime.MAX));
		}
		if (from.getConclusion() != null) {
			search.setConclusion(InspectionConclusion.valueOf(from.getConclusion()));
		}

		return search;
	}

}
