package bg.demax.inspections.backend.converter.techinsp;

import java.time.LocalTime;
import java.util.Arrays;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.controller.param.techinsp.InspectionRequestParams;
import bg.demax.inspections.backend.search.techinsp.InspectionSearch;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionRequestParamsToInspectionSearch implements Converter<InspectionRequestParams, InspectionSearch> {

	@Override
	public InspectionSearch convert(InspectionRequestParams from) {
		InspectionSearch search = new InspectionSearch();
		
		search.setChairmanId(from.getChairmanId());
		search.setCommissionMemberId(from.getCommissionMemberId());
		if (from.getFromDate() != null) {
			search.setFromDate(from.getFromDate().toLocalDate().atTime(LocalTime.MIN));
		}
		if (from.getToDate() != null) {
			search.setToDate(from.getToDate().toLocalDate().atTime(LocalTime.MAX));
		}

		if (from.getOrgUnitCode() != null) {
			search.setOrgUnitCodes(Arrays.asList(from.getOrgUnitCode()));
		}
		search.setConclusion(from.getConclusion());
		search.setIsSuspicious(from.getIsSuspicious());
		search.setIsSemt(from.getIsSemt());
		search.setKtpNum(from.getKtpNum());
		search.setStatuses(from.getStatuses());
		
		return search;
	}

}
