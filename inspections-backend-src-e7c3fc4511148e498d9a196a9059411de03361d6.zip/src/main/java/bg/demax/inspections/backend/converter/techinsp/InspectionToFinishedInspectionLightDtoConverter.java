package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.FinishedInspectionLightDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Inspection;

@Component
public class InspectionToFinishedInspectionLightDtoConverter implements Converter<Inspection, FinishedInspectionLightDto> {
	
	@Override
	public FinishedInspectionLightDto convert(Inspection from) {
		FinishedInspectionLightDto dto = new FinishedInspectionLightDto();
		InspectionToInspectionLightDtoConverter.convert(dto, from);
		
		dto.setHologramNumber(from.getReceivedSignNumber());
		dto.setProtocolNumber(from.getId());
		dto.setInspectionEndTime(from.getEndDateTime());
		dto.setConclusion(from.getConclusion() != null ? from.getConclusion().name() : null);
		dto.setStatus(from.getCurrentStatus() != null ? from.getCurrentStatus().getCode() : null);
		dto.setIsSuspicious(from.getSuspiciousInspection() != null);
		
		return dto;
	}

}
