package bg.demax.inspections.backend.converter.techinsp;

import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.export.techinsp.FinishedInspectionReportRow;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.RoadVehicleVersion;
import bg.demax.techinsp.entity.Inspection;

@Component
public class InspectionToFinishedInspectionReportRowConverter implements Converter<Inspection, FinishedInspectionReportRow> {

	@Override
	public FinishedInspectionReportRow convert(Inspection from) {
		FinishedInspectionReportRow dto = new FinishedInspectionReportRow();
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy г.");
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm ч.");
		
		dto.setId(from.getId());
		dto.setKtpNumber(from.getPermitLine().getPermit().getPermitNumber());
		dto.setInspectionType(from.getInspectionType() != null ? from.getInspectionType().getTiiaDescription() : null);
		dto.setInspectionStartTime(from.getInspectionDateTime() != null ? from.getInspectionDateTime().format(timeFormatter) : "");
		dto.setInspectionEndTime(from.getEndDateTime() != null ? from.getEndDateTime().format(timeFormatter) : "");
		dto.setInspectionDate(from.getInspectionDateTime() != null ? from.getInspectionDateTime().format(dateFormatter) : "");
		dto.setOrgUnitName(from.getPermitLine().getPermit().getOrgUnit().getShortName());
		RoadVehicleVersion roadVehicleVersion = from.getRoadVehicleVersion();
		if (roadVehicleVersion != null) {
			dto.setRegistrationNumber(roadVehicleVersion.getRegistrationNumber());
			dto.setVehicleMake(roadVehicleVersion.getMake());
			dto.setCategory(roadVehicleVersion.getCategory() != null 
					? "Категория " + roadVehicleVersion.getCategory().getCode() : null);
		}
		if (from.getInspectionDateTime() != null && from.getEndDateTime() != null) {
			dto.setInspectionMinutes(ChronoUnit.MINUTES.between(from.getInspectionDateTime(), from.getEndDateTime()));
		}
		dto.setHologramNumber(from.getReceivedSignNumber());
		dto.setProtocolNumber(from.getId());
		dto.setConclusion(from.getConclusion() != null ? from.getConclusion().getDescription() : null);
		dto.setStatus(from.getCurrentStatus() != null ? from.getCurrentStatus().getDescription() : null);
		dto.setIsSuspicious(from.getSuspiciousInspection() != null);
		
		return dto;
	}
}
