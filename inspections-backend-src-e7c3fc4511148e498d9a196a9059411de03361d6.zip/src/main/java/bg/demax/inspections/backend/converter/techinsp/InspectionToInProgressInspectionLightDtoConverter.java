package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.InProgressInspectionLightDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Inspection;
import bg.demax.techinsp.entity.PermitInspector;

@Component
public class InspectionToInProgressInspectionLightDtoConverter implements Converter<Inspection, InProgressInspectionLightDto> {

	@Override
	public InProgressInspectionLightDto convert(Inspection from) {
		InProgressInspectionLightDto dto = new InProgressInspectionLightDto();
		InspectionToInspectionLightDtoConverter.convert(dto, from);
		
		dto.setIsSuspicious(from.getSuspiciousInspection() != null);
		dto.setFuelType(from.getRoadVehicleVersion() != null ? from.getRoadVehicleVersion().getFuelType() : null);
		
		PermitInspector chairman = from.getChairman();
		
		if (chairman != null) {
			dto.setChairman(chairman.getSubjectVersion().getFullNameIfMissingCyr());
		}
		
		return dto;
	}

}
