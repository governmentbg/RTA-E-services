package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.InspectionDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypeDto;
import bg.demax.inspections.backend.dto.techinsp.RoadVehicleDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineOrgUnitDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Inspection;
import bg.demax.techinsp.entity.InspectionStatus;
import bg.demax.techinsp.entity.InspectionStopReason;
import bg.demax.techinsp.entity.PermitInspector;
import bg.demax.techinsp.entity.TerminatedInspection;

@Component
public class InspectionToInspectionDtoConverter implements Converter<Inspection, InspectionDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public InspectionDto convert(Inspection inspection) {

		InspectionDto dto = new InspectionDto();
		dto.setId(inspection.getId());
		if (inspection.getConclusion() != null) {
			dto.setConclusionCode(inspection.getConclusion().name());
		}

		if (inspection.getCurrentStatus() != null) {
			dto.setStatusCode(inspection.getCurrentStatus().getCode());

			if (InspectionStatus.STOPPED.getCode().equals(inspection.getCurrentStatus().getCode())
				|| InspectionStatus.INVALID.getCode().equals(inspection.getCurrentStatus().getCode())) {
				TerminatedInspection trminatedInspection = inspection.getTerminatedInspection();
				if (trminatedInspection != null) {
					if (InspectionStopReason.OTHER_CODE.equals(trminatedInspection.getStopReason().getCode())) {
						dto.setStopReason(trminatedInspection.getOtherStopReason());
					} else {
						dto.setStopReason(trminatedInspection.getStopReason().getDescription());
					}
				}
			}
		}

		if (inspection.getPermitLine() != null && inspection.getPermitLine().getPermit() != null) {
			dto.setPermit(conversionService.convert(inspection.getPermitLine(), PermitLineOrgUnitDto.class));
		}

		dto.setPersonEgn(getValueIfValid(inspection.getPersonEGN()));
		dto.setPersonName(getValueIfValid(inspection.getPersonName()));
		dto.setProtocolNumber(getValueIfValid(inspection.getProtocolNumber()));
		dto.setHologramNumber(getValueIfValid(inspection.getReceivedSignNumber()));
		dto.setStartedAt(inspection.getInspectionDateTime());
		dto.setFinishedAt(inspection.getEndDateTime());
		dto.setValidTo(inspection.getNextInspectionDate());
		if (inspection.getCisternProtocol() != null) {
			dto.setHasCisternProtocol(true);
		} else {
			dto.setHasCisternProtocol(false);
		}
		if (inspection.getInspectionType() != null) {
			dto.setType(conversionService.convert(inspection.getInspectionType(), InspectionTypeDto.class));
		}
		dto.setSuspicious(inspection.getSuspiciousInspection() != null);
		dto.setHasSecondaryInspection(inspection.getSeconsaryInspection() != null);
		if (inspection.getHasSemt() != null) {
			dto.setHasSemt(inspection.getHasSemt().booleanValue());
		}
		if (inspection.getRoadVehicleVersion() != null) {
			dto.setVehicle(conversionService.convert(inspection.getRoadVehicleVersion(), RoadVehicleDto.class));
		}

		PermitInspector chairman = inspection.getChairman();
		if (chairman != null && chairman.getSubjectVersion() != null) {
			dto.setChairmanName(getValueIfValid(chairman.getSubjectVersion().getFullNameIfMissingCyr()));
		}

		PermitInspector member = inspection.getMember1();
		if (member != null && member.getSubjectVersion() != null) {
			dto.setMemberName(getValueIfValid(member.getSubjectVersion().getFullNameIfMissingCyr()));
		}
		
		return dto;
	}


	private String getValueIfValid(String value) {
		if (value != null && !value.isEmpty()) {
			return value;
		}
		return null;
	}

	private Long getValueIfValid(Long value) {
		if (value != null && value.compareTo(0L) >= 0) {
			return value;
		}
		return null;
	}
}
