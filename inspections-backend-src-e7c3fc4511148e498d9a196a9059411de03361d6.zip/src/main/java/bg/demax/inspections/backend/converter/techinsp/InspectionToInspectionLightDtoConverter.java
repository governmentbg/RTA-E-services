package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.converter.OrgUnitToOrgUnitLightDtoConverter;
import bg.demax.inspections.backend.dto.OrgUnitLightDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionLightDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.RoadVehicleVersion;
import bg.demax.techinsp.entity.Inspection;

@Component
public class InspectionToInspectionLightDtoConverter implements Converter<Inspection, InspectionLightDto> {

	@Override
	public InspectionLightDto convert(Inspection from) {
		InspectionLightDto dto = new InspectionLightDto();
		return InspectionToInspectionLightDtoConverter.convert(dto, from);
	}
	
	public static InspectionLightDto convert(InspectionLightDto dto, Inspection from) {
		dto.setId(from.getId());

		if (from.getCurrentStatus() != null) {
			dto.setStatusCode(from.getCurrentStatus().getCode());
		}

		dto.setKtpNumber(from.getPermitLine().getPermit().getPermitNumber());
		dto.setLine(from.getPermitLine().getNumber());

		dto.setInspectionType(from.getInspectionType() != null ? from.getInspectionType().getTiiaDescription() : null);
		dto.setInspectionStartTime(from.getInspectionDateTime());
		
		OrgUnitLightDto orgUnitDto = new OrgUnitLightDto();
		OrgUnitToOrgUnitLightDtoConverter.convert(from.getPermitLine().getPermit().getOrgUnit(), orgUnitDto);
		dto.setOrgUnit(orgUnitDto);
		
		RoadVehicleVersion roadVehicleVersion = from.getRoadVehicleVersion();
		if (roadVehicleVersion != null) {
			dto.setRegistrationNumber(roadVehicleVersion.getRegistrationNumber());
			dto.setVehicleMake(roadVehicleVersion.getMake());
			dto.setCategory(roadVehicleVersion.getCategory() != null ? roadVehicleVersion.getCategory().getCode() : null);
		}
		dto.setHasSemt(from.getHasSemt());
		dto.setHasSecondaryInspection(from.getSeconsaryInspection() != null);
	
		return dto;
	}

}
