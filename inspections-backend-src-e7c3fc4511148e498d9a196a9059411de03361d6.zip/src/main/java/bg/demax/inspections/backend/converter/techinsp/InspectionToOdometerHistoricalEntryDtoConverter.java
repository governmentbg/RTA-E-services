package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.OdometerHistoricalEntryDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Inspection;

@Component
public class InspectionToOdometerHistoricalEntryDtoConverter implements Converter<Inspection, OdometerHistoricalEntryDto> {

	@Override
	public OdometerHistoricalEntryDto convert(Inspection from) {
		OdometerHistoricalEntryDto entry = new OdometerHistoricalEntryDto();
		entry.setInspectionDate(from.getInspectionDateTime());
		entry.setOdometerState(from.getRoadVehicleVersion().getCurrentKmState());
		entry.setKtpNumber(from.getPermitLine().getPermit().getPermitNumber());
		entry.setProtocolNumber(from.getId());

		return entry;
	}

}
