package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.SemtCertificateHtmlReportDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.RoadVehicle;
import bg.demax.techinsp.entity.Inspection;

@Component
public class InspectionToSemtCertificateHtmlReportDtoConverter implements Converter<Inspection, SemtCertificateHtmlReportDto> {

	@Override
	public SemtCertificateHtmlReportDto convert(Inspection from) {
		SemtCertificateHtmlReportDto dto = new SemtCertificateHtmlReportDto();
		
		if (from.getRoadVehicleVersion() != null) {
			dto.setRegistrationNumber(from.getRoadVehicleVersion().getRegistrationNumber());
		}
		
		RoadVehicle vehicle = from.getRoadVehicle();
		if (vehicle != null) {
			dto.setVinFrameNumber(vehicle.getVin() != null ? vehicle.getVin() : vehicle.getFrameNumber());
		}
		
		if (from.getSemtCertificate() != null && from.getSemtCertificate().getSemtCerticationDetails() != null) {
			dto.setEcoCategory(from.getSemtCertificate().getSemtCerticationDetails().getEcoCategoryCode());
		}
		
		dto.setNextInspectionDate(from.getNextInspectionDate());
		
		return dto;
	}

}
