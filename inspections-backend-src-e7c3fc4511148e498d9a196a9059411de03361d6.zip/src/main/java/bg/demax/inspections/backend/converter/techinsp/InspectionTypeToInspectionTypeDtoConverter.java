package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.InspectionTypeDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.InspectionType;

@Component
public class InspectionTypeToInspectionTypeDtoConverter implements Converter<InspectionType, InspectionTypeDto> {

	@Override
	public InspectionTypeDto convert(InspectionType type) {
		InspectionTypeDto dto = new InspectionTypeDto();
		dto.setCode(type.getCode());
		dto.setTiiaDescription(type.getTiiaDescription());
		return dto;
	}
}
