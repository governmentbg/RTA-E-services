package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountByKtpNumberReportRowDto;
import bg.demax.inspections.backend.export.report.InspectionTypesCountByKtpReportRow;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionTypesCountByKtpNumberReportRowDtoToInspectionTypesCountByKtpReportRowConverter
				implements Converter<InspectionTypesCountByKtpNumberReportRowDto, InspectionTypesCountByKtpReportRow> {

	@Override
	public InspectionTypesCountByKtpReportRow convert(InspectionTypesCountByKtpNumberReportRowDto from) {
		InspectionTypesCountByKtpReportRow row = new InspectionTypesCountByKtpReportRow();
		row.setConclusion(from.getConclusion());
		row.setInspectionsCount(from.getInspectionsCount());
		row.setInspectionType(from.getInspectionType());
		row.setKtpNumber(from.getKtpNumber());
		row.setVehicleCategoryCode(from.getVehicleCategoryCode());
		return row;
	}
}
