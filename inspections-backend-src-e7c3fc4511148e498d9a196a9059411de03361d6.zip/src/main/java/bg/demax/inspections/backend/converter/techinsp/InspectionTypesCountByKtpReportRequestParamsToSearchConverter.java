package bg.demax.inspections.backend.converter.techinsp;

import java.time.LocalTime;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.controller.param.techinsp.InspectionTypesCountByKtpReportRequestParams;
import bg.demax.inspections.backend.search.techinsp.InspectionTypesCountByKtpNumberReportSearch;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionTypesCountByKtpReportRequestParamsToSearchConverter
				implements Converter<InspectionTypesCountByKtpReportRequestParams, InspectionTypesCountByKtpNumberReportSearch> {

	@Override
	public InspectionTypesCountByKtpNumberReportSearch convert(InspectionTypesCountByKtpReportRequestParams from) {
		InspectionTypesCountByKtpNumberReportSearch search = new InspectionTypesCountByKtpNumberReportSearch();
		search.setFromDate(from.getFromDate().atStartOfDay());
		search.setToDate(from.getToDate().atTime(LocalTime.MAX));
		search.setKtpNumber(from.getKtpNumber());
		return search;
	}
}
