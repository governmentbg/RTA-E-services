package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountByKtpNumberReportRowDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountByKtpResult;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionTypesCountByKtpResultToInspectionTypesCountByKtpNumberReportRowDto 
	implements Converter<InspectionTypesCountByKtpResult, InspectionTypesCountByKtpNumberReportRowDto> {

	@Override
	public InspectionTypesCountByKtpNumberReportRowDto convert(InspectionTypesCountByKtpResult from) {
		InspectionTypesCountByKtpNumberReportRowDto dto = new InspectionTypesCountByKtpNumberReportRowDto();
		if (from.getConclusion() != null && from.getConclusion().getDescription() != null) {
			dto.setConclusion(from.getConclusion().getDescription());			
		}
		
		if (from.getInspectionsCount() != null) {
			dto.setInspectionsCount(from.getInspectionsCount());			
		}
		
		if (from.getInspectionType() != null) {
			dto.setInspectionType(from.getInspectionType());			
		}
		
		if (from.getKtpNumber() != null) {
			dto.setKtpNumber(from.getKtpNumber());			
		}
		
		if (from.getVehicleCategory() != null) {
			dto.setVehicleCategoryCode(from.getVehicleCategory().getCode());			
		}
		return dto;
	}

}
