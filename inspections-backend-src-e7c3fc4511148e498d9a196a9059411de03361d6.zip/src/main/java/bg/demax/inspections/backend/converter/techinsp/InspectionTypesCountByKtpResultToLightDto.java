package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountByKtpReportLightDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountByKtpResult;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionTypesCountByKtpResultToLightDto  
		implements Converter<InspectionTypesCountByKtpResult, InspectionTypesCountByKtpReportLightDto> {

	@Override
	public InspectionTypesCountByKtpReportLightDto convert(InspectionTypesCountByKtpResult from) {
		InspectionTypesCountByKtpReportLightDto dto = new InspectionTypesCountByKtpReportLightDto();
		
		dto.setKtpNumber(from.getKtpNumber());
		dto.setInspectionType(from.getInspectionType());
		if (from.getVehicleCategory() != null) {
			dto.setVehicleCategoryCode(from.getVehicleCategory().getCode());
		}
		dto.setConclusion(from.getConclusion());
		dto.setInspectionsCount(from.getInspectionsCount());
		
		return dto;
	}

}
