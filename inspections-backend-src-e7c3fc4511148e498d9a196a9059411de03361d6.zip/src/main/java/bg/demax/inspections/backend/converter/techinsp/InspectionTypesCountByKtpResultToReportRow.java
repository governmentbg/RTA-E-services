package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountByKtpResult;
import bg.demax.inspections.backend.export.report.InspectionTypesCountByKtpReportRow;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionTypesCountByKtpResultToReportRow implements 
	Converter<InspectionTypesCountByKtpResult, InspectionTypesCountByKtpReportRow> {

	@Override
	public InspectionTypesCountByKtpReportRow convert(InspectionTypesCountByKtpResult from) {
		InspectionTypesCountByKtpReportRow dto = new InspectionTypesCountByKtpReportRow();
		
		dto.setKtpNumber(from.getKtpNumber());
		dto.setInspectionType(from.getInspectionType());
		if (from.getVehicleCategory() != null) {
			dto.setVehicleCategoryCode(from.getVehicleCategory().getCode());
		}
		if (from.getConclusion() != null && from.getConclusion().getDescription() != null) {
			dto.setConclusion(from.getConclusion().getDescription());		
		}
		dto.setInspectionsCount(from.getInspectionsCount());
		
		return dto;
	
	}

}
