package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.controller.param.techinsp.InspectionTypesCountReportRequestParams;
import bg.demax.inspections.backend.search.techinsp.InspectionTypesCountByOrgUnitReportSearch;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionTypesCountReportRequestParamsToSearchConverter
				implements Converter<InspectionTypesCountReportRequestParams, InspectionTypesCountByOrgUnitReportSearch> {

	@Override
	public InspectionTypesCountByOrgUnitReportSearch convert(InspectionTypesCountReportRequestParams params) {
		InspectionTypesCountByOrgUnitReportSearch search = new InspectionTypesCountByOrgUnitReportSearch();
		search.setFromDate(params.getFromDate().atStartOfDay());
		search.setToDate(params.getToDate().atTime(23, 59, 59));
		search.setOrgUnitCode(params.getOrgUnitCode());
		search.setVehicleCategoryCode(params.getVehicleCategoryCode());
		return search;
	}
}
