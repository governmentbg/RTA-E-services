package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountReportLightDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountResult;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionTypesCountResultToLightDto implements Converter<InspectionTypesCountResult, InspectionTypesCountReportLightDto> {

	@Override
	public InspectionTypesCountReportLightDto convert(InspectionTypesCountResult from) {
		InspectionTypesCountReportLightDto dto = new InspectionTypesCountReportLightDto();
		
		dto.setInspectionType(from.getInspectionType());
		dto.setConclusion(from.getConclusion());
		dto.setInspectionsCount(from.getInspectionsCount());
		return dto;
	}
}
