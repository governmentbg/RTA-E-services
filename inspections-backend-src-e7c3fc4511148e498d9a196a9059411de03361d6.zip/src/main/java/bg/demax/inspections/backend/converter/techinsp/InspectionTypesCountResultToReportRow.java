package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountResult;
import bg.demax.inspections.backend.export.report.InspectionTypesCountReportRow;
import bg.demax.legacy.util.convert.Converter;

@Component
public class InspectionTypesCountResultToReportRow implements Converter<InspectionTypesCountResult, InspectionTypesCountReportRow> {

	@Override
	public InspectionTypesCountReportRow convert(InspectionTypesCountResult from) {
		InspectionTypesCountReportRow dto = new InspectionTypesCountReportRow();
		
		if (from.getInspectionType() != null) {
			dto.setInspectionType(from.getInspectionType());			
		}
		if (from.getConclusion() != null) {
			dto.setConclusion(from.getConclusion().getDescription());			
		}
		if (from.getInspectionsCount() != null) {
			dto.setInspectionsCount(from.getInspectionsCount());			
		}
		
		return dto;
	}

}
