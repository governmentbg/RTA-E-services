package bg.demax.inspections.backend.converter.techinsp;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.comparator.Comparators;

import bg.demax.inspections.backend.dto.techinsp.GasSystemDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionFaultDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypeDto;
import bg.demax.inspections.backend.dto.techinsp.RoadVehicleDto;
import bg.demax.inspections.backend.dto.techinsp.SemtDetailsDto;
import bg.demax.inspections.backend.dto.techinsp.TaxCheckResultDto;
import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineOrgUnitDto;
import bg.demax.inspections.backend.entity.vehicletax.Check;
import bg.demax.inspections.backend.entity.vehicletax.CheckResult;
import bg.demax.inspections.backend.entity.vehicletax.MinistryOfFinanceError;
import bg.demax.inspections.backend.entity.vehicletax.MinistryOfFinanceErrorType;
import bg.demax.inspections.backend.entity.vehicletax.MinistryOfFinanceResponse;
import bg.demax.inspections.backend.entity.vehicletax.MinistryOfFinanceResponseType;
import bg.demax.inspections.backend.entity.vehicletax.MunicipalityError;
import bg.demax.inspections.backend.entity.vehicletax.MunicipalityErrorType;
import bg.demax.inspections.backend.entity.vehicletax.MunicipalityResponse;
import bg.demax.inspections.backend.entity.vehicletax.MunicipalityResponseType;
import bg.demax.inspections.backend.util.InspectionPathUtil;
import bg.demax.inspections.backend.vo.techinsp.AbstractInspElementVo;
import bg.demax.inspections.backend.vo.techinsp.InspElementVo;
import bg.demax.inspections.backend.vo.techinsp.InspProtocolVo;
import bg.demax.inspections.backend.vo.techinsp.InspRemarkVo;
import bg.demax.inspections.backend.vo.techinsp.InspectionVo;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.GasSystem;
import bg.demax.techinsp.entity.Inspection;
import bg.demax.techinsp.entity.InspectionCheckValue;
import bg.demax.techinsp.entity.InspectionElementCardinality;
import bg.demax.techinsp.entity.InspectionStatus;
import bg.demax.techinsp.entity.InspectionStopReason;
import bg.demax.techinsp.entity.PermitInspector;
import bg.demax.techinsp.entity.TerminatedInspection;

@Component
public class InspectionVoToInspectionDtoConverter implements Converter<InspectionVo, InspectionDto> {

	@Autowired
	private ConversionService conversionService;

	@Autowired
	private InspectionPathUtil inspectionUtil;

	@Override
	public InspectionDto convert(InspectionVo inspectionVo) {
		Inspection inspection = inspectionVo.getInspection();

		InspectionDto dto = new InspectionDto();
		dto.setId(inspection.getId());
		if (inspection.getConclusion() != null) {
			dto.setConclusionCode(inspection.getConclusion().name());
		}

		if (inspection.getCurrentStatus() != null) {
			dto.setStatusCode(inspection.getCurrentStatus().getCode());

			if (InspectionStatus.STOPPED.getCode().equals(inspection.getCurrentStatus().getCode())
				|| InspectionStatus.INVALID.getCode().equals(inspection.getCurrentStatus().getCode())) {
				TerminatedInspection trminatedInspection = inspection.getTerminatedInspection();
				if (trminatedInspection != null) {
					if (InspectionStopReason.OTHER_CODE.equals(trminatedInspection.getStopReason().getCode())) {
						dto.setStopReason(trminatedInspection.getOtherStopReason());
					} else {
						dto.setStopReason(trminatedInspection.getStopReason().getDescription());
					}
				}
			}
		}

		if (inspection.getPermitLine() != null && inspection.getPermitLine().getPermit() != null) {
			dto.setPermit(conversionService.convert(inspection.getPermitLine(), PermitLineOrgUnitDto.class));
		}

		dto.setPersonEgn(getValueIfValid(inspection.getPersonEGN()));
		dto.setPersonName(getValueIfValid(inspection.getPersonName()));
		dto.setProtocolNumber(getValueIfValid(inspection.getProtocolNumber()));
		dto.setHologramNumber(getValueIfValid(inspection.getReceivedSignNumber()));
		dto.setStartedAt(inspection.getInspectionDateTime());
		dto.setFinishedAt(inspection.getEndDateTime());
		dto.setValidTo(inspection.getNextInspectionDate());
		if (inspection.getCisternProtocol() != null) {
			dto.setHasCisternProtocol(true);
		} else {
			dto.setHasCisternProtocol(false);
		}
		if (inspection.getInspectionType() != null) {
			dto.setType(conversionService.convert(inspection.getInspectionType(), InspectionTypeDto.class));
		}
		dto.setSuspicious(inspection.getSuspiciousInspection() != null);
		dto.setHasSecondaryInspection(inspection.getSeconsaryInspection() != null);
		if (inspection.getHasSemt() != null) {
			dto.setHasSemt(inspection.getHasSemt().booleanValue());
		}
		if (inspection.getRoadVehicleVersion() != null) {
			dto.setVehicle(conversionService.convert(inspection.getRoadVehicleVersion(), RoadVehicleDto.class));
		}

		PermitInspector chairman = inspection.getChairman();
		if (chairman != null && chairman.getSubjectVersion() != null) {
			dto.setChairmanName(getValueIfValid(chairman.getSubjectVersion().getFullNameIfMissingCyr()));
		}

		PermitInspector member = inspection.getMember1();
		if (member != null && member.getSubjectVersion() != null) {
			dto.setMemberName(getValueIfValid(member.getSubjectVersion().getFullNameIfMissingCyr()));
		}

		List<TaxCheckResultDto> taxChecksListDto = new ArrayList<TaxCheckResultDto>();
		if (inspectionVo.getTaxChecks() != null) {
			inspectionVo.getTaxChecks().forEach(taxCheck -> {
				taxChecksListDto.add(convertTaxCheckToDto(taxCheck));
			});
		}
		
		
		dto.setTaxCheckResults(taxChecksListDto);
		dto.setFaults(convertInspectionElementVosToDtos(new LinkedList<AbstractInspElementVo>(inspectionVo.getProtocols())));
		dto.setShortVideoUrl(inspectionUtil.getInspectionVideoPath(inspectionVo.getInspection().getInspectionDateTime(),
						inspectionVo.getInspection().getId()));

		dto.setSnapShotUrl(inspectionUtil.getInspectionSnapshotPath(inspectionVo.getInspection().getInspectionDateTime(),
						inspectionVo.getInspection().getId()));

		if (inspection.getSemtCertificate() != null) {
			dto.setSemt(conversionService.convert(inspection.getSemtCertificate(), SemtDetailsDto.class));
		}

		if (inspection.getGasSystem() != null) {
			dto.setGasSystem(convertGasSystemToDto(inspection.getGasSystem()));
		}


		return dto;
	}

	private GasSystemDto convertGasSystemToDto(GasSystem from) {
		GasSystemDto dto = new GasSystemDto();
		dto.setFuelType(from.getFuelType().getId().toString());
		dto.setStatusCode(from.getStatus().getDescription());
		dto.setTankMake(from.getTankMake());
		dto.setTankNumberOfApproval(from.getTankNumberOfApproval());
		dto.setTankYearOfProduction(from.getTankYearOfProduction());
		dto.setTankSerialNumber(from.getTankSerialNumber());

		if (from.getInstalletionSubjectVersion() != null) {
			dto.setInstallerFullName(from.getInstalletionSubjectVersion().getFullNameIfMissingCyr());
		}
		
		return dto;
	}

	private TaxCheckResultDto convertTaxCheckToDto(Check taxCheck) {
		if (taxCheck == null) {
			return null;
		}
		TaxCheckResultDto resultDto = new TaxCheckResultDto();
		resultDto.setCheckId(taxCheck.getId());
		for (CheckResult taxCheckResult : taxCheck.getResults()) {
			
			resultDto.setCreatedAt(taxCheckResult.getCreatedAt());
			resultDto.setRegion(taxCheck.getMunicipality().getId().getRegion().getName());
			resultDto.setMunicipality(taxCheck.getMunicipality().getName());

			resultDto.setRegistrationNumber(taxCheck.getPlateNumber());
			
			resultDto.setIdentityNumber(taxCheck.getOwnerIdentNumber());

			if (taxCheckResult instanceof MinistryOfFinanceError) {
				MinistryOfFinanceError resultError = (MinistryOfFinanceError) taxCheckResult;
				MinistryOfFinanceErrorType errorType = resultError.getType();

				resultDto.setMinistryOfFinanceResult(getMinistryOfFinanceErrorBgDescription(errorType));
			} else if (taxCheckResult instanceof MinistryOfFinanceResponse) {
				MinistryOfFinanceResponse resultResponse = (MinistryOfFinanceResponse) taxCheckResult;
				MinistryOfFinanceResponseType responseType = resultResponse.getType();

				resultDto.setMinistryOfFinanceResult(responseType.getDescription());
			} else if (taxCheckResult instanceof MunicipalityError) {
				MunicipalityError resultError = (MunicipalityError) taxCheckResult;
				MunicipalityErrorType errorType = resultError.getType();

				resultDto.setMunicipalityResult(getMunicipalityErrorTypeBgDescription(errorType));
			} else if (taxCheckResult instanceof MunicipalityResponse) {
				MunicipalityResponse resultResponse = (MunicipalityResponse) taxCheckResult;
				MunicipalityResponseType responseType = resultResponse.getType();

				resultDto.setMunicipalityResult(getMunicipalityResponseTypeBgDescription(responseType));
			}
		}
		return resultDto;
	}

	private String getMunicipalityResponseTypeBgDescription(MunicipalityResponseType responseType) {
		if (responseType.getCode().equals(MunicipalityResponseType.HAS_UNPAID_FEES)) {
			return "Има задължения за МДТ";
		} else if (responseType.getCode().equals(MunicipalityResponseType.HAS_UNPAID_FEES_DIFFERENT_PERSON)) {
			return "Има задължения/друг собственик";
		} else if (responseType.getCode().equals(MunicipalityResponseType.INTERNAL_SYSTEM_ERROR)) {
			return "Грешка в системата";
		} else if (responseType.getCode().equals(MunicipalityResponseType.INVALID_KEY_INDEX)) {
			return "Невалиден индекс на ключ";
		} else if (responseType.getCode().equals(MunicipalityResponseType.INVALID_PARAMETER)) {
			return "Невалиден параметър";
		} else if (responseType.getCode().equals(MunicipalityResponseType.INVALID_PARTNER_ID)) {
			return "Невалидно ID на партньор";
		} else if (responseType.getCode().equals(MunicipalityResponseType.INVALID_SIGNATURE)) {
			return "Невалиден подпис";
		} else if (responseType.getCode().equals(MunicipalityResponseType.KEY_PAIR_INACTIVE)) {
			return "Неактивна двойка ключове";
		} else if (responseType.getCode().equals(MunicipalityResponseType.KEY_PAIR_NOT_FOUND)) {
			return "Двойката ключове не може да бъде намерена";
		} else if (responseType.getCode().equals(MunicipalityResponseType.NO_UNPAID_FEES)) {
			return "Няма задължения за МДТ";
		} else if (responseType.getCode().equals(MunicipalityResponseType.NO_UNPAID_FEES_DIFFERENT_PERSON)) {
			return "Няма задължения/друг собственик";
		} else if (responseType.getCode().equals(MunicipalityResponseType.NOT_FOUND)) {
			return "Няма намерен резултат";
		} else if (responseType.getCode().equals(MunicipalityResponseType.PARTNER_INACTIVE)) {
			return "Неактивен партньор";
		} else if (responseType.getCode().equals(MunicipalityResponseType.PARTNER_NOT_FOUND)) {
			return "Партньорът не е намерен";
		} else if (responseType.getCode().equals(MunicipalityResponseType.YOU_HAVE_NO_RIGHT_TO_DO_THIS_OPERATION)) {
			return "Достъпът отказан";
		}
		return null;
	}

	private String getMunicipalityErrorTypeBgDescription(MunicipalityErrorType errorType) {
		if (errorType.getCode().equals(MunicipalityErrorType.INVALID_MUNICIPALITY)) {
			return "Невалидна община";
		} else if (errorType.getCode().equals(MunicipalityErrorType.INVALID_SERVICE_PROVIDER)) {
			return "Невалидна услуга";
		} else if (errorType.getCode().equals(MunicipalityErrorType.SERVICE_CONNECTION_REFUSED)) {
			return "Връзката към услугата отказана";
		} else if (errorType.getCode().equals(MunicipalityErrorType.SERVICE_CONNECTION_TIMEOUT)) {
			return "Времето за отговор изтече";
		} else if (errorType.getCode().equals(MunicipalityErrorType.TAX_CHECK_RESULT_NOT_FOUND)) {
			return "Няма намерен резултат";
		} else if (errorType.getCode().equals(MunicipalityErrorType.UNKNOWN_SERVICE_ERROR)) {
			return "Непредвидена грешка";
		}
		return null;
	}

	private String getMinistryOfFinanceErrorBgDescription(MinistryOfFinanceErrorType errorType) {
		if (errorType.getId().equals(MinistryOfFinanceErrorType.CONNECTION_REFUSED)) {
			return "Връзката е отказана";
		} else if (errorType.getId().equals(MinistryOfFinanceErrorType.CONNECTION_TIMEOUT)) {
			return "Времето за отговор изтече";
		} else if (errorType.getId().equals(MinistryOfFinanceErrorType.UNKNOWN)) {
			return "Непредвидена грешка";
		}
		return null;
	}

	private List<InspectionFaultDto> convertInspectionElementVosToDtos(List<AbstractInspElementVo> elementVos) {
		List<InspectionFaultDto> faultDtos = new LinkedList<>();
		for (AbstractInspElementVo elementVo : elementVos) {
			if (elementVo instanceof InspProtocolVo) {
				InspectionFaultDto faultDto = new InspectionFaultDto(elementVo.getId(), elementVo.getDescIndex(),
								elementVo.getDescription(), null, null, null);
				List<InspectionFaultDto> children = convertInspectionElementVosToDtos(
								new LinkedList<>(((InspProtocolVo) elementVo).getElements()));
				children.sort(Comparators.nullsLow(Comparator.comparing(InspectionFaultDto::getElementId)));
				faultDto.setChildren(children);
				faultDtos.add(faultDto);
			} else if (elementVo instanceof InspElementVo) {
				String value = ((InspElementVo) elementVo).getValue();
				InspectionCheckValue inspectionCheckValue = ((InspElementVo) elementVo).getCheckValue();
				String checkValue = null;
				if (inspectionCheckValue != null) {
					checkValue = inspectionCheckValue.getDescription();
				}

				InspectionFaultDto faultDto = new InspectionFaultDto(elementVo.getId(), elementVo.getDescIndex(),
								elementVo.getDescription(), null, value, checkValue);
				List<InspectionFaultDto> children = convertInspectionElementVosToDtos(
								new LinkedList<>(((InspElementVo) elementVo).getElements()));
				children.addAll(convertInspectionElementVosToDtos(new LinkedList<>(((InspElementVo) elementVo).getRemarks())));
				children.sort(Comparators.nullsLow(Comparator.comparing(InspectionFaultDto::getElementId)));
				faultDto.setChildren(children);
				faultDtos.add(faultDto);
			} else if (elementVo instanceof InspRemarkVo) {
				InspectionElementCardinality elementCardinality = ((InspRemarkVo) elementVo).getCardinality();
				String cardinality = null;
				if (elementCardinality != null) {
					cardinality = elementCardinality.getDescription();
				}
				faultDtos.add(new InspectionFaultDto(elementVo.getId(), elementVo.getDescIndex(), elementVo.getDescription(), cardinality,
								null, null));
			}
		}
		return faultDtos;
	}

	private String getValueIfValid(String value) {
		if (value != null && !value.isEmpty()) {
			return value;
		}
		return null;
	}

	private Long getValueIfValid(Long value) {
		if (value != null && value.compareTo(0L) >= 0) {
			return value;
		}
		return null;
	}
}
