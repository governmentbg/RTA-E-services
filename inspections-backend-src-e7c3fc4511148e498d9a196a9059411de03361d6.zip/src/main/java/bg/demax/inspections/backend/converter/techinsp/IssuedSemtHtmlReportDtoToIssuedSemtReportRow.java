package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.IssuedSemtHtmlReportDto;
import bg.demax.inspections.backend.export.techinsp.IssuedSemtReportRow;
import bg.demax.legacy.util.convert.Converter;

@Component
public class IssuedSemtHtmlReportDtoToIssuedSemtReportRow 
	implements Converter<IssuedSemtHtmlReportDto, IssuedSemtReportRow> {

	@Override
	public IssuedSemtReportRow convert(IssuedSemtHtmlReportDto from) {
		IssuedSemtReportRow dto = new IssuedSemtReportRow();
		if (from.getEcoCategory() != null) {
			dto.setEcoCategory(from.getEcoCategory());			
		}
		
		if (from.getRegistrationNumber() != null) {
			dto.setRegistrationNumber(from.getRegistrationNumber());
		}
		
		if (from.getStatus() != null) {
			dto.setStatus(from.getStatus());
		}
		
		if (from.getValidTo() != null) {
			dto.setValidTo(from.getValidTo().toString());
		}
		
		if (from.getVinFrameNumber() != null) {
			dto.setVinFrameNumber(from.getVinFrameNumber());
		}
		
		return dto;
	}

}
