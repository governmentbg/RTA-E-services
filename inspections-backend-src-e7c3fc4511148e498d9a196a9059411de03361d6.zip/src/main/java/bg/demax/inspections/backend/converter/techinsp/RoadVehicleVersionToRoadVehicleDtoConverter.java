package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.RoadVehicleDto;
import bg.demax.inspections.backend.util.RoadVehicleUtil;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.RoadVehicle;
import bg.demax.pub.entity.RoadVehicleVersion;
import bg.demax.pub.entity.SubjectVersion;

@Component
public class RoadVehicleVersionToRoadVehicleDtoConverter implements Converter<RoadVehicleVersion, RoadVehicleDto> {


	@Override
	public RoadVehicleDto convert(RoadVehicleVersion vehicleVersion) {

		RoadVehicleDto vehicleDto = new RoadVehicleDto();
		vehicleDto.setApprovedType(getValueIfValid(vehicleVersion.getApprovedType()));
		vehicleDto.setAxlesCount(getValueIfValid(vehicleVersion.getAxlesCount()));
		if (vehicleVersion.getCategory() != null) {
			vehicleDto.setCategoryCode(vehicleVersion.getCategory().getCode());
		}
		if (vehicleVersion.getOwnerVersion() != null) {
			SubjectVersion ownerVersion = vehicleVersion.getOwnerVersion();
			vehicleDto.setOwnerName(ownerVersion.getFullNameIfMissingCyr());
			vehicleDto.setOwnerIdentityNumber(getValueIfValid(ownerVersion.getSubject().getIdentityNumber()));
		}
		if (vehicleVersion.getCountry() != null) {
			vehicleDto.setCountryCode(vehicleVersion.getCountry().getCode());
		}
		vehicleDto.setColor(getValueIfValid(vehicleVersion.getColor()));
		vehicleDto.setEcoCategory(getValueIfValid(vehicleVersion.getEcoCategory()));
		vehicleDto.setEngineCapacity(getValueIfValid(vehicleVersion.getEngineCapacity()));
		vehicleDto.setEngineMaxPowerKw(getValueIfValid(vehicleVersion.getEngineMaxPowerKw()));
		vehicleDto.setEngineNumber(getValueIfValid(vehicleVersion.getEngineNumber()));
		vehicleDto.setFirstAxleMassDistributionKg(getValueIfValid(vehicleVersion.getFirstAxleMassDistributionKg()));
		vehicleDto.setFirstRegistrationDate(vehicleVersion.getFirstRegistrationDate());
		vehicleDto.setFuelType(getValueIfValid(getValueIfValid(vehicleVersion.getFuelType())));
		vehicleDto.setCurrentKmState(getValueIfValid(vehicleVersion.getCurrentKmState()));
		RoadVehicle vehicle = vehicleVersion.getRoadVehicle();
		vehicleDto.setIdentityNumber(getValueIfValid(RoadVehicleUtil.getVinOrFrameNumber(vehicle)));
		vehicleDto.setIdentityNumberType(vehicle.getVin() != null ? "VIN" : "Рама");
		vehicleDto.setMakeAndModel(getValueIfValid(vehicleVersion.getMake()));
		vehicleDto.setMassKg(getValueIfValid(vehicleVersion.getMassKg()));
		vehicleDto.setMassTrailerBrakedKg(getValueIfValid(vehicleVersion.getMassTrailerBrakedKg()));
		vehicleDto.setMaxPermissibleMassKg(getValueIfValid(vehicleVersion.getMaxPermissibleMassKg()));
		vehicleDto.setMaxPermissibleTechnicalMass(getValueIfValid(vehicleVersion.getMaxPermissibleTechnicalMass()));
		vehicleDto.setMaxPermissibleWholeMassKg(getValueIfValid(vehicleVersion.getMaxPermissibleWholeMassKg()));
		vehicleDto.setRegistrationNumber(getValueIfValid(vehicleVersion.getRegistrationNumber()));
		vehicleDto.setSeatPlaces(getValueIfValid(vehicleVersion.getSeatPlaces()));
		vehicleDto.setSecondAxleMassDistributionKg(getValueIfValid(vehicleVersion.getSecondAxleMassDistributionKg()));
		vehicleDto.setSoundLevelStationary(getValueIfValid(vehicleVersion.getSoundLevelStationary()));
		vehicleDto.setStandingPlaces(getValueIfValid(vehicleVersion.getStandingPlaces()));
		vehicleDto.setTypeApprovalNumber(getValueIfValid(vehicleVersion.getTypeApprovalNumber()));
		vehicleDto.setRegDocNumber(vehicleVersion.getRegistrationDocumentNumber());
		vehicleDto.setRegDocDate(vehicleVersion.getRegistrationDocumentDate());
		
		return vehicleDto;
	}


	private String getValueIfValid(String value) {
		if (value != null && !value.isEmpty()) {
			return value;
		}
		return null;
	}

	private Short getValueIfValid(Short value) {
		if (value != null && value.compareTo((short) 0) >= 0) {
			return value;
		}
		return null;
	}

	private Integer getValueIfValid(Integer value) {
		if (value != null && value.compareTo(0) >= 0) {
			return value;
		}
		return null;
	}
}
