package bg.demax.inspections.backend.converter.techinsp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.SemtDetailsDto;
import bg.demax.inspections.backend.dto.techinsp.SemtPrintDto;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.SemtCertificate;

@Component
public class SemtCertificateToSemtDetailsDtoConverter implements Converter<SemtCertificate, SemtDetailsDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public SemtDetailsDto convert(SemtCertificate from) {
		SemtDetailsDto dto = new SemtDetailsDto();
		dto.setCompilianceNumber(from.getSemtCerticationDetails().getCompilianceNumber());
		dto.setEngineNumber(from.getSemtCerticationDetails().getEngineNumber());
		dto.setEngineType(from.getSemtCerticationDetails().getEngineType());
		dto.setStatus(from.getStatus().getCode());
		dto.setEcoCategory(from.getSemtCerticationDetails().getEcoCategoryCode());
		dto.setMakeModelLat(from.getSemtCerticationDetails().getVMakeModelLat());
		dto.setIssueDate(from.getSemtCerticationDetails().getDateOfIssuing());
		dto.setChangeVehicleRegisterNumber(from.getRegistrationNumber());

		List<SemtPrintDto> semtPrintListDto = conversionService.convertList(from.getSemtPrints(), SemtPrintDto.class);

		semtPrintListDto.sort((p1, p2) -> {
			return p2.getPrintDate().compareTo(p1.getPrintDate());
		});

		dto.setSemtPrints(semtPrintListDto);

		return dto;
	}

}
