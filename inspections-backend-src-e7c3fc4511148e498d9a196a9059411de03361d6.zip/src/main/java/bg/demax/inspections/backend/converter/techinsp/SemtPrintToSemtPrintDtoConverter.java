package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.SemtPrintDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.SemtPrint;

@Component
public class SemtPrintToSemtPrintDtoConverter implements Converter<SemtPrint, SemtPrintDto> {

	@Override
	public SemtPrintDto convert(SemtPrint from) {
		SemtPrintDto dto = new SemtPrintDto();
		dto.setIsPrintedByIaaa(from.getIsPrintedByIaaa());
		dto.setPrintDate(from.getPrintDate());
		
		return dto;
	}
	
}
