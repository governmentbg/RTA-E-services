package bg.demax.inspections.backend.converter.techinsp;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.converter.OrgUnitToOrgUnitLightDtoConverter;
import bg.demax.inspections.backend.dto.OrgUnitLightDto;
import bg.demax.inspections.backend.dto.techinsp.VideoDownloadRequestLightDto;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.RoadVehicleVersion;
import bg.demax.techinsp.entity.Inspection;
import bg.demax.techinsp.entity.VideoDownload;
import bg.demax.techinsp.entity.VideoDownloadRequest;

@Component
public class VideoDownloadRequestToLightDtoConverter implements Converter<VideoDownloadRequest, VideoDownloadRequestLightDto> {
	@Override
	public VideoDownloadRequestLightDto convert(VideoDownloadRequest from) {
		VideoDownloadRequestLightDto dto = new VideoDownloadRequestLightDto();

		VideoDownload videoDownload = from.getVideoDownload();
		if (videoDownload != null) {
			Inspection inspection = videoDownload.getInspection();
			if (inspection != null) {
				dto.setInspectionStartTime(inspection.getInspectionDateTime());
				dto.setKtpNumber(inspection.getPermitLine().getPermit().getPermitNumber());
				
				OrgUnitLightDto orgUnitDto = new OrgUnitLightDto();
				OrgUnitToOrgUnitLightDtoConverter.convert(inspection.getPermitLine().getPermit().getOrgUnit(), orgUnitDto);
				dto.setOrgUnit(orgUnitDto);
				
				RoadVehicleVersion roadVehicleVersion = inspection.getRoadVehicleVersion();
				if (roadVehicleVersion != null) {
					dto.setRegistrationNumber(roadVehicleVersion.getRegistrationNumber());
				}
				
				dto.setHologramNumber(inspection.getReceivedSignNumber());
				dto.setInspectionType(inspection.getInspectionType() != null ? inspection.getInspectionType().getTiiaDescription() : null);
				dto.setProtocolNumber(inspection.getId());
				dto.setStatusId(videoDownload.getStatus().getId());
			}
		}
		dto.setId(from.getId());
		dto.setRequestedAt(from.getCreationTimestamp());
		return dto;
	}
}
