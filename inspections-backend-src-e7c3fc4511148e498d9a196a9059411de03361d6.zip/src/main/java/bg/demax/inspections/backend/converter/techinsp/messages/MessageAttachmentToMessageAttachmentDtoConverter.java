package bg.demax.inspections.backend.converter.techinsp.messages;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.messages.MessageAttachmentDto;
import bg.demax.inspections.backend.entity.techinsp.MessageAttachment;
import bg.demax.legacy.util.convert.Converter;

@Component
public class MessageAttachmentToMessageAttachmentDtoConverter implements Converter<MessageAttachment, MessageAttachmentDto> {

	@Override
	public MessageAttachmentDto convert(MessageAttachment from) {
		MessageAttachmentDto dto = new MessageAttachmentDto();
		dto.setId(from.getId());
		dto.setMimeType(from.getMimeType());
		dto.setFilename(from.getFilename());
		return dto;
	}
}
