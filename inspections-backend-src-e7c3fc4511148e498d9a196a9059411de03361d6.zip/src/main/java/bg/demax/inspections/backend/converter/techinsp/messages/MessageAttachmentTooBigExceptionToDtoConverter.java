package bg.demax.inspections.backend.converter.techinsp.messages;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.messages.MessageAttachmentTooBigExceptionDto;
import bg.demax.inspections.backend.service.techinsp.MessageAttachmentTooBigException;
import bg.demax.legacy.util.convert.Converter;

@Component
public class MessageAttachmentTooBigExceptionToDtoConverter
				implements Converter<MessageAttachmentTooBigException, MessageAttachmentTooBigExceptionDto> {

	@Override
	public MessageAttachmentTooBigExceptionDto convert(MessageAttachmentTooBigException from) {
		MessageAttachmentTooBigExceptionDto dto = new MessageAttachmentTooBigExceptionDto();
		dto.setError(from.getError());
		dto.setMessage(from.getMessage());
		dto.setAttachmentFileName(from.getAttachmentFileName());
		dto.setAttachmentSizeKB(from.getAttachmentSizeKB());
		dto.setMaxAttachmentSizeKB(from.getMaxAttachmentSizeKB());
		return dto;
	}
}
