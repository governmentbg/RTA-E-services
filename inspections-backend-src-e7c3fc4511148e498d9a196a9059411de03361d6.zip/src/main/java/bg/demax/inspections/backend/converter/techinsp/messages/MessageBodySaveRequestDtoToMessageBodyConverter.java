package bg.demax.inspections.backend.converter.techinsp.messages;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.messages.MessageBodySaveRequestDto;
import bg.demax.inspections.backend.entity.techinsp.MessageBody;
import bg.demax.legacy.util.convert.Converter;

@Component
public class MessageBodySaveRequestDtoToMessageBodyConverter implements Converter<MessageBodySaveRequestDto, MessageBody> {

	@Override
	public MessageBody convert(MessageBodySaveRequestDto dto) {
		MessageBody body = new MessageBody();
		body.setSubject(dto.getSubject());
		body.setBody(dto.getBody());
		return body;
	}
}
