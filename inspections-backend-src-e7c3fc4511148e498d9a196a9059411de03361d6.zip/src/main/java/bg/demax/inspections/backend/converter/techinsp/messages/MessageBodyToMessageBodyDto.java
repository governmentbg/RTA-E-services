package bg.demax.inspections.backend.converter.techinsp.messages;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.messages.MessageBodyDto;
import bg.demax.inspections.backend.entity.techinsp.MessageBody;
import bg.demax.legacy.util.convert.Converter;

@Component
public class MessageBodyToMessageBodyDto implements Converter<MessageBody, MessageBodyDto> {

	@Override
	public MessageBodyDto convert(MessageBody messageBody) {
		MessageBodyDto dto = new MessageBodyDto();
		dto.setId(messageBody.getId());
		dto.setSubject(messageBody.getSubject());
		dto.setBody(messageBody.getBody());
		
		return dto;
	}

}
