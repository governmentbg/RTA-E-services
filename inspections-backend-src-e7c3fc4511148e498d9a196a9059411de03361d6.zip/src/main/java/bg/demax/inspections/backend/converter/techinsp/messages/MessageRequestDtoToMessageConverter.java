package bg.demax.inspections.backend.converter.techinsp.messages;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.messages.MessageRequestDto;
import bg.demax.inspections.backend.entity.techinsp.Message;
import bg.demax.inspections.backend.entity.techinsp.MessageAttachment;
import bg.demax.inspections.backend.entity.techinsp.MessageBody;
import bg.demax.inspections.backend.entity.techinsp.MessageRecipientType;
import bg.demax.inspections.backend.entity.techinsp.enums.MessageStatus;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.techinsp.entity.Permit;

@Component
public class MessageRequestDtoToMessageConverter implements Converter<MessageRequestDto, Message> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public Message convert(MessageRequestDto dto) {
		Message message = new Message();

		message.setRecipientType(convertMessageRecipientType(dto.getRecipientType()));
		message.setBody(conversionService.convert(dto.getBody(), MessageBody.class));
		
		if (dto.getPermitIds() != null && !dto.getPermitIds().isEmpty()) {

			for (Integer permitId : dto.getPermitIds()) {
				Permit permit = new Permit();
				permit.setId(permitId);
				message.addPermit(permit);
			}
		}
		message.setSender(dto.getSender());
		if (dto.getStatusCode() != null && MessageStatus.SENT.equals(dto.getStatusCode())) {			
			MessageStatus status = new MessageStatus();
			status.setCode(MessageStatus.SENT);
			message.setStatus(status);
		}
		
		Set<MessageAttachment> attachments = new HashSet<>();
		for (Integer attachmentId : dto.getAttachmentIds()) {
			if (attachmentId != null) {
				MessageAttachment attachment = new MessageAttachment();
				attachment.setId(attachmentId);
				attachments.add(attachment);
			}
		}
		message.setAttachments(attachments);
		return message;
	}

	private MessageRecipientType convertMessageRecipientType(
					bg.demax.inspections.backend.dto.techinsp.messages.MessageRecipientType recipientType) {
		MessageRecipientType type = new MessageRecipientType();
		switch (recipientType) {
			case ALL:
				type.setCode(MessageRecipientType.ALL_CODE);
				return type;
			case ORG_UNIT:
				type.setCode(MessageRecipientType.ORG_UNIT_CODE);
				return type;
			case PERMIT:
				type.setCode(MessageRecipientType.PERMIT_CODE);
				return type;
			default:
				return null;
		}
	}
}