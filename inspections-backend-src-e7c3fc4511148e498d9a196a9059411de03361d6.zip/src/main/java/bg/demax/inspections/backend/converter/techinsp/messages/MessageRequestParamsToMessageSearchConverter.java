package bg.demax.inspections.backend.converter.techinsp.messages;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.controller.param.techinsp.messages.MessageRequestParams;
import bg.demax.inspections.backend.search.techinsp.MessageSearch;
import bg.demax.legacy.util.convert.Converter;

@Component
public class MessageRequestParamsToMessageSearchConverter implements Converter<MessageRequestParams, MessageSearch> {

	@Override
	public MessageSearch convert(MessageRequestParams params) {
		MessageSearch search = new MessageSearch();
		if (params.getSubject() != null && !params.getSubject().isEmpty()) {
			search.setSubject(params.getSubject());
		}
		return search;
	}
}
