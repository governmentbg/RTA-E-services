package bg.demax.inspections.backend.converter.techinsp.messages;

import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.messages.MessageStatusRequestDto;
import bg.demax.inspections.backend.entity.techinsp.enums.MessageStatus;
import bg.demax.legacy.util.convert.Converter;

@Component
public class MessageStatusRequestDtoToMessageStatusConverter implements Converter<MessageStatusRequestDto, MessageStatus> {

	@Override
	public MessageStatus convert(MessageStatusRequestDto dto) {
		MessageStatus status = new MessageStatus();
		status.setCode(dto.getStatusCode());
		return status;
	}
}
