package bg.demax.inspections.backend.converter.techinsp.messages;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.messages.MessageAttachmentDto;
import bg.demax.inspections.backend.dto.techinsp.messages.MessageDto;
import bg.demax.inspections.backend.dto.techinsp.messages.MessageLightDto;
import bg.demax.inspections.backend.entity.techinsp.Message;
import bg.demax.inspections.backend.vo.techinsp.MessageVo;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;

@Component
public class MessageVoToMessageDtoConverter implements Converter<MessageVo, MessageDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public MessageDto convert(MessageVo from) {
		MessageLightDto lightDto = conversionService.convert(from, MessageLightDto.class);
		MessageDto dto = new MessageDto();
		BeanUtils.copyProperties(lightDto, dto);

		Message message = from.getMessage();
		List<MessageAttachmentDto> attachmentDtos = conversionService.convertSet(message.getAttachments(), MessageAttachmentDto.class)
						.stream().sorted((a1, a2) -> {
							return Integer.compare(a1.getId(), a2.getId());
						}).collect(Collectors.toList());
		dto.setAttachments(attachmentDtos);
		return dto;
	}
}
