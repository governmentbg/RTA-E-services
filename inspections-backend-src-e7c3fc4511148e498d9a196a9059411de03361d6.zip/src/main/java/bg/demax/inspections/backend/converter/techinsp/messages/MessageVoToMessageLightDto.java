package bg.demax.inspections.backend.converter.techinsp.messages;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.inspections.backend.dto.techinsp.messages.MessageBodyDto;
import bg.demax.inspections.backend.dto.techinsp.messages.MessageLightDto;
import bg.demax.inspections.backend.dto.techinsp.messages.MessageRecipientDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDto;
import bg.demax.inspections.backend.entity.techinsp.Message;
import bg.demax.inspections.backend.entity.techinsp.MessageRecipientType;
import bg.demax.inspections.backend.vo.techinsp.MessageVo;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.pub.entity.OrgUnit;

@Component
public class MessageVoToMessageLightDto implements Converter<MessageVo, MessageLightDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public MessageLightDto convert(MessageVo vo) {
		Message message = vo.getMessage();
		MessageLightDto dto = new MessageLightDto();
		dto.setId(message.getId());
		dto.setCreatedAt(message.getCreatedAt());
		dto.setSentAt(message.getSentAt());
		dto.setSender(message.getSender());
		MessageRecipientDto recipientDto = convertMessageRecipientToDto(vo);
		dto.setRecipient(recipientDto);
		dto.setStatusCode(message.getStatus().getCode());
		dto.setBody(conversionService.convert(message.getBody(), MessageBodyDto.class));
		if (vo.getPermits() != null && !vo.getPermits().isEmpty()
				&& MessageRecipientType.PERMIT_CODE.equals(message.getRecipientType().getCode())) {	
			 	
			dto.setPermits(new ArrayList<>(conversionService.convertSet(vo.getPermits(), PermitDto.class)));
		}
		return dto;
	}

	private MessageRecipientDto convertMessageRecipientToDto(MessageVo vo) {
		Message message = vo.getMessage();
		if (MessageRecipientType.ALL_CODE.equals(message.getRecipientType().getCode())) {
			return new MessageRecipientDto(bg.demax.inspections.backend.dto.techinsp.messages.MessageRecipientType.ALL,
					"Всички", null, null);
		} else if (MessageRecipientType.PERMIT_CODE.equals(message.getRecipientType().getCode())) {
			return new MessageRecipientDto(
					bg.demax.inspections.backend.dto.techinsp.messages.MessageRecipientType.PERMIT, null, null, null);
		} else if (MessageRecipientType.ORG_UNIT_CODE.equals(message.getRecipientType().getCode())
				|| MessageRecipientType.UNKNOWN_CODE.equals(message.getRecipientType().getCode())) {
			List<OrgUnit> orgUnits = vo.getOrgUnits();

			StringBuilder orgUnitNames = new StringBuilder();
			int i = 0;
			for (OrgUnit orgUnit : orgUnits) {
				orgUnitNames.append(orgUnit.getShortName());
				if (i++ != orgUnits.size() - 1) {
					orgUnitNames.append(", ");
				}
			}
			return new MessageRecipientDto(
					bg.demax.inspections.backend.dto.techinsp.messages.MessageRecipientType.ORG_UNIT,
					orgUnitNames.toString(), orgUnits.get(0).getCode(), null);
		}
		return null;
	}
}
