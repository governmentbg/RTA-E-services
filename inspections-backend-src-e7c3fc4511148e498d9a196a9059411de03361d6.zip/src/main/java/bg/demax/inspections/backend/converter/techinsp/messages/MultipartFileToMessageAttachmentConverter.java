package bg.demax.inspections.backend.converter.techinsp.messages;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;

import bg.demax.inspections.backend.entity.techinsp.MessageAttachment;
import bg.demax.inspections.backend.exception.ApplicationException;
import bg.demax.inspections.backend.exception.techinsp.InvalidAttachmentFileTypeException;
import bg.demax.legacy.util.convert.Converter;

@Component
public class MultipartFileToMessageAttachmentConverter implements Converter<MultipartFile, MessageAttachment> {

	private static final Set<String> ALLOWED_FILE_CONTENT_TYPES = new HashSet<>(
			Arrays.asList(MediaType.APPLICATION_PDF_VALUE, MediaType.IMAGE_PNG_VALUE, MediaType.IMAGE_JPEG_VALUE));

	@Override
	public MessageAttachment convert(MultipartFile from) {
		if (!ALLOWED_FILE_CONTENT_TYPES.contains(from.getContentType())) {
			throw new InvalidAttachmentFileTypeException("File type not supported. Supported type are: "
					+ Arrays.toString(ALLOWED_FILE_CONTENT_TYPES.toArray()));
		}
		MessageAttachment attachment = new MessageAttachment();
		try {
			if (from.getContentType().equals(MediaType.APPLICATION_PDF_VALUE)) {
				PdfReader reader = new PdfReader(new ByteArrayInputStream(from.getBytes()));

				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

				PdfStamper stamper = new PdfStamper(reader, byteArrayOutputStream, '4');
				stamper.close();

				attachment.setContent(byteArrayOutputStream.toByteArray());
			} else {
				attachment.setContent(from.getBytes());
			}

		} catch (IOException | DocumentException e) {
			throw new ApplicationException("Could not get contents of file with filename=" + from.getOriginalFilename(), e);
		}
		attachment.setFilename(from.getOriginalFilename());
		attachment.setMimeType(from.getContentType());
		return attachment;
	}
}
