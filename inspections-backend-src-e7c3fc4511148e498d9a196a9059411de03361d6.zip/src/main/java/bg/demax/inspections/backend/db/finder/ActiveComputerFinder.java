package bg.demax.inspections.backend.db.finder;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.inspections.backend.entity.ActiveComputer;
import bg.demax.inspections.backend.search.ActiveComputerSearch;

@Repository
public class ActiveComputerFinder extends AbstractFinder {

	private static final int ACTIVE_INTERVAL_SECONDS = 120;
	
	@Autowired
	private GenericSearchSupport searchSupport;

	public List<ActiveComputer> findBySearch(ActiveComputerSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT activeComputer ")
					.append("FROM ActiveComputer activeComputer ")
					.append("JOIN FETCH activeComputer.device device ")
					.append("JOIN FETCH device.permitLineHardware devicePermitLineHardware ")
					.append("JOIN FETCH devicePermitLineHardware.permitLine devicePermitLine ")
					.append("JOIN FETCH devicePermitLine.permit devicePermit ")
					.append("JOIN FETCH devicePermit.orgUnit devicePermitOrgUnit ")
					.append("JOIN FETCH devicePermit.subject devicePermitSubject ")
					.append("JOIN FETCH devicePermitSubject.currentVersion devicePermitSubjectVersion ")
					.append("LEFT JOIN FETCH device.ipAddress deviceIpAddress ")
					.append("LEFT JOIN FETCH device.macAddress deviceMacAddress ")

					.append("WHERE activeComputer.lastActiveAt >= :lastActiveTime ");
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString += " ORDER BY activeComputer.lastActiveAt DESC, activeComputer.id DESC ";
		return createQuery(queryString, ActiveComputer.class)
			.setProperties(search)
			.setParameter("lastActiveTime", LocalDateTime.now().minusSeconds(ACTIVE_INTERVAL_SECONDS))
			.getResultList();
	}
}
