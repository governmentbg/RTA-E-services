package bg.demax.inspections.backend.db.finder;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.inspections.backend.controller.param.BillOfLadingPageRequest;
import bg.demax.inspections.backend.entity.inspection.InspectionDeliveryProtocolBillOfLading;
import bg.demax.inspections.backend.search.orders.InspectionDeliveryProtocolBillOfLadingSearch;

@Repository
public class BillOfLadingFinder extends AbstractFinder {

	@Autowired
	private PagingAndSortingSupport pagingSupport;

	@Autowired
	private GenericSearchSupport searchSupport;

	public List<InspectionDeliveryProtocolBillOfLading> getInspectionDeliveryProtocolBillOfLadings(
					InspectionDeliveryProtocolBillOfLadingSearch search, BillOfLadingPageRequest pageRequest) {

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT DISTINCT b FROM InspectionDeliveryProtocolBillOfLading b ")
					.append("LEFT JOIN b.protocols p ");

		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString += " ORDER BY b.destinationOrgUnit.code ASC ";
		queryString = pagingSupport.applySorting(queryString, pageRequest);

		Query<InspectionDeliveryProtocolBillOfLading> query = createQuery(queryString,
				InspectionDeliveryProtocolBillOfLading.class);
		query.setProperties(search);
		
		if (pageRequest != null) {
			pagingSupport.applyPaging(query, pageRequest);
		}
		
		return query.getResultList();
	}
	
	public List<InspectionDeliveryProtocolBillOfLading> getInspectionDeliveryProtocolBillOfLadings(
					InspectionDeliveryProtocolBillOfLadingSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT b FROM InspectionDeliveryProtocolBillOfLading b ");
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		
		Query<InspectionDeliveryProtocolBillOfLading> query = createQuery(queryString,
				InspectionDeliveryProtocolBillOfLading.class);	
		query.setProperties(search);
	
		return query.getResultList();
	}
	
	public InspectionDeliveryProtocolBillOfLading getInspectionDeliveryProtocolBillOfLading(
			InspectionDeliveryProtocolBillOfLadingSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT b FROM InspectionDeliveryProtocolBillOfLading b ")
					.append("LEFT JOIN b.protocols p ");

		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
	
		Query<InspectionDeliveryProtocolBillOfLading> query = createQuery(queryString,
				InspectionDeliveryProtocolBillOfLading.class);
		query.setProperties(search);

		return (InspectionDeliveryProtocolBillOfLading) query.uniqueResult();
	}
	
	public List<InspectionDeliveryProtocolBillOfLading> findAllByStatusesAndOlderThenToday(List<String> statuses) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM InspectionDeliveryProtocolBillOfLading b ")
					.append("WHERE b.status.code IN (:statuses) AND DATE(b.createdAt) < current_date()");
		
		return createQuery(queryBuilder.toString(), InspectionDeliveryProtocolBillOfLading.class)
						.setParameterList("statuses", statuses)
						.list();
	}
	
	public int getInspectionDeliveryProtocolBillOfLadingCount(InspectionDeliveryProtocolBillOfLadingSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count(DISTINCT b) FROM InspectionDeliveryProtocolBillOfLading b ")
					.append("LEFT JOIN b.protocols p ");

		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		Number count = (Number) createQuery(queryString).setProperties(search).uniqueResult();
		return count == null ? 0 : count.intValue();
	}
	
}
