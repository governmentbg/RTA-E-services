package bg.demax.inspections.backend.db.finder;

import java.util.List;

import org.springframework.stereotype.Repository;

import bg.demax.pub.entity.City;

@Repository
public class CityFinder extends bg.demax.pub.finder.CityFinder {

	public List<City> findByOrgUnitCode(String orgUnitCode) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
				.append("SELECT c.* FROM public.n_cities AS c ")
				.append("INNER JOIN ")
				.append("(SELECT ou.code AS ou_code, ou_c.code AS c_code, r.code AS r_code FROM public.n_org_units AS ou ")
				.append("INNER JOIN public.n_cities AS ou_c ")
				.append("ON ou.city_code = ou_c.code ")
				.append("INNER JOIN public.n_regions AS r ")
				.append("ON ou_c.region_code = r.code ")
				.append("WHERE ou.code = :orgUnitCode) AS ou_r_c ")
				.append("ON ou_r_c.r_code = c.region_code ")
				.append("ORDER BY c.name ASC");
		return createNativeQuery(queryBuilder.toString(), City.class).setParameter("orgUnitCode", orgUnitCode).getResultList();
	}
	
	public List<City> findByRegionCode(String regionCode) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
				.append("SELECT c.* FROM public.n_cities AS c ")
				.append("INNER JOIN public.n_regions AS r ")
				.append("ON c.region_code = r.code ")
				.append("WHERE r.code = :regionCode ")
				.append("ORDER BY c.name ASC");
		return createNativeQuery(queryBuilder.toString(), City.class).setParameter("regionCode", regionCode).getResultList();
	}
}
