package bg.demax.inspections.backend.db.finder;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.count.CountStrategy;
import bg.demax.hibernate.count.DefaultCountStrategy;
import bg.demax.hibernate.paging.OrderClause;
import bg.demax.inspections.backend.exception.NoSuchEntityException;

@Repository
public class GenericFinderPlus extends AbstractFinder {

	private Map<Integer, CountStrategy> countStrategies = new TreeMap<>();

	public GenericFinderPlus() {
		CountStrategy defaultCountStrategy = new DefaultCountStrategy();
		countStrategies.put(defaultCountStrategy.getOrder(), defaultCountStrategy);
	}

	public <ENTITY_TYPE> ENTITY_TYPE findById(Class<ENTITY_TYPE> entityClass, Serializable id) {
		return getSession().byId(entityClass).load(id);
	}

	/**
	 * Find entity or else throw {@link NoSuchEntityException}.
	 */
	public <ENTITY_TYPE> ENTITY_TYPE findByIdOrElseThrowException(Class<ENTITY_TYPE> clazz, Serializable id) {
		ENTITY_TYPE result = this.findById(clazz, id);
		if (result == null) {
			throw new NoSuchEntityException(clazz, id);
		}
		return result;
	}
	
	public <ENTITY_TYPE> ENTITY_TYPE getReferenceById(Class<ENTITY_TYPE> entityClass, Serializable id) {
		return getSession().byId(entityClass).getReference(id);
	}
	
	@SuppressWarnings("unchecked")
	public <ENTITY_TYPE> List<ENTITY_TYPE> findAll(Class<ENTITY_TYPE> entityClass) {
		return (List<ENTITY_TYPE>) createQuery("from " + entityClass.getName()).list();
	}
	
	@SuppressWarnings("unchecked")
	public <ENTITY_TYPE> List<ENTITY_TYPE> findAll(Class<ENTITY_TYPE> entityClass, OrderClause orderClause) {
		return (List<ENTITY_TYPE>) createQuery("from " + entityClass.getName() + " order by " + orderClause.getProperty() + " "
						+ orderClause.getDirection().getCode()).list();
	}
	
}
