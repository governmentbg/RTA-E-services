package bg.demax.inspections.backend.db.finder;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.pub.entity.OperationSystemImageChecksum;
import bg.demax.pub.entity.OperationSystemImageType;

@Repository
public class OperationSystemImageChecksumFinder extends AbstractFinder {

	public OperationSystemImageChecksum getTechinspComputerNewestVersionChecksum() {
		StringBuilder queryBuilder = new StringBuilder();
		
		queryBuilder.append("SELECT osic FROM OperationSystemImageChecksum osic ")
					.append("LEFT JOIN osic.operationSystemImageType osImageType ")
					.append("WHERE osImageType.id = :techinspImageTypeId ")
					.append("ORDER BY osic.timestamp DESC");
		
		Query<OperationSystemImageChecksum> query = createQuery(queryBuilder.toString(), OperationSystemImageChecksum.class);
		
		return query.setMaxResults(1)
					.setParameter("techinspImageTypeId", OperationSystemImageType.ID_TECHINSP_OS_IMAGE)
					.uniqueResult();
	}
}
