package bg.demax.inspections.backend.db.finder;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.inspections.backend.dto.OrgUnitInspectionOrdersVo;
import bg.demax.inspections.backend.entity.inspection.InspectionOrderStatus.InspectionOrderStatuses;
import bg.demax.pub.entity.OrgUnit;

@Repository
public class OrgUnitFinder extends AbstractFinder {

	public List<OrgUnit> findValid() {
		String hql = "from OrgUnit where isValid = :isValid order by code asc";
		return createQuery(hql, OrgUnit.class).setParameter("isValid", true).getResultList();
	}
	
	public List<OrgUnit> findValidWithoutIaaa() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT orgUnit FROM OrgUnit orgUnit ")
					.append("WHERE orgUnit.code != :iaaaCode and orgUnit.isValid = :isValid ")
					.append("ORDER BY orgUnit.code ASC");

		return createQuery(queryBuilder.toString(), OrgUnit.class)
				.setParameter("iaaaCode", "ИААА")
				.setParameter("isValid", true)
				.getResultList();
	}
	
	public List<OrgUnit> findOrgUnitsByParentCode(String parentCode) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT orgUnit FROM OrgUnit orgUnit ")
					.append("WHERE orgUnit.parentOrgUnit.code = :parentCode ")
					.append("ORDER BY orgUnit.code ASC");
		
		return createQuery(queryBuilder.toString(), OrgUnit.class)
				.setParameter("parentCode", parentCode)
				.getResultList();
		
	}
	
	public List<OrgUnitInspectionOrdersVo> findOrgUnitsInspectionOrders() {
		StringBuilder queryBuilder = new StringBuilder();
		
		queryBuilder.append("SELECT new bg.demax.inspections.backend.dto.OrgUnitInspectionOrdersVo")
					.append("(orgUnit, COUNT(CASE orderStatus.code WHEN :statusPaid then 1 else null end), ")
					.append("COUNT(CASE orderStatus.code WHEN :statusPrintLabel then 1 else null end)) ")
					.append("FROM InspectionOrder o ")
					.append("LEFT JOIN o.permitLine permitLine ")
					.append("LEFT JOIN permitLine.permit permit ")
					.append("LEFT JOIN permit.orgUnit orgUnit ")
					.append("LEFT JOIN o.orderStatus orderStatus ")
					.append("WHERE (orderStatus.code = :statusPaid OR orderStatus.code = :statusPrintLabel) ")
					.append("AND orgUnit.isValid = :isValid ")
					.append("GROUP BY orgUnit ")
					.append("ORDER BY orgUnit.shortName");
		
		Query<OrgUnitInspectionOrdersVo> query = createQuery(queryBuilder.toString(), OrgUnitInspectionOrdersVo.class);
				
		return query.setParameter("statusPaid", InspectionOrderStatuses.PAID.getCode())
					.setParameter("statusPrintLabel", InspectionOrderStatuses.PRINT_LABEL.getCode())
					.setParameter("isValid", true)
					.getResultList();
	}
}
