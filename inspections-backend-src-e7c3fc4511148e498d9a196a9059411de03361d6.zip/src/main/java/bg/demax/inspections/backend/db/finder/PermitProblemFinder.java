package bg.demax.inspections.backend.db.finder;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.entity.permit.problem.PermitProblem;
import bg.demax.inspections.backend.search.PermitProblemSearch;

@Repository
public class PermitProblemFinder extends AbstractFinder {

	@Autowired
	private PagingAndSortingSupport pagingSupport;
	
	@Autowired
	private GenericSearchSupport searchSupport;
	
	public List<PermitProblem> findPermitProblemsBySearch(PermitProblemSearch search, PageRequest pageRequest) {
		String queryString = buildSearchString(search);
		queryString = pagingSupport.applySorting(queryString, pageRequest);
		Query<PermitProblem> query = createQuery(queryString, PermitProblem.class);
		pagingSupport.applyPaging(query, pageRequest);
		query.setProperties(search);
		
		return query.getResultList();
	}
	
	public int countPermitProblemsBySearch(PermitProblemSearch search) {
		String queryString = buildSearchString(search);
		String querySearchString = "SELECT COUNT (id) " + queryString;
		
		Number count = createQuery(querySearchString, Number.class).setProperties(search).uniqueResult();
		return count == null ? 0 : count.intValue();
	}
	
	private String buildSearchString(PermitProblemSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM PermitProblem pp");
		String seachString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		return seachString;
	}
}
