package bg.demax.inspections.backend.db.finder;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.search.LogsReportSearch;
import bg.demax.techinsp.entity.PermitsLinesInspectorsLog;

@Repository
public class PermitsLinesInspectorsLogFinder extends AbstractFinder {

	@Autowired
	private PagingAndSortingSupport pagingSupport;

	@Autowired
	private GenericSearchSupport searchSupport;

	public List<PermitsLinesInspectorsLog> findBySearch(LogsReportSearch search, PageRequest pageRequest) {
		return findBySearchAndPageRequest(search, pageRequest);
	}

	public List<PermitsLinesInspectorsLog> findBySearch(LogsReportSearch search) {
		return findBySearchAndPageRequest(search, null);
	}

	public long countBySearch(LogsReportSearch search) {
		String queryString = searchSupport.addSearchConstraints(beginQuery(search, "SELECT COUNT(l.id) "), search);

		Number count = (Number) createQuery(queryString).setProperties(search).uniqueResult();

		return count != null ? count.longValue() : 0;
	}

	private List<PermitsLinesInspectorsLog> findBySearchAndPageRequest(LogsReportSearch search, PageRequest pageRequest) {
		String queryString = searchSupport.addSearchConstraints(beginQuery(search, "SELECT l "), search) + " ORDER BY l.id DESC";

		Query<PermitsLinesInspectorsLog> query = createQuery(queryString, PermitsLinesInspectorsLog.class);

		if (pageRequest != null) {
			pagingSupport.applyPaging(query, pageRequest);
		}

		query.setProperties(search);

		return query.list();
	}

	private String beginQuery(LogsReportSearch search, String selectString) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append(selectString).append("FROM PermitsLinesInspectorsLog l ");

		return queryBuilder.toString();
	}

}
