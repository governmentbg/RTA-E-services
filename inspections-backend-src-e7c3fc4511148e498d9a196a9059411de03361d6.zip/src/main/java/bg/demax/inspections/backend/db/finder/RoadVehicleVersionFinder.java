package bg.demax.inspections.backend.db.finder;

import java.util.List;

import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.pub.entity.RoadVehicleVersion;

@Repository
public class RoadVehicleVersionFinder extends AbstractFinder {

	public List<RoadVehicleVersion> findByOwnerId(long ownerSubjectId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM RoadVehicleVersion vehicleVersion ")
					.append("WHERE vehicleVersion.owner.id = :ownerSubjectId ");
		return createQuery(queryBuilder.toString(), RoadVehicleVersion.class)
						.setParameter("ownerSubjectId", ownerSubjectId)
						.getResultList();
	}
}
