package bg.demax.inspections.backend.db.finder;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectCard;
import bg.demax.inspections.backend.search.SubjectCardsReportSearch;

@Repository
public class SubjectCardFinder extends AbstractFinder {

	@Autowired
	private PagingAndSortingSupport pagingSupport;

	@Autowired
	private GenericSearchSupport searchSupport;

	public List<SubjectCard> findSubjectCardsBySubjectId(long subjectId) {
		StringBuilder hqlBuilder = new StringBuilder();

		hqlBuilder
			.append("FROM SubjectCard c ")
			.append("WHERE c.subject.id = :subjectId ");

		Query<SubjectCard> query = createQuery(hqlBuilder.toString(), SubjectCard.class);
		
		return query.setParameter("subjectId", subjectId).getResultList();
	}
	
	public SubjectCard findCardByCardNumber(int cardNumber) {
		StringBuilder hqlBuilder = new StringBuilder();

		hqlBuilder
			.append("FROM SubjectCard c ")
			.append("WHERE c.cardNumber = :cardNumber ");

		Query<SubjectCard> query = createQuery(hqlBuilder.toString(), SubjectCard.class);

		return query.setParameter("cardNumber", cardNumber).uniqueResult();
	}

	public List<SubjectCard> findCardsForReportBySearch(SubjectCardsReportSearch search, PageRequest pageRequest) {
		return findCardsForReportBySearchAndPageRequest(search, pageRequest);
	}

	public List<SubjectCard> findCardsForReportBySearch(SubjectCardsReportSearch search) {
		return findCardsForReportBySearchAndPageRequest(search, null);
	}
	
	public int countCardsForReportBySearch(SubjectCardsReportSearch search) {
		String queryString = "SELECT COUNT(DISTINCT c.id) " + beginNativeCardQuery(search);
		Number count = (Number) createNativeQuery(queryString).setProperties(search).uniqueResult();
		return count != null ? count.intValue() : 0;
	}

	private List<SubjectCard> findCardsForReportBySearchAndPageRequest(SubjectCardsReportSearch search, PageRequest pageRequest) {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT DISTINCT c.* ").append(beginNativeCardQuery(search));
		Query<SubjectCard> query = createNativeQuery(builder.toString(), SubjectCard.class);

		if (pageRequest != null) {
			pagingSupport.applyPaging(query, pageRequest);
		}

		query.setProperties(search);

		return query.getResultList();
	}
	
	private String beginNativeCardQuery(SubjectCardsReportSearch search) {
		StringBuilder builder = new StringBuilder();

		builder
			.append("FROM inspections.subject_cards c ")
			.append("JOIN public.subjects card_subject ON c.subject_id = card_subject.id ")
			.append("JOIN techinsp.permit_inspectors i ON card_subject.id = i.subj_id ")
			.append("JOIN techinsp.permits p ON i.permit_id = p.id ")
			.append("JOIN public.subjects permit_subject ON p.subj_id = permit_subject.id ")
			.append("WHERE p.doc_status = 'ВЛ' ");

		String query = searchSupport.addSearchConstraints(builder.toString(), search);
		
		return query;
	}

	public Boolean checkIfHasCardBySubjectIdentityNumber(String identityNumber) {
		StringBuilder hqlBuilder = new StringBuilder();

		hqlBuilder.append("SELECT 1 FROM SubjectCard c ").append("WHERE c.subject.identityNumber = :identityNumber AND c.isActive = true ");

		Query<?> query = createQuery(hqlBuilder.toString());
		query.setParameter("identityNumber", identityNumber);
		return (query.uniqueResult() != null);
	}

}
