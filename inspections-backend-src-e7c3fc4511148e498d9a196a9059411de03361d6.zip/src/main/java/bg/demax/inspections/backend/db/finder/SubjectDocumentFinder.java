package bg.demax.inspections.backend.db.finder;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectAppliedDocumentExt;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectDocumentVersion;
import bg.demax.inspections.backend.search.DashboardPermitInspectorCertificationSearch;
import bg.demax.inspections.backend.search.DashboardPermitInspectorDocumentsReportSearch;
import bg.demax.inspections.backend.search.PermitInspectorDocumentsReportSearch;
import bg.demax.inspections.backend.util.PermitReportUtil;
import bg.demax.pub.entity.AppliedDocumentType;
import bg.demax.specialist.registry.common.entity.InspectorCertification;

@Repository
public class SubjectDocumentFinder extends AbstractFinder {

	@Autowired
	private GenericSearchSupport searchSupport;

	public List<SubjectAppliedDocumentExt> findBySearchPagedAndOrderedBySubject(
			PermitInspectorDocumentsReportSearch search, long days) {
		return findBySearchPagedAndOrderedBySubject(search, null, null, days);
	}

	public List<SubjectAppliedDocumentExt> findBySearchPagedAndOrderedBySubject(
		PermitInspectorDocumentsReportSearch search, Integer page, Integer pageSize, long days) {
		StringBuilder queryBuilder = new StringBuilder();
		StringBuilder nestedSelectBuilder = new StringBuilder();

		queryBuilder
			.append("SELECT * FROM inspections.subject_appl_docs_ext AS sadx ")
			.append("JOIN public.subject_appl_docs AS sad ON (sadx.document_id = sad.id)")
			.append(" JOIN inspections.subject_document_versions AS lv ON (sadx.last_version_id = lv.id)")
			.append("WHERE sad.subj_id IN ");
		nestedSelectBuilder
			.append("(SELECT DISTINCT sad.subj_id FROM public.subject_appl_docs AS sad ")
			.append("JOIN public.subjects AS s ")
			.append("ON s.id = sad.subj_id ");
		if (search.getOrgUnits() != null) {
			nestedSelectBuilder
				.append("JOIN techinsp.permit_inspectors pi ")
				.append("ON pi.subj_id = s.id ")
				.append("JOIN techinsp.permits p ")
				.append("ON pi.permit_id = p.id ");
		}
		queryBuilder
			.append(searchSupport.addSearchConstraints(nestedSelectBuilder.toString(), search))
			.append(" GROUP BY sad.subj_id ");
		if (pageSize != null && page != null) {
			queryBuilder
				.append("ORDER BY sad.subj_id ASC ")
				.append("LIMIT :pageSize OFFSET :page) ");
		} else {
			queryBuilder
				.append("ORDER BY sad.subj_id ASC) ");
		}

		// copying 'search' so the original remains unchanged
		PermitInspectorDocumentsReportSearch searchCopy = new PermitInspectorDocumentsReportSearch();
		BeanUtils.copyProperties(search, searchCopy);
		// set to NULL because they are not needed for the outer SELECT
		searchCopy.setIdentityNumber(null);
		searchCopy.setOrgUnits(null);

		queryBuilder = new StringBuilder(searchSupport.addSearchConstraints(queryBuilder.toString(), searchCopy))
			.append(" ORDER BY sad.subj_id ASC");

		Query<SubjectAppliedDocumentExt> query = createNativeQuery(queryBuilder.toString(), SubjectAppliedDocumentExt.class);

		if (search.getStatusCode() != null) {
			if (search.getStatusCode().equals(PermitReportUtil.DOC_EXPIRING_CODE)
				|| search.getStatusCode().equals(PermitReportUtil.DOC_VALID_CODE)) {

				query.setParameter("dueDate", LocalDate.now().plusDays(days));
			}

			if (!search.getStatusCode().equals(PermitReportUtil.DOC_INVALID_CODE)) {
				query.setParameter("currentDate", LocalDate.now());	
			}
		}
		if (pageSize != null && page != null) {
			query
				.setParameter("page", (page.intValue() - 1) * pageSize.intValue())
				.setParameter("pageSize", pageSize.intValue());
		}
		return query
				.setProperties(search)
				.getResultList();
	}


	public List<SubjectDocumentVersion> findAllRequiredAndPeriodicalBySearch(
		DashboardPermitInspectorDocumentsReportSearch search, long days) {
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder
			.append("SELECT dv FROM PermitLink pl ")
			.append("JOIN pl.lastApprovedVersion pv ")
			.append("JOIN pv.permitInfo pi ")
			.append("JOIN pi.orgUnit ou ")
			.append("JOIN pv.status s ")
			.append("JOIN pv.inspectors piv ")
			.append("JOIN piv.snapshot sn ")
			.append("JOIN sn.documentVersions dv ")
			.append("JOIN dv.status dvs ")
			.append("JOIN dv.document d ")
			.append("JOIN d.type t ")
			.append("WHERE t.isPeriodically = TRUE ")
			.append("AND t.isOptional = FALSE ")
			.append("AND t.isValid = TRUE ")
			.append("AND t.requiredFor = 'I' ");

		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		Query<SubjectDocumentVersion> query = createQuery(queryString, SubjectDocumentVersion.class);

		if (search.getDocumentStatusCode() != null) {
			if (search.getDocumentStatusCode().equals(PermitReportUtil.DOC_EXPIRING_CODE)) {
				query.setParameter("dueDate", LocalDate.now().plusDays(days));
			}

			if (!search.getDocumentStatusCode().equals(PermitReportUtil.DOC_INVALID_CODE)) {
				query.setParameter("currentDate", LocalDate.now());
			}
		}

		return query.setProperties(search).getResultList();
	}

	public List<InspectorCertification> findAllCertificationBySearch(
		DashboardPermitInspectorCertificationSearch search, long days) {
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder
			.append("SELECT c FROM PermitLink pl ")
			.append("JOIN pl.lastApprovedVersion pv ")
			.append("JOIN pv.permitInfo pi ")
			.append("JOIN pi.orgUnit ou ")
			.append("JOIN pv.status s ")
			.append("JOIN pv.inspectors piv ")
			.append("JOIN piv.certifications c ")
			.append("JOIN c.status cs ");

		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		Query<InspectorCertification> query = createQuery(queryString, InspectorCertification.class);

		if (search.getCertificationStatus() != null) {
			if (search.getCertificationStatusCode().equals(PermitReportUtil.DOC_EXPIRING_CODE)) {
				query.setParameter("dueDate", LocalDate.now().plusDays(days));
			}

			if (!search.getCertificationStatusCode().equals(PermitReportUtil.DOC_INVALID_CODE)) {
				query.setParameter("currentDate", LocalDate.now());
			}

		}

		return query.setProperties(search).getResultList();
	}

	public int countSubjectsBySearch(PermitInspectorDocumentsReportSearch search, long days) {
		StringBuilder queryBuilder = new StringBuilder();
		StringBuilder nestedSelectBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT COUNT(DISTINCT sad.subj_id) ")
			.append(" FROM inspections.subject_appl_docs_ext sadx ")
			.append(" JOIN public.subject_appl_docs AS sad ON (sadx.document_id = sad.id)")
			.append(" JOIN inspections.subject_document_versions AS lv ON (sadx.last_version_id = lv.id)")
			.append(" JOIN public.subjects s ON s.id = sad.subj_id ");
		if (search.getOrgUnits() != null) {
			nestedSelectBuilder
				.append(" JOIN techinsp.permit_inspectors pi ON pi.subj_id = s.id ")
				.append(" JOIN techinsp.permits p ON pi.permit_id = p.id ");
		}
		queryBuilder
			.append(searchSupport.addSearchConstraints(nestedSelectBuilder.toString(), search));

		@SuppressWarnings("unchecked")
		Query<BigInteger> query = (Query<BigInteger>) createNativeQuery(queryBuilder.toString());

		if (search.getStatusCode() != null) {
			if (search.getStatusCode().equals(PermitReportUtil.DOC_EXPIRING_CODE)
				|| search.getStatusCode().equals(PermitReportUtil.DOC_VALID_CODE)) {

				query.setParameter("dueDate", LocalDate.now().plusDays(days));
			}

			if (!search.getStatusCode().equals(PermitReportUtil.DOC_INVALID_CODE)) {
				query.setParameter("currentDate", LocalDate.now());
			}
		}
		
		BigInteger count = query
				.setProperties(search)
				.uniqueResult();
		
		return count == null ? 0 : count.intValue();
	}
	
	public int countValidDocumentForSubjectByType(AppliedDocumentType type, long subjectId, LocalDate validTill) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT COUNT(sad.id) FROM SubjectAppliedDocumentExt sadx ")
			.append("JOIN sadx.document sad ")
			.append("JOIN sadx.lastVersion lv ")
			.append("JOIN lv.status s ")
			.append("WHERE sad.subject.id = :subjectId ")
			.append("AND sad.type = :type  AND sad.isApproved = 'Y' ")
			.append("AND sad.validTo > :validityDate ")
			.append("AND s.code = 'VALID'");
		

		Number count = (Number) createQuery(queryBuilder.toString())
			.setParameter("subjectId", subjectId)
			.setParameter("type", type)
			.setParameter("validityDate", validTill)
			.uniqueResult();
		return count == null ? 0 : count.intValue();
	}

	public int countValidCertificateForSubjectByType(String categoryDescription, long subjectId, LocalDate validTill) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT COUNT(c.id) FROM InspectorCertification c ")
			.append("JOIN c.status s ")
			.append("JOIN c.course co ")
			.append("JOIN co.educationCategory e ")
			.append("JOIN c.subjectVersion sv ")
			
			.append("WHERE sv.subject.id = :subjectId ")
			.append("AND e.type.code = 'PERIODICAL' ")
			.append("AND c.reissueOn > :validityDate ")
			.append("AND e.description = :categoryDescription ")
			.append("AND s.code = 'VALID' ");
		

		Number count = (Number) createQuery(queryBuilder.toString())
			.setParameter("subjectId", subjectId)
			.setParameter("categoryDescription", categoryDescription)
			.setParameter("validityDate", validTill)
			.uniqueResult();
		return count == null ? 0 : count.intValue();
	}
}