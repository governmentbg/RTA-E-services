package bg.demax.inspections.backend.db.finder;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectDocumentsSnapshot;

@Repository
public class SubjectDocumentSnapshotFinder extends AbstractFinder {

	public SubjectDocumentsSnapshot findDraftBySubjectIdentityNumber(String identityNumber) {
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder.append("SELECT sds FROM SubjectDocumentsSnapshot AS sds ")
					.append("JOIN sds.subject AS s ")
					.append("WHERE s.identityNumber = :identityNumber ")
					.append("AND sds.isDraft = true");

		Query<SubjectDocumentsSnapshot> query = createQuery(sqlBuilder.toString(), SubjectDocumentsSnapshot.class);
		query.setParameter("identityNumber", identityNumber);

		return query.uniqueResult();
	}
	
	public SubjectDocumentsSnapshot findLastApprovedSnapshotBySubjectId(long subjectId) {
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder.append("SELECT snap FROM PermitLink AS pl ")
					.append("JOIN pl.lastApprovedVersion AS pv ")
					.append("JOIN pv.inspectors AS pi ")
					.append("JOIN pi.snapshot AS snap ")
					.append("JOIN snap.subject AS sub ")
					.append("WHERE sub.id = :subjectId");

		Query<SubjectDocumentsSnapshot> query = createQuery(sqlBuilder.toString(), SubjectDocumentsSnapshot.class);
		query.setParameter("subjectId", subjectId);
		query.setMaxResults(1);

		return query.uniqueResult();
	}
	
	public boolean existsDraftBySubjectIdentityNumber(String identityNumber) {
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder.append("SELECT 1 FROM SubjectDocumentsSnapshot AS sds ")
				.append("JOIN sds.subject AS s ")
				.append("WHERE s.identityNumber = :identityNumber ")
				.append("AND sds.isDraft = true");

		Query<Integer> query = createQuery(sqlBuilder.toString(), Integer.class)
				.setMaxResults(1);
		query.setParameter("identityNumber", identityNumber);

		Integer result = query.uniqueResult();
		return result != null && result.intValue() > 0;
	}
	
	public int countDraftsBySubjectId(Long subjectId) {
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder.append("SELECT COUNT(sds.id) FROM SubjectDocumentsSnapshot AS sds ")
				.append("JOIN sds.subject AS s ")
				.append("WHERE s.id = :subjectId ")
				.append("AND sds.isDraft = true");

		Query<Long> query = createQuery(sqlBuilder.toString(), Long.class);
		query.setParameter("subjectId", subjectId);

		Long result = query.getSingleResult();
		if (result != null && result.intValue() != 0) {
			return result.intValue();
		} else {
			return 0;
		}
	}
}
