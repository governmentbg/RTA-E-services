package bg.demax.inspections.backend.db.finder;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.OrderClause;
import bg.demax.hibernate.paging.OrderDirection;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.entity.permit.inspector.SubjectDocumentVersion;

@Repository
public class SubjectDocumentVersionFinder extends AbstractFinder {
	
	@Autowired
	private PagingAndSortingSupport pagingSupport;
	
	
	public SubjectDocumentVersion findByInspectorVersionIdAndDocumentVersionId(int inspectorVersionId, int documentVersionId) {
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder.append("SELECT dv FROM PermitInspectorVersion AS piv ")
					.append("JOIN piv.snapshot AS snap ")
					.append("JOIN snap.documentVersions AS dv ")
					.append("WHERE piv.id = :inspectorVersionId ")
					.append("AND dv.id = :documentVersionId");

		Query<SubjectDocumentVersion> query = createQuery(sqlBuilder.toString(), SubjectDocumentVersion.class);
		query.setParameter("inspectorVersionId", inspectorVersionId);
		query.setParameter("documentVersionId", documentVersionId);

		return query.uniqueResult();
	}

	public SubjectDocumentVersion findBySubjectIdAndDocumentVersionId(long subjectId, int documentVersionId) {
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder.append("SELECT sdv FROM SubjectDocumentVersion AS sdv ")
					.append("JOIN sdv.document AS sd ")
					.append("JOIN sd.subject AS s ")
					.append("WHERE sdv.id = :documentVersionId ")
					.append("AND s.id = :subjectId");

		Query<SubjectDocumentVersion> query = createQuery(sqlBuilder.toString(), SubjectDocumentVersion.class);
		query.setParameter("subjectId", subjectId);
		query.setParameter("documentVersionId", documentVersionId);

		return query.uniqueResult();
	}
	
	public boolean containsInLastApprovedPermitVersion(int permitVersionId, 
			long subjectId, int subjectDocumentVersionId) {		
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder
			.append("SELECT 1 FROM PermitVersion AS pv ")
			.append("JOIN pv.permitLink AS pl ")
			.append("JOIN pl.lastApprovedVersion AS lav ")
			.append("JOIN lav.inspectors AS piv ")
			.append("JOIN piv.subjectVersion AS sv ")
			.append("JOIN sv.subject AS s ")
			.append("JOIN piv.snapshot AS snap ")
			.append("JOIN snap.documentVersions AS dv ")
			.append("WHERE pv.id = :permitVersionId ")
			.append("AND s.id = :subjectId ")
			.append("AND dv.id = :subjectDocumentVersionId");

		@SuppressWarnings("unchecked")
		Query<Integer> query = (Query<Integer>) createQuery(sqlBuilder.toString())
			.setMaxResults(1);
		query.setParameter("permitVersionId", permitVersionId)
			.setParameter("subjectId", subjectId)
			.setParameter("subjectDocumentVersionId", subjectDocumentVersionId);

		Integer result = query.uniqueResult();
		return result != null && result.intValue() > 0;
	}
	
	public List<SubjectDocumentVersion> findDocumentsBySubjectIdOrderedById(long subjectId, PageRequest pageRequest) {
		String queryString = "SELECT dv " + buildBeginQuery();	
		
		queryString = pagingSupport.applySorting(queryString, pageRequest);
		
		Query<SubjectDocumentVersion> query = createQuery(queryString, SubjectDocumentVersion.class);
		query = query.setParameter("subjectId", subjectId);
		
		pageRequest.addOrderClause(new OrderClause("dv.id", OrderDirection.DESCENDING));
		pagingSupport.applyPaging(query, pageRequest);

		return query.getResultList();
	}
	
	public List<SubjectDocumentVersion> findDocumentByInspectorIdOrderedById(int inspectorVersionId, PageRequest pageRequest) {	
		String queryString = "SELECT dv " + buildBeginQueryByInspectorVersionId();
		
		pageRequest.addOrderClause(new OrderClause("dv.document.type.description", OrderDirection.DESCENDING));
		pageRequest.addOrderClause(new OrderClause("dv.document.issuedDate", OrderDirection.DESCENDING));
		pageRequest.addOrderClause(new OrderClause("dv.document.validFrom", OrderDirection.DESCENDING));
		queryString = pagingSupport.applySorting(queryString, pageRequest);
		
		Query<SubjectDocumentVersion> query = createQuery(queryString, SubjectDocumentVersion.class);
		query = query.setParameter("inspectorVersionId", inspectorVersionId);
		
		pagingSupport.applyPaging(query, pageRequest);

		return query.getResultList();
	}
	
	public int countBySubjectId(long subjectId) {
		String queryString = "SELECT COUNT(dv.id) " + buildBeginQuery();

		return ((Number) createQuery(queryString).setParameter("subjectId", subjectId)
				.getSingleResult()).intValue();
	}
	
	public int countByInspectorVersionId(int inspectorVersionId) {
		String queryString = "SELECT COUNT(dv.id) " + buildBeginQueryByInspectorVersionId();
		return ((Number) createQuery(queryString).setParameter("inspectorVersionId", inspectorVersionId)
						.getSingleResult()).intValue();
	}
	
	private String buildBeginQuery() {
		
		StringBuilder queryBuilder = new StringBuilder();
		
		queryBuilder.append("FROM SubjectDocumentsSnapshot AS snap ")
			.append("JOIN snap.documentVersions AS dv ")
			.append("JOIN snap.subject AS s ")
			.append("WHERE s.id = :subjectId ")
			.append("AND snap.isDraft = false");
		
		return queryBuilder.toString();
	}
	
	private String buildBeginQueryByInspectorVersionId() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM PermitInspectorVersion AS piv ")
			.append("JOIN piv.snapshot AS snap ")
			.append("JOIN snap.documentVersions AS dv ")
			.append("WHERE piv.id = :inspectorVersionId");
		
		return queryBuilder.toString();
	}
}
