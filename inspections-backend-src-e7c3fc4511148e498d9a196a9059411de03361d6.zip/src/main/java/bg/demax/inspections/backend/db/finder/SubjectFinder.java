package bg.demax.inspections.backend.db.finder;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.pub.entity.Subject;

public class SubjectFinder extends AbstractFinder {

	public Subject findByIdentityNumber(String identityNumber) {
		return createQuery("FROM Subject WHERE identityNumber = :identityNumber", Subject.class)
						.setParameter("identityNumber", identityNumber)
						.uniqueResult();
	}
}
