package bg.demax.inspections.backend.db.finder;

import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.pub.entity.hardware.WarehouseShippingInfo;

@Repository
public class WarehouseShippingInfoFinder extends AbstractFinder {

	public WarehouseShippingInfo findByWarehouseId(int warehouseId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT wsi ")
					.append("FROM WarehouseShippingInfo wsi ")
					.append("JOIN FETCH wsi.warehouse wsiWarehouse ")
					.append("WHERE wsiWarehouse.id = :warehouseId ");
		return (WarehouseShippingInfo) createQuery(queryBuilder.toString())
						.setParameter("warehouseId", warehouseId)
						.uniqueResult();
	}
}
