package bg.demax.inspections.backend.db.finder.equipment;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.search.equipment.ConsumableTransfersSearch;
import bg.demax.pub.entity.hardware.ConsumableTransferBillOfLading;

@Repository
public class ConsumableTransferFinder extends AbstractFinder {

	@Autowired
	PagingAndSortingSupport pagingSupport;
	
	@Autowired
	GenericSearchSupport searchSupport;
	
	public List<ConsumableTransferBillOfLading> findPagedBySearch(PageRequest pageRequest,
					ConsumableTransfersSearch search) {
		
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT b ")
					.append("FROM ConsumableTransferBillOfLading b ")
					.append("LEFT JOIN FETCH b.permit p ")
					.append("LEFT JOIN FETCH p.ktpCity city ");
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString += " ORDER BY b.id DESC, (CASE WHEN b.status LIKE 'NOT_SENT' THEN 1 else 2 end), b.status ";
		
		Query<ConsumableTransferBillOfLading> query = createQuery(queryString, ConsumableTransferBillOfLading.class);
		
		if (pageRequest != null) {
			pagingSupport.applyPaging(query, pageRequest);
		}
		return query.setProperties(search).getResultList();
	}
	
	public int getCountBySearch(ConsumableTransfersSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count(DISTINCT b) ")
					.append("FROM ConsumableTransferBillOfLading b ");
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		Number count = createQuery(queryString, Number.class)
				.setProperties(search)
				.uniqueResult();
		return count == null ? 0 : count.intValue();
	}
	
	public List<Integer> findAllBillOfLadingsWithStatusNotSent() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT b.id ")
					.append("FROM ConsumableTransferBillOfLading b ")
					.append("WHERE b.status LIKE 'NOT_SENT' ");
		Query<Integer> query = createQuery(queryBuilder.toString(), Integer.class);
		return query.getResultList();
	}

	public List<ConsumableTransferBillOfLading> findNotSentBillOfLadingForPermitWithId(Integer permitId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT b ")
					.append("FROM ConsumableTransferBillOfLading b ")
					.append("JOIN FETCH b.permit p ")
					.append("WHERE b.status LIKE 'NOT_SENT' AND p.id = :permitId ");
		Query<ConsumableTransferBillOfLading> query = createQuery(queryBuilder.toString(), ConsumableTransferBillOfLading.class);
		
		return query.setParameter("permitId", permitId).getResultList();
	}
}
