package bg.demax.inspections.backend.db.finder.equipment;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.entity.HardwareDevice;
import bg.demax.inspections.backend.search.equipment.HardwareDeviceSearch;
import bg.demax.pub.entity.hardware.Device;
import bg.demax.pub.entity.hardware.DeviceStatus;
import bg.demax.pub.entity.hardware.RemovableHardware;
import bg.demax.pub.entity.hardware.SimCard;
import bg.demax.security.entity.User;

@Repository
public class HardwareDeviceFinder extends AbstractFinder {

	@Autowired
	private PagingAndSortingSupport pageingSupport;

	@Autowired
	private GenericSearchSupport searchSupport;

	public List<HardwareDevice> findPagedBySearch(PageRequest pageRequest, HardwareDeviceSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT hd ")
					.append("FROM HardwareDevice hd ")
					
					.append("LEFT JOIN hd.device device ")
					.append("LEFT JOIN hd.simCard simCard ")

					.append("LEFT JOIN device.warehouse dWarehouse ")
					.append("LEFT JOIN device.type dType ")
					.append("LEFT JOIN device.ipAddress dIpAddress ")

					.append("LEFT JOIN simCard.warehouse sWarehouse ")
					.append("LEFT JOIN simCard.type sType ")

					.append("LEFT JOIN device.permitLineHardware dPermitLineHardware ")
					.append("LEFT JOIN dPermitLineHardware.permitLine dPermitLine ")
					.append("LEFT JOIN dPermitLine.permit dPermit ")

					.append("LEFT JOIN simCard.permitLineHardware sPermitLineHardware ")
					.append("LEFT JOIN sPermitLineHardware.permitLine sPermitLine ")
					.append("LEFT JOIN sPermitLine.permit sPermit ");

		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString += " ORDER BY hd.id DESC, hd.deviceType DESC ";
		queryString = pageingSupport.applySorting(queryString, pageRequest);
		Query<HardwareDevice> query = createQuery(queryString, HardwareDevice.class);
		pageingSupport.applyPaging(query, pageRequest);
		return query.setProperties(search)
				.getResultList();
	}

	public List<User> testPerformanceOld(PageRequest pageRequest) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT u ")
					.append("FROM User u ")
					.append("LEFT JOIN FETCH u.userAuthorities a ")
					.append("WHERE u.enabled = :isEnabled ");

		String queryString = queryBuilder.toString();
		queryString += " ORDER BY u.id , a.id  ";
		Query<User> query = createQuery(queryString, User.class);
		query.setParameter("isEnabled", true);
		pageingSupport.applyPaging(query, pageRequest);
		return query.getResultList();
	}

	public List<User> testPerformanceNew(PageRequest pageRequest) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT u ")
					.append("FROM User u ")
					.append("LEFT JOIN FETCH u.authorities a")
					.append("WHERE u.enabled = :isEnabled ");

		String queryString = queryBuilder.toString();
		queryString += " ORDER BY u.id , a.d  ";
		Query<User> query = createQuery(queryString, User.class);
		pageingSupport.applyPaging(query, pageRequest);
		return query.getResultList();
	}

	public SimCard findSimCardByIdAndCode(Integer id, Short code) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT simCard ")
					.append("FROM SimCard simCard ")
					.append("LEFT JOIN FETCH simCard.type type ")
					.append("WHERE simCard.id = :id AND simCard.type.code = :code ");
		Query<SimCard> query = createQuery(queryBuilder.toString(), SimCard.class);

		return query.setParameter("id", id).setParameter("code", code).uniqueResult();
	}
	
	public Device findDeviceByIdAndCode(Integer id, Short code) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT device ")
					.append("FROM Device device ")
					.append("LEFT JOIN FETCH device.type type ")
					.append("WHERE device.id = :id AND device.type.code = :code ");
		Query<Device> query = createQuery(queryBuilder.toString(), Device.class);

		return query.setParameter("id", id).setParameter("code", code).uniqueResult();
	}
	
	public int countBySearch(HardwareDeviceSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count(hd.id) ")
					.append("FROM HardwareDevice hd ")
					
					.append("LEFT JOIN hd.device device ")
					.append("LEFT JOIN hd.simCard simCard ")
					
					.append("LEFT JOIN device.warehouse dWarehouse ")
					.append("LEFT JOIN device.type dType ")
					.append("LEFT JOIN device.ipAddress dIpAddress ")
					
					.append("LEFT JOIN simCard.warehouse sWarehouse ")
					.append("LEFT JOIN simCard.type sType ")
					
					.append("LEFT JOIN device.permitLineHardware dPermitLineHardware ")
					.append("LEFT JOIN dPermitLineHardware.permitLine dPermitLine ")
					.append("LEFT JOIN dPermitLine.permit dPermit ")
					.append("LEFT JOIN dPermit.subject dPermitSubject ")
					.append("LEFT JOIN dPermitSubject.currentVersion dPermitSubjectCurrentVersion ")
					
					.append("LEFT JOIN simCard.permitLineHardware sPermitLineHardware ")
					.append("LEFT JOIN sPermitLineHardware.permitLine sPermitLine ")
					.append("LEFT JOIN sPermitLine.permit sPermit ")
					.append("LEFT JOIN sPermit.subject sPermitSubject ")
					.append("LEFT JOIN sPermitSubject.currentVersion sPermitSubjectCurrentVersion ");
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		Number count = createQuery(queryString, Number.class)
				.setProperties(search)
				.uniqueResult();
		return count == null ? 0 : count.intValue();
	}

	public List<HardwareDevice> findBySearch(HardwareDeviceSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT hd ")
					.append("FROM HardwareDevice hd ")
					
					.append("LEFT JOIN FETCH hd.device device ")
					.append("LEFT JOIN FETCH hd.simCard simCard ")
					
					.append("LEFT JOIN FETCH device.warehouse dWarehouse ")
					.append("LEFT JOIN FETCH device.type dType ")
					.append("LEFT JOIN FETCH device.ipAddress dIpAddress ")
					.append("LEFT JOIN FETCH device.status dStatus ")
					
					.append("LEFT JOIN FETCH simCard.warehouse sWarehouse ")
					.append("LEFT JOIN FETCH simCard.type sType ")
					.append("LEFT JOIN FETCH simCard.status sStatus ")
					
					.append("LEFT JOIN FETCH device.permitLineHardware dPermitLineHardware ")
					.append("LEFT JOIN FETCH dPermitLineHardware.permitLine dPermitLine ")
					.append("LEFT JOIN FETCH dPermitLine.permit dPermit ")
					.append("LEFT JOIN FETCH dPermit.orgUnit dPermitOrgUnit ")
					.append("LEFT JOIN FETCH dPermit.ktpCity dPermitKtpCity ")
					.append("LEFT JOIN dPermit.subject dPermitSubject ")
					.append("LEFT JOIN dPermitSubject.currentVersion dPermitSubjectCurrentVersion ")
					
					.append("LEFT JOIN FETCH simCard.permitLineHardware sPermitLineHardware ")
					.append("LEFT JOIN FETCH sPermitLineHardware.permitLine sPermitLine ")
					.append("LEFT JOIN FETCH sPermitLine.permit sPermit ")
					.append("LEFT JOIN FETCH sPermit.orgUnit sPermitOrgUnit ")
					.append("LEFT JOIN FETCH sPermit.ktpCity sPermitKtpCity ")
					.append("LEFT JOIN sPermit.subject sPermitSubject ")
					.append("LEFT JOIN sPermitSubject.currentVersion sPermitSubjectCurrentVersion ");
	
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString += " ORDER BY hd.id ASC, hd.deviceType ASC ";
		Query<HardwareDevice> query = createQuery(queryString, HardwareDevice.class);
		return query.setProperties(search)
				.getResultList();
	}
	
	public List<HardwareDevice> findBySerialNumber(String serialNumber) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT hd ")
					.append("FROM HardwareDevice hd ")
					.append("LEFT JOIN FETCH hd.device device ")
					.append("LEFT JOIN FETCH hd.simCard simCard ")
					.append("LEFT JOIN FETCH device.type dType ")
					.append("LEFT JOIN FETCH simCard.type sType ") 
					.append("WHERE device.serialNumber LIKE CONCAT('%', :sn, '%') OR simCard.iccId LIKE CONCAT('%', :sn, '%') ");
		
		Query<HardwareDevice> query = createQuery(queryBuilder.toString(), HardwareDevice.class);
		return query.setParameter("sn", serialNumber)
				.getResultList();
	}
	
	public SimCard findSimCardBySerialNumber(String serialNumber) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM SimCard sc ")
					.append("WHERE sc.iccId = :sn ");
		
		Query<SimCard> query = createQuery(queryBuilder.toString(), SimCard.class);
		return query.setParameter("sn", serialNumber)
				.uniqueResult();
	}
	
	public Device findDeviceBySerialNumber(String serialNumber) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM Device d ")
					.append("WHERE d.serialNumber = :sn ");
		
		Query<Device> query = createQuery(queryBuilder.toString(), Device.class);
		return query.setParameter("sn", serialNumber)
				.uniqueResult();
	}
	
	public HardwareDevice findHardwareBySerialNumberAndDeviceType(Short typeCode, String serialNumber) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT hd ")
					.append("FROM HardwareDevice hd ")
					.append("LEFT JOIN FETCH hd.device device ")
					.append("LEFT JOIN FETCH hd.simCard simCard ")
					.append("LEFT JOIN FETCH device.type dType ")
					.append("LEFT JOIN FETCH simCard.type sType ") 
					.append("WHERE (dType.code = :typeCode AND device.serialNumber LIKE CONCAT('%', :serialNumber, '%')) OR ")
					.append("(sType.code = :typeCode AND simCard.iccId LIKE CONCAT('%', :serialNumber, '%'))");
		Query<HardwareDevice> query = createQuery(queryBuilder.toString(), HardwareDevice.class);
		return query.setParameter("typeCode", typeCode)
						.setParameter("serialNumber", serialNumber)
						.uniqueResult();
	}
	
	public List<Device> findDevicesByPermitLineId(Integer permitLineId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT device ")
					.append("FROM Device device ")
					.append("LEFT JOIN device.permitLineHardware permitLineHardware ")
					.append("LEFT JOIN permitLineHardware.permitLine permitLine ")
					.append("WHERE permitLine.id = :permitLineId ");
		Query<Device> query = createQuery(queryBuilder.toString(), Device.class);
		
		return query.setParameter("permitLineId", permitLineId).getResultList();
	}
	
	public Optional<Device> findDeviceForLine(int permitVersionId, int permitLineVersionId, int deviceId) {
		Query<Device> query = getHardwareForLineQuery(permitVersionId, permitLineVersionId, deviceId, Device.class);
		
		return Optional.ofNullable(query.uniqueResult());
	}
	
	public Optional<SimCard> findSimCardForLine(int permitVersionId, int permitLineVersionId, int simId) {
		Query<SimCard> query = getHardwareForLineQuery(permitVersionId, permitLineVersionId, simId, SimCard.class);
		
		return Optional.ofNullable(query.uniqueResult());
	}

	private <T extends RemovableHardware> Query<T> getHardwareForLineQuery(int permitVersionId, int permitLineVersionId, int simOrDeviceId,
					Class<T> clazz) {
		String thirdParam = clazz.equals(Device.class) ? "dev" : "sim";
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT %1$s FROM %2$s %1$s ")
					.append("LEFT JOIN PermitLineVersion plv ON %<s.permitLineHardware.permitLine.id = plv.permitLine.id ")
					.append("LEFT JOIN PermitVersion pv ON plv MEMBER OF pv.permitLines ")
					.append("WHERE pv.id = :permitVersionId ")
					.append("AND plv.id = :permitLineVersionId ")
					.append("AND %<s.id = :%<sId");
		
		Query<T> query = createQuery(String.format(queryBuilder.toString(), thirdParam, clazz.getSimpleName()), clazz);
		query.setParameter("permitVersionId", permitVersionId);
		query.setParameter("permitLineVersionId", permitLineVersionId);
		query.setParameter(String.format("%sId", thirdParam), simOrDeviceId);
		return query;
	}

	public List<HardwareDevice> findHardwareDevicesPageByPermitLineId(Integer permitLineId, PageRequest pageRequest) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT hd FROM HardwareDevice hd "
						+ "LEFT JOIN FETCH  hd.device device "
						+ "LEFT JOIN FETCH hd.simCard simCard "
						+ "LEFT JOIN FETCH device.permitLineHardware deviceHardware "
						+ "LEFT JOIN FETCH simCard.permitLineHardware simHardware "
						+ "LEFT JOIN FETCH deviceHardware.permitLine deviceHardwareLine "
						+ "LEFT JOIN FETCH simHardware.permitLine simHardwareLine "
						+ "WHERE deviceHardwareLine.id = :permitLineId "
						+ "OR simHardwareLine.id = :permitLineId");
		Query<HardwareDevice> query = createQuery(queryBuilder.toString(), HardwareDevice.class);
		pageingSupport.applyPaging(query, pageRequest);
		return query.setParameter("permitLineId", permitLineId).getResultList();
	}
	
	public int findHardwarDevicesCountByPermitLineId(Integer permitLineId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT COUNT(hd.id) FROM HardwareDevice hd " 
						+ "LEFT JOIN hd.device device "
						+ "LEFT JOIN hd.simCard simCard " 
						+ "LEFT JOIN device.permitLineHardware deviceHardware "
						+ "LEFT JOIN simCard.permitLineHardware simHardware "
						+ "LEFT JOIN deviceHardware.permitLine deviceHardwareLine "
						+ "LEFT JOIN simHardware.permitLine simHardwareLine " 
						+ "WHERE deviceHardwareLine.id = :permitLineId "
						+ "OR simHardwareLine.id = :permitLineId");
		Number count = createQuery(queryBuilder.toString(), Number.class).setParameter("permitLineId", permitLineId).uniqueResult();
		return count == null ? 0 : count.intValue();
	}
	
	public List<HardwareDevice> findHardwareBySerialNumberAndStoreCode(String storeCode, String serialNumber) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT hd ")
					.append("FROM HardwareDevice hd ")
					.append("LEFT JOIN hd.device device ")
					.append("LEFT JOIN hd.simCard simCard ")
					.append("LEFT JOIN device.store dStore ")
					.append("LEFT JOIN simCard.store sStore ")
					.append("LEFT JOIN device.status dStatus ")
					.append("LEFT JOIN simCard.status sStatus ")
					.append("WHERE (dStatus.id in :statuses AND dStore.code = :storeCode ")
					.append("AND device.serialNumber LIKE CONCAT('%', :serialNumber, '%')) OR ")
					.append("(sStatus.id in :statuses AND sStore.code = :storeCode ")
					.append("AND simCard.iccId LIKE CONCAT('%', :serialNumber, '%'))");
		Query<HardwareDevice> query = createQuery(queryBuilder.toString(), HardwareDevice.class);
		return query.setParameter("storeCode", storeCode)
						.setParameter("serialNumber", serialNumber)
						.setParameter("statuses", Arrays.asList(DeviceStatus.AVAILABLE_ID, DeviceStatus.NEW_ID))
						.getResultList();
	}
	
}
