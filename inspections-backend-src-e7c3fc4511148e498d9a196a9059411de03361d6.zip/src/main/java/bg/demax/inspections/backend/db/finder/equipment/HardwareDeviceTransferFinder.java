package bg.demax.inspections.backend.db.finder.equipment;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.search.equipment.HardwareDeviceTransfersSearch;
import bg.demax.pub.entity.hardware.HardwareDeviceTransferBillOfLading;

@Repository
public class HardwareDeviceTransferFinder extends AbstractFinder {

	@Autowired
	private PagingAndSortingSupport pagingSupport;

	@Autowired
	private GenericSearchSupport searchSupport;

	public List<HardwareDeviceTransferBillOfLading> findPagedBySearch(PageRequest pageRequest,
					HardwareDeviceTransfersSearch search) {

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT b ")
					.append("FROM HardwareDeviceTransferBillOfLading b ")
					.append("LEFT JOIN FETCH b.warehouse warehouse ")
					.append("LEFT JOIN FETCH b.protocols p ");
					
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString += " ORDER BY b.id DESC, (CASE WHEN b.status LIKE 'NOT_SENT' THEN 1 else 2 end), b.status ";

		Query<HardwareDeviceTransferBillOfLading> query = createQuery(queryString, HardwareDeviceTransferBillOfLading.class);

		if (pageRequest != null) {
			pagingSupport.applyPaging(query, pageRequest);
		}
		
		
		return query.setProperties(search)
						.getResultList();
	}
	
	public int getCountBySearch(HardwareDeviceTransfersSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count(DISTINCT b) ")
					.append("FROM HardwareDeviceTransferBillOfLading b ");
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		Number count = createQuery(queryString, Number.class)
				.setProperties(search)
				.uniqueResult();
		return count == null ? 0 : count.intValue();
	}
	
	public HardwareDeviceTransferBillOfLading findBillOfLadingById(Integer id) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT DISTINCT bol ")
					.append("FROM HardwareDeviceTransferBillOfLading bol ")
					.append("LEFT JOIN FETCH bol.protocols p ")
					.append("WHERE bol.id = :id ");
		
		Query<HardwareDeviceTransferBillOfLading> query = createQuery(queryBuilder.toString(),
						HardwareDeviceTransferBillOfLading.class);
		return query.setParameter("id", id).uniqueResult();
	}
	
	public Short getHardwareCountForProtocolById(Integer protocolId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count(DISTINCT devices) + count(DISTINCT simCards) ")
					.append("FROM HardwareDeviceTransferProtocol p ")
					.append("LEFT JOIN p.devices devices ")
					.append("LEFT JOIN p.simCards simCards ")
					.append("WHERE p.id = :protocolId ");
		Number count = createQuery(queryBuilder.toString(), Number.class).setParameter("protocolId", protocolId).uniqueResult();
		return count == null ? 0 : count.shortValue();
	}
}