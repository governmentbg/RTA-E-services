package bg.demax.inspections.backend.db.finder.equipment;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.search.equipment.PrinterConsumableSearch;
import bg.demax.pub.entity.hardware.PrinterConsumable;

@Repository
public class PrinterConsumableFinder extends AbstractFinder {

	@Autowired
	private PagingAndSortingSupport pagingSupport;
	
	@Autowired
	private GenericSearchSupport searchSupport;
	
	public List<PrinterConsumable> findPaginated(PageRequest pageRequest, PrinterConsumableSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT consumable ")
					.append("FROM PrinterConsumable consumable ")
					.append("LEFT JOIN FETCH consumable.sentToPermit consumableSentToPermit ")
					.append("LEFT JOIN FETCH consumableSentToPermit.orgUnit consumableSentToPermitOrgUnit ")
					.append("LEFT JOIN FETCH consumable.printer consumablePrinter ")
					.append("LEFT JOIN FETCH consumablePrinter.type ")
					.append("LEFT JOIN FETCH consumablePrinter.permitLineHardware consumablePLH ")
					.append("LEFT JOIN FETCH consumablePLH.permitLine consumablePermitLine ")
					.append("LEFT JOIN FETCH consumablePermitLine.permit consumablePermit ")
					.append("LEFT JOIN FETCH consumablePermit.orgUnit consumablePermitOrgUnit ");
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString += " ORDER BY consumable.status.code ASC, consumable.percentUsed DESC, consumable.id DESC ";
		pagingSupport.applySorting(queryString, pageRequest);
		return pagingSupport.applyPaging(createQuery(queryString, PrinterConsumable.class), pageRequest)
						.setProperties(search)
						.getResultList();
	}

	public int countBySearch(PrinterConsumableSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count(consumable) ")
					.append("FROM PrinterConsumable consumable ")
					.append("LEFT JOIN consumable.sentToPermit consumableSentToPermit ")
					.append("LEFT JOIN consumableSentToPermit.orgUnit consumableSentToPermitOrgUnit ")
					.append("LEFT JOIN consumable.printer consumablePrinter ")
					.append("LEFT JOIN consumablePrinter.type ")
					.append("LEFT JOIN consumablePrinter.permitLineHardware consumablePLH ")
					.append("LEFT JOIN consumablePLH.permitLine consumablePermitLine ")
					.append("LEFT JOIN consumablePermitLine.permit consumablePermit ")
					.append("LEFT JOIN consumablePermit.orgUnit consumablePermitOrgUnit ");
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		Number count = createQuery(queryString, Number.class)
						.setProperties(search)
						.uniqueResult();
		return count == null  ? 0 : count.intValue();
	}

	public List<PrinterConsumable> findBySearch(PrinterConsumableSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT consumable ")
					.append("FROM PrinterConsumable consumable ")
					.append("LEFT JOIN FETCH consumable.sentToPermit consumableSentToPermit ")
					.append("LEFT JOIN FETCH consumableSentToPermit.orgUnit consumableSentToPermitOrgUnit ")
					.append("LEFT JOIN FETCH consumable.printer consumablePrinter ")
					.append("LEFT JOIN FETCH consumable.type consumableType ")
					.append("LEFT JOIN FETCH consumable.status consumableStatus ")
					.append("LEFT JOIN FETCH consumablePrinter.type ")
					.append("LEFT JOIN FETCH consumablePrinter.permitLineHardware consumablePLH ")
					.append("LEFT JOIN FETCH consumablePLH.permitLine consumablePermitLine ")
					.append("LEFT JOIN FETCH consumablePermitLine.permit consumablePermit ")
					.append("LEFT JOIN FETCH consumablePermit.orgUnit consumablePermitOrgUnit ");
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString += " ORDER BY consumable.id DESC ";
		return createQuery(queryString, PrinterConsumable.class)
						.setProperties(search)
						.getResultList();
	}
	
	public int countInspectionNeededPages(int permitLineId, LocalDateTime fromDateTime, LocalDateTime toDateTime) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT (COALESCE(SUM(inspectionType.copies), 0) ")
					.append("			+ COALESCE((SELECT count(insp.hasSemt) * 6 ")
					.append("				FROM Inspection insp ")
					.append("				WHERE insp.permitLine.id = :permitLineId ")
					.append("				AND insp.inspectionDateTime >= :fromDateTime ")
					.append("				AND insp.inspectionDateTime <= :toDateTime ")
					.append("				AND insp.hasSemt = true ")
					.append("				GROUP BY insp.hasSemt), 0)) AS count ")
					.append("FROM Inspection inspection ") 
					.append("LEFT JOIN inspection.inspectionType inspectionType ") 
					.append("WHERE inspection.permitLine.id = :permitLineId ")
					.append("AND inspection.inspectionDateTime >= :fromDateTime ")
					.append("AND inspection.inspectionDateTime <= :toDateTime ") 
					.append("AND inspection.hasSemt = false ")
					.append("GROUP BY inspection.hasSemt ");
		Number count = createQuery(queryBuilder.toString(), Number.class)
						.setParameter("permitLineId", permitLineId)
						.setParameter("fromDateTime", fromDateTime)
						.setParameter("toDateTime", toDateTime)
						.uniqueResult();
		return count == null ? 0 : count.intValue();
	}
	
}
