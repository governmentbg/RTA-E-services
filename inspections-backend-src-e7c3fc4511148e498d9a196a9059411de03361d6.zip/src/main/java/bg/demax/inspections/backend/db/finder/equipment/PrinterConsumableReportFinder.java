package bg.demax.inspections.backend.db.finder.equipment;

import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.pub.entity.hardware.PrinterConsumable;
import bg.demax.pub.entity.hardware.PrinterConsumableReport;
import bg.demax.techinsp.entity.PermitLine;

@Repository
public class PrinterConsumableReportFinder extends AbstractFinder {

	public PrinterConsumableReport findLatestByPermitLine(PermitLine permitLine) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM PrinterConsumableReport report ")
					.append("WHERE report.permitLine = :permitLine ")
					.append("ORDER BY report.id DESC ");
		return createQuery(queryBuilder.toString(), PrinterConsumableReport.class)
						.setParameter("permitLine", permitLine)
						.setMaxResults(1)
						.uniqueResult();
	}

	public PrinterConsumableReport findLatestByPrinterConsumable(PrinterConsumable consumable) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM PrinterConsumableReport report ")
					.append("WHERE report.consumable = :consumable ")
					.append("ORDER BY report.id DESC ");
		return createQuery(queryBuilder.toString(), PrinterConsumableReport.class)
						.setParameter("consumable", consumable)
						.setMaxResults(1)
						.uniqueResult();
	}
}
