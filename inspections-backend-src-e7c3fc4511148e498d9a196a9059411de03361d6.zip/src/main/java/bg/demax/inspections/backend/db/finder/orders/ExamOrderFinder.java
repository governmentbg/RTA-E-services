package bg.demax.inspections.backend.db.finder.orders;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.entity.motor.exam.result.ExamOrder;
import bg.demax.inspections.backend.entity.motor.exam.result.ExamProduct.ExamProducts;
import bg.demax.inspections.backend.search.orders.ExamOrderSearch;
import bg.demax.pub.entity.City;

@Repository
public class ExamOrderFinder extends AbstractFinder {	
	@Autowired
	private PagingAndSortingSupport pagingSupport;

	@Autowired
	private GenericSearchSupport searchSupport;

	public List<ExamOrder> getExamOrders(ExamOrderSearch examOrderSearch,
							PageRequest pageRequest) {
		
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT DISTINCT o FROM ExamOrderItem oi ")
					.append("JOIN oi.examOrder o ");
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), examOrderSearch);
		queryString = pagingSupport.applySorting(queryString, pageRequest);

		Query<ExamOrder> query = createQuery(queryString, ExamOrder.class);
		
		query.setProperties(examOrderSearch);
		return pagingSupport.applyPaging(query, pageRequest).getResultList();
	
	}

	public int getExamOrderCount(ExamOrderSearch examOrderSearch) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count(DISTINCT o) FROM ExamOrderItem oi ")
					.append("JOIN oi.examOrder o ");
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), examOrderSearch);
		Number count = (Number) createQuery(queryString)
								.setProperties(examOrderSearch)
								.uniqueResult();
		return count == null ? 0 : count.intValue();
	}

	public List<City> getExamOrderCities() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT DISTINCT c FROM ExamOrderItem as oi ")
					.append("JOIN City as c ")
					.append("ON oi.examOrder.city.code = c.code ")
					.append("WHERE oi.examProduct.id = " + ExamProducts.VOUCHERS_FOR_PRACTICAL_EXAMS.getId() + " ");
		
		return createQuery(queryBuilder.toString(), City.class).getResultList();
	}
		
}
