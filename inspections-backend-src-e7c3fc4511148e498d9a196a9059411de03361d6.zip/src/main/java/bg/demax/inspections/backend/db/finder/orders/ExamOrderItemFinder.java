package bg.demax.inspections.backend.db.finder.orders;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import bg.demax.exams.entity.Voucher;
import bg.demax.hibernate.AbstractFinder;
import bg.demax.inspections.backend.dto.orders.Interval;
import bg.demax.inspections.backend.exception.ApplicationException;
import bg.demax.inspections.backend.exception.InsufficientQuantityException;
import bg.demax.pub.entity.ApplicationType;

@Repository
public class ExamOrderItemFinder extends AbstractFinder {

	public long getBiggestToNum() {
		Number count = (Number) createQuery("SELECT max(eoi.toNum) FROM ExamOrderItem eoi").uniqueResult();
		count = count != null ? count : 0;
		return count.longValue();
	}

	public boolean checkIfIntervalIsAvailable(long fromNum, long toNum) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count(DISTINCT oi) FROM ExamOrderItem oi ")
				.append("WHERE oi.fromNum BETWEEN :fromNum AND :toNum ")
				.append("OR oi.toNum BETWEEN :fromNum and :toNum");

		Number count = (Number) createQuery(queryBuilder.toString()).setParameter("fromNum", fromNum)
				.setParameter("toNum", toNum).uniqueResult();

		count = count != null ? count : 0;

		return count.intValue() <= 0;
	}

	public boolean checkIfPracticalExamVouchersForIntervalExist(long fromNum, long toNum) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count(DISTINCT v) FROM Voucher v ")
				.append(String.format("WHERE v.id BETWEEN %s AND %s", fromNum, toNum))
				.append(" AND v.applicationType.code = :practicalExamsVouchersCode");

		Number count = (Number) createQuery(queryBuilder.toString())
				.setParameter("practicalExamsVouchersCode", ApplicationType.CODE_PRACTICAL_EXAMS).uniqueResult();

		count = count != null ? count : 0;
		return count.longValue() == toNum - fromNum + 1;
	}

	public List<Interval> getAvailablePracticalVoucherIntervals(long quantity) {
		if (quantity > (long) Integer.MAX_VALUE) {
			throw new ApplicationException("Quantity of voucher order is too large");
		}

		int intQuantity = new Long(quantity).intValue();

		long biggestFreeVoucherId = getBiggestToNum() + 1;
		
		if (biggestFreeVoucherId > (long) Integer.MAX_VALUE) {
			throw new ApplicationException("Voucher ids have become too large to convert to int");
		}

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT v FROM Voucher v ").append(String.format("WHERE v.id >= %s ", biggestFreeVoucherId))
							.append("AND v.applicationType.code = :practicalExamsVouchersCode ")
							.append("ORDER BY v.id asc");

		List<Voucher> vouchers = createQuery(queryBuilder.toString(), Voucher.class)
				.setParameter("practicalExamsVouchersCode", ApplicationType.CODE_PRACTICAL_EXAMS)
				.setMaxResults(intQuantity).getResultList();

		if (vouchers == null || vouchers.size() != intQuantity) {
			throw new InsufficientQuantityException(String.format("Required %s vouchers but had %s", intQuantity, vouchers.size()));
		}

		return transformVouchersToIntervals(vouchers);
	}
	
	private List<Interval> transformVouchersToIntervals(List<Voucher> vouchers) {
		List<Interval> intervals = new ArrayList<>();

		int vouchersLen = vouchers.size();

		Voucher firstVoucher = vouchers.get(0);
		long fromNum = firstVoucher.getId();
		long toNum = firstVoucher.getId();

		if (vouchersLen == 1) {
			Interval interval = new Interval(fromNum, toNum);
			intervals.add(interval);
		} else {
			for (int i = 1; i < vouchersLen; i++) {
				Voucher voucher = vouchers.get(i);
				long voucherId = voucher.getId();
				
				if (voucherId == toNum + 1) {
					toNum++;
				} else {
					Interval interval = new Interval(fromNum, toNum);
					intervals.add(interval);
					fromNum = voucherId;
					toNum = voucherId;
				}
				
				boolean isLastRotation = i + 1 == vouchersLen;
				
				if (isLastRotation) {
					Interval interval = new Interval(fromNum, toNum);
					intervals.add(interval);
				}
			}
		}
		
		return intervals;
	}
}
