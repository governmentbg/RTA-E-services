package bg.demax.inspections.backend.db.finder.orders;

import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.entity.inspection.InspectionOrder;
import bg.demax.inspections.backend.entity.inspection.InspectionOrderStatus.InspectionOrderStatuses;
import bg.demax.inspections.backend.search.orders.InspectionOrderSearch;
import bg.demax.inspections.backend.search.orders.InspectionOrdersReportSearch;
import bg.demax.inspections.backend.search.orders.StickersReportSearch;
import bg.demax.inspections.backend.validation.IdentityNumberValidator;
import bg.demax.pub.entity.OrgUnit;

@Repository
public class InspectionOrderFinder extends AbstractFinder {	
	@Autowired
	private PagingAndSortingSupport pagingSupport;

	@Autowired
	private GenericSearchSupport searchSupport;
	
	public List<InspectionOrder> getOrders(InspectionOrderSearch orderSearch,
							PageRequest pageRequest) {
		
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT DISTINCT o FROM InspectionOrder o ")
					.append("JOIN o.orderItems oi ");

		if (orderSearch.getIdFirmEikOrPermitNum() != null && !orderSearch.getIdFirmEikOrPermitNum().trim().equals("")) {
			addSpecificSearchConstraints(queryBuilder, orderSearch);
		}
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), orderSearch);
		
		queryString = pagingSupport.applySorting(queryString, pageRequest);

		Query<InspectionOrder> query = createQuery(queryString, InspectionOrder.class);
		
		query.setProperties(orderSearch);
		
		pagingSupport.applyPaging(query, pageRequest);
		
		return query.getResultList();
	
	}
	
	public List<InspectionOrder> getOrders(InspectionOrderSearch orderSearch) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT DISTINCT o FROM InspectionOrder o ")
					.append("JOIN o.orderItems oi ");
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), orderSearch);
		
		Query<InspectionOrder> query = createQuery(queryString, InspectionOrder.class);	
		query.setProperties(orderSearch);
	
		return query.getResultList();
	}

	public int getOrderCount(InspectionOrderSearch orderSearch) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count(DISTINCT o) FROM InspectionOrder o ")
					.append("JOIN o.orderItems oi ");
		
		if (orderSearch.getIdFirmEikOrPermitNum() != null && !orderSearch.getIdFirmEikOrPermitNum().trim().equals("")) {
			addSpecificSearchConstraints(queryBuilder, orderSearch);
		}
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), orderSearch);
		
		Number count = (Number) createQuery(queryString)
								.setProperties(orderSearch)
								.uniqueResult();
		return count == null ? 0 : count.intValue();
	}

	public List<InspectionOrder> getOrdersForIdList(List<Long> inspectionOrderIds) {
		
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT DISTINCT o FROM InspectionOrder o ")
					.append("JOIN o.orderItems oi ")
					.append("WHERE o.id IN (:ids) ");
		
		
		return createQuery(queryBuilder.toString(), InspectionOrder.class)
						.setParameter("ids", inspectionOrderIds)
						.list();
	}

	public List<InspectionOrder> findAllByStatusesForPermitOrgUnit(List<String> statuses, OrgUnit orgUnit) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT o FROM InspectionOrder o ")
					.append("LEFT JOIN o.permitLine pl ")
					.append("LEFT JOIN pl.permit p ")
					.append("WHERE o.orderStatus.code IN (:statuses) AND p.orgUnit = :orgUnit ");
		
		return createQuery(queryBuilder.toString(), InspectionOrder.class)
						.setParameterList("statuses", statuses)
						.setParameter("orgUnit", orgUnit)
						.list();
	}

	public List<InspectionOrder> findLastYearActiveOrdersByPermit(int permitId) {
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("SELECT DISTINCT o FROM InspectionOrder o ")
					.append("LEFT JOIN o.permitLine permitLine ")
					.append("LEFT JOIN permitLine.permit permit ")
					.append("LEFT JOIN o.orderItems orderItems ")
					.append("WHERE permit.id = :permitId AND o.orderStatus.code = :activatedStatus ")
					.append("AND o.orderDatetime >= :oneYearAgo ")
					.append("ORDER BY o.orderDatetime DESC ");
		Query<InspectionOrder> query = createQuery(queryBuilder.toString(), InspectionOrder.class);
		return query.setParameter("permitId", permitId)
				.setParameter("activatedStatus", InspectionOrderStatuses.ACTIVATED.getCode())
				.setParameter("oneYearAgo", LocalDateTime.now().minusYears(1))
				.getResultList();
	}
	
	public List<InspectionOrder> findByPermitIdDescending(int permitId, int size) {
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("SELECT o FROM InspectionOrder o ")
					.append("WHERE o.permitLine.permit.id = :permitId ")
					.append("ORDER BY o.id DESC");
		
		Query<InspectionOrder> query = createQuery(queryBuilder.toString(), InspectionOrder.class);
		return query.setParameter("permitId", permitId)
				.setMaxResults(size)
				.getResultList();
	}
	
	public int countByPermitIdDescending(int permitId) {
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("SELECT COUNT(o) FROM InspectionOrder o ")
					.append("WHERE o.permitLine.permit.id = :permitId ");
		
		Number count = createQuery(queryBuilder.toString(), Number.class)
				.setParameter("permitId", permitId)
				.uniqueResult();
		return count == null ? 0 : count.intValue();
	}
	
	public List<InspectionOrder> findBySearch(InspectionOrdersReportSearch search, PageRequest pageRequest) {
		return findBySearchAndPageRequest(search, pageRequest);
	}

	public List<InspectionOrder> findBySearch(InspectionOrdersReportSearch search) {
		return findBySearchAndPageRequest(search, null);
	}
	
	public int countBySearch(InspectionOrdersReportSearch search) {

		String queryString = searchSupport.addSearchConstraints(buildReportSearchQuery(search, "SELECT count(o.id) "), search);	
		
		Query<Number> query = createQuery(queryString, Number.class);		
		
		query.setProperties(search);
		
		return query.uniqueResult().intValue();
	}
	
	// Stickers

	public List<InspectionOrder> findByStickersSearch(StickersReportSearch search, PageRequest pageRequest) {
		return findByStickersSearchAndPageRequest(search, pageRequest);
	}

	public List<InspectionOrder> findByStickersSearch(StickersReportSearch search) {
		return findByStickersSearchAndPageRequest(search, null);
	}

	public long countByStickersSearch(StickersReportSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT COUNT(DISTINCT o.id) ").append(beginNativeStickersSearchQuery(search));

		Number count = (Number) createNativeQuery(queryBuilder.toString()).setProperties(search).uniqueResult();

		return count != null ? count.longValue() : 0;
	}

	private String buildReportSearchQuery(InspectionOrdersReportSearch search, String selectString) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append(selectString)
			.append("FROM InspectionOrder o ")
			.append("JOIN o.permitLine pl ")
			.append("JOIN pl.permit p ");
		
		return queryBuilder.toString();
	}
	
	private void addSpecificSearchConstraints(StringBuilder queryBuilder, InspectionOrderSearch orderSearch) {
		String input = orderSearch.getIdFirmEikOrPermitNum();
		boolean isBulstat = IdentityNumberValidator.isValidBulstat(input);
		
		if (isBulstat) {
			queryBuilder.append("WHERE ( cast(o.id as text) = :idFirmEikOrPermitNum OR ");
			queryBuilder.append("o.subjectVersion.subject.identityNumber = :idFirmEikOrPermitNum ) ");
		} else {
			queryBuilder.append("WHERE ( cast(o.id as text) = :idFirmEikOrPermitNum OR ");
			queryBuilder.append("cast(o.permitLine.permit.permitNumber as text) = :idFirmEikOrPermitNum ) ");
		}
		
	}
	
	private List<InspectionOrder> findBySearchAndPageRequest(InspectionOrdersReportSearch search, PageRequest pageRequest) {
		String queryString = searchSupport.addSearchConstraints(buildReportSearchQuery(search, "SELECT o "), search);

		Query<InspectionOrder> query = createQuery(queryString, InspectionOrder.class);

		if (pageRequest != null) {
			pagingSupport.applyPaging(query, pageRequest);
		}

		query.setProperties(search);

		return query.list();
	}

	private List<InspectionOrder> findByStickersSearchAndPageRequest(StickersReportSearch search, PageRequest pageRequest) {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT o.* ");

		if (pageRequest != null) {
			builder.append(getStickersPagedQuery(search, pageRequest));
		} else {
			builder.append(getStickersDistinctQuery(search));
		}

		Query<InspectionOrder> query = createNativeQuery(builder.toString(), InspectionOrder.class);

		if (pageRequest != null) {
			query.setParameter("limit", pageRequest.getPageSize());
			query.setParameter("offset", pageRequest.getPageOffset());
		}

		return query.setProperties(search).getResultList();
	}

	private String getStickersDistinctQuery(StickersReportSearch search) {
		String searchQuery = beginNativeStickersSearchQuery(search);

		return searchQuery + " GROUP BY o.id ORDER BY o.id DESC ";
	}

	private String getStickersPagedQuery(StickersReportSearch search, PageRequest pageRequest) {
		String searchQuery = beginNativeStickersSearchQuery(search);

		return searchQuery + " GROUP BY o.id ORDER BY o.id DESC LIMIT :limit OFFSET :offset";
	}

	private String beginNativeStickersSearchQuery(StickersReportSearch search) {
		StringBuilder builder = new StringBuilder();

		String firstPart = builder
						.append("FROM public.orders o ")
						.append("JOIN techinsp.permit_lines pl ON o.permit_line_id = pl.id ")
						.append("JOIN techinsp.permits p ON pl.permit_id = p.id ")
						.append("JOIN public.order_items oi ON o.id = oi.order_id ")
						.append("JOIN public.product_nums pn ON oi.id = pn.order_item_id ").toString();

		builder = new StringBuilder();

		builder.append(searchSupport.addSearchConstraints(firstPart, search));

		return builder.toString();
	}

}
