package bg.demax.inspections.backend.db.finder.orders;

import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;

@Repository
public class InspectionOrderItemFinder extends AbstractFinder {

	public boolean checkIfIntervalIsAvailable(long fromNum, long toNum) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count(DISTINCT oi) FROM InspectionOrderItem oi ")
					.append("WHERE oi.fromNum BETWEEN :fromNum AND :toNum ")
					.append("OR oi.toNum BETWEEN :fromNum and :toNum");
		
		Number count = (Number) createQuery(queryBuilder.toString())
				.setParameter("fromNum", fromNum)
				.setParameter("toNum", toNum)
				.uniqueResult();
		
		count = count != null ? count : 0;
		
		return count.intValue() <= 0;
	}
	
	public long getBiggestToNum() {
		Number count = (Number) createQuery("SELECT max(oi.toNum) FROM InspectionOrderItem oi")
								.uniqueResult();
		count = count != null ? count : 0;
		return count.longValue();
	}
	
	public long getBiggestToNumByProductId(long productId) {
		String hql = "SELECT max(oi.toNum) FROM InspectionOrderItem oi WHERE oi.product.id = :productId";
		Number count = (Number) createQuery(hql).setParameter("productId", productId)
								.uniqueResult();
		count = count != null ? count : 0;
		return count.longValue();
	}

}
