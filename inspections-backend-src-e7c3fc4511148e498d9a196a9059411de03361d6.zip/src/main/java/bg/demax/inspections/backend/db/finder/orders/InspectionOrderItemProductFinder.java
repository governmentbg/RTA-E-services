package bg.demax.inspections.backend.db.finder.orders;

import java.util.List;

import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.inspections.backend.entity.inspection.InspectionOrderItemProduct;

@Repository
public class InspectionOrderItemProductFinder extends AbstractFinder {

	public Integer findActiveStickersForOrderItem(long orderItemId) {
		StringBuilder queryBuilder = new StringBuilder();
		
		queryBuilder.append("SELECT COUNT(orderItemProduct) FROM InspectionOrderItemProduct orderItemProduct ")
					.append("LEFT JOIN orderItemProduct.id.orderItem orderItem ")
					.append("WHERE orderItem.id = :orderItemId ")
					.append("AND orderItemProduct.id.documentNumber >= orderItem.fromNum ")
					.append("AND orderItemProduct.id.documentNumber <= orderItem.toNum ")
					.append("AND orderItemProduct.documentState = :stateCodeActivated ");
		
		Number count = (Number) createQuery(queryBuilder.toString())
				.setParameter("orderItemId", orderItemId)
				.setParameter("stateCodeActivated", InspectionOrderItemProduct.STATE_CODE_ACTIVATED)
				.uniqueResult();
		
		return count != null ? count.intValue() : 0;		
	}

	public List<InspectionOrderItemProduct> findStickersForOrderItems(List<Long> orderItemIds) {
		StringBuilder queryBuilder = new StringBuilder();
		
		queryBuilder.append("SELECT orderItemProduct FROM InspectionOrderItemProduct orderItemProduct ")
					.append("LEFT JOIN orderItemProduct.id.orderItem orderItem ")
					.append("WHERE orderItem.id IN (:orderItemIds) ");
		
		return createQuery(queryBuilder.toString(), InspectionOrderItemProduct.class)
						.setParameter("orderItemIds", orderItemIds)
						.getResultList();
	}

}
