package bg.demax.inspections.backend.db.finder.orders;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.entity.inspection.InspectionDeliveryProtocol;
import bg.demax.inspections.backend.search.orders.InspectionDeliveryProtocolSearch;

@Repository
public class InspectionProtocolFinder extends AbstractFinder {
	@Autowired
	private PagingAndSortingSupport pagingSupport;

	@Autowired
	private GenericSearchSupport searchSupport;

	public List<InspectionDeliveryProtocol> getDeliveryProtocols(InspectionDeliveryProtocolSearch search,
			PageRequest pageRequest) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT DISTINCT idp FROM InspectionDeliveryProtocol idp ")
					.append("JOIN idp.inspectionOrders io WHERE idp.creationTimestamp IS NOT NULL AND idp.billOfLading IS NOT NULL");
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString = pagingSupport.applySorting(queryString, pageRequest);

		Query<InspectionDeliveryProtocol> query = createQuery(queryString, InspectionDeliveryProtocol.class);

		query.setProperties(search);
		return pagingSupport.applyPaging(query, pageRequest).getResultList();
	}

	public int getDeliveryProtocolsCount(InspectionDeliveryProtocolSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count(DISTINCT idp) FROM InspectionDeliveryProtocol idp ")
					.append("JOIN idp.inspectionOrders io WHERE idp.creationTimestamp IS NOT NULL AND idp.billOfLading IS NOT NULL");
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);

		Number count = (Number) createQuery(queryString)
				.setProperties(search)
				.uniqueResult();
		return count == null ? 0 : count.intValue();
	}
}
