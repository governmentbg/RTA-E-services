package bg.demax.inspections.backend.db.finder.permit;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.OrderClause;
import bg.demax.hibernate.paging.OrderDirection;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.entity.permit.PermitAppliedDocumentExt;
import bg.demax.inspections.backend.entity.permit.PermitDocumentVersion;
import bg.demax.inspections.backend.search.DashboardPermitAppliedDocumentsReportSearch;
import bg.demax.inspections.backend.search.PermitAppliedDocumentsReportSearch;
import bg.demax.inspections.backend.util.PermitReportUtil;
import bg.demax.pub.entity.AppliedDocumentType;
import bg.demax.techinsp.entity.PermitStatus;

@Repository
public class PermitAppliedDocumentFinder extends AbstractFinder {

	@Autowired
	private PagingAndSortingSupport pagingSupport;

	@Autowired
	private GenericSearchSupport searchSupport;
	
	public List<PermitAppliedDocumentExt> findPermitAppliedDocumentsBySearch(PermitAppliedDocumentsReportSearch search,
					PageRequest pageRequest, long days) {

		String queryString = "SELECT permitApplDocsExt " + beginSearchQueryStringForReport(search);
		queryString = pagingSupport.applySorting(queryString, pageRequest);
		Query<PermitAppliedDocumentExt> query = createQuery(queryString, PermitAppliedDocumentExt.class);
		pagingSupport.applyPaging(query, pageRequest);

		if (search.getStatusCode() != null && (search.getStatusCode().equals(PermitReportUtil.DOC_EXPIRING_CODE) 
						|| search.getStatusCode().equals(PermitReportUtil.DOC_VALID_CODE))) {
			query.setParameter("dueDate", LocalDate.now().plusDays(days));
		}
		return query.setProperties(search).list();
	}

	public List<PermitAppliedDocumentExt> findPermitAppliedDocumentsBySearch(PermitAppliedDocumentsReportSearch search,
			long days) {

		String queryString = "SELECT permitApplDocsExt " + beginSearchQueryStringForReport(search);
		Query<PermitAppliedDocumentExt> query = createQuery(queryString, PermitAppliedDocumentExt.class);

		if (search.getStatusCode() != null && (search.getStatusCode().equals(PermitReportUtil.DOC_EXPIRING_CODE)
						|| search.getStatusCode().equals(PermitReportUtil.DOC_VALID_CODE))) {
			query.setParameter("dueDate", LocalDate.now().plusDays(days));
		}
		return query.setProperties(search).list();
	}

	public int countPermitAppliedDocumentsBySearch(PermitAppliedDocumentsReportSearch search, long days) {
		String queryString = "SELECT DISTINCT COUNT(permitApplDocsExt.id) " + beginSearchQueryStringForReport(search);
		Query<Number> query = createQuery(queryString, Number.class).setProperties(search);

		if (search.getStatusCode() != null && (search.getStatusCode().equals(PermitReportUtil.DOC_EXPIRING_CODE)
						|| search.getStatusCode().equals(PermitReportUtil.DOC_VALID_CODE))) {
			query.setParameter("dueDate", LocalDate.now().plusDays(days));
		}
		Number count = query.uniqueResult();
		return count == null ? 0 : count.intValue();
	}

	private String beginSearchQueryStringForReport(PermitAppliedDocumentsReportSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM PermitAppliedDocumentExt permitApplDocsExt ")
					.append("JOIN permitApplDocsExt.document permitApplDocs ")
					.append("JOIN permitApplDocs.permit permit ")
					.append("WHERE permit.permitNumber IS NOT NULL ");
		return searchSupport.addSearchConstraints(queryBuilder.toString(), search);
	}

	public List<PermitAppliedDocumentExt> findValidPermitAppliedDocumentsForValidPermits(int daysUntilExpire) {

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT pade ")
					.append("FROM PermitAppliedDocumentExt pade ")
					.append("JOIN FETCH pade.document pad ")
					.append("JOIN pade.lastVersion lv ")
					.append("JOIN lv.status ls ")
					.append("JOIN FETCH pad.permit p ")
					.append("JOIN p.docStatus s ")
					.append("WHERE ls.code = 'VALID' AND pad.isValid = true AND s.code = :docStatus AND pad.validTo <= :expirationDate ");
		Query<PermitAppliedDocumentExt> query = createQuery(queryBuilder.toString(), PermitAppliedDocumentExt.class);
		query.setParameter("docStatus", PermitStatus.VALID_CODE);
		query.setParameter("expirationDate", LocalDate.now().plusDays(daysUntilExpire));
		
	
		return query.list();
	}

	public List<PermitDocumentVersion> findAllRequiredAndPeriodicalBySearch(
		DashboardPermitAppliedDocumentsReportSearch search, int days) {
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder
			.append("SELECT dv FROM PermitLink pl ")
			.append("JOIN pl.lastApprovedVersion pv ")
			.append("JOIN pv.permitInfo pi ")
			.append("JOIN pi.orgUnit ou ")
			.append("JOIN pv.status s ")
			.append("JOIN pv.documentVersions dv ")
			.append("JOIN dv.status dvs ")
			.append("JOIN dv.document d ")
			.append("JOIN d.type t ")
			.append("WHERE t.isPeriodically = TRUE ")
			.append("AND t.isOptional = FALSE ")
			.append("AND t.isValid = TRUE ")
			.append("AND t.requiredFor = 'P' ");

		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		OrderClause clause1 = new OrderClause("pi.permitNumber", OrderDirection.DESCENDING);
		queryString = pagingSupport.applySorting(queryString, Arrays.asList(clause1));

		Query<PermitDocumentVersion> query = createQuery(queryString, PermitDocumentVersion.class);
		

		if (search.getStatusCode() != null) {
			if (search.getStatusCode().equals(PermitReportUtil.DOC_EXPIRING_CODE)) {
				query.setParameter("dueDate", LocalDate.now().plusDays(days));
			}

			if (!search.getStatusCode().equals(PermitReportUtil.DOC_INVALID_CODE)) {
				query.setParameter("currentDate", LocalDate.now());
			}
		}

		return query.setProperties(search).getResultList();
	}

	public int countValidDocumentForPermitIdByType(AppliedDocumentType type, int permitId, LocalDate validTill) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT COUNT(pad.id) FROM PermitAppliedDocumentExt padx ")
			.append("JOIN padx.document pad ")
			.append("JOIN padx.lastVersion lv ")
			.append("JOIN lv.status s ")
			.append("WHERE pad.permit.id = :permitId ")
			.append("AND pad.type = :type AND pad.isApproved = 'Y' ")
			.append("AND pad.validTo > :validityDate ")
			.append("AND s.code = 'VALID'");
		

		Number count = (Number) createQuery(queryBuilder.toString())
			.setParameter("permitId", permitId)
			.setParameter("type", type)
			.setParameter("validityDate", validTill)
			.uniqueResult();
		return count == null ? 0 : count.intValue();
	}

}
