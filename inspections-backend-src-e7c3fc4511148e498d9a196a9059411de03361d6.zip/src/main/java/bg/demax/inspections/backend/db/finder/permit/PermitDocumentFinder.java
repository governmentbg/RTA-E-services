package bg.demax.inspections.backend.db.finder.permit;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.entity.permit.PermitDocumentVersion;

@Repository
public class PermitDocumentFinder extends AbstractFinder {

	@Autowired
	private PagingAndSortingSupport pagingSupport;

	public List<PermitDocumentVersion> findPermitDetailsDocumentVersionsByPermitVersionId(int permitVersionId,
			PageRequest pageRequest) {
		String queryString = "SELECT * " + buildBeginQuery();
		queryString = pagingSupport.applySorting(queryString, pageRequest);
		Query<PermitDocumentVersion> query = createNativeQuery(queryString, PermitDocumentVersion.class);
		pagingSupport.applyPaging(query, pageRequest);
		query = query.setParameter("permitVersionId", permitVersionId);

		return query.getResultList();
	}

	public int countByPermitVersionId(int permitVersionId) {
		String queryString = "SELECT COUNT(docs.id) " + buildBeginQuery();

		return ((Number) createNativeQuery(queryString).setParameter("permitVersionId", permitVersionId)
				.getSingleResult()).intValue();
	}
	
	public PermitDocumentVersion findVersionByDocumentIdAndPermitVersionId(int documentVersionId, int permitVersionId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT doc FROM PermitVersion AS pv ")
			.append("JOIN pv.documentVersions AS doc ")
			.append("WHERE pv.id = :permitVersionId ")
			.append("AND doc.id = :documentVersionId");

		Query<PermitDocumentVersion> query = createQuery(queryBuilder.toString(), PermitDocumentVersion.class);
		query = query
				.setParameter("documentVersionId", documentVersionId)
				.setParameter("permitVersionId", permitVersionId);

		return query.uniqueResult();
	}
	
	public boolean containsInLastApprovedPermitVersion(int permitVersionId, int documentVersionId) {		
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder
			.append("SELECT 1 FROM inspections.permit_versions_permit_document_versions AS pv_pdv ")
			.append("WHERE pv_pdv.permit_version_id = ")
			.append("(SELECT pl.last_approved_version_id FROM inspections.permit_links AS pl ")
			.append("WHERE pl.id = ")
			.append("(SELECT pv.permit_link_id FROM inspections.permit_versions AS pv ")
			.append("WHERE pv.id = :permitVersionId)) ")
			.append("AND pv_pdv.permit_document_version_id = :documentVersionId");

		@SuppressWarnings("unchecked")
		Query<Integer> query = (Query<Integer>) createNativeQuery(sqlBuilder.toString())
			.setMaxResults(1);
		query.setParameter("permitVersionId", permitVersionId)
			.setParameter("documentVersionId", documentVersionId);

		Integer result = query.uniqueResult();
		return result != null && result.intValue() > 0;
	}
	
	private String buildBeginQuery() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("FROM inspections.permit_document_versions AS docs ")
			.append("JOIN techinsp.permit_appl_docs as pad ON docs.document_id = pad.id ")
			.append("JOIN public.n_req_docs as rd ON rd.code = pad.req_doc ")
			.append("WHERE docs.id IN ")
			.append("(SELECT permit_document_version_id FROM inspections.permit_versions_permit_document_versions AS pv_pdv ")
			.append("WHERE pv_pdv.permit_version_id = :permitVersionId)");

		return queryBuilder.toString();
	}
}
