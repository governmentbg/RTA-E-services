package bg.demax.inspections.backend.db.finder.permit;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitHtmlReportDto;
import bg.demax.inspections.backend.entity.permit.PermitVersion;
import bg.demax.inspections.backend.search.DashbaordPermitVersionSearchForInspectorCertification;
import bg.demax.inspections.backend.search.PermitVersionReportSearch;
import bg.demax.inspections.backend.search.PermitVersionSearch;
import bg.demax.inspections.backend.search.PermitVersionSearchForInspectorDocumentsReport;
import bg.demax.pub.entity.OrgUnit;
import bg.demax.techinsp.entity.Permit;
import bg.demax.techinsp.entity.PermitInspectorStatus;
import bg.demax.techinsp.entity.PermitStatus;

@Repository
public class PermitFinder extends AbstractFinder {

	@Autowired
	private PagingAndSortingSupport pagingSupport;

	@Autowired
	private GenericSearchSupport searchSupport;

	public Permit findByNumber(int permitNumber) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT p FROM Permit p WHERE p.permitNumber = :permitNumber");

		Query<Permit> query = createQuery(queryBuilder.toString(), Permit.class);

		return query.setParameter("permitNumber", permitNumber).uniqueResult();
	}

	public List<Permit> findValidByOrgUnit(OrgUnit orgUnit) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT p FROM Permit p ")
			.append("JOIN p.docStatus s ")
			.append("WHERE s.code IN (:statuses) ")
			.append("AND p.orgUnit = :orgUnit");

		Query<Permit> query = createQuery(queryBuilder.toString(), Permit.class);
		query.setParameter("statuses", Arrays.asList(PermitStatus.VALID_CODE, PermitStatus.REVOKING_IN_PROCESS_CODE))
				.setParameter("orgUnit", orgUnit);

		return query.list();
	}

	public List<Permit> findAllValid() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT p FROM Permit p ")
			.append("JOIN p.docStatus s ")
			.append("WHERE s.code IN (:statuses)");

		Query<Permit> query = createQuery(queryBuilder.toString(), Permit.class);
		query.setParameter("statuses", Arrays.asList(PermitStatus.VALID_CODE, PermitStatus.REVOKING_IN_PROCESS_CODE));

		return query.list();
	}
	
	public List<PermitHtmlReportDto> findAllValidReport() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
		.append("SELECT permit.permit_num as \"permitNumber\", subjectver.full_name as \"companyName\", permit.ktp_address as \"address\", "
				+ "subjectver.phone_num as \"phoneNumber\", city.name as \"city\", region.name as \"region\", "
				+ "array_to_string(ARRAY_AGG(plc.category), ',') as \"categories\" "
				+ "FROM techinsp.permits permit ")
		.append("inner join techinsp.n_permit_statuses permitstat on permit.doc_status = permitstat.code ")
		.append("inner join public.subj_versions subjectver on permit.subj_ver_id = subjectver.id ")
		.append("inner join public.n_cities city on permit.ktp_city_code = city.code ")
		.append("inner join public.n_regions region on city.region_code = region.code ")
		.append("inner join techinsp.permit_lines line on line.permit_id = permit.id ")
		.append("inner join techinsp.permit_line_categories plc on plc.line_id = line.id ")
		.append("WHERE permitstat.code IN ('ВЛ', 'ПОТ') ")
		.append("AND line.is_valid = 'Y' ")
		.append("group by permit.permit_num, subjectver.full_name, permit.ktp_address, subjectver.phone_num, city.name, region.name ")
			.append("order by permit.permit_num");
		
		
		@SuppressWarnings({ "unchecked", "deprecation" })
		List<PermitHtmlReportDto> resultList = (List<PermitHtmlReportDto>) createNativeQuery(queryBuilder.toString())
				.setResultTransformer( Transformers.aliasToBean( PermitHtmlReportDto.class )).list();
		
		return resultList;
	}

	public List<Permit> findPermitBySubjectIdentityNumber(String identityNumber) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT p FROM Permit p ")
			.append("JOIN p.subject s ")
			.append("WHERE s.identityNumber IN (:identityNumber)");

		Query<Permit> query = createQuery(queryBuilder.toString(), Permit.class);
		query.setParameter("identityNumber", identityNumber);

		return query.list();
	}
	
	public List<Permit> findAllValidAndExpiring(int daysUntilExpire) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT p FROM Permit p ")
			.append("JOIN p.docStatus s ")
			.append("WHERE s.code IN (:statuses) AND p.validTo <= :expirationDate");

		Query<Permit> query = createQuery(queryBuilder.toString(), Permit.class);
		query.setParameter("statuses", Arrays.asList(PermitStatus.VALID_CODE, PermitStatus.REVOKING_IN_PROCESS_CODE));
		query.setParameter("expirationDate", LocalDate.now().plusDays(daysUntilExpire));

		return query.list();
	}

	public List<Permit> findValidPermitsByInspectionTypeCode(String inspectionTypeCode) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT p FROM Permit p ")
			.append("JOIN p.docStatus s ")
			.append("JOIN p.permitLines pl ")
			.append("JOIN pl.inspectionTypes plit ")
			.append("JOIN plit.inspectionType it ")
			.append("WHERE s.code IN (:statuses) ")
			.append("AND pl.isValid = true ")
			.append("AND plit.isValid = true ")
			.append("AND it.code = :inspectionTypeCode");

		Query<Permit> query = createQuery(queryBuilder.toString(), Permit.class);
		query.setParameter("statuses", Arrays.asList(PermitStatus.VALID_CODE, PermitStatus.REVOKING_IN_PROCESS_CODE))
			.setParameter("inspectionTypeCode", inspectionTypeCode);

		return query.list();
	}
	
	public List<Permit> findValidCategoryLPermits() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT p FROM Permit p ")
			.append("JOIN p.docStatus s ")
			.append("JOIN p.permitLines pl ")
			.append("JOIN pl.categories plc ")
			.append("JOIN plc.vehicleCategory vc ")
			.append("WHERE s.code IN (:statuses) ")
			.append("AND pl.isValid = true ")
			.append("AND plc.isValid = true ")
			.append("AND vc.code LIKE 'L%'");

		Query<Permit> query = createQuery(queryBuilder.toString(), Permit.class);
		query.setParameter("statuses", Arrays.asList(PermitStatus.VALID_CODE, PermitStatus.REVOKING_IN_PROCESS_CODE));

		return query.list();
	}

	public List<PermitVersion> findPermitVersionsBySearch(PermitVersionSearch search, PageRequest pageRequest) {
		String searchQueryString = beginSearchQueryString(search);
		searchQueryString = pagingSupport.applySorting(searchQueryString, pageRequest);

		Query<PermitVersion> query = createQuery(searchQueryString, PermitVersion.class);
		pagingSupport.applyPaging(query, pageRequest);

		return query.setProperties(search).getResultList();
	}
	
	public List<PermitVersion> findPermitVersionsForReportBySearch(PermitVersionReportSearch search, PageRequest pageRequest) {
		String queryString = beginSearchQueryStringForReport(search);
		queryString = pagingSupport.applySorting(queryString, pageRequest);
		Query<PermitVersion> query = createQuery(queryString, PermitVersion.class);
		pagingSupport.applyPaging(query, pageRequest);
		
		return query.setProperties(search).getResultList();
	}
	
	public List<PermitVersion> findPermitVersionsForReportBySearch(PermitVersionReportSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append(beginSearchQueryStringForReport(search));
		queryBuilder.append(" ORDER BY permitInfo.permitNumber DESC");
		Query<PermitVersion> query = createQuery(queryBuilder.toString(), PermitVersion.class);
		return query.setProperties(search).getResultList();
	}
	
	public int countPermitVersionsForReportBySearch(PermitVersionReportSearch search) {
		String queryString = "SELECT COUNT(id) " + beginSearchQueryStringForReport(search);
		Number count = createQuery(queryString, Number.class).setProperties(search).uniqueResult();
		return count == null ? 0 : count.intValue();
	}

	public int countPermitsBySearch(PermitVersionSearch search) {
		String queryString = "SELECT COUNT(id) " + beginSearchQueryString(search);

		Number count = createQuery(queryString, Number.class).setProperties(search).uniqueResult();
		return count == null ? 0 : count.intValue();
	}
	
	public PermitVersion findPermitVersionById(Integer id) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT p FROM PermitVersion p WHERE p.id = :id");
		Query<PermitVersion> query = createQuery(queryBuilder.toString(), PermitVersion.class);
		query.setParameter("id", id);
		
		return query.uniqueResult();
	}
	
	public int findLastPermitNumber() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT pi.permitNumber FROM PermitInfo AS pi ")
			.append("WHERE pi.permitNumber IS NOT NULL ")
			.append("ORDER BY pi.permitNumber DESC");
		
		Query<Integer> query = createQuery(queryBuilder.toString(), Integer.class);

		return query.setMaxResults(1).getSingleResult();
	}
	
	public List<PermitVersion> findAllNonHistoricVersionsByInspectorIdWithoutPermitId(
			int inspectorVersionId, int permitVersionIdToSkip) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT * FROM inspections.permit_versions AS pv ")
			.append("JOIN techinsp.n_permit_statuses AS ps ")
			.append("ON ps.code = pv.status ")
			.append("JOIN inspections.permit_versions_permit_inspector_versions AS pv_piv ")
			.append("ON pv_piv.permit_version_id = pv.id ")
			.append("WHERE pv_piv.permit_inspector_version_id = :inspectorVersionId ")
			.append("AND pv.status NOT IN (:statuses) ")
			.append("AND pv.id != :permitVersionIdToSkip ")
			.append("AND pv.version_number IS NULL");
		Query<PermitVersion> query = createNativeQuery(queryBuilder.toString(), PermitVersion.class);
		query.setParameter("inspectorVersionId", inspectorVersionId)
			.setParameter("permitVersionIdToSkip", permitVersionIdToSkip)
			.setParameter("statuses", Arrays.asList(
					PermitStatus.CHANGED_CONDITIONS_CODE,
					PermitStatus.CHANGED_LISTS_CODE,
					PermitStatus.CHANGED_CONDITIONS_AND_LISTS_CODE,
					PermitStatus.REJECTED_CODE));
		
		return query.list();
	}
	
	public List<PermitVersion> findVersionsBySubjectIdAndStatuses(long subjectId, List<String> statuses) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT pv FROM PermitVersion pv ")
					.append("JOIN pv.inspectors pivs ")
					.append("WHERE pv.status.code IN (:statuses) ")
					.append("AND pivs IN (FROM PermitInspectorVersion piv ")
					.append("WHERE piv.subjectVersion.subject.id = :subjectId) ")
					.append("AND pv.versionNumber IS NULL");
				
		Query<PermitVersion> query = createQuery(queryBuilder.toString(), PermitVersion.class);
		
		return query
			.setParameter("subjectId", subjectId)
			.setParameter("statuses", statuses)
			.list();
	}
	
	public List<PermitVersion> findLastApprovedValidOrRevokingInProgressVersionsBySubjectId(long subjectId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT pv FROM PermitLink pl ")
					.append("JOIN pl.lastApprovedVersion pv ")
					.append("JOIN pv.inspectors pivs ")
					.append("WHERE pv.status.code IN (:statuses) ")
					.append("AND pivs.subjectVersion.subject.id = :subjectId");
				
		Query<PermitVersion> query = createQuery(queryBuilder.toString(), PermitVersion.class);
		
		return query
			.setParameter("subjectId", subjectId)
			.setParameter("statuses", Arrays.asList(PermitStatus.VALID_CODE, PermitStatus.REVOKING_IN_PROCESS_CODE))
			.list();
	}
	
	public List<PermitVersion> findLastApprovedValidOrRevokingInProgressVersionsBySubjectIdAndIncludedStatus(long subjectId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT pv FROM PermitLink pl ")
					.append("JOIN pl.lastApprovedVersion pv ")
					.append("JOIN pv.inspectors piv ")
					.append("WHERE pv.status.code IN (:statuses) ")
					.append("AND piv.currentStatus = :currentStatus ")
					.append("AND piv.subjectVersion.subject.id = :subjectId");
				
		Query<PermitVersion> query = createQuery(queryBuilder.toString(), PermitVersion.class);
		
		return query
			.setParameter("subjectId", subjectId)
			.setParameter("statuses", Arrays.asList(PermitStatus.VALID_CODE, PermitStatus.REVOKING_IN_PROCESS_CODE))
			.setParameter("currentStatus", PermitInspectorStatus.INCLUDED.getCode())
			.list();
	}

	public List<PermitVersion> findAllByExistingDraftSubjectDocumentsSnapshot(long subjectId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT pv FROM PermitVersion pv ")
					.append("JOIN pv.inspectors piv ")
					.append("WHERE piv.currentStatus = :currentStatus ")
					.append("AND piv.subjectVersion.subject.id = :subjectId ")
					.append("AND piv.snapshot.isDraft = true");
				
		Query<PermitVersion> query = createQuery(queryBuilder.toString(), PermitVersion.class);
		
		return query
			.setParameter("subjectId", subjectId)
			.setParameter("currentStatus", PermitInspectorStatus.INCLUDED.getCode())
			.list();
	}

	public Integer findLastVersionNumberByPermitLinkId(int permitLinkId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT pv.versionNumber FROM PermitVersion AS pv ")
			.append("JOIN pv.permitLink AS pl ")
			.append("WHERE pl.id = :permitLinkId ")
			.append("AND pv.versionNumber IS NOT NULL ")
			.append("ORDER BY pv.versionNumber DESC");
		
		Query<Integer> query = createQuery(queryBuilder.toString(), Integer.class);
		query.setParameter("permitLinkId", permitLinkId);

		return query.setMaxResults(1).uniqueResult();
	}
	
	public List<PermitVersion> findPermitVersionsForInspectorDocumentsReportBySearch(
			PermitVersionSearchForInspectorDocumentsReport search) {
		StringBuilder queryBuilder = new StringBuilder();
		
		queryBuilder.append("SELECT pv FROM PermitLink pl ")
			.append("JOIN pl.lastApprovedVersion pv ")
			.append("JOIN pv.inspectors piv ")
			.append("JOIN pv.permitInfo pi ")
			.append("JOIN pi.orgUnit orgUnit ")
			.append("JOIN pv.status status ")
			.append("JOIN piv.permitInspectorInfo pii ")
			.append("JOIN piv.subjectVersion sv ")
			.append("JOIN sv.subject subject ");
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		Query<PermitVersion> query = createQuery(queryString, PermitVersion.class);
		
		return query.setProperties(search).getResultList();
	}

	public List<PermitVersion> findAllLastApproverdPermitVersionsForInspectorCertification(
		DashbaordPermitVersionSearchForInspectorCertification search) {
		StringBuilder queryBuilder = new StringBuilder();
		
		queryBuilder.append("SELECT pv FROM PermitLink pl ")
			.append("JOIN pl.lastApprovedVersion pv ")
			.append("JOIN pv.inspectors piv ")
			.append("JOIN piv.certifications c ")
			.append("JOIN pv.permitInfo pi ")
			.append("JOIN pi.orgUnit orgUnit ")
			.append("JOIN pv.status status ");
			
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		Query<PermitVersion> query = createQuery(queryString, PermitVersion.class);
		
		return query.setProperties(search).getResultList();
	}
	
	public PermitVersion fetchLastApprovedValidPermitVersionContainingLine(int permitLineId) {
		StringBuilder queryBuilder = new StringBuilder();
		
		queryBuilder.append("SELECT pv FROM PermitLink pl ")
			.append("JOIN pl.lastApprovedVersion pv ")
			.append("JOIN pv.permitLines line ")
			.append("JOIN pv.status status ")
			.append("JOIN FETCH pv.permitInfo pi ")
			.append("JOIN FETCH pi.orgUnit ou ")
			.append("JOIN FETCH pv.subjectVersion sv ")
			.append("JOIN FETCH sv.subject s ")
			.append("WHERE line.id = :permitLineId ")
			.append("AND status.id IN (:statuses) ");
		
		Query<PermitVersion> query = createQuery(queryBuilder.toString(), PermitVersion.class);
		query.setParameter("permitLineId", permitLineId)
			.setParameter("statuses", Arrays.asList(PermitStatus.VALID_CODE, PermitStatus.REVOKING_IN_PROCESS_CODE));
		
		return query.uniqueResult();
	}
	
	public PermitVersion findLastApprovedPermitVersionByPermitId(int permitId) {
		StringBuilder queryBuilder = new StringBuilder();
		
		queryBuilder
			.append("SELECT pv FROM PermitLink AS pl ")
			.append("JOIN pl.lastApprovedVersion pv ")
			.append("JOIN pl.permit p ")
			.append("WHERE p.id = :permitId");
		
		Query<PermitVersion> query = createQuery(queryBuilder.toString(), PermitVersion.class);
		query.setParameter("permitId", permitId);
		
		return query.uniqueResult();
	}

	public PermitVersion findLastApprovedPermitVersionsForInspectVersion(
			int permitInspectorVersionId) {
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("SELECT pv FROM PermitLink pl ")
				.append("JOIN pl.lastApprovedVersion pv ")
				.append("JOIN pv.inspectors piv ")
				.append("WHERE piv.id = :permitInspectorVersionId ");

		Query<PermitVersion> query = createQuery(queryBuilder.toString(), PermitVersion.class);
		query.setParameter("permitInspectorVersionId", permitInspectorVersionId);

		return query.uniqueResult();
	}


	private String beginSearchQueryString(PermitVersionSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM PermitVersion AS permitVersion ");
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		return queryString;
	}
	
	private String beginSearchQueryStringForReport(PermitVersionReportSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM PermitVersion AS permitVersion ");
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		return queryString;
	}

}
