package bg.demax.inspections.backend.db.finder.permit;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.inspections.backend.entity.permit.PermitInspection;
import bg.demax.inspections.backend.entity.permit.PermitInspectionWithFile;

@Repository
public class PermitInspectionFinder extends AbstractFinder {

	public PermitInspection findByPermitVersionIdAndId(int permitVersionId, int permitInspectionId) {
		StringBuilder queryBuilder = new StringBuilder()
			.append("SELECT pi FROM PermitVersion AS pv ")
			.append("JOIN pv.permitInspections AS pi ")
			.append("WHERE pv.id = :permitVersionId ")
			.append("AND pi.id = :permitInspectionId");
			

		Query<PermitInspection> query = createQuery(queryBuilder.toString(), PermitInspection.class);
		query.setParameter("permitVersionId", permitVersionId)
			.setParameter("permitInspectionId", permitInspectionId);

		return query.uniqueResult();
	}
	
	public PermitInspectionWithFile findPermitInspectionWithFileByPermitVersionIdAndId(int permitVersionId,  int permitInspectionId) {
		StringBuilder queryBuilder = new StringBuilder()
			.append("SELECT pi FROM PermitInspectionWithFile AS pi ")
			.append("JOIN pi.permitVersions AS pv ")
			.append("WHERE pv.id = :permitVersionId ")
			.append("AND pi.id = :permitInspectionId");

		Query<PermitInspectionWithFile> query = createQuery(queryBuilder.toString(), PermitInspectionWithFile.class);
		query.setParameter("permitVersionId", permitVersionId)
			.setParameter("permitInspectionId", permitInspectionId);

		return query.uniqueResult();
	}
	
	public boolean containsInLastApprovedPermitByPermitVersionIdAndId(int permitVersionId, int permitInspectionId) {
		
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder.append("SELECT 1 FROM inspections.permit_versions_permit_inspections AS pv_pi ")
				.append("WHERE pv_pi.permit_inspection_id = :permitInspectionId ")
				.append("AND pv_pi.permit_inspector_version_id = ")
				.append("(SELECT FROM inspections.permit_versions AS pv ")
				.append("JOIN inspections.permit_links AS pl ")
				.append("ON pv.");

		@SuppressWarnings("unchecked")
		Query<Integer> query = (Query<Integer>) createNativeQuery(sqlBuilder.toString())
			.setMaxResults(1);
		query.setParameter("permitVersionId", permitVersionId)
			.setParameter("permitInspectionId", permitInspectionId);

		Integer result = query.uniqueResult();
		return result != null && result.intValue() > 0;
	}
}
