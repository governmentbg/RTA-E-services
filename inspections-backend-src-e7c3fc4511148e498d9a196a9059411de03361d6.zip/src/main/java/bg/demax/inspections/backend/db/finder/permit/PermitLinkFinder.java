package bg.demax.inspections.backend.db.finder.permit;

import java.util.Arrays;
import java.util.List;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.inspections.backend.entity.permit.PermitLink;
import bg.demax.techinsp.entity.PermitStatus;

@Repository
public class PermitLinkFinder extends AbstractFinder {

	public PermitLink findPermitLinkByPermitId(Integer permitId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM PermitLink p WHERE p.permit.id = :permitId");

		Query<PermitLink> query = createQuery(queryBuilder.toString(), PermitLink.class);

		return query.setParameter("permitId", permitId).uniqueResult();
	}

	public PermitLink findPermitLinkByPermitNumber(Integer permitNumber) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM PermitLink p WHERE p.lastApprovedVersion.permitInfo.permitNumber = :permitNumber");

		Query<PermitLink> query = createQuery(queryBuilder.toString(), PermitLink.class);

		return query.setParameter("permitNumber", permitNumber).uniqueResult();
	}
	
	public List<PermitLink> findAllValid() {
		StringBuilder queryBuilder = new StringBuilder();
		
		queryBuilder
			.append("SELECT pl FROM PermitLink pl ")
			.append("JOIN pl.permit.docStatus s ")
			.append("WHERE s.code IN(:statuses)");
		
		Query<PermitLink> query = createQuery(queryBuilder.toString(), PermitLink.class);
		query.setParameter("statuses", Arrays.asList(PermitStatus.VALID_CODE, PermitStatus.REVOKING_IN_PROCESS_CODE));
		return query.getResultList();
	}
	
	public List<PermitLink> findValidPermitsByInspectionTypeCode(String inspectionTypeCode) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT DISTINCT plink FROM PermitLink plink ")
			.append("JOIN plink.permit.docStatus s ")
			.append("JOIN plink.permit.permitLines pl ")
			.append("JOIN pl.inspectionTypes plit ")
			.append("JOIN plit.inspectionType it ")
			.append("WHERE s.code IN (:statuses) ")
			.append("AND pl.isValid = true ")
			.append("AND plit.isValid = true ")
			.append("AND it.code = :inspectionTypeCode");

		Query<PermitLink> query = createQuery(queryBuilder.toString(), PermitLink.class);
		query.setParameter("statuses", Arrays.asList(PermitStatus.VALID_CODE, PermitStatus.REVOKING_IN_PROCESS_CODE))
			.setParameter("inspectionTypeCode", inspectionTypeCode);

		return query.list();
	}
	
	public List<PermitLink> findValidCategoryLPermits() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT DISTINCT plink FROM PermitLink plink ")
			.append("JOIN plink.permit.docStatus s ")
			.append("JOIN plink.permit.permitLines pl ")
			.append("JOIN pl.categories plc ")
			.append("JOIN plc.vehicleCategory vc ")
			.append("WHERE s.code IN (:statuses) ")
			.append("AND pl.isValid = true ")
			.append("AND plc.isValid = true ")
			.append("AND vc.code LIKE 'L%'");

		Query<PermitLink> query = createQuery(queryBuilder.toString(), PermitLink.class);
		query.setParameter("statuses", Arrays.asList(PermitStatus.VALID_CODE, PermitStatus.REVOKING_IN_PROCESS_CODE));

		return query.list();
	}
}
