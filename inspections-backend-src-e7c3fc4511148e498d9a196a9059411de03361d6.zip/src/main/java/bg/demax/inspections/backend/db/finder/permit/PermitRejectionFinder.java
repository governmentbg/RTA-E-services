package bg.demax.inspections.backend.db.finder.permit;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;

@Repository
public class PermitRejectionFinder extends AbstractFinder {

	public byte[] findFileByPermitVersionId(int permitVersionId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT pr.file FROM PermitRejectionWithFile pr ")
					.append("JOIN pr.permitVersion pv ")
					.append("WHERE pv.id = :permitVersionId");

		Query<byte[]> query = createQuery(queryBuilder.toString(), byte[].class);
		query.setParameter("permitVersionId", permitVersionId);

		return query.uniqueResult();
	}
}
