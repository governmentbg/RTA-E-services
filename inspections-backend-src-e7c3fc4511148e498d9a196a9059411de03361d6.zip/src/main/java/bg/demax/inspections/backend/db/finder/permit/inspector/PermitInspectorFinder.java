package bg.demax.inspections.backend.db.finder.permit.inspector;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorStampType;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorVersion;
import bg.demax.inspections.backend.enums.TechinspPermitInspectorStampStatus;
import bg.demax.inspections.backend.search.PermitInspectorReportSearch;
import bg.demax.inspections.backend.search.PermitInspectorSearch;
import bg.demax.techinsp.entity.PermitInspector;
import bg.demax.techinsp.entity.PermitInspectorStatus;
import bg.demax.techinsp.entity.PermitStatus;

@Repository
public class PermitInspectorFinder extends AbstractFinder {
	
	@Autowired
	private GenericSearchSupport searchSupport;
	
	@Autowired
	private PagingAndSortingSupport pagingSupport;

	public List<PermitInspectorVersion> findAllValidPermitInspectorsForValidPermits() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT i FROM PermitLink pl ")
					.append("JOIN pl.lastApprovedVersion p ")
					.append("JOIN p.inspectors i ")
					.append("WHERE p.status.code = :permitStatus AND i.currentStatus = :inspectorStatus");
		
				
		Query<PermitInspectorVersion> query = createQuery(queryBuilder.toString(), PermitInspectorVersion.class);
		query.setParameter("permitStatus", PermitStatus.VALID_CODE)
			.setParameter("inspectorStatus", PermitInspectorStatus.INCLUDED.getCode());
		return query.list();
	}

	public List<PermitInspector> findPermitInspectorsBySearch(PermitInspectorSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT pi FROM PermitInspector pi ")
					.append("JOIN pi.subjectVersion sv ")
					.append("JOIN pi.permit p ")
					.append("JOIN p.orgUnit ou ")
					.append("LEFT JOIN sv.firstNameCyr firstNameCyr ")
					.append("LEFT JOIN sv.surnameCyr surnameCyr ")
					.append("LEFT JOIN sv.familyNameCyr familyNameCyr ");
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString += " ORDER BY coalesce (sv.fullName, concat(firstNameCyr.original, surnameCyr.original, familyNameCyr.original)) ASC ";
				
		Query<PermitInspector> query = createQuery(queryString, PermitInspector.class);
		
		return query.setProperties(search).setMaxResults(50).getResultList();
	}
	
	public List<PermitInspector> findIncludedWithAdrStampByPermitId(int permitId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT pi FROM PermitInspector pi ")
					.append("JOIN pi.permit p ")
					.append("JOIN pi.stamps s ")
					.append("WHERE s.stampType = :stampType ")
					.append("AND s.status = :stampStatus ")
					.append("AND pi.currentStatus = :inspectorStatus ")
					.append("AND p.id = :permitId");
				
		Query<PermitInspector> query = createQuery(queryBuilder.toString(), PermitInspector.class);
		query
			.setParameter("stampType", PermitInspectorStampType.ADR_STAMP_ID)
			.setParameter("stampStatus", TechinspPermitInspectorStampStatus.VALID_CODE)
			.setParameter("inspectorStatus", PermitInspectorStatus.INCLUDED.getCode())
			.setParameter("permitId", permitId);
		
		return query.list();
	}
	
	public List<PermitInspectorVersion> findVersionsByPermitVersionId(int permitVersionId, PageRequest pageRequest) {		
		
		String queryString = pagingSupport.applySorting("SELECT * " + buildBeginQuery(), pageRequest);
		Query<PermitInspectorVersion> query = createNativeQuery(queryString, PermitInspectorVersion.class);
		pagingSupport.applyPaging(query, pageRequest);	
		
		return query.setParameter("permitVersionId", permitVersionId).getResultList();
	}
	
	public int countVersionsByPermitVersionId(int permitVersionId) {
		String queryString = "SELECT COUNT(piv.id) " + buildBeginQuery();
		
		return ((Number) createNativeQuery(queryString).setParameter("permitVersionId", permitVersionId).getSingleResult()).intValue();
	}
	
	public List<PermitInspectorVersion> findVersionsBySubjectId(long subjectId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT pi FROM PermitInspectorVersion pi ")
					.append("JOIN pi.subjectVersion sv ")
					.append("JOIN sv.subject s ")
					.append("WHERE s.id = :subjectId ");
				
		Query<PermitInspectorVersion> query = createQuery(queryBuilder.toString(), PermitInspectorVersion.class);
		
		return query.setParameter("subjectId", subjectId).getResultList();
	}
	
	public boolean containsInPermitVersion(int permitVersionId, int inspectorVersionId) {
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder.append("SELECT 1 FROM inspections.permit_versions_permit_inspector_versions AS pv_piv ")
				.append("WHERE pv_piv.permit_version_id = :permitVersionId ")
				.append("AND pv_piv.permit_inspector_version_id = :inspectorVersionId");

		@SuppressWarnings("unchecked")
		Query<Integer> query = (Query<Integer>) createNativeQuery(sqlBuilder.toString())
			.setMaxResults(1);
		query.setParameter("permitVersionId", permitVersionId)
			.setParameter("inspectorVersionId", inspectorVersionId);

		Integer result = query.uniqueResult();
		return result != null && result.intValue() > 0;
	}
	
	public boolean containsInLastApprovedPermitVersion(int permitVersionId, int inspectorVersionId) {		
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder
			.append("SELECT 1 FROM inspections.permit_versions_permit_inspector_versions AS pv_piv ")
			.append("WHERE pv_piv.permit_version_id = ")
			.append("(SELECT pl.last_approved_version_id FROM inspections.permit_links AS pl ")
			.append("WHERE pl.id = ")
			.append("(SELECT pv.permit_link_id FROM inspections.permit_versions AS pv ")
			.append("WHERE pv.id = :permitVersionId)) ")
			.append("AND pv_piv.permit_inspector_version_id = :inspectorVersionId");

		@SuppressWarnings("unchecked")
		Query<Integer> query = (Query<Integer>) createNativeQuery(sqlBuilder.toString())
			.setMaxResults(1);
		query.setParameter("permitVersionId", permitVersionId)
			.setParameter("inspectorVersionId", inspectorVersionId);

		Integer result = query.uniqueResult();
		return result != null && result.intValue() > 0;
	}

	public PermitInspectorVersion findByPermitVersionIdAndSubjectId(int permitVersionId, long subjectId) {		
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder
			.append("SELECT piv FROM PermitVersion AS pv ")
			.append("JOIN pv.inspectors AS piv ")
			.append("JOIN piv.subjectVersion AS sv ")
			.append("JOIN sv.subject AS s ")
			.append("WHERE pv.id = :permitVersionId ")
			.append("AND s.id = :subjectId");

		Query<PermitInspectorVersion> query = createQuery(sqlBuilder.toString(), PermitInspectorVersion.class);
		query.setParameter("permitVersionId", permitVersionId)
			.setParameter("subjectId", subjectId);

		return query.uniqueResult();
	}
	
	public Short findLastOrderNumberByPermitVersionId(int permitVersionId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT pii.orderNumber FROM PermitVersion pv ")
			.append("JOIN pv.inspectors AS piv ")
			.append("JOIN piv.permitInspectorInfo AS pii ")
			.append("WHERE pv.id = :permitVersionId ")
			.append("ORDER BY pii.orderNumber DESC ");
		
		@SuppressWarnings("unchecked")
		Query<Short> query = (Query<Short>) createQuery(queryBuilder.toString());
		query.setParameter("permitVersionId", permitVersionId);
		query.setMaxResults(1);
		
		return query.uniqueResult();
	}
	
	public List<PermitInspectorVersion> findPermitInspectorsForReportBySearch(PermitInspectorReportSearch search, PageRequest pageRequest) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT DISTINCT piv ").append(buildBeginForReportQuery(search))
					.append(" ORDER BY piv.id DESC");

		Query<PermitInspectorVersion> query = createQuery(queryBuilder.toString(), PermitInspectorVersion.class);
		pagingSupport.applyPaging(query, pageRequest);
		return query.setProperties(search).list();
	}
	
	public List<PermitInspectorVersion> findPermitInspectorsForReportBySearch(PermitInspectorReportSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT DISTINCT piv ").append(buildBeginForReportQuery(search));
		Query<PermitInspectorVersion> query = createQuery(queryBuilder.toString(), PermitInspectorVersion.class);
		return query.setProperties(search).list();
	}
	
	public int countPermitInspectorsForReportBySearch(PermitInspectorReportSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT COUNT (DISTINCT piv.id) ").append(buildBeginForReportQuery(search));
		Query<Number> query = createQuery(queryBuilder.toString(), Number.class).setProperties(search);
		
		Number count = query.uniqueResult();
		return count == null ? 0 : count.intValue();
	}
	
	public int countSubjectIsChairman(long subjectId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT COUNT(pi) FROM PermitInspector pi ")
			.append("JOIN pi.subject AS s ")
			.append("WHERE s.id = :subjectId ")
			.append("AND pi.isChairman = true");

		Number count = createQuery(queryBuilder.toString(), Number.class).setParameter("subjectId", subjectId).uniqueResult();
		return count == null ? 0 : count.intValue();
	}
	
	private String buildBeginQuery() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("FROM inspections.permit_inspector_versions AS piv ")
			.append("INNER JOIN inspections.permit_versions_permit_inspector_versions AS pv_piv ")
			.append("ON pv_piv.permit_inspector_version_id = piv.id ")
			.append("INNER JOIN inspections.permit_inspector_infos AS pivi ")
			.append("ON pivi.id = piv.permit_inspector_info_id ")
			.append("WHERE pv_piv.permit_version_id = :permitVersionId ");
		
		return queryBuilder.toString();
	}
	
	private String buildBeginForReportQuery(PermitInspectorReportSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("FROM PermitVersion pv ")
			.append("JOIN pv.permitInfo pi ")
			.append("JOIN pv.inspectors piv ")
			.append("JOIN piv.certifications cert ")
			.append("JOIN cert.course c ")
			.append("JOIN c.educationCategory ec ")
			.append("JOIN ec.inspectionTypes inspectionType ");
		
		if (search.getHasCardConstraint() != null) {
			queryBuilder.append("LEFT JOIN SubjectCard card ON piv.subjectVersion.subject = card.subject ");
		}
		
		return searchSupport.addSearchConstraints(queryBuilder.toString(), search);
	}

}
