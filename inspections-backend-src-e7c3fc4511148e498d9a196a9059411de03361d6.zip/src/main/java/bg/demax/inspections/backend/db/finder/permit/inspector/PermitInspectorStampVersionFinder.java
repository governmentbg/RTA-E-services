package bg.demax.inspections.backend.db.finder.permit.inspector;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorStampVersion;

@Repository
public class PermitInspectorStampVersionFinder extends AbstractFinder {

	public PermitInspectorStampVersion findStampVersionByIdAndInspectorAndPermit(int permitVersionId,
			int permitInspectorVersionId, int attachmentId) {
		StringBuilder hqlBuilder = new StringBuilder();

		hqlBuilder.append("SELECT a FROM PermitVersion p JOIN p.inspectors i JOIN i.")
				.append("stamps a ")
				.append("WHERE p.id = :permitVersionId ")
				.append("AND i.id = :permitInspectorVersionId ")
				.append("AND a.id = :attatchmentId");

		Query<PermitInspectorStampVersion> query = createQuery(hqlBuilder.toString(),
				PermitInspectorStampVersion.class);

		return query.setParameter("permitVersionId", permitVersionId)
				.setParameter("permitInspectorVersionId", permitInspectorVersionId)
				.setParameter("attatchmentId", attachmentId).uniqueResult();
	}

	public PermitInspectorStampVersion findExistingStampVersionByPermitAndStampNumber(int permitVersionId, int permitInspectorVersionId,
			String stampNumber) {
		StringBuilder hqlBuilder = new StringBuilder();

		hqlBuilder.append("SELECT a FROM PermitVersion p JOIN p.inspectors i JOIN i.")
				.append("stamps a ")
				.append("WHERE p.id = :permitVersionId ")
				.append("AND i.id != :permitInspectorVersionId ")
				.append("AND a.stampNumber = :stampNumber");

		Query<PermitInspectorStampVersion> query = createQuery(hqlBuilder.toString(),
				PermitInspectorStampVersion.class);

		return query.setParameter("permitVersionId", permitVersionId)
					.setParameter("permitInspectorVersionId", permitInspectorVersionId)
					.setParameter("stampNumber", stampNumber)
					.uniqueResult();
	}

	public List<PermitInspectorStampVersion> findPermitInspectorStampVersionByPermitAndStampNumber(int permitVersionId, 
			int permitInspectorVersionId, String stampNumber) {
		StringBuilder hqlBuilder = new StringBuilder();

		hqlBuilder.append("SELECT a FROM PermitVersion p JOIN p.inspectors i JOIN i.")
				.append("stamps a ")
				.append("WHERE p.id = :permitVersionId ")
				.append("AND i.id = :permitInspectorVersionId ")
				.append("AND a.stampNumber = :stampNumber ORDER BY a.id DESC");

		Query<PermitInspectorStampVersion> query = createQuery(hqlBuilder.toString(),
				PermitInspectorStampVersion.class);

		return query.setParameter("permitVersionId", permitVersionId)
					.setParameter("permitInspectorVersionId", permitInspectorVersionId)
					.setParameter("stampNumber", stampNumber)
					.list();
	}

}
