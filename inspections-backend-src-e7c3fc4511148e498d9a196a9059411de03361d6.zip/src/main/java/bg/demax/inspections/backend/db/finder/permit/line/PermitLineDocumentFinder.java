package bg.demax.inspections.backend.db.finder.permit.line;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.entity.permit.line.PermitLineDocumentExt;
import bg.demax.inspections.backend.entity.permit.line.PermitLineDocumentVersion;
import bg.demax.inspections.backend.search.DashboardPermitLineDocumentsReportSearch;
import bg.demax.inspections.backend.search.PermitLineDocumentsReportSearch;
import bg.demax.inspections.backend.util.PermitReportUtil;

@Repository
public class PermitLineDocumentFinder extends AbstractFinder {

	@Autowired
	private PagingAndSortingSupport pagingSupport;

	@Autowired
	private GenericSearchSupport searchSupport;

	public List<PermitLineDocumentVersion> getPermitLineDocumentsByPermitLineVersionId(int permitLineVersionId,
			PageRequest pageRequest) {
		String queryString = "SELECT * " + beginQuery();
		queryString = pagingSupport.applySorting(queryString, pageRequest);
		Query<PermitLineDocumentVersion> query = createNativeQuery(queryString, PermitLineDocumentVersion.class);
		pagingSupport.applyPaging(query, pageRequest);
		query.setParameter("permitLineVersionId", permitLineVersionId);

		return query.getResultList();
	}

	public List<PermitLineDocumentExt> findByExtAndStatusExpired() {
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("SELECT pve FROM PermitLineDocumentExt AS pve ")
				.append("JOIN pve.lastVersion lv ")
				.append("JOIN lv.status ps ")
				.append("WHERE ps.code = 'EXPIRED' ");

		Query<PermitLineDocumentExt> query = createQuery(queryBuilder.toString(), PermitLineDocumentExt.class);


		return query.list();
	}

	public PermitLineDocumentVersion findByPermitIdAndLineIdAndDocumentId(int permitVersionId, int permitLineVersionId,
			int permitLineDocumentId) {
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("SELECT pldv FROM PermitVersion AS pv ")
					.append("JOIN pv.permitLines AS plv ")
					.append("JOIN plv.documentVersions AS pldv ")
					.append("JOIN FETCH pldv.document AS pld ")
					.append("WHERE pv.id = :permitVersionId ")
					.append("AND plv.id = :permitLineVersionId ")
					.append("AND pldv.id = :permitLineDocumentId");

		Query<PermitLineDocumentVersion> query = createQuery(queryBuilder.toString(), PermitLineDocumentVersion.class);

		query.setParameter("permitVersionId", permitVersionId).setParameter("permitLineVersionId", permitLineVersionId)
				.setParameter("permitLineDocumentId", permitLineDocumentId);

		return query.uniqueResult();
	}

	public int countPermitLineDocumentByPermitLineVersionId(int permitLineVersionId) {
		String queryString = "SELECT COUNT(docs.id) " + beginQuery();

		return ((Number) createNativeQuery(queryString).setParameter("permitLineVersionId", permitLineVersionId)
				.getSingleResult()).intValue();
	}

	public List<PermitLineDocumentExt> findPermitLineDocumentsForReportBySearch(PermitLineDocumentsReportSearch search,
			PageRequest pageRequest, long days) {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT pldx ").append(beginSearchQueryStringForReport(search))
				.append(" ORDER BY permit.permitNumber DESC");

		Query<PermitLineDocumentExt> query = createQuery(builder.toString(), PermitLineDocumentExt.class);
		pagingSupport.applyPaging(query, pageRequest);

		
		if (search.getStatusCode() != null && (search.getStatusCode().equals(PermitReportUtil.DOC_EXPIRING_CODE)
				|| search.getStatusCode().equals(PermitReportUtil.DOC_VALID_CODE))) {
			query.setParameter("dueDate", LocalDate.now().plusDays(days));
		}
		return query.setProperties(search).list();
	}

	public List<PermitLineDocumentExt> findPermitLineDocumentsForReportBySearch(PermitLineDocumentsReportSearch search,
			long days) {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT pldx ").append(beginSearchQueryStringForReport(search))
				.append(" ORDER BY permit.permitNumber DESC");

		Query<PermitLineDocumentExt> query = createQuery(builder.toString(), PermitLineDocumentExt.class);
		
		if (search.getStatusCode() != null && (search.getStatusCode().equals(PermitReportUtil.DOC_EXPIRING_CODE)
				|| search.getStatusCode().equals(PermitReportUtil.DOC_VALID_CODE))) {
			query.setParameter("dueDate", LocalDate.now().plusDays(days));
		}
		return query.setProperties(search).list();
	}

	public int findCountPermitLineDocumentsForReportBySearch(PermitLineDocumentsReportSearch search,
			long days) {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT COUNT(plad.id) ").append(beginSearchQueryStringForReport(search));
		Query<Number> query = createQuery(builder.toString(), Number.class).setProperties(search);
		
		if (search.getStatusCode() != null && (search.getStatusCode().equals(PermitReportUtil.DOC_EXPIRING_CODE)
				|| search.getStatusCode().equals(PermitReportUtil.DOC_VALID_CODE))) {
			query.setParameter("dueDate", LocalDate.now().plusDays(days));
		}
		Number count = query.uniqueResult();
		return count == null ? 0 : count.intValue();
	}

	private String beginQuery() {
		StringBuilder builder = new StringBuilder();
		builder.append("FROM inspections.permit_line_document_versions as docs ");
		builder.append("JOIN techinsp.permit_line_appl_docs as plad ON docs.document_id = plad.id ");
		builder.append("WHERE docs.id IN ");
		builder.append("(SELECT plv_pld.permit_line_document_version_id ");
		builder.append("FROM inspections.permit_line_versions_permit_line_document_versions AS plv_pld ");
		builder.append("WHERE plv_pld.permit_line_version_id = :permitLineVersionId)");

		return builder.toString();
	}

	private String beginSearchQueryStringForReport(PermitLineDocumentsReportSearch search) {
		StringBuilder builder = new StringBuilder();
		builder.append("FROM PermitLineDocumentExt pldx ")
				.append("JOIN pldx.document plad ")
				.append("JOIN pldx.lastVersion pldv ")
				.append("JOIN plad.permitLine pline ")
				.append("JOIN pline.permit permit ")
				.append("JOIN plad.type type ")
				.append("WHERE permit.permitNumber IS NOT NULL ")
				.append("AND pline.isValid = TRUE ");
		return searchSupport.addSearchConstraints(builder.toString(), search);
	}

	public List<PermitLineDocumentVersion> findAllPermitLineDocumentsDashboard(DashboardPermitLineDocumentsReportSearch search,
			long days) {
		StringBuilder builder = new StringBuilder();
		builder.append("SELECT dv ").append(beginSearchQueryStringForDashboardLines(search))
				.append(" ORDER BY pi.permitNumber DESC");

		Query<PermitLineDocumentVersion> query = createQuery(builder.toString(), PermitLineDocumentVersion.class);
		
		if (search.getStatusCode() != null && (search.getStatusCode().equals(PermitReportUtil.DOC_EXPIRING_CODE)
				|| search.getStatusCode().equals(PermitReportUtil.DOC_VALID_CODE))) {
			query.setParameter("dueDate", LocalDate.now().plusDays(days));
		}
		return query.setProperties(search).list();
	}

	private String beginSearchQueryStringForDashboardLines(DashboardPermitLineDocumentsReportSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("FROM PermitLink pl ")
			.append("JOIN pl.lastApprovedVersion pv ")
			.append("JOIN pv.permitInfo pi ")
			.append("JOIN pi.orgUnit ou ")
			.append("JOIN pv.status s ")
			.append("JOIN pv.permitLines pvl ")
			.append("JOIN pvl.documentVersions dv ")
			.append("JOIN dv.status dvs ")
			.append("JOIN dv.document d ")
			.append("JOIN d.type t ")
			.append("WHERE t.isPeriodically = TRUE ")
			.append("AND t.isOptional = FALSE ")
			.append("AND t.isValid = TRUE ")
			.append("AND t.requiredFor = 'L' ");
		return searchSupport.addSearchConstraints(queryBuilder.toString(), search);
	}

	public int getCountOfNewerValidDocuments(LocalDate validAfter, Integer permitLineId, Short code) {
		StringBuilder builder = new StringBuilder();

		builder.append("SELECT COUNT(pld.id) ")
			.append("FROM PermitLineDocumentExt pldx ")
			.append("JOIN pldx.document pld ")
			.append("JOIN pld.permitLine pline ")
			.append("JOIN pld.type type ")
			.append("JOIN pldx.lastVersion lv ")
			.append("JOIN lv.status s ")
			.append("WHERE type.code = :docType ")
			.append("AND pline.id = :lineId ")
			.append("AND pld.validTo > :dueDate AND pld.isApproved = 'Y' ")
			.append("AND s.code = 'VALID'");
		Query<Number> query = createQuery(builder.toString(), Number.class);
		
		
		query.setParameter("dueDate", validAfter);
		query.setParameter("lineId", permitLineId);
		query.setParameter("docType", code);
		
		Number count = query.uniqueResult();
		return count == null ? 0 : count.intValue();
	}
}
