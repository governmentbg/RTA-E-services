package bg.demax.inspections.backend.db.finder.permit.line;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.entity.permit.line.PermitLineVersion;
import bg.demax.inspections.backend.search.PermitLineDiagnosticSearch;
import bg.demax.inspections.backend.search.PermitLineReportSearch;
import bg.demax.techinsp.entity.PermitLine;
import bg.demax.techinsp.entity.PermitStatus;

@Repository
public class PermitLineFinder extends AbstractFinder {

	@Autowired
	private PagingAndSortingSupport pagingSupport;

	@Autowired
	private GenericSearchSupport searchSupport;


	public List<PermitLineVersion> findAllValidPermitLinesForValidPermits() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT l FROM PermitLink pl ")
					.append("JOIN pl.lastApprovedVersion p ")
					.append("JOIN p.permitLines l ")
					.append("WHERE p.status.code = :permitStatus");
		
				
		Query<PermitLineVersion> query = createQuery(queryBuilder.toString(), PermitLineVersion.class);
		query.setParameter("permitStatus", PermitStatus.VALID_CODE);
		return query.list();
	}

	public List<PermitLine> findPermitLinesConnectivityBySearch(PermitLineDiagnosticSearch search,
			PageRequest pageRequest) {

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT DISTINCT permitLine FROM PermitLine permitLine ")
				.append("JOIN permitLine.permit permit ")
				.append("JOIN permit.orgUnit orgUnit ")
				.append("LEFT JOIN permitLine.connectivityStatuses connStatuses ")
				.append("LEFT JOIN permitLine.camPositions camPositions ");
			
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString += " ORDER BY permitLine.permit ";
		Query<PermitLine> query = createQuery(queryString, PermitLine.class);
		pagingSupport.applyPaging(query, pageRequest);
		return query.setProperties(search)
					.getResultList();
	}

	public Integer countPermitLinesWithConnectivityBySearch(PermitLineDiagnosticSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT COUNT(DISTINCT permitLine.id) FROM PermitLine permitLine ")
				.append("JOIN permitLine.permit permit ")
				.append("JOIN permit.orgUnit orgUnit ")
				.append("LEFT JOIN permitLine.connectivityStatuses connStatuses ")
				.append("LEFT JOIN permitLine.camPositions camPositions ");
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);

		Number count = createQuery(queryString, Number.class).setProperties(search).uniqueResult();
		return count == null ? 0 : count.intValue();
	}
	
	public List<PermitLine> findPermitLinesByPermitId(Integer permitId) {
		String hql = "FROM PermitLine pl WHERE pl.permit.id = :permitId ORDER BY pl.number asc";
		return createQuery(hql, PermitLine.class).setParameter("permitId", permitId).getResultList();
	}
	
	public List<PermitLineVersion> findVersionsByPermitVersionId(int permitVersionId, PageRequest pageRequest) {		
		
		String queryString = pagingSupport.applySorting("SELECT * " + buildBeginQuery(), pageRequest);	
		Query<PermitLineVersion> query = createNativeQuery(queryString, PermitLineVersion.class);
		pagingSupport.applyPaging(query, pageRequest);	
		query = query.setParameter("permitVersionId", permitVersionId);
		
		return query.getResultList();
	}
	
	public int countVersionsByPermitVersionId(int permitVersionId) {
		String queryString = "SELECT COUNT(plv.id) " + buildBeginQuery();
		
		return ((Number) createNativeQuery(queryString).setParameter("permitVersionId", permitVersionId).getSingleResult()).intValue();
	}
	
	public Short findLastLineNumberByPermitVersionId(int permitVersionId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT plv.line_number FROM inspections.permit_line_versions AS plv ")
			.append("INNER JOIN inspections.permit_versions_permit_line_versions AS pv_plv ")
			.append("ON pv_plv.permit_line_version_id = plv.id ")
			.append("WHERE pv_plv.permit_version_id = :permitVersionId ")
			.append("ORDER BY plv.line_number DESC LIMIT 1");
		
		@SuppressWarnings("unchecked")
		Query<Short> query = (Query<Short>) createNativeQuery(queryBuilder.toString());
		query = query.setParameter("permitVersionId", permitVersionId);
		
		return query.uniqueResult();
	}
	
	public PermitLineVersion findByPermitLineVersionIdAndPermitVersionId(int permitLineVersionId, int permitVersionId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT * FROM inspections.permit_line_versions AS plv ")
			.append("WHERE plv.id = ")
			.append("(SELECT permit_line_version_id FROM inspections.permit_versions_permit_line_versions AS pv_plv ")
			.append("WHERE pv_plv.permit_version_id = :permitVersionId ")
			.append("AND pv_plv.permit_line_version_id = :permitLineVersionId)");

		Query<PermitLineVersion> query = createNativeQuery(queryBuilder.toString(), PermitLineVersion.class);
		query = query
				.setParameter("permitLineVersionId", permitLineVersionId)
				.setParameter("permitVersionId", permitVersionId);

		return query.uniqueResult();
	}
	
	public boolean containsInLastApprovedPermitVersion(int permitVersionId, int permitLineVersionId) {		
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder
			.append("SELECT 1 FROM inspections.permit_versions_permit_line_versions AS pv_plv ")
			.append("WHERE pv_plv.permit_version_id = ")
			.append("(SELECT pl.last_approved_version_id FROM inspections.permit_links AS pl ")
			.append("WHERE pl.id = ")
			.append("(SELECT pv.permit_link_id FROM inspections.permit_versions AS pv ")
			.append("WHERE pv.id = :permitVersionId)) ")
			.append("AND pv_plv.permit_line_version_id = :permitLineVersionId");

		@SuppressWarnings("unchecked")
		Query<Integer> query = (Query<Integer>) createNativeQuery(sqlBuilder.toString())
			.setMaxResults(1);
		query.setParameter("permitVersionId", permitVersionId)
			.setParameter("permitLineVersionId", permitLineVersionId);

		Integer result = query.uniqueResult();
		return result != null && result.intValue() > 0;
	}
	
	public List<PermitLine> findPermitLinesNotContainedInOtherVersion(int permitVersionId, int otherPermitVersionId) {
		StringBuilder queryBuilder = new StringBuilder();
		
		queryBuilder.append("SELECT pl FROM PermitLine AS pl ")
					.append("WHERE pl.id IN ")
					.append("(SELECT pl.id FROM PermitVersion AS pv ")
					.append("JOIN pv.permitLines AS plv ")
					.append("JOIN plv.permitLine AS pl ")
					.append("WHERE pv.id = :permitVersionId ")
					.append("AND pl.id NOT IN ")
					.append("(SELECT pl.id FROM PermitVersion AS pv ")
					.append("JOIN pv.permitLines AS plv ")
					.append("JOIN plv.permitLine AS pl ")
					.append("WHERE pv.id = :otherPermitVersionId))");
		
		Query<PermitLine> query = createQuery(queryBuilder.toString(), PermitLine.class);
		query.setParameter("permitVersionId", permitVersionId)
			.setParameter("otherPermitVersionId", otherPermitVersionId);
		
		return query.list();
	}
	
	public List<Integer> findMaxNumberOfPermitLinesForAllPermits() {
		StringBuilder queryBuilder = new StringBuilder();
		
		ArrayList<Integer> list = new ArrayList<Integer>();
		
		queryBuilder.append("SELECT DISTINCT count(permit_id) FROM techinsp.permit_lines group by permit_id");
		@SuppressWarnings("unchecked")
		List<Number> result = (List<Number>) createNativeQuery(queryBuilder.toString()).list();
		
		for (Number obj: result) {
			list.add(obj.intValue());
		}
		Collections.sort(list);
		
		return list;
	}
	
	public List<PermitLineVersion> findByReportSearch(PermitLineReportSearch search, PageRequest pageRequest) {

		String queryString = buildReportSearchQuery(search, "SELECT lines.* ");	
		
		Query<PermitLineVersion> query = createNativeQuery(queryString, PermitLineVersion.class);		
		pagingSupport.applyPaging(query, pageRequest);	
		
		query.setProperties(search);
		
		return query.list();
	}
	
	public List<PermitLineVersion> findByReportSearch(PermitLineReportSearch search) {

		String queryString = buildReportSearchQuery(search, "SELECT lines.* ");	
		
		Query<PermitLineVersion> query = createNativeQuery(queryString, PermitLineVersion.class);		
		
		query.setProperties(search);
		
		return query.list();
	}
	
	public int countByReportSearch(PermitLineReportSearch search) {
		String queryString = buildReportSearchQuery(search, "SELECT COUNT(lines.id) ");	
		
		@SuppressWarnings("unchecked")
		Query<Number> query = (Query<Number>) createNativeQuery(queryString);	
		query.setProperties(search);
		
		Number result = query.uniqueResult();
		
		return result == null ? 0 : result.intValue();
	}
	
	private String buildBeginQuery() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("FROM inspections.permit_line_versions AS plv ")
			.append("INNER JOIN inspections.permit_versions_permit_line_versions AS pv_plv ")
			.append("ON pv_plv.permit_line_version_id = plv.id ")
			.append("WHERE pv_plv.permit_version_id = :permitVersionId ");
		
		return queryBuilder.toString();
	}
	
	
	private String buildReportSearchQuery(PermitLineReportSearch search, String selectString) {
		StringBuilder withBuilder = new StringBuilder();
		StringBuilder mainBuilder = new StringBuilder();
		
		withBuilder
			.append("WITH lines AS (")
			.append("SELECT lines.*, pv.subject_version_id AS sv_id, pv.permit_info_id AS pi_id FROM inspections.permit_links AS pl ")
			.append("JOIN inspections.permit_versions AS pv ")
			.append("ON pl.last_approved_version_id = pv.id ")
			.append("JOIN inspections.permit_versions_permit_line_versions AS pv_plv ")
			.append("ON pv_plv.permit_version_id = pv.id ")
			.append("JOIN inspections.permit_line_versions AS lines ")
			.append("ON lines.id = pv_plv.permit_line_version_id ")
			.append("WHERE pv.status IN (:permitStatuses)) ");
		
		mainBuilder.append(selectString).append(" FROM lines ");
		if (search.getOrgUnits() != null || search.getPermitNumber() != null) {
			mainBuilder
				.append("JOIN inspections.permit_infos AS pi ")
				.append("ON pi.id = lines.pi_id ");
		}
		if (search.getIdentityNumber() != null) {
			mainBuilder
				.append("JOIN public.subj_versions AS sv ")
				.append("ON sv.id = lines.sv_id ")
				.append("JOIN public.subjects AS subject ")
				.append("ON subject.id = sv.subj_id ");
		}
		
		withBuilder.append(searchSupport.addSearchConstraints(mainBuilder.toString(), search));
		
		return withBuilder.toString();
	}
}
