package bg.demax.inspections.backend.db.finder.permit.line;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.pub.entity.hardware.PermitLineHardware;

@Repository
public class PermitLineHardwareFinder extends AbstractFinder {
	
	public PermitLineHardware findPermitLineHardwareByPermitLineId(int permitLineId) {
		StringBuilder builder = new StringBuilder();
		builder.append("FROM PermitLineHardware as plh WHERE plh.permitLine.id = :permitLineId ORDER BY plh.id DESC");
		Query<PermitLineHardware> query = createQuery(builder.toString(), PermitLineHardware.class);
		query.setParameter("permitLineId", permitLineId);
		List<PermitLineHardware> result = query.getResultList();
		if (result.isEmpty()) {
			return null;
		} else {
			return result.get(0);
		}
	}

}
