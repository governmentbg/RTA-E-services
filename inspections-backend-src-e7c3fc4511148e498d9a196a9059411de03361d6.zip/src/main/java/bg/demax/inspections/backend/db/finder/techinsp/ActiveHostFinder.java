package bg.demax.inspections.backend.db.finder.techinsp;

import java.time.LocalDateTime;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.pub.entity.ActiveHost;
import bg.demax.pub.entity.ApplicationType;

@Repository
public class ActiveHostFinder extends AbstractFinder {
	public static final long MAX_MINUTES_SINCE_LAST_ACTIVE_HOST_ACTIVITY = 20L;
	
	public ActiveHost findLastActiveHostByInspectionId(long inspectionId) {
		String queryString = "SELECT ah FROM ActiveHost ah WHERE appCode = :appCode "
				+ "AND inspId = :inspectionId "
				+ "AND lastActivity >= :lastActivity "
				+ "ORDER BY lastActivity desc";
		
		Query<ActiveHost> query = createQuery(queryString, ActiveHost.class);
		query.setParameter("appCode", ApplicationType.CODE_TECHNICAL_INSPECTIONS);
		query.setParameter("inspectionId", inspectionId);
		query.setParameter("lastActivity", LocalDateTime.now().minusMinutes(MAX_MINUTES_SINCE_LAST_ACTIVE_HOST_ACTIVITY));
		query.setMaxResults(1);
		
		return query.uniqueResult();
	}
	
	public int countActiveHostsWithDevSnAndMaxSecondsSinceLastActivity(String hardwareSerialNumber, long seconds) {
		LocalDateTime lastActivityFilter = LocalDateTime.now().minusSeconds(seconds);
		
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count (ah) FROM ActiveHost ah WHERE ")
				.append("ah.devSn = :devSn AND ")
				.append("ah.lastActivity >= :lastActivityFilter AND ")
				.append("ah.appCode = :appCode ");
		
		
		Query<Number> query = createQuery(queryBuilder.toString(), Number.class);
		query.setParameter("devSn", hardwareSerialNumber);
		query.setParameter("lastActivityFilter", lastActivityFilter);
		query.setParameter("appCode", ApplicationType.CODE_TECHNICAL_INSPECTIONS);
		
		Number count = query.uniqueResult();
		
		return count == null ? 0 : count.intValue();
	}

}
