package bg.demax.inspections.backend.db.finder.techinsp;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.pub.entity.CamRequest;
import bg.demax.pub.entity.CamRequest.CamRequestCode;

@Repository
public class CamRequestFinder extends AbstractFinder {
	
	public CamRequest getIdleCamRequest(int resolution) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT cr FROM CamRequest cr ")
					.append("WHERE activeHost is null ")
					.append("and reqCode = :reqCodeClosed ")
					.append("and id.resolution = :resolution");
		
		Query<CamRequest> query = this.<CamRequest>createQuery(queryBuilder.toString(), CamRequest.class);
		query.setParameter("reqCodeClosed", CamRequestCode.CLOSED);
		query.setParameter("resolution", resolution);
		
		query.setMaxResults(1);
		
		return query.uniqueResult();
	}
	
	public List<CamRequest> getNotClosedCamRequests() {
		String queryStr = "SELECT cr FROM CamRequest cr WHERE reqCode != :reqCode";
		
		Query<CamRequest> query = createQuery(queryStr, CamRequest.class);
		query.setParameter("reqCode", CamRequestCode.CLOSED);
		
		return query.getResultList();
	}
}
