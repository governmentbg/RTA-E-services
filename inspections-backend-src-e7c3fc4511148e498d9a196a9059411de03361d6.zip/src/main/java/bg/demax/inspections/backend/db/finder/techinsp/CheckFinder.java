package bg.demax.inspections.backend.db.finder.techinsp;

import java.util.List;

import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.inspections.backend.entity.vehicletax.Check;
import bg.demax.techinsp.entity.Inspection;

@Repository
public class CheckFinder extends AbstractFinder {

	public List<Check> findAllByInspection(Inspection inspection) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM Check check ")
					.append("WHERE check.inspection = :inspection ")
					.append("ORDER BY check.id DESC ");
		return createQuery(queryBuilder.toString(), Check.class)
						.setParameter("inspection", inspection)
						.list();
	}
}
