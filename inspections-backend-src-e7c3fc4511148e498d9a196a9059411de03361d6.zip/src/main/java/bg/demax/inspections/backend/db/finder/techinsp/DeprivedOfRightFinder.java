package bg.demax.inspections.backend.db.finder.techinsp;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.inspections.backend.entity.techinsp.DeprivedOfRight;

@Repository
public class DeprivedOfRightFinder extends AbstractFinder {

	public DeprivedOfRight findBySubjectId(long subjectId) {
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("FROM DeprivedOfRight d WHERE d.subject.id = :id AND d.recoveryDate > now() ORDER BY d.depriveDate DESC");
		Query<DeprivedOfRight> query = createQuery(queryBuilder.toString(), DeprivedOfRight.class);
		query.setParameter("id", subjectId);

		List<DeprivedOfRight> result = query.list();
		return result.isEmpty() ? null : result.get(0);
	}

}
