package bg.demax.inspections.backend.db.finder.techinsp;

import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.dto.SemtCertificateHtmlReportDto;
import bg.demax.inspections.backend.search.techinsp.AbstractInspectionSearch;
import bg.demax.inspections.backend.search.techinsp.ActiveInspectionSearch;
import bg.demax.techinsp.entity.Inspection;
import bg.demax.techinsp.entity.InspectionCheck;
import bg.demax.techinsp.entity.InspectionConclusion;
import bg.demax.techinsp.entity.InspectionElement;
import bg.demax.techinsp.entity.InspectionProtocolType;
import bg.demax.techinsp.entity.InspectionStatus;
import bg.demax.techinsp.entity.InspectionValue;
import bg.demax.techinsp.entity.InspectionVariableValue;
import bg.demax.techinsp.entity.SemtCertificate;
import bg.demax.techinsp.entity.SemtStatus;

@Repository
public class InspectionFinder extends AbstractFinder {

	private static final String BASE_INSPECTIONS_SELECT_QUERY = "SELECT insp FROM Inspection insp ";
	private static final String BASE_INSPECTIONS_COUNT_QUERY = "SELECT count(insp) FROM Inspection insp ";

	@Autowired
	private PagingAndSortingSupport pagingSupport;

	@Autowired
	private GenericSearchSupport searchSupport;

	public List<Inspection> getInspectionsForPage(AbstractInspectionSearch search, PageRequest pageRequest) {
		String strQuery = addInspectionSearchConstraints(BASE_INSPECTIONS_SELECT_QUERY, search);
		strQuery = pagingSupport.applySorting(strQuery, pageRequest);
		Query<Inspection> query = createQuery(strQuery, Inspection.class);
		query.setProperties(search);

		pagingSupport.applyPaging(query, pageRequest);
		return query.getResultList();
	}

	public List<Inspection> getInspections(AbstractInspectionSearch search) {
		String strQuery = addInspectionSearchConstraints(BASE_INSPECTIONS_SELECT_QUERY, search);
		strQuery += " ORDER BY insp.id DESC ";
		Query<Inspection> query = createQuery(strQuery, Inspection.class);
		query.setProperties(search);

		return query.getResultList();
	}
	
	public long findLastInspectionIdForRoadVehicle(long roadVehicleId) {
		String strQuery = "SELECT i.id FROM Inspection i where i.roadVehicle.id = :id ORDER BY i.id DESC";
		Query<Long> query = createQuery(strQuery, Long.class);
		query.setMaxResults(1);
		query.setParameter("id", roadVehicleId);

		Long result = query.uniqueResult();
		return result != null ? result.longValue() : 0L;
	}

	public int getInspectionsCount(AbstractInspectionSearch search) {

		String strQuery = addInspectionSearchConstraints(BASE_INSPECTIONS_COUNT_QUERY, search);

		Number count = (Number) createQuery(strQuery).setProperties(search).uniqueResult();
		return count == null ? 0 : count.intValue();
	}
	
	public int getSemtCertificatesCountForCertificateDetailsId(int id) {

		String strQuery = "SELECT COUNT(c.id) FROM SemtCertificate c WHERE c.semtCerticationDetails.id = :id ";

		Number count = (Number) createQuery(strQuery).setParameter("id", id).uniqueResult();
		return count == null ? 0 : count.intValue();
	}

	public List<Inspection> getActiveInspectionsForPage(ActiveInspectionSearch inspectionSearch, PageRequest pageRequest) {

		String strQuery = "";
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT insp FROM ActiveHost ah ")
					.append("INNER JOIN Inspection insp ON ah.inspId = insp.id ")
					.append("AND ah.lastActivity >= :fromDateTime ")
					.append("AND insp.currentStatus = :inProgressStatus");

		strQuery = searchSupport.addSearchConstraints(queryBuilder.toString(), inspectionSearch);
		strQuery = pagingSupport.applySorting(strQuery, pageRequest);

		Query<Inspection> query = createQuery(strQuery, Inspection.class);
		pagingSupport.applyPaging(query, pageRequest);

		query.setProperties(inspectionSearch);
		query.setParameter("fromDateTime", LocalDateTime.now().minusDays(1));
		query.setParameter("inProgressStatus", InspectionStatus.INPROGRESS);

		return query.getResultList();
	}
	
	public List<SemtCertificateHtmlReportDto> getSemtReportInspections() {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT DISTINCT new bg.demax.inspections.backend.dto.SemtCertificateHtmlReportDto("
					+ "rvv.registrationNumber, COALESCE(rv.vin, rv.frameNumber), scd.ecoCategoryCode, insp.nextInspectionDate"
					+ ") FROM Inspection insp ")
			.append("JOIN insp.semtCertificate sc ")
			.append("JOIN insp.roadVehicleVersion rvv ")
			.append("JOIN rvv.roadVehicle rv ")
			.append("JOIN sc.semtCerticationDetails scd ")
			.append("WHERE insp.conclusion = :conclusion ")
			.append("AND insp.hasSemt = true ")
			.append("AND insp.currentStatus = :currentStatus ")
			.append("AND insp.nextInspectionDate >= current_date() ")
			.append("AND sc.status.code = :semtStatus");

		Query<SemtCertificateHtmlReportDto> query = createQuery(queryBuilder.toString(), SemtCertificateHtmlReportDto.class);
		
		query.setParameter("conclusion", InspectionConclusion.IA)
			.setParameter("currentStatus", InspectionStatus.COMPLETED)
			.setParameter("semtStatus", SemtStatus.APPROVED);

		return query.list();
	}
	
	public List<Inspection> getInspectionsByRoadVehicleId(Long roadVehicleId) {
		StringBuilder queryBuilder = new StringBuilder(BASE_INSPECTIONS_SELECT_QUERY); 
		
		queryBuilder
			.append("WHERE insp.roadVehicle.id = :roadVehicleId")
			.append(" AND insp.inspectionDateTime >= :fiveYearsAgo")
			.append(" AND insp.inspectionDateTime <= :currentDate")
			.append(" AND insp.currentStatus = :currentStatus ")
			.append(" AND insp.conclusion = :conclusion ")
			.append(" ORDER BY insp.inspectionDateTime DESC");

		Query<Inspection> query = createQuery(queryBuilder.toString(), Inspection.class);

		query
			.setParameter("roadVehicleId", roadVehicleId)
			.setParameter("currentDate", LocalDateTime.now())
			.setParameter("fiveYearsAgo", LocalDateTime.now().minusYears(5L))
			.setParameter("currentStatus", InspectionStatus.COMPLETED)
			.setParameter("conclusion", InspectionConclusion.IA);
	

		return query.list();
	}

	public int getActiveInspectionsCount(ActiveInspectionSearch inspectionSearch) {

		String strQuery = "";
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT COUNT(insp) FROM ActiveHost ah ")
					.append("INNER JOIN Inspection insp ON ah.inspId = insp.id ")
					.append("AND ah.lastActivity >= :fromDateTime ")
					.append("AND insp.currentStatus = :inProgressStatus");
	
		strQuery = searchSupport.addSearchConstraints(queryBuilder.toString(), inspectionSearch);

		Number count = (Number) createQuery(strQuery).setParameter("fromDateTime", LocalDateTime.now().minusDays(1))
				.setParameter("inProgressStatus", InspectionStatus.INPROGRESS).setProperties(inspectionSearch)
				.uniqueResult();

		return count == null ? 0 : count.intValue();
	}

	public Inspection findById(long inspectionId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM Inspection inspection ").append("WHERE inspection.id = :inspectionId ");
		return createQuery(queryBuilder.toString(), Inspection.class).setParameter("inspectionId", inspectionId)
				.uniqueResult();
	}

	public InspectionCheck findInspectionCheckByElementIdAndInspectionId(long elementId, long inspectionId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM InspectionCheck check ").append("WHERE check.id.element.id = :elementId ")
				.append("AND check.id.inspection.id = :inspectionId ");
		return createQuery(queryBuilder.toString(), InspectionCheck.class).setParameter("elementId", elementId)
				.setParameter("inspectionId", inspectionId).uniqueResult();
	}

	public InspectionValue findInspectionValueByElementIdAndInspectionId(long elementId, long inspectionId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM InspectionValue val ").append("WHERE val.id.element.id = :elementId ")
				.append("AND val.id.inspection.id = :inspectionId ");
		return createQuery(queryBuilder.toString(), InspectionValue.class).setParameter("elementId", elementId)
				.setParameter("inspectionId", inspectionId).uniqueResult();
	}

	public List<InspectionElement> findInspectionElementsByProtocolType(InspectionProtocolType protocolType) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM InspectionElement element ").append("WHERE element.protocolType = :protocolType AND element.id < 200000")
				.append("ORDER BY element.id ASC ");
		return createQuery(queryBuilder.toString(), InspectionElement.class).setParameter("protocolType", protocolType)
				.getResultList();
	}
	

	public List<InspectionVariableValue> findInspectionVariableValuessByInspectionAndProtocolType(Inspection inspection,
			InspectionProtocolType protocolType) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM InspectionVariableValue varValue ")
				.append("WHERE varValue.id.inspection = :inspection ")
				.append("AND varValue.id.variable.protocolType = :protocolType ");
		return createQuery(queryBuilder.toString(), InspectionVariableValue.class)
				.setParameter("inspection", inspection).setParameter("protocolType", protocolType).getResultList();
	}

	public SemtCertificate findRoadVehicleSemtCertificationByInspectionId(long inspectionId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("FROM SemtCertification semt ").append("JOIN  semt.inspection insp")
				.append("WHERE insp.id = :inspectionId ");

		return createQuery(queryBuilder.toString(), SemtCertificate.class).setParameter("inspectionId", inspectionId)
				.uniqueResult();
	}

	private String addInspectionSearchConstraints(String strQuery, AbstractInspectionSearch inspectionSearch) {
		strQuery = addIsSuspiciousClauseIfNecessary(strQuery, inspectionSearch.getIsSuspicious());
		strQuery = searchSupport.addSearchConstraints(strQuery, inspectionSearch);

		return strQuery;
	}

	private String addIsSuspiciousClauseIfNecessary(String strQuery, Boolean isSuspicious) {
		if (isSuspicious == null) {
			return strQuery;
		}

		StringBuilder queryBuilder = new StringBuilder(strQuery);
		queryBuilder.append(" left join insp.suspiciousInspection si ");

		if (strQuery.contains("WHERE")) {
			queryBuilder.append("AND");
		} else {
			queryBuilder.append("WHERE");
		}

		queryBuilder.append(" ");

		if (isSuspicious == true) {
			queryBuilder.append("si IS NOT NULL");
		} else if (isSuspicious == false) {
			queryBuilder.append("si IS NULL");
		}

		queryBuilder.append(" ");

		return queryBuilder.toString();
	}
}
