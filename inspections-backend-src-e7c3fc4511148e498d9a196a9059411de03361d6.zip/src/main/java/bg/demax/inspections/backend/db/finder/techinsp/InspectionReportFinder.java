package bg.demax.inspections.backend.db.finder.techinsp;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.inspections.backend.dto.IssuedSemtHtmlReportDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionCountForVehicleReport;
import bg.demax.inspections.backend.dto.techinsp.InspectionIssuesCountReportDto;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountByKtpResult;
import bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountResult;
import bg.demax.inspections.backend.search.techinsp.AbstractInspectionTypesCountReportSearch;
import bg.demax.inspections.backend.search.techinsp.InspectionReportSearch;
import bg.demax.inspections.backend.search.techinsp.InspectionTypesCountByKtpNumberReportSearch;
import bg.demax.inspections.backend.search.techinsp.InspectionTypesCountByOrgUnitReportSearch;
import bg.demax.inspections.backend.search.techinsp.IssuedSemtsReportSearch;
import bg.demax.techinsp.entity.InspectionConclusion;
import bg.demax.techinsp.entity.InspectionStatus;

@Repository
public class InspectionReportFinder extends AbstractFinder {

	@Autowired
	private GenericSearchSupport searchSupport;
	
	public List<InspectionTypesCountByKtpResult> findInspectionTypesCountByKtpReportForKtpNumber(
					InspectionTypesCountByKtpNumberReportSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT new bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountByKtpResult")
					.append("(permit.permitNumber, inspType.description, rvsv.category, insp.conclusion, COUNT(insp.id)) ")
					.append("FROM Inspection insp ")
					.append("LEFT JOIN insp.permitLine permitLine ")
					.append("LEFT JOIN permitLine.permit permit ")
					.append("LEFT JOIN insp.roadVehicleVersion rvsv ")
					.append("LEFT JOIN insp.inspectionType inspType ");
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString += " GROUP BY permit.permitNumber, inspType, rvsv.category, insp.currentStatus, insp.conclusion ";
		
		return createQuery(queryString, InspectionTypesCountByKtpResult.class)
						.setProperties(search)
						.getResultList();
	}
	
	public List<InspectionTypesCountByKtpResult> findInspectionTypesCountByKtpResult(InspectionTypesCountByOrgUnitReportSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT new bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountByKtpResult")
					.append("(permit.permitNumber, inspType.description, rvsv.category, insp.conclusion, COUNT(insp.id)) ")
					.append("FROM Inspection insp ")
					.append("LEFT JOIN insp.permitLine permitLine ")
					.append("LEFT JOIN permitLine.permit permit ")
					.append("LEFT JOIN insp.roadVehicleVersion rvsv ")
					.append("LEFT JOIN insp.inspectionType inspType ")
					.append("WHERE insp.currentStatus != 'INPROGRESS' ");
		
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString += " GROUP BY permit.permitNumber, inspType, rvsv.category, insp.currentStatus, insp.conclusion";
		
		Query<InspectionTypesCountByKtpResult> query = createQuery(queryString, InspectionTypesCountByKtpResult.class);
		
		return query.setProperties(search)
					.getResultList();
	}
	
	public List<InspectionTypesCountResult> findInspectionTypesCountResult(AbstractInspectionTypesCountReportSearch search) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT new bg.demax.inspections.backend.dto.techinsp.InspectionTypesCountResult")
					.append("(inspType.description, insp.conclusion, insp.currentStatus, COUNT(insp.id)) ")
					.append("FROM Inspection insp ")
					.append("LEFT JOIN insp.permitLine permitLine ")
					.append("LEFT JOIN permitLine.permit permit ")
					.append("LEFT JOIN insp.roadVehicleVersion rvsv ")
					.append("LEFT JOIN insp.inspectionType inspType ")
					.append("WHERE insp.currentStatus != 'INPROGRESS' ");
					
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString += " GROUP BY inspType, insp.currentStatus, insp.conclusion ";
		
		return createQuery(queryString, InspectionTypesCountResult.class)
						.setProperties(search)
						.getResultList();
	}

	public List<InspectionIssuesCountReportDto> findInspectionIssuesCount(InspectionReportSearch search, int permitId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT new bg.demax.inspections.backend.dto.techinsp.InspectionIssuesCountReportDto")
					.append("(inspElement.description, inspCheck.value, inspElement.cardinality, COUNT(DISTINCT inspCheck.id)) ")
					.append("FROM InspectionCheck inspCheck ")
					.append("LEFT JOIN inspCheck.id.element inspElement ")
					.append("LEFT JOIN inspCheck.id.inspection insp ")
					.append("LEFT JOIN insp.permitLine permitLine ")
					.append("LEFT JOIN permitLine.permit permit ")
					.append("WHERE permit.id=:permitId AND (insp.inspectionDateTime BETWEEN :fromDate AND :toDate) ")
					.append("AND insp.conclusion=:conclusion ")
					.append("AND inspCheck.value in ('Y', 'N') ")
					.append("GROUP BY inspElement.description, inspCheck.value, inspElement.cardinality ");
		
		Query<InspectionIssuesCountReportDto> query = createQuery(queryBuilder.toString(), InspectionIssuesCountReportDto.class);
		
		return query.setProperties(search)
					.setParameter("permitId", permitId)
					.getResultList();
	}
	
	public Integer findInspectionPassedAfterIssuesCount(InspectionReportSearch search, int permitId ) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT COUNT(insp.id) ")
					.append("FROM Inspection insp ")
					.append("LEFT JOIN insp.permitLine permitLine ")
					.append("LEFT JOIN permitLine.permit permit ")
					.append("WHERE insp.conclusion='TA' ")
					.append("AND permit.id=:permitId ")
					.append("AND insp.inspectionDateTime BETWEEN :fromDate AND :toDate ")
					.append("AND EXISTS (SELECT i.id FROM Inspection i ")
					.append("	WHERE i.roadVehicle = insp.roadVehicle ")
					.append("	AND i.conclusion = 'IA' AND i.inspectionDateTime > insp.inspectionDateTime)");

		Number count = (Number) createQuery(queryBuilder.toString())
				.setParameter("permitId", permitId)
				.setParameter("fromDate", search.getFromDate())
				.setParameter("toDate", search.getToDate())
				.uniqueResult();
		
		return count == null ? 0 : count.intValue();
	}

	public List<InspectionCountForVehicleReport> findVehicleInspectionsCount(InspectionReportSearch search, Integer permitId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT new bg.demax.inspections.backend.dto.techinsp.InspectionCountForVehicleReport")
					.append("(orgUnit, rvsv.registrationNumber, rvsv.make, COUNT(rvsv.registrationNumber), insp.conclusion) ")
					.append("FROM Inspection insp ")
					.append("LEFT JOIN insp.permitLine permitLine ")
					.append("LEFT JOIN permitLine.permit permit ")
					.append("LEFT JOIN permit.orgUnit orgUnit ")
					.append("LEFT JOIN insp.inspectionType inspType ")
					.append("LEFT JOIN insp.roadVehicleVersion rvsv ")
					.append("WHERE permit.id = :permitId AND insp.inspectionDateTime BETWEEN :fromDate AND :toDate ")
					.append("GROUP BY orgUnit, permit.permitNumber, rvsv.registrationNumber, rvsv.make, insp.conclusion ")
					.append("HAVING COUNT(rvsv.registrationNumber) " + search.getInspectionsCountOption().getDescription() + " :inspCount ")
					.append("ORDER BY permit.permitNumber ASC");
		
		Query<InspectionCountForVehicleReport> query = createQuery(queryBuilder.toString(), InspectionCountForVehicleReport.class);
		
		return query.setParameter("permitId", permitId)
					.setParameter("fromDate", search.getFromDate())
					.setParameter("toDate", search.getToDate())
					.setParameter("inspCount", (long) search.getInspectionsCount())
					.getResultList();
	}

	public List<IssuedSemtHtmlReportDto> getIssuedSemtReportInspections(IssuedSemtsReportSearch params) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("SELECT DISTINCT new bg.demax.inspections.backend.dto.IssuedSemtHtmlReportDto("
					+ "rvv.registrationNumber, COALESCE(rv.vin, rv.frameNumber), scd.ecoCategoryCode, insp.nextInspectionDate, ss.code"
					+ ") FROM Inspection insp ")
			.append("JOIN insp.semtCertificate sc ")
			.append("JOIN insp.roadVehicleVersion rvv ")
			.append("JOIN rvv.roadVehicle rv ")
			.append("JOIN sc.semtCerticationDetails scd ")
			.append("JOIN sc.status ss ")
			.append("JOIN sc.semtPrints sp ")
			.append("WHERE insp.conclusion = :conclusion ")
			.append("AND insp.hasSemt = true ")
			.append("AND insp.currentStatus = :currentStatus ");

		if (params.getPublishedBy() != null && !params.getPublishedBy().equals("ANY")) {
			queryBuilder.append(" AND sp.isPrintedByIaaa = :issuedByIaaa ");
		}
		
		if (params.getSemtStatus() != null && !params.getSemtStatus().isEmpty() && !params.getSemtStatus().contains("ANY")) {
			queryBuilder.append("AND ss.code IN (:semtStatus) ");
		}
		
		if (params.getEcoCategory() != null && !params.getEcoCategory().isEmpty() && !params.getEcoCategory().contains("ANY")) {
			queryBuilder.append("AND scd.ecoCategoryCode IN (:ecoCategory) ");
		}
		
		if (params.getIsValidByCurrentMoment() != null && params.getIsValidByCurrentMoment().equals(Boolean.TRUE)) {
			queryBuilder.append("AND sp.printDate >= :firstDayOfCurrentMonthMinusYear ");
		}
		
		if (params.getIsValidByCurrentMoment() != null && params.getIsValidByCurrentMoment().equals(Boolean.FALSE)
				|| params.getIsValidByCurrentMoment() == null) {
			if (params.getSemtStatus().contains("N") || params.getSemtStatus().contains("D")) {
				queryBuilder.append("AND insp.inspectionDateTime BETWEEN :beginDateTime AND :endDateTime");
			} else if (params.getSemtStatus().size() == 1 && params.getSemtStatus().contains("A")) {
				queryBuilder.append("AND insp.nextInspectionDate BETWEEN :beginDate AND :endDate");
			} else {
				queryBuilder.append("AND sp.printDate BETWEEN :beginDate AND :endDate ");				
			}
		}

		Query<IssuedSemtHtmlReportDto> query = createQuery(queryBuilder.toString(), IssuedSemtHtmlReportDto.class);
		
		query.setParameter("conclusion", InspectionConclusion.IA)
			.setParameter("currentStatus", InspectionStatus.COMPLETED);
		
		if (params.getSemtStatus() != null && !params.getSemtStatus().isEmpty() && !params.getSemtStatus().contains("ANY")) {
			query.setParameter("semtStatus", params.getSemtStatus());
		}
		
		if (params.getEcoCategory() != null && !params.getEcoCategory().isEmpty() && !params.getEcoCategory().contains("ANY")) {
			query.setParameter("ecoCategory", params.getEcoCategory());
		}
	
		if (params.getIsValidByCurrentMoment() != null && params.getIsValidByCurrentMoment().equals(Boolean.FALSE)
				|| params.getIsValidByCurrentMoment() == null) {
			if (params.getSemtStatus().contains("N") || params.getSemtStatus().contains("D")) {
				if (params.getFromDate() != null) {
					query.setParameter("beginDateTime", LocalDateTime.of(params.getFromDate(), LocalTime.MIN));
				}
				
				if (params.getToDate() != null) {
					query.setParameter("endDateTime", LocalDateTime.of(params.getToDate(), LocalTime.MAX));
				} 
			} else {
				if (params.getFromDate() != null) {
					query.setParameter("beginDate", params.getFromDate());
				}
				
				if (params.getToDate() != null) {
					query.setParameter("endDate", params.getToDate());
				}
			}
		}
		if (params.getPublishedBy() != null && !params.getPublishedBy().equals("ANY")) {
			if (params.getPublishedBy().equals("KTP")) {
				query.setParameter("issuedByIaaa", false);				
			} else {
				query.setParameter("issuedByIaaa", true);
			}
		}
		
		if (params.getIsValidByCurrentMoment() != null && params.getIsValidByCurrentMoment()) {
			query.setParameter("firstDayOfCurrentMonthMinusYear", params.getFirstDayOfThisMonth().minusYears(1L));
		}

		
		return query.list();
	}
}
