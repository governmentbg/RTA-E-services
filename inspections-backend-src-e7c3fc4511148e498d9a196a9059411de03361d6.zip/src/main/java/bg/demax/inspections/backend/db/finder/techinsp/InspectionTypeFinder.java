package bg.demax.inspections.backend.db.finder.techinsp;

import java.util.Collection;
import java.util.List;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.techinsp.entity.InspectionType;

@Repository
public class InspectionTypeFinder extends AbstractFinder {
	
	public List<InspectionType> findAllByCodes(Collection<String> codes) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder
			.append("FROM InspectionType AS it ")
			.append("WHERE it.code IN (:codes)");
		
		Query<InspectionType> query = createQuery(queryBuilder.toString(), InspectionType.class);
		query.setParameter("codes", codes);
		
		return query.list();
	}
}
