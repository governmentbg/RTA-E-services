package bg.demax.inspections.backend.db.finder.techinsp;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.OrderClause;
import bg.demax.hibernate.paging.OrderDirection;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.entity.techinsp.Message;
import bg.demax.inspections.backend.entity.techinsp.enums.MessageStatus;
import bg.demax.inspections.backend.search.techinsp.MessageSearch;
import bg.demax.pub.entity.OrgUnit;
import bg.demax.techinsp.entity.Permit;

@Repository
public class MessageFinder extends AbstractFinder {

	@Autowired
	private PagingAndSortingSupport pagingSupport;

	@Autowired
	private GenericSearchSupport searchSupport;

	public List<Message> findMessages(MessageSearch messageSearch, PageRequest pageRequest, MessageStatus status) {
		addOrderClause(pageRequest, status);
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT message ")
					.append("FROM Message message ")
					.append("JOIN FETCH message.body messageBody ")
					.append("WHERE message.status = :messageStatus ");
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), messageSearch);
		queryString = pagingSupport.applySorting(queryString, pageRequest);
		Query<Message> query = createQuery(queryString, Message.class);
		pagingSupport.applyPaging(query, pageRequest);
		return query.setProperties(messageSearch)
			.setParameter("messageStatus", status)
			.getResultList();
	}

	public int findMessagesCount(MessageSearch messageSearch, MessageStatus status) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count(message) ")
					.append("FROM Message message ")
					.append("JOIN message.body messageBody ")
					.append("WHERE message.status = :messageStatus ");
		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), messageSearch);
		Query<Number> query = createQuery(queryString, Number.class);
		query.setProperties(messageSearch);
		Number count = createQuery(queryString, Number.class)
						.setProperties(messageSearch)
						.setParameter("messageStatus", status)
						.uniqueResult();
		return count == null ? 0 : count.intValue();
	}

	public List<OrgUnit> findOrgUnitsByMessage(Message message) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT DISTINCT orgUnit ")
					.append("FROM Message message ")
					.append("JOIN message.messagePermits messagePermit ")
					.append("JOIN messagePermit.permit permit ")
					.append("JOIN permit.orgUnit orgUnit ")
					.append("WHERE message = :message ")
					.append("ORDER BY orgUnit.code ASC ");
		return createQuery(queryBuilder.toString(), OrgUnit.class)
						.setParameter("message", message)
						.getResultList();
		
	}
	
	private void addOrderClause(PageRequest pageRequest, MessageStatus status) {
		if (status.getCode().equals(MessageStatus.SENT)) {
			pageRequest.addOrderClause(new OrderClause("message.sentAt", OrderDirection.DESCENDING));
		} else if (status.getCode().equals(MessageStatus.DRAFT)) {
			pageRequest.addOrderClause(new OrderClause("message.id", OrderDirection.DESCENDING));
		}
	}

	public Permit findFirstPermitByMessage(Message message) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT DISTINCT permit ")
					.append("FROM Message message ")
					.append("JOIN message.messagePermits messagePermit ")
					.append("JOIN messagePermit.permit permit ")
					.append("WHERE message = :message ")
					.append("ORDER BY permit.id ASC ");
		return createQuery(queryBuilder.toString(), Permit.class)
						.setParameter("message", message)
						.setMaxResults(1)
						.uniqueResult();
	}
}