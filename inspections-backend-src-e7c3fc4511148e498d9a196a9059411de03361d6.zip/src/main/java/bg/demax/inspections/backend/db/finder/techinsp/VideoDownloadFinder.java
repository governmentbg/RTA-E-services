package bg.demax.inspections.backend.db.finder.techinsp;

import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.techinsp.entity.VideoDownload;

@Repository
public class VideoDownloadFinder extends AbstractFinder {
	
	public VideoDownload findByProtocolNumber(long protocolNumber) {
		StringBuilder queryBuilder = new StringBuilder();
		
		queryBuilder.append("SELECT vd FROM VideoDownload vd ")
					.append("LEFT JOIN vd.inspection insp ")
					.append("WHERE insp.id = :protocolNumber ");
		
		Query<VideoDownload> query = createQuery(queryBuilder.toString(), VideoDownload.class);
		return query.setParameter("protocolNumber", protocolNumber).uniqueResult();
	}
}
