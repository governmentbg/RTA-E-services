package bg.demax.inspections.backend.db.finder.techinsp;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractFinder;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.hibernate.paging.PageRequest;
import bg.demax.inspections.backend.search.techinsp.VideoDownloadRequestSearch;
import bg.demax.security.entity.User;
import bg.demax.techinsp.entity.VideoDownloadRequest;

@Repository
public class VideoDownloadRequestFinder extends AbstractFinder {

	@Autowired
	PagingAndSortingSupport pagingSupport;

	@Autowired
	GenericSearchSupport searchSupport;
	
	public List<VideoDownloadRequest> getVideoDownloadRequestsForPage(VideoDownloadRequestSearch search,
			PageRequest pageRequest, User user) {
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("SELECT vdr FROM VideoDownloadRequest vdr ")
						.append("LEFT JOIN FETCH vdr.videoDownload vd ")
						.append("LEFT JOIN vd.status vd_status ")
						.append("LEFT JOIN FETCH vd.inspection insp ")
						.append("LEFT JOIN insp.roadVehicleVersion road_vehcile_version ")
						.append("LEFT JOIN insp.permitLine permit_line ")
						.append(getUserWhereClause(user));

		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		queryString += " ORDER BY vdr.creationTimestamp DESC ";
		Query<VideoDownloadRequest> query = createQuery(queryString, VideoDownloadRequest.class);
		
		if (pageRequest != null) {
			pagingSupport.applyPaging(query, pageRequest);
		}

		return query.setProperties(search).getResultList();
	}

	public int getVideoDownloadRequestsCount(VideoDownloadRequestSearch search, User user) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT count(vdr.id) ")
					.append("FROM VideoDownloadRequest vdr ")
					.append("LEFT JOIN vdr.videoDownload vd ")
					.append("LEFT JOIN vd.status vd_status ")
					.append("LEFT JOIN vd.inspection insp ")
					.append("LEFT JOIN insp.roadVehicleVersion road_vehcile_version ")
					.append("LEFT JOIN insp.permitLine permit_line ")
					.append(getUserWhereClause(user));

		String queryString = searchSupport.addSearchConstraints(queryBuilder.toString(), search);
		
		Number count = (Number) createQuery(queryString).setProperties(search).uniqueResult();
		return count == null ? 0 : count.intValue();
	}
	
	public VideoDownloadRequest findByUserIdAndVideoDownloadId(int userId, int videoDownloadId) {
		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT vdr FROM VideoDownloadRequest vdr ")
					.append("LEFT JOIN vdr.user user ")
					.append("LEFT JOIN vdr.videoDownload vd ")
					.append("WHERE user.id = :userId AND vd.id = :videoDownloadId");
		Query<VideoDownloadRequest> query = createQuery(queryBuilder.toString(), VideoDownloadRequest.class);
		
		return query.setParameter("userId", userId).setParameter("videoDownloadId", videoDownloadId).uniqueResult();
	}
	
	private String getUserWhereClause(User user) {
		if (user == null) {
			return "";
		}
		return "WHERE vdr.user.id = " + user.getId();
	}
}
