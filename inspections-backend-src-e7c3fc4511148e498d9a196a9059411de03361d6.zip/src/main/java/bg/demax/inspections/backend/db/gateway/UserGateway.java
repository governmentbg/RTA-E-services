package bg.demax.inspections.backend.db.gateway;

import org.springframework.stereotype.Repository;

import bg.demax.hibernate.AbstractRepository;

@Repository
public class UserGateway extends AbstractRepository {
	
	public void updateUserPassword(Integer userId, String newPassword ) {
		String queryString = "UPDATE User user SET user.password = :newPassword WHERE user.id = :userId";
		getSession().createQuery(queryString)
			.setParameter("userId", userId)
			.setParameter("newPassword", newPassword)
			.executeUpdate();
	}
}
