package bg.demax.inspections.backend.db.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import bg.demax.inspections.backend.entity.permit.inspector.PermitInspectorVersion;
import bg.demax.specialist.registry.common.entity.InspectorCertification;

@Repository
public interface PermitInspectorVersionRepository extends JpaRepository<PermitInspectorVersion, Integer> {

	@Query(
			"SELECT cert FROM PermitInspectorVersion piv "
			+ "JOIN piv.certifications cert "
			+ "WHERE piv.id = ?1"
	)
	Page<InspectorCertification> findByInspectorVersion(Integer id, Pageable pageable);

	@Query(
			"SELECT cert FROM PermitInspectorVersion piv "
			+ "JOIN piv.certifications cert "
			+ "WHERE piv.id = ?1 AND cert.id = ?2"
	)
	Optional<InspectorCertification> findByInspectorVersionAndId(int inspectorVersionId, int certId);
	
}
