package bg.demax.inspections.backend.db.util;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bg.demax.hibernate.GenericGateway;
import bg.demax.inspections.backend.db.finder.GenericFinderPlus;
import bg.demax.inspections.backend.exception.NoSuchEntityException;
import bg.demax.pub.entity.ApplicationType;
import bg.demax.pub.entity.EventLog;
import bg.demax.security.entity.User;

@Repository
public class PublicEventsApplicationLogger {
	@Autowired
	private GenericFinderPlus genericFinder;
	
	@Autowired
	private GenericGateway genericGateway;
	
	public void logEvent(String eventDescription, LogEventSearchKeys searchKey, User user) {
		ApplicationType applicationType = genericFinder.findById(ApplicationType.class, ApplicationType.CODE_DEMAX_ADMIN);
		
		if (applicationType == null) {
			throw new NoSuchEntityException("ApplicationType with id \"" + ApplicationType.CODE_DEMAX_ADMIN + "\" not found");
		}
		
		EventLog eventLog = new EventLog();
		eventLog.setApplicationType(applicationType);
		eventLog.setEventTime(LocalDateTime.now());
		eventLog.setUser(user);
		eventLog.setDescription(eventDescription);
		eventLog.setSearchKey(searchKey.getValue());
		
		genericGateway.save(eventLog);
	}
	
	public static enum LogEventSearchKeys {
		VOUCHER_INTERVAL_OVERRIDE("VOUCHER_INTERVAL_OVERRIDE"),
		INSPECTION_INTERVAL_OVERRIDE("INSPECTION_INTERVAL_OVERRIDE"),
		INSPECTIONS_WEIGHT_OVERRIDE("INSPECTIONS_WEIGHT_OVERRIDE");
		
		private String searchKey;
		
		private LogEventSearchKeys(String searchKey) {
			this.searchKey = searchKey;
		}
		
		public String getValue() {
			return searchKey;
		}
	}
}
