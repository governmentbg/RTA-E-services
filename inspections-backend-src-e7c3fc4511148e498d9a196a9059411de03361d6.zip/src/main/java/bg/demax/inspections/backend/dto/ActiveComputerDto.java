package bg.demax.inspections.backend.dto;

import java.time.LocalDateTime;

import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineDto;

public class ActiveComputerDto {

	private Integer id = null;
	private PermitLineDto permitLine = null;
	private String serviceMenuUrl = null;
	private LocalDateTime lastActiveAt = null;
	private String ipAddress = null;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public PermitLineDto getPermitLine() {
		return permitLine;
	}

	public void setPermitLine(PermitLineDto permitLine) {
		this.permitLine = permitLine;
	}

	public String getServiceMenuUrl() {
		return serviceMenuUrl;
	}

	public void setServiceMenuUrl(String serviceMenuUrl) {
		this.serviceMenuUrl = serviceMenuUrl;
	}

	public LocalDateTime getLastActiveAt() {
		return lastActiveAt;
	}

	public void setLastActiveAt(LocalDateTime lastActiveAt) {
		this.lastActiveAt = lastActiveAt;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
}
