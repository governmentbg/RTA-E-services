package bg.demax.inspections.backend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AppliedDocumentTypeDto {
	
	private short code;
	private String description;
	private Boolean isOptional;
	private Boolean hasValidFromDate;
	private Boolean hasValidToDate;
	private Boolean hasIssueDate;
	private Boolean hasBrandModel;
	private Integer validityLength;
}
