package bg.demax.inspections.backend.dto;

import java.time.LocalDateTime;
import java.time.LocalTime;

public class BillOfLadingDto {

	private Integer id;
	private String billOfLadingIdForCourier;
	private String courierCode;
	private String courierServiceTypeCode;
	private LocalDateTime createdAt;
	private LocalTime fixedTimeDelivery;
	private String statusCode;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCourierCode() {
		return courierCode;
	}

	public void setCourierCode(String courierCode) {
		this.courierCode = courierCode;
	}

	public String getCourierServiceTypeCode() {
		return courierServiceTypeCode;
	}

	public void setCourierServiceTypeCode(String courierServiceTypeCode) {
		this.courierServiceTypeCode = courierServiceTypeCode;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getBillOfLadingIdForCourier() {
		return billOfLadingIdForCourier;
	}

	public void setBillOfLadingIdForCourier(String billOfLadingId) {
		this.billOfLadingIdForCourier = billOfLadingId;
	}

	public LocalTime getFixedTimeDelivery() {
		return fixedTimeDelivery;
	}

	public void setFixedTimeDelivery(LocalTime fixedTimeDelivery) {
		this.fixedTimeDelivery = fixedTimeDelivery;
	}

}
