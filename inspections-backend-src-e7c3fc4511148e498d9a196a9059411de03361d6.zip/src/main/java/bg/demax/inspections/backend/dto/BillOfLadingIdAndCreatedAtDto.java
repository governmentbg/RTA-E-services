package bg.demax.inspections.backend.dto;

import java.time.LocalDateTime;

public class BillOfLadingIdAndCreatedAtDto {
	private String billOfLadingId;
	private LocalDateTime createdAt;

	
	public BillOfLadingIdAndCreatedAtDto(String billOfLadingId, LocalDateTime createdAt) {
		this.billOfLadingId = billOfLadingId;
		this.createdAt = createdAt;
	}
	
	public String getBillOfLadingId() {
		return billOfLadingId;
	}

	public void setBillOfLadingId(String billOfLadingId) {
		this.billOfLadingId = billOfLadingId;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

}