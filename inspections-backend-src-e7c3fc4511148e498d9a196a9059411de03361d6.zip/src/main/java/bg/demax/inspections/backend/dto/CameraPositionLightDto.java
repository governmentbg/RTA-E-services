package bg.demax.inspections.backend.dto;

import java.time.LocalDateTime;

public class CameraPositionLightDto {

	private Integer id;
	private Integer camIndex;
	private Boolean isInPlace;
	private LocalDateTime lastUpdate;

	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public Integer getCamIndex() {
		return camIndex;
	}
	
	public void setCamIndex(Integer camIndex) {
		this.camIndex = camIndex;
	}
	
	public Boolean getIsInPlace() {
		return isInPlace;
	}
	
	public void setIsInPlace(Boolean isInPlace) {
		this.isInPlace = isInPlace;
	}
	
	public LocalDateTime getLastUpdate() {
		return lastUpdate;
	}
	
	public void setLastUpdate(LocalDateTime lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
}
