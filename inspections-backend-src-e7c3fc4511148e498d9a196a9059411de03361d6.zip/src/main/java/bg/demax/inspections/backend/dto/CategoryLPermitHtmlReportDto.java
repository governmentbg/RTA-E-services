package bg.demax.inspections.backend.dto;

public class CategoryLPermitHtmlReportDto extends GasPermitHtmlReportDto {

}
