package bg.demax.inspections.backend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryVPermitHtmlReportDto {

	private int permitNumber;
	private String companyName;
	private String address;
	private String city;
	private String region;
	private String phoneNumber;
}
