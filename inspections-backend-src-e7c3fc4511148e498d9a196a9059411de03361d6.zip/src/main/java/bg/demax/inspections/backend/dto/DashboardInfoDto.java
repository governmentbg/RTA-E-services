package bg.demax.inspections.backend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DashboardInfoDto {

	private int requestedPermitsCount = 0;
	private int processingPermitsCount = 0;
	private int remainingDaysBeforeExpirationCount = 0;
	private DocumentsCountDto permitDocuments;
	private DocumentsCountDto inspectorDocuments;
	private DocumentsCountDto lineDocuments;
	private DocumentsCountDto inspectorCertificates;
}
