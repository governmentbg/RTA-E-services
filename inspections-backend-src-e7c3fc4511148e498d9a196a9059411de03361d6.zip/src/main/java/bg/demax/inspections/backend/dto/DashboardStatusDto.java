package bg.demax.inspections.backend.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import bg.demax.inspections.backend.util.PermitReportUtil;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DashboardStatusDto {
	
	@NotBlank
	@Pattern(regexp = "^(" 
		+ PermitReportUtil.DOC_EXPIRED_CODE + "|" 
		+ PermitReportUtil.DOC_EXPIRING_CODE + ")$")
	private String statusCode;
}
