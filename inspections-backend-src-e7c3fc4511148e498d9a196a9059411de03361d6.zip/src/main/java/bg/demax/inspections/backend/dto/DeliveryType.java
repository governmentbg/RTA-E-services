package bg.demax.inspections.backend.dto;

public enum DeliveryType {

	DOOR_TO_DOOR, DOOR_TO_OFFICE
}
