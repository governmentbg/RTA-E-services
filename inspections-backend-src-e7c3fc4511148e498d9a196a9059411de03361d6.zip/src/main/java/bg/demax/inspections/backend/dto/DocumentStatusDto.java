package bg.demax.inspections.backend.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import bg.demax.inspections.backend.entity.DocumentStatus;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentStatusDto {
	
	@NotBlank
	@Pattern(regexp = "^(" 
		+ DocumentStatus.VALID_CODE + "|" 
		+ DocumentStatus.EXPIRED_CODE + "|" 
		+ DocumentStatus.INVALID_CODE + ")$")
	private String statusCode;
}
