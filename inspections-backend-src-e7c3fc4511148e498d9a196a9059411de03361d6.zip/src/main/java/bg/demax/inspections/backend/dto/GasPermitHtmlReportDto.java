package bg.demax.inspections.backend.dto;

import java.util.Set;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GasPermitHtmlReportDto {

	private int permitNumber;
	private String companyName;
	private String address;
	private String city;
	private String region;
	private String phoneNumber;
	private String ktpCategory;
	private Set<String> categories;
}
