package bg.demax.inspections.backend.dto;

import java.io.Serializable;

public class IdentifierDto {

	private Serializable id = null;

	public IdentifierDto(Serializable id) {
		this.id = id;
	}

	public Serializable getId() {
		return id;
	}

	public void setId(Serializable id) {
		this.id = id;
	}
}
