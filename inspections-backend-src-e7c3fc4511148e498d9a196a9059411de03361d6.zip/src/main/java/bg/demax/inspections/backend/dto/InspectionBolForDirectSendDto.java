package bg.demax.inspections.backend.dto;

import java.math.BigDecimal;

public class InspectionBolForDirectSendDto {

	private String cityName;
	private String cityType;
	private String cityRegion;
	private String phoneNumber;
	private String contactPersonName;
	private String contactPersonPhoneNumber;
	private String shippingAddress;
	private Integer packageCount;
	private BigDecimal weight;

	public String getCityRegion() {
		return cityRegion;
	}
	
	public void setCityRegion(String cityRegion) {
		this.cityRegion = cityRegion;
	}
	
	public String getCityType() {
		return cityType;
	}
	
	public void setCityType(String cityType) {
		this.cityType = cityType;
	}
	
	public String getCityName() {
		return cityName;
	}
	
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactPersonPhoneNumber() {
		return contactPersonPhoneNumber;
	}

	public void setContactPersonPhoneNumber(String contactPersonPhoneNumber) {
		this.contactPersonPhoneNumber = contactPersonPhoneNumber;
	}

	public String getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public Integer getPackageCount() {
		return packageCount;
	}

	public void setPackageCount(Integer packageCount) {
		this.packageCount = packageCount;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}
}
