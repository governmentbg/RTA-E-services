package bg.demax.inspections.backend.dto;

import bg.demax.specialist.registry.common.dto.certification.InspectorCertificationLightDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InspectorCertificationLightWithCanEditFlagDto extends InspectorCertificationLightDto {

	private Boolean canEdit;

}
