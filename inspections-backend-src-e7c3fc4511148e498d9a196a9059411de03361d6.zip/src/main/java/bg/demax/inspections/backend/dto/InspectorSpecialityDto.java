package bg.demax.inspections.backend.dto;

import lombok.Value;

@Value
public class InspectorSpecialityDto {

	String code;
}
