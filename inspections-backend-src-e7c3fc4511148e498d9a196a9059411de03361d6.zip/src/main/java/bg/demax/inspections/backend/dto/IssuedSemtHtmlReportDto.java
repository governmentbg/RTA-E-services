package bg.demax.inspections.backend.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class IssuedSemtHtmlReportDto {
	
	private String registrationNumber;
	private String vinFrameNumber;
	private String ecoCategory;
	private LocalDate validTo;
	private String status;
}
