package bg.demax.inspections.backend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class KtpCategoryDto {

	private String code;
	private String label;
}
