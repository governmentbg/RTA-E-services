package bg.demax.inspections.backend.dto;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LogsReportListItemDto {

	private LocalDate date;
	private String message;

}
