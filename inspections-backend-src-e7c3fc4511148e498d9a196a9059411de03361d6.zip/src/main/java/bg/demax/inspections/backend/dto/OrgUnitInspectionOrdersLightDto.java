package bg.demax.inspections.backend.dto;

public class OrgUnitInspectionOrdersLightDto {

	private OrgUnitLightDto orgUnit;
	private long paidInspectionOrdersCount;
	private long labelInspectionOrdersCount;
	
	public OrgUnitLightDto getOrgUnit() {
		return orgUnit;
	}
	
	public void setOrgUnit(OrgUnitLightDto orgUnit) {
		this.orgUnit = orgUnit;
	}
	
	public long getPaidInspectionOrdersCount() {
		return paidInspectionOrdersCount;
	}
	
	public void setPaidInspectionOrdersCount(long paidInspectionOrdersCount) {
		this.paidInspectionOrdersCount = paidInspectionOrdersCount;
	}
	
	public long getLabelInspectionOrdersCount() {
		return labelInspectionOrdersCount;
	}
	
	public void setLabelInspectionOrdersCount(long labelInspectionOrdersCount) {
		this.labelInspectionOrdersCount = labelInspectionOrdersCount;
	}
}
