package bg.demax.inspections.backend.dto;

import java.util.List;

public class OrgUnitInspectionOrdersResponseDto {

	private List<OrgUnitInspectionOrdersLightDto> orgUnitLightDtos;
	private long totalPaidInspectionOrdersCount;
	private long totalLabelInspectionOrdersCount;

	public List<OrgUnitInspectionOrdersLightDto> getOrgUnitLightDtos() {
		return orgUnitLightDtos;
	}
	
	public void setOrgUnitLightDtos(List<OrgUnitInspectionOrdersLightDto> orgUnitLightDtos) {
		this.orgUnitLightDtos = orgUnitLightDtos;
	}
	
	public long getTotalPaidInspectionOrdersCount() {
		return totalPaidInspectionOrdersCount;
	}
	
	public void setTotalPaidInspectionOrdersCount(long totalPaidInspectionOrdersCount) {
		this.totalPaidInspectionOrdersCount = totalPaidInspectionOrdersCount;
	}
	
	public long getTotalLabelInspectionOrdersCount() {
		return totalLabelInspectionOrdersCount;
	}

	public void setTotalLabelInspectionOrdersCount(long totalLabelInspectionOrdersCount) {
		this.totalLabelInspectionOrdersCount = totalLabelInspectionOrdersCount;
	}
}
