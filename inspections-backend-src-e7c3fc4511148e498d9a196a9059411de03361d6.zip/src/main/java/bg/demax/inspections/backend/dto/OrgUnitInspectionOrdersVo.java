package bg.demax.inspections.backend.dto;

import bg.demax.pub.entity.OrgUnit;

public class OrgUnitInspectionOrdersVo {
	
	private OrgUnit orgUnit;
	private long paidInspectionOrdersCount;
	private long labelInspectionOrdersCount;
	
	public OrgUnitInspectionOrdersVo(OrgUnit orgUnit, long paidInspectionOrdersCount, long labelInspectionOrdersCount) {
		this.orgUnit = orgUnit;
		this.paidInspectionOrdersCount = paidInspectionOrdersCount;
		this.labelInspectionOrdersCount = labelInspectionOrdersCount;
	}
	
	public OrgUnit getOrgUnit() {
		return orgUnit;
	}
	
	public void setOrgUnit(OrgUnit orgUnit) {
		this.orgUnit = orgUnit;
	}
	
	public long getPaidInspectionOrdersCount() {
		return paidInspectionOrdersCount;
	}
	
	public void setPaidInspectionOrdersCount(long paidInspectionOrdersCount) {
		this.paidInspectionOrdersCount = paidInspectionOrdersCount;
	}
	
	public long getLabelInspectionOrdersCount() {
		return labelInspectionOrdersCount;
	}
	
	public void setLabelInspectionOrdersCount(long labelInspectionOrdersCount) {
		this.labelInspectionOrdersCount = labelInspectionOrdersCount;
	}
}
