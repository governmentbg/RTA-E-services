package bg.demax.inspections.backend.dto;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StickersReportListItemDto {

	private Integer permitNumber;
	private String orgUnit;
	private Long orderNumber;
	private String companyName;
	private LocalDateTime activationDate;
	private Long fromNumber;
	private Long toNumber;
	private Long quantity;
	private String activatedIntervals;
	private String usedIntervals;
	private String scrappedIntervals;
	private Integer activatedIntervalsCount;
	private Integer usedIntervalsCount;
	private Integer scrappedIntervalsCount;

}
