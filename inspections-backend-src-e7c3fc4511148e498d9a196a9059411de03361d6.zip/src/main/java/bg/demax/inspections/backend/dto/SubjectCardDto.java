package bg.demax.inspections.backend.dto;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubjectCardDto extends SubjectCardLightDto {

	private String commonName;
	private LocalDate issuedOn;
	private String remarks;
	private SubjectWithEducationLightDto subjectWithEducation;

}
