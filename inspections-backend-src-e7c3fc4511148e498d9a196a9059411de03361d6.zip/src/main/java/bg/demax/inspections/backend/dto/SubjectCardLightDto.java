package bg.demax.inspections.backend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubjectCardLightDto {

	private Integer id;
	private Integer cardNumber;
	private String serialNumber;
	private Boolean isActive;
	
}
