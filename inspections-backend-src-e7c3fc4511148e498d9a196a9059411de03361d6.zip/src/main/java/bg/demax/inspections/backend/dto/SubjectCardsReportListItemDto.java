package bg.demax.inspections.backend.dto;

import java.util.List;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitOrgUnitDto;
import bg.demax.specialist.registry.common.dto.user.SubjectLightDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubjectCardsReportListItemDto {

	private Integer cardNumber;
	private String serialNumber;
	private SubjectLightDto subject;
	private SubjectLightDto company;
	private Boolean isActive;
	private List<PermitOrgUnitDto> permits;

}
