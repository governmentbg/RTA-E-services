package bg.demax.inspections.backend.dto;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TechinspPermitAdditionalInfoDto {

	private Integer permitNumber = null;
	private OrgUnitLightDto permitOrgUnit = null;
	private CityDto ktpCity = null;
	private String ktpAddress = null;
	private String contactPersonName = null;
	private String contactPersonPhone = null;
	private String contactPersonStationaryPhone = null;
	private String contactPersonEmail = null;
	private String signingPersonName;
	private String signingPersonEgn;
	private String signingPersonPhone;
	private String signingPersonStationaryPhone;
	private String signingPersonEmail;
	private Double gpsN = null;
	private Double gpsE = null;
	private String umtsCellFrequency = null;
	private BigDecimal umtsSpeed = null;
	private String region;
}
