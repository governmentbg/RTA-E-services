package bg.demax.inspections.backend.dto;

import java.util.List;

public class UserDto {
	private String username;
	private String name;
	private List<OrgUnitLightDto> employeeOrgUnit;
	private List<String> authorities;
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getAuthorities() {
		return authorities;
	}

	public void setAuthorities(List<String> authorities) {
		this.authorities = authorities;
	}

	public List<OrgUnitLightDto> getEmployeeOrgUnit() {
		return employeeOrgUnit;
	}

	public void setEmployeeOrgUnit(List<OrgUnitLightDto> employeeOrgUnit) {
		this.employeeOrgUnit = employeeOrgUnit;
	}
}
