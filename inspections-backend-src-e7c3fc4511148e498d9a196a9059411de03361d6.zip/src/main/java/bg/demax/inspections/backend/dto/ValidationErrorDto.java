package bg.demax.inspections.backend.dto;

import java.util.LinkedList;
import java.util.List;

public class ValidationErrorDto {
	
	private List<FieldErrorDto> errors = new LinkedList<>();
	
	public ValidationErrorDto() {
		
	}

	public void addError(String field, String error) {
		errors.add(new FieldErrorDto(field, error));
	}

	public List<FieldErrorDto> getErrors() {
		return errors;
	}

	public static final class FieldErrorDto {
		private String field;
		private String error;
		
		public FieldErrorDto() {
			
		}

		public FieldErrorDto(String field, String error) {
			this.field = field;
			this.error = error;
		}

		public String getField() {
			return field;
		}

		public String getError() {
			return error;
		}
	}
}
