package bg.demax.inspections.backend.dto;

public class WarehouseShippingInfoDto {

	private WarehouseDto warehouse = null;
	private CityDto city = null;
	private String address = null;
	private String recipientPersonName = null;
	private String recipientPersonPhone = null;
	private String speedyOfficeAddress = null;

	public WarehouseDto getWarehouse() {
		return warehouse;
	}

	public void setWarehouse(WarehouseDto warehouse) {
		this.warehouse = warehouse;
	}

	public CityDto getCity() {
		return city;
	}

	public void setCity(CityDto city) {
		this.city = city;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getRecipientPersonName() {
		return recipientPersonName;
	}

	public void setRecipientPersonName(String recipientPersonName) {
		this.recipientPersonName = recipientPersonName;
	}

	public String getRecipientPersonPhone() {
		return recipientPersonPhone;
	}

	public void setRecipientPersonPhone(String recipientPersonPhone) {
		this.recipientPersonPhone = recipientPersonPhone;
	}

	public String getSpeedyOfficeAddress() {
		return speedyOfficeAddress;
	}

	public void setSpeedyOfficeAddress(String speedyOfficeAddress) {
		this.speedyOfficeAddress = speedyOfficeAddress;
	}
}
