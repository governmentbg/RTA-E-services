package bg.demax.inspections.backend.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class WarehouseShippingInfoRequestDto {

	@NotNull
	@Min(1)
	private Integer warehouseId = null;

	@NotEmpty
	private String address = null;

	@NotEmpty
	private String recipientPersonName = null;

	@NotEmpty
	private String recipientPersonPhone = null;
	
	private String speedyOfficeAddress = null;

	public Integer getWarehouseId() {
		return warehouseId;
	}

	public void setWarehouseId(Integer warehouseId) {
		this.warehouseId = warehouseId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getRecipientPersonName() {
		return recipientPersonName;
	}

	public void setRecipientPersonName(String recipientPersonName) {
		this.recipientPersonName = recipientPersonName;
	}

	public String getRecipientPersonPhone() {
		return recipientPersonPhone;
	}

	public void setRecipientPersonPhone(String recipientPersonPhone) {
		this.recipientPersonPhone = recipientPersonPhone;
	}
	
	public String getSpeedyOfficeAddress() {
		return speedyOfficeAddress;
	}
	
	public void setSpeedyOfficeAddress(String speedyOfficeAddress) {
		this.speedyOfficeAddress = speedyOfficeAddress;
	}
}
