package bg.demax.inspections.backend.dto.equipment;

import java.math.BigDecimal;

import bg.demax.inspections.backend.dto.BillOfLadingDto;

public class ConsumableTransferBillOfLadingDto extends BillOfLadingDto {
	private Integer permitNumber;
	private String contactPersonName;
	private String contactPersonPhoneNumber;
	private String shippingAddress;
	private Short cartridgesCount;
	private Short drumsCount;
	private Integer packageCount;
	private BigDecimal weight;

	public Integer getPermitNumber() {
		return permitNumber;
	}

	public void setPermitNumber(Integer permitNumber) {
		this.permitNumber = permitNumber;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactPersonPhoneNumber() {
		return contactPersonPhoneNumber;
	}

	public void setContactPersonPhoneNumber(String contactPersonPhoneNumber) {
		this.contactPersonPhoneNumber = contactPersonPhoneNumber;
	}

	public String getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public Short getCartridgesCount() {
		return cartridgesCount;
	}

	public void setCartridgesCount(Short cartridgesCount) {
		this.cartridgesCount = cartridgesCount;
	}

	public Short getDrumsCount() {
		return drumsCount;
	}

	public void setDrumsCount(Short drumsCount) {
		this.drumsCount = drumsCount;
	}

	public Integer getPackageCount() {
		return packageCount;
	}

	public void setPackageCount(Integer packageCount) {
		this.packageCount = packageCount;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}
}
