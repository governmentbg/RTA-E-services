package bg.demax.inspections.backend.dto.equipment;

import java.time.LocalDateTime;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitLightWithCityNameDto;

public class ConsumableTransferBillOfLadingRowDto {

	private Integer id = null;
	private String courierName = null;
	private String billOfLadingIdForCourier = null;
	private LocalDateTime createdAt = null;
	private PermitLightWithCityNameDto permit = null;
	private Short cartridgesCount = null;
	private Short drumsCount = null;
	private String statusCode = null;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCourierName() {
		return courierName;
	}

	public void setCourierName(String courierName) {
		this.courierName = courierName;
	}

	public String getBillOfLadingIdForCourier() {
		return billOfLadingIdForCourier;
	}
	
	public void setBillOfLadingIdForCourier(String billOfLadingIdForCourier) {
		this.billOfLadingIdForCourier = billOfLadingIdForCourier;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public PermitLightWithCityNameDto getPermit() {
		return permit;
	}
	
	public void setPermit(PermitLightWithCityNameDto permit) {
		this.permit = permit;
	}
	
	public Short getCartridgesCount() {
		return cartridgesCount;
	}

	public void setCartridgesCount(Short cartridgesCount) {
		this.cartridgesCount = cartridgesCount;
	}

	public Short getDrumsCount() {
		return drumsCount;
	}

	public void setDrumsCount(Short drumsCount) {
		this.drumsCount = drumsCount;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
}
