package bg.demax.inspections.backend.dto.equipment;

import java.math.BigDecimal;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import bg.demax.inspections.backend.controller.param.CourierBillOfLadingRequestParams;
import bg.demax.inspections.backend.dto.DeliveryType;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitShippingInfoRequestDto;
import bg.demax.inspections.backend.validation.equipment.ValidConsumableTransferBillOfLadingCreationDto;

@ValidConsumableTransferBillOfLadingCreationDto
public class ConsumableTransferCreationRequestDto extends CourierBillOfLadingRequestParams {

	@Valid
	@NotNull
	private PermitShippingInfoRequestDto permitShippingInfo = null;

	@NotNull
	private DeliveryType deliveryType = null;

	@NotNull
	private Short cartridgesCount = null;

	@NotNull
	private Short drumsCount = null;

	@NotNull
	private Integer packetsCount = null;

	@NotNull
	private BigDecimal weightKg = null;

	public PermitShippingInfoRequestDto getPermitShippingInfo() {
		return permitShippingInfo;
	}

	public void setPermitShippingInfo(PermitShippingInfoRequestDto permitShippingInfo) {
		this.permitShippingInfo = permitShippingInfo;
	}

	public DeliveryType getDeliveryType() {
		return deliveryType;
	}

	public void setDeliveryType(DeliveryType deliveryType) {
		this.deliveryType = deliveryType;
	}

	public Short getCartridgesCount() {
		return cartridgesCount;
	}

	public void setCartridgesCount(Short cartridgesCount) {
		this.cartridgesCount = cartridgesCount;
	}

	public Short getDrumsCount() {
		return drumsCount;
	}

	public void setDrumsCount(Short drumsCount) {
		this.drumsCount = drumsCount;
	}

	public Integer getPacketsCount() {
		return packetsCount;
	}

	public void setPacketsCount(Integer packetsCount) {
		this.packetsCount = packetsCount;
	}

	public BigDecimal getWeightKg() {
		return weightKg;
	}

	public void setWeightKg(BigDecimal weightKg) {
		this.weightKg = weightKg;
	}
}