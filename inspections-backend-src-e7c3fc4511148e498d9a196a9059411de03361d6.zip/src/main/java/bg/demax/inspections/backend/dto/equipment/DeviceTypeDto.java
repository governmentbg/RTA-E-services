package bg.demax.inspections.backend.dto.equipment;

public class DeviceTypeDto {

	private Short code = null;
	private String description = null;

	public Short getCode() {
		return code;
	}

	public void setCode(Short code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
