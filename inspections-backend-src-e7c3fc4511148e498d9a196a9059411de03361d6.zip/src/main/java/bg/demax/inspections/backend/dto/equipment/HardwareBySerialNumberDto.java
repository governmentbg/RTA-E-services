package bg.demax.inspections.backend.dto.equipment;

public class HardwareBySerialNumberDto {
	
	private Integer id = null;
	private String serialNumber = null;
	private String ip = null;
	private DeviceTypeDto type = null;
	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getSerialNumber() {
		return serialNumber;
	}
	
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	
	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public DeviceTypeDto getType() {
		return type;
	}
	
	public void setType(DeviceTypeDto type) {
		this.type = type;
	}
}
