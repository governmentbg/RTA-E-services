package bg.demax.inspections.backend.dto.equipment;

import bg.demax.inspections.backend.dto.WarehouseDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDto;

public class HardwareDeviceDto {

	private Integer id = null;
	private DeviceTypeDto type = null;
	private String serialNumber = null;
	private WarehouseDto warehouse = null;
	private DeviceStatusDto status = null;
	private PermitDto permit = null;
	private String scrapReason = null;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public DeviceTypeDto getType() {
		return type;
	}

	public void setType(DeviceTypeDto type) {
		this.type = type;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public WarehouseDto getWarehouse() {
		return warehouse;
	}

	public void setWarehouse(WarehouseDto warehouse) {
		this.warehouse = warehouse;
	}

	public DeviceStatusDto getStatus() {
		return status;
	}

	public void setStatus(DeviceStatusDto status) {
		this.status = status;
	}

	public PermitDto getPermit() {
		return permit;
	}

	public void setPermit(PermitDto permit) {
		this.permit = permit;
	}

	public String getScrapReason() {
		return scrapReason;
	}

	public void setScrapReason(String scrapReason) {
		this.scrapReason = scrapReason;
	}
}
