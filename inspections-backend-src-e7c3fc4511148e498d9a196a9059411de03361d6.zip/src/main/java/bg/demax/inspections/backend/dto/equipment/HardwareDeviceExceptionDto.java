package bg.demax.inspections.backend.dto.equipment;

import bg.demax.inspections.backend.dto.ApplicationExceptionDto;

public class HardwareDeviceExceptionDto extends ApplicationExceptionDto {

	private Integer deviceId;
	private Integer simCardId;
	private String serialNumber;

	public Integer getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(Integer deviceId) {
		this.deviceId = deviceId;
	}

	public Integer getSimCardId() {
		return simCardId;
	}

	public void setSimCardId(Integer simCardId) {
		this.simCardId = simCardId;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
}
