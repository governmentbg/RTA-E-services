package bg.demax.inspections.backend.dto.equipment;

import javax.validation.constraints.NotNull;

public class HardwareDeviceIdentifierDto {

	@NotNull
	private Integer id = null;

	@NotNull
	private Short typeCode = null;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Short getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(Short typeCode) {
		this.typeCode = typeCode;
	}
}