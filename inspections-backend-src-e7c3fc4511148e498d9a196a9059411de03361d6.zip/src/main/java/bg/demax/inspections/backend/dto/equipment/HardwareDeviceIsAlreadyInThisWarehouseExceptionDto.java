package bg.demax.inspections.backend.dto.equipment;

import bg.demax.inspections.backend.dto.ApplicationExceptionDto;

public class HardwareDeviceIsAlreadyInThisWarehouseExceptionDto extends ApplicationExceptionDto {

	private Integer simId = null;
	private Integer deviceId = null;
	private String serialNumber = null;

	public Integer getSimId() {
		return simId;
	}

	public void setSimId(Integer simId) {
		this.simId = simId;
	}

	public Integer getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(Integer deviceId) {
		this.deviceId = deviceId;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
}
