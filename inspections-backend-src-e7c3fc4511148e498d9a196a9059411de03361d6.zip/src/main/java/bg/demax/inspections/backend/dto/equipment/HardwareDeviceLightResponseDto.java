package bg.demax.inspections.backend.dto.equipment;

import bg.demax.inspections.backend.dto.StoreDto;
import bg.demax.inspections.backend.dto.WarehouseDto;
import bg.demax.inspections.backend.dto.techinsp.permit.PermitDto;

public class HardwareDeviceLightResponseDto {

	private Integer id = null;
	private DeviceTypeDto type = null;
	private String serialNumber = null;
	private DeviceStatusDto status = null;
	private StoreDto store = null;
	private WarehouseDto warehouse = null;
	private PermitDto permit = null;

	private String macAddress = null;
	private String ipAddress = null;
	private DeviceScrapReasonDto scrapReason = null;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public DeviceTypeDto getType() {
		return type;
	}

	public void setType(DeviceTypeDto type) {
		this.type = type;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public WarehouseDto getWarehouse() {
		return warehouse;
	}

	public void setWarehouse(WarehouseDto warehouse) {
		this.warehouse = warehouse;
	}

	public DeviceStatusDto getStatus() {
		return status;
	}

	public void setStatus(DeviceStatusDto status) {
		this.status = status;
	}

	public StoreDto getStore() {
		return store;
	}

	public void setStore(StoreDto store) {
		this.store = store;
	}

	public String getMacAddress() {
		return macAddress;
	}

	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public DeviceScrapReasonDto getScrapReason() {
		return scrapReason;
	}

	public void setScrapReason(DeviceScrapReasonDto scrapReason) {
		this.scrapReason = scrapReason;
	}

	public PermitDto getPermit() {
		return permit;
	}

	public void setPermit(PermitDto permit) {
		this.permit = permit;
	}
}