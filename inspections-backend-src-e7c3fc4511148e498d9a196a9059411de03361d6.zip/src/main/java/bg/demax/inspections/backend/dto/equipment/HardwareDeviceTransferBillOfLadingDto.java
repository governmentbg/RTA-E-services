package bg.demax.inspections.backend.dto.equipment;

import java.math.BigDecimal;
import java.util.List;

import bg.demax.inspections.backend.dto.BillOfLadingDto;

public class HardwareDeviceTransferBillOfLadingDto extends BillOfLadingDto {
	private String recipient;
	private List<HardwareDeviceTransferProtocolDto> protocols;
	private Integer packageCount;
	private BigDecimal weight;
	private String contactPersonName;
	private String contactPersonPhoneNumber;
	private String shippingAddress;

	public String getRecipient() {
		return recipient;
	}

	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}

	public List<HardwareDeviceTransferProtocolDto> getProtocols() {
		return protocols;
	}

	public void setProtocols(List<HardwareDeviceTransferProtocolDto> protocols) {
		this.protocols = protocols;
	}

	public Integer getPackageCount() {
		return packageCount;
	}

	public void setPackageCount(Integer packageCount) {
		this.packageCount = packageCount;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactPersonPhoneNumber() {
		return contactPersonPhoneNumber;
	}

	public void setContactPersonPhoneNumber(String contactPersonPhoneNumber) {
		this.contactPersonPhoneNumber = contactPersonPhoneNumber;
	}

	public String getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
}
