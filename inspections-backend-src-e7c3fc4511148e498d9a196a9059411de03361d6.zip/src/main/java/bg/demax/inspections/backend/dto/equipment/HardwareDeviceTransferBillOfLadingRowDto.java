package bg.demax.inspections.backend.dto.equipment;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import bg.demax.inspections.backend.dto.WarehouseDto;

public class HardwareDeviceTransferBillOfLadingRowDto {

	private Integer id = null;
	private String courierName = null;
	private String billOfLadingId = null;
	private LocalDateTime createdAt = null;
	private WarehouseDto warehouse = null;
	private List<Integer> protocolsIds = null;
	private Integer packageCount = null;
	private BigDecimal weightKg = null;
	private String statusCode = null;
	private Short hardwareItemsCount = null;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCourierName() {
		return courierName;
	}

	public void setCourierName(String courierName) {
		this.courierName = courierName;
	}

	public String getBillOfLadingId() {
		return billOfLadingId;
	}

	public void setBillOfLadingId(String billOfLadingId) {
		this.billOfLadingId = billOfLadingId;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public WarehouseDto getWarehouse() {
		return warehouse;
	}

	public void setWarehouse(WarehouseDto warehouse) {
		this.warehouse = warehouse;
	}

	public List<Integer> getProtocolsIds() {
		return protocolsIds;
	}
	
	public void setProtocolsIds(List<Integer> protocolsIds) {
		this.protocolsIds = protocolsIds;
	}
	
	public Integer getPackageCount() {
		return packageCount;
	}

	public void setPackageCount(Integer packageCount) {
		this.packageCount = packageCount;
	}

	public BigDecimal getWeightKg() {
		return weightKg;
	}

	public void setWeightKg(BigDecimal weightKg) {
		this.weightKg = weightKg;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	public Short getHardwareItemsCount() {
		return hardwareItemsCount;
	}
	
	public void setHardwareItemsCount(Short hardwareItemsCount) {
		this.hardwareItemsCount = hardwareItemsCount;
	}
}