package bg.demax.inspections.backend.dto.equipment;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import bg.demax.inspections.backend.controller.param.CourierBillOfLadingRequestParams;
import bg.demax.inspections.backend.dto.DeliveryType;
import bg.demax.inspections.backend.dto.WarehouseShippingInfoRequestDto;
import bg.demax.inspections.backend.validation.equipment.ValidHardwareDeviceTransferBillOfLadingCreationDto;

@ValidHardwareDeviceTransferBillOfLadingCreationDto
public class HardwareDeviceTransferCreationRequestDto extends CourierBillOfLadingRequestParams {

	@Valid
	@NotNull
	private WarehouseShippingInfoRequestDto warehouseShippingInfo = null;

	@NotNull
	private DeliveryType deliveryType = null;

	@NotNull
	@NotEmpty
	private List<HardwareDeviceIdentifierDto> devices = null;

	@NotNull
	private Integer packetsCount = null;

	@NotNull
	private BigDecimal weightKg = null;

	public WarehouseShippingInfoRequestDto getWarehouseShippingInfo() {
		return warehouseShippingInfo;
	}

	public void setWarehouseShippingInfo(WarehouseShippingInfoRequestDto warehouseShippingInfo) {
		this.warehouseShippingInfo = warehouseShippingInfo;
	}

	public DeliveryType getDeliveryType() {
		return deliveryType;
	}

	public void setDeliveryType(DeliveryType deliveryType) {
		this.deliveryType = deliveryType;
	}

	public List<HardwareDeviceIdentifierDto> getDevices() {
		return devices;
	}

	public void setDevices(List<HardwareDeviceIdentifierDto> devices) {
		this.devices = devices;
	}

	public Integer getPacketsCount() {
		return packetsCount;
	}

	public void setPacketsCount(Integer packetsCount) {
		this.packetsCount = packetsCount;
	}

	public BigDecimal getWeightKg() {
		return weightKg;
	}

	public void setWeightKg(BigDecimal weightKg) {
		this.weightKg = weightKg;
	}
}