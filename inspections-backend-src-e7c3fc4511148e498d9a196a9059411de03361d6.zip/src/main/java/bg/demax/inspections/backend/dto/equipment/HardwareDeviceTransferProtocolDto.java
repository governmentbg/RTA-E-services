package bg.demax.inspections.backend.dto.equipment;

import java.time.LocalDateTime;
import java.util.Set;

public class HardwareDeviceTransferProtocolDto {
	private Integer id;
	private Integer billOfLadingId;
	private LocalDateTime createdAt;
	private Set<HardwareLightDto> devices;
	private Set<HardwareLightDto> simCards;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getBillOfLadingId() {
		return billOfLadingId;
	}

	public void setBillOfLadingId(Integer billOfLadingId) {
		this.billOfLadingId = billOfLadingId;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public Set<HardwareLightDto> getDevices() {
		return devices;
	}

	public void setDevices(Set<HardwareLightDto> devices) {
		this.devices = devices;
	}

	public Set<HardwareLightDto> getSimCards() {
		return simCards;
	}

	public void setSimCards(Set<HardwareLightDto> simCards) {
		this.simCards = simCards;
	}
}
