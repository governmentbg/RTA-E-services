package bg.demax.inspections.backend.dto.equipment;

import javax.validation.constraints.NotNull;

import bg.demax.inspections.backend.validation.equipment.ValidHardwareDeviceUpdateRequestDto;
import lombok.Getter;
import lombok.Setter;

@ValidHardwareDeviceUpdateRequestDto
@Getter
@Setter
public class HardwareDeviceUpdateRequestDto {

	@NotNull
	private Short typeCode = null;

	@NotNull
	private Integer warehouseId = null;
	private String macAddress = null;
	private String ipAddress = null;
	private String serialNumber = null;
	private Integer statusId = null;
	private String scrapReason = null;

	
}
