package bg.demax.inspections.backend.dto.equipment;

import java.util.List;

import javax.validation.constraints.NotEmpty;

public class HardwareDevicesRequestDto {

	@NotEmpty
	private List<HardwareDeviceIdentifierDto> hardwareDevices = null;

	public List<HardwareDeviceIdentifierDto> getHardwareDevices() {
		return hardwareDevices;
	}

	public void setHardwareDevices(List<HardwareDeviceIdentifierDto> hardwareDevices) {
		this.hardwareDevices = hardwareDevices;
	}
}