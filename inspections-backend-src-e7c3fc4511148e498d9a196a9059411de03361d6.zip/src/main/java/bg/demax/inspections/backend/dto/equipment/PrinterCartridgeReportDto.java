package bg.demax.inspections.backend.dto.equipment;

import java.time.LocalDateTime;

public class PrinterCartridgeReportDto {

	private Integer id = null;
	private Integer printedPages = null;
	private Integer inspectionNeededPages = null;
	private Integer pagesForPayment = null;
	private LocalDateTime createdAt = null;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getPrintedPages() {
		return printedPages;
	}

	public void setPrintedPages(Integer printedPages) {
		this.printedPages = printedPages;
	}

	public Integer getInspectionNeededPages() {
		return inspectionNeededPages;
	}

	public void setInspectionNeededPages(Integer inspectionNeededPages) {
		this.inspectionNeededPages = inspectionNeededPages;
	}

	public Integer getPagesForPayment() {
		return pagesForPayment;
	}

	public void setPagesForPayment(Integer pagesForPayment) {
		this.pagesForPayment = pagesForPayment;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
}
