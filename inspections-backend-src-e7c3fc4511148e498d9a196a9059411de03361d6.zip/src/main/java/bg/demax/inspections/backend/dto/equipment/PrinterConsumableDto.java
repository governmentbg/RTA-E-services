package bg.demax.inspections.backend.dto.equipment;

import java.time.LocalDate;
import java.time.LocalDateTime;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitDto;

public class PrinterConsumableDto {

	private Integer id = null;
	private PermitDto permit = null;
	private PrinterConsumableTypeEnum type = null;
	private String serialNumber = null;
	private String printerSerialNumber = null;
	private LocalDateTime firstInstalledAt = null;
	private Integer percentUsed = null;
	private Integer printedPages = null;
	private Integer remainingPages = null;
	private LocalDateTime sentAt = null;
	private LocalDateTime lastUsedAt = null;
	private Integer totalImpressions = null;
	private PrinterConsumableStatusEnum status = null;
	private PrinterCartridgeReportDto latestReport = null;
	private Integer inspectionNeededPages = null;
	private Boolean isDefective = null;
	private LocalDate returnedAt = null;
	private String returnedNotes = null;
					

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public PermitDto getPermit() {
		return permit;
	}

	public void setPermit(PermitDto permit) {
		this.permit = permit;
	}

	public PrinterConsumableTypeEnum getType() {
		return type;
	}

	public void setType(PrinterConsumableTypeEnum type) {
		this.type = type;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getPrinterSerialNumber() {
		return printerSerialNumber;
	}

	public void setPrinterSerialNumber(String printerSerialNumber) {
		this.printerSerialNumber = printerSerialNumber;
	}

	public LocalDateTime getFirstInstalledAt() {
		return firstInstalledAt;
	}

	public void setFirstInstalledAt(LocalDateTime firstInstalledAt) {
		this.firstInstalledAt = firstInstalledAt;
	}

	public Integer getPercentUsed() {
		return percentUsed;
	}

	public void setPercentUsed(Integer percentUsed) {
		this.percentUsed = percentUsed;
	}

	public Integer getPrintedPages() {
		return printedPages;
	}

	public void setPrintedPages(Integer printedPages) {
		this.printedPages = printedPages;
	}

	public Integer getRemainingPages() {
		return remainingPages;
	}

	public void setRemainingPages(Integer remainingPages) {
		this.remainingPages = remainingPages;
	}

	public LocalDateTime getSentAt() {
		return sentAt;
	}

	public void setSentAt(LocalDateTime sentAt) {
		this.sentAt = sentAt;
	}

	public LocalDateTime getLastUsedAt() {
		return lastUsedAt;
	}

	public void setLastUsedAt(LocalDateTime lastUsedAt) {
		this.lastUsedAt = lastUsedAt;
	}

	public Integer getTotalImpressions() {
		return totalImpressions;
	}

	public void setTotalImpressions(Integer totalImpressions) {
		this.totalImpressions = totalImpressions;
	}

	public PrinterConsumableStatusEnum getStatus() {
		return status;
	}

	public void setStatus(PrinterConsumableStatusEnum status) {
		this.status = status;
	}

	public PrinterCartridgeReportDto getLatestReport() {
		return latestReport;
	}

	public void setLatestReport(PrinterCartridgeReportDto latestReport) {
		this.latestReport = latestReport;
	}

	public Integer getInspectionNeededPages() {
		return inspectionNeededPages;
	}

	public void setInspectionNeededPages(Integer inspectionNeededPages) {
		this.inspectionNeededPages = inspectionNeededPages;
	}

	public Boolean getIsDefective() {
		return isDefective;
	}

	public void setIsDefective(Boolean isDefective) {
		this.isDefective = isDefective;
	}

	public LocalDate getReturnedAt() {
		return returnedAt;
	}
	
	public void setReturnedAt(LocalDate returnedAt) {
		this.returnedAt = returnedAt;
	}
	
	public String getReturnedNotes() {
		return returnedNotes;
	}
	
	public void setReturnedNotes(String returnedNotes) {
		this.returnedNotes = returnedNotes;
	}
}
