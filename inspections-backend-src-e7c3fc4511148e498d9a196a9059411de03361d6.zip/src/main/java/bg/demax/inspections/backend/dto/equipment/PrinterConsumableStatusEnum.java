package bg.demax.inspections.backend.dto.equipment;

public enum PrinterConsumableStatusEnum {
	SENT, INSTALLED, REPORTED, RETURNED
}