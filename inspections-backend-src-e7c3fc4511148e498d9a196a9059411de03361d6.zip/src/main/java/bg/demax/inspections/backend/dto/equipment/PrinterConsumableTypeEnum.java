package bg.demax.inspections.backend.dto.equipment;

public enum PrinterConsumableTypeEnum {
	CARTRIDGE, DRUM
}
