package bg.demax.inspections.backend.dto.equipment;

public class SimCardResponseDto extends HardwareDeviceLightResponseDto {

	private String msisdn = null;
	private String imsi = null;
	
	public String getMsisdn() {
		return msisdn;
	}
	
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	
	public String getImsi() {
		return imsi;
	}
	
	public void setImsi(String imsi) {
		this.imsi = imsi;
	}
}
