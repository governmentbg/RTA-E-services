package bg.demax.inspections.backend.dto.inspections;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DepriveOfRightsVo {

	private int permitVersionIdToReturn;
	private List<Integer> permitNumbers;
}
