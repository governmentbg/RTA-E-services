package bg.demax.inspections.backend.dto.inspections;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DetectedChangesDto extends DetectedChangesOnlyValuesDto {

	private String additionalId;
	private String additionalInfo;
	
	public DetectedChangesDto() {
		super();
	}

	public DetectedChangesDto(String newValue, String oldValue, String additionalId, String additionalInfo) {
		super(newValue, oldValue);
		this.additionalId = additionalId;
		this.additionalInfo = additionalInfo;
	}
	
}
