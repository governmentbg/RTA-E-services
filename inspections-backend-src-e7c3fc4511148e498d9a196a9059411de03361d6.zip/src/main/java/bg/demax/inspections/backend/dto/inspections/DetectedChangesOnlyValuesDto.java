package bg.demax.inspections.backend.dto.inspections;

import org.springframework.lang.Nullable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DetectedChangesOnlyValuesDto {

	@Nullable
	private String newValue;
	
	@Nullable
	private String oldValue;
	
}
