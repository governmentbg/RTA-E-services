package bg.demax.inspections.backend.dto.inspections;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EducationLevelDto {
	private Short code;
	private String description;
	private Boolean isValid;
}
