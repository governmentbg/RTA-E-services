package bg.demax.inspections.backend.dto.inspections;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitInspectionDto {

	private int id;
	private LocalDate inspectionDate;
	private String inspectionProtocolNumber;
	private String inspectionPaymentNumber;
	private LocalDate inspectionProtocolDate;
	private Boolean isFeePaid;
	private Boolean conclusion;
}
