package bg.demax.inspections.backend.dto.inspections;

import java.util.List;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitOrgUnitEikDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitInspectorExceptionDto {

	private String error;
	private String message;
	private List<PermitOrgUnitEikDto> permits;
}
