package bg.demax.inspections.backend.dto.inspections;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PermitInspectorIdWithReason {

	@NotNull
	private Integer id;

	@NotBlank
	@Size(max = 250)
	private String reason;

}
