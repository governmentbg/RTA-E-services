package bg.demax.inspections.backend.dto.inspections;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import bg.demax.inspections.backend.enums.DetectedChangesCode;
import bg.demax.techinsp.entity.PermitInspectorStatus;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitInspectorVersionChangesDto {

	private Map<DetectedChangesCode, DetectedChangesDto> infoChanges = new HashMap<DetectedChangesCode, DetectedChangesDto>();
	private Map<Integer, Map<DetectedChangesCode, DetectedChangesDto>> documentChanges 
																= new HashMap<Integer, Map<DetectedChangesCode, DetectedChangesDto>>();
	private Map<DetectedChangesCode, List<DetectedChangesDto>> certificationChanges 
																= new HashMap<DetectedChangesCode, List<DetectedChangesDto>>();

	public boolean isEmpty() {
		return this.infoChanges.isEmpty() && this.documentChanges.isEmpty();
	}

	public boolean hasExcludedInspector() {
		DetectedChangesDto changes = this.infoChanges.get(DetectedChangesCode.PERMIT_INSPECTOR_EDIT_STATUS);
		if (changes != null && changes.getNewValue().equals(PermitInspectorStatus.EXCLUDED.getCode())) {
			return true;
		}
		return false;
	}

	public boolean hasNewDocuments() {
		for (Map.Entry<Integer, Map<DetectedChangesCode, DetectedChangesDto>> entry : this.documentChanges.entrySet()) {
			if (entry.getValue().get(DetectedChangesCode.PERMIT_INSPECTOR_ADD_DOCUMENT) != null) {
				return true;
			}
		}
		return false;
	}
}
