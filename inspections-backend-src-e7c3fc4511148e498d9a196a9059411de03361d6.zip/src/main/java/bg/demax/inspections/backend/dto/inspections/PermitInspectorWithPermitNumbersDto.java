package bg.demax.inspections.backend.dto.inspections;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitInspectorWithPermitNumbersDto {

	private Integer id;
	private String fullName;
	private String identityNumber;
	private Boolean isChairman;
	private String statusCode;
	private List<Integer> permitNumbers;
	
}
