package bg.demax.inspections.backend.dto.inspections;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitRejectionDto {

	private String reason;
	private LocalDate date;
	private String filename;
}
