package bg.demax.inspections.backend.dto.inspections;

import java.util.Map;

import bg.demax.inspections.backend.enums.DetectedChangesCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermitVersionChangesDto {

	private Map<DetectedChangesCode, DetectedChangesOnlyValuesDto> permitInfoChanges;
	private Map<Integer, PermitInspectorVersionChangesDto> inspectorChanges;
	private Map<Integer, Map<DetectedChangesCode, DetectedChangesDto>> documentChanges;
	private Map<Integer, Map<DetectedChangesCode, DetectedChangesOnlyInfoDto>> lineChanges;
	private Map<Integer, Map<DetectedChangesCode, DetectedChangesOnlyValuesDto>> inspectionChanges;

	public boolean isEmpty() {
		return isMapEmpty(this.permitInfoChanges) && isMapEmpty(this.inspectorChanges) && isMapEmpty(this.documentChanges)
						&& isMapEmpty(lineChanges) && isMapEmpty(inspectionChanges);
	}

	public boolean inspectorChangesContainsAny(DetectedChangesCode... codes) {
		if (isMapEmpty(this.inspectorChanges)) {
			return false;
		}
		for (Map.Entry<Integer, PermitInspectorVersionChangesDto> entry : this.inspectorChanges.entrySet()) {
			for (DetectedChangesCode code : codes) {
				if (entry.getValue().getInfoChanges().get(code) != null) {
					return true;
				}
			}
		}
		return false;
	}

	public boolean inspectorChangesHaveExcluded() {
		if (isMapEmpty(this.inspectorChanges)) {
			return false;
		}
		for (Map.Entry<Integer, PermitInspectorVersionChangesDto> entry : this.inspectorChanges.entrySet()) {
			if (entry.getValue().hasExcludedInspector()) {
				return true;
			}
		}
		return false;
	}

	public boolean documentChangesContainsAny(DetectedChangesCode... codes) {
		if (isMapEmpty(this.documentChanges)) {
			return false;
		}
		for (Map.Entry<Integer, Map<DetectedChangesCode, DetectedChangesDto>> entry : this.documentChanges.entrySet()) {
			for (DetectedChangesCode code : codes) {
				if (entry.getValue().get(code) != null) {
					return true;
				}
			}
		}
		return false;
	}

	public boolean lineChangesContainsAny(DetectedChangesCode... codes) {
		if (isMapEmpty(this.lineChanges)) {
			return false;
		}
		for (Map.Entry<Integer, Map<DetectedChangesCode, DetectedChangesOnlyInfoDto>> entry : this.lineChanges.entrySet()) {
			for (DetectedChangesCode code : codes) {
				if (entry.getValue().get(code) != null) {
					return true;
				}
			}
		}
		return false;
	}

	private <K, V> boolean isMapEmpty(Map<K, V> map) {
		return map == null || map.isEmpty();
	}

}
