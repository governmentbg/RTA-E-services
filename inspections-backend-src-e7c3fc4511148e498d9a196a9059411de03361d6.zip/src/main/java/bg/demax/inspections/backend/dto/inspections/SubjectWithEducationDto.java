package bg.demax.inspections.backend.dto.inspections;

import bg.demax.specialist.registry.common.dto.user.SubjectLightDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubjectWithEducationDto extends SubjectLightDto {

	private Long subjectVersionId;
	private EducationLevelDto educationLevel;
	private String categories;

}
