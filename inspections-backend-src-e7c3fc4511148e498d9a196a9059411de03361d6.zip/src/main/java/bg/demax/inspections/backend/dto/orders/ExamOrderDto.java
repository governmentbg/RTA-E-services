package bg.demax.inspections.backend.dto.orders;

import java.time.LocalDateTime;
import java.util.List;

import bg.demax.inspections.backend.dto.BillOfLadingDto;

public class ExamOrderDto {

	private long id;
	private LocalDateTime orderCreationDate;
	private String receptionCityName;
	private String receptionCityType;
	private String receptionAddress;
	private String receptionPersonName;
	private String receptionPersonPhoneNumber;
	private BillOfLadingDto billOfLadingDto;

	private String statusCode;
	private String accountantName;
	private String accountantCode;
	private LocalDateTime invoiceDateTime;
	private String invoiceNumber;
	
	private boolean hasBankStatement;
	
	private ExamOrderCustomerDto examOrderCustomerDto;
	private List<OrderItemDto> examOrderItemDtos;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public LocalDateTime getOrderCreationDate() {
		return orderCreationDate;
	}

	public void setOrderCreationDate(LocalDateTime orderCreationDate) {
		this.orderCreationDate = orderCreationDate;
	}

	public String getReceptionCityName() {
		return receptionCityName;
	}

	public void setReceptionCityName(String receptionCityName) {
		this.receptionCityName = receptionCityName;
	}

	public String getReceptionCityType() {
		return receptionCityType;
	}

	public void setReceptionCityType(String receptionCityType) {
		this.receptionCityType = receptionCityType;
	}

	public String getReceptionAddress() {
		return receptionAddress;
	}

	public void setReceptionAddress(String receptionAddress) {
		this.receptionAddress = receptionAddress;
	}

	public String getReceptionPersonName() {
		return receptionPersonName;
	}

	public void setReceptionPersonName(String receptionPersonName) {
		this.receptionPersonName = receptionPersonName;
	}

	public String getReceptionPersonPhoneNumber() {
		return receptionPersonPhoneNumber;
	}

	public void setReceptionPersonPhoneNumber(String receptionPersonPhoneNumber) {
		this.receptionPersonPhoneNumber = receptionPersonPhoneNumber;
	}

	public String getStatusCode() {
		return this.statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getAccountantName() {
		return accountantName;
	}

	public void setAccountantName(String accountantName) {
		this.accountantName = accountantName;
	}

	public String getAccountantCode() {
		return accountantCode;
	}

	public void setAccountantCode(String accountantCode) {
		this.accountantCode = accountantCode;
	}

	public LocalDateTime getInvoiceDateTime() {
		return invoiceDateTime;
	}

	public void setInvoiceDateTime(LocalDateTime invoiceDateTime) {
		this.invoiceDateTime = invoiceDateTime;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public ExamOrderCustomerDto getExamOrderCustomerDto() {
		return examOrderCustomerDto;
	}

	public void setExamOrderCustomerDto(ExamOrderCustomerDto examOrderCustomerDto) {
		this.examOrderCustomerDto = examOrderCustomerDto;
	}

	public List<OrderItemDto> getExamOrderItemDtos() {
		return examOrderItemDtos;
	}

	public void setExamOrderItemDtos(List<OrderItemDto> examOrderItemDtos) {
		this.examOrderItemDtos = examOrderItemDtos;
	}

	public boolean isHasBankStatement() {
		return hasBankStatement;
	}

	public void setHasBankStatement(boolean hasBankStatement) {
		this.hasBankStatement = hasBankStatement;
	}

	public BillOfLadingDto getBillOfLadingDto() {
		return billOfLadingDto;
	}

	public void setBillOfLadingDto(BillOfLadingDto billOfLadingDto) {
		this.billOfLadingDto = billOfLadingDto;
	}
}
