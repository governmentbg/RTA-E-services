package bg.demax.inspections.backend.dto.orders;

import java.time.LocalDateTime;
import java.util.List;

public class ExamOrderLightDto {
	private long id;
	private LocalDateTime createdAt;
	private String companyName;
	private String eik;
	private int permitNumber;
	private String statusCode;
	private String receptionCityName;
	private String receptionAddress;
	private List<OrderItemLightDto> orderItems;

	public String getReceptionCityName() {
		return receptionCityName;
	}

	public void setReceptionCityName(String receptionCityName) {
		this.receptionCityName = receptionCityName;
	}

	public String getReceptionAddress() {
		return receptionAddress;
	}

	public void setReceptionAddress(String receptionAddress) {
		this.receptionAddress = receptionAddress;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getEik() {
		return eik;
	}

	public void setEik(String eik) {
		this.eik = eik;
	}

	public int getPermitNumber() {
		return permitNumber;
	}

	public void setPermitNumber(int permitNumber) {
		this.permitNumber = permitNumber;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public List<OrderItemLightDto> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(List<OrderItemLightDto> orderItems) {
		this.orderItems = orderItems;
	}

}
