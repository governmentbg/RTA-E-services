package bg.demax.inspections.backend.dto.orders;

public interface IInterval {
	long getFromNum();
	
	long getToNum();
	
	default long getQuantity() {
		return getToNum() - getFromNum() + 1;
	}
}
