package bg.demax.inspections.backend.dto.orders;

import java.math.BigDecimal;
import java.util.List;

import bg.demax.inspections.backend.dto.BillOfLadingDto;
import bg.demax.inspections.backend.dto.OrgUnitLightDto;

public class InspectionBillOfLadingDto extends BillOfLadingDto {

	private String recipient;
	private String contactPersonName;
	private String contactPersonPhoneNumber;
	private String shippingAddress;
	private OrgUnitLightDto orgUnit = null;
	private List<InspectionDeliveryProtocolLightDto> protocols;
	private Integer packageCount;
	private BigDecimal weight;
	

	public String getRecipient() {
		return recipient;
	}

	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactPersonPhoneNumber() {
		return contactPersonPhoneNumber;
	}

	public void setContactPersonPhoneNumber(String contactPersonPhoneNumber) {
		this.contactPersonPhoneNumber = contactPersonPhoneNumber;
	}

	public String getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public OrgUnitLightDto getOrgUnit() {
		return orgUnit;
	}

	public void setOrgUnit(OrgUnitLightDto orgUnit) {
		this.orgUnit = orgUnit;
	}

	public List<InspectionDeliveryProtocolLightDto> getProtocols() {
		return protocols;
	}

	public void setProtocols(List<InspectionDeliveryProtocolLightDto> protocols) {
		this.protocols = protocols;
	}

	public Integer getPackageCount() {
		return packageCount;
	}

	public void setPackageCount(Integer packageCount) {
		this.packageCount = packageCount;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}
}
