package bg.demax.inspections.backend.dto.orders;

import java.math.BigDecimal;
import java.util.List;

import bg.demax.inspections.backend.dto.BillOfLadingDto;
import bg.demax.inspections.backend.dto.OrgUnitLightDto;

public class InspectionDeliveryProtocolBillOfLadingLightDto extends BillOfLadingDto {
	
	private OrgUnitLightDto orgUnit = null;
	private List<Long> protocols = null;
	private Integer packageCount = null;
	private BigDecimal weight = null;

	public OrgUnitLightDto getOrgUnit() {
		return orgUnit;
	}

	public void setOrgUnit(OrgUnitLightDto orgUnit) {
		this.orgUnit = orgUnit;
	}

	public List<Long> getProtocols() {
		return protocols;
	}

	public void setProtocols(List<Long> protocols) {
		this.protocols = protocols;
	}

	public Integer getPackageCount() {
		return packageCount;
	}

	public void setPackageCount(Integer packageCount) {
		this.packageCount = packageCount;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}
}
