package bg.demax.inspections.backend.dto.orders;

import java.util.List;

public class InspectionDeliveryProtocolDto extends InspectionDeliveryProtocolMediumDto {
	private List<InspectionOrderLightDto> orders;

	public List<InspectionOrderLightDto> getOrders() {
		return orders;
	}

	public void setOrders(List<InspectionOrderLightDto> orders) {
		this.orders = orders;
	}
}
