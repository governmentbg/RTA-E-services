package bg.demax.inspections.backend.dto.orders;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class InspectionDeliveryProtocolLightDto {
	private long id;
	private LocalDateTime creationTimestamp;
	private String billOfLadingIdForCourier;
	private Long itemsCount;
	private BigDecimal weight;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public LocalDateTime getCreationTimestamp() {
		return creationTimestamp;
	}

	public void setCreationTimestamp(LocalDateTime creationTimestamp) {
		this.creationTimestamp = creationTimestamp;
	}

	public String getBillOfLadingIdForCourier() {
		return billOfLadingIdForCourier;
	}

	public void setBillOfLadingIdForCourier(String billOfLading) {
		this.billOfLadingIdForCourier = billOfLading;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public Long getItemsCount() {
		return itemsCount;
	}

	public void setItemsCount(Long itemsCount) {
		this.itemsCount = itemsCount;
	}

}
