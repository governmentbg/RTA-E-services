package bg.demax.inspections.backend.dto.orders;

public class InspectionDeliveryProtocolMediumDto extends InspectionDeliveryProtocolLightDto {
	private String orgUnitName;
	private Integer ordersCount;


	public String getOrgUnitName() {
		return orgUnitName;
	}

	public void setOrgUnitName(String orgUnitName) {
		this.orgUnitName = orgUnitName;
	}

	public Integer getOrdersCount() {
		return ordersCount;
	}

	public void setOrdersCount(Integer ordersCount) {
		this.ordersCount = ordersCount;
	}
}
