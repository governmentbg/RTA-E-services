package bg.demax.inspections.backend.dto.orders;

import java.time.LocalDateTime;

import bg.demax.inspections.backend.dto.BillOfLadingDto;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class InspectionOrderDto extends InspectionOrderLightDto {

	private String activationCode;
	private String accountantCode;
	private String accountantName;
	private Boolean hasBankStatement;
	private String invoiceAddress;
	private LocalDateTime invoiceDateTime;
	private Long invoiceNumber;
	private String managerName;
	private String receptionAddress;
	private String receptionPhone;
	private String vatNumber;
	private WeightAndWeightOffsetDto desiredWeightAndWeightOffset;
	
	private BillOfLadingDto billOfLadingDto;
	
}
