package bg.demax.inspections.backend.dto.orders;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InspectionOrderLightDto {

	private List<OrderItemDto> orderItems;

	private long id;
	private LocalDateTime createdAt;
	private String receptionName;
	private String companyName;
	private String eik;
	private Integer permitNumber;
	private String managerPhoneNumber;
	private String statusCode;
	private Long quantity;
	private BigDecimal weight;

}
