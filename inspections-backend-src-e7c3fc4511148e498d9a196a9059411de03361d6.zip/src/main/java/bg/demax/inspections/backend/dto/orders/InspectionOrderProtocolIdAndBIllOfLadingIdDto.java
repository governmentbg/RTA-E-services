package bg.demax.inspections.backend.dto.orders;

public class InspectionOrderProtocolIdAndBIllOfLadingIdDto {

	private Long protocolId;

	private Integer billOfLadingId;

	public Long getProtocolId() {
		return protocolId;
	}
	
	public void setProtocolId(Long protocolId) {
		this.protocolId = protocolId;
	}
	
	public Integer getBillOfLadingId() {
		return billOfLadingId;
	}

	public void setBillOfLadingId(Integer billOfLadingId) {
		this.billOfLadingId = billOfLadingId;
	}
}
