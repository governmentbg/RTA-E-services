package bg.demax.inspections.backend.dto.orders;

import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InspectionOrderReportListItemDto {

	private long id; 
	private Integer permitNumber;
	private String companyName;
	private String orgUnit;
	private LocalDateTime orderDateTime;
	private LocalDateTime activationDateTime;
	private Long invoiceNumber;
	private LocalDate invoiceDate;
	private String status;
	private boolean hasBankStatement;
}
