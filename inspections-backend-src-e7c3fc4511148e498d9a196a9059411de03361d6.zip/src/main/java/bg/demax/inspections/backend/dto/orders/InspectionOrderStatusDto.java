package bg.demax.inspections.backend.dto.orders;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InspectionOrderStatusDto {

	private String code;
	private String description;
}
