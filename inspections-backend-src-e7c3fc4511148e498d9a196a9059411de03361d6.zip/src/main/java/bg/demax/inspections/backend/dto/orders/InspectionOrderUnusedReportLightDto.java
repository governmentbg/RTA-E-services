package bg.demax.inspections.backend.dto.orders;

import java.time.LocalDateTime;

public class InspectionOrderUnusedReportLightDto {

	private Long id;
	private LocalDateTime createdAt;
	private LocalDateTime activatedAt;
	private Long quantity;
	private Integer unusedStickers;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getActivatedAt() {
		return activatedAt;
	}
	
	public void setActivatedAt(LocalDateTime activatedAt) {
		this.activatedAt = activatedAt;
	}
	
	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}
	
	public Integer getUnusedStickers() {
		return unusedStickers;
	}
	
	public void setUnusedStickers(Integer unusedStickers) {
		this.unusedStickers = unusedStickers;
	}
}
