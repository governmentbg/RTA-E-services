package bg.demax.inspections.backend.dto.orders;

import java.util.List;

import bg.demax.inspections.backend.dto.OrgUnitLightDto;

public class InspectionOrderUnusedStickersReportDto {

	private Integer permitNumber;
	private OrgUnitLightDto orgUnit;
	private String ktpName;
	private List<InspectionOrderUnusedReportLightDto> orders;
	private Integer totalUnusedStickers;

	public Integer getPermitNumber() {
		return permitNumber;
	}

	public void setPermitNumber(Integer permitNumber) {
		this.permitNumber = permitNumber;
	}

	public OrgUnitLightDto getOrgUnit() {
		return orgUnit;
	}

	public void setOrgUnit(OrgUnitLightDto orgUnit) {
		this.orgUnit = orgUnit;
	}

	public String getKtpName() {
		return ktpName;
	}

	public void setKtpName(String ktpName) {
		this.ktpName = ktpName;
	}

	public List<InspectionOrderUnusedReportLightDto> getOrders() {
		return orders;
	}

	public void setOrders(List<InspectionOrderUnusedReportLightDto> orders) {
		this.orders = orders;
	}

	public Integer getTotalUnusedStickers() {
		return totalUnusedStickers;
	}

	public void setTotalUnusedStickers(Integer totalUnusedStickers) {
		this.totalUnusedStickers = totalUnusedStickers;
	}

}
