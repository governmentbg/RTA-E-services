package bg.demax.inspections.backend.dto.orders;

import bg.demax.inspections.backend.exception.IntervalConflictException;

public class Interval implements IInterval {
	private long fromNum;
	private long toNum;
	
	public Interval(long fromNum, long toNum) {
		this.fromNum = fromNum;
		
		if (this.fromNum > toNum) {
			throw new IntervalConflictException("fromNum must be smaller or equal to toNum");
		}
		
		this.toNum = toNum;
	}

	public long getFromNum() {
		return fromNum;
	}

	public long getToNum() {
		return toNum;
	}
}
