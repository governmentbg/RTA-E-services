package bg.demax.inspections.backend.dto.orders;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderItemDto {
	private Long id;
	private Long fromNum;
	private Long toNum;
	private Long quantity;
	private long productId;
	private String productName;
	private List<Long> productQuantityOptions;
}
