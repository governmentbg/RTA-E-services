package bg.demax.inspections.backend.dto.orders;

public class OrderStatusDto {
	private String code;
	private String desctiption;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesctiption() {
		return desctiption;
	}

	public void setDesctiption(String desctiption) {
		this.desctiption = desctiption;
	}

}
