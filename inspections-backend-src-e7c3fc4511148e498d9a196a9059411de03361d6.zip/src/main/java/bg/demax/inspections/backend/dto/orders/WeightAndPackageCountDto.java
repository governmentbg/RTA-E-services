package bg.demax.inspections.backend.dto.orders;

import java.math.BigDecimal;

public class WeightAndPackageCountDto {
	private BigDecimal weight;
	private int packageCount;

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public int getPackageCount() {
		return packageCount;
	}

	public void setPackageCount(int packageCount) {
		this.packageCount = packageCount;
	}
}