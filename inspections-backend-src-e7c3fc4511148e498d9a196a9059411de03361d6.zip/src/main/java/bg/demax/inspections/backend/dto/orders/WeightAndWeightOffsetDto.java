package bg.demax.inspections.backend.dto.orders;

import java.math.BigDecimal;

public class WeightAndWeightOffsetDto {
	private BigDecimal weight;
	private BigDecimal weightOffset;

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public BigDecimal getWeightOffset() {
		return weightOffset;
	}

	public void setWeightOffset(BigDecimal weightOffset) {
		this.weightOffset = weightOffset;
	}

}
