package bg.demax.inspections.backend.dto.techinsp;

public class CamRequestLightDto {
	private Integer feedNum;
	private Integer resolution;
	private String statusCode;

	public Integer getFeedNum() {
		return feedNum;
	}

	public void setFeedNum(Integer feedNum) {
		this.feedNum = feedNum;
	}

	public Integer getResolution() {
		return resolution;
	}

	public void setResolution(Integer resolution) {
		this.resolution = resolution;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
}
