package bg.demax.inspections.backend.dto.techinsp;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import bg.demax.inspections.backend.dto.techinsp.permit.PermitDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DashboardInspectorCertificationDto {
	
	private Integer id;
	private String docNumber;
	private String docType;
	private LocalDate reissueOn;
	private String subjectIdentityNumber;
	private String subjectFullName;
	private String statusCode;
	private String categories;
	private String inspectionTypes;
	private List<PermitDto> permits = new ArrayList<>();

	
}
