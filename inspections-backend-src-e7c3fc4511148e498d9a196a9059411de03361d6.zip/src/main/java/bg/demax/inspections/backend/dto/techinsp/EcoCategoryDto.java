package bg.demax.inspections.backend.dto.techinsp;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EcoCategoryDto {

	private String code;
	private String description;
	
}
