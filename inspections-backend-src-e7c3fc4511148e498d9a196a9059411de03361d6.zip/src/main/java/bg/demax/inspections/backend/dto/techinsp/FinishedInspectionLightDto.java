package bg.demax.inspections.backend.dto.techinsp;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FinishedInspectionLightDto extends InspectionLightDto {
	private LocalDateTime inspectionEndTime;
	private Long protocolNumber;
	private Long hologramNumber;
	private String conclusion;
	private String status;
	private Boolean isSuspicious;
	private String shortVideoUrl;

}
