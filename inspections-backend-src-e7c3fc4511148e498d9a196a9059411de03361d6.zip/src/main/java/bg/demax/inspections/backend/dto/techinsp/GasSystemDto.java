package bg.demax.inspections.backend.dto.techinsp;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GasSystemDto {

	private String statusCode = null;
	private String fuelType = null;
	private String tankMake = null;
	private String installerFullName = null;
	private String tankNumberOfApproval = null;
	private String tankSerialNumber = null;
	private Short tankYearOfProduction = null;

}
