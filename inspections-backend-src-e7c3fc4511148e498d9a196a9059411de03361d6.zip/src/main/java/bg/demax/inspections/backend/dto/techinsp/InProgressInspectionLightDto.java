package bg.demax.inspections.backend.dto.techinsp;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InProgressInspectionLightDto extends InspectionLightDto {
	private String fuelType;
	private String chairman;
	private Boolean isSuspicious;
}
