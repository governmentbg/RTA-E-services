package bg.demax.inspections.backend.dto.techinsp;

import bg.demax.pub.entity.OrgUnit;
import bg.demax.techinsp.entity.InspectionConclusion;

public class InspectionCountForVehicleReport {
	private OrgUnit orgUnit;
	private String registrationNumber;
	private String makeAndModel;
	private Long inspectionsCount;
	private InspectionConclusion conclusion;

	public InspectionCountForVehicleReport(OrgUnit orgUnit, String registrationNumber, String makeAndModel,
			Long inspectionsCount, InspectionConclusion conclusion) {
		this.orgUnit = orgUnit;
		this.registrationNumber = registrationNumber;
		this.makeAndModel = makeAndModel;
		this.inspectionsCount = inspectionsCount;
		this.conclusion = conclusion;
	}

	public OrgUnit getOrgUnit() {
		return orgUnit;
	}

	public void setOrgUnit(OrgUnit orgUnit) {
		this.orgUnit = orgUnit;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public String getMakeAndModel() {
		return makeAndModel;
	}

	public void setMakeAndModel(String makeAndModel) {
		this.makeAndModel = makeAndModel;
	}

	public Long getInspectionsCount() {
		return inspectionsCount;
	}

	public void setInspectionsCount(Long inspectionsCount) {
		this.inspectionsCount = inspectionsCount;
	}

	public InspectionConclusion getConclusion() {
		return conclusion;
	}

	public void setConclusion(InspectionConclusion conclusion) {
		this.conclusion = conclusion;
	}
}
