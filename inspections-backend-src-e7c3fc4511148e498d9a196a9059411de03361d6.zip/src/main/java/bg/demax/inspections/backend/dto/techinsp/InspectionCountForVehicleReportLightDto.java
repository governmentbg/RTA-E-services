package bg.demax.inspections.backend.dto.techinsp;

import bg.demax.techinsp.entity.InspectionConclusion;

public class InspectionCountForVehicleReportLightDto {
	
	private String registrationNumber;
	private String makeAndModel;
	private InspectionConclusion conclusion;
	private Integer inspectionsCount;

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public String getMakeAndModel() {
		return makeAndModel;
	}

	public void setMakeAndModel(String makeAndModel) {
		this.makeAndModel = makeAndModel;
	}

	public InspectionConclusion getConclusion() {
		return conclusion;
	}

	public void setConclusion(InspectionConclusion conclusion) {
		this.conclusion = conclusion;
	}

	public Integer getInspectionsCount() {
		return inspectionsCount;
	}

	public void setInspectionsCount(Integer inspectionsCount) {
		this.inspectionsCount = inspectionsCount;
	}
}
