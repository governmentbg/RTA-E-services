package bg.demax.inspections.backend.dto.techinsp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import bg.demax.inspections.backend.dto.techinsp.permit.line.PermitLineOrgUnitDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InspectionDto {

	private Long id = null;
	private String statusCode = null;
	private PermitLineOrgUnitDto permit = null;
	private RoadVehicleDto vehicle = null;
	private String personName = null;
	private String personEgn = null;
	private String chairmanName = null;
	private String memberName = null;
	private Long protocolNumber = null;
	private Long hologramNumber = null;
	private InspectionTypeDto type = null;
	private String conclusionCode = null;
	private LocalDateTime startedAt = null;
	private LocalDateTime finishedAt = null;
	private LocalDate validTo = null;
	private String stopReason = null;
	private boolean isSuspicious = false;
	private Boolean hasSecondaryInspection = false;
	private Boolean hasCisternProtocol = false;
	private Boolean hasSemt = false;
	private SemtDetailsDto semt = null;
	private GasSystemDto gasSystem = null;

	private SecondaryInspectionDto secondaryInspection = null;

	private String shortVideoUrl;
	private String snapShotUrl;

	private List<TaxCheckResultDto> taxCheckResults = null;

	private List<InspectionFaultDto> faults = null;

}
