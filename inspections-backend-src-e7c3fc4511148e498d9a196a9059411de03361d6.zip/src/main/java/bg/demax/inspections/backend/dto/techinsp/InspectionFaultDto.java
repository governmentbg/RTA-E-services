package bg.demax.inspections.backend.dto.techinsp;

import java.util.LinkedList;
import java.util.List;

public class InspectionFaultDto {

	private Long elementId = null;
	private String descIndex = null;
	private String description = null;
	private String cardinality = null;

	private String value = null;
	private String checkValue = null;

	private List<InspectionFaultDto> children = new LinkedList<>();

	public InspectionFaultDto(Long elementId, String descIndex, String description, String cardinality, String value, String checkValue) {
		this.elementId = elementId;
		this.descIndex = descIndex;
		this.description = description;
		this.cardinality = cardinality;
		this.value = value;
		this.checkValue = checkValue;
	}

	public Long getElementId() {
		return elementId;
	}

	public void setElementId(Long elementId) {
		this.elementId = elementId;
	}

	public String getDescIndex() {
		return descIndex;
	}

	public void setDescIndex(String descIndex) {
		this.descIndex = descIndex;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCardinality() {
		return cardinality;
	}

	public void setCardinality(String cardinality) {
		this.cardinality = cardinality;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCheckValue() {
		return checkValue;
	}

	public void setCheckValue(String checkValue) {
		this.checkValue = checkValue;
	}

	public List<InspectionFaultDto> getChildren() {
		return children;
	}

	public void setChildren(List<InspectionFaultDto> children) {
		this.children = children;
	}

	public static enum InspectionFaultCardinality {
		SIGNIFICANT, INSIGNIFICANT, DANGEROUS
	}
}
