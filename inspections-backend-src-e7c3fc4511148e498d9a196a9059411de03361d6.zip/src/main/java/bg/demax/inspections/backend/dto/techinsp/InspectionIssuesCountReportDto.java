package bg.demax.inspections.backend.dto.techinsp;

import bg.demax.techinsp.entity.InspectionCheckValue;
import bg.demax.techinsp.entity.InspectionElementCardinality;

public class InspectionIssuesCountReportDto {

	private String inspectionElementDescription;
	private InspectionCheckValue inspectionCheckValue;
	private InspectionElementCardinality inspectionElementCardinality;
	private Long inspectionsCount;

	public InspectionIssuesCountReportDto(String inspectionElementDescription,
			InspectionCheckValue inspectionCheckValue, InspectionElementCardinality inspectionElementCardinality,
			Long inspectionsCount) {
		this.inspectionElementDescription = inspectionElementDescription;
		this.inspectionCheckValue = inspectionCheckValue;
		this.inspectionElementCardinality = inspectionElementCardinality;
		this.inspectionsCount = inspectionsCount;
	}

	public String getInspectionElementDescription() {
		return inspectionElementDescription;
	}

	public void setInspectionElementDescription(String inspectionElementDescription) {
		this.inspectionElementDescription = inspectionElementDescription;
	}

	public InspectionCheckValue getInspectionCheckValue() {
		return inspectionCheckValue;
	}

	public void setInspectionCheckValue(InspectionCheckValue inspectionCheckValue) {
		this.inspectionCheckValue = inspectionCheckValue;
	}

	public InspectionElementCardinality getInspectionElementCardinality() {
		return inspectionElementCardinality;
	}

	public void setInspectionElementCardinality(InspectionElementCardinality inspectionElementCardinality) {
		this.inspectionElementCardinality = inspectionElementCardinality;
	}

	public Long getInspectionsCount() {
		return inspectionsCount;
	}

	public void setInspectionsCount(Long inspectionsCount) {
		this.inspectionsCount = inspectionsCount;
	}
}
