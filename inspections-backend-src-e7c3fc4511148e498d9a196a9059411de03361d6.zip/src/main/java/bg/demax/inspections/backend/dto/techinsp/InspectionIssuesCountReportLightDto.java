package bg.demax.inspections.backend.dto.techinsp;

public class InspectionIssuesCountReportLightDto {

	private String inspectionElementDescription;
	private String inspectionCheckValue;
	private String inspectionElementCardinality;
	private Long inspectionsCount;

	public String getInspectionElementDescription() {
		return inspectionElementDescription;
	}

	public void setInspectionElementDescription(String inspectionElementDescription) {
		this.inspectionElementDescription = inspectionElementDescription;
	}

	public String getInspectionCheckValue() {
		return inspectionCheckValue;
	}

	public void setInspectionCheckValue(String inspectionCheckValue) {
		this.inspectionCheckValue = inspectionCheckValue;
	}

	public String getInspectionElementCardinality() {
		return inspectionElementCardinality;
	}

	public void setInspectionElementCardinality(String inspectionElementCardinality) {
		this.inspectionElementCardinality = inspectionElementCardinality;
	}

	public Long getInspectionsCount() {
		return inspectionsCount;
	}

	public void setInspectionsCount(Long inspectionsCount) {
		this.inspectionsCount = inspectionsCount;
	}
}
