package bg.demax.inspections.backend.dto.techinsp;

import java.util.List;

import bg.demax.inspections.backend.export.report.InspectionIssuesCountReportRow;

public class InspectionIssuesCountReportRequestDto {
	private String title;
	private List<InspectionIssuesCountReportRow> rows;
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<InspectionIssuesCountReportRow> getRows() {
		return rows;
	}
	
	public void setRows(List<InspectionIssuesCountReportRow> rows) {
		this.rows = rows;
	}
}
