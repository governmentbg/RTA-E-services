package bg.demax.inspections.backend.dto.techinsp;

import java.time.LocalDateTime;

import bg.demax.inspections.backend.dto.OrgUnitLightDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InspectionLightDto {
	private Long id;
	private String statusCode = null;
	private LocalDateTime inspectionStartTime;
	private Integer ktpNumber;
	private Short line;
	private OrgUnitLightDto orgUnit;
	private String registrationNumber;
	private String inspectionType;
	private String vehicleMake;
	private String category;
	private boolean hasSemt;
	private Boolean hasSecondaryInspection = false;

	private SecondaryInspectionDto secondaryInspection;
}
