package bg.demax.inspections.backend.dto.techinsp;

public class InspectionLiveStreamSetupResponseDto {
	private String restreamAddress;
	private Boolean isAsf;
	private CamRequestLightDto camRequest;

	public String getRestreamAddress() {
		return restreamAddress;
	}

	public void setRestreamAddress(String restreamAddress) {
		this.restreamAddress = restreamAddress;
	}

	public Boolean getIsAsf() {
		return isAsf;
	}

	public void setIsAsf(Boolean isAsf) {
		this.isAsf = isAsf;
	}

	public CamRequestLightDto getCamRequest() {
		return camRequest;
	}

	public void setCamRequest(CamRequestLightDto camRequest) {
		this.camRequest = camRequest;
	}

}
