namespace("demax.inspections");

demax.inspections.Application = function() {

	this.run = function() {
		demax.inspections.logger = function(msg) {
			console.log(msg);
		};

		demax.inspections.settings = {
			momentDateFormat: "DD.MM.YYYY г.",
			momentDateTimeFormat: "DD.MM.YYYYг. HH:mmч.",
			momentTimeFormat: "HH:mmч.",
			serverDateFormat: "YYYY-MM-DD",
			serverDateTimeFormat: "YYYY-MM-DD HH:MM",
			serverTimeFormat: "HH:mm",
			peripheralDevicesServerAddress: "https://demax-admin-local-server:8082"
		};

		demax.inspections.utils.DocumentUtil.init();

		demax.inspections.logger("running demax.inspections app");
		demax.inspections.authenticatedUser = ko.observable(new demax.inspections.model.User());
		demax.inspections.events = new pastel.util.EventQueue();

		var ajaxClient = new pastel.web.AjaxRestClient();
		var blobClient = new pastel.plus.util.blob.BlobClient();

		demax.inspections.ajaxClient = ajaxClient;
		demax.inspections.restClient = new pastel.plus.util.rc.PastelRcWrapper(ajaxClient);
		demax.inspections.blobClient = new pastel.plus.util.rc.BlobClientWrapper(blobClient);
		blobClient.addAfterExecutionInterceptor(attachErrorHandler);

		demax.inspections.popupManager = setUpPopupManager(new demax.inspections.utils.SimplePopupManager());

		setupAjax(ajaxClient);
		setupCustomBindings();
		setupKoValidation();
		setupCustomFunctions();
		setupMoment();
		setupCustomBindings();
		setupCustomComponents();

		ajaxClient.getResource("api/users/current").done(function(resp) {
			demax.inspections.authenticatedUser(new demax.inspections.model.User(resp));
			var layoutVM = new demax.inspections.viewmodel.LayoutVM();
			layoutVM.init();
			ko.applyBindings(layoutVM);
			var router = setupRouter(ajaxClient);
			demax.inspections.router = router;
			setupRouterListeners(demax.inspections.router);
			demax.inspections.router.startRouting();
		}).fail(function() {
			window.location.href = "login.html";
		});
	};

	function setupMoment() {
		pastel.moment.MomentHelper.registerJacksonPlugin();
	}

	function setupCustomFunctions() {
		ko.observableArray.fn.find = function(prop, data) {
			var valueToMatch = data[prop]; 
			return ko.utils.arrayFirst(this(), function(item) {
				return item[prop] === valueToMatch; 
			});
		};
		ko.extenders.upperCase = function(target) {
			target.subscribe(function(newValue) {
				target(newValue.toUpperCase());
			});
			return target;
		};
	}

	function setupKoValidation() {
		ko.validation.init({
			insertMessages: false,
			errorsAsTitle: false,
			errorElementClass: "has-error",
			errorClass: "has-error",
			grouping: {
				deep: true,
				observable: true,
				live: true
			}
		});

		ko.validation.rules["dateIsAfter"] = {
			validator: function (endDate, startDate) {
				return endDate.format(demax.inspections.settings.serverDateFormat) > startDate.format(demax.inspections.settings.serverDateFormat);
			},
			message: function (endDate) {
				return "Тази дата трябва да е след " + endDate.format(demax.inspections.settings.momentDateFormat);
			}
		};

		ko.validation.rules["dateIsAfterOrEqual"] = {
			validator: function (endDate, startDate) {
				return endDate.format(demax.inspections.settings.serverDateFormat) >= startDate.format(demax.inspections.settings.serverDateFormat);
			},
			message: function (endDate) {
				return "Тази дата трябва да е равна или след " + endDate.format(demax.inspections.settings.momentDateFormat);
			}
		};

		ko.validation.rules["isAdult"] = {
			validator: function (age) {
				return demax.inspections.utils.ValidatorUtil.validateBirthDate(age);
			},
			message: function () {
				var now = moment().subtract(18, "years");
				return "Лицето трябва да бъде с навършени 18 години. Въведете дата на раждане преди " 
					+ now.format(demax.inspections.settings.momentDateFormat);
			}
		};

		ko.validation.rules["isBirthDateLegitIfPersonHasEgn"] = {
			validator: function (birthDate, params) {
				if (params.country() && params.country().code === "BGR" && params.egn()) {
					var dateFromEgn = demax.inspections.utils.GeneralUtil.convertIdentityNumberToDate(params.egn());
					var dateFromEgnString = moment(dateFromEgn, "YYYYMMDD").format(demax.inspections.settings.momentDateFormat);
					var birthDateString = birthDate.format(demax.inspections.settings.momentDateFormat);
					return (dateFromEgnString === birthDateString);
				}
				return false;
			},
			message: function () {
				return "Датата на раждане от ЕГН трябва да съвпада с въведената дата на раждане.";
			}
		};

		ko.validation.rules["dateInterval"] = {
			validator: function (val, params) {
				var startDate = moment(val);
				var endDate = params.endDate;
				var interval = params.interval;
				return startDate.add(interval, "months") >= endDate();
			},

			message: function (params) {
				return "Интервалът между началната и крайната дата трябва да е най-много " + params.interval + " месеца!";
			}
		};

		ko.validation.rules["identityNumber"] = {
			validator: function (val) {
				return (demax.inspections.utils.ValidatorUtil.validateEgn(val));
			},
			message: "Моля, въведете валидно ЕГН."
		};

		ko.validation.rules["isFirstOrFamilyNameCyrillicUpperCaseWithDashesSpacesOrApotrophes"] = {
			validator: function (name) {
				var regex = new RegExp("^[А-Я]+((\u0020)?(('|-|.)?([А-Я])+))*$");
				return regex.test(name);
			},
			message: "Името може да съдържа само главни букви от кирилицата и трябва да започва и завършва с буква."
		};

		ko.validation.rules["isSurnameNullOrCyrillicUpperCaseWithDashesSpacesOrApotrophes"] = {
			validator: function (name) {
				if (name === null || name === undefined || name.trim().length < 1) {
					return true;
				}
				var regex = new RegExp("^[А-Я]+((\u0020)?(('|-|.)?([А-Я])+))*$");
				return regex.test(name);
			},
			message: "Презимето може да е празно или да съдържа само главни букви от кирилицата и трябва да започва и завършва с буква."
		};
		
		ko.validation.rules["eicNumber"] = {
			validator: function (val) {
				return demax.inspections.utils.ValidatorUtil.validateEic(val);
			},
			message: "Моля, въведете валидно ЕИК/Булстат."
		};

		ko.validation.rules["doubleNumberValidation"] = {
			validator: function (val) {
				var regex = new RegExp("[0-9\u0020\u002C\u002F\u003B]");
				return regex.test(val);
			},
			message: "Моля, въведете до 2 номера, разделени със ',', '/' или ';' без да използвате ' '."
		};

		ko.validation.registerExtenders();

		ko.validation.rules.digit.message = "Моля, въведете цифра.";
		ko.validation.rules.number.message = "Моля, въведете число.";
		ko.validation.rules.required.message = "Полето е задължително.";
		ko.validation.rules.min.message = "Минималната допустима стойност е {0}.";
		ko.validation.rules.maxLength.message = "Моля, въведете до {0} символа.";
		ko.validation.rules.minLength.message = "Моля, въведете {0} или повече символа.";
		ko.validation.rules.pattern.message = "Невалиден формат на данни.";
	}

	function setupCustomBindings() {
		pastel.knockout.KnockoutHelper.registerLibraryBindings();

		// overwrites pastel moment binding
		var DemaxAdminMomentBinding = function() {
			pastel.plus.binding.MomentPlusBinding.call(this, {
				format: demax.inspections.settings.momentDateFormat
			});
			var update = this.update;

			this.update = function(element, valueAccessor) {
				update(element, valueAccessor);
				var $element = $(element);
				if (!$element.text() || $element.text() === "") {
					$element.text("-");
				}
			};
		};

		ko.bindingHandlers.moment = new DemaxAdminMomentBinding();

		ko.bindingHandlers.hasAnyRole = new pastel.plus.binding.HasAnyRoleBinding(demax.inspections.authenticatedUser);

		// overwrites pastel datetime picker binding
		var DemaxAdminDateTimePickerBinding = function(options) {
			pastel.plus.binding.DateTimePickerBinding.call(this, options);
			var init = this.init;

			this.init = function(element, valueAccessor, allBindingsAccessor) {
				init(element, valueAccessor, allBindingsAccessor);
				var $input = $(element).find("input");
				$input.attr("placeholder", "-");
			};
		};

		ko.bindingHandlers.dateTimePicker = new DemaxAdminDateTimePickerBinding();
		ko.bindingHandlers.futureDateTimePicker = new DemaxAdminDateTimePickerBinding({
			allowInputToggle: true,
			locale: "bg",
			format: "DD.MM.YYYY",
			useCurrent: false
		});
		ko.bindingHandlers.dateRangePicker = new pastel.plus.binding.dateRangePicker.DateRangePickerBinding({
			locale:"bulgarian"
		});
		ko.bindingHandlers.quill = new demax.inspections.binding.Quill();
		ko.bindingHandlers.fileInput = new demax.inspections.binding.FileInput();
		ko.bindingHandlers.fancybox = new demax.inspections.binding.FancyBoxBinding();
		ko.bindingHandlers.permitNumbersTags = new demax.inspections.binding.MessagePermitNumbersTagsBinding();
	}

	function setupAjax(pastelRestClient) {
		jQuery.ajaxSettings.traditional = true;

		pastelRestClient.addInterceptor({
			lastAjaxOptions: null,
			beforeExecution: function(ajaxOptions) {
				this.lastAjaxOptions = ajaxOptions;
			},
			afterExecution: function(promise) {
				attachErrorHandler(promise, this.lastAjaxOptions);
			}
		});

		pastelRestClient.addInterceptor({
			beforeExecution: function(options) {
				if (options.method === "GET") {
					return;
				}

				var csrfToken = Cookies.get("_csrf");
				options.headers = {
					"X-CSRF-TOKEN": csrfToken
				};
			}
		});
	}

	function attachErrorHandler(promise, ajaxOptions) {
		var popupManager = demax.inspections.popupManager;
		promise.errorHandlers = {
			Exception: function() {
				popupManager.error("Възникна непредвидена грешка");
				demax.inspections.logger("An exception was thrown.");
			},
			IncorrectPasswordException: function() {
				popupManager.error("Грешна парола");
			},
			NoAuthorityException: function() {
				popupManager.error("Нямате права за това действие.");
			},
			BillOfLadingCreationException: function(message) {
				popupManager.error("Проблем при създаването на товарителница при свързването с куриера. \n Грешка: " + message);
			},
			BillOfLadingPdfException: function(message) {
				popupManager.error("Проблем при взимането на pdf-а на товарителницата от куриера. \n Грешка: " + message);
			},
			MissingSystemVariableException: function (message) {
				demax.inspections.logger("MissingSystemVariableException: " + message);
				popupManager.error("Системен проблем. Моля, свържете се с поддъжката.");
			},
			NoValidPermitsFoundForOrgUnitException: function() {
				popupManager.error("Не са намерени активни разрешения за избрания областен отдел.");
			},
			MissingCourierAccountForUser: function() {
				popupManager.error("Нямате куриерски акаунт за този доставчик.");
			},
			MessageAttachmentTooBigException: function(message, error) {
				popupManager.error("Прикаченият файл '" + error.attachmentFileName
					+ "' e по-голям от максимално разрешения размер за прикачени файлове - " + error.maxAttachmentSizeKB + "KB.");
			},
			CannotAddDocumentToClosedPermit: function() {
				popupManager.error("Не можете да добавите документ към вече закрито Разрешение.");	
			},
			NoSuchEntityException: function(message) {
				if (message.indexOf("OrgUnit") > -1) {
					popupManager.error("Не е намерена организационната единица.");
				} else if (message.indexOf("Courier") > -1) {
					popupManager.error("Не е намерен избраният куриер.");
				} else if (message.indexOf("CourierServiceType") > -1) {
					popupManager.error("Не е намерен избраният тип на доставка.");
				} else if (message.indexOf("InspectionDeliveryProtocol") > -1) {
					popupManager.error("Не е намерен избраният протокол.");
				} else if (message.indexOf("ExamOrder") > -1) {
					popupManager.error("Поръчката не е намерена.");
				} else if (message.indexOf("InspectionOrder") > -1) {
					popupManager.error("Не е намерена поръчката за комплект за прегледи.");
				} else if (message.indexOf("InspectionProduct") > -1) {
					popupManager.error("не е намерен такъв продукт за преглед.");
				} else if (message.indexOf("User") > -1) {
					popupManager.error("Не е намерен такъв потребител.");
				} else if (message.indexOf("InspectionDeliveryProtocolBillOfLading") > -1) {
					popupManager.error("Не е намерена такава товарителница за комплекти за технически преглед.");
				} else if (message.indexOf("BillOfLading") > -1) {
					popupManager.error("Не е намерена такава товарителница.");
				} else if (message.indexOf("Permit") > -1) {
					popupManager.error("Не е намерено такова Разрешение.");
				} else if (message.indexOf("AppliedDocumentType") > -1) {
					popupManager.error("Не е намерено такъв тип Разрешение.");
				}
			},
			HardwareDeviceIsAtInspectionStationException: function(error, errorObject) {
				if (errorObject.deviceId) {
					demax.inspections.popupManager.error("Устройство със сериен номер " + errorObject.serialNumber
						+ " се намира в пункт за прегледи.");
				} else if (errorObject.simCardId) {
					demax.inspections.popupManager.error("Сим карта със сериен номер " + errorObject.serialNumber
						+ " се намира в пункт за прегледи.");
				}
			},
			HardwareDeviceIsNotAtWarehouseTsarigradskoShoseException: function(error, errorObject) {
				if (errorObject.deviceId) {
					demax.inspections.popupManager.error("Устройство със сериен номер " + errorObject.serialNumber
						+ " не се намира в София Цариградско шосе голям или малък склад.");
				} else if (errorObject.simId) {
					demax.inspections.popupManager.error("Сим карта със сериен номер " + errorObject.serialNumber
						+ " не се намира в София Цариградско шосе голям или малък склад.");
				}
			},
			InvalidHardwareDeviceLocationException: function(error, errorObject) {
				if (errorObject.deviceId) {
					demax.inspections.popupManager.error("Устройство със сериен номер " + errorObject.serialNumber
						+ " има невалидно местоположение!");
				} else if (errorObject.simCardId) {
					demax.inspections.popupManager.error("Сим карта със сериен номер " + errorObject.serialNumber
						+ " има невалидно местоположение!");
				}
			},
			BillOfLadingRequestSpeedyOrEcontInSameCityException: function() {
				demax.inspections.popupManager.error("Не може да бъде създадена заявка към Спиди или Еконт за град София!");
			},
			InvalidPermitStatusException: function() {
				demax.inspections.popupManager.error("Разрешението има грешен статус");
			},
			PermitIsNotLastValidVersion: function () {
				demax.inspections.popupManager.error("Разрешението не е последната валидна версия.");
			},
			NoRightsForOrgUnitException: function() {

				popupManager.customError({
					cssClass: "popError",
					message: "Нямате право на достъп до данни на този Областен Отдел!",
					okButtonCss: "btn-primary"
				}).done(function () {
					window.history.back();
					
				});

				// demax.inspections.popupManager.error("Нямате право на достъп до данни на този Областен Отдел!");
			}
		};

		promise.handleErrors = function(handledErrors) {
			$.extend(promise.errorHandlers, handledErrors);
			return promise;
		};
		promise.fail(function(xhr) {
			var isStatusDueToNoAuthorityException = xhr.responseJSON !== undefined
				&& xhr.responseJSON.error !== undefined && (xhr.responseJSON.error == "NoAuthorityException" 
					|| xhr.responseJSON.error == "NoRightsForOrgUnitException");
			if (xhr.status === 403 && !isStatusDueToNoAuthorityException) {
				var currentUser = demax.inspections.authenticatedUser();
				if (currentUser.roles.length > 0) {
					demax.inspections.popupManager.warn("Сесията ви е изтекла. Моля, влезте наново.").done(function() {
						window.location.href = "login.html";
					});
				} else {
					window.location.href = "login.html";
				}
			} else if (xhr.responseJSON !== undefined && xhr.responseJSON.error !== undefined) {
				var error = xhr.responseJSON.error;

				if ($.isFunction(promise.errorHandlers[error])) {
					promise.errorHandlers[error](xhr.responseJSON.message, xhr.responseJSON);
				} else {
					demax.inspections.logger("An unhandled error has occured.");
				}
				demax.inspections.logger("Error details: " + JSON.stringify(ajaxOptions));
			} else {
				if ((xhr.status === 0 && xhr.statusText !== "abort") || xhr.status >= 502) {
					demax.inspections.popupManager.error("Няма връзка със сървъра. Моля, опитайте пак по-късно или се свържете с администратор.");
					demax.inspections.logger("Lost connection");
					return;
				}
			}
		});
		return promise;
	}

	function setupRouter(pastelRestClient) {
		var router = new pastel.routing.Router();
		registerRoutes(router);

		var binderListener = new pastel.routing.KnockoutBinderListener({
			contentHolder: "#content"
		});

		binderListener.setRestClient(pastelRestClient);

		router.addListener(binderListener);

		return router;
	}

	function setupRouterListeners(router) {
		router.addListener(new pastel.plus.util.SecurityRouterListener({
			user: demax.inspections.authenticatedUser,
			onUnautherizedAccess: function() {
				demax.inspections.popupManager.warn("Нямате права за достъп до тази страница")
					.always(function() {
						window.history.back();
					});
			}
		}));

		router.addListener({
			onRouteChange: function(route) {
				// args: route, parameters, router

				setTimeout(function() {
					setupNewBoxWidgetElements();
				}, 100);

				demax.inspections.events.publish(demax.inspections.Event.ROUTE_CHANGED, route);
			}

		});

		function setupNewBoxWidgetElements() {
			$(".box").each(function() {
				$.fn.boxWidget.call($(this));
			});
		}
	}

	function setUpPopupManager(popupManager) {
		popupManager.info = function(message) {
			var settings = {
				type: "alert",
				okButtonText: "Добре",
				okButtonCss: "btn-default",
				title: "Внимание",
				message: message,
				cssClass: "popInfo"
			};

			return popupManager.addPopupToQue(settings);
		};

		popupManager.error = function(message) {
			var settings = {
				type: "alert",
				okButtonText: "Добре",
				okButtonCss: "btn-default",
				title: "Грешка",
				message: message,
				cssClass: "popError"
			};

			return popupManager.addPopupToQue(settings);
		};

		popupManager.customError = function(options) {
			var settings = $.extend({
				type: "alert",
				okButtonText: "Добре",
				okButtonCss: "btn-default",
				title: "Грешка",
				message: "",
				cssClass: "popError"
			}, options);

			return popupManager.addPopupToQue(settings);
		};

		popupManager.warn = function(message) {
			var settings = {
				type: "alert",
				okButtonText: "Добре",
				okButtonCss: "btn-default",
				title: "Внимание",
				message: message,
				cssClass: "popWarning"
			};

			return popupManager.addPopupToQue(settings);
		};

		popupManager.showInfo = function(options) {
			var settings = $.extend({}, {
				type: "alert",
				okButtonText: "Добре",
				okButtonCss: "btn-default",
				title: "Информация",
				message: "",
				cssClass: "popInfo"
			}, options);

			return popupManager.addPopupToQue(settings);
		};

		popupManager.success = function(options) {
			var settings = $.extend({}, {
				type: "alert",
				okButtonText: "Добре",
				okButtonCss: "btn-default",
				title: "Готово!",
				message: "",
				cssClass: "popSuccess"
			}, options);
			return popupManager.addPopupToQue(settings);
		};

		popupManager.confirm = function(options) {
			var settings = $.extend({}, {
				type: "confirm",
				okButtonText: "Да",
				okButtonCss: "btn-default",
				cancelButtonText: "Не",
				title: "Внимание",
				message: "",
				cssClass: "popWarning"
			}, options);

			return popupManager.addPopupToQue(settings);
		};

		popupManager.prompt = function(options) {
			var settings = $.extend({}, {
				type: "prompt",
				isDateInput: false,
				okButtonText: "Запази",
				okButtonCss: "btn-success",
				cancelButtonText: "Откажи",
				title: "Попълнете",
				message: "",
				cssClass: "popInfo"
			}, options);

			return popupManager.addPopupToQue(settings);
		};

		popupManager.form = function(options) {
			var settings = $.extend({}, {
				type: "form",
				okButtonText: "Запази",
				okButtonCss: "btn-success",
				cancelButtonText: "Откажи",
				title: "Попълнете",
				message: "",
				cssClass: "popInfo"
			}, options);

			return popupManager.addPopupToQue(settings);
		};

		return popupManager;
	}


	function setupCustomComponents() {
		ko.components.loaders.unshift(new pastel.knockout.AjaxComponentTemplateLoader());

		ko.components.register("paginator", {
			viewModel: pastel.plus.component.pagination.Paginator,
			template: {
				url: "./bower_components/pastel-plus/dist/plugin-body/component/pagination/template/paginator.html"
			}
		});

		ko.components.register("small-paginator", {
			viewModel: pastel.plus.component.pagination.Paginator,
			template: {
				url: "views/components/small-paginator.html"
			}
		});

		ko.components.register("loader", {
			template: {
				url: "views/components/loader.html"
			}
		});

		ko.components.register("no-table-entries", {
			template: {
				url: "views/components/no-table-entries.html"
			}
		});

		ko.components.register("page-not-found", {
			template: {
				url: "views/components/page-not-found.html"
			}
		});

		ko.components.register("protocol-print-button", {
			viewModel: demax.inspections.component.ProtocolPrintButtonComponent,
			template: {
				url: "views/components/protocol-print-button.html"
			}
		});

		ko.components.register("supervisor-details", {
			viewModel: demax.inspections.component.SupervisorDetailsComponent,
			template: {
				url: "views/components/supervisor-details.html"
			}
		});

		ko.components.register("intervals", {
			viewModel: demax.inspections.component.IntervalsComponent,
			template: {
				url: "views/components/intervals.html"
			}
		});
		ko.components.register("delivery-details", {
			viewModel: demax.inspections.component.DeliveryTransferComponent,
			template: {
				url: "views/components/delivery-details.html"
			}
		});
		ko.components.register("choose-courier", {
			viewModel: demax.inspections.component.ChooseCourierComponent,
			template: {
				url: "views/components/choose-courier.html"
			}
		});

		ko.components.register("back-button", {
			template: {
				url: "views/components/back-button.html"
			}
		});

		ko.components.register("weight-measure", {
			viewModel: demax.inspections.component.WeightMeasureComponent,
			template: {
				url: "views/components/weight-measure.html"
			}
		});

		ko.components.register("page-is-forbidden", {
			template: {
				url: "views/components/page-is-forbidden.html"
			}
		});

		ko.components.register("inspection-side-menu", {
			template: {
				url: "views/components/inspection-side-menu.html"
			}
		});

		ko.components.register("inspection-bill-of-lading-details", {
			template: {
				url: "views/components/inspection-bill-of-lading-details.html"
			}
		});

		ko.components.register("ajax-autocomplete", {
			viewModel: demax.inspections.component.AjaxAutocomplete,
			template: {
				url: "views/components/ajax-autocomplete.html"
			}
		});

		ko.components.register("permit-details", {
			template: {
				url: "views/components/permit-details.html"
			}
		});

		ko.components.register("permit-company-details", {
			template: {
				url: "views/components/permit-company-details.html"
			}
		});

		ko.components.register("fuzzy-finder", {
			viewModel: pastel.plus.component.FuzzyFinder,
			template: {
				url: "./bower_components/pastel-plus/dist/plugin-body/component/fuzzy-finder/template/fuzzy-finder.html"
			}
		});

		ko.components.register("redirect", {
			template: {
				url: "views/components/redirect.html"
			}
		});
	}

	function registerRoutes(router) {
		var Group = demax.inspections.nomenclature.Group;
		var Role = demax.inspections.nomenclature.Role;

		var viewsDir = "views/";
		var ordersViewsDir = viewsDir + "orders/";
		var techinspViewsDir = viewsDir + "techinsp/";
		var equipmentViewsDir = viewsDir + "equipment/";
		var consumableViewsDir = equipmentViewsDir + "consumable/";
		var permitViewDir = viewsDir + "permits/";
		var hardwareViewsDir = equipmentViewsDir + "hardware/";
		var problemViewsDir = viewsDir + "problems/";
		var inspectorsViewDir = permitViewDir + "inspectors/";
		var linesViewDir = permitViewDir + "lines/";
		var reportsViewDir = permitViewDir + "reports/";

		var ordersVms = demax.inspections.viewmodel.orders;
		var techinspVms = demax.inspections.viewmodel.techinsp;
		var equipmentVms = demax.inspections.viewmodel.equipment;
		var hardwareVms = equipmentVms.hardware;
		var consumableVms = equipmentVms.consumable;
		var permitVms = demax.inspections.viewmodel.permits;
		var problemVms = demax.inspections.viewmodel.problems;
		var inspectorVms = demax.inspections.viewmodel.permits.inspectors;
		var reportsVms = demax.inspections.viewmodel.permits.reports;

		var idRule = {
			id: /[0-9]+/
		};

		var CC_IAAA_RDAA_CONTROL_ROLES = [Role.CALL_CENTER, Role.TECHINSP_IAAA, Role.TECHINSP_INSP_RDAA, Role.TECHINSP_CHILD_ORG_UNIT_INSPECTOR];

		router.redirect("", demax.inspections.authenticatedUser().landingPage);

		router.addRoute({
			url: "page-is-forbidden",
			view: viewsDir + "page-is-forbidden.html",
			viewModel: demax.inspections.viewmodel.PageIsForbiddenVM
		});
		//in the future we might want to prefix these routes with orders/
		var ordersRoutes = {
			url: "",
			children: [
				{
					url: "inspection-order-protocol/{id}",
					view: ordersViewsDir + "inspection-order-protocol-view.html",
					viewModel: ordersVms.InspectionOrderProtocolVM,
					rules: idRule,
					access: Group.PACKAGING_INSPECTIONS
				},

				{
					url: "inspection-order-protocols-list",
					view: ordersViewsDir + "inspection-order-protocols-list-view.html",
					viewModel: ordersVms.InspectionOrderProtocolsListVM,
					access: Group.PACKAGING_INSPECTIONS
				},

				{
					url: "inspection-order/{id}",
					view: ordersViewsDir + "inspection-order-view.html",
					viewModel: ordersVms.InspectionOrderVM,
					rules: idRule,
					access: Group.PACKAGING_INSPECTIONS
				},

				{
					url: "inspection-orders-list",
					view: ordersViewsDir + "inspection-orders-list-view.html",
					viewModel: ordersVms.InspectionOrdersListVM,
					access: Group.PACKAGING_INSPECTIONS
				},

				{
					url: "inspection-orders-packaging",
					view: ordersViewsDir + "inspection-orders-packaging-view.html",
					viewModel: ordersVms.InspectionOrdersPackagingVM,
					access: Group.INSPECTION_PROTOCOL_HANDLER
				},

				{
					url: "bills-of-lading-list",
					view: ordersViewsDir + "bills-of-lading-list-view.html",
					viewModel: ordersVms.BillsOfLadingListVM,
					access: Group.INSPECTION_BOL_HANDLER
				},

				{
					url: "create-bill-of-lading",
					view: ordersViewsDir + "create-bill-of-lading-view.html",
					viewModel: ordersVms.CreateBillOfLadingVM,
					access: Group.INSPECTION_BOL_HANDLER
				},

				{
					url: "bill-of-lading/{id}",
					view: ordersViewsDir + "bill-of-lading-view.html",
					viewModel: ordersVms.InspectionBillOfLadingVM,
					rules: idRule,
					access: Group.INSPECTION_BOL_HANDLER
				},

				{
					url: "exam-order/{id}",
					view: ordersViewsDir + "exam-order-view.html",
					viewModel: ordersVms.ExamOrderVM,
					rules: idRule,
					access: Group.PACKAGING_VOUCHERS
				},

				{
					url: "exam-orders-list",
					view: ordersViewsDir + "exam-orders-list-view.html",
					viewModel: ordersVms.ExamOrdersListVM,
					access: Group.PACKAGING_VOUCHERS
				}
			]
		};

		var hardwareRoutes = {
			url: "hardware",
			access: [Role.CALL_CENTER],
			children: [
				{
					url: "devices",
					view: hardwareViewsDir + "device-list.html",
					viewModel: hardwareVms.DeviceListVM
				},

				{
					url: "devices/new",
					view: hardwareViewsDir + "add-hardware.html",
					viewModel: hardwareVms.AddHardwareVM
				},

				{
					url: "devices/edit/{id}/{code}",
					view: hardwareViewsDir + "edit-hardware.html",
					viewModel: hardwareVms.EditHardwareVM,
					rules: idRule
				},

				{
					url: "devices/receive",
					view: hardwareViewsDir + "receive-hardware.html",
					viewModel: hardwareVms.ReceiveHardwareVM
				},

				{
					url: "device-transfers",
					view: hardwareViewsDir + "requests-list.html",
					viewModel: hardwareVms.RequestsListVM
				},

				{
					url: "device-transfers/new",
					view: hardwareViewsDir + "new-device-transfer.html",
					viewModel: hardwareVms.DeviceTransferCreationVM
				},

				{
					url: "device-transfers/{id}",
					view: hardwareViewsDir + "view-request.html",
					viewModel: hardwareVms.ViewRequestVM
				}
			]
		};


		var consumableRoutes = {
			url: "consumables",
			access: [Role.CALL_CENTER],
			children: [

				{
					url: "supplies",
					view: consumableViewsDir + "list.html",
					viewModel: consumableVms.ConsumablesListVM
				},

				{
					url: "supplies/{id}",
					view: consumableViewsDir + "open.html",
					viewModel: consumableVms.ConsumableOpenVM,
					rules: idRule
				},

				{
					url: "requests",
					view: consumableViewsDir + "requests-list.html",
					viewModel: consumableVms.RequestsListVM
				},

				{
					url: "requests/new",
					view: consumableViewsDir + "request-new.html",
					viewModel: consumableVms.CreateRequestVM
				},

				{
					url: "requests/{id}",
					view: consumableViewsDir + "request-open.html",
					viewModel: consumableVms.RequestOpenVM,
					rules: idRule
				}
			]
		};

		var permitRoutes = {
			url: "permits",
			access: CC_IAAA_RDAA_CONTROL_ROLES,
			children: [
				{
					url: "",
					view: permitViewDir + "permit-list.html",
					viewModel: permitVms.PermitListVM
				},
				{
					url: "details/{id}",
					rules: idRule,
					children: [
						{
							url: "company",
							view: permitViewDir + "edit-company.html",
							viewModel: permitVms.PermitCompanyVM,
							access: [Role.TECHINSP_INSP_RDAA]
						},
						{
							url: "",
							view: permitViewDir + "permit-details.html",
							viewModel: permitVms.PermitDetailsVM
						},
						{
							url: "documents/new",
							view: permitViewDir + "applied-document.html",
							viewModel: permitVms.AppliedDocumentVM,
							access: [Role.TECHINSP_INSP_RDAA]
						},
						{
							url: "documents/{docId}",
							view: permitViewDir + "applied-document.html",
							viewModel: permitVms.AppliedDocumentVM
						},
						{
							url: "deprive-of-rights",
							view: inspectorsViewDir + "deprive-inspectors-of-rights.html",
							viewModel: inspectorVms.DepriveInspectorsOfRightsVM
						},
						{
							url: "lines/new",
							view: linesViewDir + "permit-line.html",
							viewModel: permitVms.lines.PermitLineVM
						},
						{
							url: "lines/{lineId}",
							children: [
								{
									url: "",
									view: linesViewDir + "permit-line.html",
									viewModel: permitVms.lines.PermitLineVM
								},
								{
									url:"/hardware",
									view: linesViewDir + "permit-line-hardware.html",
									viewModel: permitVms.lines.PermitLineHardwareVM
								},
								{
									url:"/documents/new",
									view: linesViewDir + "line-applied-document.html",
									viewModel: permitVms.lines.LineAppliedDocumentVM
								},
								{
									url: "/documents/{documentId}",
									view: linesViewDir + "line-applied-document.html",
									viewModel: permitVms.lines.LineAppliedDocumentVM
								}
							]
						},
						{
							url: "inspectors/new",
							view: inspectorsViewDir + "inspector.html",
							viewModel: inspectorVms.InspectorVM
						},
						{
							url: "inspectors/{inspectorId}",
							children: [
								{
									url: "",
									view: inspectorsViewDir + "inspector.html",
									viewModel: inspectorVms.InspectorVM
								},
								{
									url: "documents/new",
									view: inspectorsViewDir + "inspector-document.html",
									viewModel: inspectorVms.InspectorCreateDocumentVM
								},
								{
									url: "documents/{documentId}",
									view: inspectorsViewDir + "inspector-document.html",
									viewModel: inspectorVms.InspectorCreateDocumentVM
								},
								{
									url: "stamps/new",
									view: inspectorsViewDir + "inspector-stamp.html",
									viewModel: inspectorVms.InspectorStampVM
								},
								{
									url: "stamps/{stampId}",
									view: inspectorsViewDir + "inspector-stamp.html",
									viewModel: inspectorVms.InspectorStampVM
								},
								{
									url: "certificates/{certificateId}",
									view: inspectorsViewDir + "preview-inspector-certificate.html",
									viewModel: inspectorVms.InspectorCertificatePreview
								},
								{
									url: "subjects/{subjectId}",
									children: [ 
										{
											url: "cards/new",
											view: inspectorsViewDir + "inspector-card.html",
											viewModel: inspectorVms.InspectorCardVM
										},
										{
											url: "cards/{cardId}",
											view: inspectorsViewDir + "inspector-card.html",
											viewModel: inspectorVms.InspectorCardVM
										}
									]
								}
							]
						}
					]
				},
				{
					url: "create",
					children: [
						{
							url: "",
							view: permitViewDir + "permit-create.html",
							viewModel: permitVms.PermitCreateVM,
							access: [Role.TECHINSP_INSP_RDAA]
						},
						{
							url: "company",
							view: permitViewDir + "edit-company.html",
							viewModel: permitVms.PermitCompanyVM,
							access: [Role.TECHINSP_INSP_RDAA]
						}
					]
				}
			]
		};

		var problemRoutes = {
			url: "problems",
			access: [Role.CALL_CENTER],
			children: [
				{
					url: "",
					view: problemViewsDir + "problem-list.html",
					viewModel: problemVms.ProblemsListVM
				},
				{
					url: "/add",
					view: problemViewsDir + "add-problem.html",
					viewModel: problemVms.AddProblemVM,
					access: [Role.CALL_CENTER]
				},
				{
					url: "/preview/{id}",
					view: problemViewsDir + "edit-problem.html",
					viewModel: problemVms.EditProblemVM,
					rules: idRule
				}
			]
		};

		var techinspRoutes = {
			url: "techinsp",
			children: [
				{
					url: "in-progress-inspections-list",
					view: techinspViewsDir + "in-progress-inspections-list.html",
					viewModel: techinspVms.InProgressInspectionsListVM,
					access: Group.INSPECTION_VIEWER
				},

				{
					url: ["in-progress-inspection/{id}", "finished-inspection/{id}"],
					view: techinspViewsDir + "inspection.html",
					viewModel: techinspVms.InspectionVM,
					rules: idRule,
					access: Group.INSPECTION_VIEWER
				},

				{
					url: "finished-inspections-list",
					view: techinspViewsDir + "finished-inspections-list.html",
					viewModel: techinspVms.FinishedInspectionsListVM,
					access: Group.FINISHED_INSPECTION_VIEWER
				},

				{
					url: "inspection/{id}/live-stream",
					view: techinspViewsDir + "inspection-live-stream-view.html",
					viewModel: techinspVms.InspectionLiveStreamVM,
					rules: idRule,
					access: Group.INSPECTION_VIEWER
				},

				{
					url: "online-computers-list",
					view: techinspViewsDir + "online-computers-list.html",
					viewModel: techinspVms.OnlineComputersListVM,
					access: [Role.CALL_CENTER]
				},

				{
					url: "reports",
					children: [
						{
							url: "inspections",
							view: techinspViewsDir + "reports.html",
							viewModel: techinspVms.ReportsVM,
							access: [Role.CALL_CENTER, Role.TECHINSP_IAAA]
						},
						{
							url: "permits",
							view: reportsViewDir + "permit-report.html",
							viewModel: reportsVms.PermitReportVM,
							access: CC_IAAA_RDAA_CONTROL_ROLES
						},
						{
							url: "permits-documents",
							view: reportsViewDir + "permit-documents-report.html",
							viewModel: reportsVms.PermitDocumentsReportVM,
							access: CC_IAAA_RDAA_CONTROL_ROLES
						},
						{
							url: "permits-lines",
							view: reportsViewDir + "permit-lines-report.html",
							viewModel: reportsVms.PermitLinesReportVM,
							access: CC_IAAA_RDAA_CONTROL_ROLES
						},
						{
							url: "permits-lines-documents",
							view: reportsViewDir + "permit-line-documents-report.html",
							viewModel: reportsVms.PermitLineDocumentsReportVM,
							access: CC_IAAA_RDAA_CONTROL_ROLES
						},
						{
							url: "permits-inspectors",
							view: reportsViewDir + "permit-inspectors-report.html",
							viewModel: reportsVms.PermitInspectorsReportVM,
							access: CC_IAAA_RDAA_CONTROL_ROLES
						},
						{
							url: "permits-inspectors-documents",
							view: reportsViewDir + "permit-inspector-documents-report.html",
							viewModel: reportsVms.PermitInspectorDocumentsReportVM,
							access: CC_IAAA_RDAA_CONTROL_ROLES
						},
						{
							url: "permits-subject-cards",
							view: reportsViewDir + "subject-cards-report.html",
							viewModel: reportsVms.SubjectCardsReportVM,
							access: [Role.CALL_CENTER, Role.TECHINSP_IAAA]
						},
						{
							url: "permits-orders",
							view: reportsViewDir + "inspection-orders-report.html",
							viewModel: reportsVms.InspectionOrderReportVM,
							access: [Role.CALL_CENTER, Role.ACCOUNTING, Role.SUPERVISOR]
						},
						{
							url: "permits-stickers",
							view: reportsViewDir + "stickers-report.html",
							viewModel: reportsVms.StickersReportVM,
							access: [Role.CALL_CENTER, Role.ACCOUNTING, Role.SUPERVISOR, Role.TECHINSP_IAAA]
						},
						{
							url: "html",
							view: reportsViewDir + "html-report.html",
							viewModel: reportsVms.HtmlReportVM,
							access: [Role.TECHINSP_IAAA]
						},
						{
							url: "logs",
							view: reportsViewDir + "logs-report.html",
							viewModel: reportsVms.LogsReportVM,
							access: [Role.CALL_CENTER, Role.TECHINSP_IAAA]
						}
					]
				},

				{
					url: "messages/sent",
					view: techinspViewsDir + "messages/sent.html",
					viewModel: techinspVms.messages.SentListVM,
					access: [Role.CALL_CENTER, Role.TECHINSP_MESSAGES_EDIT, Role.TECHINSP_MESSAGES_VIEW]
				},

				{
					url: ["messages/compose", "messages/compose/{id}"],
					view: techinspViewsDir + "messages/compose.html",
					viewModel: techinspVms.messages.ComposeVM,
					access: [Role.CALL_CENTER, Role.TECHINSP_MESSAGES_EDIT]
				},

				{
					url: "messages/sent/{id}/view",
					view: techinspViewsDir + "messages/view.html",
					viewModel: techinspVms.messages.ViewVM,
					access: [Role.CALL_CENTER, Role.TECHINSP_MESSAGES_EDIT, Role.TECHINSP_MESSAGES_VIEW]
				},

				{
					url: "messages/draft/{id}/view",
					view: techinspViewsDir + "messages/view.html",
					viewModel: techinspVms.messages.ViewVM,
					access: [Role.CALL_CENTER, Role.TECHINSP_MESSAGES_EDIT]
				},

				{
					url: "messages/draft",
					view: techinspViewsDir + "messages/draft.html",
					viewModel: techinspVms.messages.DraftListVM,
					access: [Role.CALL_CENTER, Role.TECHINSP_MESSAGES_EDIT]
				},

				{
					url: "videos",
					view: techinspViewsDir + "videos-list.html",
					viewModel: techinspVms.VideosListVM,
					access: CC_IAAA_RDAA_CONTROL_ROLES
				},

				{
					url: "diagnostics",
					view: techinspViewsDir + "diagnostics.html",
					viewModel: techinspVms.DiagnosticsVM,
					access: [Role.CALL_CENTER]
				},

				{
					url: "dashboard",
					view: techinspViewsDir + "dashboard.html",
					viewModel: techinspVms.DashboardVM,
					access: [Role.TECHINSP_IAAA, Role.TECHINSP_INSP_RDAA]
				}
			]
		};

		router.addRoute(ordersRoutes);
		router.addRoute(hardwareRoutes);
		router.addRoute(consumableRoutes);
		router.addRoute(techinspRoutes);
		router.addRoute(permitRoutes);
		router.addRoute(problemRoutes);
	}
};
