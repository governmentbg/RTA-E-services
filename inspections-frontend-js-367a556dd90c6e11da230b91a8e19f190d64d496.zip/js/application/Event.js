namespace("demax.inspections");

demax.inspections.Event = {
	ROUTE_CHANGED: "ROUTE_CHANGED",
	SET_ORDER_PAID: "SET_ORDER_PAID",
	KEYPRESS_ENTER: "KEYPRESS_ENTER",
	KEYPRESS_ESC: "KEYPRESS_ESC"
};
