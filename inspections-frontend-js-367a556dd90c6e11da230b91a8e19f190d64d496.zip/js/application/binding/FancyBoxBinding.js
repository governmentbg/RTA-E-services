namespace("demax.inspections.binding");

demax.inspections.binding.FancyBoxBinding = function() {

	this.init = function(element, valueAccessor) {
		var $element = $(element);
		var imageSrc = null;
		if (valueAccessor() && valueAccessor().imageSrc) {
			imageSrc = valueAccessor().imageSrc;
		}
		
		$element.on("click", function() {
			$.fancybox.open({
				src: imageSrc,
				defaultType: "image",
				smallBtn: "true",
				animationEffect: "fade",
				animationDuration: 200
			});			
		});
	};
};