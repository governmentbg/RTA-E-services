namespace("demax.inspections.binding");

demax.inspections.binding.FileInput = function() {

	this.init = function(element, valueAccessor) {

		var filesObservableArray = null;
		if (valueAccessor() && ko.isObservable(valueAccessor()) && $.isFunction(valueAccessor().destroyAll)) {
			filesObservableArray = valueAccessor();
		} else if (valueAccessor() && ko.isObservable(valueAccessor().filesObservableArray)
			&& $.isFunction(valueAccessor().filesObservableArray.destroyAll)) {
			filesObservableArray = valueAccessor().filesObservableArray;
		} else {
			throw new Error("Files observable array not specified");
		}

		var files = [];
		for (var i = 0; i < element.files.length; i++) {
			files.push(element.files[i]);
		}
		filesObservableArray(files);

		var $element = $(element);
		$element.on("change", function() {
			var files = [];
			for (var i = 0; i < element.files.length; i++) {
				files.push(element.files[i]);
			}
			filesObservableArray(files);
			element.value = "";
		});

		ko.utils.domNodeDisposal.addDisposeCallback(element, function() {
			$element.off("change");
		});
	};
};
