namespace("demax.inspections.binding");

demax.inspections.binding.MessagePermitNumbersTagsBinding = function() {

	this.init = function(element, valueAccessor) {
		var $element = $(element);
		var permits = valueAccessor();
		var restClient = demax.inspections.restClient;

		$element.tagsinput({
			confirmKeys: [13, 44, 32]
		});

		// stop propagation because popUp is listening for ENTER and immediately closes (Close button of popUp won't be functional)
		$element.tagsinput("input").parent().parent().on("keyup", function(event) {
			event.stopPropagation();
		});
		
		for (var i = 0; i < permits().length; i++) {
			$element.tagsinput("add", permits()[i], { skipValidation: true });
		}

		$element.on("itemAdded", function(event) {
			permits.push(event.options.permitDto);
		});
		
		$element.on("itemRemoved", function(event) {
			permits(permits().filter(function(permit) {
				return permit.number != event.item;
			}));
		});

		$element.on("beforeItemAdd", function(event) {

			if (event.options && event.options.skipValidation) {
				return;
			}

			event.cancel = true;

			if (!/^[1-9][0-9]*$/.test(event.item)) {
				demax.inspections.popupManager.error("Невалиден номер").done(focus);
				return;
			}

			restClient.getResource("api/permits/by-number/" + event.item)
				.done(function(permitDto) {
					$element.tagsinput("add", event.item, { skipValidation: true, permitDto: permitDto });
				}).handleErrors({
					PermitIsNotValidException: function() {
						demax.inspections.popupManager.error("Невалидно разрешение").done(focus);
					},
					NoSuchEntityException: function() {
						demax.inspections.popupManager.error("Не е намерено такова Разрешение").done(focus);
					}
				});
		});

		function focus() {
			$element.tagsinput("focus");
		}
	};
};
