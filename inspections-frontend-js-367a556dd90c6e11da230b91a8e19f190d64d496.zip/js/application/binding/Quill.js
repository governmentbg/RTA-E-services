namespace("demax.inspections.binding");

demax.inspections.binding.Quill = function() {
	var subscriptions = [];
	var editor = null;

	this.init = function(element, valueAccessor) {
		var contentClipboardSelector = null;
		if (valueAccessor() && valueAccessor().contentClipboardSelector) {
			contentClipboardSelector = valueAccessor().contentClipboardSelector;
		}

		var toolbarSelector = null;
		if (valueAccessor() && valueAccessor().toolbarSelector) {
			toolbarSelector = valueAccessor().toolbarSelector;
		}

		var options = {
			theme: "snow",
			modules: {
				toolbar: (toolbarSelector ? toolbarSelector : [[{ "header": [1, 2, 3, false] }],
					["bold", "italic", "underline", "strike"],
					[{ "list": "ordered"}, { "list": "bullet" }]])
			}
		};
		editor = new window.Quill(element, options);

		var htmlObservable = null;
		if (valueAccessor() && valueAccessor().htmlObservable && ko.isObservable(valueAccessor().htmlObservable)) {
			htmlObservable = valueAccessor().htmlObservable;
			var initialHtmlObservableChangeSubscription = htmlObservable.subscribe(function() {
				if (initialHtmlObservableChangeSubscription != null) {
					initialHtmlObservableChangeSubscription.dispose();
					initialHtmlObservableChangeSubscription = null;
					setClipboardTextFromHtml();
				}
			});
			setClipboardTextFromHtml();

			$(contentClipboardSelector).click(function() {
				setClipboardTextFromHtml();
			});
			if (valueAccessor() && ko.isObservable(valueAccessor().htmlObservable) && valueAccessor().shouldShowToolbar() !== undefined) {
				subscriptions.push(valueAccessor().shouldShowToolbar.subscribe(function(newValue) {
					if (newValue === false) {
						$(".ql-toolbar.ql-snow").hide();
					} else {
						$(".ql-toolbar.ql-snow").show();
					}
				}));
			}
		}

		editor.on("text-change", function() {
			if (htmlObservable && ko.isObservable(htmlObservable)) {
				if (initialHtmlObservableChangeSubscription != null) {
					initialHtmlObservableChangeSubscription.dispose();
				}
				htmlObservable(editor.container.firstChild.innerHTML);
			}
		});

		ko.utils.domNodeDisposal.addDisposeCallback(element, function() {
			$.each(subscriptions, function(i, subscription) {
				subscription.dispose();
			});
		});

		function setClipboardTextFromHtml() {
			if (ko.unwrap(htmlObservable)) {
				editor.clipboard.dangerouslyPasteHTML(ko.unwrap(htmlObservable), "silent");
			}
		}
	};
};
