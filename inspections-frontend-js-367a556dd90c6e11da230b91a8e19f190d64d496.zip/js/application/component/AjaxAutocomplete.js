namespace("demax.inspections.component");

demax.inspections.component.AjaxAutocomplete = function(params) {
	var self = this;

	var objectProperty = params.objectProperty || null; //For when the options are objects and not strings
	var minInputLenToLoadOptions = params.minInputLenToLoadOptions || 1;

	this.id = "ajaxAutocomplete" + new Date().getTime();
	this.inputSelector = "#" + params.inputId;
	this.subscriptions = [];
	this.namespace = params.namespace || this.id;
	this.selectedOptionIndex = ko.observable(-1);
	this.inputObservable = params.inputObservable;
	this.ajaxLoaderCallback = params.ajaxLoaderCallback;
	this.onItemSelectedCallback = params.onItemSelectedCallback;
	this.onComponentLoadedCallback = params.onComponentLoadedCallback;
	this.originalObject = params.originalObject;
	this.blockSingleOptionsVisibilityUpdate = params.blockSingleOptionsVisibilityUpdate ? params.blockSingleOptionsVisibilityUpdate : ko.observable(false);

	this.shouldShowOptions = ko.observable(false);

	this.inputValue = ko.pureComputed(function() {
		return ko.unwrap(self.inputObservable);
	}).extend({
		rateLimit: { timeout: 500, method: "notifyWhenChangesStop" }
	});

	this.filteredOptions = ko.observableArray();

	this.subscriptions.push(self.inputValue.subscribe(function(filterValue) {
		if (typeof(filterValue) == "string" && filterValue.trim().length >= minInputLenToLoadOptions) {
			if ($.isFunction(self.ajaxLoaderCallback)) {
				var timeout = setTimeout(function() {
					self.filteredOptions([{
						isMock: true,
						optionKey: "Зареждане...",
						matchStartIndex: -1,
						matchEndIndex: -1
					}]);
					self.shouldShowOptions(true);
				}, 250);
				self.ajaxLoaderCallback(filterValue, self.originalObject)
					.done(function(filteredOptions) {
						if (filteredOptions && $.isArray(filteredOptions) && filteredOptions.length > 0) {
							
							var shouldSkipVisiblityUpdate = self.blockSingleOptionsVisibilityUpdate != null && ko.unwrap(self.blockSingleOptionsVisibilityUpdate) === true; 
							if (!shouldSkipVisiblityUpdate) {
								self.shouldShowOptions(true);
							}
							self.blockSingleOptionsVisibilityUpdate(false);
					
							self.selectedOptionIndex(-1);
							var options = convertToComponentOptions(filteredOptions, filterValue);
							self.filteredOptions(options);
						} else {
							self.shouldShowOptions(true);
							self.filteredOptions([{
								isMock: true,
								optionKey: "Няма намерени резултати",
								matchStartIndex: -1,
								matchEndIndex: -1
							}]);
						}
					}).fail(function() {
						resetOptions();
					}).always(function() {
						clearTimeout(timeout);
					});
			}
		} else {
			resetOptions();
		}
	}));

	this.setOption = function(optionObj) {
		if ($.isFunction(self.onItemSelectedCallback) && !optionObj.isMock) {
			self.onItemSelectedCallback(optionObj.option, self.originalObject);
		}
	};

	enableKeyboardControl();
	enableClosingOptionOnClickOutside();
	enabledDynamicOptionsScrolling();

	function convertToComponentOptions(options, filter) {
		var componentOptions = [];
		filter = filter.toLowerCase() + "";
		options.forEach(function(option) {
			var optionKey = option;
			
			if (objectProperty !== null) {
				optionKey = ko.unwrap(option[objectProperty]) + "";
			}
			var lowerCaseOptionKey = optionKey.toLowerCase() + "";

			var optionObj = {
				option: option,
				optionKey: optionKey,
				matchStartIndex: 0,
				matchEndIndex: 0
			};

			var indexOfFilter = lowerCaseOptionKey.indexOf(filter);
			if (indexOfFilter > -1) {
				
				optionObj.matchStartIndex = indexOfFilter;
				optionObj.matchEndIndex = indexOfFilter + filter.length - 1;
			}
			componentOptions.push(optionObj);
		});
		return componentOptions;
	}

	function resetOptions() {
		self.selectedOptionIndex(-1);
		self.shouldShowOptions(false);
		self.filteredOptions.removeAll();
	}

	function enabledDynamicOptionsScrolling() {
		var lastActiveIndex = -1;
		var singleElementOuterHeight = 39;
		var visibleOptionsSize = 10;

		self.subscriptions.push(self.selectedOptionIndex.subscribe(function(newIndex) {
			var $optionsContainer = $("#" + self.id);

			var pixelsAboveScroll;
			if (newIndex == 0) {
				pixelsAboveScroll = 0;
			} else if (newIndex > lastActiveIndex) {
				var distanceFromBottom = getDistanceFromBottom(newIndex, $optionsContainer);
				if (distanceFromBottom < singleElementOuterHeight) {
					pixelsAboveScroll = $optionsContainer.scrollTop() + singleElementOuterHeight - distanceFromBottom;
				}
			} else if (newIndex < lastActiveIndex) {
				var distanceFromTop = getDistanceFromTop(newIndex, $optionsContainer);
				if (distanceFromTop < singleElementOuterHeight) {
					pixelsAboveScroll = $optionsContainer.scrollTop() - (singleElementOuterHeight - distanceFromTop);
				}
			}

			$optionsContainer.scrollTop(pixelsAboveScroll);
			lastActiveIndex = newIndex;
		}));

		function getDistanceFromTop(elementIndex, optionsContainer) {
			var spaceFromTheTop = (elementIndex + 1) * singleElementOuterHeight - optionsContainer.scrollTop();
			return spaceFromTheTop;
		}

		function getDistanceFromBottom(elementIndex, optionsContainer) {
			var spaceFromTheBottom = optionsContainer.scrollTop()
				+ visibleOptionsSize * singleElementOuterHeight - elementIndex * singleElementOuterHeight;

			return spaceFromTheBottom;
		}
	}

	function enableKeyboardControl() {
		$(self.inputSelector).on("keydown." + self.namespace, function(event) {
			switch (event.keyCode) {
				case pastel.util.KeyCodes.UP_ARROW:
					if (self.selectedOptionIndex() > 0) {
						self.selectedOptionIndex(self.selectedOptionIndex() - 1);
					} else if (self.selectedOptionIndex() == 0) {
						self.selectedOptionIndex(self.filteredOptions().length - 1);
					}
					break;
				case pastel.util.KeyCodes.DOWN_ARROW:
					if (self.selectedOptionIndex() < self.filteredOptions().length - 1) {
						self.selectedOptionIndex(self.selectedOptionIndex() + 1);
					} else {
						self.selectedOptionIndex(0);
					}
					break;
				case pastel.util.KeyCodes.ENTER:
					if (self.selectedOptionIndex() > -1) {
						self.setOption(self.filteredOptions()[self.selectedOptionIndex()]);
						resetOptions();
					}
					break;
				case pastel.util.KeyCodes.ESCAPE:
					resetOptions();
					break;
			}
		});
	}

	function enableClosingOptionOnClickOutside() {
		$(document).on("click." + self.namespace, function(event) {
			var clickedOnInput = event.target.id == params.inputId;

			if (!clickedOnInput) {
				resetOptions();
			}
		});
	}
	
	if ($.isFunction(self.onComponentLoadedCallback)) {
		self.onComponentLoadedCallback();
	}
};

pastel.plus.component.FuzzyFinder.prototype.dispose = function() {
	$(this.inputSelector).off("keydown." + this.namespace);
	$(document).off("click." + this.namespace);

	this.subscriptions.forEach(function(subscription) {
		subscription.dispose();
	});
};
