namespace("demax.inspections.component");

demax.inspections.component.ChooseCourierComponent = function(params) {
	var self = this;

	var WORKING_TIME_FROM = "09:29";
	var WORKING_TIME_TO = "17:31";
	
	var dateTimePickerOptions = {
		allowInputToggle: true,
		format: "HH:mm"
	};

	ko.bindingHandlers.timePicker = new pastel.plus.binding.DateTimePickerBinding(dateTimePickerOptions);
	
	params = params || {};
	this.isVisible = ko.isObservable(params.isVisible) ? params.isVisible : ko.observable(params.isVisible);
	this.selectedCourier = params.selectedCourier;
	this.selectedCourierServiceType = params.selectedCourierServiceType;
	this.selectedCourierDeliveryType = params.selectedCourierDeliveryType
		|| ko.observable(demax.inspections.nomenclature.CourierDeliveryType.DOOR_TO_DOOR);
	this.selectedTimeValid = params.selectedTimeValid;
	this.selectedTime = params.selectedTime;
	this.disabledCouriers = params.disabledCouriers ? params.disabledCouriers : [];

	var disabledCouriersSubscription = (function() {
		if (ko.isObservable(self.disabledCouriers)) {
			return self.disabledCouriers.subscribe(function() {
				var disabledCouriers = ko.unwrap(self.disabledCouriers);
				if (disabledCouriers && disabledCouriers.length > 0) {
					var firstEnabledCourier = null;
					for (var courierKey in demax.inspections.nomenclature.Courier) {
						if (disabledCouriers.indexOf(demax.inspections.nomenclature.Courier[courierKey]) < 0) {
							firstEnabledCourier = demax.inspections.nomenclature.Courier[courierKey];
							break;
						}
					}
					if (firstEnabledCourier) {
						self.selectedCourier(firstEnabledCourier);
					} else {
						self.selectedCourier(null);
					}
				}
			});
		}
		return null;
	})();

	this.isSelectTimeVisible = ko.pureComputed(function() {
		return self.selectedCourierServiceType() === demax.inspections.nomenclature.CourierServiceType.EXPRESS;
	});

	this.isTimeValid = ko.pureComputed(function() {
		var isValid = false;
		if (!self.isSelectTimeVisible()) {
			isValid = true;
		} else {
			isValid = self.selectedTime().isAfter(moment(WORKING_TIME_FROM, dateTimePickerOptions.format))
				&& self.selectedTime().isBefore(moment(WORKING_TIME_TO, dateTimePickerOptions.format));
		}
		self.selectedTimeValid(isValid);
		return isValid;
	});

	this.couriers = ko.observableArray(pastel.plus.util.toArray(demax.inspections.nomenclature.Courier));

	this.selectCourier = function(courierService) {
		if (self.selectedCourier() !== courierService) {
			self.selectedCourier(courierService);
			self.selectedCourierServiceType(
				courierService.serviceTypes[self.selectedCourierServiceType()]
					||	courierService.serviceTypes[0]
			);
			self.selectedCourierDeliveryType(
				courierService.deliveryTypes[self.selectedCourierDeliveryType()]
					||	courierService.deliveryTypes[0]
			);
		}
	};

	this.dispose = function() {
		ko.bindingHandlers.timePicker = undefined;
		if (disabledCouriersSubscription) {
			disabledCouriersSubscription.dispose();
		}
	};
};
