namespace("demax.inspections.component");

demax.inspections.component.DeliveryTransferComponent = function(params) {
	var self = this;
	
	var speedyUrl = "https://www.speedy.bg/bg/track-shipment?shipmentNumber=";

	var restClient = demax.inspections.restClient;
	this.deliveryDetails = ko.unwrap(params.deliveryDetails);
	this.isVisible = params.isVisible !== undefined ? params.isVisible : true;
	var authenticatedUser = demax.inspections.authenticatedUser();
	var Group = demax.inspections.nomenclature.Group;
	
	this.deliveryDetails.invoiceText = ko.observable(invoiceText());
	this.deliveryDetails.accountantText = accountantText();
	this.hasTitle = params.hasTitle || false;
	this.isSettingInvoice = ko.observable(false);
	this.invoiceNumber = ko.observable();
	this.invalidInvoiceInfo = ko.observable(false);
	
	this.invoiceNumber.extend({
		required: true,
		min: 1,
		pattern: "^[0-9]{1,}$"
	});
	
	this.invoiceDate = ko.observable();
	
	this.invoiceDate.extend({
		required: true
	});
	
	var validation = ko.validatedObservable({
		invoiceNumber: self.invoiceNumber,
		invoiceDate: self.invoiceDate
	});
	
	var billOfLading = this.deliveryDetails.billOfLading;
	
	this.deliveryDetails.courierName = ko.pureComputed(function() {
		var bol = ko.unwrap(billOfLading);
		var hasBol = bol !== undefined && bol !== null;
		var hasCourier = hasBol ? bol.courier !== undefined && bol.courier !== null : false;
		return hasCourier ? bol.courier.displayText : "";
	});

	this.deliveryDetails.courierServiceTypeName = ko.pureComputed(function() {
		var bol = ko.unwrap(billOfLading);
		var hasBol = bol !== undefined && bol !== null;
		var hasCourierServiceType = hasBol ? bol.courierServiceType !== undefined && bol.courierServiceType !== null : false;
		return hasCourierServiceType ? bol.courierServiceType.displayText : "";
	});

	this.deliveryDetails.bolIdForCourier = ko.pureComputed(function() {
		var bol = ko.unwrap(billOfLading);
		var hasBol = bol !== undefined && bol !== null;
		return hasBol ? bol.billOfLadingIdForCourier : "";
	});

	this.deliveryDetails.url = ko.pureComputed(function() {
		var bol = ko.unwrap(billOfLading);
		var hasBol = bol !== undefined && bol !== null;
		return hasBol ? speedyUrl + bol.billOfLadingIdForCourier : "";
	});

	this.deliveryDetails.hasDeliveryTime = ko.pureComputed(function() {
		var bol = ko.unwrap(billOfLading);
		return bol !== undefined && bol !== null && bol.hasFixedTimeDelivery();
	});
	
	this.deliveryDetails.deliveryTime = ko.pureComputed(function() {
		var bol = ko.unwrap(billOfLading);
		return bol.formattedFixedTimeDelivery;
	});
	
	this.editInvoiceFields = function () {
		if (self.isSettingInvoice()) {
			self.invoiceNumber(undefined);
			self.invoiceDate(undefined);
		}
		self.isSettingInvoice(!self.isSettingInvoice());
	};
	
	this.isInvoiceStatusEditable = ko.pureComputed(function () {
		var hasPermissionToSetOrderStatus = authenticatedUser.isUserOfGroup(Group.INSPECTION_ORDER_EDITOR);
		var isOrderIssued = self.deliveryDetails.status === "ISSUED";
		
		return hasPermissionToSetOrderStatus && isOrderIssued && self.deliveryDetails.invoiceText() === " - неплатена";
	});
	
	this.setInvoiceInfo = function() {

		if (validation.isValid()) {

			var url = "api/inspection-orders/" + self.deliveryDetails.orderId + "/pay";

			var params = {
				invoiceNumber : self.invoiceNumber(),
				invoiceDate : self.invoiceDate().format(demax.inspections.settings.serverDateFormat)
			};

			return restClient.patchResource(url, JSON.stringify(params)).done(function() {
				self.deliveryDetails.invoiceNumber = self.invoiceNumber();
				self.deliveryDetails.invoiceDateTime = self.invoiceDate();
				self.invalidInvoiceInfo(false);
				self.editInvoiceFields();
				self.deliveryDetails.status === "PAID";
				self.deliveryDetails.invoiceText(invoiceText());
				demax.inspections.events.publish(demax.inspections.Event.SET_ORDER_PAID, params);
			}).fail(function() {
				self.invalidInvoiceInfo(true);
			});
		} else {
			self.invalidInvoiceInfo(true);
		}
	};
	
	function invoiceText() {
		var invoiceNumber = self.deliveryDetails.invoiceNumber;
		var invoiceDateTime = self.deliveryDetails.invoiceDateTime;
		if (invoiceNumber != undefined && invoiceDateTime != undefined) {
			return "№" + invoiceNumber + " / " + invoiceDateTime.format(demax.inspections.settings.momentDateFormat);
		} else {
			return " - неплатена";
		}
	}

	function accountantText() {
		var accountantCode = self.deliveryDetails.accountantCode;
		var accountantName = self.deliveryDetails.accountantName;

		var isAccountantNamePresent = typeof(accountantName) == "string" && accountantName.trim().length > 0;
		var isAccountantCodePreset = typeof(accountantCode) == "string" && accountantCode.trim().length > 0;

		if (isAccountantNamePresent && isAccountantCodePreset) {
			return accountantName + ", код " + accountantCode;
		} else {
			return "-";
		}
	}
};
