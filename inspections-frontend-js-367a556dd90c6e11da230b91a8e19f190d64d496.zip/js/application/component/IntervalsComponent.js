namespace("demax.inspections.component");

demax.inspections.component.IntervalsComponent = function(params) {
	var self = this;
	var IntervalParams = demax.inspections.model.IntervalParams;
	var requestedQuantity = ko.unwrap(params.quantity);

	this.intervals = params.intervals;
	this.intervalsCopy = params.intervalsCopy;
	
	this.originalSize = this.intervals().length;
	this.conflictingIntervals = ko.observableArray([]);
	this.quantityDifference = ko.observable(0);
	this.keepSize = params.keepSize || true;

	this.hasError = params.hasError || ko.observable(false);
	
	this.intervals().forEach(function(interval) {
		self.intervalsCopy.push(new IntervalParams({
			fromNum: interval.fromNum(),
			toNum: interval.toNum()
		}));
	});

	this.quantity = ko.pureComputed(function() {
		var sum = 0;
		var hasError = false;
		self.intervalsCopy().some(function(interval) {
			if (!interval.isValid() || self.conflictingIntervals().length > 0) {
				hasError = true;
				sum = requestedQuantity;
				return true;
			}
			sum += interval.quantity();
			return false;
		});
		
		self.quantityDifference(requestedQuantity - sum);
		if (hasError) {
			self.hasError(true);
		} else {
			updateHasError();
		}
		
		return sum;
	}, this);
	
	this.addInterval = function() {
		self.intervalsCopy.push(new IntervalParams());
	};

	this.removeInterval = function(interval) {
		self.intervalsCopy.remove(interval);
	};

	this.updateAndReturnConflictingIntervals = ko.pureComputed(function() {
		var isValid = true;
		self.conflictingIntervals.removeAll();
		self.intervalsCopy().forEach(function(interval, index) {
			self.intervalsCopy().slice(index + 1).forEach(function(otherInterval) {
				if (!isValid) {
					return;
				}
				if (interval !== otherInterval && (interval.isValid() && otherInterval.isValid())) {
					var toNum = parseInt(interval.toNum());
					var fromNum = parseInt(otherInterval.fromNum());
					isValid &= ((isNaN(toNum) || isNaN(fromNum)) || toNum < fromNum);
					if (!isValid) {
						self.conflictingIntervals.push(interval);
						self.conflictingIntervals.push(otherInterval);
						return;
					}
				}
			});
		});
		if (!isValid) {
			updateHasError();
		}
		return self.conflictingIntervals();
	}, this);

	function updateHasError() {
		if (self.conflictingIntervals().length > 0 || self.quantityDifference() !== 0) {
			self.hasError(true);
		} else {
			self.hasError(false);
		}
	}
};
