namespace("demax.inspections.component");

demax.inspections.component.ProtocolPrintButtonComponent = function(params) {
	var self = this;
	var CONTROLLER_ADDRESS = "api/inspection-protocols/";
	this.protocol = ko.unwrap(params.protocol);
	this.css = params.css || "";
	this.isLoading = params.isLoading || ko.observable(false);

	this.printProtocol = function() {
		var url = CONTROLLER_ADDRESS + this.protocol.id + "/pdf";

		self.isLoading(true);
		demax.inspections.blobClient.openBlob(url)
			.always(function() {
				self.isLoading(false);
			});
	};
};
