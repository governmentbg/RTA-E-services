namespace("demax.inspections.component");

demax.inspections.component.SupervisorDetailsComponent = function(params) {
	var self = this;

	var thisNamespace = ".supervisorComponent" + new Date().getTime();

	var Event = demax.inspections.Event;
	var eventsQueue = demax.inspections.events;


	var credentialsDeferred = $.Deferred();
	params.objectLink(this);


	this.title = ko.observable(null);

	this.isVisible = ko.observable(false);

	var isVisibleSubscription = this.isVisible.subscribe(function(newVal) {
		if (newVal) {
			subscribeToKeyEvents();
		} else {
			unsubscribeFromKeyEvents();
		}
	});

	this.username = ko.observable(null);
	this.password = ko.observable(null);

	this.getCredentials = function(title) {
		self.title(title);
		self.isVisible(true);
		return credentialsDeferred;
	};

	this.confirm = function() {
		credentialsDeferred.resolve({
			username: self.username(),
			password: self.password()
		});
		resetComponent();
	};

	this.cancel = function() {
		credentialsDeferred.reject();
		resetComponent();
	};

	this.canConfirm = ko.pureComputed(function() {
		var username = self.username();
		var password = self.password();

		var hasPassword = typeof(password) == "string" && password.trim().length > 3;
		var hasUsername = typeof(username) == "string" && username.trim().length > 3;

		return hasPassword && hasUsername;
	});

	function resetComponent() {
		credentialsDeferred = $.Deferred();
		self.title(null);
		self.isVisible(false);
		self.password(null);
		self.username(null);
	}

	function onEnter() {
		if (!self.isVisible()) {
			return;
		}

		if (self.canConfirm()) {
			self.confirm();
		}
	}

	function onEsc() {
		if (!self.isVisible()) {
			return;
		}
		self.cancel();
	}

	function subscribeToKeyEvents() {
		eventsQueue.subscribe(Event.KEYPRESS_ENTER + thisNamespace, onEnter);
		eventsQueue.subscribe(Event.KEYPRESS_ESC + thisNamespace, onEsc);
	}

	function unsubscribeFromKeyEvents() {
		eventsQueue.unsubscribe(Event.KEYPRESS_ENTER + thisNamespace);
		eventsQueue.unsubscribe(Event.KEYPRESS_ESC + thisNamespace);
	}

	this.dispose = function() {
		isVisibleSubscription.dispose();
		unsubscribeFromKeyEvents();
	};
};
