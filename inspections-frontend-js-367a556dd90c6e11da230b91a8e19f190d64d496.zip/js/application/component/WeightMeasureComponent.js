namespace("demax.inspections.component");

demax.inspections.component.WeightMeasureComponent = function(params) {
	var self = this;

	params.objectLink(this);

	this.weight = ko.observable(0);

	this.isVisible = params.isVisible !== undefined ? params.isVisible : true;
	this.desiredWeightAndWeightOffset = params.desiredWeightAndWeightOffset !== undefined ? params.desiredWeightAndWeightOffset : null;

	this.isWeightValid = ko.pureComputed(function() {
		var weight = self.weight();
		var desiredWeightAndWeightOffset = ko.unwrap(self.desiredWeightAndWeightOffset);

		if (weight <= 0) {
			return false;
		}

		if (desiredWeightAndWeightOffset == null) {
			return false;
		}

		var difference = Math.abs(weight - desiredWeightAndWeightOffset.weight);
		return desiredWeightAndWeightOffset.weightOffset >= difference;
	});

	this.weightPoller = new demax.inspections.utils.WeightScalePoller({
		weight: self.weight
	});

	if (ko.unwrap(self.isVisible)) {
		this.weightPoller.startPolling();
	}

	var stopPollingOnNotVisibleSubscription = ko.computed(function () {
		var isVisible = ko.unwrap(self.isVisible);

		if (isVisible == true) {
			self.weightPoller.startPolling();
		} else if (isVisible == false) {
			self.weightPoller.stopPolling();
		}
	});

	this.dispose = function() {
		self.weightPoller.stopPolling();
		stopPollingOnNotVisibleSubscription.dispose();
	};

};
