namespace("demax.inspections.model");

demax.inspections.model.City = function(dto) {
	this.name = dto && dto.name !== undefined ? dto.name : null;
	this.code = dto && dto.code !== undefined ? dto.code : null;
};
