namespace("demax.inspections.model");

demax.inspections.model.EcoCategory = function (dto) {
	this.code = dto && dto.code ? dto.code : null;
	this.description = dto && dto.description ? dto.description : null;
};
