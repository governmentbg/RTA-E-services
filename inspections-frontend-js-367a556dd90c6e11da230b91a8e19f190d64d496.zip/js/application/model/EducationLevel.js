namespace("demax.inspections.model");

demax.inspections.model.EducationLevel = function(dto) {
	this.code = dto && dto.code !== undefined ? dto.code : null;
	this.description = dto && dto.description !== undefined ? dto.description : null;
	this.isValid = dto && dto.isValid !== undefined ? dto.isValid : null;
};