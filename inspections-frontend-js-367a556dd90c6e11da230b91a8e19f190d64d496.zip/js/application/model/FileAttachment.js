namespace("demax.inspections.model");

demax.inspections.model.FileAttachment = function(file) {
	this.file = file;
	this.mimeType = file.type;
	this.filename = file.name;
};