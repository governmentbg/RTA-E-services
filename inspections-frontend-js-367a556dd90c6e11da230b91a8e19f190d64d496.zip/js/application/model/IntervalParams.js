namespace("demax.inspections.model");

demax.inspections.model.IntervalParams = function(dto) {
	var self = this;

	this.fromNum = ko.observable((dto && dto.fromNum) || "");
	this.toNum = ko.observable((dto && dto.toNum) || "");
	
	this.fromNum.extend({
		min: 1,
		max: self.toNum,
		pattern: "^[0-9]{1,}$"
	});
	
	this.toNum.extend({
		min: self.fromNum,
		pattern: "^[0-9]{1,}$"
	});

	this.text = ko.pureComputed(function() {
		return self.fromNum() + " - " + self.toNum();
	});

	this.quantity = ko.pureComputed(function() {
		var fromNum = parseInt(self.fromNum());
		var toNum = parseInt(self.toNum());
		if (isNaN(fromNum) || isNaN(toNum)) {
			return 0;
		}

		return self.toNum() - self.fromNum() + 1;
	});
	
	var validation = ko.validatedObservable({
		fromNum: self.fromNum,
		toNum: self.toNum
	});

	this.areIntervalsFilled = ko.pureComputed(function() {
		return self.fromNum() !== "" && self.toNum() !== "";
	});

	this.isValid = ko.pureComputed(function() {
		if (!self.areIntervalsFilled()) {
			return true;
		}
		return validation.isValid();
	}, this).extend({
		equal: true
	});
	
	this.toDto = function() {
		return {
			fromNum: self.fromNum(),
			toNum: self.toNum()
		};
	};
	
	this.getFormmattedText = function() {
		var formattedFromNum = self.fromNum() ? self.fromNum().toString().match(/(\d+?)(?=(\d{3})+(?!\d)|$)/g).join(" ") : "";
		var formattedToNum = self.toNum() ? self.toNum().toString().match(/(\d+?)(?=(\d{3})+(?!\d)|$)/g).join(" ") : "";
		return formattedFromNum + " - " + formattedToNum;
	}; 
};
