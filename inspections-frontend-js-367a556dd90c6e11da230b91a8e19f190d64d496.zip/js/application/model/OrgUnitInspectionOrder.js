namespace("demax.inspections.model");

demax.inspections.model.OrgUnitInspectionOrder = function(dto) {
	if (dto && dto.orgUnit && dto.orgUnit.name) {
		dto.orgUnit.name = dto.orgUnit.name.replace("ОО \"АА\" - ", "");	
	}
	this.orgUnit = dto && dto.orgUnit ? new demax.inspections.model.OrgUnit(dto.orgUnit) : null;
	this.paidInspectionOrdersCount = dto ? dto.paidInspectionOrdersCount : 0;
	this.labelInspectionOrdersCount = dto ? dto.labelInspectionOrdersCount : 0;
};
