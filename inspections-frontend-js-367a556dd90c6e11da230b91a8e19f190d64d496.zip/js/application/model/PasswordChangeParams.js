namespace("demax.inspections.model");

demax.inspections.model.PasswordChangeParams = function() {
	var self = this;
	var subscriptions = [];
	this.errorMessage = ko.observable();
	this.showNewPasswordsDontMatch = ko.observable(false);
	this.showPatternDontMatch = ko.observable(false);
	
	this.oldPassword = ko.observable().extend({
		required: true
	});

	this.newPassword = ko.observable().extend({
		required: true,
		equal: {
			onlyIf : function() {
				return self.showNewPasswordsDontMatch();
			},
			message : "Паролите не съвпадат"
		},
		pattern: {
			onlyIf : function() {
				return self.showPatternDontMatch();
			},
			message: "Невалидна парола",
			params: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}$/
		}
	});
	
	this.newPasswordRepeat = ko.observable().extend({
		required: true,
		equal: {
			onlyIf : function() {
				return self.showNewPasswordsDontMatch();
			},
			message : "Паролите не съвпадат"
		},
		pattern: {
			onlyIf : function() {
				return self.showPatternDontMatch();
			},
			message: "Невалидна парола",
			params: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}$/
		}
	});

	subscriptions.push(self.oldPassword.subscribe(function() {
		self.errorMessage("");
	}));
	subscriptions.push(self.newPassword.subscribe(function() {
		self.showNewPasswordsDontMatch(false);
		self.errorMessage("");
	}));
	subscriptions.push(self.newPasswordRepeat.subscribe(function() {
		self.showNewPasswordsDontMatch(false);
		self.errorMessage("");
	}));

	this.validatePasswords = function() {
		self.showPatternDontMatch(true);
		if (!self.newPassword() && !self.newPasswordRepeat()) {
			return;
		}
		if (self.newPassword().trim() == self.newPasswordRepeat().trim()) {
			return true;
		} else {
			self.showNewPasswordsDontMatch(true);
			return false;
		}
	};
	
	this.toQueryParams = function() {
		var dto = {};
		if (self.oldPassword() && self.newPassword()) {
			dto.oldPassword = self.oldPassword().trim();
			dto.newPassword = self.newPassword().trim();
		}
		return dto;
	};
};
