namespace("demax.inspections.model");

demax.inspections.model.SubjectLight = function(dto) {
	this.id = dto && dto.name ? dto.name : null;
	this.identityNumber = dto && dto.identityNumber ? dto.identityNumber : null;
	this.fullName = dto && dto.fullName ? dto.fullName : null;
};
