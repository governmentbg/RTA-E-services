namespace("demax.inspections.model");

demax.inspections.model.User = function(dto) {
	var self = this;
	var Role = demax.inspections.nomenclature.Role;
	var OrgUnit = demax.inspections.model.OrgUnit;

	dto = dto || {};
	
	this.username = dto.username !== undefined ? dto.username : null;
	this.fullName = dto.name !== undefined ? dto.name : null;
	this.roles = Array.isArray(dto.authorities) ? dto.authorities : [];
	this.guiRoleName = "";
	this.guiSkinClass = "";
	this.landingPage = "";
	this.canChangePassword = true;
	this.employeeOrgUnit = [];

	if (dto.employeeOrgUnit !== null && dto.employeeOrgUnit !== undefined) {
		dto.employeeOrgUnit.forEach(function(element) {
			self.employeeOrgUnit.push(new OrgUnit(element));
		});
	} else {
		self.employeeOrgUnit = null;
	}

	var demaxLogoPath = "./bower_components/admin-lte-demax/dist/demax_logo.png";
	var iaaaLogoPath = "./bower_components/admin-lte-demax/dist/iaaa_logo.png";

	if (this.roles.indexOf(Role.ROLE_SUPER_ADMIN) > -1) {
		this.guiRoleName = "супер админ";
		this.guiSkinClass = "skin-blue";
		this.landingPage = "techinsp/finished-inspections-list";
		this.appLogoPath = demaxLogoPath;
		this.canChangePassword = false;
	} else if (this.roles.indexOf(Role.SUPERVISOR) > -1) {
		this.guiRoleName = "супервайзър";
		this.guiSkinClass = "skin-blue";
		this.landingPage = "inspection-orders-list";
		this.appLogoPath = demaxLogoPath;
	} else if (this.roles.indexOf(Role.CALL_CENTER) > -1) {
		this.guiRoleName = "Call център";
		this.guiSkinClass = "skin-green";
		this.landingPage = "hardware/devices";
		this.appLogoPath = demaxLogoPath;
	} else if (this.roles.indexOf(Role.ACCOUNTING) > -1) {
		this.guiRoleName = "счетоводител";
		this.guiSkinClass = "skin-purple";
		this.landingPage = "inspection-orders-list";
		this.appLogoPath = demaxLogoPath;
	} else if (this.roles.indexOf(Role.PACKAGING_VOUCHERS) > -1) {
		this.guiRoleName = "пакетатор ваучери";
		this.guiSkinClass = "skin-blue";
		this.landingPage = "exam-orders-list";
		this.appLogoPath = demaxLogoPath;
	} else if (this.roles.indexOf(Role.PACKAGING_INSPECTIONS) > -1) {
		this.guiRoleName = "пакетатор прегледи";
		this.guiSkinClass = "skin-blue";
		this.landingPage = "inspection-orders-packaging";
		this.appLogoPath = demaxLogoPath;
	} else if (this.roles.indexOf(Role.TECHINSP_IAAA) > -1) {
		this.guiRoleName = "techinsp IAAA";
		this.guiSkinClass = "skin-blue";
		this.landingPage = "techinsp/in-progress-inspections-list";
		this.appLogoPath = iaaaLogoPath;
	} else if (this.roles.indexOf(Role.TECHINSP_INSP_RDAA) > -1) {
		this.guiRoleName = "techinsp RDAA";
		this.guiSkinClass = "skin-blue";
		this.landingPage = "techinsp/in-progress-inspections-list";
		this.appLogoPath = iaaaLogoPath;
	} else if (this.roles.indexOf(Role.TECHINSP_INSP_SEARCH_ALL) > -1) {
		this.guiRoleName = "techinsp search all";
		this.guiSkinClass = "skin-blue";
		this.landingPage = "techinsp/finished-inspections-list";
		this.appLogoPath = iaaaLogoPath;
	} else if (this.roles.indexOf(Role.TECHINSP_CHILD_ORG_UNIT_INSPECTOR) > -1) {
		this.guiRoleName = "techinsp regional control";
		this.guiSkinClass = "skin-blue";
		this.landingPage = "techinsp/in-progress-inspections-list";
		this.appLogoPath = iaaaLogoPath;
	} else {
		this.guiRoleName = "непознат";
		this.guiSkinClass = "skin-red";
		this.landingPage = "page-is-forbidden";
		this.appLogoPath = demaxLogoPath;
		this.canChangePassword = false;
	}
	
	this.isUserOfGroup = function(group) {
		return this.roles.some(function(role) {
			return group.indexOf(role) > -1;
		});
	};

	self.userIsIaaa = ko.pureComputed(function () {
		return self.roles.indexOf(Role.TECHINSP_IAAA) > -1;
	});

	self.userIsCallCenter = ko.pureComputed(function () {
		return self.roles.indexOf(Role.CALL_CENTER) > -1;
	});

	self.userIsRdaa = ko.pureComputed(function () {
		return self.roles.indexOf(Role.TECHINSP_INSP_RDAA) > -1;
	});

	self.userHasSecondaryInspectionRole = ko.pureComputed(function () {
		return self.roles.indexOf(Role.TECHINSP_SECONDARY_INSPECTION) > -1;
	});

	self.userIsAdmin = ko.pureComputed(function () {
		return self.roles.indexOf(Role.ROLE_SUPER_ADMIN) > -1;
	});

	self.userIsControl = ko.pureComputed(function () {
		return self.roles.indexOf(Role.TECHINSP_CHILD_ORG_UNIT_INSPECTOR) > -1;
	});

	self.userCanViewMessages = ko.pureComputed(function () {
		return self.roles.indexOf(Role.TECHINSP_MESSAGES_VIEW) > -1;
	});

	self.userCanEditMessages = ko.pureComputed(function () {
		return self.roles.indexOf(Role.TECHINSP_MESSAGES_EDIT) > -1;
	});
};
