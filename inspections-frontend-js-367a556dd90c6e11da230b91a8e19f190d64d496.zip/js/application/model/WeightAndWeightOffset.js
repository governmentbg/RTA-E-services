namespace("demax.inspections.model");

demax.inspections.model.WeightAndWeightOffset = function(dto) {
	dto = dto || {};

	this.weight = dto.weight !== undefined ? dto.weight : null;
	this.weightOffset = dto.weightOffset !== undefined ? dto.weightOffset : null;
};
