namespace("demax.inspections.model.equipment.consumable");

demax.inspections.model.equipment.consumable.ConsumableRequestsSearchFilters = function() {
	var self = this;
	var BolStatus = demax.inspections.nomenclature.BillOfLadingStatus;
	var lastUsedFilters = null;

	this.searchText = ko.observable();
	this.receiver = ko.observable();
	this.createdAt = ko.observable();
	this.status = ko.observable(BolStatus.NOT_SENT);
	
	this.currentLoadedStatusFilter = ko.observable();

	this.toQueryParams = function() {
		self.currentLoadedStatusFilter(self.status());		
		var dto = {};

		if (self.searchText()) {
			dto.searchText = self.searchText().trim();
		}
		if (self.receiver()) {
			dto.receiver = self.receiver().trim();
		}
		if (self.createdAt()) {
			dto.createdAt = self.createdAt().format(demax.inspections.settings.serverDateFormat);
		}
		if (self.status()) {
			dto.statusCode = self.status().code;
		}
		return dto;
	};
	
	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			searchText: self.searchText(),
			receiver: self.receiver(),
			createdAt: self.createdAt(),
			status: self.status()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.searchText(lastUsedFilters.searchText);
			self.receiver(lastUsedFilters.receiver);
			self.createdAt(lastUsedFilters.createdAt);
			self.status(lastUsedFilters.status);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.searchText(null);
		self.receiver(null);
		self.createdAt(null);
		self.status(null);
	};
};
