namespace("demax.inspections.model.equipment.consumable");

demax.inspections.model.equipment.consumable.ConsumableTransferBillOfLadingDto = function(dto) {
	var self = this;
	var Courier = demax.inspections.nomenclature.Courier;
	var CourierServiceType = demax.inspections.nomenclature.CourierServiceType;
	
	this.id = dto ? dto.id : null;
	this.courier = dto ? demax.inspections.nomenclature.Courier[dto.courierCode] : null;
	this.courierServiceType = dto ? CourierServiceType[dto.courierServiceTypeCode] : null;
	this.billOfLadingIdForCourier = dto ? dto.billOfLadingIdForCourier : null;
	this.createdAt = dto ? moment.fromJacksonDateTimeArray(dto.createdAt) : null;
	this.fixedTimeDelivery = dto && dto.fixedTimeDelivery !== undefined ? moment.fromJacksonTimeArray(dto.fixedTimeDelivery) : null;
	this.packageCount = dto ? dto.packageCount : 0;
	this.weight = dto ? dto.weight : 0;
	this.status = dto ? demax.inspections.nomenclature.BillOfLadingStatus[dto.statusCode] : null;
	this.recipient = dto ? "КТП " + dto.permitNumber : null;
	this.contactPersonName = dto ? dto.contactPersonName : null;
	this.contactPersonPhoneNumber = dto ? dto.contactPersonPhoneNumber : null;
	this.shippingAddress = dto ? dto.shippingAddress : null;
	this.cartridgesCount = dto ? dto.cartridgesCount : null;
	this.drumsCount = dto ? dto.drumsCount : null;
	
	this.hasFixedTimeDelivery = ko.pureComputed(function() {
		return self.courierServiceType === CourierServiceType.EXPRESS;
	});
	
	this.formattedFixedTimeDelivery = function() {
		var time = self.fixedTimeDelivery;
		return self.hasFixedTimeDelivery() && time ? time.format(demax.inspections.settings.momentTimeFormat) : "";
	}();

	this.hasBolPdf = function () {
		return self.courier == Courier.SPEEDY || self.courier == Courier.ECONT;
	};
};