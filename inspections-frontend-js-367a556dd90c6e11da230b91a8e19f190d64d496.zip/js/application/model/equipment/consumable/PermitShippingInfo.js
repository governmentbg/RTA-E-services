namespace("demax.inspections.model.equipment.consumable");

demax.inspections.model.equipment.consumable.PermitShippingInfo = function(dto) {
	var self = this;
	
	this.permitId = dto ? dto.id : "";
	this.address = ko.observable(dto ? dto.address : null).extend({
		required: true,
		minLength: 5
	});
	this.recipientPersonName = ko.observable(dto ? dto.recipientPersonName : null).extend({
		required: true
	});
	this.recipientPersonPhone = ko.observable(dto ? dto.recipientPersonPhone : null).extend({
		required: true
	});
	
	this.ktpCityName = ko.observable(dto ? dto.ktpCityName : null).extend({
		required: true
	});
	
	this.toDto = function() {
		var dto = {
			permitId: self.permitId ? self.permitId : null,
			address: self.address() ? self.address() : null,
			recipientPersonName: self.recipientPersonName() ? self.recipientPersonName() : null,
			recipientPersonPhone: self.recipientPersonPhone() ? self.recipientPersonPhone() : null,
			ktpCityName: self.ktpCityName() ? self.ktpCityName() : null
		};
		return dto;
	};
};