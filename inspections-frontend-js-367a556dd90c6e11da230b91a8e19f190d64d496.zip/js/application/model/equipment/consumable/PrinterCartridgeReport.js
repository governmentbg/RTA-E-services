namespace("demax.inspections.model.equipment.consumable");

demax.inspections.model.equipment.consumable.PrinterCartridgeReport = function(dto) {
	var self = this;

	this.id = dto ? dto.id : null;
	this.printedPages = dto ? dto.printedPages : null;
	this.inspectionNeededPages = dto ? dto.inspectionNeededPages : null;
	this.pagesForPayment = dto ? dto.pagesForPayment : null;
	this.createdAt = dto ? moment.fromJacksonDateTimeArray(dto.createdAt) : null;

	this.createdAtFormated = (function() {
		if (self.createdAt) {
			return self.createdAt.format(demax.inspections.settings.momentDateTimeFormat);
		}
		return "-";
	})();
};
