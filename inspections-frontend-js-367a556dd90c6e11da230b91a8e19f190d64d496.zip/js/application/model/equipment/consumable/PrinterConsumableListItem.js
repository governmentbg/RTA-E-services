namespace("demax.inspections.model.equipment.consumable");

demax.inspections.model.equipment.consumable.PrinterConsumableListItem = function(dto) {
	var self = this;

	var PrinterConsumableStatus = demax.inspections.nomenclature.equipment.consumable.PrinterConsumableStatus;
	var PrinterConsumableType = demax.inspections.nomenclature.equipment.consumable.PrinterConsumableType;

	this.id = dto ? dto.id : null;
	this.permit = dto ? dto.permit : null;
	this.type = dto ? PrinterConsumableType.getByCode(dto.type) : null;
	this.serialNumber = dto ? dto.serialNumber : null;
	this.sentAt = dto && dto.sentAt ? moment.fromJacksonDateTimeArray(dto.sentAt) : null;
	this.firstInstalledAt = dto && dto.firstInstalledAt ? moment.fromJacksonDateTimeArray(dto.firstInstalledAt) : null;
	this.percentUsed = dto ? dto.percentUsed : null;
	this.printedPages = dto ? dto.printedPages : null;
	this.remainingPages = dto ? dto.remainingPages : null;
	this.lastUsedAt = dto ? moment.fromJacksonDateTimeArray(dto.lastUsedAt) : null;
	this.inspectionNeededPages = dto ? dto.inspectionNeededPages : null;
	this.totalImpressions = dto ? dto.totalImpressions : null;
	this.status = dto ? PrinterConsumableStatus.getByCode(dto.status) : null;

	this.sentAtFormatted = (function() {
		if (self.sentAt) {
			return self.sentAt.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();

	this.firstInstalledAtFormatted = (function() {
		if (self.firstInstalledAt) {
			return self.firstInstalledAt.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();

	this.lastUsedAtFormatted = (function() {
		if (self.lastUsedAt) {
			return self.lastUsedAt.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();
};
