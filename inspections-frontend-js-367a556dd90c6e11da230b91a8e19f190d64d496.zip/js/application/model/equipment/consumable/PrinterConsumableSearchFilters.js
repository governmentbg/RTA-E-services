namespace("demax.inspections.model.equipment.consumable");

demax.inspections.model.equipment.consumable.PrinterConsumableSearchFilters = function() {
	var self = this;
	var lastUsedFilters = null;

	this.searchText = ko.observable();
	this.type = ko.observable();
	this.orgUnit = ko.observable();
	this.statuses = ko.observableArray();

	this.toQueryParams = function() {
		var dto = {};

		if (self.searchText()) {
			dto.searchText = self.searchText();
		}
		if (self.type()) {
			dto.type = self.type().code;
		}
		if (self.statuses() && self.statuses().length > 0) {
			var statuses = [];
			self.statuses().forEach(function(status) {
				statuses.push(status.code);
			});
			dto.statuses = statuses;
		}
		if (self.orgUnit()) {
			dto.orgUnitCode = ko.unwrap(self.orgUnit().code);
		}

		return dto;
	};

	this.saveLastUsedFilters = function() {
		var usedFilters = {};
		var statuses = ko.utils.arrayMap(self.statuses(), function(status) {
			return demax.inspections.nomenclature.equipment.consumable.PrinterConsumableStatus[status.code];
		});
		usedFilters.searchText = self.searchText();
		usedFilters.type = self.type();
		usedFilters.orgUnit = self.orgUnit();
		usedFilters.statuses = statuses;
		
		lastUsedFilters = usedFilters;
	};

	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.searchText(lastUsedFilters.searchText);
			self.type(lastUsedFilters.type);
			self.orgUnit(lastUsedFilters.orgUnit);
			self.statuses(ko.utils.arrayMap(lastUsedFilters.statuses, function(status) {
				return demax.inspections.nomenclature.equipment.consumable.PrinterConsumableStatus[status.code];
			}));
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};

	this.clear = function() {
		self.searchText(null);
		self.type(null);
		self.orgUnit(null);
		self.statuses.removeAll();
	};
};
