namespace("demax.inspections.model.equipment.consumable");

demax.inspections.model.equipment.consumable.RequestListItem = function(dto) {
	var self = this;
	
	this.id = dto ? dto.id : null;
	this.courier = dto ? demax.inspections.nomenclature.Courier[dto.courierName] : null;
	this.courierServiceType = dto ? demax.inspections.nomenclature.CourierServiceType["STANDARD"] : null;
	this.billOfLadingIdForCourier = dto ? dto.billOfLadingIdForCourier : "";
	this.createdAt = dto ? moment.fromJacksonDateTimeArray(dto.createdAt) : null;
	this.permit = dto ? dto.permit : "";
	this.cartridgesCount = dto ? dto.cartridgesCount : 0;
	this.drumsCount = dto ? dto.drumsCount : 0;
	this.status = dto ? demax.inspections.nomenclature.BillOfLadingStatus[dto.statusCode] : null;
	
	this.getConsumablesTypeText = function() {
		var text = "";
		if (self.cartridgesCount) {
			text += "Tонер - " + self.cartridgesCount + " бр. ";
		}
		if (self.drumsCount) {
			text += "Барабан - " + self.drumsCount + " бр.";
		}
		return text;
	};
	
};