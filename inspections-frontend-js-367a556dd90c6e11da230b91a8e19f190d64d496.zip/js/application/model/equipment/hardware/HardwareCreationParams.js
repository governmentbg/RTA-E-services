namespace("demax.inspections.model.equipment.hardware");

demax.inspections.model.equipment.hardware.HardwareCreationParams = function() {
	var self = this;

	var DeviceType = demax.inspections.nomenclature.equipment.hardware.DeviceType;
	var Warehouse = demax.inspections.nomenclature.Warehouse;

	this.deviceType = ko.observable().extend({
		required : {
			message : "Полето е задължително"
		}
	});
	this.serialNumber = ko.observable().extend({
		required : {
			message : "Полето е задължително"
		},
		validation: [{
			validator: function(value) { // device serial number validator
				var deviceRexex = /^[A-Z0-9]*$/g;

				var matchArray = null;
				if (self.deviceType() && self.deviceType().code !== DeviceType.VIVACOM_SIM_CARD.code
								&& self.deviceType().code !== DeviceType.GLOBUL_SIM_CARD.code) {
					matchArray = value.match(deviceRexex);
				} else {
					return true;
				}
				return matchArray && matchArray.length > 0;
			},
			message: "Серийният номер трябва да съдържа само главни букви на латиница A-Z и цифрите 0-9"
		}, {
			validator: function(value) { // sim card serial number validator
				var simRegex = /^[0-9]{0,22}$/g;

				var matchArray = null;
				if (self.deviceType() && (self.deviceType().code == DeviceType.VIVACOM_SIM_CARD.code
								|| self.deviceType().code == DeviceType.GLOBUL_SIM_CARD.code)) {
					matchArray = value.match(simRegex);
				} else {
					return true;
				}
				return matchArray && matchArray.length > 0;
			},
			message: "Серийният номер трябва да съдържа само цифри 0-9 и да е с максимална дължина 22"
		}]
	});
	this.warehouse = ko.observable(Warehouse[2]);
	this.macAddress = ko.observable().extend({
		validation: [{
			validator: function(value) { // MAC address validation
				if (value) {
					var macAddressRexex = /^([0-9a-fA-F][0-9a-fA-F]:){5}([0-9a-fA-F][0-9a-fA-F])$/g;
	
					var matchArray = null;
					if (self.deviceType() && self.deviceType().code == DeviceType.IP_CAMERA_INSPECTIONS.code) {
						matchArray = value.match(macAddressRexex);
					} else {
						return true;
					}
					return matchArray && matchArray.length > 0;
				} else {
					return true;
				}
			},
			message: "Невалиден MAC адрес"
		}]
	});
	this.ipAddress = ko.observable().extend({
		required : {
			onlyIf : function() {
				return self.deviceType() !== undefined
								&& (self.deviceType().code == 55 || self.deviceType().code == 60);
			},
			message : "Полето е задължително"
		},
		pattern: {
			params: "^\\b(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])"
					+ "\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])"
					+ "\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])"
					+ "\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\\b$",
			message: "Невалиден IP адрес"
		}
	});
	this.msisdn = ko.observable().extend({
		required : {
			onlyIf : function() {
				return self.deviceType() !== undefined
								&& (self.deviceType().code == 55 || self
									.deviceType().code == 60);
			},
			message : "Полето е задължително"
		}
	});

	this.imsi = ko.observable();

	this.toJsonRequest = function() {
		var dto = {
			deviceTypeCode : self.deviceType() ? self.deviceType().code : null,
			serialNumber : self.serialNumber() && self.serialNumber() != "" ? self.serialNumber() : null,
			warehouseId : self.warehouse() ? self.warehouse().id : null,
			macAddress : self.macAddress() && self.macAddress() != "" ? self.macAddress() : null,
			ipAddress : self.ipAddress() && self.ipAddress() != "" ? self.ipAddress() : null,
			msisdn : self.msisdn() && self.msisdn() != "" ? self.msisdn() : null,
			imsi : self.imsi() && self.imsi() != "" ? self.imsi() : null
		};
		return JSON.stringify(dto);
	};

	this.reset = function() {
		if (self.serialNumber()) {
			self.serialNumber("");
		}
		self.warehouse(Warehouse[2]);
		if (self.macAddress()) {
			self.macAddress(null);
		}
		if (self.ipAddress()) {
			self.ipAddress("");
		}
		if (self.msisdn()) {
			self.msisdn("");
		}
		if (self.imsi()) {
			self.imsi("");
		}
	};
};
