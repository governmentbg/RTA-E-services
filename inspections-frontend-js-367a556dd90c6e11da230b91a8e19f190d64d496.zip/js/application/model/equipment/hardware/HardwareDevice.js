namespace("demax.inspections.model.equipment.hardware");

demax.inspections.model.equipment.hardware.HardwareDevice = function(dto) {
	var DeviceStatus = demax.inspections.nomenclature.equipment.hardware.DeviceStatus;
	var DeviceType = demax.inspections.nomenclature.equipment.hardware.DeviceType;
	var Warehouse = demax.inspections.nomenclature.Warehouse;

	this.id = dto.id;
	this.deviceType = dto && dto.type ? DeviceType.getByCode(dto.type.code) : null;
	this.serialNumber = dto.serialNumber || "";
	this.warehouse = dto.warehouse ? Warehouse[dto.warehouse.id] : null;
	this.scrapReason = dto.scrapReason || "";
	this.location = dto.store ? dto.store : null;
	this.permit = dto.permit ? dto.permit : null;
	this.status = dto.status ? DeviceStatus.getById(dto.status.id) : null;
	this.macAddress = dto.macAddress || "";
	this.ipAddress = dto.ipAddress || "";
	this.msisdn = dto.msisdn || "";
	this.imsi = dto.imsi || "";
};