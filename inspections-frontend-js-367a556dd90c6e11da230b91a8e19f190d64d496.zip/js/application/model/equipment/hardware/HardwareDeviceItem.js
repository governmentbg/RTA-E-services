namespace("demax.inspections.model.equipment.hardware");

demax.inspections.model.equipment.hardware.HardwareDeviceItem = function(dto) {
	var self = this;

	this.id = ko.observable(dto ? dto.id : null);
	this.serialNumber = ko.observable(dto ? dto.serialNumber : null);
	this.ip = ko.observable(dto ? dto.ip : null);
	this.type = ko.observable(dto ? dto.type : null);

	this.isUpdatable = ko.observable(true).extend({
		required: true,
		equal: false
	});

	this.hasComponentLoaded = ko.observable(false);

	this.updateFromOption = function(option) {
		if (!ko.unwrap(self.isUpdatable)) {
			return;
		}
		self.isUpdatable(false);
		self.id(ko.unwrap(option.id));
		self.serialNumber(ko.unwrap(option.serialNumber));
		self.type(ko.unwrap(option.type));
	};
	
	this.onComponentLoadedCallback = function() {
		self.hasComponentLoaded(true);
	};
};
