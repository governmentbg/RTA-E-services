namespace("demax.inspections.model.equipment.hardware");

demax.inspections.model.equipment.hardware.HardwareDeviceListItem = function(dto) {
	var self = this;

	var DeviceLocationType = demax.inspections.nomenclature.equipment.hardware.DeviceLocationType;
	var DeviceStatus = demax.inspections.nomenclature.equipment.hardware.DeviceStatus;
	var DeviceType = demax.inspections.nomenclature.equipment.hardware.DeviceType;

	this.id = dto ? dto.id : null;
	this.permit = dto ? dto.permit : null;
	this.scrapReason = dto ? dto.scrapReason : null;
	this.serialNumber = dto ? dto.serialNumber : null;
	this.status = dto ? DeviceStatus.getById(dto.status.id) : null;
	this.type = dto ? dto.type : null;
	this.warehouse = dto ? dto.warehouse : null;

	this.locationType = (function() {
		if (self.permit) {
			return DeviceLocationType.INSPECTION_POINT;
		} else {
			return DeviceLocationType.WAREHOUSE;
		}
	})();

	this.locationName = (function() {
		if (self.permit) {
			return self.permit.orgUnit.name;
		} else if (self.warehouse) {
			return self.warehouse.name;
		} else {
			return "Неизвестно";
		}
	})();

	this.iconCssClasses = (function() {
		if (self.type.code == DeviceType.DELL_COMPUTER.code) {
			return "fa m-t-3 margin-r-5 fa-laptop";
		} else if (self.type.code == DeviceType.SCANNER_THEORETICAL_EXAMS.code
				|| self.type.code == DeviceType.DELL_COMPUTER_KEYBOARD.code) {
			return "fa m-t-3 margin-r-5 fa-keyboard-o";
		} else if (self.type.code == DeviceType.XEROX_PRINTER_INSPECTIONS.code
				|| self.type.code == DeviceType.XEROX_PRINTER_FIXED_CODE.code) {
			return "fa m-t-3 margin-r-5 fa-print";
		} else if (self.type.code == DeviceType.DELL_MONITOR_INSPECTIONS.code) {
			return "fa m-t-3 margin-r-5 fa-television";
		} else if (self.type.code == DeviceType.VIVACOM_SDSL.code) {
			return "fa m-t-3 margin-r-5 fa-at";
		} else if (self.type.code == DeviceType.VIVACOM_3G_MODEM.code) {
			return "fa m-t-3 margin-r-5 fa-signal";
		} else if (self.type.code == DeviceType.VIVACOM_3G_MODEM_A.code) {
			return "fa m-t-3 margin-r-5 fa-object-group";
		} else if (self.type.code == DeviceType.GLOBUL_3G_MODEM.code) {
			return "fa m-t-3 margin-r-5 fa-map-signs";
		} else if (self.type.code == DeviceType.VIVACOM_SIM_CARD.code
				|| self.type.code == DeviceType.GLOBUL_3G_MODEM_A.code) {
			return "fa m-t-3 margin-r-5 fa-feed";
		} else if (self.type.code == DeviceType.GLOBUL_SIM_CARD.code) {
			return "fa m-t-3 margin-r-5 fa-wifi";
		} else if (self.type.code == DeviceType.SATELLITE_MODEM.code) {
			return "fa m-t-3 margin-r-5 fa-ship";
		} else if (self.type.code == DeviceType.ROUTER.code) {
			return "fa m-t-3 margin-r-5 fa-hdd-o";
		} else if (self.type.code == DeviceType.LAN_CARD.code) {
			return "fa m-t-3 margin-r-5 fa-globe";
		} else if (self.type.code == DeviceType.SATELLITE_CONVERTER.code) {
			return "fa m-t-3 margin-r-5 fa-shield";
		} else if (self.type.code == DeviceType.IP_CAMERA_INSPECTIONS.code) {
			return "fa m-t-3 margin-r-5 fa-camera";
		} else if (self.type.code == DeviceType.COMMUTATOR.code) {
			return "fa m-t-3 margin-r-5 fa-share-alt";
		} else if (self.type.code == DeviceType.DELL_COMPUTER_MOUSE.code) {
			return "fa m-t-3 margin-r-5 fa-hand-pointer-o";
		} else if (self.type.code == DeviceType.LTE_4G_MODEM.code) {
			return "fa m-t-3 margin-r-5 fa-rocket";
		} else if (self.type.code == DeviceType.WIFI_ADDAPTER.code) {
			return "fa m-t-3 margin-r-5 fa-chain";
		} else {
			return "fa m-t-3 margin-r-5";
		}
	})();
};
