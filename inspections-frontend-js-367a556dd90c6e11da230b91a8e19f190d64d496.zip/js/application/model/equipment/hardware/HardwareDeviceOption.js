namespace("demax.inspections.model.equipment.hardware");

demax.inspections.model.equipment.hardware.HardwareDeviceOption = function(dto) {
	var self = this;

	this.id = dto ? dto.id : null;
	this.serialNumber = dto ? dto.serialNumber : null;
	this.type = dto ? dto.type : null;

	this.optionsText = (function() {
		return ko.unwrap(self.serialNumber) + " - " + ko.unwrap(self.type).description;
	})();
};
