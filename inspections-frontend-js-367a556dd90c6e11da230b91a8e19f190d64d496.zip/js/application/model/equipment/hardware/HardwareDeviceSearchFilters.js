namespace("demax.inspections.model.equipment.hardware");

demax.inspections.model.equipment.hardware.HardwareDeviceSearchFilters = function(dto) {
	var self = this;
	var lastUsedFilters = null;

	this.searchText = ko.observable(dto ? ko.unwrap(dto.searchText) : null);
	this.type = ko.observable(dto ? ko.unwrap(dto.type) : null);
	this.locationType = ko.observable(dto ? ko.unwrap(dto.locationType) : null);
	this.warehouse = ko.observable(dto ? ko.unwrap(dto.warehouse) : null);
	this.orgUnit = ko.observable(dto ? ko.unwrap(dto.orgUnit) : null);
	this.status = ko.observable(dto ? ko.unwrap(dto.status) : null);

	this.toQueryParams = function() {
		var dto = {};
		
		if (self.searchText()) {
			dto.searchText = self.searchText();
		}
		if (self.type()) {
			dto.typeCode = self.type().code;
		}
		if (self.locationType()) {
			dto.locationType = self.locationType().code;
		}
		if (self.warehouse()) {
			dto.warehouseId = self.warehouse().id;
		}
		if (self.orgUnit()) {
			dto.orgUnitCode = self.orgUnit().code;
		}
		if (self.status()) {
			dto.statusId = self.status().id;
		}
		return dto;
	};
	
	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			searchText: self.searchText(),
			type: self.type(),
			locationType: self.locationType(),
			warehouse: self.warehouse(),
			orgUnit: self.orgUnit(),
			status: self.status()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.searchText(lastUsedFilters.searchText);
			self.type(lastUsedFilters.type);
			self.locationType(lastUsedFilters.locationType);
			self.warehouse(lastUsedFilters.warehouse);
			self.orgUnit(lastUsedFilters.orgUnit);
			self.status(lastUsedFilters.status);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};

	this.clear = function() {
		self.searchText(null);
		self.type(null);
		self.locationType(null);
		self.warehouse(null);
		self.orgUnit(null);
		self.status(null);
	};
};
