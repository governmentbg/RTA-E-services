namespace("demax.inspections.model.equipment.hardware");

demax.inspections.model.equipment.hardware.HardwareDeviceTransferRequestListItem = function(dto) {
	this.id = dto ? dto.id : null;
	this.courier = dto ? demax.inspections.nomenclature.Courier[dto.courierName] : null;
	this.courierServiceType = dto ? demax.inspections.nomenclature.CourierServiceType["STANDARD"] : null;
	this.billOfLadingId = dto ? dto.billOfLadingId : null;
	this.createdAt = dto ? moment.fromJacksonDateTimeArray(dto.createdAt) : null;
	this.warehouse = dto ? dto.warehouse : null;
	this.protocolsIds = dto ? dto.protocolsIds : null;
	this.hardwareItemsCount = dto ? dto.hardwareItemsCount : null;
	this.packageCount = ko.observable(dto ? dto.packageCount : 0);
	this.weight = ko.observable(dto ? dto.weightKg : 0);
	this.status = dto ? demax.inspections.nomenclature.BillOfLadingStatus[dto.statusCode] : null;
};
