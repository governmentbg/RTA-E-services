namespace("demax.inspections.model.orders");

demax.inspections.model.equipment.hardware.HardwareDeviceTransferSearchFilters = function() {
	var self = this;
	var BolStatus = demax.inspections.nomenclature.BillOfLadingStatus;
	var lastUsedFilters = null;

	this.searchText = ko.observable();
	this.warehouse = ko.observable();
	this.createdAt = ko.observable();
	this.status = ko.observable(BolStatus.NOT_SENT);

	this.toQueryParams = function() {
		var dto = {};
		
		if (self.searchText()) {
			dto.searchText = self.searchText().trim();
		}
		if (self.warehouse()) {
			dto.warehouseId = self.warehouse().id;
		}
		if (self.createdAt()) {
			dto.createdAt = self.createdAt().format(demax.inspections.settings.serverDateFormat);
		}
		if (self.status()) {
			dto.statusCode = self.status().code;
		}
		return dto;
	};
	
	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			searchText: self.searchText(),
			warehouse: self.warehouse(),
			createdAt: self.createdAt(),
			status: self.status()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.searchText(lastUsedFilters.searchText);
			self.warehouse(lastUsedFilters.warehouse);
			self.createdAt(lastUsedFilters.createdAt);
			self.status(lastUsedFilters.status);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.searchText(null);
		self.warehouse(null);
		self.createdAt(null);
		self.status(null);
	};
};
