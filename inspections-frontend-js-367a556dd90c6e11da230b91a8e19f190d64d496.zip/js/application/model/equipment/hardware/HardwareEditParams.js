namespace("demax.inspections.model.equipment.hardware");

demax.inspections.model.equipment.hardware.HardwareEditParams = function(dto) {
	var self = this;

	var DeviceType = demax.inspections.nomenclature.equipment.hardware.DeviceType;

	this.deviceType = dto.deviceType;
	this.warehouse = ko.observable(dto.warehouse);

	this.serialNumber = ko.observable(dto.serialNumber).extend({
		required : {
			message : "Полето е задължително"
		},
		validation: [{
			validator: function(value) { // device serial number validator
				var deviceRexex = /^[A-Z0-9]*$/g;

				var matchArray = null;
				if (self.deviceType && self.deviceType.code !== DeviceType.VIVACOM_SIM_CARD.code
								&& self.deviceType.code !== DeviceType.GLOBUL_SIM_CARD.code) {
					matchArray = value.match(deviceRexex);
				} else {
					return true;
				}
				return matchArray && matchArray.length > 0;
			},
			message: "Серийният номер трябва да съдържа само главни букви на латиница A-Z и цифрите 0-9"
		}, {
			validator: function(value) { // sim card serial number validator
				var simRegex = /^[0-9]{0,22}$/g;

				var matchArray = null;
				if (self.deviceType && (self.deviceType.code == DeviceType.VIVACOM_SIM_CARD.code
								|| self.deviceType.code == DeviceType.GLOBUL_SIM_CARD.code)) {
					matchArray = value.match(simRegex);
				} else {
					return true;
				}
				return matchArray && matchArray.length > 0;
			},
			message: "Серийният номер трябва да съдържа само цифри 0-9 и да е с максимална дължина 22"
		}]
	});

	this.macAddress = ko.observable(dto.macAddress).extend({
		required : {
			onlyIf : function() {
				return self.deviceType !== undefined
								&& (self.deviceType.code == DeviceType.IP_CAMERA_INSPECTIONS.code);
			},
			message : "Полето е задължително"
		}
	});
	this.ipAddress = ko.observable(dto.ipAddress).extend({
		required: {
			onlyIf: function() {
				return self.deviceType !== undefined && (self.deviceType.code == 55 || self.deviceType.code == 60);
			},
			message: "Полето е задължително"
		}
	});
	this.status = ko.observable(dto.status);
	this.scrapReason = ko.observable(dto.scrapReason).extend({
		required: {
			onlyIf: function() {
				return self.status() !== undefined && self.status().id == 3;
			},
			message: "Полето е задължително"
		}
	});

	this.toJsonRequest = function() {
		var dto = {
			typeCode : self.deviceType !== undefined ? self.deviceType.code : null,
			warehouseId : self.warehouse() !== undefined ? self.warehouse().id : null,
			serialNumber : self.serialNumber(),
			macAddress : self.macAddress(),
			ipAddress : self.ipAddress(),
			statusId : self.status() != undefined ? self.status().id : null
		};
		if (self.status() && self.status().id == 3) {
			dto.scrapReason = self.scrapReason();
		}
		return JSON.stringify(dto);
	};
};
