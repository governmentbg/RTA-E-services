namespace("demax.inspections.model.equipment.hardware");

demax.inspections.model.equipment.hardware.WarehouseShippingInfo = function(dto) {
	var self = this;

	this.warehouse = dto ? dto.warehouse : null;
	this.city = dto ? dto.city : null;
	this.speedyOfficeAddress = dto ? dto.speedyOfficeAddress : null;
	this.address = ko.observable(dto ? dto.address : null).extend({
		required: true,
		minLength: 5
	});
	this.recipientPersonName = ko.observable(dto ? dto.recipientPersonName : null).extend({
		required: true
	});
	this.recipientPersonPhone = ko.observable(dto ? dto.recipientPersonPhone : null).extend({
		required: true
	});

	this.toDto = function() {
		var warehouseId = ko.unwrap(self.warehouse) ? ko.unwrap(self.warehouse).id : null;
		var address = ko.unwrap(self.address) ? ko.unwrap(self.address) : null;
		var recipientPersonName = ko.unwrap(self.recipientPersonName) ? ko.unwrap(self.recipientPersonName) : null;
		var recipientPersonPhone = ko.unwrap(self.recipientPersonPhone) ? ko.unwrap(self.recipientPersonPhone) : null;
		var speedyOfficeAddress = ko.unwrap(self.speedyOfficeAddress) ? ko.unwrap(self.speedyOfficeAddress) : null;

		return {
			warehouseId: warehouseId,
			address: address,
			recipientPersonName: recipientPersonName,
			recipientPersonPhone: recipientPersonPhone,
			speedyOfficeAddress: speedyOfficeAddress
		};
	};
};
