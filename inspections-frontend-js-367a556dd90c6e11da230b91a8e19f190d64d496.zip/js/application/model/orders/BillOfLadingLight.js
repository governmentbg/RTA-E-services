namespace("demax.inspections.model.orders");

demax.inspections.model.orders.BillOfLadingLight = function(dto) {

	var self = this;
	var BolStatus = demax.inspections.nomenclature.BillOfLadingStatus;
	var Courier = demax.inspections.nomenclature.Courier;
	var CourierServiceType = demax.inspections.nomenclature.CourierServiceType;

	this.id = dto.id;
	this.billOfLadingIdForCourier = dto.billOfLadingIdForCourier !== undefined ? dto.billOfLadingIdForCourier : null;
	this.courier = Courier[dto.courierCode];
	this.courierServiceType = CourierServiceType[dto.courierServiceTypeCode];
	this.status = ko.observable(BolStatus[dto.statusCode]);
	this.createdAt = dto.createdAt !== undefined ? moment.fromJacksonDateTimeArray(dto.createdAt) : null;
	this.fixedTimeDelivery = dto.fixedTimeDelivery !== undefined ? moment.fromJacksonTimeArray(dto.fixedTimeDelivery) : null;
	this.orgUnit = dto.orgUnit !== undefined ? new demax.inspections.model.OrgUnit(dto.orgUnit) : null;
	this.protocols = dto.protocols !== undefined ? dto.protocols : null;
	this.packageCount = dto.packageCount !== undefined ? dto.packageCount : null;
	this.weight = dto.weight !== undefined ? dto.weight : null;

	this.hasFixedTimeDelivery = ko.pureComputed(function() {
		return self.courierServiceType === CourierServiceType.EXPRESS;
	});
	
	this.formattedFixedTimeDelivery = function() {
		var time = self.fixedTimeDelivery;
		return self.hasFixedTimeDelivery() && time ? time.format(demax.inspections.settings.momentTimeFormat) : "";
	}();
	
	this.getProtocolsToText = function() {
		if (self.protocols && self.protocols.length > 0) {
			return self.protocols.join();
		} else {
			return "-";
		}
	}();

	this.formatWeight = function() {
		if (self.weight) {
			return self.weight + " кг.";
		} else {
			return "-";
		}
	}();

	this.canSend = ko.pureComputed(function() {
		return self.status() == BolStatus.NOT_SENT;
	});

	this.canCancel = ko.pureComputed(function() {
		return self.status() == BolStatus.REQUESTED;
	});

	this.formatPackageCount = function() {
		if (self.packageCount) {
			return self.packageCount + " бр.";
		} else {
			return "-";
		}
	}();

	this.hasBolPdf = function () {
		return self.courier == Courier.SPEEDY || self.courier == Courier.ECONT;   
	}();
};
