namespace("demax.inspections.model.orders");

demax.inspections.model.orders.BillOfLadingSearchFilters = function() {
	var self = this;
	var lastUsedFilters = null;
	var BolStatus = demax.inspections.nomenclature.BillOfLadingStatus;
	
	this.searchText = ko.observable();
	this.orgUnit = ko.observable();
	this.date = ko.observable();
	this.statuses = ko.observable([BolStatus.REQUESTED, BolStatus.NOT_SENT]);

	this.toQueryParams = function() {
		var dto = {};
		var statuses = ko.unwrap(self.statuses());
		
		if (self.searchText() !== null && self.searchText() !== undefined) {
			dto.billOfLadingIdForCourierOrProtocolId = self.searchText().trim();
		}
		if (self.orgUnit()) {
			dto.orgUnitCode = self.orgUnit().code;
		}
		if (self.date()) {
			dto.exactDate = self.date().format(demax.inspections.settings.serverDateFormat);
		}
		if (Array.isArray(statuses)
			&& statuses.length > 0
			&& statuses[0] !== undefined
			&& statuses[0] !== null) {
			dto.statusCodes = statuses.reduce(function(reducedAr, status) {
				reducedAr.push(status.code);
				return reducedAr;
			}, []);
		}
		return dto;
	};
	
	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			searchText: self.searchText(),
			orgUnit: self.orgUnit(),
			date: self.date(),
			statuses: self.statuses()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.searchText(lastUsedFilters.searchText);
			self.orgUnit(lastUsedFilters.orgUnit);
			self.date(lastUsedFilters.date);
			self.statuses(lastUsedFilters.statuses);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.searchText(null);
		self.orgUnit(null);
		self.date(null);
		self.statuses([]);
	};
};
