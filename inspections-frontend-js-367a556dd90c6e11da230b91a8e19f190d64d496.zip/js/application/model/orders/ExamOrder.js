namespace("demax.inspections.model.orders");

demax.inspections.model.orders.ExamOrder = function(dto) {
	dto = dto || {};

	var self = this;
	var OrderUtils = demax.inspections.utils.OrderUtils;
	var BillOfLadingLight = demax.inspections.model.orders.BillOfLadingLight;
	var ExamOrderCustomer = demax.inspections.model.orders.ExamOrderCustomer;
	var ExamOrderStatus = demax.inspections.nomenclature.orders.ExamOrderStatus;

	this.id = dto.id;
	this.orderCreationDate = (dto.orderCreationDate && moment.fromJacksonDateTimeArray(dto.orderCreationDate)) || null;
	this.receptionCityName = dto.receptionCityName || null;
	this.receptionAddress = dto.receptionAddress || null;
	this.receptionPersonName = dto.receptionPersonName || null;
	this.receptionPersonPhoneNumber = dto.receptionPersonPhoneNumber || null;
	this.status = ko.observable(ExamOrderStatus[dto.statusCode]);
	this.accountantName = dto.accountantName || null;
	this.accountantCode = dto.accountantCode || null;
	this.invoiceDateTime = (dto.invoiceDateTime && moment.fromJacksonDateTimeArray(dto.invoiceDateTime)) || null;
	this.invoiceNumber = dto.invoiceNumber || null;
	this.hasBankStatement = dto.hasBankStatement || false;
	this.examOrderCustomer = (dto.examOrderCustomerDto && new ExamOrderCustomer(dto.examOrderCustomerDto)) || null;

	this.examOrderItems = OrderUtils.mergeOrderItemsByProduct(dto.examOrderItemDtos);

	var bolDto = dto.billOfLadingDto;
	this.billOfLading = ko.observable(bolDto !== undefined && bolDto !== null ? new BillOfLadingLight(bolDto) : null);

	this.doAllOrderItemsHaveAllIntervals = ko.pureComputed(function() {
		var orderItems = self.examOrderItems;
		return orderItems.every(function(orderItem) {
			return orderItem.hasAllIntervals();
		});
	});

	this.intervalsCssClass = ko.pureComputed(function() {
		return self.areIntervalsApproximate() ? "text-red" : "text-green" + " textSize";
	});

	this.areIntervalsApproximate = function() {
		return self.status().stage <= ExamOrderStatus.PAID.stage;
	};

	this.toDeliveryDetails = function() {
		return {
			invoiceNumber: self.invoiceNumber,
			invoiceDateTime: self.invoiceDateTime,
			accountantName: self.accountantName,
			accountantCode: self.accountantCode,
			companyName: self.examOrderCustomer !== null ? self.examOrderCustomer.companyName : "",
			eik: self.examOrderCustomer !== null ? self.examOrderCustomer.eik : "",
			vatNumber: self.examOrderCustomer !== null ? self.examOrderCustomer.vatNumber : null,
			receptionAddress: self.receptionAddress,
			mol: self.examOrderCustomer !== null ? self.examOrderCustomer.mol : "",
			phoneNumber: self.examOrderCustomer !== null ? self.examOrderCustomer.phoneNumber : "",
			receptionPersonName: self.receptionPersonName,
			receptionPersonPhoneNumber: self.receptionPersonPhoneNumber,
			invoiceAddress: self.examOrderCustomer !== null ? self.examOrderCustomer.address : "",
			billOfLading: self.billOfLading
		};
	};

};
