namespace("demax.inspections.model.orders");

demax.inspections.model.orders.ExamOrderCustomer = function(dto) {
	this.companyName = dto.companyName !== undefined ? dto.companyName : null;
	this.eik = dto.eik !== undefined ? dto.eik : null;
	this.cityName = dto.cityName !== undefined ? dto.cityName : null;
	this.phoneNumber = dto.phoneNumber !== undefined ? dto.phoneNumber : null;
	this.address = dto.address !== undefined ? dto.address : null;
	this.mol = dto.mol !== undefined ? dto.mol : null;
	this.municipality = dto.municipality !== undefined ? dto.municipality : null;
	this.vatNumber = dto.vatNumber !== undefined ? dto.vatNumber : null;
};
