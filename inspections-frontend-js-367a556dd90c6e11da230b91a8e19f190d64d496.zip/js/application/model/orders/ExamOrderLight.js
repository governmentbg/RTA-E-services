namespace("demax.inspections.model.orders");

demax.inspections.model.orders.ExamOrderLight = function(dto) {
	var self = this;

	var OrderItemLight = demax.inspections.model.orders.OrderItemLight;
	var ExamOrderStatus = demax.inspections.nomenclature.orders.ExamOrderStatus;

	this.id = dto !== undefined && dto.id !== undefined ? dto.id : "";
	this.createdAt = moment.fromJacksonDateTimeArray(dto.createdAt);
	this.companyName = dto !== undefined && dto.companyName !== undefined ? dto.companyName : "";
	this.eik = dto !== undefined && dto.eik !== undefined ? dto.eik : "";
	this.permitNumber = dto !== undefined && dto.permitNumber !== undefined ? dto.permitNumber : "";
	this.status = ko.observable(ExamOrderStatus[dto.statusCode]);
	this.receptionCityName = dto !== undefined && dto.receptionCityName !== undefined ? dto.receptionCityName : "";
	this.receptionAddress = dto !== undefined && dto.receptionAddress !== undefined ? dto.receptionAddress : "";

	this.items = ko.utils.arrayMap(dto.orderItems, function(itemDto) {
		return new OrderItemLight(itemDto);
	});

	this.intervalAndQuantityConcat = (function() {
		var intervalsAndQuantityArray = [];
		self.items.forEach(function(item) {
			var itemText = "";
			var hasFromNum = item.fromNum !== undefined && item.fromNum !== null; 
			var hasToNum = item.toNum !== undefined && item.toNum !== null;
			if (hasFromNum && hasToNum) {
				itemText = getFormattedIntervals(item.fromNum, item.toNum);
			}
			itemText += item.quantity + " бр.";

			intervalsAndQuantityArray.push(itemText);
		});

		return intervalsAndQuantityArray.join(", ");
	})();
	
	function getFormattedIntervals(fromNum, toNum) {
		var formattedFromNum = fromNum ? fromNum.toString().match(/(\d+?)(?=(\d{3})+(?!\d)|$)/g).join(" ") : "";
		var formattedToNum = toNum ? toNum.toString().match(/(\d+?)(?=(\d{3})+(?!\d)|$)/g).join(" ") : "";
		
		if (formattedFromNum && formattedToNum) {
			return formattedFromNum + " - " + formattedToNum + " / ";
		}
		return "";
	}
};
