namespace("demax.inspections.model.orders");

demax.inspections.model.orders.ExamOrderSearchFilters = function(dto) {
	var self = this;
	var lastUsedFilters = null;

	this.searchText = ko.observable(dto ? ko.unwrap(dto.searchText) : null);
	this.selectedCity = ko.observable(dto ? ko.unwrap(dto.selectedCity) : null);
	this.date = ko.observable(dto ? ko.unwrap(dto.date) : null);
	this.status = ko.observable(dto ? ko.unwrap(dto.status) : null);

	this.toQueryParams = function() {
		var dto = {};

		if (self.searchText()) {
			dto.idFirmEikOrPermitNumber = self.searchText();
		}
		if (self.selectedCity()) {
			dto.cityCode = self.selectedCity().code;
		}
		if (self.date()) {
			dto.exactDate = self.date().format(demax.inspections.settings.serverDateFormat);
		}
		if (self.status()) {
			dto.statusCodes = [self.status().code];
		}
		return dto;
	};

	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			searchText: self.searchText(),
			selectedCity: self.selectedCity(),
			date: self.date(),
			status: self.status()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.searchText(lastUsedFilters.searchText);
			self.selectedCity(lastUsedFilters.selectedCity);
			self.date(lastUsedFilters.date);
			self.status(lastUsedFilters.status);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.searchText(null);
		self.selectedCity(null);
		self.date(null);
		self.status(null);
	};
};
