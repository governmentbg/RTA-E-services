namespace("demax.inspections.model.orders");

demax.inspections.model.orders.InspectionBillOfLading = function(dto) {
	dto = dto || {};

	var self = this;
	var Courier = demax.inspections.nomenclature.Courier;
	var CourierServiceType = demax.inspections.nomenclature.CourierServiceType;
	var InspectionProtocolLight = demax.inspections.model.orders.InspectionProtocolLight;
	
	this.id = dto.id || null;
	this.billOfLadingIdForCourier = dto.billOfLadingIdForCourier !== undefined ? dto.billOfLadingIdForCourier : null;
	this.courier = dto.courierCode !== undefined ? Courier[dto.courierCode] : null;
	this.courierServiceType = dto.courierServiceTypeCode !== undefined ?
		CourierServiceType[dto.courierServiceTypeCode] : null;
	this.createdAt = dto.createdAt !== undefined ? moment.fromJacksonDateTimeArray(dto.createdAt) : null;
	this.fixedTimeDelivery = dto.fixedTimeDelivery !== undefined ? moment.fromJacksonTimeArray(dto.fixedTimeDelivery) : null;
	this.status = dto.statusCode !== undefined ? demax.inspections.nomenclature.BillOfLadingStatus[dto.statusCode] : null;
	this.recipient = dto.recipient || null;
	this.contactPersonName = dto.contactPersonName || null;
	this.contactPersonPhoneNumber = dto.contactPersonPhoneNumber || null;
	this.shippingAddress = dto.shippingAddress || null;
	this.orgUnit = new demax.inspections.model.OrgUnit(dto.orgUnit);
	this.weight = dto.weight || null;
	this.packageCount = dto.packageCount || null;

	this.hasFixedTimeDelivery = ko.pureComputed(function() {
		return self.courierServiceType === CourierServiceType.EXPRESS;
	});
	
	this.formattedFixedTimeDelivery = function() {
		var time = self.fixedTimeDelivery;
		return self.hasFixedTimeDelivery() && time ? time.format(demax.inspections.settings.momentTimeFormat) : "";
	}();
	
	this.protocols = ko.utils.arrayMap(dto.protocols, function(protocolDto) {
		return new InspectionProtocolLight(protocolDto);
	});

	this.hasBolPdf = function() {
		return self.courier == Courier.SPEEDY || self.courier == Courier.ECONT;
	}();

};
