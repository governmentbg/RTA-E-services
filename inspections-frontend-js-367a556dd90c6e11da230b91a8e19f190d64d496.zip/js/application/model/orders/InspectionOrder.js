namespace("demax.inspections.model.orders");

demax.inspections.model.orders.InspectionOrder = function(dto) {
	var OrderUtils = demax.inspections.utils.OrderUtils;
	var BillOfLadingLight = demax.inspections.model.orders.BillOfLadingLight;
	var InspectionOrderStatus = demax.inspections.nomenclature.orders.InspectionOrderStatus;
	var InspectionProductsWithIntervals = demax.inspections.nomenclature.orders.InspectionProductsWithIntervals;

	this.accountantCode = dto.accountantCode !== undefined ? dto.accountantCode : null;
	this.accountantName = dto.accountantName !== undefined ? dto.accountantName : null;
	this.activationCode = typeof(dto.activationCode) == "string" && dto.activationCode.trim().length > 0 ? dto.activationCode : null;
	var bolDto = dto.billOfLadingDto;
	this.billOfLading = bolDto !== undefined && bolDto !== null ? new BillOfLadingLight(bolDto) : null;
	this.createdAt = moment.fromJacksonDateTimeArray(dto.createdAt);
	this.companyName = dto.companyName !== undefined ? dto.companyName : null;
	this.eik = dto.eik !== undefined ? dto.eik : null;
	this.hasBankStatement = dto.hasBankStatement === true;
	this.id = dto.id;
	this.invoiceAddress = dto.invoiceAddress !== undefined ? dto.invoiceAddress : null;
	this.invoiceDateTime = dto.invoiceDateTime !== undefined ? moment.fromJacksonDateTimeArray(dto.invoiceDateTime) : null;
	this.invoiceNumber = dto.invoiceNumber !== undefined ? dto.invoiceNumber : null;
	this.managerName = dto.managerName !== undefined ? dto.managerName : null;
	this.managerPhoneNumber = dto.managerPhoneNumber !== undefined ? dto.managerPhoneNumber : null;
	this.permitNumber = dto.permitNumber !== undefined ? dto.permitNumber : null;
	this.receptionName = dto.receptionName !== undefined ? dto.receptionName : null;
	this.receptionAddress = dto.receptionAddress !== undefined ? dto.receptionAddress : null;
	this.receptionPhone = dto.receptionPhone !== undefined ? dto.receptionPhone : null;
	this.vatNumber = dto.vatNumber !== undefined ? dto.vatNumber : null;
	this.status = dto.statusCode !== undefined ?
		ko.observable(InspectionOrderStatus[dto.statusCode]) : ko.observable(null);
	this.quantity = dto.quantity;
	this.weight = dto.weight !== undefined ? dto.weight : null;
	this.desiredWeightAndWeightOffset = dto.desiredWeightAndWeightOffset !== null ?
		new demax.inspections.model.WeightAndWeightOffset(dto.desiredWeightAndWeightOffset) : null;
	this.orderItems = OrderUtils.mergeOrderItemsByProduct(dto.orderItems);

	this.orderItems.forEach(function(orderItem) {
		orderItem.hasIntervals = InspectionProductsWithIntervals.indexOf(orderItem.productId) > -1;
	});

	this.toDeliveryDetails = function() {
		return {
			orderId: this.id,
			status: this.status().code,
			invoiceNumber: this.invoiceNumber,
			invoiceDateTime: this.invoiceDateTime,
			accountantName: this.accountantName,
			accountantCode: this.accountantCode,
			companyName: this.companyName,
			eik: this.eik,
			vatNumber: this.vatNumber,
			receptionAddress: this.receptionAddress,
			mol: this.managerName,
			phoneNumber: this.managerPhoneNumber,
			receptionPersonName: this.receptionName,
			receptionPersonPhoneNumber: this.receptionPhone,
			invoiceAddress: this.invoiceAddress,
			billOfLading: this.billOfLading
		};
	};
};
