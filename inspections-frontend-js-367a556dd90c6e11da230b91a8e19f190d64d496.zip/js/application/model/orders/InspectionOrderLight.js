namespace("demax.inspections.model.orders");

demax.inspections.model.orders.InspectionOrderLight = function(dto) {
	var self = this;

	var OrderUtils = demax.inspections.utils.OrderUtils;
	var InspectionOrderStatus = demax.inspections.nomenclature.orders.InspectionOrderStatus;
	var InspectionProductsWithIntervals = demax.inspections.nomenclature.orders.InspectionProductsWithIntervals;

	this.id = dto && dto.id ? dto.id : "-";
	this.createdAt = moment.fromJacksonDateTimeArray(dto.createdAt);
	this.companyName = dto && dto.companyName ? dto.companyName : "-";
	this.eik = dto && dto.eik ? dto.eik : "";
	this.permitNumber = dto && dto.permitNumber ? dto.permitNumber : "-";
	this.managerPhoneNumber = dto && dto.managerPhoneNumber ? dto.managerPhoneNumber : "-";
	this.status = InspectionOrderStatus[dto.statusCode];
	this.receptionName = dto && dto.receptionName ? dto.receptionName : "-";
	this.quantity = dto && dto.quantity ? dto.quantity : "-";
	this.weight = dto && dto.weight ? dto.weight : "-";

	this.orderItems = OrderUtils.mergeOrderItemsByProduct(dto.orderItems);

	this.orderItems.forEach(function(orderItem) {
		orderItem.hasIntervals = InspectionProductsWithIntervals.indexOf(orderItem.productId) > -1;
	});

	this.orderItemsWithIntervalsConcat = (function() {
		if (self.status.stage < InspectionOrderStatus.PRINT_LABEL.stage) {
			return "";
		}

		var orderItemsWithIntervalsConcat = "";

		self.orderItems.forEach(function(orderItem) {
			if (!orderItem.hasIntervals) {
				return;
			}

			if (orderItemsWithIntervalsConcat != "") {
				orderItemsWithIntervalsConcat += ", ";
			}

			orderItemsWithIntervalsConcat += orderItem.intervalsConcat;
		});

		return orderItemsWithIntervalsConcat;
	})();

	this.orderItemsTypesConcat = (function () {
		var orderItemsTypesConcat = "";

		self.orderItems.forEach(function (item) {

			if (orderItemsTypesConcat != "") {
				orderItemsTypesConcat += ", ";
			}

			orderItemsTypesConcat += item.productName;

		});

		return orderItemsTypesConcat;
	})();

};
