namespace("demax.inspections.model.orders");

demax.inspections.model.orders.InspectionOrderPackagingSearchFilters = function() {
	var self = this;
	var InspectionOrderStatus = demax.inspections.nomenclature.orders.InspectionOrderStatus;

	this.searchText = ko.observable();
	this.orgUnit = ko.observable();
	this.date = ko.observable();
	
	this.toPaidQueryParams = function() {
		var dto = {};
		
		if (self.searchText()) {
			dto.idFirmEikOrPermitNum = self.searchText().trim();
		}
		if (self.orgUnit()) {
			dto.orgUnitCode = self.orgUnit().code;
		}
		if (self.date()) {
			dto.exactDate = self.date().format(demax.inspections.settings.serverDateFormat);
		}
		dto.statusCodes = [InspectionOrderStatus.PAID.code];
		return dto;
	};
	
	this.toLabelQueryParams = function() {
		var dto = {};
		
		if (self.orgUnit()) {
			dto.orgUnitCode = self.orgUnit().code;
		}
		dto.statusCodes = [InspectionOrderStatus.PRINT_LABEL.code];
		return dto;
	};
	
	this.copyProperties = function() {
		var dto = {
			searchText: self.searchText(),
			orgUnit: self.orgUnit(),
			date: self.date()
		};
		return dto;
	};
};
