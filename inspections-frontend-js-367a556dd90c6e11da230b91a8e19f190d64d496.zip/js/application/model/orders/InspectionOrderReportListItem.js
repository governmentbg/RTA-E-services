namespace("demax.inspections.model.orders");

demax.inspections.model.orders.InspectionOrderReportListItem = function(dto) {

	this.id = dto ? dto.id : null;
	this.permitNumber = dto ? dto.permitNumber : null;
	this.companyName = dto ? dto.companyName : null;
	this.orgUnit = dto ? dto.orgUnit : null;
	this.orderDateTime = dto ? moment.fromJacksonDateTimeArray(dto.orderDateTime) : null;
	this.activationDateTime = dto ? moment.fromJacksonDateTimeArray(dto.activationDateTime) : null;
	this.invoiceNumber = dto ? dto.invoiceNumber : null;
	this.invoiceDate = dto ? moment.fromJacksonDateTimeArray(dto.invoiceDate) : null;
	this.status = dto ? dto.status : null;
	this.hasBankStatement = dto ? dto.hasBankStatement : null;
};