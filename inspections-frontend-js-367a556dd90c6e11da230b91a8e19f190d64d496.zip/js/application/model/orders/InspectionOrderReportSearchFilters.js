namespace("demax.inspections.model.orders");

demax.inspections.model.orders.InspectionOrderReportSearchFilters = function() {
	var self = this;
	var lastUsedFilters = null;
	
	this.searchText = ko.observable();
	this.orgUnit = ko.observable();
	this.orderStatus = ko.observable();
	this.hasBankStatement = ko.observable();
	this.dateRange = ko.observable(new pastel.plus.binding.dateRangePicker.model.DateRange(moment().subtract(7, "d"), moment()));

	this.toQueryParams = function() {
		var dto = {};
		
		if (self.searchText()) {
			dto.searchText = self.searchText();
		}
		if (self.orgUnit()) {
			dto.orgUnit = self.orgUnit().code;
		}
		if (self.orderStatus()) {
			dto.orderStatus = self.orderStatus();
		}
		if (self.hasBankStatement() !== undefined) {
			dto.hasBankStatement = self.hasBankStatement();
		}
		if (self.dateRange() && self.dateRange().fromDate()) {
			dto.orderDateFrom = self.dateRange().fromDate().format(demax.inspections.settings.serverDateFormat);
		}
		if (self.dateRange() && self.dateRange().toDate()) {
			dto.orderDateTo = self.dateRange().toDate().format(demax.inspections.settings.serverDateFormat);
		}
		return dto;
	};
	
	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			searchText: self.searchText(),
			orgUnit: self.orgUnit(),
			orderStatus: self.orderStatus(),
			hasBankStatement: self.hasBankStatement(),
			dateRange: self.dateRange()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.searchText(lastUsedFilters.searchText);
			self.orgUnit(lastUsedFilters.orgUnit);
			self.orderStatus(lastUsedFilters.orderStatus);
			self.hasBankStatement(lastUsedFilters.hasBankStatement);
			self.dateRange(lastUsedFilters.dateRange);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.searchText(null);
		self.orgUnit(null);
		self.orderStatus(null);
		self.hasBankStatement(null);
		self.dateRange().fromDate(moment().subtract(7, "d"));
		self.dateRange().toDate(moment());
	};
};