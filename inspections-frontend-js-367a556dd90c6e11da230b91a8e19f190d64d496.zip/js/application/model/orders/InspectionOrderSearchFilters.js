namespace("demax.inspections.model.orders");

demax.inspections.model.orders.InspectionOrderSearchFilters = function() {
	var self = this;
	var lastUsedFilters = null;
	
	this.searchText = ko.observable();
	this.orgUnit = ko.observable();
	this.date = ko.observable();
	this.status = ko.observable();

	this.toQueryParams = function() {
		var dto = {};
		
		if (self.searchText()) {
			dto.idFirmEikOrPermitNum = self.searchText().trim();
		}
		if (self.orgUnit()) {
			dto.orgUnitCode = self.orgUnit().code;
		}
		if (self.date()) {
			dto.exactDate = self.date().format(demax.inspections.settings.serverDateFormat);
		}
		if (self.status()) {
			dto.statusCodes = [self.status().code];
		}
		return dto;
	};
	
	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			searchText: self.searchText(),
			orgUnit: self.orgUnit(),
			date: self.date(),
			status: self.status()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.searchText(lastUsedFilters.searchText);
			self.orgUnit(lastUsedFilters.orgUnit);
			self.date(lastUsedFilters.date);
			self.status(lastUsedFilters.status);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.searchText(null);
		self.orgUnit(null);
		self.date(null);
		self.status(null);
	};
};
