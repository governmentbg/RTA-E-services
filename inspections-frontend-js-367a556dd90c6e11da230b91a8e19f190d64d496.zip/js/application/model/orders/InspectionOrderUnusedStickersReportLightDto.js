namespace("demax.inspections.model.orders");

demax.inspections.model.orders.InspectionOrderUnusedStickersReportLightDto = function(dto) {
	var momentDateFormat = demax.inspections.settings.momentDateFormat;
	var self = this;
	
	this.id = dto ? dto.id : null;
	this.createdAt = dto && dto.createdAt ? moment.fromJacksonDateTimeArray(dto.createdAt) : null;
	this.activatedAt = dto && dto.activatedAt ? moment.fromJacksonDateTimeArray(dto.activatedAt) : null;
	this.quantity = dto ? dto.quantity : null;
	this.unusedStickers = dto ? dto.unusedStickers : null;

	this.formattedCreatedAtDate= function() {
		var date = self.createdAt;
		return date ? date.format(momentDateFormat) : "";
	}();
	
	this.formattedActivatedAtDate= function() {
		var date = self.activatedAt;
		return date ? date.format(momentDateFormat) : "";
	}();
};
