namespace("demax.inspections.model.orders");

demax.inspections.model.orders.InspectionProtocol = function(dto) {
	var self = this;

	var InspectionOrderLight = demax.inspections.model.orders.InspectionOrderLight; 

	this.id = dto.id;
	this.creationTimestamp = dto.creationTimestamp !== undefined ? moment.fromJacksonDateTimeArray(dto.creationTimestamp) : null;
	this.billOfLadingIdForCourier = dto.billOfLadingIdForCourier !== undefined ? dto.billOfLadingIdForCourier : null;
	this.orgUnitName = dto.orgUnitName !== undefined ? dto.orgUnitName : null;
	this.ordersCount = dto.ordersCount !== undefined ? dto.ordersCount : null;
	this.itemsCount = dto.itemsCount !== undefined ? dto.itemsCount : null;
	this.weight = dto.weight !== undefined ? dto.weight : null;

	this.orders = ko.utils.arrayMap(dto.orders, function(orderDto) {
		return new InspectionOrderLight(orderDto);
	});

	this.summary = (function() {
		var summary = "";
		var hasWeight = self.weight !== null;
		var hasItemsCount = self.itemsCount !== null;

		if (hasItemsCount) {
			summary += "Комплекти " + self.itemsCount + " бр.";
		}

		if (hasItemsCount && hasWeight) {
			summary += " / ";
		}

		if (hasWeight) {
			summary += "Общо тегло " + self.weight + " кг.";
		}

		return summary;
	})();
};
