namespace("demax.inspections.model.orders");

demax.inspections.model.orders.InspectionProtocolLight = function(dto) {

	var urlStr = "https://www.speedy.bg/bg/track-shipment?shipmentNumber=";


	this.id = dto.id;
	this.creationTimestamp = dto.creationTimestamp !== undefined ? moment.fromJacksonDateTimeArray(dto.creationTimestamp) : null;
	this.billOfLading = dto.billOfLadingIdForCourier !== undefined ? dto.billOfLadingIdForCourier : null;
	this.orgUnitName = dto.orgUnitName !== undefined ? dto.orgUnitName : null;
	this.ordersCount = dto.ordersCount !== undefined ? dto.ordersCount : null;
	this.itemsCount = dto.itemsCount !== undefined ? dto.itemsCount : null;
	this.weight = dto.weight !== undefined ? dto.weight : null;

	this.url = this.billOfLading != undefined ? urlStr + this.billOfLading : null;
};
