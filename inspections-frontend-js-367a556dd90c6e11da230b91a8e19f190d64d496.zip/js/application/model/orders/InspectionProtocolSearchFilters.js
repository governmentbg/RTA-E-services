namespace("demax.inspections.model.orders");

demax.inspections.model.orders.InspectionProtocolSearchFilters = function() {
	var self = this;
	var lastUsedFilters = null;
	
	this.protocolNumber = ko.observable();
	this.orgUnit = ko.observable();
	this.date = ko.observable();

	this.toQueryParams = function() {
		var dto = {};
		
		if (self.protocolNumber()) {
			dto.protocolNumber = self.protocolNumber();
		}
		if (self.orgUnit()) {
			dto.orgUnitCode = self.orgUnit().code;
		}
		if (self.date()) {
			dto.date = self.date().format(demax.inspections.settings.serverDateFormat);
		}
		return dto;
	};
	
	this.saveLastUsedFilters = function() {
		var usedFilters = {};
		usedFilters.protocolNumber = self.protocolNumber();
		usedFilters.orgUnit = self.orgUnit();
		usedFilters.date = self.date();
		lastUsedFilters = usedFilters;
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.protocolNumber(lastUsedFilters.protocolNumber);
			self.orgUnit(lastUsedFilters.orgUnit);
			self.date(lastUsedFilters.date);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.protocolNumber(null);
		self.orgUnit(null);
		self.date(null);
	};
};
