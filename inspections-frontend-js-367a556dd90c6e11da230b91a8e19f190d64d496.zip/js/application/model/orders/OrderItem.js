namespace("demax.inspections.model.orders");

demax.inspections.model.orders.OrderItem = function(dto) {
	var self = this;

	var OrderUtils = demax.inspections.utils.OrderUtils;
	dto = dto || {};

	this.id = dto.id || null;
	this.quantity = ko.observable(dto.quantity || null);
	this.productId = dto.productId || null;
	this.productName = dto.productName || null;
	this.productQuantityOptions = dto.productQuantityOptions || [];
	this.hasValidOptions = (function () {
		var validOptionsCount = self.productQuantityOptions.filter(function (quantityOption) {
			return quantityOption > 0; 
		}).length; 

		return validOptionsCount > 0;
	})();

	this.intervals = ko.observableArray([
		new demax.inspections.model.IntervalParams({
			fromNum: dto.fromNum || null,
			toNum: dto.toNum || null
		})
	]);

	this.hasAllIntervals = ko.pureComputed(function() {
		var intervals = self.intervals();
		return intervals.every(function(interval) {
			return interval.areIntervalsFilled();
		});
	});

	this.intervalsConcat = OrderUtils.concatIntervals(this.intervals);
	
	this.getProductCssClass = function() {
		var cssClass = "";
		switch (self.productId) {
			case 903: {
				cssClass = "text-light-blue";
			} 
				break;
			case 904: {
				cssClass = "text-green";
			} 
				break;
			case 905: {
				cssClass = "text-aqua";
			} 
				break;
			case 906: {
				cssClass = "text-red";
			} 
				break;
			case 806: {
				cssClass = "text-red";
			} 
				break;
			case 907: {
				cssClass = "text-yellow";
			} 
				break;
			case 807: {
				cssClass = "text-yellow";
			} 
				break;
		}
		return cssClass;
	}();
};
