namespace("demax.inspections.model.orders");

demax.inspections.model.orders.OrderItemLight = function(dto) {
	this.fromNum = dto.fromNum !== undefined ? dto.fromNum : null;
	this.toNum = dto.toNum !== undefined ? dto.toNum : null;
	this.quantity = dto.quantity !== undefined ? dto.quantity : null;
};
