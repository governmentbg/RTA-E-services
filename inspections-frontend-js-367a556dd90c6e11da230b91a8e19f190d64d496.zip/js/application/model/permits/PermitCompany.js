namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitCompany = function (dto) {
	var City = demax.inspections.model.City;
	var Country = demax.inspections.model.Country;

	this.hasVatNumberOptions = [{
		code: true,
		text: "Да"
	}, {
		code: false,
		text: "Не"
	}];

	var self = this;

	this.id = dto ? dto.id : undefined;

	this.eik = ko.observable(dto ? dto.eik : undefined)
		.extend({
			eicNumber: true,
			required: true
		});
	this.name = ko.observable(dto ? dto.name : undefined)
		.extend({
			maxLength: 255,
			required: true,
			upperCase: true
		});
	this.hasVatRegistration = ko.observable(dto ? dto.hasVatRegistration : undefined)
		.extend({
			required: true
		});
	this.managerName = ko.observable(dto ? dto.managerName : undefined)
		.extend({
			maxLength: 120,
			required: true
		});
	this.managerEgn = ko.observable(dto ? dto.managerEgn : undefined)
		.extend({
			identityNumber: true,
			required: true
		});

	this.country = dto ? new Country(dto.country) : new Country();

	this.phoneNumber = ko.observable(dto ? dto.phoneNumber : undefined)
		.extend({
			maxLength: 25,
			doubleNumberValidation: true,
			required: true
		});

	this.email = ko.observable(dto ? dto.email : undefined)
		.extend({
			maxLength: 30,
			email: { params: true, message: "Моля, въведете валиден имейл"}
		});

	this.city = ko.observable(dto ? new City(dto.city) : new City())
		.extend({
			required: true
		});
	this.address = ko.observable(dto ? dto.address : undefined)
		.extend({
			maxLength: 255,
			required: true
		});

	this.regionCode = ko.observable(dto ? dto.regionCode : undefined);

	this.hasVatRegistrationText = function () {
		if (self.hasVatRegistration() == true) {
			return "Да";
		} else if (self.hasVatRegistration() == false) {
			return "Не";
		} else {
			return "Неизвестно";
		}
	};

	this.toJson = function () {
		return JSON.stringify({
			eik: self.eik(),
			name: self.name(),
			hasVatRegistration: self.hasVatRegistration(),
			managerName: self.managerName(),
			managerEgn: self.managerEgn(),
			phoneNumber: self.phoneNumber(),
			email: self.email() ? self.email() : null,
			city: self.city(),
			address: self.address()
		});
	};

	this.getValidationGroup = function () {
		return ko.validation.group([
			self.eik,
			self.name,
			self.hasVatRegistration,
			self.managerName,
			self.managerEgn,
			self.phoneNumber,
			self.email,
			self.city,
			self.address

		]);
	};
};