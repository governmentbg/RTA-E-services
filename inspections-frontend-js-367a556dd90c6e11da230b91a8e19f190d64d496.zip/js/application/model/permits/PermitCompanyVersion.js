namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitCompanyVersion = function(dto) {
	var util = demax.inspections.utils.GeneralUtil;
	
	this.versionDate = dto ? util.formatDate(dto.versionDate) : "-";
	this.companyName = dto ? dto.companyName : "-";
	this.hasVatRegistration = dto ? dto.hasVatRegistration : undefined;
	this.phoneNumber = dto ? dto.phoneNumber : "-";
	this.email = dto ? dto.email : "-";
	this.managerName = dto ? dto.managerName : "-";
	this.managerIdentityNumber = dto ? dto.managerIdentityNumber : "-";
	this.municipality = dto ? dto.municipality : "-";
	this.city = dto ? dto.city : "-";
	this.address = dto ? dto.address : "-";

	this.hasVatRegistrationText = util.getCompanyHasVatRegistrationText(this);
};