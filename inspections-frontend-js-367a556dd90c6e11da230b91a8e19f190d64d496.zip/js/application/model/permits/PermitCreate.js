namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitCreate = function() {
	var self = this;
	var OrgUnit = demax.inspections.model.OrgUnit;
	
	this.permitOrgUnit = new OrgUnit();
	this.company = null;

	this.applicationNumber = ko.observable()
		.extend({ maxLength: 20 })
		.extend({ required: true });
	this.applicationDate = ko.observable();
	this.ktpAddress = ko.observable()
		.extend({ maxLength: 255 })
		.extend({ required: true });
	this.contactKtpPhone = ko.observable()
		.extend({ maxLength: 80})
		.extend({ required: true });
	this.contactKtpEmail = ko.observable()
		.extend({ maxLength: 80 })
		.extend({email: { params: true, message: "Моля, въведете валиден имейл"}});
	this.ktpCity = ko.observable(new demax.inspections.model.City());

	this.getValidationGroup = function() {
		return ko.validation.group([
			self.applicationNumber,
			self.ktpAddress,
			self.contactKtpPhone,
			self.contactKtpEmail
		]);
	};

	this.toJson = function() {
		return JSON.stringify({
			applicationNumber: self.applicationNumber(),
			applicationDate: self.applicationDate() ? self.applicationDate().format(demax.inspections.settings.serverDateFormat) : null,
			ktpCityCode: self.ktpCity().code,
			ktpAddress: self.ktpAddress(),
			contactKtpPhone: self.contactKtpPhone(),
			contactKtpEmail: self.contactKtpEmail() ? self.contactKtpEmail() : null,
			companyEik: self.company.eik()
		});
	};
};
