namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitDetails = function(dto) {
	var PermitStatus = demax.inspections.nomenclature.permits.PermitStatus;
	var PermitCompany = demax.inspections.model.permits.PermitCompany;
	var KtpCategory = demax.inspections.nomenclature.permits.KtpCategory;

	this.id;
	this.draftId;
	this.orgUnit = new demax.inspections.model.OrgUnit();
	this.applicationNumber;
	this.applicationDate;
	this.permitNumber;
	this.versionNumber;
	this.status = PermitStatus.getNullStatus();
	this.issuedOn;
	this.validFrom;
	this.validTo;
	this.ktpCategory;
	this.inspectionDate;
	this.inspectionProtocolsNumbers;
	this.closeDate;
	this.closeReason;
	this.statusChange;
	this.lastChangeDate;
	this.listChangeDate;
	this.ktpAddress;
	this.contactKtpPhone;
	this.contactKtpEmail;
	this.ktpCity;
	this.rejection;
	this.sentToIaaaBy;
	this.remarks;

	if (dto) {
		this.id = dto.id;
		this.applicationNumber = dto.applicationNumber;
		this.applicationDate = dto.applicationDate ? moment.fromJacksonDateTimeArray(dto.applicationDate) : undefined;
		this.draftId = dto.draftId;
		this.orgUnit = new demax.inspections.model.OrgUnit(dto.orgUnit);
		this.applicationNumber = dto.applicationNumber;
		this.permitNumber = dto.permitNumber;
		this.versionNumber = dto.versionNumber;
		this.status = dto.statusCode ? PermitStatus.getByCode(dto.statusCode) : PermitStatus.getNullStatus();
		this.issuedOn = dto.issuedOn ? moment.fromJacksonDateTimeArray(dto.issuedOn) : undefined;
		this.validFrom = dto.validFrom ? moment.fromJacksonDateTimeArray(dto.validFrom) : undefined;
		this.validTo = dto.validTo ? moment.fromJacksonDateTimeArray(dto.validTo) : undefined;
		this.ktpCategory = dto.ktpCategory ? 
			dto.ktpCategory === KtpCategory.FOUR_TB.name || dto.ktpCategory === KtpCategory.FOUR_TM.name ?
				KtpCategory.FOUR.name 
				: dto.ktpCategory 
			: undefined;
		this.inspectionDate = dto.inspectionDate ? moment.fromJacksonDateTimeArray(dto.inspectionDate) : undefined;
		this.inspectionProtocolsNumbers = dto.inspectionProtocolsNumbers;
		this.closeDate = dto.closeDate ? moment.fromJacksonDateTimeArray(dto.closeDate) : undefined;
		this.closeReason = dto.closeReason;
		this.statusChange = dto.statusChangeCode ? PermitStatus.getByCode(dto.statusChangeCode) : PermitStatus.getNullStatus();
		this.lastChangeDate = dto.lastChangeDate ? moment.fromJacksonDateTimeArray(dto.lastChangeDate) : undefined;
		this.listChangeDate = dto.listChangeDate ? moment.fromJacksonDateTimeArray(dto.listChangeDate) : undefined;
		this.ktpAddress = dto.ktpAddress;
		this.contactKtpPhone = dto.contactKtpPhone;
		this.contactKtpEmail = dto.contactKtpEmail;
		this.ktpCity = new demax.inspections.model.City(dto.ktpCity);
		this.rejection = dto.rejection ? new demax.inspections.model.permits.PermitRejectionDto(dto.rejection) : null;
		this.sentToIaaaBy = dto.sentToIaaaBy;
		this.remarks = dto.remarks;
	}

	this.company = dto && dto.company ? new PermitCompany(dto.company) : new PermitCompany();

	this.additionalInfo = ko.observable(new demax.inspections.model.permits.PermitDetailsAdditionalInfo(dto.additionalInfo));

	this.documents = ko.observableArray([]);
	this.inspectors = ko.observableArray([]);
	this.permitLines = ko.observableArray([]);
	this.inspections = ko.observableArray((dto && dto.inspections ? dto.inspections : []).map(function(inspection) {
		return new demax.inspections.model.permits.PermitInspectionDto(inspection);
	}));
	this.orders = (dto && dto.orders ? dto.orders.items : []).map(function(order) {
		return new demax.inspections.model.permits.PermitDetailsInspectionOrder(order);
	});
	this.problems = (dto && dto.problems ? dto.problems.items : []).map(function(problem) {
		return new demax.inspections.model.permits.PermitDetailsPermitProblem(problem);
	});
};