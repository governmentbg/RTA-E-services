namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitDetailsAdditionalInfo = function (dto) {

	var self = this;

	this.contactPersonName = ko.observable(dto ? dto.contactPersonName : null)
		.extend({ required: true })
		.extend({ maxLength: 120 });
	this.contactPersonPhone = ko.observable(dto ? dto.contactPersonPhone : null)
		.extend({ required: true })
		.extend({ maxLength: 20 });
	this.contactPersonStationaryPhone = ko.observable(dto ? dto.contactPersonStationaryPhone : null)
		.extend({ maxLength: 20 });
	this.contactPersonEmail = ko.observable(dto ? dto.contactPersonEmail : null)
		.extend({ maxLength: 20 })
		.extend({ email: { params: true, message: "Моля, въведете валиден имейл" } });
	this.gpsN = ko.observable(dto ? dto.gpsN : null)
		.extend({ max: { params: 90, message: "Максималната стойност е 90" } })
		.extend({ min: { params: -90, message: "Минималната стойност е -90" } });
	this.gpsE = ko.observable(dto ? dto.gpsE : null)
		.extend({ max: { params: 180, message: "Максималната стойност е 90" } })
		.extend({ min: { params: -180, message: "Минималната стойност е -90" } });
	this.ktpRealAddress = ko.observable(dto ? dto.ktpRealAddress : null)
		.extend({ required: true })
		.extend({ maxLength: 120 });

	this.ktpPostCode = ko.observable(dto ? dto.ktpPostCode : null)
		.extend({ minLegth: 4, maxLength: 4 });
	
	this.hasExteriorAntenna = ko.observable(dto && dto.hasExteriorAntenna ? dto.hasExteriorAntenna : false);
	this.googleMapsUrl = ko.pureComputed(function () {
		if (self.gpsN == null && self.gpsE == null) {
			return undefined;
		} else {
			return "https://www.google.com/maps/search/?api=1&query=" + self.gpsN() + "," + self.gpsE();
		}
	});

	this.toEditDto = function () {
		var dto = {};
		dto.contactPersonName = this.contactPersonName();

		if (dto.contactPersonName === "") {
			dto.contactPersonName = undefined;
		}

		dto.contactPersonPhone = this.contactPersonPhone();

		if (dto.contactPersonPhone === "") {
			dto.contactPersonPhone = undefined;
		}

		dto.contactPersonEmail = this.contactPersonEmail();

		if (dto.contactPersonEmail === "") {
			dto.contactPersonEmail = undefined;
		}

		dto.contactPersonStationaryPhone = this.contactPersonStationaryPhone();

		if (dto.contactPersonStationaryPhone === "") {
			dto.contactPersonStationaryPhone = undefined;
		}

		dto.ktpRealAddress = this.ktpRealAddress();
		if (dto.ktpRealAddress === "") {
			dto.ktpRealAddress = undefined;
		}

		dto.ktpPostCode = this.ktpPostCode();
		if (dto.ktpPostCode === "") {
			dto.ktpPostCode = undefined;
		}

		dto.gpsN = this.gpsN();
		dto.gpsE = this.gpsE();
		dto.hasExteriorAntenna = this.hasExteriorAntenna();
		return dto;
	};
};

