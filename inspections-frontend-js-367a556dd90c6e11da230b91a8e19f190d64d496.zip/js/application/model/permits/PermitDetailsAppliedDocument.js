namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitDetailsAppliedDocument = function (dto) {
	var PermitDocumentStatus = demax.inspections.nomenclature.permits.PermitDocumentStatus;

	this.id = dto ? dto.id : "-";
	this.type = dto && dto.type ? dto.type : "-";
	this.status = dto ? PermitDocumentStatus.getByCode(dto.status) : "-";
	this.validTo = dto && dto.validTo ? moment.fromJacksonDateTimeArray(dto.validTo) : undefined;
	this.issuedOn = dto && dto.issuedOn ? moment.fromJacksonDateTimeArray(dto.issuedOn) : undefined;
	this.isApproved = dto ? dto.isApproved : false;
};