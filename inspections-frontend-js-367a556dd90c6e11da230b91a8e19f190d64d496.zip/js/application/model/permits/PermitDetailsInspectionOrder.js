namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitDetailsInspectionOrder = function (dto) {
	var util = demax.inspections.utils.GeneralUtil;
	var InspectionOrderStatus = demax.inspections.nomenclature.orders.InspectionOrderStatus;

	this.id = dto ? dto.id : "-";
	this.orderDatetime = dto && dto.orderDatetime ? util.formatDate(dto.orderDatetime) : "-";
	this.activationDatetime = dto && dto.activationDatetime ? util.formatDate(dto.activationDatetime) : "-";
	this.invoiceNumber = dto && dto.invoiceNumber ? dto.invoiceNumber : "-";
	this.invoiceDate = dto && dto.invoiceDate ? util.formatDate(dto.invoiceDate) : "-";
	this.status = dto && dto.status ? InspectionOrderStatus.getByCode(dto.status) : InspectionOrderStatus.getNullStatus();
};