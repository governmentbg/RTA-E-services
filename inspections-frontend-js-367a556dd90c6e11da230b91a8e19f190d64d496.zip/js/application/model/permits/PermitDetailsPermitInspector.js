namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitDetailsPermitInspector = function (dto) {
	var util = demax.inspections.utils.GeneralUtil;
	var PermitInspectorStatus = demax.inspections.nomenclature.permits.PermitInspectorStatus;
    
	this.id = dto ? dto.id : "-";
	this.fullName = dto && dto.fullName ? dto.fullName : "-";
	this.orderNumber = dto && dto.orderNumber ? dto.orderNumber : "-";
	this.identityNumber = dto && dto.identityNumber ? dto.identityNumber : "-";
	this.isChairmanData = dto && dto.isChairman !== undefined
		&& dto.isChairman !== null ? util.getPermitInspectorIsChairmanData(dto.isChairman) : util.getNullData();
	this.status = dto && dto.statusCode ? PermitInspectorStatus.getByCode(dto.statusCode) : PermitInspectorStatus.getNullStatus();
	this.isNewInspector = dto ? dto.newInspector : false;

};