namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitDetailsPermitLine = function (dto) {
	var util = demax.inspections.utils.GeneralUtil;

	this.id = dto ? dto.id : "-";
	this.number = dto && dto.number ? dto.number : "-";
	this.addedOn = dto && dto.addedOn ? util.formatDate(dto.addedOn) : "-";
	this.status = dto && dto.isValid !== undefined && dto.isValid !== null ? util.getPermitLineStatusData(dto.isValid) : util.getNullData();
};