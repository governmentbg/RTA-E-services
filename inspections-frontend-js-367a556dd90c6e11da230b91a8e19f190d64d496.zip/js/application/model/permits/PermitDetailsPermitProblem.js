namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitDetailsPermitProblem = function (dto) {
	var util = demax.inspections.utils.GeneralUtil;
	var PermitProblemStatus = demax.inspections.nomenclature.permits.PermitProblemStatus;

	this.id = dto ? dto.id : "-";
	this.createdOn = dto && dto.createdOn ? util.formatDate(dto.createdOn) : "-";
	this.description = dto && dto.description ? dto.description : "-";
	this.status = dto && dto.statusId ? PermitProblemStatus.getById(dto.statusId) : PermitProblemStatus.getNullStatus();
};