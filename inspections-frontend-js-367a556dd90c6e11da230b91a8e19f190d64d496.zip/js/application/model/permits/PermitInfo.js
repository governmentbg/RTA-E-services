namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitInfo = function(dto) {
	var self = this;

	this.applicationNumber = ko.observable()
		.extend({ required: true })
		.extend({ maxLength: 20 });
	this.applicationDate = ko.observable();
	this.ktpAddress = ko.observable()
		.extend({ maxLength: 255 })
		.extend({ required: true });
	this.contactKtpPhone = ko.observable()
		.extend({ maxLength: 25 })
		.extend({ doubleNumberValidation: true })
		.extend({ required: true });
	this.contactKtpEmail = ko.observable()
		.extend({ maxLength: 30 })
		.extend({email: { params: true, message: "Моля, въведете валиден имейл"}});
	this.ktpCity = ko.observable(new demax.inspections.model.City());

	if (dto) {
		this.applicationNumber(dto.applicationNumber);
		this.applicationDate(dto.applicationDate ? moment(dto.applicationDate) : undefined);
		this.ktpCity(new demax.inspections.model.City(dto.ktpCity));
		this.ktpAddress(dto.ktpAddress);
		this.contactKtpPhone(dto.contactKtpPhone);
		this.contactKtpEmail(dto.contactKtpEmail);
	}

	this.getValidationGroupForDraftPermit = function() {
		return ko.validation.group([
			self.ktpAddress
		]);
	};

	this.getValidationGroupForCreatedPermit = function() {
		return ko.validation.group([
			self.applicationNumber,
			self.ktpAddress
		]);
	};

	this.toParams = function() {
		return {
			applicationNumber: self.applicationNumber(),
			applicationDate: self.applicationDate() ? self.applicationDate().format(demax.inspections.settings.serverDateFormat) : null,
			ktpCityCode: self.ktpCity().code,
			ktpAddress: self.ktpAddress(),
			contactKtpEmail: self.contactKtpEmail() ? self.contactKtpEmail() : null,
			contactKtpPhone: self.contactKtpPhone()
		};
	};
};
