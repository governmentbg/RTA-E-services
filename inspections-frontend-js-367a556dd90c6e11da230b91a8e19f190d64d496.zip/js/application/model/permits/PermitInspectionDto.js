namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitInspectionDto = function (dto) {
	
	this.id = dto && dto.id ? dto.id : null;
	this.inspectionDate = dto.inspectionDate ? moment.fromJacksonDateTimeArray(dto.inspectionDate) : null;
	this.inspectionProtocolNumber = dto && dto.inspectionProtocolNumber ? dto.inspectionProtocolNumber : null;
	this.inspectionPaymentNumber = dto && dto.inspectionPaymentNumber ? dto.inspectionPaymentNumber : null;
	this.inspectionProtocolDate = dto.inspectionProtocolDate ? moment.fromJacksonDateTimeArray(dto.inspectionProtocolDate) : null;
	this.isFeePaid = dto && dto.isFeePaid !== null && dto.isFeePaid !== undefined ? dto.isFeePaid : null;
	this.conclusion = dto && dto.conclusion !== null && dto.conclusion !== undefined ? dto.conclusion : null;
};
