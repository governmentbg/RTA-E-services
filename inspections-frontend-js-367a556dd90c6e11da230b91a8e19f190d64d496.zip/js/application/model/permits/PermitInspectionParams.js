namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitInspectionParams = function () {
	var self = this;

	this.inspectionDate = ko.observable().extend({
		required: true
	});
	this.inspectionProtocolNumber = ko.observable().extend({
		required: true
	});
	this.inspectionProtocolDate = ko.observable().extend({
		required: true
	});
	this.inspectionPaymentNumber = ko.observable().extend({
		required: true
	});
	this.conclusion = ko.observable(false);
	this.file = ko.observable(null).extend({
		required: true
	});

	this.inspectionDateError = ko.observable(false);
	this.inspectionProtocolDateError = ko.observable(false);

	this.inspectionDate.subscribe(function () {
		self.inspectionDateError(false);
	});
	this.inspectionProtocolDate.subscribe(function () {
		self.inspectionProtocolDateError(false);
	});

	this.getValidationGroup = function() {
		return ko.validation.group([
			self.inspectionProtocolNumber,
			self.inspectionPaymentNumber,
			self.file
		]);
	};

	this.hasError = function () {
		return self.inspectionDateError() || self.inspectionProtocolDateError();
	};

	this.toJson = function() {
		return JSON.stringify({
			inspectionDate: self.inspectionDate() ? self.inspectionDate().format(demax.inspections.settings.serverDateFormat) : null,
			inspectionProtocolNumber: self.inspectionProtocolNumber(),
			inspectionPaymentNumber: self.inspectionPaymentNumber(),
			inspectionProtocolDate: self.inspectionProtocolDate() ? self.inspectionProtocolDate().format(demax.inspections.settings.serverDateFormat) : null,
			conclusion: self.conclusion(),
			file: self.file()
		});
	};
};