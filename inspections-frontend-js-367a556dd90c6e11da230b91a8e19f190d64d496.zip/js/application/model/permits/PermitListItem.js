namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitListItem = function(dto) {
	var self = this;

	var PermitStatus = demax.inspections.nomenclature.permits.PermitStatus;

	this.id = dto ? dto.id : null;
	this.permitNum = dto && dto.permitNum ? dto.permitNum : "-";
	this.applicationNum = dto ? dto.applicationNum : null;
	this.applicationDate = dto ? moment.fromJacksonDateTimeArray(dto.applicationDate) : null;
	this.orgUnit = dto ? dto.orgUnit : null;
	this.companyName = dto ? dto.companyName : null;
	this.identityNum = dto ? dto.identityNum : null;
	this.validTo = dto ? moment.fromJacksonDateTimeArray(dto.validTo) : null;
	this.status = dto ? PermitStatus.getByCode(dto.status) : null;
	this.isListPrinted = dto ? dto.isListPrinted : null;

	this.applicationDateFormatted = (function() {
		if (self.applicationDate) {
			return self.applicationDate.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();

	this.validToFormatted = (function() {
		if (self.validTo) {
			return self.validTo.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();
};