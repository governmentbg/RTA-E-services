namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitOrgUnitCode = function (dto) {
	this.id = dto ? dto.id : null;
	this.number = dto ? dto.number : null;
	this.orgUnit = dto ? dto.orgUnit : null;
};