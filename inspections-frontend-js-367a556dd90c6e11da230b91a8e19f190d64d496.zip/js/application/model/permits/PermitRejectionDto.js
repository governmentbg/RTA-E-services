namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitRejectionDto = function (dto) {
	this.reason = dto && dto.reason ? dto.reason : null;
	this.date = dto && dto.date ? dto.date : null;
	this.filename = dto && dto.filename ? dto.filename : null;
};