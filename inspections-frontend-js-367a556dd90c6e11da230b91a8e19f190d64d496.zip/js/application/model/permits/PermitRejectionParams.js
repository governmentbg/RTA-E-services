namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitRejectionParams = function () {
	var self = this;
	
	this.submitFunction = null;
	this.type = ko.observable();

	// Params
	this.reason = ko.observable();
	this.reason.extend({
		maxLength: 255,
		required: true
	});
	this.sendMessage = ko.observable(false);
	this.file;
	this.filename;

	// CONSTANTS
	this.REJECT_PERMIT = "REJECT_PERMIT";
	this.RETURN_PERMIT = "RETURN_PERMIT";

	this.toRequestBody = function () {
		var dto = {};

		if (self.reason()) {
			dto["reason"] = self.reason();
		}
		if (self.file) {
			dto["file"] = self.file;
		}
		if (self.filename) {
			dto["filename"] = self.filename;
		}
		dto["sendMessage"] = self.sendMessage();

		return JSON.stringify(dto);
	};

	this.setSubmitFunction = function (func) {
		this.submitFunction = func;
	};

	this.submit = function () {
		this.submitFunction();
	};

	self.isForReject = ko.pureComputed(function () {
		return self.type() === self.REJECT_PERMIT;
	});

	self.isForReturn = ko.pureComputed(function () {
		return self.type() === self.RETURN_PERMIT;
	});

};