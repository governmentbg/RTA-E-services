namespace("demax.inspections.model.permits");

demax.inspections.model.permits.PermitStatusChange = function() {
	var self = this;
	var PermitStatus = demax.inspections.nomenclature.permits.PermitStatus;

	this.status = ko.observable();
	this.closeDate = ko.observable();
	this.revokeDate = ko.observable();
	this.revokeReason = ko.observable()
		.extend({ maxLength: 60 })
		.extend({ 
			required: { 
				onlyIf: function () {
					return self.status() === PermitStatus.REVOKED;
				}  
			}
		});
	this.closeApplicationNumber = ko.observable()
		.extend({ maxLength: 60 })
		.extend({ 
			required: { 
				onlyIf: function () {
					return self.status() === PermitStatus.CLOSED;
				}  
			}
		});

	this.setProperties = function(permitDto) {
		if (permitDto.status === PermitStatus.CREATED || permitDto.status === PermitStatus.DRAFT) {
			if (permitDto.statusChange.code) {
				setStatusChangeProperties(permitDto, permitDto.statusChange);
			} else {
				self.status(undefined);
			}
		} else {
			setStatusChangeProperties(permitDto, permitDto.status);
		}
	};

	function setStatusChangeProperties(permitDto, permitStatus) {
		self.status(permitStatus);

		if (permitStatus === PermitStatus.REVOKED) {
			self.revokeReason(permitDto.closeReason);
			self.revokeDate(permitDto.closeDate ? moment(permitDto.closeDate) : undefined);
			self.closeApplicationNumber(undefined);
			self.closeApplicationNumber.isModified(false);
			self.closeDate(undefined);
		} else if (permitStatus === PermitStatus.CLOSED) {
			self.closeApplicationNumber(permitDto.closeReason);
			self.closeDate(permitDto.closeDate ? moment(permitDto.closeDate) : undefined);
			self.revokeReason(undefined);
			self.revokeReason.isModified(false);
			self.revokeDate(undefined);
		}
	}

	this.getValidationGroup = function() {
		return ko.validation.group([
			self.closeApplicationNumber,
			self.closeReason,
			self.revokeReason
		]);
	};

	this.toJson = function() {
		return JSON.stringify({
			closeDate: self.status() ? self.status() === PermitStatus.REVOKED ? self.revokeDate()
				.format(demax.inspections.settings.serverDateFormat) 
				: self.status() === PermitStatus.CLOSED ? self.closeDate().format(demax.inspections.settings.serverDateFormat) : null : null,
			closeReason: self.status() ? self.status() === PermitStatus.REVOKED ? self.revokeReason() 
				: self.status() === PermitStatus.CLOSED ? self.closeApplicationNumber() : null : null,
			statusChangeCode: self.status() ? self.status().code : null
		});
	};
};