namespace("demax.inspections.model.permits.documents");

demax.inspections.model.permits.documents.AppliedDocument = function (dto, documentTypes) {
	var self = this;
	var DocumentTypeCodes = demax.inspections.nomenclature.permits.DocumentTypeCodes;

	var PermitDocumentStatus = demax.inspections.nomenclature.permits.PermitDocumentStatus;

	this.docType = ko.observable();

	if (dto && documentTypes) {
		for (var i = 0; i < documentTypes.length; i++) {
			if (documentTypes[i].code === dto.docTypeId) {
				self.docType = ko.observable(documentTypes[i]);
			}
		}
	}
	this.docType.extend({ required: true });

	this.docTypeName = dto ? ko.observable(dto.docTypeName) : ko.observable();
	this.docNumber = dto ? ko.observable(dto.docNumber) : ko.observable();
	this.docNumber.extend({
		maxLength: 20,
		required: {
			onlyIf: function () {
				return self.docType() && self.docType().code !== DocumentTypeCodes.INSPECTION_STATION_PLAN_CODE
					&& self.docType().code !== DocumentTypeCodes.TECHNICAL_SPECIALISTS_LIST_CODE
					&& self.docType().code !== DocumentTypeCodes.MACHINES_LIST_CODE
					&& self.docType().code !== DocumentTypeCodes.TECHNOLOGICAL_CARD_CODE;
			}
		}
	});

	this.issuer = dto ? ko.observable(dto.issuer) : ko.observable();
	this.issuer.extend({
		maxLength: 60,
		required: {
			onlyIf: function () {
				return self.docType() && self.docType().code !== DocumentTypeCodes.INSPECTION_STATION_PLAN_CODE
					&& self.docType().code !== DocumentTypeCodes.TECHNICAL_SPECIALISTS_LIST_CODE
					&& self.docType().code !== DocumentTypeCodes.MACHINES_LIST_CODE
					&& self.docType().code !== DocumentTypeCodes.ACCORDANCE_PROTOCOL_CODE
					&& self.docType().code !== DocumentTypeCodes.TECHNOLOGICAL_CARD_CODE;
			}
		}
	});

	this.issuedOn = dto && dto.issuedOn ? ko.observable(moment.fromJacksonDateTimeArray(dto.issuedOn)) : ko.observable();
	this.issuedOn.extend({
		required: {
			onlyIf: function () {
				return self.docType() && self.docType().hasIssueDate;
			}
		}
	});

	this.validFrom = dto && dto.validFrom ? ko.observable(moment.fromJacksonDateTimeArray(dto.validFrom)) : ko.observable();
	this.validFrom.extend({
		required: {
			onlyIf: function () {
				return self.docType() && self.docType().hasValidFromDate;
			}
		},
		dateIsAfterOrEqual: {
			params: self.issuedOn,
			message: "Началната дата на валидност трябва да е след датата на издаване.",
			onlyIf: function () {
				return self.docType() && self.docType().hasValidFromDate;
			}
		}
	});

	this.shouldShowBrandAndModel = ko.pureComputed(function () {
		return self.docType() && self.docType().hasBrandModel;
	});

	this.updateValidityByValidFrom = function () {
		if (self.validFrom() && self.docType() && self.docType().validityLength) {
			self.validTo(moment(self.validFrom()).add(self.docType().validityLength, "M"));
		}
	};

	this.updateValidityByIssuedOn = function () {
		if (self.issuedOn() && self.docType() && self.docType().validityLength) {
			if (!self.validFrom() || (self.validFrom() && !self.docType().hasValidFromDate)) {
				self.validFrom(self.issuedOn());
				self.updateValidityByValidFrom();
			}
		}
	};

	this.validTo = dto && dto.validTo ? ko.observable(moment.fromJacksonDateTimeArray(dto.validTo)) : ko.observable();
	this.validTo.extend({
		required: {
			onlyIf: function () {
				return self.docType() && self.docType().hasValidToDate;
			}
		},
		dateIsAfter: {
			params: self.validFrom,
			message: "Крайната дата на валидност трябва да е след началната дата на валидност.",
			onlyIf: function () {
				return self.docType() && self.docType().hasValidToDate;
			}
		}
	});

	this.remarks = dto ? ko.observable(dto.remarks) : ko.observable();
	this.remarks.extend({ maxLength: 250 });

	this.status = dto ? ko.observable(PermitDocumentStatus.getByCode(dto.status)) : ko.observable("-");
	this.status.extend({
		required: true
	});

	this.hasDocument = dto ? ko.observable(dto.hasDocument) : ko.observable();
	this.isApproved = dto ? ko.observable(dto.isApproved) : ko.observable();

	this.brand = dto ? ko.observable(dto.brand) : ko.observable();
	this.brand.extend({
		minLength: 1,
		maxLength: 32,
		required: {
			onlyIf: self.shouldShowBrandAndModel
		}
	});

	this.model = dto ? ko.observable(dto.model) : ko.observable();
	this.model.extend({
		minLength: 1,
		maxLength: 32,
		required: {
			onlyIf: self.shouldShowBrandAndModel
		}
	});

	this.deviceType = dto ? ko.observable(dto.deviceType) : ko.observable();
	this.deviceType.extend({
		minLength: 1,
		maxLength: 32,
		required: {
			onlyIf: self.shouldShowBrandAndModel
		}
	});

	this.serialNumber = dto ? ko.observable(dto.serialNumber) : ko.observable();
	this.serialNumber.extend({
		minLength: 1,
		maxLength: 50,
		required: {
			onlyIf: self.shouldShowBrandAndModel
		}
	});

	this.toRequestBody = function (file) {
		var dto = {};

		if (self.docType()) {
			dto["docTypeId"] = self.docType().code;
		}
		if (self.docNumber()) {
			dto["docNumber"] = self.docNumber();
		}
		if (self.issuer()) {
			dto["issuer"] = self.issuer();
		}
		if (self.issuedOn()) {
			dto["issuedOn"] = self.issuedOn().format(demax.inspections.settings.serverDateFormat);
		}
		if (self.validFrom()) {
			dto["validFrom"] = self.validFrom().format(demax.inspections.settings.serverDateFormat);
		}
		if (self.remarks()) {
			dto["remarks"] = self.remarks();
		}
		if (self.validTo()) {
			dto["validTo"] = self.validTo().format(demax.inspections.settings.serverDateFormat);
		}
		if (self.brand()) {
			dto["brand"] = self.brand();
		}
		if (self.model()) {
			dto["model"] = self.model();
		}
		if (self.model()) {
			dto["deviceType"] = self.deviceType();
		}
		if (self.model()) {
			dto["serialNumber"] = self.serialNumber();
		}
		if (file) {
			dto["file"] = file;
		}

		return JSON.stringify(dto);
	};
};