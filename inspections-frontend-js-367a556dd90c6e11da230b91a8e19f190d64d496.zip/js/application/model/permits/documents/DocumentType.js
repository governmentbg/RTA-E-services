namespace("demax.inspections.model.permits.documents");

demax.inspections.model.permits.documents.DocumentType = function (dto) {

	this.code = dto ? dto.code : null;
	this.description = dto ? dto.description : null;
	this.hasValidFromDate = dto ? dto.hasValidFromDate : null;
	this.hasValidToDate = dto ? dto.hasValidToDate : null;
	this.hasIssueDate = dto ? dto.hasIssueDate : null;
	this.hasBrandModel = dto ? dto.hasBrandModel : null;
	this.validityLength = dto ? dto.validityLength : null;
};