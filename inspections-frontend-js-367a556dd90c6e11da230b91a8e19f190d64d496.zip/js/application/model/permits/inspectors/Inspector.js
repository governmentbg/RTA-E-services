namespace("demax.inspections.model.permits.inspectors");

demax.inspections.model.permits.inspectors.Inspector = function() {
	var self = this;
	var InspectorStatus = demax.inspections.nomenclature.permits.PermitInspectorStatus;

	this.subjectId = ko.observable().extend({
		required: true
	});
	this.firstName = ko.observable().extend({
		required: true,
		isFirstOrFamilyNameCyrillicUpperCaseWithDashesSpacesOrApotrophes: true,
		maxLength: 80
	});
	this.surname = ko.observable().extend({
		isSurnameNullOrCyrillicUpperCaseWithDashesSpacesOrApotrophes: true,
		maxLength: 80
	});
	this.familyName = ko.observable().extend({
		required: true,
		isFirstOrFamilyNameCyrillicUpperCaseWithDashesSpacesOrApotrophes: true,
		maxLength: 80
	});
	this.subjectVersionId = ko.observable();
	this.educationLevel = ko.observable().extend({
		required: true
	});
	this.identityNumber = ko.observable().extend({
		identityNumber: true
	});
	this.address = ko.observable().extend({
		required: true
	});
	this.country = ko.observable().extend({
		required: true
	});
	this.region = ko.observable().extend({
		required: true
	});
	this.city = ko.observable().extend({
		required: true
	});
	this.birthDate = ko.observable().extend({
		required: true,
		isAdult: true,
		isBirthDateLegitIfPersonHasEgn: {
			country: self.country,
			egn: self.identityNumber
		}
	});
	this.numberInList = ko.observable();
	this.isIncluded = ko.observable().extend({
		required: true
	});
	this.isChairman = ko.observable().extend({
		required: true
	});
	this.speciality = ko.observable().extend({
		required: true
	});
	this.remarks = ko.observable().extend({
		maxLength: 250
	});
	this.includedOn = ko.observable();
	this.excludedOn = ko.observable();
	this.lastModifiedOn = ko.observable();

	this.includedOnFormatted = ko.observable();
	this.excludedOnFormatted = ko.observable();
	this.lastModifiedOnFormatted = ko.observable();

	this.isDeprivedOfRights = ko.observable();
	this.deprivedOn = ko.observable();
	this.depriveReason = ko.observable();

	this.deprivedOnFormatted = ko.observable();
	this.chairmanDesignationDateFormated = ko.observable();
	this.categories = ko.observable();
	this.inspectionTypes = ko.observable();

	this.certificationIds = [];

	this.toRequestBody = function() {
		var dto = {};
		dto.identityNumber = self.identityNumber();
		dto.subjectId = self.subjectId();
		dto.isIncluded = self.isIncluded();
		dto.isChairman = self.isChairman();
		dto.speciality = self.speciality();
		dto.numberInList = self.numberInList();
		dto.remarks = self.remarks();
		dto.birthDate = self.birthDate().format(demax.inspections.settings.serverDateFormat);
		dto.firstName = self.firstName();
		dto.surname = self.surname();
		dto.familyName = self.familyName();
		dto.countryCode = self.country().code;
		dto.regionCode = self.region().code;
		dto.cityCode = self.city().code;
		dto.address = self.address();
		dto.educationLevelCode = self.educationLevel().code;
		dto.certificationIds = self.certificationIds;
		return JSON.stringify(dto);
	};

	this.toRequestBodyForUpdate = function() {
		var dto = {};
		dto.isIncluded = self.isIncluded();
		dto.isChairman = self.isChairman();
		dto.speciality = self.speciality();
		dto.remarks = self.remarks();
		dto.birthDate = self.birthDate().format(demax.inspections.settings.serverDateFormat);
		dto.firstName = self.firstName();
		dto.surname = self.surname();
		dto.familyName = self.familyName();
		dto.countryCode = self.country().code;
		dto.regionCode = self.region().code;
		dto.cityCode = self.city().code;
		dto.address = self.address();
		dto.educationLevelCode = self.educationLevel().code;
		return JSON.stringify(dto);
	};

	this.setUpInspector = function(dto) {
		self.identityNumber(dto.subjectWithEducation.identityNumber);
		self.subjectId(dto.subjectWithEducation.id);
		self.firstName(dto.subjectWithEducation.firstName);
		self.surname(dto.subjectWithEducation.surname);
		self.familyName(dto.subjectWithEducation.familyName);
		self.subjectVersionId(dto.subjectWithEducation.subjectVersionId);
		self.birthDate(moment.fromJacksonDateTimeArray(dto.subjectWithEducation.birthDate));
		self.country(new demax.inspections.model.Country(dto.subjectWithEducation.country));
		self.address(dto.subjectWithEducation.address);
		self.region(new demax.inspections.model.Region(dto.subjectWithEducation.region));
		self.city(new demax.inspections.model.City(dto.subjectWithEducation.city));
		self.educationLevel(new demax.inspections.model.EducationLevel(dto.subjectWithEducation.educationLevel));
		self.numberInList(dto.info.orderNumber);
		self.isIncluded(dto.statusCode === InspectorStatus.INCLUDED.code ? true : false);
		self.isDeprivedOfRights(dto.statusCode === InspectorStatus.DEPRIVED_OF_RIGHTS.code ? true : false);

		if (self.isDeprivedOfRights()) {
			self.deprivedOn(moment.fromJacksonDateTimeArray(dto.info.deprivedOn));
			self.depriveReason(dto.info.depriveReason);
			self.deprivedOnFormatted(self.deprivedOn().format(demax.inspections.settings.momentDateFormat));
		}

		self.isChairman(dto.info.isChairman);
		self.speciality(dto.info.specialityCode);
		self.remarks(dto.info.remarks);
		self.includedOn(moment.fromJacksonDateTimeArray(dto.includedOn));
		self.excludedOn(moment.fromJacksonDateTimeArray(dto.excludedOn));
		self.lastModifiedOn(moment.fromJacksonDateTimeArray(dto.lastModifiedOn));
		self.includedOnFormatted(self.includedOn() ? self.includedOn().format(demax.inspections.settings.momentDateFormat) : "-");
		self.excludedOnFormatted(self.excludedOn() ? self.excludedOn().format(demax.inspections.settings.momentDateFormat) : "-");
		self.lastModifiedOnFormatted(self.lastModifiedOn() ? self.lastModifiedOn().format(demax.inspections.settings.momentDateFormat) : "-");
		self.chairmanDesignationDateFormated(dto.info.chairmanDesignationDate ? 
			moment.fromJacksonDateTimeArray(dto.info.chairmanDesignationDate).format(demax.inspections.settings.momentDateFormat)
			: undefined);
		self.categories(dto.categories ? dto.categories : "-");
		self.inspectionTypes(dto.inspectionTypes ? dto.inspectionTypes : "-");
	};

};