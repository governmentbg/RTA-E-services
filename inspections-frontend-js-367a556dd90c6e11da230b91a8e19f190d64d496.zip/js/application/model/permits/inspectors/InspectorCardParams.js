namespace("demax.inspections.model.permits.inspectors");

demax.inspections.model.permits.inspectors.InspectorCardParams = function() {
	var self = this;
	
	this.id = undefined;
	
	this.cardNumber = ko.observable();
	this.cardNumber.extend({ required: true });

	this.serialNumber = ko.observable();
	this.serialNumber.extend({ required: true, maxLength: 19 });

	this.commonName = ko.observable();
	this.commonName.extend({ required: true }).extend({ pattern: {
		message: "Полето трябва да е на латиница с главни букви",
		params: "^[A-Z ]+$"
	}});

	this.issuedOn = ko.observable();
	this.isActive = ko.observable();

	this.remarks = ko.observable();
	this.remarks.extend({
		required: {
			onlyIf: function () {
				return !self.isActive();
			}
		}
	});

	this.subjectId = undefined;
	this.fullName = ko.observable();
	this.education = ko.observable();
	this.identityNumber = ko.observable();

	this.toRequestBody = function() {
		var dto = {};
		dto.cardNumber = self.cardNumber();
		dto.serialNumber = self.serialNumber();
		dto.commonName = self.commonName();
		dto.remarks = self.remarks();
		return JSON.stringify(dto);
	};

	this.toRequestBodyForUpdate = function () {
		var dto = {};
		dto.cardNumber = self.cardNumber();
		dto.serialNumber = self.serialNumber();
		dto.commonName = self.commonName();
		dto.remarks = self.remarks();
		dto.isActive = self.isActive();
		return JSON.stringify(dto);
	};

	this.setUpCard = function(dto) {
		this.id = dto.id;
		this.subjectId = dto.subjectWithEducation.id;
		this.fullName(dto.subjectWithEducation.fullName);
		this.identityNumber(dto.subjectWithEducation.identityNumber);
		this.education(dto.subjectWithEducation.education);
		this.cardNumber(dto.cardNumber);
		this.serialNumber(dto.serialNumber);
		this.commonName(dto.commonName);
		this.issuedOn(dto.issuedOn);
		this.remarks(dto.remarks);
		this.isActive(dto.isActive);
	};

	this.setUpEducation = function(dto) {
		this.id = dto.id;
		this.fullName(dto.fullName);
		this.identityNumber(dto.identityNumber);
		this.education(dto.education);
	};

};