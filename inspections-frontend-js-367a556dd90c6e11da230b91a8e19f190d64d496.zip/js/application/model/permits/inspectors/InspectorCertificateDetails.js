namespace("demax.inspections.model.permits.inspectors");

demax.inspections.model.permits.inspectors.InspectorCertificateDetails = function (dto) {
	var util = demax.inspections.utils.GeneralUtil;
	this.name = dto.name;
	this.identityNumber = dto.identityNumber;
	this.education = dto.education ? dto.education : "-";
	this.docNumber = dto.docNumber ? dto.docNumber : "-";
	this.certificateType = dto.certificateType;

	this.issuedOn = dto.issuedOn ? util.formatDate(dto.issuedOn) : "-";
	this.validTo = dto.validTo ? util.formatDate(dto.validTo) : "-";
	this.issuer = dto.issuer === null || dto.issuer === "НЕНАЛИЧЕН" ? "-" : dto.issuer;
	this.status = dto.status;
	this.categories = dto.categories === null ? "-" : dto.categories;
	this.inspectionTypes = dto.inspectionTypes === null ? "-" : dto.inspectionTypes;
	this.validityText = dto.validityText ? dto.validityText : "-";
};