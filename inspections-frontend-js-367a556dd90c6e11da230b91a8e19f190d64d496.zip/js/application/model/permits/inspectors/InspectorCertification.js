namespace("demax.inspections.model.permits.inspectors");

demax.inspections.model.permits.inspectors.InspectorCertification = function (dto) {
	var util = demax.inspections.utils.GeneralUtil;
	this.id = dto.id ? dto.id : undefined;
	this.docNumber = dto.docNumber ? dto.docNumber : "-";
	this.docType = dto.docType ? dto.docType : undefined;
	
	if (dto.issuedOn) {
		this.issuedOn = util.formatDate(dto.issuedOn);
	} else {
		this.issuedOn = "-";
	}
	if (dto.reissuedOn) {
		this.reissuedOn = util.formatDate(dto.reissuedOn);
	} else {
		this.reissuedOn = "-";
	}
	this.status = dto.status ? dto.status : undefined;
	this.categories = dto.categories === null ? "-" : dto.categories;
	this.inspectionTypes = dto.inspectionTypes === null ? "-" : dto.inspectionTypes;
	this.canEdit = dto.canEdit ? true : false;

	this.isChecked = ko.observable(false);
};