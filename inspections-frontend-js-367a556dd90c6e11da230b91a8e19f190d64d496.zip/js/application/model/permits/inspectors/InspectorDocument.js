namespace("demax.inspections.model.permits.inspectors");

demax.inspections.model.permits.inspectors.InspectorDocument = function(dto) {
	var util = demax.inspections.utils.GeneralUtil;

	var PermitDocumentStatus = demax.inspections.nomenclature.permits.PermitDocumentStatus;

	this.id = dto.id;
	this.documentNumber = dto.documentNumber;
	this.documentType = dto.documentType;
	this.issuer = dto.issuer;
	this.issuedOn = dto.issuedOn ? util.formatDate(dto.issuedOn) : "-";
	this.status = dto ? PermitDocumentStatus.getByCode(dto.status) : "-";
	this.validTo = dto.validTo ? util.formatDate(dto.validTo) : "-";
	this.remarks = dto.remarks;
	this.isApproved = dto.isApproved;
};