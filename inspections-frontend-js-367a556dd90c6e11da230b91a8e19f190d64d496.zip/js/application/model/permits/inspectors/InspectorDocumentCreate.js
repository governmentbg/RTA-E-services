namespace("demax.inspections.model.permits.inspectors");

demax.inspections.model.permits.inspectors.InspectorDocumentCreate = function() {
	var self = this;
	var PermitDocumentStatus = demax.inspections.nomenclature.permits.PermitDocumentStatus;

	this.hasDocument = ko.observable(false);
	this.documentNumber = ko.observable().extend({
		required: true,
		maxLength: 20
	});
	this.documentType = ko.observable().extend({ 
		required: true 
	});
	this.issuer = ko.observable().extend({ 
		required: true 
	});
	this.remarks = ko.observable().extend({
		maxLength : 250
	});
	this.issuedOn = ko.observable().extend({ 
		required: {
			onlyIf: function () {
				return self.documentType() && self.documentType().hasIssueDate;
			}
		}
	});
	this.validTo = ko.observable().extend({
		required: {
			onlyIf: function () {
				return self.documentType() && self.documentType().hasValidToDate;
			}
		},
		dateIsAfter: {
			params: self.issuedOn, 
			message: "Крайната дата на валидност трябва да е след от датата на издаване.", 
			onlyIf: function () {
				return self.documentType() && self.documentType().hasValidToDate;
			}
		}
	});

	this.image = ko.observable().extend({
		required: {
			message: "Моля, качете сканирано копие на документа"
		}
	});

	this.status = ko.observable().extend({
		required: true
	});

	this.updateValidityIfNeeded = function () {
		if (self.documentType() && self.documentType().validityLength && self.issuedOn()) {
			self.validTo(moment(self.issuedOn()).add(self.documentType().validityLength, "M"));
		}
	};

	this.isApproved = ko.observable();

	this.toDto = function() {
		var dto = {};
		dto.documentNumber = self.documentNumber();
		dto.typeCode = self.documentType().code;
		dto.issuer = self.issuer();
		dto.remarks = self.remarks();
		dto.status = self.status;
		if (self.issuedOn()) {
			dto.issuedOn = self.issuedOn().format(demax.inspections.settings.serverDateFormat);
		}
		if (self.validTo()) {
			dto.validTo = self.validTo().format(demax.inspections.settings.serverDateFormat);
		}
		dto.image = self.image();
		return JSON.stringify(dto);
	};

	this.setUpInspectorDocument = function(dto, documentTypes) {
		self.id = dto.id;
		self.documentNumber(dto.documentNumber);
		self.issuer(dto.issuer);
		if (dto.issuedOn) {
			self.issuedOn(moment.fromJacksonDateTimeArray(dto.issuedOn));
		}
		self.status(PermitDocumentStatus.getByCode(dto.status));
		if (dto.validTo) {
			self.validTo(moment.fromJacksonDateTimeArray(dto.validTo));
		}
		self.remarks(dto.remarks);
		self.isApproved(dto.isApproved);
		self.hasDocument(dto.hasDocument);
		for (var i = 0; i < documentTypes.length; i++) {
			if (documentTypes[i].code === dto.documentTypeCode) {
				self.documentType(documentTypes[i]);
				break;
			}
		}
	};
};
