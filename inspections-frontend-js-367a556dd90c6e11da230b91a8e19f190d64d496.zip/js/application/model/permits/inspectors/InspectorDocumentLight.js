namespace("demax.inspections.model.permits.inspectors");

demax.inspections.model.permits.inspectors.InspectorDocumentLight = function(dto) {
	this.id = dto.id;
	this.documentNumber = dto.documentNumber;
	this.documentType = dto.documentType;
	this.issuedOn = moment.fromJacksonDateTimeArray(dto.issuedOn);
	this.isValid = dto.isValid;
	this.issuer = dto.issuer;
};