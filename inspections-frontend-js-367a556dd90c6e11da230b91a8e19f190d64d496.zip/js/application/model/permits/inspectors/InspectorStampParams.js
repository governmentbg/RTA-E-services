namespace("demax.inspections.model.permits.inspectors");

demax.inspections.model.permits.inspectors.InspectorStampParams = function () {
	var self = this;
	var Type = demax.inspections.nomenclature.permits.inspectors.InspectorStampType;
	var Status = demax.inspections.nomenclature.permits.inspectors.InspectorStampStatus;

	self.id = undefined;
	self.stampTypeId = ko.observable().extend({
		required: true
	});
	self.stampNumber = ko.observable().extend({
		required: {
			onlyIf: function () {
				return self.stampTypeId() === Type.ADR.id;
			},
			message: "Полето е задължително"
		}
	});
	self.stampTypeDescription = ko.observable();
	self.statusCode = ko.observable();
	self.statusDescription = ko.observable();
	self.issuedOn = ko.observable();
	self.hasFile = ko.observable();
	self.revokedOn = ko.observable().extend({
		required: {
			onlyIf: function () {
				return self.statusCode() === Status.TAKEN.code;
			},
			message: "Полето е задължително при статус Отнет!"
		}
	});
	self.remarks = ko.observable().extend({
		maxLength: 250
	});

	this.image = ko.observable().extend({
		required: {
			message: "Моля, качете сканирано копие на документа"
		},
		validation: {
			validator: function (val) {
				//get image bytes size and check if image size < 5mb
				return encodeURI(val).split(/%..|./).length - 1 <= 5242880;
			},
			message: "Изображението не трябва да е по голямо от 5MB"
		}
	});

	self.fullName = ko.observable();
	self.identityNumber = ko.observable();
	self.education = ko.observable();

	self.formattedIssuedOn = ko.observable();
	self.formattedRevokedOn = ko.observable();

	self.toRequestBody = function () {
		var dto = {};
		dto.stampTypeId = self.stampTypeId();
		dto.remarks = self.remarks();
		dto.stampNumber = self.stampNumber();
		return JSON.stringify(dto);
	};

	self.toRequestBodyForUpdate = function () {
		var dto = {};
		dto.revokedOn = self.revokedOn() ? self.revokedOn().format(demax.inspections.settings.serverDateFormat) : null;
		dto.statusCode = self.statusCode();
		dto.protocol = self.image();
		return JSON.stringify(dto);
	};

	self.setUpStamp = function (dto) {
		self.id = dto.id;
		self.stampNumber(dto.stampNumber);
		self.issuedOn(moment.fromJacksonDateTimeArray(dto.issuedOn));
		self.revokedOn(moment.fromJacksonDateTimeArray(dto.revokedOn));
		self.formattedIssuedOn(self.issuedOn() ? self.issuedOn().format(demax.inspections.settings.momentDateFormat) : "-");
		self.formattedRevokedOn(self.revokedOn() ? self.revokedOn().format(demax.inspections.settings.momentDateFormat) : "-");
		self.stampTypeId(dto.type.id);
		self.stampTypeDescription(dto.type.description);
		self.statusCode(dto.status.code);
		self.statusDescription(dto.status.description);
		self.remarks(dto.remarks);
		self.fullName(dto.inspectorInfo.fullName);
		self.identityNumber(dto.inspectorInfo.identityNumber);
		self.education(dto.inspectorInfo.education);
		self.hasFile(dto.hasFile);
	};

	self.setUpEducation = function (dto) {
		this.fullName(dto.fullName);
		this.identityNumber(dto.identityNumber);
		this.education(dto.education);
	};

};