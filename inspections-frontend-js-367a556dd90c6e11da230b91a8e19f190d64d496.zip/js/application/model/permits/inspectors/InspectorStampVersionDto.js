namespace("demax.inspections.model.permits.inspectors");

demax.inspections.model.permits.inspectors.InspectorStampVersionDto = function(dto) {
	var util = demax.inspections.utils.GeneralUtil;
	var InspectorStampType = demax.inspections.nomenclature.permits.inspectors.InspectorStampType;
	this.id = dto.id;
	this.stampNumber = dto.stampNumber;
	this.type = InspectorStampType.getById(dto.type.id);
	this.status = dto.status;
	this.issuedOn = util.formatDate(dto.issuedOn ? dto.issuedOn : null);
	this.revokedOn = dto.revokedOn ? util.formatDate(dto.revokedOn) : null;
	this.modifiedOn = dto.modifiedOn ? util.formatDateTime(dto.modifiedOn) : null;
	this.hasFile = dto.hasFile ? true : false;
};