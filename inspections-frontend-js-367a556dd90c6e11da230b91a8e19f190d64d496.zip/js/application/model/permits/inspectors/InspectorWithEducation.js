namespace("demax.inspections.model.permits.inspectors");

demax.inspections.model.permits.inspectors.InspectorWithEducation = function() {

	this.id = ko.observable();
	this.subjectId = ko.observable();
	this.fullName = ko.observable();
	this.identityNumber = ko.observable();
	this.education = ko.observable();

	this.setUpInspector = function(dto) {
		this.id(dto.id);
		this.subjectId(dto.subjectId);
		this.fullName(dto.fullName);
		this.identityNumber(dto.identityNumber);
		this.education(dto.education);
	};

};