namespace("demax.inspections.model.permits.inspectors");

demax.inspections.model.permits.inspectors.InspectorWithPermitNumbersDto = function (dto) {
	var self = this;
	var PermitInspectorStatus = demax.inspections.nomenclature.permits.PermitInspectorStatus;

	self.id = dto.id;
	self.fullName = dto.fullName;
	self.identityNumber = dto.identityNumber;
	self.isChairman = dto.isChairman;
	self.status = PermitInspectorStatus.getByCode(dto.statusCode);
	self.permitNumbers = dto.permitNumbers;

	self.depriveReason = ko.observable();
	self.isChecked = ko.observable(false);

	self.getEntry = function () {
		return { id: self.id, reason: self.depriveReason() };
	};

	self.check = function () {
		self.isChecked(!self.isChecked());
	};

	self.getPermitNumbersString = (function() {
		var string = "Разреш. ";
		self.permitNumbers.forEach(function (number) {
			string = string + "№" + number + ", ";
		});
		return string.substring(0, string.length - 2);
	})();

};