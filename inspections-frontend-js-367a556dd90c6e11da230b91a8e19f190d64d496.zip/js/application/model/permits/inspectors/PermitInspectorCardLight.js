namespace("demax.inspections.model.permits.inspectors");

demax.inspections.model.permits.inspectors.PermitInspectorCardLight = function(dto) {
	this.id = dto.id;
	this.cardNumber = dto.cardNumber;
	this.serialNumber = dto.serialNumber;
	this.isActive = dto.isActive;
};