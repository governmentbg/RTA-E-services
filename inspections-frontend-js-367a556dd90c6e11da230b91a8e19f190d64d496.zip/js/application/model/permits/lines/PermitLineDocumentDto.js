namespace("demax.inspections.model.permits.lines");

demax.inspections.model.permits.lines.PermitLineDocumentDto = function(dto) {
	var util = demax.inspections.utils.GeneralUtil;
	var PermitDocumentStatus = demax.inspections.nomenclature.permits.PermitDocumentStatus;

	this.id = dto ? dto.id : null;
	this.docNumber = dto && dto.docNumber ? dto.docNumber : "-";
	this.type = dto ? dto.type : "-";
	this.status = dto ? PermitDocumentStatus.getByCode(dto.status) : "-";
	this.isApproved = dto ? dto.isApproved : null;
	this.issueDate = dto.issueDate ? util.formatDate(dto.issueDate) : "-";
	this.validFrom = dto.validFrom ? util.formatDate(dto.validFrom) : null;
	this.validTo = dto.validTo ? util.formatDate(dto.validTo) : null;
};