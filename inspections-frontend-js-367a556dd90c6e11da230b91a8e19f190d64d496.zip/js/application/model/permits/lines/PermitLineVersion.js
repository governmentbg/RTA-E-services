namespace("demax.inspections.model.permits.lines");

demax.inspections.model.permits.lines.PermitLineVersion = function() {
	var self = this;
	var InspectionTypes = demax.inspections.nomenclature.techinsp.InspectionTypes;

	this.addedOn = ko.observable();
	this.modifiedOn = ko.observable();
	this.number = ko.observable();
	this.isApproved = ko.observable();
	this.vehicleCategoriesFormatted = ko.observable();
	this.inspectionTypesFormatted = ko.observable();

	this.setPropertiesFromDto = function(dto) {
		self.addedOn(moment.fromJacksonDateTimeArray(dto.addedOn));
		self.modifiedOn(moment.fromJacksonDateTimeArray(dto.modifiedOn));
		self.number(dto.number);
		self.isApproved(dto.isApproved);
		
		self.vehicleCategoriesFormatted(dto.vehicleCategoryCodes.join(", "));
		self.inspectionTypesFormatted(dto.inspectionTypeCodes.map(function(code) {
			return InspectionTypes[code].text;
		}).join(", "));
	};
};