namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.CategoryLPermitHtmlReportDto = function(dto) {
	demax.inspections.model.permits.reports.GasPermitHtmlReportDto.call(this, dto);
};