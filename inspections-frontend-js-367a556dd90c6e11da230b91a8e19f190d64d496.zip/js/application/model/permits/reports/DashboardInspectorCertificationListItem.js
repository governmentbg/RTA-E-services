namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.DashboardInspectorCertificationListItem = function(dto) {

	var self = this;

	this.id = dto ? dto.id : null;
	this.docNumber = dto ? dto.docNumber : null;
	this.docType = dto ? dto.docType : [];
	this.reissueOn = dto ? dto.reissueOn : [];
	this.subjectIdentityNumber = dto ? dto.subjectIdentityNumber : null;
	this.subjectFullName = dto ? dto.subjectFullName : null;
	this.permits = [];

	this.categories = dto.categories === null ? "-" : dto.categories;
	this.inspectionTypes = dto.inspectionTypes === null ? "-" : dto.inspectionTypes;
	
	if (dto) {
		$.each(dto.permits, function(i, value) {
			self.permits.push(new demax.inspections.model.permits.PermitOrgUnit(value));
		});
	}

	this.statusCode = dto ? dto.statusCode : [];
};
