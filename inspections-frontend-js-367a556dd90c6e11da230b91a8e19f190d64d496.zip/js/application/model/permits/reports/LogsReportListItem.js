namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.LogsReportListItem = function (dto) {
	var self = this;

	this.message = dto && dto.message ? dto.message : "-";
	this.date = dto ? moment.fromJacksonDateTimeArray(dto.date) : null;

	this.dateFormatted = (function () {
		if (self.date) {
			return self.date.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();

};
