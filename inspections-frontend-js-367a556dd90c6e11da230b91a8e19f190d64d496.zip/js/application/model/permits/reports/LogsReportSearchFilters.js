namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.LogsReportSearchFilters = function () {

	var self = this;
	var lastUsedFilters = null;

	var LogQueryTypes = demax.inspections.nomenclature.logs.LogQueryType;
	var LogObjectTypes = demax.inspections.nomenclature.logs.LogObjectType;

	this.queryType = ko.observable(LogQueryTypes.NEW);
	this.objectType = ko.observable(LogObjectTypes.PERMITS);
	this.dateRange = ko.observable(new pastel.plus.binding.dateRangePicker.model.DateRange(moment().subtract(7, "d"), moment()));

	this.toQueryParams = function () {
		var dto = {};

		if (self.queryType()) {
			dto.queryType = self.queryType().code;
		}
		if (self.objectType()) {
			dto.objectType = self.objectType().code;
		}
		if (self.dateRange() && self.dateRange().fromDate()) {
			dto.from = self.dateRange().fromDate().format(demax.inspections.settings.serverDateFormat);
		}
		if (self.dateRange() && self.dateRange().toDate()) {
			dto.to = self.dateRange().toDate().format(demax.inspections.settings.serverDateFormat);
		}

		return dto;
	};

	this.getFormattedRange = ko.pureComputed(function () {
		var from = self.dateRange().fromDate().format(demax.inspections.settings.momentDateFormat);
		var to = self.dateRange().toDate().format(demax.inspections.settings.momentDateFormat);
		return from + " - " + to;
	});

	this.saveLastUsedFilters = function () {
		lastUsedFilters = {
			queryType: self.queryType(),
			objectType: self.objectType(),
			dateRange: self.dateRange()
		};
	};

	this.loadLastUsedFilters = function () {
		if (lastUsedFilters) {
			self.queryType(lastUsedFilters.queryType);
			self.objectType(lastUsedFilters.objectType);
			self.dateRange(lastUsedFilters.dateRange);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function () {
		return lastUsedFilters;
	};

	this.clear = function () {
		self.queryType(LogQueryTypes.NEW);
		self.objectType(LogObjectTypes.PERMITS);
		self.dateRange().fromDate(moment().subtract(7, "d"));
		self.dateRange().toDate(moment());
	};

};