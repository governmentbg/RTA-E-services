namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.PermitDocumentReportListItem = function(dto) {
	var self = this;

	var PermitDocumentStatus = demax.inspections.nomenclature.permits.PermitDocumentStatus;

	this.id = dto ? dto.id : null;
	this.permitVersionId = dto ? dto.permitVersionId : null;
	this.permitNumber = dto ? dto.permitNumber : null;
	this.orgUnit = dto ? dto.orgUnit : null;
	this.companyName = dto ? dto.companyName : null;
	this.identityNum = dto ? dto.identityNum : null;
	this.documentType = dto ? dto.documentType : null;
	this.validFrom = dto ? moment.fromJacksonDateTimeArray(dto.validFrom) : null;
	this.validTo = dto ? moment.fromJacksonDateTimeArray(dto.validTo) : null;
	this.status = dto ? PermitDocumentStatus.getByCode(dto.status) : null;

	this.validToFormatted = (function() {
		if (self.validTo) {
			return self.validTo.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();

	this.validFromFormatted = (function() {
		if (self.validFrom) {
			return self.validFrom.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();

};
