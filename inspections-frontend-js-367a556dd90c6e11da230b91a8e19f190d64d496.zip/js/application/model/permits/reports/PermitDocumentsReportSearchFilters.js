namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.PermitDocumentsReportSearchFilters = function() {

	var self = this;
	var lastUsedFilters = null;

	this.searchText = ko.observable();
	this.orgUnit = ko.observable();
	this.docType = ko.observable();
	this.statusCode = ko.observable();


	this.toQueryParams = function() {
		var dto = {};

		if (self.searchText()) {
			dto.searchText = self.searchText().trim();
		}
		if (self.orgUnit()) {
			dto.orgUnit = self.orgUnit().code;
		}
		if (self.docType()) {
			dto.docType = self.docType();
		}
		if (self.statusCode()) {
			dto.statusCode = self.statusCode().code;
		}

		return dto;
	};

	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			searchText: self.searchText(),
			orgUnit: self.orgUnit(),
			statusCode: self.statusCode(),
			docType: self.docType()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.searchText(lastUsedFilters.searchText);
			self.orgUnit(lastUsedFilters.orgUnit);
			self.statusCode(lastUsedFilters.statusCode);
			self.docType(lastUsedFilters.docType);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.searchText(null);
		self.orgUnit(null);
		self.statusCode(null);
		self.docType(null);
	};

};