namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.PermitInspectorDocumentsReportListItem = function(dto) {

	this.fullName = dto ? dto.fullName : null;
	this.identityNumber = dto ? dto.identityNumber : null;
	this.permits = dto ? dto.permits : [];
	this.documents = dto ? dto.documents : [];
};
