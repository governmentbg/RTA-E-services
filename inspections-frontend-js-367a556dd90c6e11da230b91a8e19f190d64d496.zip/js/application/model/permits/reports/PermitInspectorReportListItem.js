namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.PermitInspectorReportListItem = function (dto) {
	var self = this;
	var PermitInspectorStatus = demax.inspections.nomenclature.permits.PermitInspectorStatus;
	var PermitStatus = demax.inspections.nomenclature.permits.PermitStatus;

	this.id = dto ? dto.id : null;
	this.inspectorName = dto ? dto.inspectorName : null;
	this.inspectorIdentityNum = dto ? dto.inspectorIdentityNum : null;
	this.permitNum = dto ? dto.permitNum : null;
	this.permitStatus = dto ? PermitStatus.getByCode(dto.permitStatus) : null;
	this.orgUnit = dto ? dto.orgUnit : null;
	this.companyIdentNum = dto ? dto.companyIdentNum : null;
	this.companyName = dto ? dto.companyName : null;
	this.isChairman = dto ? dto.isChairman : null;
	this.inspectionType = dto ? dto.inspectionType : null;
	this.hasCard = dto ? dto.hasCard : null;
	this.status = dto ? PermitInspectorStatus.getByCode(dto.status) : null;
	this.permitVersionId = dto ? dto.permitVersionId : null;
	this.dateOfStatus = dto && dto.dateOfStatus ? moment.fromJacksonDateTimeArray(dto.dateOfStatus) : null;

	this.dateOfStatusFormatted = (function () {
		if (self.dateOfStatus) {
			return self.dateOfStatus.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();

};
