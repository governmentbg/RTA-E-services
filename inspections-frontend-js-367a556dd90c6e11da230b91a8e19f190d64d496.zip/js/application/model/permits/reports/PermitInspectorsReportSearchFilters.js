namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.PermitInspectorsReportSearchFilters = function() {

	var self = this;
	var lastUsedFilters = null;

	this.searchText = ko.observable();
	this.orgUnit = ko.observable();
	this.isChairman = ko.observable();
	this.inspectionType = ko.observable();
	this.hasCard = ko.observable();
	this.statusCode = ko.observable();


	this.toQueryParams = function() {
		var dto = {};

		if (self.searchText()) {
			dto.searchText = self.searchText().trim();
		}
		if (self.orgUnit()) {
			dto.orgUnit = self.orgUnit().code;
		}
		if (self.isChairman() || self.isChairman() === false) {
			dto.isChairman = self.isChairman();
		}
		if (self.inspectionType()) {
			dto.inspectionType = self.inspectionType().code;
		}
		if (self.hasCard() || self.hasCard() === false) {
			dto.hasCard = self.hasCard();
		}
		if (self.statusCode()) {
			dto.statusCode = self.statusCode();
		}

		return dto;
	};

	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			searchText: self.searchText(),
			orgUnit: self.orgUnit(),
			isChairman: self.isChairman(),
			inspectionType: self.inspectionType(),
			hasCard: self.hasCard(),
			statusCode: self.statusCode()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.searchText(lastUsedFilters.searchText);
			self.orgUnit(lastUsedFilters.orgUnit);
			self.isChairman(lastUsedFilters.isChairman);
			self.inspectionType(lastUsedFilters.inspectionType);
			self.hasCard(lastUsedFilters.hasCard);
			self.statusCode(lastUsedFilters.statusCode);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.searchText(null);
		self.orgUnit(null);
		self.isChairman(null);
		self.inspectionType(null);
		self.hasCard(null);
		self.statusCode(null);
	};

};