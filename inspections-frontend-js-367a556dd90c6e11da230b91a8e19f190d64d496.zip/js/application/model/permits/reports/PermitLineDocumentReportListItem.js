namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.PermitLineDocumentReportListItem = function(dto) {
	var self = this;

	var PermitDocumentStatus = demax.inspections.nomenclature.permits.PermitDocumentStatus;

	this.id = dto ? dto.id : null;
	this.lineVersionId = dto ? dto.lineVersionId : null;
	this.permitVersionId = dto ? dto.permitVersionId : null;
	this.permitNumber = dto ? dto.permitNumber : null;
	this.lineNumber = dto ? dto.lineNumber : null;
	this.orgUnit = dto ? dto.orgUnit : null;
	this.documentType = dto ? dto.docType : null;
	this.validFrom = dto ? moment.fromJacksonDateTimeArray(dto.validFrom) : null;
	this.validTo = dto ? moment.fromJacksonDateTimeArray(dto.validTo) : null;
	this.status = dto ? PermitDocumentStatus.getByCode(dto.status) : null;

	this.validToFormatted = (function() {
		if (self.validTo) {
			return self.validTo.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();

	this.validFromFormatted = (function() {
		if (self.validFrom) {
			return self.validFrom.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();

};
