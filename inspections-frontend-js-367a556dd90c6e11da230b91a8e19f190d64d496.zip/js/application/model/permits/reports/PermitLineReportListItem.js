namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.PermitLineReportListItem = function(dto) {

	this.permitNumber = dto.permitNumber;
	this.orgUnit = dto.orgUnit;
	this.identityNumber = dto.identityNumber;
	this.companyName = dto.companyName;
	this.lineNumber = dto.lineNumber;
	this.categories = dto.categories.join(", ");
	this.inspectionTypes = dto.inspectionTypes.join(", ");
	this.lineVersionId = dto.lineVersionId;
	this.permitVersionId = dto.permitVersionId;
};