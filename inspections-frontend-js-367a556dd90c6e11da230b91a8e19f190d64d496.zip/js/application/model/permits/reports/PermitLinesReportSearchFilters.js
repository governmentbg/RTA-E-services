namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.PermitLinesReportSearchFilters = function() {
	var self = this;
	var lastUsedFilters = null;

	this.searchText = ko.observable();
	this.orgUnit = ko.observable();
	this.categories = ko.observableArray([undefined]);
	this.inspectionTypes = ko.observableArray([undefined]);

	subscribeToMultiSelect(this.categories);
	subscribeToMultiSelect(this.inspectionTypes);

	this.toQueryParams = function() {	
		var dto = {};

		if (self.searchText()) {
			dto.searchText = self.searchText().trim();
		}
		if (self.orgUnit()) {
			dto.orgUnit = self.orgUnit().code;
		}
		var categories = self.categories() ? self.categories().filter(function(category) {
			return category !== undefined;
		}) : null;
		if (categories && categories.length > 0) {
			dto.categories = categories;
		}
		var inspectionTypes = self.inspectionTypes() ? self.inspectionTypes().filter(function(inspectionType) {
			return inspectionType !== undefined;
		}) : null;
		if (inspectionTypes && inspectionTypes.length > 0) {
			dto.inspectionTypes = inspectionTypes.map(function(type) {
				return type.code;
			});
		}
		return dto;
	};

	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			searchText: self.searchText(),
			orgUnit: self.orgUnit(),
			categories: self.categories(),
			inspectionTypes: self.inspectionTypes()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.searchText(lastUsedFilters.searchText);
			self.orgUnit(lastUsedFilters.orgUnit);
			self.categories(lastUsedFilters.categories);
			self.inspectionTypes(lastUsedFilters.inspectionTypes);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function () {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.searchText(null);
		self.orgUnit(null);
		self.categories([undefined]);
		self.inspectionTypes([undefined]);
	};

	function subscribeToMultiSelect(observableArray) {
		observableArray.subscribe(function(changes) {
			var addAll = false;

			changes.forEach(function(change) {
				if (change.value === undefined && change.status === "added") {
					observableArray([undefined]);
					addAll = true;
					return;
				}
			});
	
			if (!addAll && observableArray()[0] === undefined && observableArray().length > 1) {
				observableArray(observableArray().slice(1));
			}
	
		}, self, "arrayChange");
	}
};
