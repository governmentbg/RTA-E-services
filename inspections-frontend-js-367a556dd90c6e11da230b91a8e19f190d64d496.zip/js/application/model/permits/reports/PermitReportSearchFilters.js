namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.PermitReportSearchFilters = function() {
	var self = this;
	var lastUsedFilters = null;
	var KtpCategory = demax.inspections.nomenclature.permits.KtpCategory;

	this.searchText = ko.observable();
	this.orgUnit = ko.observable();
	this.ktpCategory = ko.observable();
	this.status = ko.observable();
	this.numberOfLines = ko.observable();
	this.validTo = ko.observable();
	this.numberFrom = ko.observable();
	this.numberTo = ko.observable();

	this.currentLoadedStatusFilter = ko.observable();

	this.toQueryParams = function() {
		self.currentLoadedStatusFilter(self.status());		
		var dto = {};

		if (self.searchText()) {
			dto.searchText = self.searchText().trim();
		}
		if (self.orgUnit()) {
			dto.orgUnit = self.orgUnit().code;
		}
		if (self.ktpCategory()) {
			if (self.ktpCategory() === KtpCategory.FOUR) {
				dto.ktpCategories = [KtpCategory.FOUR_TB.code, KtpCategory.FOUR_TM.code];
			} else {
				dto.ktpCategories = [self.ktpCategory().code];
			}
		}
		if (self.status()) {
			dto.statusCode = self.status().code;
		}
		if (self.numberOfLines()) {
			dto.numberOfLines = self.numberOfLines();
		}
		if (self.validTo()) {
			dto.validTo = self.validTo().format(demax.inspections.settings.serverDateFormat);
		}
		if (self.numberFrom() && self.numberTo()) {
			dto.numberFrom = self.numberFrom();
			dto.numberTo = self.numberTo();
		}
		return dto;
	};

	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			searchText: self.searchText(),
			orgUnit: self.orgUnit(),
			ktpCategory: self.ktpCategory(),
			status: self.status(),
			numberOfLines: self.numberOfLines(),
			validTo: self.validTo(),
			numberFrom: self.numberFrom(),
			numberTo: self.numberTo()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.searchText(lastUsedFilters.searchText);
			self.orgUnit(lastUsedFilters.orgUnit);
			self.ktpCategory(lastUsedFilters.ktpCategory);
			self.status(lastUsedFilters.status);
			self.numberOfLines(lastUsedFilters.numberOfLines);
			self.validTo(lastUsedFilters.validTo);
			self.numberFrom(lastUsedFilters.numberFrom);
			self.numberTo(lastUsedFilters.numberTo);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.searchText(null);
		self.orgUnit(null);
		self.ktpCategory(null);
		self.status(null);
		self.numberOfLines(null);
		self.validTo(null);
		self.numberFrom(null);
		self.numberTo(null);
	};
};
