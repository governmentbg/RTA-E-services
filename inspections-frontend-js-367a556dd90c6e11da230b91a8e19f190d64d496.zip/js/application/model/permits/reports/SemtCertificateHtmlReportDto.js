namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.SemtCertificateHtmlReportDto = function(dto) {

	this.registrationNumber = dto.registrationNumber;
	this.vinFrameNumber = dto.vinFrameNumber;
	this.ecoCategory = dto.ecoCategory;
	this.nextInspectionDate = dto.nextInspectionDate ? demax.inspections.utils.GeneralUtil.formatDate(dto.nextInspectionDate) : null;
};