namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.SemtPermitHtmlReportDto = function(dto) {

	this.permitNumber = dto.permitNumber;
	this.companyName = dto.companyName;
	this.address = dto.address;
	this.city = dto.city;
	this.region = dto.region;
	this.phoneNumber = dto.phoneNumber;
};