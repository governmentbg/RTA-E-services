namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.StickersReportListItem = function (dto) {
	var self = this;
	this.permitNumber = dto ? dto.permitNumber : null;
	this.orgUnit = dto ? dto.orgUnit : null;
	this.orderNumber = dto ? dto.orderNumber : null;
	this.companyName = dto ? dto.companyName : null;
	this.activationDate = dto ? moment.fromJacksonDateTimeArray(dto.activationDate) : null;
	this.fromNumber = dto ? dto.fromNumber : null;
	this.toNumber = dto ? dto.toNumber : null;
	this.quantity = dto ? dto.quantity : null;
	this.activatedIntervals = dto && dto.activatedIntervals ? dto.activatedIntervals : "-";
	this.usedIntervals = dto && dto.usedIntervals ? dto.usedIntervals : "-";
	this.scrappedIntervals = dto && dto.scrappedIntervals ? dto.scrappedIntervals : "-";

	this.activatedIntervalsCount = dto ? dto.activatedIntervalsCount : 0;
	this.usedIntervalsCount = dto ? dto.usedIntervalsCount : 0;
	this.scrappedIntervalsCount = dto ? dto.scrappedIntervalsCount : 0;

	// Watchers
	this.isExpanded = ko.observable(false);

	this.toggleExpanded = function () {
		self.isExpanded(!self.isExpanded());
	},

	this.activationDateFormatted = (function () {
		if (self.activationDate) {
			return self.activationDate.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();

};
