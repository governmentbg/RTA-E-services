namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.StickersReportSearchFilters = function () {

	var self = this;
	var lastUsedFilters = null;
	var StickerSearchTypes = demax.inspections.nomenclature.orders.stickers.StickerSearchType;

	this.searchText = ko.observable();
	this.searchType = ko.observable();
	this.orgUnit = ko.observable();
	this.status = ko.observable();
	this.fromDate = ko.observable(moment().startOf("day").subtract(7, "days"));
	this.toDate = ko.observable(moment().startOf("day"));

	this.searchText.extend({
		pattern: {
			params: "[0-9]+",
			message: "Полето трябва да съдържа само цифри!"
		},
		required: {
			onlyIf: function () {
				return self.searchType();
			},
			message: "Полето е задължително при избран вид на търсене!"
		}
	});

	this.searchType.extend({
		required: {
			onlyIf: function () {
				return self.searchText();
			},
			message: "Полето е задължително когато полето за търсене е попълнено!"
		}
	});

	this.fromDate.extend({
		required: true,
		dateInterval: {
			endDate: self.toDate,
			interval: 12
		}
	});

	this.toDate.extend({
		required: true,
		dateIsAfterOrEqual: self.fromDate
	});

	this.toQueryParams = function () {
		var dto = {};

		if (this.searchText()) {
			if (this.searchType() === StickerSearchTypes.PERMIT_NUMBER) {
				dto.permitNumber = parseInt(self.searchText().trim());
			} else if (this.searchType() === StickerSearchTypes.ORDER_NUMBER) {
				dto.orderNumber = parseInt(self.searchText().trim());
			} else if (this.searchType() === StickerSearchTypes.STICKER_NUMBER) {
				dto.stickerNumber = parseInt(self.searchText().trim());
			}
		}
		if (self.orgUnit()) {
			dto.orgUnit = self.orgUnit().code;
		}
		if (self.status()) {
			dto.status = self.status().code;
		}
		if (self.fromDate()) {
			dto.from = self.fromDate().format(demax.inspections.settings.serverDateFormat);
		}
		if (self.toDate()) {
			dto.to = self.toDate().format(demax.inspections.settings.serverDateFormat);
		}

		return dto;
	};

	this.saveLastUsedFilters = function () {
		lastUsedFilters = {
			searchText: self.searchText(),
			searchType: self.searchType(),
			orgUnit: self.orgUnit(),
			status: self.status(),
			fromDate: self.fromDate(),
			toDate: self.toDate()
		};
	};

	this.loadLastUsedFilters = function () {
		if (lastUsedFilters) {
			self.searchText(lastUsedFilters.searchText);
			self.searchType(lastUsedFilters.searchType);
			self.orgUnit(lastUsedFilters.orgUnit);
			self.status(lastUsedFilters.status);
			self.fromDate(lastUsedFilters.fromDate);
			self.toDate(lastUsedFilters.toDate);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function () {
		return lastUsedFilters;
	};

	this.clear = function () {
		self.searchText(null);
		self.searchType(null);
		self.orgUnit(null);
		self.status(null);
		self.fromDate(moment().startOf("day").subtract(7, "days"));
		self.toDate(moment().startOf("day"));
	};

};