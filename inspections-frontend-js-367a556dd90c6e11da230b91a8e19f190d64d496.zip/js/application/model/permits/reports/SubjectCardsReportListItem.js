namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.SubjectCardsReportListItem = function (dto) {
	var PermitOrgUnitCode = demax.inspections.model.permits.PermitOrgUnitCode;
	var SubjectLight = demax.inspections.model.SubjectLight;

	this.cardNumber = dto ? dto.cardNumber : null;
	this.serialNumber = dto ? dto.serialNumber : null;
	this.subject = dto ? new SubjectLight(dto.subject) : null;
	this.company = dto ? new SubjectLight(dto.company) : null;
	this.isActive = dto ? dto.isActive : null;
	this.permits = dto ? dto.permits.map(function (permitDto) {
		return new PermitOrgUnitCode(permitDto);
	}) : null;

};
