namespace("demax.inspections.model.permits.reports");

demax.inspections.model.permits.reports.SubjectCardsReportSearchFilters = function() {

	var self = this;
	var lastUsedFilters = null;

	this.searchText = ko.observable();
	this.orgUnit = ko.observable();
	this.isActive = ko.observable();

	// Validation
	this.searchText.extend({
		minLength: 1,
		maxLength: 10,
		pattern: {
			params: "[0-9]+",
			message: "Полето трябва да съдържа само цифри!"
		}
	});

	this.toQueryParams = function() {
		var dto = {};

		if (self.searchText()) {
			dto.searchText = self.searchText().trim();
		}
		if (self.orgUnit()) {
			dto.orgUnit = self.orgUnit().code;
		}
		if (self.isActive() !== undefined && self.isActive() !== null) {
			dto.isActive = self.isActive();
		}

		return dto;
	};

	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			searchText: self.searchText(),
			orgUnit: self.orgUnit(),
			isActive: self.isActive()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.searchText(lastUsedFilters.searchText);
			self.orgUnit(lastUsedFilters.orgUnit);
			self.isActive(lastUsedFilters.isActive);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.searchText(null);
		self.orgUnit(null);
		self.isActive(null);
	};

};