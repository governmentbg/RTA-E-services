namespace("demax.inspections.model.problems");

demax.inspections.model.problems.PermitProblemCreationRequest = function() {
	var self = this;
	
	this.permitId = ko.observable().extend({
		required: true
	});
	this.problemDesc = ko.observable().extend({
		required: true,
		maxLength: 250
	});
	this.expectedCheckDate = ko.observable();

	this.toRequestBody = function() {
		var dto = {};
		
		if (self.permitId()) {
			dto.permitId = self.permitId();
		}
		if (self.problemDesc()) {
			dto.problemDesc = self.problemDesc();
		}
		if (self.expectedCheckDate()) {
			dto.expectedCheckDate = self.expectedCheckDate().format(demax.inspections.settings.serverDateFormat);
		}
		return JSON.stringify(dto);
	};

	this.clearAllFields = function () {
		self.permitId(null);
		self.problemDesc(null);
		self.problemDesc.clearError();
		self.expectedCheckDate(null);
	};
};