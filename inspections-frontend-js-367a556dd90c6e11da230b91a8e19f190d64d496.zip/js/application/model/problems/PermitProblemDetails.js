namespace("demax.inspections.model.problems");

demax.inspections.model.problems.PermitProblemDetails = function () {
	var self = this;

	this.id = ko.observable();
	this.companyName = ko.observable();
	this.identityNumber = ko.observable();
	this.contactPerson = ko.observable();
	this.contactNumber = ko.observable();
	this.city = ko.observable();
	this.address = ko.observable();

	this.loadDetails = function (dto) {
		self.id(dto.id);
		self.companyName(dto.companyName);
		self.identityNumber(dto.identityNumber);
		self.contactPerson(dto.contactPerson);
		self.contactNumber(dto.contactNumber);
		self.city(dto.city);
		self.address(dto.address);
	};

	this.clearAllFields = function () {
		self.id(null);
		self.companyName(null);
		self.identityNumber(null);
		self.contactPerson(null);
		self.contactNumber(null);
		self.city(null);
		self.address(null);
	};
};