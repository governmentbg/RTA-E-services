namespace("demax.inspections.model.problems");

demax.inspections.model.problems.PermitProblemEditDetails = function (dto) {
	var self = this;
	var ProblemStatuses = demax.inspections.nomenclature.problems.ProblemStatuses;

	this.id = dto.id;
	this.permitNum = dto.permitNum;
	this.companyName = dto.companyName;
	this.identityNum = dto.identityNum;
	this.contactName = dto.contactName;
	this.contactNum = dto.contactNum;
	this.city = dto.city;
	this.address = dto.address;
	this.operatorName = dto.operatorName;
	this.dateCreated = dto.dateCreated ? moment.fromJacksonDateTimeArray(dto.dateCreated) : null;
	this.problemDesc = ko.observable(dto.problemDesc).extend({
		required: true,
		maxLength: 250
	});
	this.expectedCheckDate = dto.expectedCheckDate ? moment.fromJacksonDateTimeArray(dto.expectedCheckDate) : null;
	this.checkedOn = dto.checkedOn ? ko.observable(moment.fromJacksonDateTimeArray(dto.checkedOn)
		.format(demax.inspections.settings.momentDateFormat)) : ko.observable().extend({
		required: true
	});
	this.checkedBy = ko.observable(dto.checkedBy).extend({
		required: true,
		maxLength: 50
	});
	this.checkDescription = ko.observable(dto.checkDescription).extend({
		required: true,
		maxLength: 250
	});
	this.status = ProblemStatuses.getById(dto.status);

	this.toRequestBody = function () {
		var dto = {};

		if (self.checkedOn()) {
			dto.checkedOn = self.checkedOn().format(demax.inspections.settings.serverDateFormat);
		}
		if (self.checkedBy()) {
			dto.checkedBy = self.checkedBy();
		}
		if (self.checkDescription()) {
			dto.checkDescription = self.checkDescription();
		}
		return JSON.stringify(dto);
	};

	this.dateCreatedFormatted = (function () {
		if (self.dateCreated) {
			return self.dateCreated.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();

	this.expectedCheckDateFormatted = (function () {
		if (self.expectedCheckDate) {
			return self.expectedCheckDate.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();

	this.isForEdit = (function () {
		return !self.checkedOn();
	})();

};