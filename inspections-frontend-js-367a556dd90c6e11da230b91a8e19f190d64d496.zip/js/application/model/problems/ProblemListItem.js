namespace("demax.inspections.model.problems");

demax.inspections.model.problems.ProblemListItem = function(dto) {
	var self = this;

	var ProblemStatuses = demax.inspections.nomenclature.problems.ProblemStatuses;

	this.id = dto ? dto.id : null;
	this.permitVersionId = dto ? dto.permitVersionId : null;
	this.permitNum = dto ? dto.permitNum : null;
	this.dateCreated = dto ? moment.fromJacksonDateTimeArray(dto.dateCreated) : null;
	this.problemDesc = dto ? dto.problemDesc : null;
	this.companyName = dto ? dto.companyName : null;
	this.identityNum = dto ? dto.identityNum : null;
	this.contactName = dto ? dto.contactName : null;
	this.contactNum = dto ? dto.contactNum : null;
	this.address = dto ? dto.address : null;
	this.city = dto ? dto.city : null;
	this.orgUnit = dto ? dto.orgUnit : null;
	this.status = dto ? ProblemStatuses.getById(dto.status) : null;

	this.dateCreatedFormatted = (function() {
		if (self.dateCreated) {
			return self.dateCreated.format(demax.inspections.settings.momentDateFormat);
		} else {
			return "-";
		}
	})();

	this.companyDetails = (function() {
		if (self.companyName && self.identityNum) {
			return self.companyName + " " + self.identityNum;
		} else {
			return "-";
		}
	})();

	this.contactDetails = (function() {
		if (self.contactName && self.contactNum) {
			return self.contactName + " " + self.contactNum;
		} else {
			return "-";
		}
	})();
};
