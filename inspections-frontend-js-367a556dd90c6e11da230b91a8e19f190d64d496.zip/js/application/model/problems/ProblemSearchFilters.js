namespace("demax.inspections.model.problems");

demax.inspections.model.problems.ProblemSearchFilters = function () {
	var self = this;
	var lastUsedFilter = null;
	var ProblemStatuses = demax.inspections.nomenclature.problems.ProblemStatuses;

	this.searchText = ko.observable();
	this.searchDescription = ko.observable();
	this.dateCreated = ko.observable();
	this.status = ko.observable([ProblemStatuses.WAITING, ProblemStatuses.RESOLVED]);
	this.orgUnit = ko.observable();

	this.selectedStatus = ko.observable();

	this.toQueryParams = function () {
		self.selectedStatus(self.status());
		var dto = {};

		if (self.searchText()) {
			dto.searchTerm = self.searchText().trim();
		}
		if (self.searchDescription()) {
			dto.searchDescription = self.searchDescription().trim();
		}
		if (self.dateCreated()) {
			dto.dateCreated = self.dateCreated().format(demax.inspections.settings.serverDateFormat);
		}
		if (self.status()) {
			dto.status = self.status().id;
		}
		if (self.orgUnit()) {
			dto.orgUnitCode = self.orgUnit().code;
		}

		return dto;
	};

	this.saveLastUsedFilters = function () {
		lastUsedFilter = {
			searchText: self.searchText(),
			searchDescription: self.searchDescription(),
			dateCreated: self.dateCreated(),
			status: self.status(),
			orgUnitCode: self.orgUnit()
		};
	};

	this.loadLastUsedFilters = function () {
		if (lastUsedFilter) {
			self.searchText(lastUsedFilter.searchText);
			self.searchDescription(lastUsedFilter.searchDescription);
			self.dateCreated(lastUsedFilter.dateCreated);
			self.status(lastUsedFilter.status);
			self.orgUnit(lastUsedFilter.orgUnit);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilter;
	};

	this.clear = function () {
		self.searchText(null);
		self.searchDescription(null);
		self.dateCreated(null);
		self.status(null);
		self.orgUnit(null);
	};
};
