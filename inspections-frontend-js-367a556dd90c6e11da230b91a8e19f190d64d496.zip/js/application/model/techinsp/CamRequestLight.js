namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.CamRequestLight = function(dto) {
	var CamRequestStatus = demax.inspections.nomenclature.techinsp.CamRequestStatus;

	this.feedNum = dto.feedNum !== undefined ? dto.feedNum : null;
	this.resolution = dto.resolution !== undefined ? dto.resolution : null;
	this.status = ko.observable(dto.statusCode !== undefined ? CamRequestStatus[dto.statusCode] : null);

	this.getId = function() {
		return {
			feedNum: this.feedNum,
			resolution: this.resolution
		};
	};
};
