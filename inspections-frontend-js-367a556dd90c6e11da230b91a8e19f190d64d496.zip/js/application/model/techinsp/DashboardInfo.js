namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.DashboardInfo = function(dto) {
	this.requestedPermitsCount = dto ? dto.requestedPermitsCount : null;
	this.processingPermitsCount = dto ? dto.processingPermitsCount : null;
	this.remainingDaysBeforeExpirationCount = dto ? dto.remainingDaysBeforeExpirationCount : null;
	this.permitDocuments = dto ? new demax.inspections.model.techinsp.DocumentsCount(dto.permitDocuments) : null;
	this.inspectorDocuments = dto ? new demax.inspections.model.techinsp.DocumentsCount(dto.inspectorDocuments) 
		: new demax.inspections.model.techinsp.DocumentsCount();
	this.lineDocuments = dto ? new demax.inspections.model.techinsp.DocumentsCount(dto.lineDocuments) : null;
	this.inspectorCertificates = dto ? new demax.inspections.model.techinsp.DocumentsCount(dto.inspectorCertificates) 
		: new demax.inspections.model.techinsp.DocumentsCount();
};