namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.DiagnosticCameraPosition = function(dto) {
	this.id = dto ? dto.id : null;
	this.camIndex = dto ? dto.camIndex : null;
	this.isInPlace = dto ? dto.isInPlace : null;
	this.lastUpdate = dto ? moment.fromJacksonDateTimeArray(dto.lastUpdate) : null;
};