namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.DiagnosticConnectivityStatus = function(dto) {
	var DiagnosticConnectivityType = demax.inspections.nomenclature.techinsp.DiagnosticConnectivityType;
	
	this.id = dto ? dto.id : null;
	this.lastCheck = dto ? moment.fromJacksonDateTimeArray(dto.lastCheck) : null;
	this.connectivity = dto ? DiagnosticConnectivityType[dto.connectivityCode] : null;
	this.isSuccessful = dto ? dto.isSuccessful : null;
	this.lastCheck = dto ? moment.fromJacksonDateTimeArray(dto.lastCheck) : null;
};