namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.DiagnosticListItem = function(dto) {
	var self = this;
	var OrgUnit = demax.inspections.model.OrgUnit;
	var DiagnosticConnectivityStatus = demax.inspections.model.techinsp.DiagnosticConnectivityStatus;
	var DiagnosticCameraPosition = demax.inspections.model.techinsp.DiagnosticCameraPosition;
	var momentDateTimeFormat = demax.inspections.settings.momentDateTimeFormat;

	this.id = dto ? dto.id : null;
	this.permitNumber = dto ? dto.permitNumber : null;
	this.orgUnit = dto.orgUnit !== undefined ? new OrgUnit(dto.orgUnit) : null;
	this.permitLineNumber = dto ? dto.permitLineNumber : null;
	this.connectivityStatuses = dto ? getConnectivityStatuses(dto.connectivityStatuses): null;
	this.cameraPositions = dto ? getCameraPositions(dto.cameraPositions) : null;
	this.operationSystemLastUpdate = dto && dto.operationSystemLastUpdate ? 
		moment.fromJacksonDateTimeArray(dto.operationSystemLastUpdate) : null;
	this.isOperationSystemUpToDate = dto ? dto.isOperationSystemUpToDate : null;
	
	this.formattedLastConnectivityCheckDateTime = function() {
		var date = null;
		if (self.connectivityStatuses.length > 0) {
			date = ko.unwrap(self.connectivityStatuses[0].lastCheck);
		}
		return date ? date.format(momentDateTimeFormat) : "";
	}();
	
	this.formattedLastCameraUpdateDateTime = function() {
		var date = null;
		if (self.cameraPositions.length > 0) {
			date = ko.unwrap(self.cameraPositions[0].lastUpdate);
		}
		return date ? date.format(momentDateTimeFormat) : "";
	}();
	
	this.formattedOperationSystemLastUpdate = function() {
		var date = ko.unwrap(self.operationSystemLastUpdate);
		return date ? date.format(momentDateTimeFormat) : "";
	}();

	this.getIsOperationSystemUpToDateText = function() {
		if (self.isOperationSystemUpToDate === true) {
			return "последна версия";
		}
	}();
	
	function getConnectivityStatuses(connectivityStatuses) {
		return ko.utils.arrayMap(connectivityStatuses, function(itemDto) {
			return new DiagnosticConnectivityStatus(itemDto);
		});
	}
	
	function getCameraPositions(cameraPositions) {
		return ko.utils.arrayMap(cameraPositions, function(itemDto) {
			return new DiagnosticCameraPosition(itemDto);
		});
	}
};
