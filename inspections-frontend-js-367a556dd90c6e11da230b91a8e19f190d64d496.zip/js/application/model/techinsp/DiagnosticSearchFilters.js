namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.DiagnosticSearchFilters = function() {
	var self = this;
	var DiagnosticConnectivityStatus = demax.inspections.nomenclature.techinsp.DiagnosticConnectivityStatus;
	var lastUsedFilters = null;
	
	this.permitNumber = ko.observable().extend({
		number : true
	});
	this.orgUnit = ko.observable();
	this.cameraStatus = ko.observable();
	this.connectivityStatus = ko.observable(DiagnosticConnectivityStatus.UNSUCCESSFUL);
	this.softwareStatus = ko.observable();

	this.toQueryParams = function() {
		var dto = {};
		var permitNumber = self.permitNumber();
		var orgUnit = self.orgUnit();
		var cameraStatus = self.cameraStatus();
		var connectivityStatus = self.connectivityStatus();
		var softwareStatus = self.softwareStatus();

		if (permitNumber) {
			dto.permitNumber = permitNumber;
		}
		if (orgUnit) {
			dto.orgUnitCode = orgUnit.code;
		}
		if (cameraStatus) {
			dto.isCameraInPosition = cameraStatus.serverValue;
		}
		if (connectivityStatus) {
			dto.connectivityStatus = connectivityStatus.serverValue;
		}
		if (softwareStatus) {
			dto.softwareStatus = softwareStatus.code;
		}
		return dto;
	};
	
	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			permitNumber: self.permitNumber(),
			orgUnit: self.orgUnit(),
			cameraStatus: self.cameraStatus(),
			connectivityStatus : self.connectivityStatus(),
			softwareStatus : self.softwareStatus()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.permitNumber(lastUsedFilters.permitNumber);
			self.orgUnit(lastUsedFilters.orgUnit);
			self.cameraStatus(lastUsedFilters.cameraStatus);
			self.connectivityStatus(lastUsedFilters.connectivityStatus);
			self.softwareStatus(lastUsedFilters.softwareStatus);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.permitNumber(null);
		self.orgUnit(null);
		self.cameraStatus(null);
		self.connectivityStatus(null);
		self.softwareStatus(null);
	};
};