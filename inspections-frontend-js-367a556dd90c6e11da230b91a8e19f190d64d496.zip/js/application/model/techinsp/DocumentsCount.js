namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.DocumentsCount = function(dto) {
	this.expired = ko.observable(dto ? dto.expired : 0);
	this.expireAfterDays = ko.observable(dto ? dto.expireAfterDays : 0);
};