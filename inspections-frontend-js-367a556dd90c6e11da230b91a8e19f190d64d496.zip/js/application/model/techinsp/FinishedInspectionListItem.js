namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.FinishedInspectionListItem = function(dto) {
	var self = this;

	var OrgUnit = demax.inspections.model.OrgUnit;
	var InspectionStatus = demax.inspections.nomenclature.techinsp.InspectionStatus;
	var InspectionConclusion = demax.inspections.nomenclature.techinsp.InspectionConclusion;
	var momentTimeFormat = demax.inspections.settings.momentTimeFormat;
	var momentDateFormat = demax.inspections.settings.momentDateFormat;

	this.id = dto ? dto.id : null;
	this.inspectionStartTime = dto ? moment.fromJacksonDateTimeArray(dto.inspectionStartTime) : null;
	this.inspectionEndTime = dto ? moment.fromJacksonDateTimeArray(dto.inspectionEndTime) : null;
	this.ktpNumber = dto ? dto.ktpNumber : null;
	this.line = dto ? dto.line : null;
	this.orgUnit = dto.orgUnit !== undefined ? new OrgUnit(dto.orgUnit) : null;
	this.protocolNumber = dto ? dto.protocolNumber : null;
	this.hologramNumber = dto ? dto.hologramNumber: null;
	this.registrationNumber = dto ? dto.registrationNumber : null;
	this.vehicleMake = dto ? dto.vehicleMake : null;
	this.inspectionType = dto ? dto.inspectionType : null;
	this.category = dto ? dto.category : null;
	this.status = dto ? InspectionStatus[dto.status] : null;
	this.conclusion = dto ? InspectionConclusion[dto.conclusion] : null;
	this.isSuspicious = dto ? dto.isSuspicious : null;
	this.shortVideoUrl = dto ? dto.shortVideoUrl : null;
	this.hasSemt = dto ? dto.hasSemt : null;


	this.formattedInspectionDate= function() {
		var date = self.inspectionStartTime;
		return date ? date.format(momentDateFormat) : "";
	}();
	
	this.formattedInspectionStartTime = function() {
		var time = self.inspectionStartTime;
		return time ? time.format(momentTimeFormat) : "";
	}();
	
	this.formattedInspectionEndTime = function() {
		var time = self.inspectionEndTime;
		return time ? time.format(momentTimeFormat) : "";
	}();
	
	this.formattedInspectionLength = function() {
		var inspectionStart = self.inspectionStartTime;
		var inspectionEnd = self.inspectionEndTime;
		return inspectionStart && inspectionEnd ? moment(inspectionEnd.diff(inspectionStart)).format("m[m]") : "";
	}();
};
