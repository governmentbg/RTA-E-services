namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.FinishedInspectionSearchFilters = function (dto) {
	var self = this;

	this.ktpNum = ko.observable(dto ? ko.unwrap(dto.ktpNum) : null);
	this.chairman = ko.observable(dto ? ko.unwrap(dto.chairman) : null);
	this.commissionMember = ko.observable(dto ? ko.unwrap(dto.commissionMember) : null);
	this.dateRange = ko.observable(dto && dto.dateRange ? dto.dateRange : new pastel.plus.binding.dateRangePicker.model.DateRange(
		moment().subtract(7, "d"), moment())).extend({
		required: {
			message: "Полето е задължително"
		}
	});
	this.orgUnit = ko.observable(dto ? ko.unwrap(dto.orgUnit) : null);
	this.conclusion = ko.observable(dto ? ko.unwrap(dto.conclusion) : null);
	this.isSuspicious = ko.observable(dto ? ko.unwrap(dto.isSuspicious) : false);
	this.isSemt = ko.observable(dto ? ko.unwrap(dto.isSemt) : false);
	this.status = ko.observable(dto ? ko.unwrap(dto.status) : null);

	this.toQueryParams = function () {
		var dto = {};
		if (self.ktpNum()) {
			dto.ktpNum = self.ktpNum().trim();
		}
		if (self.chairman() && self.chairman().id) {
			dto.chairmanId = self.chairman().id;
		}
		if (self.commissionMember() && self.commissionMember().id) {
			dto.commissionMemberId = self.commissionMember().id;
		}
		if (self.dateRange() && self.dateRange().fromDate()) {
			dto.fromDate = self.dateRange().fromDate().format(demax.inspections.settings.serverDateTimeFormat);
		}
		if (self.dateRange() && self.dateRange().toDate()) {
			dto.toDate = self.dateRange().toDate().format(demax.inspections.settings.serverDateTimeFormat);
		}
		if (self.orgUnit()) {
			dto.orgUnitCode = self.orgUnit().code;
		}
		if (self.conclusion()) {
			dto.conclusion = self.conclusion().code;
		}
		if (self.isSuspicious() === true) {
			dto.isSuspicious = self.isSuspicious();
		}
		if (self.isSemt() === true) {
			dto.isSemt = self.isSemt();
		}
		if (self.status()) {
			dto.statuses = [self.status().dbStatusCodes];
		}
		return dto;
	};

	this.copyProperties = function () {
		var dto = {
			ktpNum: self.ktpNum(),
			chairman: self.chairman(),
			commissionMember: self.commissionMember(),
			dateRange: self.dateRange(),
			orgUnit: self.orgUnit(),
			conclusion: self.conclusion(),
			isSuspicious: self.isSuspicious(),
			isSemt: self.isSemt(),
			status: self.status()
		};
		return dto;
	};

	this.toggleIsSuspicious = function () {
		self.isSuspicious(!self.isSuspicious());
	};

	this.toggleIsSemt = function () {
		self.isSemt(!self.isSemt());
	};
};