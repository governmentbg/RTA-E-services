namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.FinishedInspectionSpecificSearchFilters = function(dto) {
	var self = this;

	this.input = ko.observable(dto ? dto.input : "").extend({
		required: true
	});
	this.selectedSpecificSearchFilter = ko.observable(dto ? dto.selectedSpecificSearchFilter : "");

	this.toQueryParams = function() {
		var dto = {};
		self.input(self.input().trim());
		switch (self.selectedSpecificSearchFilter().code) {
			case "REG_NUM": {
				dto.regNum = self.input();
			}
				break;
			case "HOLOGRAM": {
				dto.hologram = self.input();
			}
				break;
			case "PROTOCOL": {
				dto.protocolNum = self.input();
			}
				break;
			case "VIN_OR_RAMA": {
				dto.vinOrRama = self.input();
			}
				break;
			case "OWNER_IDENTITY_NUMBER": {
				dto.ownerIdentityNumber = self.input();
			}
				break;
			case "INSPECTION_PERSON_EGN": {
				dto.inspectionPersonEgn = self.input();
			}
				break;
		}
		return dto;
	};

	this.copyProperties = function() {
		var dto = {
			input : self.input(),
			selectedSpecificSearchFilter : self.selectedSpecificSearchFilter()
		};
		return dto;
	};
};
