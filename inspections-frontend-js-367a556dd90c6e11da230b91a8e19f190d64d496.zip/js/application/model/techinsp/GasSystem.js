namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.GasSystem = function(dto) {
	var self = this;

	self.status = dto && dto.statusCode ? demax.inspections.nomenclature.techinsp.GasSystemStatusType.getByCode(dto.statusCode) : "-";	
	self.fuelType = dto && dto.fuelType ? demax.inspections.nomenclature.techinsp.GasSystemFuelType.getByCode(dto.fuelType) : "-";
	self.tankMake = dto && dto.tankMake ? dto.tankMake : "-";
	self.installerFullName = dto && dto.installerFullName ? dto.installerFullName : "-";
	self.tankNumberOfApproval = dto && dto.tankNumberOfApproval ? dto.tankNumberOfApproval : "-";
	self.tankSerialNumber = dto && dto.tankSerialNumber ? dto.tankSerialNumber : "-";
	self.tankYearOfProduction = dto && dto.tankYearOfProduction ? dto.tankYearOfProduction : "-";

};
