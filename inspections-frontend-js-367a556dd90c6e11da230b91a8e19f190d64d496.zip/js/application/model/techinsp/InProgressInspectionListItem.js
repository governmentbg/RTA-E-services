namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.InProgressInspectionListItem = function(dto) {
	var self = this;
	
	var OrgUnit = demax.inspections.model.OrgUnit;

	this.id = dto ? dto.id : null;
	this.status = dto && dto.statusCode ? demax.inspections.nomenclature.InspectionStatus.getByCode(dto.statusCode) : null;
	this.inspectionStartTime = dto ? moment.fromJacksonDateTimeArray(dto.inspectionStartTime) : null;
	this.ktpNumber = dto ? dto.ktpNumber : null;
	this.orgUnit = dto && dto.orgUnit !== undefined ? new OrgUnit(dto.orgUnit) : null;
	this.chairman = dto ? dto.chairman : null,
	this.registrationNumber = dto ? dto.registrationNumber : null;
	this.vehicleMake = dto ? dto.vehicleMake : null;
	this.fuelType = dto ? dto.fuelType : null;
	this.inspectionType = dto ? dto.inspectionType : null;
	this.category = dto ? dto.category : null;
	this.isSuspicious = dto ? dto.isSuspicious : null;
	this.hasSecondaryInspection = dto ? dto.hasSecondaryInspection : false;

	this.secondaryInspection = dto && dto.secondaryInspection ? 
		new demax.inspections.model.techinsp.SecondaryInspection(dto.secondaryInspection) : undefined;

	this.formattedInspectionStartTime = function() {
		return self.inspectionStartTime ? self.inspectionStartTime.format(demax.inspections.settings.momentTimeFormat) : "";
	}();
};
