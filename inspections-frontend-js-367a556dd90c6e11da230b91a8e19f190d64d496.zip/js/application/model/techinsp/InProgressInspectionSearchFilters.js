namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.InProgressInspectionSearchFilters = function(dto) {
	var self = this;
	var lastUsedFilters = null;

	this.ktpNum = ko.observable(dto ? ko.unwrap(dto.ktpNum) : null);
	this.regNum = ko.observable(dto ? ko.unwrap(dto.regNum) : null);
	this.orgUnit = ko.observable(dto ? ko.unwrap(dto.orgUnit) : null);

	this.toQueryParams = function() {
		var dto = {};

		var ktpNum = self.ktpNum();
		var regNum = self.regNum();
		var orgUnit = self.orgUnit();

		if (ktpNum !== null && ktpNum !== undefined) {
			dto.ktpNum = ktpNum.trim();
		}

		if (regNum !== null && regNum !== undefined) {
			dto.regNum = regNum.trim();
		}
		
		if (orgUnit !== null && orgUnit !== undefined) {
			dto.orgUnitCode = orgUnit.code;
		}

		return dto;
	};
	
	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			ktpNum: self.ktpNum(),
			regNum: self.regNum(),
			orgUnit: self.orgUnit()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.ktpNum(lastUsedFilters.ktpNum);
			self.regNum(lastUsedFilters.regNum);
			self.orgUnit(lastUsedFilters.orgUnit);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.ktpNum(null);
		self.regNum(null);
		self.orgUnit(null);
	};
};
