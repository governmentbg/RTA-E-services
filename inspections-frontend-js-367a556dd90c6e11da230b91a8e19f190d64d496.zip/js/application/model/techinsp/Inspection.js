namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.Inspection = function(dto) {
	var self = this;

	this.id = dto ? dto.id : null;
	this.status = dto && dto.statusCode ? demax.inspections.nomenclature.InspectionStatus.getByCode(dto.statusCode) : null;
	this.permit = dto ? new demax.inspections.model.permits.PermitOrgUnit(dto.permit) : null;
	this.vehicle = dto ? new demax.inspections.model.techinsp.RoadVehicle(dto.vehicle) : null;
	this.personName = dto ? dto.personName : null;
	this.personEgn = dto ? dto.personEgn : null;
	this.chairmanName = dto ? dto.chairmanName : null;
	this.memberName = dto ? dto.memberName : null;
	this.protocolNumber = dto ? dto.protocolNumber : null;
	this.hologramNumber = dto ? dto.hologramNumber : null;
	this.type = dto && dto.type ? new demax.inspections.model.techinsp.InspectionType(dto.type) : null;
	this.conclusion = dto && dto.conclusionCode ? demax.inspections.nomenclature.InspectionConclusion.getByCode(dto.conclusionCode) : null;
	this.startedAt = dto && dto.startedAt ? moment.fromJacksonDateTimeArray(dto.startedAt) : null;
	this.finishedAt = dto && dto.finishedAt ? moment.fromJacksonDateTimeArray(dto.finishedAt) : null;
	this.validTo = dto && dto.validTo ? moment.fromJacksonDateTimeArray(dto.validTo) : null;
	this.taxCheckResults = [];
	this.isSuspicious = dto ? dto.suspicious : false;
	this.hasSecondaryInspection = dto ? dto.hasSecondaryInspection : false;
	this.hasCisternProtocol = dto ? dto.hasCisternProtocol : false;
	this.hasSemt = dto ? dto.hasSemt : false;
	this.shortVideoUrl = dto ? dto.shortVideoUrl : null;
	this.snapShotUrl = dto ? dto.snapShotUrl : null;
	this.stopReason = dto && dto.stopReason ? dto.stopReason : null;
	this.gasSystem = dto && dto.gasSystem ? new demax.inspections.model.techinsp.GasSystem(dto.gasSystem) : null;

	this.secondaryInspection = dto && dto.secondaryInspection ? 
		new demax.inspections.model.techinsp.SecondaryInspection(dto.secondaryInspection) : undefined;

	this.faults = dto && dto.faults ? dto.faults : [];

	this.semtDetails = dto && dto.semt ? new demax.inspections.model.techinsp.SemtDetails(dto.semt) : null;

	$.each(dto.taxCheckResults, function (index, taxCheckResult) {
		self.taxCheckResults.push(new demax.inspections.model.techinsp.TaxCheckResult(taxCheckResult));
	});
	

};
