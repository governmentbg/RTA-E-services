namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.InspectionLiveStreamSetupResponse = function(dto) {
	var CamRequestLight = demax.inspections.model.techinsp.CamRequestLight;

	this.restreamAddress = dto.restreamAddress !== undefined ? dto.restreamAddress : null;
	this.isAsf = dto.isAsf === true;
	this.camRequest = dto.camRequest !== undefined ? new CamRequestLight(dto.camRequest) : null;
};
