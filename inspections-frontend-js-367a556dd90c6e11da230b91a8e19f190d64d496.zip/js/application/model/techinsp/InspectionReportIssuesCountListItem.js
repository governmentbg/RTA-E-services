namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.InspectionReportIssuesCountListItem = function(dto) {
	var self = this;
	
	this.inspectionElementDescription = dto ? dto.inspectionElementDescription : null;
	this.inspectionCheckValue = dto ? dto.inspectionCheckValue : null;
	this.inspectionElementCardinality = dto ? getIssueCardinality(dto.inspectionElementCardinality) : null;
	this.inspectionsCount = dto ? dto.inspectionsCount : null;
	
	function getIssueCardinality(cardinality) {
		if (cardinality == "НП") {
			return "Незначителна повреда";
		}
		
		if (cardinality == "ЗП") {
			return "Значителна повреда";
		}

		if (cardinality == "ОП") {
			return "Опасна повреда";
		}
		return "Не е отбелязана";
	}
	
	this.toReportRow = function() {
		return {
			inspectionElementDescription: self.inspectionElementDescription ? self.inspectionElementDescription : "",
			inspectionCheckValue: self.inspectionCheckValue ? self.inspectionCheckValue : "",
			inspectionElementCardinality: self.inspectionElementCardinality ? self.inspectionElementCardinality : "",
			inspectionsCount: self.inspectionsCount ? self.inspectionsCount : 0
		};
	};
};