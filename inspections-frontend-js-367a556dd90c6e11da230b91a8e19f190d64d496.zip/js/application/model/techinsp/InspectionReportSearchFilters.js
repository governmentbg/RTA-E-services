namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.InspectionReportSearchFilters = function(reportType) {
	var self = this;
	var serverDateFormat = demax.inspections.settings.serverDateFormat;
	var momentDateFormat = demax.inspections.settings.momentDateFormat;
	var description = "";
	var reportTitle = "";
	var loadedConclusionFilter = "";
	var selectedReportType = reportType;

	this.ktpNumber = ko.observable().extend({
		required : {
			onlyIf : function() {
				return selectedReportType !== undefined && (selectedReportType != "types-count" && selectedReportType != "issued-semts-count");
			},
			message : "Полето е задължително"
		},
		number: true
	});

	this.orgUnit = ko.observable().extend({
		required : {
			onlyIf : function() {
				return selectedReportType !== undefined && selectedReportType == "types-count";
			},
			message: "Полето е задължително"
		}
	});

	this.vehicleCategoryCode = ko.observable();

	this.dateRange = ko.observable(new pastel.plus.binding.dateRangePicker.model.DateRange(moment().subtract(1, "y"), moment())).extend({
		required : {
			onlyIf : function() {
				return selectedReportType !== undefined && (selectedReportType != "unused-stickers" && selectedReportType != "issued-semts-count");
			},
			message: "Полето е задължително"
		}
	});

	this.conclusion = ko.observable().extend({
		required : {
			onlyIf : function() {
				return selectedReportType !== undefined && selectedReportType == "issues-count";
			},
			message: "Полето е задължително"
		}
	});

	this.inspectionsCount = ko.observable().extend({
		required : {
			onlyIf : function() {
				return selectedReportType !== undefined && selectedReportType == "vehicle-inspections-count";
			},
			message: "Полето е задължително"
		},
		min: 3
	});

	this.inspectionsCountOption = ko.observable().extend({
		required : {
			onlyIf : function() {
				return selectedReportType !== undefined && selectedReportType == "vehicle-inspections-count";
			},
			message: "Полето е задължително"
		}
	});
	
	this.publishedBy = ko.observable().extend({
		required : {
			onlyIf : function() {
				return selectedReportType !== undefined && selectedReportType == "issued-semts-count";
			},
			message: "Полето е задължително"
		}
	});

	this.ecoCategory = ko.observable().extend({
		required : {
			onlyIf : function() {
				return selectedReportType !== undefined && selectedReportType == "issued-semts-count";
			},
			message: "Полето е задължително"
		}
	});

	this.semtStatus = ko.observable().extend({
		required : {
			onlyIf : function() {
				return selectedReportType !== undefined && selectedReportType == "issued-semts-count";
			},
			message: "Полето е задължително"
		}
	});

	this.isValidByCurrentMoment = ko.observable(false).extend({
		required : {
			onlyIf : function() {
				return selectedReportType !== undefined && selectedReportType == "issued-semts-count";
			},
			message: "Полето е задължително"
		}
	});

	this.toQueryParams = function() {
		var dto = {};

		if (self.ktpNumber()) {
			var ktpNumber = self.ktpNumber().trim();
		}
		var orgUnit = self.orgUnit();
		var dateRange = self.dateRange();
		var conclusion = self.conclusion();
		if (self.inspectionsCount()) {
			var inspectionsCount = self.inspectionsCount().trim();
		}
		var inspectionsCountOption = self.inspectionsCountOption();
		var vehicleCategoryCode = self.vehicleCategoryCode();
		var publishedBy = self.publishedBy();
		var ecoCategory = self.ecoCategory();
		var semtStatus = self.semtStatus();
		var isValidByCurrentMoment = self.isValidByCurrentMoment();

		if (ktpNumber) {
			dto.ktpNumber = ktpNumber;
		}
		if (orgUnit) {
			dto.orgUnitCode = orgUnit.code;
		}
		if (conclusion) {
			dto.conclusion = conclusion.code;
		}
		if (inspectionsCount) {
			dto.inspectionsCount = inspectionsCount;
		}
		if (inspectionsCountOption) {
			dto.inspectionsCountOption = inspectionsCountOption.code;
		}
		if (dateRange) {
			dto.fromDate = ko.unwrap(dateRange.fromDate).format(serverDateFormat);
			dto.toDate = ko.unwrap(dateRange.toDate).format(serverDateFormat);
		}
		if (vehicleCategoryCode) {
			dto.vehicleCategoryCode = vehicleCategoryCode.code;
		}
		if (publishedBy) {
			dto.publishedBy = publishedBy;
		}
		if (ecoCategory) {
			dto.ecoCategory = ecoCategory;
		}
		if (publishedBy) {
			dto.semtStatus = semtStatus;
		}
		if (isValidByCurrentMoment) {
			dto.isValidByCurrentMoment = isValidByCurrentMoment;
		}
		
		return dto;
	};

	this.setTypesCountByKtpNumberReportDescription = function() {
		var ktpNumber = self.ktpNumber() ? self.ktpNumber() : "";
		var fromDate = self.dateRange() && self.dateRange().fromDate() ? self.dateRange().fromDate().format(momentDateFormat) : "";
		var	toDate = self.dateRange() && self.dateRange().toDate() ? self.dateRange().toDate().format(momentDateFormat) : "";

		reportTitle = "Справка за брой и видове прегледи за " + "КТП № " + ktpNumber + " за период " + fromDate + " - " + toDate;
		description = "КТП № " + ktpNumber + " за период " + fromDate + " - " + toDate;
	};

	this.setTypesCountReportDescription = function() {
		var orgUnit = self.orgUnit() ? self.orgUnit().name : "";
		var fromDate = self.dateRange() && self.dateRange().fromDate() ? self.dateRange().fromDate().format(momentDateFormat) : "";
		var	toDate = self.dateRange() && self.dateRange().toDate() ? self.dateRange().toDate().format(momentDateFormat) : "";
		var vehicleCategoryCode = self.vehicleCategoryCode() ? " - Категория " + self.vehicleCategoryCode() : "";

		reportTitle = "Справка за брой и видове прегледи за " + orgUnit + " за период " + fromDate + " - " + toDate + vehicleCategoryCode;
		description = orgUnit + " за период " + fromDate + " - " + toDate + vehicleCategoryCode;
	};

	this.setIssuesCountReportDescription = function() {
		var ktpNumber = self.ktpNumber() ? self.ktpNumber() : "";
		var fromDate = self.dateRange() && self.dateRange().fromDate() ? self.dateRange().fromDate().format(momentDateFormat) : "";
		var	toDate = self.dateRange() && self.dateRange().toDate() ? self.dateRange().toDate().format(momentDateFormat) : "";
		var conclusionText = self.conclusion() ? self.conclusion().displayText : "";

		description = " КТП " + ktpNumber + " за период " + fromDate + " - " + toDate;
		loadedConclusionFilter = ", заключение - " + conclusionText;
		reportTitle = "Справка за видове технически неизправности за КТП "
			+ ktpNumber + " за период " + fromDate + " - " + toDate + loadedConclusionFilter;
	};

	this.setPassedAfterIssuesCountReportDescription = function() {
		var ktpNumber = self.ktpNumber() ? self.ktpNumber() : "";
		var fromDate = self.dateRange() && self.dateRange().fromDate() ? self.dateRange().fromDate().format(momentDateFormat) : "";
		var	toDate = self.dateRange() && self.dateRange().toDate() ? self.dateRange().toDate().format(momentDateFormat) : "";

		reportTitle = "Справка за ППС преминали ГТП след отстраняване на неизправности "
				+ "за КТП " + ktpNumber + " за период " + fromDate + "-" + toDate;
		description = "КТП " + ktpNumber + " за период " + fromDate + "-" + toDate;
	};

	this.setVehicleInspectionsCountReportDescription = function() {
		var ktpNumber = self.ktpNumber() ? self.ktpNumber() : "";
		var fromDate = self.dateRange() && self.dateRange().fromDate() ? self.dateRange().fromDate().format(momentDateFormat) : "";
		var	toDate = self.dateRange() && self.dateRange().toDate() ? self.dateRange().toDate().format(momentDateFormat) : "";

		reportTitle = "Справка за брой ГТП на ППС за КТП " + ktpNumber + " за период " + fromDate + " - " + toDate;

		if (self.inspectionsCountOption() && self.inspectionsCountOption().code == "EQUALS") {
			reportTitle += ", които имат точно " + self.inspectionsCount() + " прегледа.";
		} else if (self.inspectionsCountOption() && self.inspectionsCountOption().code == "GREATER_THAN") {
			reportTitle += ", които имат повече от " + self.inspectionsCount() + " прегледа.";
		}

		description = "КТП " + ktpNumber + " за период " + fromDate + " - " + toDate;
	};
	
	this.setUnusedStickersReportDescription = function() {
		var ktpNumber = self.ktpNumber() ? self.ktpNumber() : "";
		description = "Справка за неизползвани стикери за последните 12 месеца към КТП " + ktpNumber;
	};
	
	this.setUnusedStickersReportDescription = function() {
		var ktpNumber = self.ktpNumber() ? self.ktpNumber() : "";
		description = "Справка за неизползвани стикери за последните 12 месеца към КТП " + ktpNumber;
	};
	
	this.setIssuedSemtsReportDescription = function() {
		description = "Справка за СЕМТ сертификати";
	};

	this.getLoadedConclusionFilter = function() {
		return loadedConclusionFilter;
	};

	this.getDescription = function() {
		return description;
	};

	this.getReportTitle = function() {
		return reportTitle;
	};

	this.toggleIsValidByCurrentMoment = function () {
		self.isValidByCurrentMoment(!self.isValidByCurrentMoment());
	};
};
