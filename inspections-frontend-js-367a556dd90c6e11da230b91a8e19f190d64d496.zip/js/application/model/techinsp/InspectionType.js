namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.InspectionType = function(dto) {
	this.code = dto ? dto.code : null;
	this.tiiaDescription = dto ? dto.tiiaDescription : null;
};
