namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.InspectionTypesCountByKtpListItem = function(dto) {
	var InspectionConclusion = demax.inspections.nomenclature.techinsp.InspectionConclusion;
	var self = this;
	
	this.ktpNumber = dto ? dto.ktpNumber : null;
	this.inspectionType = dto ? dto.inspectionType : null;
	this.vehicleCategory = dto ? dto.vehicleCategoryCode : null;
	this.conclusion = dto ? InspectionConclusion[dto.conclusion] : null;
	this.inspectionsCount = dto ? dto.inspectionsCount : null;
	
	this.toReportRow = function() {
		return {
			ktpNumber: self.ktpNumber ? self.ktpNumber : "",
			inspectionType: self.inspectionType ? self.inspectionType : "",
			vehicleCategoryCode: self.vehicleCategory ? self.vehicleCategory : "",
			conclusion: self.conclusion ? self.conclusion.displayText : "",
			inspectionsCount: self.inspectionsCount ? self.inspectionsCount : 0
		};
	};
};