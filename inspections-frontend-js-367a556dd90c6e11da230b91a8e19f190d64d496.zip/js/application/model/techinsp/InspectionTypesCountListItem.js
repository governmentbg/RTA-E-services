namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.InspectionTypesCountListItem = function(dto) {
	var InspectionConclusion = demax.inspections.nomenclature.techinsp.InspectionConclusion;
	var self = this;

	this.inspectionType = dto ? dto.inspectionType : null;
	this.conclusion = dto ? InspectionConclusion[dto.conclusion] : null;
	this.inspectionsCount = dto ? dto.inspectionsCount : null;
	
	this.toReportRow = function() {
		return {
			inspectionType: self.inspectionType ? self.inspectionType : "",
			conclusion: self.conclusion ? self.conclusion.displayText : "",
			inspectionsCount: self.inspectionsCount ? self.inspectionsCount : 0
		};
	};
};