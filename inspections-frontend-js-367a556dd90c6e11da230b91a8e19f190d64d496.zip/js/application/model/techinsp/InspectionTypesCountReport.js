namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.InspectionTypesCountReport = function(dto) {
	var InspectionTypesCountByKtpListItem = demax.inspections.model.techinsp.InspectionTypesCountByKtpListItem;
	var InspectionTypesCountListItem = demax.inspections.model.techinsp.InspectionTypesCountListItem;
	
	this.typesCountByKtpItems = ko.observable(dto ? getTypesCountByKtpItems(dto.inspectionTypesCountByKtpDtos) : []);
	this.typesCountItems = ko.observable(dto ? getTypesCountItems(dto.inspectionTypesCountDtos) : []);
	
	function getTypesCountByKtpItems(items) {
		return ko.utils.arrayMap(items, function(itemDto) {
			return new InspectionTypesCountByKtpListItem(itemDto);
		});
	}
	function getTypesCountItems(items) {
		return ko.utils.arrayMap(items, function(itemDto) {
			return new InspectionTypesCountListItem(itemDto);
		});
	}
};