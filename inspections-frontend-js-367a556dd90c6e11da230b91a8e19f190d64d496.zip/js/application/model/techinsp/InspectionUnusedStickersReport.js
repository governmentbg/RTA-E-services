namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.InspectionUnusedStickersReport = function(dto) {
	var OrgUnit = demax.inspections.model.OrgUnit;
	var InspectionOrderUnusedStickersReportLightDto = demax.inspections.model.orders.InspectionOrderUnusedStickersReportLightDto;
	
	this.permitNumber = dto ? dto.permitNumber: null;
	this.orgUnit = dto ? new OrgUnit(dto.orgUnit) : null; 
	this.ktpName = dto ? dto.ktpName : null;
	this.orders = dto && dto.orders ? getOrdersDtos(dto.orders) : null;
	this.totalUnusedStickers = dto ? dto.totalUnusedStickers : null;
	
	function getOrdersDtos(orders) {
		return ko.utils.arrayMap(orders, function(item) {
			return new InspectionOrderUnusedStickersReportLightDto(item);
		});
	}
};