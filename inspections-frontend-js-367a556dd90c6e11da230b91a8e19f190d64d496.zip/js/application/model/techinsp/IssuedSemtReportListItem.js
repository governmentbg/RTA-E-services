namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.IssuedSemtReportListItem = function(dto) {
	var SemtStatus = demax.inspections.model.techinsp.SemtStatus;
	var self = this;
	
	this.registrationNumber = dto ? dto.registrationNumber : null;
	this.vinFrameNumber = dto ? dto.vinFrameNumber : null;
	this.ecoCategory = dto ? dto.ecoCategory : null;
	this.validTo = dto ? moment.fromJacksonDateTimeArray(dto.validTo) : null;
	this.status = dto ? SemtStatus.getByCode(dto.status) : null;
	
	this.toReportRow = function() {
		return {
			registrationNumber: self.registrationNumber ? self.registrationNumber : "",
			vinFrameNumber: self.vinFrameNumber ? self.vinFrameNumber : "",
			ecoCategory: self.ecoCategory ? self.ecoCategory : "",
			validTo: self.validTo ? self.validTo : "",
			status: self.status ? self.status.name : ""
		};
	};
};