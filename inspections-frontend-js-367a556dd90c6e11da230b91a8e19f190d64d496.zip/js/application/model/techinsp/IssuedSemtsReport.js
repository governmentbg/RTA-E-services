namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.IssuedSemtsReport = function(dto) {
	var IssuedSemtReportListItem = demax.inspections.model.techinsp.IssuedSemtReportListItem;
	
	this.issuedSemtItems = ko.observable(dto ? getIssuedSemtItems(dto.issuedSemtsDtos) : []);
	
	function getIssuedSemtItems(items) {
		return ko.utils.arrayMap(items, function(itemDto) {
			return new IssuedSemtReportListItem(itemDto);
		});
	}
};