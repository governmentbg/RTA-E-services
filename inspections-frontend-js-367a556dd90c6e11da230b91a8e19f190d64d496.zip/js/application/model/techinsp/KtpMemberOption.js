namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.KtpMemberOption = function(dto) {
	var self = this;

	this.id = dto ? dto.id : null;
	this.name = dto ? dto.name : null;
	this.ktpName = dto ? dto.ktpName : null;

	this.optionsText = (function() {
		return ko.unwrap(self.name) + " - " + ko.unwrap(self.ktpName);
	})();
};
