namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.OdometerHistory = function(dto) {

	this.inspectionDate = dto ? moment.fromJacksonDateTimeArray(dto.inspectionDate) : null;
	this.odometerState = dto ? dto.odometerState : null;
	this.ktpNumber = dto ? dto.ktpNumber : null;
	this.protocolNumber = dto ? dto.protocolNumber : null;
};
