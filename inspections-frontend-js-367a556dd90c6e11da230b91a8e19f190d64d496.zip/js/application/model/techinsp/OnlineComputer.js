namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.OnlineComputer = function(dto) {

	this.id = dto ? dto.id : null;
	this.permitLine = dto ? dto.permitLine : null;
	this.serviceMenuUrl = dto ? dto.serviceMenuUrl : null;
	this.lastActiveAt = dto ? moment.fromJacksonDateTimeArray(dto.lastActiveAt) : null;
	this.ipAddress = dto ? dto.ipAddress : null;
};
