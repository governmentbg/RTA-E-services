namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.OnlineComputersSearchFilters = function() {
	var self = this;
	var lastUsedFilters = null;
	
	this.permitNumber = ko.observable();
	this.orgUnit = ko.observable();

	this.toQueryParams = function() {
		var dto = {};
		if (self.permitNumber()) {
			dto.permitNumber = self.permitNumber();
		}
		if (self.orgUnit()) {
			dto.orgUnitCode = self.orgUnit().code;
		}
		return dto;
	};
	
	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			permitNumber: self.permitNumber(),
			orgUnit: self.orgUnit()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.permitNumber(lastUsedFilters.permitNumber);
			self.orgUnit(lastUsedFilters.orgUnit);
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.permitNumber(null);
		self.orgUnit(null);
	};
};
