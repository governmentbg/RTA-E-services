namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.SecondaryInspection = function(dto) {
	var self = this;

	self.id = dto ? dto.id : undefined;
	self.reason = dto && dto.reason ? dto.reason : undefined;
	self.createdBy = dto ? dto.createdBy : undefined;
	self.createdDateTime = dto ? moment.fromJacksonDateTimeArray(dto.createdDateTime) : undefined;

	self.canceledBy = dto ? dto.canceledBy : undefined;
	self.canceledDateTime = dto ? moment.fromJacksonDateTimeArray(dto.canceledDateTime) : undefined;
	
	self.isActive = dto ? dto.active : undefined;
};
