namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.SemtDetails = function (dto) {
	var self = this;
	var requiredValidator = { required: true };

	this.registrationNumber = dto ? ko.observable(dto.changeVehicleRegisterNumber) : ko.observable();
	this.compilianceNumber = dto ? ko.observable(dto.compilianceNumber) : ko.observable();
	this.ecoCategory = dto && dto.ecoCategory ? ko.observable(dto.ecoCategory) : ko.observable(undefined);
	this.makeModelLat = dto ? ko.observable(dto.makeModelLat) : ko.observable();
	this.engineNumber = dto ? ko.observable(dto.engineNumber) : ko.observable();
	this.engineType = dto ? ko.observable(dto.engineType) : ko.observable();

	self.registrationNumber.extend({
		required: true,
		pattern: "^([ABEKMHOPCTYX]{1,2})([0-9]{4})([ABEKMHOPCTYX]{1,2})$"
	});
	self.compilianceNumber.extend(requiredValidator);
	self.ecoCategory.extend(requiredValidator);
	self.makeModelLat.extend(requiredValidator);
	self.engineNumber.extend(requiredValidator);
	self.engineType.extend(requiredValidator);

	this.status = dto ? demax.inspections.model.techinsp.SemtStatus.getByCode(dto.status) : null;
	this.issueDate = dto ? moment.fromJacksonDateTimeArray(dto.issueDate) : null;
	this.prints = (dto && dto.semtPrints ? dto.semtPrints : []).map(function(prints) {
		return new demax.inspections.model.techinsp.SemtPrint(prints);
	});

	self.toQueryParams = function () {
		var engineNumber = self.engineNumber();
		if (self.engineNumber() === "") {
			engineNumber = undefined;
		}

		var engineType = self.engineType();
		if (self.engineType() === "") {
			engineType = undefined;
		}

		var params = {
			compilianceNumber: self.compilianceNumber(),
			ecoCategory: self.ecoCategory(),
			makeModelLat: self.makeModelLat(),
			engineNumber: engineNumber,
			engineType: engineType
		};

		return params;
	};

};