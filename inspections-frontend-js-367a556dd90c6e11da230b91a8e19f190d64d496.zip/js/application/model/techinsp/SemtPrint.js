namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.SemtPrint = function (dto) {
	var self = this;

	self.printDate = dto ? moment.fromJacksonDateTimeArray(dto.printDate) : null;
	self.printedBy = dto ? dto.isPrintedByIaaa ? "ИААА" : "КТП" : "-";


};