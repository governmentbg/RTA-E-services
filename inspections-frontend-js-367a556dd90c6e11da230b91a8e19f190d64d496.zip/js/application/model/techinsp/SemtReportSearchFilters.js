namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.SemtReportSearchFilters = function() {
	var self = this;
	
	this.publishedBy = ko.observable();
	this.ecoCategory = ko.observable();
	this.semtStatus = ko.observable();

	this.toQueryParams = function() {
		var dto = {};

		if (self.publishedBy()) {
			dto.publishedBy = self.publishedBy().code;
		}
		if (self.ecoCategory()) {
			dto.ecoCategory = self.ecoCategory().code;
		}
		if (self.semtStatus()) {
			dto.semtStatus = self.semtStatus();
		}

		return dto;
	};
};
