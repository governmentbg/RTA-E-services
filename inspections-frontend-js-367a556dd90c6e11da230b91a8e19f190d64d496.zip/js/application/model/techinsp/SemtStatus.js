namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.SemtStatus = {
	NEW: {
		code: "N",
		name: "Нов",
		cssClass: "label-primary"
	},
	LATE: {
		code: "L",
		name: "Закъснял",
		cssClass: "label-warning"
	},
	APPROVED: {
		code: "A",
		name: "Одобрен",
		cssClass: "label-success"
	},
	CHANGED_NUMBER: {
		code: "C",
		name: "Сменен Рег. Номер",
		cssClass: "label-gray"
	},
	DECLINED: {
		code: "D",
		name: "Отказан",
		cssClass: "label-danger"
	},
	ANY: {
		code: "ANY",
		name: "Всички"
	},

	get ALL() {
		return [this.ANY, this.NEW, this.LATE, this.APPROVED, this.CHANGED_NUMBER, this.DECLINED];
	},

	getByCode: function (code) {
		var status = null;
		for (var key in this) {
			if (this[key].code == code) {
				status = this[key];
				break;
			}
		}
		return status;
	}

};
