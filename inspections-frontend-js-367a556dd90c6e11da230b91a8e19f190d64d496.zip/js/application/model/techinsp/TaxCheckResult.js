namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.TaxCheckResult = function(dto) {

	this.checkId = dto ? dto.checkId : undefined;
	this.region = dto ? dto.region : undefined;
	this.municipality = dto ? dto.municipality : undefined;
	this.registrationNumber = dto ? dto.registrationNumber : undefined;
	this.identityNumber = dto ? dto.identityNumber : undefined;
	this.createdAt = dto ? moment.fromJacksonDateTimeArray(dto.createdAt) : undefined;
	this.ministryOfFinanceResult = dto ? dto.ministryOfFinanceResult : undefined;
	this.municipalityResult = dto ? dto.municipalityResult : undefined;
	this.error = dto ? dto.error : undefined;

};
