namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.VehicleInspectionsCountReportListItem = function(dto) {
	var InspectionConclusion = demax.inspections.nomenclature.techinsp.InspectionConclusion;
	var self = this;
	
	this.registrationNumber = dto ? dto.registrationNumber : null;
	this.makeAndModel = dto ? dto.makeAndModel : null;
	this.inspectionsCount = dto ? dto.inspectionsCount : null;
	this.conclusion = dto ? InspectionConclusion[dto.conclusion] : null;
	
	this.toReportRow = function() {
		return {
			registrationNumber: self.registrationNumber ? self.registrationNumber : "",
			makeAndModel: self.makeAndModel ? self.makeAndModel : "",
			inspectionsCount: self.inspectionsCount ? self.inspectionsCount : 0,
			conclusion: self.conclusion ? self.conclusion.displayText : ""
		};
	};
};