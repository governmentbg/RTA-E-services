namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.VideoDownloadRequestListItem = function(dto) {
	var self = this;
	var OrgUnit = demax.inspections.model.OrgUnit;
	var momentDateFormat = demax.inspections.settings.momentDateFormat;
	var VideoDownloadRequestStatus = demax.inspections.nomenclature.techinsp.VideoDownloadRequestStatus;
	
	this.inspectionStartTime = dto ? moment.fromJacksonDateTimeArray(dto.inspectionStartTime) : null;
	this.ktpNumber = dto ? dto.ktpNumber : null;
	this.orgUnit = dto && dto.orgUnit !== undefined ? new OrgUnit(dto.orgUnit): null;
	this.registrationNumber = dto ? dto.registrationNumber : null;
	this.hologramNumber = dto ? dto.hologramNumber : null;
	this.inspectionType = dto ? dto.inspectionType : null;
	this.requestedAt = dto ? moment.fromJacksonDateTimeArray(dto.requestedAt) : null;
	this.protocolNumber = dto ? dto.protocolNumber : null;
	this.status = dto ? VideoDownloadRequestStatus.getById(dto.statusId) : null;
	this.isDownloading = ko.observable(false);
	
	this.formattedInspectionStartTime = function() {
		return self.inspectionStartTime ? self.inspectionStartTime.format(momentDateFormat) : "";
	}();
	
	this.formattedRequestedAtTime = function() {
		return self.requestedAt ? self.requestedAt.format(momentDateFormat) : "";
	}();
};