namespace("demax.inspections.model.techinsp");

demax.inspections.model.techinsp.VideoDownloadRequestSearchFilters = function(dto) {
	var self = this;
	var lastUsedFilters = null;
	
	this.ktpNum = ko.observable(dto ? ko.unwrap(dto.ktpNum) : null);
	this.regNum = ko.observable(dto ? ko.unwrap(dto.regNum) : null);
	this.protocolNum = ko.observable(dto ? ko.unwrap(dto.protocolNum) : null);
	this.hologramNum = ko.observable(dto ? ko.unwrap(dto.hologramNum) : null);
	this.orgUnit = ko.observable(dto ? ko.unwrap(dto.orgUnit) : null);
	this.status = ko.observable(dto ? ko.unwrap(dto.status) : null);
	
	this.toQueryParams = function() {
		var dto = {};
		
		if (self.ktpNum()) {
			var ktpNum = self.ktpNum().trim();
		}

		if (self.regNum()) {
			var regNum = self.regNum().trim();
		}

		if (self.protocolNum()) {
			var protocolNum = self.protocolNum().trim();
		}

		if (self.hologramNum()) {
			var hologramNum = self.hologramNum().trim();
		}
		
		var orgUnit = self.orgUnit();
		var status = self.status();
		
		if (ktpNum !== null && ktpNum !== undefined) {
			dto.ktpNum = ktpNum;
		}
		
		if (regNum !== null && regNum !== undefined) {
			dto.regNum = regNum;
		}
		
		if (protocolNum !== null && protocolNum !== undefined) {
			dto.protocolNum = protocolNum;
		}

		if (hologramNum !== null && hologramNum !== undefined) {
			dto.hologramNum = hologramNum;
		}
		
		if (orgUnit !== null && orgUnit !== undefined) {
			dto.orgUnitCode = orgUnit.code;
		}
		
		if (status !== null && status !== undefined) {
			dto.statusId = status.id;
		}
		
		return dto;
	};
	
	this.saveLastUsedFilters = function() {
		lastUsedFilters = {
			ktpNum: self.ktpNum(),
			regNum: self.regNum(),
			protocolNum: self.protocolNum(),
			hologramNum: self.hologramNum(),
			orgUnit: self.orgUnit(),
			status: self.status()
		};
	};
	
	this.loadLastUsedFilters = function() {
		if (lastUsedFilters) {
			self.ktpNum(lastUsedFilters.ktpNum);
			self.regNum(lastUsedFilters.regNum);
			self.protocolNum(lastUsedFilters.protocolNum);
			self.hologramNum(lastUsedFilters.hologramNum);
			self.orgUnit(lastUsedFilters.orgUnit);
			self.status(lastUsedFilters.status);
		} else {
			self.clear();
		}
	};

	this.getLastUsedFilters = function() {
		return lastUsedFilters;
	};
	
	this.clear = function() {
		self.ktpNum(null);
		self.regNum(null);
		self.protocolNum(null);
		self.hologramNum(null);
		self.orgUnit(null);
		self.status(null);
	};
};