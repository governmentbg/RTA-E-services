namespace("demax.inspections.model.techinsp.messages");

demax.inspections.model.techinsp.messages.MessageAttachment = function(dto) {

	this.id = dto ? dto.id : null;
	this.mimeType = dto ? dto.mimeType : null;
	this.filename = dto ? dto.filename : null;
};
