namespace("demax.inspections.model.techinsp.messages");

demax.inspections.model.techinsp.messages.MessageListItem = function(dto) {
	var self = this;

	this.id = dto ? dto.id : null;
	this.sender = dto ? dto.sender : null;
	this.recipient = dto ? dto.recipient : null;
	this.statusCode = dto ? dto.statusCode : null;
	this.createdAt = dto && dto.createdAt ? moment.fromJacksonDateTimeArray(dto.createdAt) : null;
	this.sentAt = dto && dto.sentAt ? moment.fromJacksonDateTimeArray(dto.sentAt) : null;
	this.body = dto ? new demax.inspections.model.techinsp.messages.MessageListItemBody(dto.body) : null;
	this.attachments = ko.observableArray(dto && dto.attachments ? ko.utils.arrayMap(dto.attachments, function(attachmentDto) {
		return new demax.inspections.model.techinsp.messages.MessageAttachment(attachmentDto);
	}) : []);
	this.permits = dto && dto.permits ? dto.permits : [];

	this.recipientText = (function() {
		if (self.recipient && self.recipient.type == "ALL") {
			return "Всички";
		} else if (self.recipient && self.recipient.type == "PERMIT") {
			return getPermitsText();
		} else {
			return self.recipient.subject;
		}
	})();

	this.recipientShortText = (function() {
		if (self.recipient && self.recipient.type == "ALL") {
			return "Всички";
		} else if (self.recipient && self.recipient.type == "PERMIT") {
			return getPermitsText();
		} else {
			var commaIndex = self.recipient.subject.indexOf(",");
			if (commaIndex > -1) {
				return self.recipient.subject.substring(0, self.recipient.subject.indexOf(","));
			} else {
				return self.recipient.subject;
			}
		}
	})();

	function getPermitsText() {
		var text = "КТП " + self.permits[0].number;

		for (var i = 1; i < self.permits.length; i++) {
			text += ", КТП " + self.permits[i].number;
		}

		return text;
	}
};
