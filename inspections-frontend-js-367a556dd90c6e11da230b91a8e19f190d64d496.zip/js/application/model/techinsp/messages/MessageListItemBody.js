namespace("demax.inspections.model.techinsp.messages");

demax.inspections.model.techinsp.messages.MessageListItemBody = function(dto) {

	this.subject = dto ? dto.subject : null;
	this.body = dto ? dto.body : null;
};
