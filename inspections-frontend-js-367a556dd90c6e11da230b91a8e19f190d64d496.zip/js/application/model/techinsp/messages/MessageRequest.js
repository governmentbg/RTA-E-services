namespace("demax.inspections.model.techinsp.messages");

demax.inspections.model.techinsp.messages.MessageRequest = function(dto) {
	var self = this;

	this.id = ko.observable(dto ? dto.id : null);
	this.sender = ko.observable(dto ? dto.sender : null);
	this.statusCode = ko.observable(dto ? dto.statusCode : null);
	this.orgUnitCode = ko.observable(dto && dto.recipient && dto.recipient.type === "ORG_UNIT" ? dto.recipient.orgUnitCode : null);
	this.permits = ko.observableArray(dto && dto.recipient && dto.recipient.type === "PERMIT" ? dto.permits : []);
	this.body = ko.observable(new demax.inspections.model.techinsp.messages.MessageRequestBody(dto ? dto.body : null));
	this.attachments = ko.observableArray(dto && dto.attachments ? ko.utils.arrayMap(dto.attachments, function(attachmentDto) {
		return new demax.inspections.model.techinsp.messages.MessageAttachment(attachmentDto);
	}) : []);

	this.setFromDto = function(dto) {
		if (dto) {
			self.id(dto.id);
			self.sender(dto.sender);
			self.statusCode(dto.statusCode);
			self.permits(dto.recipient && dto.recipient.type === "PERMIT" ? dto.permits : []);
			self.orgUnitCode(dto.recipient && dto.recipient.type === "ORG_UNIT" ? dto.recipient.orgUnitCode : null);
			ko.unwrap(self.body).setFromDto(dto.body);
			self.attachments(dto && dto.attachments ? dto.attachments : []);
		}
	};

	this.toDto = function() {
		var recipientType = null;
		if (ko.unwrap(self.permits) != null && ko.unwrap(self.permits != undefined) && self.permits().length > 0) {
			recipientType = "PERMIT";
		} else if (ko.unwrap(self.orgUnitCode) != null && ko.unwrap(self.orgUnitCode) != undefined) {
			recipientType = "ORG_UNIT";
		} else {
			recipientType = "ALL";
		}
		
		var attachmentIds = [];
		$.each(ko.unwrap(self.attachments), function(i, attachment) {
			attachmentIds.push(attachment.id);
		});

		return {
			recipientType: recipientType,
			sender: ko.unwrap(self.sender),
			orgUnitCode: ko.unwrap(self.orgUnitCode),
			permitIds: ko.unwrap(self.permits).map(function(permit) { 
				return permit.id; 
			}),
			body:  ko.unwrap(self.body).toDto(),
			attachmentIds: attachmentIds
		};
	};
};
