namespace("demax.inspections.model.techinsp.messages");

demax.inspections.model.techinsp.messages.MessageRequestBody = function(dto) {
	var self = this;

	this.subject = ko.observable(dto ? dto.subject : null);
	this.body = ko.observable(dto ? dto.body : null);

	this.setFromDto = function(dto) {
		if (dto) {
			self.subject(dto.subject);
			self.body(dto.body);
		}
	};

	this.toDto = function() {
		return {
			subject: ko.unwrap(self.subject),
			body: ko.unwrap(self.body)
		};
	};
};
