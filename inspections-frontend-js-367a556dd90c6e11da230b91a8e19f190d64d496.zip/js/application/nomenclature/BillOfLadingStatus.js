namespace("demax.inspections.nomenclature");

demax.inspections.nomenclature.BillOfLadingStatus = {
	REQUESTED: {
		code: "REQUESTED",
		displayText: "празна",
		cssClass: "label-info"
	},

	NOT_SENT: {
		code: "NOT_SENT",
		displayText: "неизпратена",
		cssClass: "label-warning"
	},

	SENT: {
		code: "SENT",
		displayText: "изпратена",
		cssClass: "label-success"
	},

	EXPIRED: {
		code: "EXPIRED",
		displayText: "изтекла",
		cssClass: "label-default"
	},

	CANCELED: {
		code: "CANCELED",
		displayText: "отказана",
		cssClass: "label-danger"
	},

	get WITHOUT_REQUESTED() {
		return [this.NOT_SENT, this.SENT, this.EXPIRED, this.CANCELED];
	}
};
