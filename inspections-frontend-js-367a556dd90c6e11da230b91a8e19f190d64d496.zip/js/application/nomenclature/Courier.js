namespace("demax.inspections.nomenclature");

demax.inspections.nomenclature.Courier = {
	SPEEDY: {
		code: "SPEEDY",
		displayText: "Спиди",
		cssClass: "speedy",
		serviceTypes: [
			demax.inspections.nomenclature.CourierServiceType.STANDARD,
			demax.inspections.nomenclature.CourierServiceType.EXPRESS
		],
		deliveryTypes: [
			demax.inspections.nomenclature.CourierDeliveryType.DOOR_TO_DOOR,
			demax.inspections.nomenclature.CourierDeliveryType.DOOR_TO_OFFICE
		]
	},

	ECONT: {
		code: "ECONT",
		displayText: "Еконт",
		cssClass: "ekont",
		serviceTypes: [demax.inspections.nomenclature.CourierServiceType.STANDARD],
		deliveryTypes: [
			demax.inspections.nomenclature.CourierDeliveryType.DOOR_TO_DOOR
		]
	},
	DEMAX: {
		code: "DEMAX",
		displayText: "Собствен транспорт",
		cssClass: "demax",
		serviceTypes: [demax.inspections.nomenclature.CourierServiceType.STANDARD],
		deliveryTypes: [demax.inspections.nomenclature.CourierDeliveryType.DOOR_TO_DOOR]
	}
};
