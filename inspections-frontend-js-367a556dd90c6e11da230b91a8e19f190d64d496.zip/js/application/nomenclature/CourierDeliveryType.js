namespace("demax.inspections.nomenclature");

demax.inspections.nomenclature.CourierDeliveryType = {
	DOOR_TO_DOOR: {
		code: "DOOR_TO_DOOR",
		displayText: "До адрес"
	},
	DOOR_TO_OFFICE: {
		code: "DOOR_TO_OFFICE",
		displayText: "До офис на куриер"
	}
};
