namespace("demax.inspections.nomenclature");

demax.inspections.nomenclature.CourierServiceType = {
	STANDARD: {
		code: "STANDARD",
		displayText: "Стандартна"
	},

	EXPRESS: {
		code: "EXPRESS",
		displayText: "Експресна"
	}
};
