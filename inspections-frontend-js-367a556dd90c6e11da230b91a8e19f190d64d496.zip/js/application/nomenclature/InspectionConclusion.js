namespace("demax.inspections.nomenclature");

demax.inspections.nomenclature.InspectionConclusion = {
	IA: {
		code: "IA",
		description: "Допуска се за движение"
	},
	TA: {
		code: "TA",
		description: "Временно се допуска за движение"
	},
	NA: {
		code: "NA",
		description: "Не се допуска за движение"
	},

	ALL: function() {
		return [this.IA, this.TA, this.NA];
	},

	getByCode: function(code) {
		var conclusion = null;
		for (var key in this) {
			if (this[key].code == code) {
				conclusion = this[key];
				break;
			}
		}
		return conclusion;
	}
};
