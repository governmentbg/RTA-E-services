namespace("demax.inspections.nomenclature");

demax.inspections.nomenclature.InspectionStatus = {
	INPROGRESS: {
		code: "INPROGRESS",
		description: "В процес"
	},
	COMPLETED: {
		code: "COMPLETED",
		description: "Приключен със заключение"
	},
	INVALID: {
		code: "INVALID",
		description: "Невалиден"
	},
	STOPPED: {
		code: "STOPPED",
		description: "Спрян"
	},
	DAYS14: {
		code: "DAYS14",
		description: "Приключен с възможност за продължение"
	},

	ALL: function() {
		return [this.INPROGRESS, this.COMPLETED, this.INVALID, this.STOPPED, this.DAYS14];
	},

	getByCode: function(code) {
		var status = null;
		for (var key in this) {
			if (this[key].code == code) {
				status = this[key];
				break;
			}
		}
		return status;
	}
};
