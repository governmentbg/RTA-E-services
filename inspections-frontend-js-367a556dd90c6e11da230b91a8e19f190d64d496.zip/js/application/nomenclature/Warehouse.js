namespace("demax.inspections.nomenclature");

(function() {
	var Courier = demax.inspections.nomenclature.Courier;

	demax.inspections.nomenclature.Warehouse = {
		1: {
			id: 1,
			name: "София Кремиковци",
			disabledCouriers: [Courier.SPEEDY, Courier.ECONT]
		},
		2: {
			id: 2,
			name: "София Цариградско шосе голям склад",
			disabledCouriers: []
		},
		3: {
			id: 3,
			name: "София Цариградско шосе малък склад",
			disabledCouriers: []
		},
		4: {
			id: 4,
			name: "Бургас",
			disabledCouriers: []
		},
		5: {
			id: 5,
			name: "Варна",
			disabledCouriers: []
		},
		6: {
			id: 6,
			name: "Враца",
			disabledCouriers: []
		},
		7: {
			id: 7,
			name: "Плевен",
			disabledCouriers: []
		},
		8: {
			id: 8,
			name: "Пловдив",
			disabledCouriers: []
		},
		9: {
			id: 9,
			name: "Стара Загора",
			disabledCouriers: []
		},
		10: {
			id: 10,
			name: "Благоевград",
			disabledCouriers: []
		},
		11: {
			id: 11,
			name: "София СИСКОМ 4-ти км",
			disabledCouriers: [Courier.SPEEDY, Courier.ECONT]
		},

		get AVAILABLE_WHEN_CREATING_HARDWARE() {
			return [this[2], this[3]];
		},

		get POSSIBLE_HARDWARE_RECEIVERS() {
			return [this[1], this[11], this[4], this[5], this[6], this[7], this[8], this[9], this[10]];
		},

		get ALL() {
			return [this[1], this[11], this[2], this[3], this[4], this[5], this[6], this[7], this[8], this[9], this[10]];
		}
	};
})();
