namespace("demax.inspections.nomenclature.equipment.consumable");

demax.inspections.nomenclature.equipment.consumable.PrinterConsumableStatus = {
	SENT: {
		code: "SENT",
		displayText: "Изпратен",
		labelCssClasses: "label label-default"
	},
	INSTALLED: {
		code: "INSTALLED",
		displayText: "Инсталиран",
		labelCssClasses: "label label-success"
	},
	REPORTED: {
		code: "REPORTED",
		displayText: "Отчетен",
		labelCssClasses: "label label-info"
	},
	RETURNED: {
		code: "RETURNED",
		displayText: "Върнат",
		labelCssClasses: "label label-primary"
	},

	get ALL() {
		return [this.SENT, this.INSTALLED, this.REPORTED, this.RETURNED];
	},

	getByCode: function(code) {
		var foundStatus = null;
		$.each(demax.inspections.nomenclature.equipment.consumable.PrinterConsumableStatus.ALL, function(i, status) {
			if (status.code == code) {
				foundStatus = status;
				return false;
			}
		});
		return foundStatus;
	}
};
