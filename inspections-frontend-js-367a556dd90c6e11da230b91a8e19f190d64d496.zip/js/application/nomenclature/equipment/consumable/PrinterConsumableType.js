namespace("demax.inspections.nomenclature.equipment.consumable");

demax.inspections.nomenclature.equipment.consumable.PrinterConsumableType = {
	CARTRIDGE: {
		code: "CARTRIDGE",
		displayText: "Тонер"
	},
	DRUM: {
		code: "DRUM",
		displayText: "Барабан"
	},

	get ALL() {
		return [this.CARTRIDGE, this.DRUM];
	},

	getByCode: function(code) {
		var foundType = null;
		$.each(demax.inspections.nomenclature.equipment.consumable.PrinterConsumableType.ALL, function(i, type) {
			if (type.code == code) {
				foundType = type;
				return false;
			}
		});
		return foundType;
	}
};
