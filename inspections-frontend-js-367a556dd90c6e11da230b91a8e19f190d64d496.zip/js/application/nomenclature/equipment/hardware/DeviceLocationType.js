namespace("demax.inspections.nomenclature.equipment.hardware");

demax.inspections.nomenclature.equipment.hardware.DeviceLocationType = {
	WAREHOUSE: { 
		code: "WAREHOUSE", 
		name: "Склад"
	},
	INSPECTION_POINT: { 
		code: "INSPECTION_POINT",
		name: "Пункт за прегледи"
	}
};
