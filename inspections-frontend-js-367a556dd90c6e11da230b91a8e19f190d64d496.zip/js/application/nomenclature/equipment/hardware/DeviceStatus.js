namespace("demax.inspections.nomenclature.equipment.hardware");

demax.inspections.nomenclature.equipment.hardware.DeviceStatus = {
	NEW: {
		id: 1,
		name: "new",
		bgName: "Ново",
		cssLabelClasses: "label label-success"
	},
	AVAILABLE: {
		id: 2,
		name: "available",
		bgName: "Налично",
		cssLabelClasses: "label label-info"
	},
	SCRAPPED: {
		id: 3,
		name: "scrapped",
		bgName: "Бракувано",
		cssLabelClasses: "label label-default"
	},
	FOR_REPAIR: {
		id: 4,
		name: "for_repair",
		bgName: "За ремонт",
		cssLabelClasses: "label label-warning"
	},

	STOLEN: {
		id: 5,
		name: "stolen",
		bgName: "Откраднато",
		cssLabelClasses: "label label-danger"
	},

	get EDITABLE_STATUSES_WHEN_IN_FOR_REPAIR() {
		return [this.AVAILABLE, this.SCRAPPED];
	},

	get EDITABLE_STATUSES_WHEN_IN_AVAILABLE() {
		return [this.AVAILABLE, this.FOR_REPAIR, this.SCRAPPED, this.STOLEN];
	},

	getById: function(statusId) {
		if (statusId == this.NEW.id) {
			return this.NEW;
		} else if (statusId == this.AVAILABLE.id) {
			return this.AVAILABLE;
		} else if (statusId == this.SCRAPPED.id) {
			return this.SCRAPPED;
		} else if (statusId == this.FOR_REPAIR.id) {
			return this.FOR_REPAIR;
		} else if (statusId == this.STOLEN.id) {
			return this.STOLEN;
		}
		return null;
	},

	get ALL() {
		return [this.NEW, this.AVAILABLE, this.SCRAPPED, this.FOR_REPAIR, this.STOLEN];
	}
};
