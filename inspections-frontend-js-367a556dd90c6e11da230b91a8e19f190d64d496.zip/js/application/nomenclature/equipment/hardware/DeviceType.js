namespace("demax.inspections.nomenclature.equipment.hardware");

demax.inspections.nomenclature.equipment.hardware.DeviceType = {
	DELL_COMPUTER: {
		code: 6,
		description: "DELL компютър прегледи",
		hasIpAddress: true
	},
	LTE_4G_MODEM: {
		code: 10,
		description: "4G LTE модем",
		hasIpAddress: false
	},
	WIFI_ADDAPTER: {
		code: 11,
		description: "WiFi адаптер",
		hasIpAddress: false
	},
	SCANNER_THEORETICAL_EXAMS: {
		code: 15,
		description: "Скенер листовки",
		hasIpAddress: false
	},
	IP_CAMERA_INSPECTIONS: {
		code: 16,
		description: "IP камера",
		hasIpAddress: false,
		hasMacAddress: true
	},
	XEROX_PRINTER_INSPECTIONS: {
		code: 21,
		description: "Xerox принтер прегледи",
		hasIpAddress: false
	},
	XEROX_PRINTER_FIXED_CODE: {
		code: 86,
		description: "Xerox принтер прегледи ремонтиран",
		hasIpAddress: false
	},
	DELL_MONITOR_INSPECTIONS: {
		code: 26,
		description: "Dell Монитор прегледи",
		hasIpAddress: false
	},
	DELL_COMPUTER_MOUSE: {
		code: 27,
		description: "DELL компютърна мишка",
		hasIpAddress: false
	},
	DELL_COMPUTER_KEYBOARD: {
		code: 28,
		description: "DELL компютърна клавиатура",
		hasIpAddress: false
	},
	VIVACOM_SDSL: {
		code: 35,
		description: "VIVACOM SDSL",
		hasIpAddress: true
	},
	VIVACOM_3G_MODEM: {
		code: 40,
		description: "VIVACOM 3G модем",
		hasIpAddress: false
	},
	VIVACOM_3G_MODEM_A: {
		code: 45,
		description: "VIVACOM 3G модем (VA)",
		hasIpAddress: false
	},
	GLOBUL_3G_MODEM: {
		code: 50,
		description: "GLOBUL 3G модем",
		hasIpAddress: false
	},
	VIVACOM_SIM_CARD: {
		code: 55,
		description: "VIVACOM SIM карта",
		hasIpAddress: true,
		hasMsisdn: true,
		hasImsi: true
	},
	GLOBUL_SIM_CARD: {
		code: 60,
		description: "GLOBUL SIM карта",
		hasIpAddress: true,
		hasMsisdn: true,
		hasImsi: true
	},
	SATELLITE_MODEM: {
		code: 65,
		description: "Сателитен модем (VIVACOM Tooway)",
		hasIpAddress: true
	},
	ROUTER: {
		code: 70,
		description: "Рутер (TP-Link TL-WR1043ND)",
		hasIpAddress: false
	},
	COMMUTATOR: {
		code: 71,
		description: "Комутатор (TP_link_TL_SF1005D)",
		hasIpAddress: false
	},
	LAN_CARD: {
		code: 75,
		description: "LAN Card (D-LINK DGE-528T)",
		hasIpAddress: true
	},
	SATELLITE_CONVERTER: {
		code: 80,
		description: "Сателитен конвертор (VIVACOM Tooway)",
		hasIpAddress: false
	},
	GLOBUL_3G_MODEM_A: {
		code: 85,
		description: "GLOBUL 3G модем (GA)",
		hasIpAddress: false
	},

	get ALL() {
		var values = [];
		for (var key in this) {
			if (key != "ALL" && key != "ALLOWED_FOR_CREATION" && key != "getByCode") {
				values.push(this[key]);
			}
		}
		return values;
	},

	get ALLOWED_FOR_CREATION() {
		var values = [];
		for (var key in this) {
			if (key != "ALL" && key != "ALLOWED_FOR_CREATION" && key != "getByCode" && key != "BRIEFCASE_COMPUTER") {
				values.push(this[key]);
			}
		}
		return values;
	},

	getByCode: function(deviceTypeCode) {
		var deviceType = null;
		for (var key in this) {
			if (this[key].code == deviceTypeCode) {
				deviceType = this[key];
				break;
			}
		}
		return deviceType;
	}
};
