namespace("demax.inspections.nomenclature.logs");

demax.inspections.nomenclature.logs.LogObjectType = {
	PERMITS: { code: "permits", description: "Разрешителни" },
	INSPECTORS: { code: "permit_inspectors", description: "Специалисти" },
	LINES: { code: "permit_lines", description: "Линии" },

	get ALL() {
		return [this.PERMITS, this.INSPECTORS, this.LINES];
	}
};
