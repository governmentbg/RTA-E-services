namespace("demax.inspections.nomenclature.permits");

demax.inspections.nomenclature.logs.LogQueryType = {
	NEW: { code: "INSERT", description: "Нови" },
	UPDATED: { code: "UPDATE", description: "Променени" },

	get ALL() {
		return [this.NEW, this.UPDATED];
	}
};
