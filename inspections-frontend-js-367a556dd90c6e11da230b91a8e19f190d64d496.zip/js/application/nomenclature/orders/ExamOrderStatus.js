namespace("demax.inspections.nomenclature.orders");

(function() {
	var Role = demax.inspections.nomenclature.Role;
	demax.inspections.nomenclature.orders.ExamOrderStatus = {

		//exists in db but probably is a mistake there
		/*ACTIVATED: {*/
		//code: "ACTIVATED",
		//displayText: "активирана",
		//cssClass: "label-success",
		//stage: 7
		/*},*/

		ISSUED: {
			code: "ISSUED",
			displayText: "заявена",
			cssClass: "label-info",
			stage: 1,
			access: [Role.ACCOUNTING, Role.CALL_CENTER]
		},

		PAID: {
			code: "PAID",
			displayText: "платена",
			cssClass: "label-primary",
			stage: 3,
			access: [Role.ACCOUNTING, Role.CALL_CENTER, Role.SUPERVISOR, Role.PACKAGING_VOUCHERS]
		},

		SEND: {
			code: "SEND",
			displayText: "изпратена",
			cssClass: "label-success",
			stage: 5,
			access: [Role.ACCOUNTING, Role.CALL_CENTER, Role.SUPERVISOR, Role.PACKAGING_VOUCHERS]
		},
			
		//unlike InspectionOrderStatus.CANCELLED this one is used
		CANCELED: {
			code: "CANCELED",
			displayText: "отказана",
			cssClass: "label-default",
			stage: -1,
			access: [Role.ACCOUNTING, Role.CALL_CENTER]
		}

		//exists in db but is never used
		/*CREATED: {*/
		//code: "CREATED",
		//displayText: "създадена",
		//cssClass: "label-info",
		//stage: 0
		/*},*/

		//exists in db but is probably never used
		/*DELIVERED: {*/
		//code: "DELIVERED",
		//displayText: "доставена",
		//cssClass: "label-primary",
		//stage: 6
		/*},*/

		//exists in db but is probably never used
		/*IN_PROGRESS: {*/
		//code: "IN_PROGRESS",
		//displayText: "обработва се",
		//cssClass: "label-warning",
		//stage: 2
		/*},*/

		
	};
})();
