namespace("demax.inspections.nomenclature.orders");

(function() {
	var Role = demax.inspections.nomenclature.Role;
	demax.inspections.nomenclature.orders.InspectionOrderStatus = {
		
		ISSUED: {
			code: "ISSUED",
			displayText: "заявена",
			cssClass: "label label-info",
			stage: 1,
			access: [Role.ACCOUNTING, Role.CALL_CENTER]
		},
		
		PAID: {
			code: "PAID",
			displayText: "платена",
			cssClass: "label label-primary",
			stage: 3,
			access: [Role.ACCOUNTING, Role.CALL_CENTER, Role.SUPERVISOR, Role.PACKAGING_INSPECTIONS]
		},
		
		PRINT_LABEL: {
			code: "PRINT_LABEL",
			displayText: "етикет",
			cssClass: "label label-warning",
			stage: 4,
			access: [Role.ACCOUNTING, Role.CALL_CENTER, Role.SUPERVISOR, Role.PACKAGING_INSPECTIONS]
		},
		
		SEND: {
			code: "SEND",
			displayText: "изпратена",
			cssClass: "label label-light-green",
			stage: 5,
			access: [Role.ACCOUNTING, Role.CALL_CENTER, Role.SUPERVISOR, Role.PACKAGING_INSPECTIONS]
		},
		
		ACTIVATED: {
			code: "ACTIVATED",
			displayText: "активирана",
			cssClass: "label label-success",
			stage: 7,
			access: [Role.ACCOUNTING, Role.PACKAGING_INSPECTIONS, Role.CALL_CENTER, Role.SUPERVISOR]
		},

		get EVERY_STATUS() {
			return [this.ISSUED, this.PAID, this.PRINT_LABEL, this.SEND, this.ACTIVATED];
		},

		getByCode: function(code) {
			var foundStatus = null;
			this.EVERY_STATUS.forEach(function(status) {
				if (status.code === code) {
					foundStatus = status;
					return false;
				}
			});
			return foundStatus;
		},

		getNullStatus: function() {
			return {
				code: "",
				displayText: "-",
				cssClass: ""
			};
		}

		//exists in db but is never used
		/*CANCELED: {*/
		//code: "CANCELLED",
		//displayText: "отказана",
		//cssClass: "label-danger",
		//stage: -1
		/*},*/

		//exists in db but is probably never used
		/*CREATED: {*/
		//code: "CREATED",
		//displayText: "създадена",
		//cssClass: "label-info",
		//stage: 0
		/*},*/

		//exists in db but probably never used
		/*DELIVERED: {*/
		//code: "DELIVERED",
		//displayText: "доставена",
		//cssClass: "label-primary",
		//stage: 6
		/*},*/

		//exist in db but probably never used
		/*IN_PROGRESS: {*/
		//code: "IN_PROGRESS",
		//displayText: "обработва се",
		//cssClass: "label-warning",
		//stage: 2
		/*},*/
		
	};
})();
