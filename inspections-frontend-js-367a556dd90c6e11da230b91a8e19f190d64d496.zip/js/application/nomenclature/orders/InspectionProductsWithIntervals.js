namespace("demax.inspections.nomenclature.orders");

demax.inspections.nomenclature.orders.InspectionProductsWithIntervals = [
	905,
	904,
	912,
	903
];
