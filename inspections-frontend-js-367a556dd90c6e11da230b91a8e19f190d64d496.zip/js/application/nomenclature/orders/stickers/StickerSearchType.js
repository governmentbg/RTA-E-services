namespace("demax.inspections.nomenclature.orders.stickers");

demax.inspections.nomenclature.orders.stickers.StickerSearchType = {

	PERMIT_NUMBER: {
		code: "PERMIT_NUMBER",
		name: "Разрешение №"
	},
	ORDER_NUMBER: {
		code: "ORDER_NUMBER",
		name: "Поръчка №"
	},
	STICKER_NUMBER: {
		code: "STICKER_NUMBER",
		name: "Стикер №"
	},

	get ALL() {
		return [this.PERMIT_NUMBER, this.ORDER_NUMBER, this.STICKER_NUMBER];
	},

	getByCode: function(code) {
		var foundItem = null;
		this.ALL.forEach(function (item) {
			if (item.code === code) {
				foundItem = item;
				return false;
			}
		});
		return foundItem;
	}
};