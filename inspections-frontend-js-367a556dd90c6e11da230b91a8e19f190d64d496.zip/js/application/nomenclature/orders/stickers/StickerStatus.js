namespace("demax.inspections.nomenclature.orders.stickers");

demax.inspections.nomenclature.orders.stickers.StickerStatus = {
	ALL: [
		{ code: "ACTIVATED", name: "активиран" },
		{ code: "USED", name: "използван" },
		{ code: "SCRAPPED", name: "бракуван" }
	]
};
