namespace("demax.inspections.nomenclature.permits");

demax.inspections.nomenclature.permits.ChangeCodes = {

	// Permit
	PERMIT_CHANGE_CITY: {
		code: "PERMIT_CHANGE_CITY",
		text: "Редактиран е град от \"{oldValue}\" към \"{newValue}\"."
	},
	PERMIT_CHANGE_ADDRESS: {
		code: "PERMIT_CHANGE_ADDRESS",
		text: "Редактиран е адрес от \"{oldValue}\" към \"{newValue}\"."
	},
	PERMIT_CHANGE_REISSUE_APPLICATION_DATE: {
		code: "PERMIT_CHANGE_REISSUE_APPLICATION_DATE",
		text: "Добавена дата на заявление за преиздаване \"{newValue}\"."
	},
	PERMIT_CHANGE_REISSUE_APPLICATION_NUMBER: {
		code: "PERMIT_CHANGE_REISSUE_APPLICATION_NUMBER",
		text: "Добавен номер на заявление за преиздаване \"{newValue}\"."
	},
	PERMIT_CHANGE_REISSUE_VALID_TO: {
		code: "PERMIT_CHANGE_REISSUE_VALID_TO",
		text: "Редактирана валидност от \"{oldValue}\" към \"{newValue}\" поради преиздаване."
	},
	PERMIT_CHANGE_REVOKE_DATE: {
		code: "PERMIT_CHANGE_REVOKE_DATE",
		text: "Добавена дата на отнемане \"{newValue}\"."
	},
	PERMIT_CHANGE_CLOSE_DATE: {
		code: "PERMIT_CHANGE_CLOSE_DATE",
		text: "Добавена дата на закриване \"{newValue}\"."
	},
	PERMIT_CHANGE_REVOKE_REASON: {
		code: "PERMIT_CHANGE_REVOKE_REASON",
		text: "Добавена причина за отнемане \"{newValue}\"."
	},
	PERMIT_CHANGE_CLOSE_APPLICATION_NUMBER: {
		code: "PERMIT_CHANGE_REVOKE_REASON",
		text: "Добавен номер на заявление за закриване \"{newValue}\"."
	},
	PERMIT_CHANGE_STATUS_CHANGE: {
		code: "PERMIT_CHANGE_STATUS_CHANGE",
		text: "Добавено е искане за промяна на статус към \"{newValue}\"."
	},
	PERMIT_CHANGE_COMPANY: {
		code: "PERMIT_CHANGE_COMPANY",
		text: "Променена е фирма - ЕИК на предишна фирма: {oldValue}, ЕИК на нова фирма: {newValue}",
		textIfMissingInfo: "Намерени са промени в данните за фирма."
	},


	PERMIT_INSPECTOR_ADD: {
		code: "PERMIT_INSPECTOR_ADD",
		text: "Добавен е нов инспектор с ЕГН {newValue}"
	},
	PERMIT_LINE_ADD: {
		code: "PERMIT_LINE_ADD",
		text: "Добавена е нова линия с номер {additionalId}"
	},
	PERMIT_INSPECTION_ADD: {
		code: "PERMIT_INSPECTION_ADD",
		text: "Добавен е нов оглед с номер на протокол {newValue}"
	},

	PERMIT_DOCUMENT_ADD: {
		code: "PERMIT_DOCUMENT_ADD",
		text: "Добавен е нов документ \"{additionalInfo}\" с номер {newValue}"
	},
	PERMIT_DOCUMENT_EDIT_STATUS: {
		code: "PERMIT_DOCUMENT_EDIT_STATUS",
		text: "Редактирана е статус на документ номер {additionalId} от \"{oldValue}\" към \"{newValue}\", тип \"{additionalInfo}\"."
	},

	// Permit Inspectors
	PERMIT_INSPECTOR_EDIT_STATUS: {
		code: "PERMIT_INSPECTOR_EDIT_STATUS",
		text: "Редактиран е статус на специалист {additionalInfo} с ЕГН {additionalId} от \"{oldValue}\" към \"{newValue}\"."
	},

	PERMIT_INSPECTOR_EDIT_ORDER_NUMBER: {
		code: "PERMIT_INSPECTOR_EDIT_ORDER_NUMBER",
		text: "Редактиран е пореден номер на специалист {additionalInfo} с ЕГН {additionalId} от \"{oldValue}\" към \"{newValue}\"."
	},

	PERMIT_INSPECTOR_EDIT_IS_CHAIRMAN: {
		code: "PERMIT_INSPECTOR_EDIT_IS_CHAIRMAN",
		text: "Редактиран е статус 'ПРЕДСЕДАТЕЛ' на специалист {additionalInfo} с ЕГН {additionalId} от \"{oldValue}\" към \"{newValue}\"."
	},

	PERMIT_INSPECTOR_EDIT_SPECIALITY: {
		code: "PERMIT_INSPECTOR_EDIT_SPECIALITY",
		text: "Редактирана е специалност на специалист {additionalInfo} с ЕГН {additionalId} от \"{oldValue}\" към \"{newValue}\"."
	},

	PERMIT_INSPECTOR_EDIT_REMARKS: {
		code: "PERMIT_INSPECTOR_EDIT_REMARKS",
		text: "Редактирани са бележки към специалист {additionalInfo} с ЕГН {additionalId} от \"{oldValue}\" към \"{newValue}\"."
	},

	// Permit Inspector Documents
	PERMIT_INSPECTOR_EDIT_DOCUMENT_STATUS: {
		code: "PERMIT_INSPECTOR_EDIT_DOCUMENT_STATUS",
		text: "Редактиран е документ към специалист {additionalInfo} с ЕГН {additionalId} от статус \"{oldValue}\" към \"{newValue}\"."
	},

	PERMIT_INSPECTOR_ADD_DOCUMENT: {
		code: "PERMIT_INSPECTOR_ADD_DOCUMENT",
		text: "Добавен е нов документ с номер {newValue} към специалист {additionalInfo} с ЕГН {additionalId}."
	},

	PERMIT_INSPECTOR_ADD_CERTIFICATION: {
		code: "PERMIT_INSPECTOR_ADD_CERTIFICATION",
		text: "Добавено ново удостоверение с номер: {newValue}."
	},

	PERMIT_INSPECTOR_REMOVE_CERTIFICATION: {
		code: "PERMIT_INSPECTOR_REMOVE_CERTIFICATION",
		text: "Премахнато удостовение с номер: {newValue}."
	},

	// Permit Lines
	PERMIT_LINE_EDIT_CATEGORY: {
		code: "PERMIT_LINE_EDIT_CATEGORY",
		text: "Променени са категории към линия номер {additionalId}."
	},

	PERMIT_LINE_EDIT_DOCUMENT: {
		code: "PERMIT_LINE_EDIT_DOCUMENT",
		text: "Променени са документи към линия номер {additionalId}."
	},

	PERMIT_LINE_ADD_DOCUMENT: {
		code: "PERMIT_LINE_ADD_DOCUMENT",
		text: "Добавен е документ към линия номер {additionalId}."
	},

	PERMIT_LINE_DELETE: {
		code: "PERMIT_LINE_DELETE",
		text: "Добавен е документ към линия номер {additionalId}."
	},

	getText: function (code, data) {
		var text = this[code].text;

		// If Company info change, show generic text
		if (code === this.PERMIT_CHANGE_COMPANY.code && !data["oldValue"]) {
			text = this[code].textIfMissingInfo;
		}

		var newValue = "-";
		var oldValue = "-";
		var additionalId = "-";
		var additionalInfo = "-";

		if (data["newValue"]) {
			var dataContent = data["newValue"];

			if (dataContent === "true") {
				dataContent = "ДА";
			} else if (dataContent === "false") {
				dataContent = "НЕ";
			} else if (dataContent === "И" || dataContent === "В") {
				dataContent = this.getInspectorStatus(dataContent);
			}

			newValue = dataContent;
		}

		if (data["oldValue"]) {
			var dataContent2 = data["oldValue"];

			if (dataContent2 === "true") {
				dataContent2 = "ДА";
			} else if (dataContent2 === "false") {
				dataContent2 = "НЕ";
			} else if (dataContent2 === "И" || dataContent2 === "В") {
				dataContent2 = this.getInspectorStatus(dataContent2);
			}

			oldValue = dataContent2;
		}

		if (data["additionalInfo"]) {
			additionalInfo = data["additionalInfo"];
		}

		if (data["additionalId"]) {
			additionalId = data["additionalId"];
		}

		return text
			.replace("{newValue}", newValue)
			.replace("{oldValue}", oldValue)
			.replace("{additionalInfo}", additionalInfo)
			.replace("{additionalId}", additionalId);
	},

	getInspectorStatus: function (code) {
		return demax.inspections.nomenclature.permits.PermitInspectorStatus.getByCode(code).text;
	}

};