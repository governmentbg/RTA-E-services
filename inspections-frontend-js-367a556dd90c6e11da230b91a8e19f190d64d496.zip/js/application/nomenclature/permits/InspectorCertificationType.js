namespace("demax.inspections.nomenclature.permits");

demax.inspections.nomenclature.permits.InspectorCertificationType = {

	PERIODICAL: {
		code: "PERIODICAL",
		text: " Периодичен",
		cssClass: "fa fa-refresh"
	},
	INITIAL: {
		code: "INITIAL",
		text: " Първоначален",
		cssClass: "fa fa-graduation-cap"
	},

	get EVERY_STATUS() {
		return [this.PERIODICAL, this.INITIAL];
	},
	
	getByCode: function(code) {
		var foundStatus = null;
		this.EVERY_STATUS.forEach(function(status) {
			if (status.code === code) {
				foundStatus = status;
				return false;
			}
		});

		if (foundStatus === null) {
			foundStatus = this.getNullStatus();
		}

		return foundStatus;
	},
	
	getNullStatus: function() {
		return {
			code: "",
			text: "-",
			cssClass: ""
		};
	}
};