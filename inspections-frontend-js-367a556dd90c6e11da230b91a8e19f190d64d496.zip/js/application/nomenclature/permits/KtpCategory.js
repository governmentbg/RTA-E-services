namespace("demax.inspections.nomenclature.permits");

demax.inspections.nomenclature.permits.KtpCategory = {
	ONE: {
		code: "I",
		name: "I КАТЕГОРИЯ"
	},
	TWO: {
		code: "II",
		name: "II КАТЕГОРИЯ"
	},
	THREE: {
		code: "III",
		name: "III КАТЕГОРИЯ"
	},

	FOUR: {
		code: "IV",
		name: "IV КАТЕГОРИЯ"
	},

	FOUR_TB: {
		code: "IVТБ",
		name: "IVТБ КАТЕГОРИЯ"
	},

	FOUR_TM: {
		code: "IVТМ",
		name: "IVТМ КАТЕГОРИЯ"
	},

	FIVE: {
		code: "V",
		name: "V КАТЕГОРИЯ"
	},

	get ALL() {
		return [this.ONE, this.TWO, this.THREE, this.FOUR, this.FIVE];
	},

	getByCode: function(code) {
		var foundCategory = null;
		this.ALL.forEach(function (category) {
			if (category.code === code) {
				foundCategory = category;
				return false;
			}
		});
		return foundCategory;
	}
};