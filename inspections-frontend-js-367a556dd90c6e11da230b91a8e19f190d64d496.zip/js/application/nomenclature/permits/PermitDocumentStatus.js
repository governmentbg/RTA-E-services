namespace("demax.inspections.nomenclature.permits");

demax.inspections.nomenclature.permits.PermitDocumentStatus = {
	VALID : {
		code: "VALID",
		name: "Валиден",
		cssClass: "label label-success"
	},
	VALID_EXPIRED : {
		code: "VALID_EXPIRED",
		name: "Валиден - изтекъл",
		cssClass: "label label-dark-orange"
	},
	INVALID : {
		code: "INVALID",
		name: "Невалиден",
		cssClass: "label label-dark-gray"
	},
	EXPIRED : {
		code: "EXPIRED",
		name: "Изтекъл",
		cssClass: "label label-danger"
	},
	EXPIRING : {
		code: "EXPIRING",
		name: "Изтичащ",
		cssClass: "label label-warning"
	},

	get EVERY_STATUS() {
		return [this.VALID, this.VALID_EXPIRED, this.EXPIRED, this.EXPIRING, this.INVALID];
	},

	get REAL_STATUSES() {
		return [this.VALID, this.EXPIRED, this.INVALID];
	},

	getByCode: function (code) {
		var foundStatus = null;
		this.EVERY_STATUS.forEach(function (status) {
			if (status.code === code) {
				foundStatus = status;
				return false;
			}
		});
		return foundStatus;
	}
};