namespace("demax.inspections.nomenclature.permits");

demax.inspections.nomenclature.permits.PermitErrors = {

	NO_SUBJECT: { 
		code: 100, 
		message: "Фирмата не е намерена"
	},
	SUBJECT_IS_NOT_LEGAL_ENTITY: {
		code: 101, 
		message: "Субекта не е фирма"
	},
	NO_VALID_DOCUMENTS: {
		code: 200, 
		message: "Разрешението няма валидни документи"
	},
	MISSING_REQUIRED_DOCUMENT: { 
		code: 201, 
		message: "Липсват задължителни документи към разрешението" 
	},
	NOT_ENOUGH_INSPECTORS: {
		code: 202, 
		message: "Недостатъчно добавени специалста към разрешението. Изискват се поне двама"
	},
	NO_CHAIRMAN: {
		code: 203, 
		message: "Няма председател сред специалистите"
	},
	NO_LINES: {
		code: 204, 
		message: "Разрешението няма валидни линии. Изисква се поне една"
	},
	NO_PAID_AND_PASSED_INSPECTION: {
		code: 205, 
		message: "Разрешението няма заплатен и успешно преминал oглед"
	},
	INSPECTOR_IS_MISSING_REQUIRED_DOCUMENT: {
		code: 300, 
		message: "Липсват задължителни документи към специалист"
	},
	INSPECTOR_HAS_DOCUMENT_DRAFT_SNAPSHOT_IN_ANOTHER_PERMIT: { 
		code: 301, 
		message: "Специалиста се обработва в друго разрешение"
	},
	INSPECTOR_IS_IN_ANOTHER_COMPANY: {
		code: 302, 
		message: "Специалиста е към разрешение с друга фирма"
	},
	INSPECTOR_HAS_NO_VALID_CERTIFICATIONS: {
		code: 303, 
		message: "Специалиста няма валидни удостоверения"
	},
	INSPECTOR_WITH_REVOKED_RIGHTS: {
		code: 304, 
		message: "В разрешението има специалист с отнети права"
	},
	LINE_IS_MISSING_REQUIRED_DOCUMENT: {
		code: 400, 
		message: "Липсват задължителни документи на линия към разрешението"
	}
};