namespace("demax.inspections.nomenclature.permits");

demax.inspections.nomenclature.permits.PermitInspectorStatus = {

	INCLUDED: {
		code: "В",
		text: "включен",
		cssClass: "label label-success"
	},
	EXCLUDED: {
		code: "И",
		text: "изключен",
		cssClass: "label label-danger"
	},

	DEPRIVED_OF_RIGHTS: {
		code: "О",
		text: "отнети права",
		cssClass: "label label-warning"
	},

	get EVERY_STATUS() {
		return [this.INCLUDED, this.EXCLUDED, this.DEPRIVED_OF_RIGHTS];
	},
	
	getByCode: function(code) {
		var foundStatus = null;
		this.EVERY_STATUS.forEach(function(status) {
			if (status.code === code) {
				foundStatus = status;
				return false;
			}
		});

		if (foundStatus === null) {
			foundStatus = this.getNullStatus();
		}

		return foundStatus;
	},
	
	getNullStatus: function() {
		return {
			code: "",
			text: "-",
			cssClass: ""
		};
	}
};