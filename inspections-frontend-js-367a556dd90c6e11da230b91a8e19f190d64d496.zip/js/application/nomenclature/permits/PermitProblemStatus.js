namespace("demax.inspections.nomenclature.permits");

demax.inspections.nomenclature.permits.PermitProblemStatus = {

	WAITING: {
		id: 1,
		text: "чакащ",
		cssClass: "label label-warning"
	},
	RESOLVED: {
		id: 2,
		text: "разрешен",
		cssClass: "label label-success"
	},

	get EVERY_STATUS() {
		return [this.WAITING, this.RESOLVED];
	},
	
	getById: function(id) {
		var foundStatus = null;
		this.EVERY_STATUS.forEach(function(status) {
			if (status.id === id) {
				foundStatus = status;
				return false;
			}
		});

		if (foundStatus === null) {
			foundStatus = this.getNullStatus();
		}

		return foundStatus;
	},
	
	getNullStatus: function() {
		return {
			text: "-",
			cssClass: ""
		};
	}
};