namespace("demax.inspections.nomenclature.permits");

demax.inspections.nomenclature.permits.PermitStatus = {

	EXPIRED: {
		code: "ИЗ",
		name: "Изтекло",
		cssClass: "label label-danger"
	},

	CLOSED: {
		code: "ЗК",
		name: "Закрито",
		cssClass: "label label-danger"
	},

	REQUESTED: {
		code: "ЗВ",
		name: "Заявено",
		cssClass: "label label-warning"
	},

	VALID: {
		code: "ВЛ",
		name: "Валидно",
		cssClass: "label label-success"
	},

	CREATED: {
		code: "СЗ",
		name: "Създадено",
		cssClass: "label label-info"
	},

	REVOKED: {
		code: "ОТ",
		name: "Отнето",
		cssClass: "label label-danger"
	},
	//превода на името на статуса не отговаря поради решение на дизайнера
	PROCESSING: {
		code: "ОБ",
		name: "Чакащо одобрение",
		cssClass: "label label-warning"
	},

	CHANGED_CONDITIONS: {
		code: "ПО",
		name: "Променени обстоятелства",
		cssClass: "label label-primary"
	},

	CHANGED_LISTS: {
		code: "ПС",
		name: "Променени списъци",
		cssClass: "label label-primary"
	},

	CHANGED_CONDITIONS_AND_LISTS_CODE: {
		code: "ПОС",
		name: "Променени обстоятелства и списъци",
		cssClass: "label label-primary"
	},

	DRAFT: {
		code: "ЧР",
		name: "Чернова",
		cssClass: "label bg-teal"
	},

	REJECTED: {
		code: "ОТК",
		name: "Отказано",
		cssClass: "label label-danger"
	},

	REVOKING_IN_PROCESS: {
		code: "ПОТ",
		name: "В процес на отнемане",
		cssClass: "label label-warning"
	},

	INVALID: {
		code: "НВ",
		name: "Невалидно",
		cssClass: "label label-danger"
	},

	CHANGED_STATUS: {
		code: "ПРС",
		name: "Променен статус",
		cssClass: "label label-warning"
	},

	REISSUED_STATUS: {
		code: "ПР",
		name: "Преиздадено",
		cssClass: "label label-warning"
	},

	ALL: {
		code: null,
		name: "Всички"
	},

	get EVERY_STATUS() {
		return [this.CREATED, this.REQUESTED, this.VALID, this.CLOSED, this.EXPIRED, this.REVOKED, this.PROCESSING, 
			this.CHANGED_CONDITIONS, this.CHANGED_LISTS, this.CHANGED_CONDITIONS_AND_LISTS_CODE, this.DRAFT, this.REJECTED,
			this.REVOKING_IN_PROCESS, this.INVALID, this.CHANGED_STATUS, this.REISSUED_STATUS];
	},

	get EVERY_STATUS_WITHOUT_CREATED_AND_DRAFT() {
		return [this.REQUESTED, this.VALID, this.CLOSED, this.EXPIRED, this.REVOKED, this.PROCESSING, 
			this.CHANGED_CONDITIONS, this.CHANGED_LISTS, this.CHANGED_CONDITIONS_AND_LISTS_CODE, this.REJECTED,
			this.REVOKING_IN_PROCESS, this.INVALID, this.CHANGED_STATUS, this.REISSUED_STATUS];
	},

	get AVALIABLE_STATUS_CHANGES_BY_IAAA() {
		return [this.VALID, this.CLOSED, this.REVOKED, this.REVOKING_IN_PROCESS, this.INVALID];
	},

	get AVALIABLE_STATUS_CHANGES_BY_RDAA() {
		return [this.CLOSED, this.REVOKED];
	},

	getByCode: function (code) {
		var foundStatus = null;
		this.EVERY_STATUS.forEach(function (status) {
			if (status.code === code) {
				foundStatus = status;
				return false;
			}
		});
		return foundStatus;
	},

	getNullStatus: function () {
		return {
			code: "",
			name: "-",
			cssClass: ""
		};
	}
};