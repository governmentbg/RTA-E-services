namespace("demax.inspections.nomenclature.permits.inspectors");

demax.inspections.nomenclature.permits.inspectors.InspectorDocumentTypes = {
	ALL: [
		{code: "20306", name: "Копие от дипломата за завършено средно или висше образование със специалности по пр. №1"},
		{code: "20307", name: "Документ, удостоверяващ трудовия стаж"},
		{code: "20308", name: "Копие на трудовия договор"},
		{code: "20309", name: "Свидетелство за управление на МПС"},
		{code: "20310", name: "Свидетелстово за съдимост"}
	]
};