namespace("demax.inspections.nomenclature.permits.inspectors");

demax.inspections.nomenclature.permits.inspectors.InspectorStampStatus = {
	VALID: { code: "VALID", description: "Валиден" },

	INVALID: { code: "INVALID", description: "Невалиден" },

	TAKEN: { code: "TAKEN", description: "Отнет" },

	get ALL() {
		return [this.VALID, this.INVALID, this.TAKEN];
	}

};