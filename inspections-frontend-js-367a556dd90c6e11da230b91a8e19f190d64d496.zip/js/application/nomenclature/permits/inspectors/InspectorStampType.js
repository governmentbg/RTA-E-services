namespace("demax.inspections.nomenclature.permits.inspectors");

demax.inspections.nomenclature.permits.inspectors.InspectorStampType = {
	INSPECTION: { id: 1, description: "Печат за преглед" },

	ADR: { id: 2, description: "Печат за ADR" },

	SEMT: { id: 3, description: "Печат за СЕМТ" },

	get ALL() {
		return [this.INSPECTION, this.ADR];
	},

	getById: function(stampTypeId) {
		var stampType = null;
		for (var key in this) {
			if (this[key].id == stampTypeId) {
				stampType = this[key];
				break;
			}
		}
		return stampType;
	}
};