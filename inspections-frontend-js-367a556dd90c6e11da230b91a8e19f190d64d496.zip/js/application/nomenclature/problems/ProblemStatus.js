namespace("demax.inspections.nomenclature.problems");

demax.inspections.nomenclature.problems.ProblemStatuses = {
	WAITING: {
		id: 1,
		name: "Чакащ",
		cssClass: "label label-warning"
	},
	RESOLVED: {
		id: 2,
		name: "Разрешен",
		cssClass: "label label-success"
	},

	get EVERY_STATUS() {
		return [this.WAITING, this.RESOLVED];
	},

	getById: function(id) {
		var foundStatus = null;
		this.EVERY_STATUS.forEach(function(status) {
			if (status.id === id) {
				foundStatus = status;
				return false;
			}
		});
		return foundStatus;
	}
};