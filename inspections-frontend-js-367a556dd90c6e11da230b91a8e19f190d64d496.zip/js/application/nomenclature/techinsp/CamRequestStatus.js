namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.CamRequestStatus = {
	REQ_OPEN: {
		code: "REQ_OPEN"
	},
	REQ_OPEN_SRV: {
		code: "REQ_OPEN_SRV"
	},
	REQ_CLOSE: {
		code: "REQ_CLOSE"
	},
	OPENED: {
		code: "OPENED"
	},
	CLOSED: {
		code: "CLOSED"
	}
};
