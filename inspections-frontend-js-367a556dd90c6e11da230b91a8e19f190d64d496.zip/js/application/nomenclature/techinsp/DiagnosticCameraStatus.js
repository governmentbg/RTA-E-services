namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.DiagnosticCameraStatus = {
	OK: {
		code: "ok",
		serverValue: true,
		description: "OK"
	},
	MOVED: {
		code: "moved",
		serverValue: false,
		description: "Разместена"
	}
};