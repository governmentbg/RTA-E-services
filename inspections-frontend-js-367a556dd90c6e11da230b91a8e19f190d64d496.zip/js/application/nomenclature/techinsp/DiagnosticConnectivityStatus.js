namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.DiagnosticConnectivityStatus = {
	SUCCESSFUL: {
		code: "SUCCESSFUL",
		description: "Успешно",
		serverValue: true
	},
	UNSUCCESSFUL: {
		code: "UNSUCCESSFUL",
		description: "Неуспешно",
		serverValue: false
	}
};