namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.DiagnosticConnectivityType = {
	ethernet: {
		code: "ethernet",
		description: "LAN"
	},
	telenor: {
		code: "telenor",
		description: "Mobile - telenor"
	},
	vivacom: {
		code: "vivacom",
		description: "Mobile - vivacom"
	},
	wifi: {
		code: "wifi",
		description: "WiFi"
	}
};