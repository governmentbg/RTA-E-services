namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.DiagnosticSoftwareStatusOption = {
	UPDATED: {
		code: "UPDATED",
		description: "С последна версия"
	},
	NOTUPDATED: {
		code: "NOTUPDATED",
		description: "Без последна версия"
	}
};