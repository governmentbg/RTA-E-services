namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.EcoCategoryLightReport = {
	EURO6: {
		code: "E6",
		displayText: "EURO6"
	},
	EURO5: {
		code: "E5",
		displayText: "EURO5"
	},
	EURO4: {
		code: "E4",
		displayText: "EURO4"
	},
	EURO3: {
		code: "E3",
		displayText: "EURO3"
	},
	EURO2: {
		code: "E2",
		displayText: "EURO2"
	},
	EURO1: {
		code: "E1",
		displayText: "EURO1"
	},
	EUROE2E5: {
		code: "E2E5",
		displayText: "E2-E5"
	},
	EUROEEV: {
		code: "EEV",
		displayText: "EEV"
	},
	ANY: {
		code: "ANY",
		displayText: "Всички"
	},

	get ALL() {
		return [this.ANY, this.EURO1, this.EURO2, this.EURO3, this.EURO4, this.EURO5, this.EURO6, this.EUROE2E5, this.EUROEEV];
	},

	getByCode: function(code) {
		var foundType = null;
		$.each(demax.inspections.nomenclature.techinsp.EcoCategoryLightReport.ALL, function(i, type) {
			if (type.code == code) {
				foundType = type;
				return false;
			}
		});
		return foundType;
	}
};
