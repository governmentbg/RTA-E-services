namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.GasSystemFuelType = {
	LPG: {
		id: 1,
		displayText: "Втечнен нефтен газ (ВНГ)"
	},
	CNG: {
		id: 2,
		displayText: "Сгъстен природен газ (СПГ)"
	},

	getByCode: function(code) {
		var status = null;
		for (var key in this) {
			if (this[key].id == code) {
				status = this[key];
				break;
			}
		}
		return status;
	}
};