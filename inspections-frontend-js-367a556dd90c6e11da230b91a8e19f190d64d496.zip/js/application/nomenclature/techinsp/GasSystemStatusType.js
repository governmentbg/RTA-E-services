namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.GasSystemStatusType = {
	MOUNTED: {
		code: "Mounted",
		displayText: "Монтирана"
	},
	UNMOUNTED: {
		code: "Unmounted",
		displayText: "Демонтирана"
	},

	getByCode: function(code) {
		var status = null;
		for (var key in this) {
			if (this[key].code == code) {
				status = this[key];
				break;
			}
		}
		return status;
	}
};
