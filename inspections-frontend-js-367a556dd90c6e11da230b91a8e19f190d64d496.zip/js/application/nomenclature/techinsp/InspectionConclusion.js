namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.InspectionConclusion = {
	IA: {
		code: "IA",
		displayText: "Допуска се",
		cssClass: "label label-success"
	},
	TA: {
		code: "TA",
		displayText: "Временно се допуска",
		cssClass: "label label-warning"
	},
	NA: {
		code: "NA",
		displayText: "Не се допуска",
		cssClass: "label label-danger"
	}
};
