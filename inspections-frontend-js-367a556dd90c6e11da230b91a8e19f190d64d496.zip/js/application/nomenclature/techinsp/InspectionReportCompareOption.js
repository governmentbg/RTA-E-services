namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.InspectionReportCompareOption = {
	EQUALS: {
		code: "EQUALS",
		displayText: "="
	},
	GREATER_THAN: {
		code: "GREATER_THAN",
		displayText: ">"
	}
};
