namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.InspectionSpecificSearchFilter = {
	REG_NUM: {
		code: "REG_NUM",
		displayText: "Рег. №",
		placeholderValue: "Търси по Рег. №"
	},
	HOLOGRAM: {
		code: "HOLOGRAM",
		displayText: "Холограма",
		placeholderValue: "Търси по холограма"
	},
	PROTOCOL: {
		code: "PROTOCOL",
		displayText: "Протокол",
		placeholderValue: "Търси по Протокол №"
	},
	VIN_OR_RAMA: {
		code: "VIN_OR_RAMA",
		displayText: "VIN/Рама",
		placeholderValue: "Търси по VIN/Рама"
	},
	OWNER_IDENTITY_NUMBER: {
		code: "OWNER_IDENTITY_NUMBER",
		displayText: "ЕГН/ЛНЧ на собственик",
		placeholderValue: "Търси по ЕГН/ЛНЧ на собственик"
	},
	INSPECTION_PERSON_EGN: {
		code: "INSPECTION_PERSON_EGN",
		displayText: "ЕГН на лице представило ППС",
		placeholderValue: "Търси по ЕГН на лице представило ППС"
	},

	ALL: function() {
		return [this.REG_NUM, this.HOLOGRAM, this.PROTOCOL, this.VIN_OR_RAMA, this.OWNER_IDENTITY_NUMBER, this.INSPECTION_PERSON_EGN];
	},

	getByUserRoles: function(roles) {
		var Role = demax.inspections.nomenclature.Role;
		if (roles.indexOf(Role.ROLE_SUPER_ADMIN) > -1) {
			return [this.REG_NUM, this.HOLOGRAM, this.PROTOCOL, this.VIN_OR_RAMA, this.OWNER_IDENTITY_NUMBER, this.INSPECTION_PERSON_EGN];
		} else if (roles.indexOf(Role.CALL_CENTER) > -1) {
			return [this.REG_NUM, this.HOLOGRAM, this.PROTOCOL, this.VIN_OR_RAMA, this.OWNER_IDENTITY_NUMBER, this.INSPECTION_PERSON_EGN];
		} else if (roles.indexOf(Role.TECHINSP_INSP_SEARCH_ALL) > -1) {
			return [this.REG_NUM, this.HOLOGRAM, this.PROTOCOL, this.VIN_OR_RAMA, this.OWNER_IDENTITY_NUMBER, this.INSPECTION_PERSON_EGN];
		}
		return [this.REG_NUM, this.HOLOGRAM, this.PROTOCOL, this.VIN_OR_RAMA];
	}
};
