namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.InspectionStatus = {
	INPROGRESS: {
		code: "INPROGRESS",
		displayText: "Преглед в процес",
		shortDisplayText: "В процес",
		isFinished: false,
		iconCss: "text-light-blue"
	},
	COMPLETED: {
		code: "COMPLETED",
		displayText: "Приключен - със заключение",
		shortDisplayText: "Приключен",
		isFinished: true,
		iconCss: "text-green"
	},
	INVALID: {
		code: "INVALID",
		displayText: "Приключен - невалиден",
		shortDisplayText: "Невалиден",
		isFinished: true,
		iconCss: "text-red"
	},
	STOPPED: {
		code: "STOPPED",
		displayText: "Приключен - спрян",
		shortDisplayText: "Спрян",
		isFinished: true,
		iconCss: "text-yellow"
	},
	DAYS14: {
		code: "DAYS14",
		displayText: "Приключен - с възможност за продължение",
		shortDisplayText: "Приключен",
		isFinished: true,
		iconCss: "text-blue"
	}
};
