namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.InspectionStatusOption = {
	INPROGRESS: {
		code: "INPROGRESS",
		displayText: "Всички прегледи в процес",
		dbStatusCodes: [
			demax.inspections.nomenclature.techinsp.InspectionStatus.INPROGRESS.code
		]
	},
	ALLCOMPLETED: {
		code: "ALLCOMPLETED",
		displayText: "Всички приключени прегледи",
		dbStatusCodes: [
			demax.inspections.nomenclature.techinsp.InspectionStatus.COMPLETED.code,
			demax.inspections.nomenclature.techinsp.InspectionStatus.INVALID.code,
			demax.inspections.nomenclature.techinsp.InspectionStatus.STOPPED.code,
			demax.inspections.nomenclature.techinsp.InspectionStatus.DAYS14.code
		]
	},
	COMPLETED: {
		code: "COMPLETED",
		displayText: "Приключен - със заключение",
		dbStatusCodes: [
			demax.inspections.nomenclature.techinsp.InspectionStatus.COMPLETED.code
		]
	},
	INVALID: {
		code: "INVALID",
		displayText: "Приключен - невалиден",
		dbStatusCodes: [
			demax.inspections.nomenclature.techinsp.InspectionStatus.INVALID.code
		]
	},
	STOPPED: {
		code: "STOPPED",
		displayText: "Приключен - спрян",
		dbStatusCodes: [
			demax.inspections.nomenclature.techinsp.InspectionStatus.STOPPED.code
		]
	},
	DAYS14: {
		code: "DAYS14",
		displayText: "Приключен - с възможност за продължение",
		dbStatusCodes: [
			demax.inspections.nomenclature.techinsp.InspectionStatus.DAYS14.code
		]
	}
};
