namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.InspectionTypes = {

	BUS: {
		code: "BUS",
		text: "автобуси за превоз на пътници",
		altText: "Автобус"
	},
	BUSCHILDREN: {
		code: "BUSCHILDREN",
		text: "автобуси за превоз на деца и ученици",
		altText: "Превоз на деца"
	},
	TAXI: {
		code: "TAXI",
		text: "таксиметров превоз на пътници",
		altText: "Такси"
	},
	TRAM: {
		code: "TRAM",
		text: "трамвайни мотриси",
		altText: "Трамвай"
	},
	TROL: {
		code: "TROL",
		text: "тролейбуси",
		altText: "Тролей"
	},
	SEMT: {
		code: "SEMT",
		text: "издаване/заверка на ЕКМТ сертификат",
		altText: "СЕМТ"
	},
	ADR: {
		code: "ADR",
		text: "Проверка на ППС по ADR",
		altText: "АДР"
	},
	GAS: {
		code: "GAS",
		text: "Първоначална проверка на уредбите ВНГ/СПГ",
		altText: "GAS"
	},
	SG: {
		code: "SG",
		text: "атракцион",
		altText: "Атракцион"
	},
	VEHICLE: {
		code: "VEHICLE",
		text: "Протокол 9",
		altText: "Протокол №9"
	},

	get ALL() {
		return [this.BUS, this.BUSCHILDREN, this.SG, this.SEMT, this.ADR, this.GAS, this.VEHICLE, this.TAXI, this.TRAM, this.TROL];
	}
};