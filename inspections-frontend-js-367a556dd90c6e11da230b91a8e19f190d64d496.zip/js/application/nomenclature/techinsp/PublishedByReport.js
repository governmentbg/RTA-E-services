namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.PublishedByReport = {
	IAAA: {
		code: "IAAA",
		displayText: "ИААА"
	},
	KTP: {
		code: "KTP",
		displayText: "КТП"
	},
	ANY: {
		code: "ANY",
		displayText: "ИААА и КТП"
	},

	get ALL() {
		return [this.ANY, this.IAAA, this.KTP];
	},

	getByCode: function(code) {
		var foundType = null;
		$.each(demax.inspections.nomenclature.techinsp.PublishedByReport.ALL, function(i, type) {
			if (type.code == code) {
				foundType = type;
				return false;
			}
		});
		return foundType;
	}
};
