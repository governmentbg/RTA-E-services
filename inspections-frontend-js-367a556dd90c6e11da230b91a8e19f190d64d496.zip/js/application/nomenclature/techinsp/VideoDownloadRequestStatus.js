namespace("demax.inspections.nomenclature.techinsp");

demax.inspections.nomenclature.techinsp.VideoDownloadRequestStatus = {
	REQUESTED: {
		id: 1,
		description: "Заявен",
		dropdownName: "заявени",
		displayText: "заявено",
		cssClass: "label label-primary"
	},
	NO_RECORD: {
		id: 2,
		description: "Няма Запис",
		dropdownName: "няма запис",
		displayText: "няма запис",
		cssClass: "label label-danger"
	},
	DOWNLOADED: {
		id: 3,
		description: "Свален",
		dropdownName: "свалени",
		displayText: "Свали",
		cssClass: "btn btn-success btn-sm"
	},
	DELETED: {
		id: 4,
		description: "Изтрит",
		displayText: "изтрит",
		cssClass: "label label-danger"
	},
	
	get ALL_WITHOUT_DELETED() {
		return [this.REQUESTED, this.DOWNLOADED, this.NO_RECORD];
	},
	
	getById: function(statusId) {
		if (statusId == this.REQUESTED.id) {
			return this.REQUESTED;
		} else if (statusId == this.NO_RECORD.id) {
			return this.NO_RECORD;
		} else if (statusId == this.DOWNLOADED.id) {
			return this.DOWNLOADED;
		} else if (statusId == this.DELETED.id) {
			return this.DELETED;
		}
		return null;
	}
};
