namespace("demax.inspections.nomenclature");

demax.inspections.nomenclature.NomenclatureService = (function () {

	var URL = {
		ORG_UNITS: "api/org-units/without-iaaa",
		CITIES: "api/nomenclatures/cities",
		REGIONS: "api/nomenclatures/regions",
		COUNTRIES: "api/nomenclatures/countries",
		VEHICLE_CATEGORY_CODES: "api/nomenclatures/vehicle-categories/code",
		INSPECTION_TYPES_AND_CATEGORIES: "api/nomenclatures/inspection-types-categories",
		INSPECTION_TYPES: "api/nomenclatures/inspection-types",
		ECO_CATEGORIES: "api/nomenclatures/eco-categories",
		EDUCATION_LEVELS: "api/nomenclatures/education-levels"
	};

	var cache = {
		orgUnits: undefined,
		vehicleCategoryCodes: undefined,
		inspectionTypesAndCategories: undefined,
		regions: undefined,
		inspectionTypes: undefined,
		ecoCategories: undefined,
		countries: undefined,
		educationLevels: undefined
	};

	function getNomencalture(url, entitiesKey) {
		if (cache[entitiesKey]) {
			var promise = $.Deferred().resolve(cache[entitiesKey]);

			demax.inspections.restClient.activePromises.push(promise);
			promise.always(function() {
				demax.inspections.restClient.activePromises.remove(promise);
			});
		
			return promise;
		} else {
			return demax.inspections.restClient.getResource(url)
				.done(function (result) {
					cache[entitiesKey] = result.map(function(element) {
						return element;
					});
				});
		}
	}

	return {
		getOrgUnitsWithoutIaaa: function () {
			return getNomencalture(URL.ORG_UNITS, "orgUnits");
		},

		getCitiesByOrgUnitCode: function (orgUnitCode) {
			return demax.inspections.restClient.getResource(URL.CITIES + "?orgUnitCode=" + orgUnitCode);
		},

		getCitiesByRegion: function (regionCode) {
			return demax.inspections.restClient.getResource(URL.REGIONS + "/" + regionCode + "/cities");
		},

		getAllVehicleCategoryCodes: function() {
			return getNomencalture(URL.VEHICLE_CATEGORY_CODES, "vehicleCategoryCodes");
		},

		getInspectionTypesAndCategories: function() {
			return getNomencalture(URL.INSPECTION_TYPES_AND_CATEGORIES, "inspectionTypesAndCategories");
		},

		getRegions: function () {
			return getNomencalture(URL.REGIONS, "regions");
		},

		getInspectionTypes: function() {
			return getNomencalture(URL.INSPECTION_TYPES, "inspectionTypes");
		},
		
		getEcoCategories: function() {
			return getNomencalture(URL.ECO_CATEGORIES, "ecoCategories");
		},
		
		getCountries: function() {
			return getNomencalture(URL.COUNTRIES, "countries");
		},

		getEducationLevels: function() {
			return getNomencalture(URL.EDUCATION_LEVELS, "educationLevels");
		}
	};
})();