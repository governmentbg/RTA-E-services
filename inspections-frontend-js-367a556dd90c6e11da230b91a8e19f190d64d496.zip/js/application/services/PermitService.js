namespace("demax.inspections.service");

demax.inspections.service.PermitService = (function () {

	var URL = {
		GET_PERMIT_STATUS: "api/permits/{0}/status"
	};

	return {
		getPermitStatusCodeByPermitId: function(permitId, restClient) {
			if (!restClient) {
				restClient = demax.inspections.restClient;
			}
			return restClient.getResource(pastel.util.StringHelper.format(URL.GET_PERMIT_STATUS, permitId));
		}
	};
})();