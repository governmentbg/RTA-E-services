namespace("demax.inspections.utils");

demax.inspections.utils.DocumentUtil = {
		
	init: function() {
		demax.inspections.printOptions = {};
		var nextId = sessionStorage.getItem("demax.inspections.print.nextId");
		
		if (nextId == "NaN") {
			sessionStorage.setItem("demax.inspections.print.nextId", 1);
		}
	},
	
	downloadDocument: function(src, options) {
		if (options !== undefined && options.data !== undefined) {
			options = $.extend({}, options);
			if (typeof options.data !== "string") {
				options.data = JSON.stringify(options.data);
			}
		} else {
			options = {};
		}
		var nextId = parseInt(sessionStorage.getItem("demax.inspections.print.nextId"));
		sessionStorage.setItem("demax.inspections.print.nextId", nextId + 1);
		demax.inspections.printOptions[nextId] = JSON.stringify(options);
		localStorage.setItem("demax.inspections.print.printOptionsRef", nextId);
		window.open("download-document.html#" + src, "_blank");
		
		setTimeout(function() {
			delete demax.inspections.printOptions[nextId];
		}, 2 * 60 * 1000);
	}
};