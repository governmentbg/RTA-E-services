namespace("demax.inspections.utils");

demax.inspections.utils.FilePickerBox = function (settings) {
	var self = this;

	var fileSettings = {
		size: (settings && settings.size) ? settings.size : 5000000,
		type: (settings && settings.type) ? settings.type : /(pdf|jpg|jpeg|png)/,
		filename: (settings && settings.filename) ? new RegExp(settings.filename) : /.*/
	};

	self.file = ko.observable(null);
	self.filename = ko.observable();

	this.fileSelect = function (_element, event) {
		var file = event.target.files[0];
		if (!fileSettings.type.test(file.type)) {
			demax.inspections.popupManager.error("Моля, прикачете " + fileSettings.type);
			self.clearFile();
			return;
		}
		if (file.size > fileSettings.size) {
			var size = appendSize(fileSettings.size);
			demax.inspections.popupManager.error("Моля, прикачете файл с размер по-малък от " + size);
			self.clearFile();
			return;
		}
		if (!fileSettings.filename.test(file.name)) {
			demax.inspections.popupManager.error("Невалидно име на файла");
			self.clearFile();
			return;
		}
		self.filename(file.name);

		var reader = new FileReader();
		reader.onload = (function () {
			return function (e) {
				var base64 = e.target.result;
				self.file(base64.substring(base64.indexOf(",") + 1));
			};
		})(file);
		reader.readAsDataURL(file);
	};

	this.clearFile = function () {
		self.file(null);
		self.filename(null);
	};

	function appendSize(currentSize) {
		if (currentSize < 1000000) { 
			return currentSize / 1000 + " KB.";
		} else {
			return currentSize / 1000000 + " MB.";
		}
	}

};