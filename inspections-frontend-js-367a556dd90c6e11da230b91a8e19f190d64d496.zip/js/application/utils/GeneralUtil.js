namespace("demax.inspections.utils");

demax.inspections.utils.GeneralUtil = {

	convertIdentityNumberToDate: function(identityNumber) {
		var datePart = identityNumber.substring(0, 6);
		var stringArr = datePart.split("");
		var month = stringArr[2];
		if (month === "5") {
			stringArr[2] = "1";
			stringArr.splice(0, 0, "20");
		} else if (month === "4") {
			stringArr[2] = "0";
			stringArr.splice(0, 0, "20");
		} else {
			stringArr.splice(0, 0, "19");
		}
		return stringArr.join("");
	},
	
	getCompanyHasVatRegistrationText: function(company) {
		if (company.hasVatRegistration == true) {
			return "Да";
		} else if (company.hasVatRegistration == false) {
			return "Не";
		} else {
			return "Неизвестно";
		}
	},

	formatDate: function(date) {
		return moment.fromJacksonDateTimeArray(date).format(demax.inspections.settings.momentDateFormat);
	},


	formatDateTime: function(dateTime) {
		return moment.fromJacksonDateTimeArray(dateTime).format(demax.inspections.settings.momentDateTimeFormat);
	},

	getAppliedDocumentStatusData: function(status) {
		if (status) {
			return {
				text: "валиден",
				cssClass: "label label-success"
			};
		} else {
			return {
				text: "невалиден",
				cssClass: "label label-danger"
			};
		}
	},

	getPermitInspectorIsChairmanData: function(isChairman) {
		if (isChairman) {
			return {
				text: "ДА",
				cssClass: "text-green",
				glyphClass: "fa fa-check text-green"
			};
		} else {
			return {
				text: "НЕ",
				glyphClass: "fa fa-close"
			};
		}
	},

	getPermitLineStatusData: function(status) {
		if (status) {
			return {
				text: "Валидна",
				cssClass: "label label-success"
			};
		} else {
			return {
				text: "Невалидна",
				cssClass: "label label-danger"
			};
		}
	},

	getNullData: function() {
		return {
			text: "-",
			cssClass: "",
			glyphClass: ""
		};
	},

	wrapProperties: function(obj) {
		var self = this;
		Object.keys(obj).forEach(function(key) {
			var prop = obj[key];
			if (prop instanceof Object) {
				self.wrapProperties(prop);
			} else {
				obj[key] = ko.observable(prop);
			}
		});

		return obj;
	},

	unwrapProperties: function(obj) {
		var self = this;
		Object.keys(obj).forEach(function(key) {
			var prop = obj[key];
			if (prop instanceof Object) {
				self.unwrapProperties(prop);
			} else {
				obj[key] = ko.unwrap(prop);
			}
		});

		return obj;
	}
};