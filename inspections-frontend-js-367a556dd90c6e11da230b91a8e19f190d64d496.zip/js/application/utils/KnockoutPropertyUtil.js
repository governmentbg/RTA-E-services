namespace("demax.inspections.utils");

/**
 * Summary:
 * 
 * Knockout property util is class that is used for comparing,
 * rollbacking or applying changes made from
 * one object with observable values to another.
 * 
 * Description:
 * 
 * Used to be called KnockoutPropertyCooker :)
 * 
 */
demax.inspections.utils.KnockoutPropertyUtil = {

	/**
     * Apply changes from the current object to the initial one.
	 * @param from - The object with ko observable properties you want the properties from.
	 * @param to - The object with ko observable properties you want to copy the properties to.
	 * @param {string[]} params - Array of strings holding the property names.
     */
	copyProperties: function (from, to, params) {
		params.forEach(function (param) {
			var isObservable = ko.isObservable(from[param]);
			var value = isObservable ? ko.unwrap(from[param]) : from[param];
			if (value instanceof Object) {
				if (value instanceof moment) {
					isObservable ? to[param](value.clone()) : to[param] = value.clone();
				} else {
					var obj = $.extend(true, {}, value);
					isObservable ? to[param](obj) : to[param] = obj;
				}
			} else {
				isObservable ? to[param](value) : to[param] = value;
			}
		});
	},

	/**
     * Checks the two objects for changes in their ko observable property values.
	 * @param current - The current object with ko observable properties.
	 * @param initial - The initial object with ko observable properties.
	 * @param {string[]} params - Array of strings holding the property names.
	 * @return {boolean} hasChanges boolean flag.
     */
	hasChanges: function (current, initial, params) {
		var hasChanges = false;

		params.forEach(function (param) {
			if (ko.toJSON(current[param]) !== ko.toJSON(initial[param])) {
				hasChanges = true;
			}
		});

		return hasChanges;
	},

	/**
     * Checks the two arrays for changes in their item property values.
	 * Accepts both arrays and observableArrays.
	 * @param current - The current array.
	 * @param initial - The initial array.
	 * @return {boolean} hasChanges boolean flag.
     */
	hasChangesArray: function (current, initial) {
		var unwrappedCurrent = ko.unwrap(current);
		var unwrappedInitial = ko.unwrap(initial);
		for (var index = 0; index < unwrappedCurrent.length; index++) {
			var item = unwrappedCurrent[index];
			var item2 = unwrappedInitial[index];
			
			if (ko.toJSON(item) !== ko.toJSON(item2)) {
				return true;
			}
		}
		return false;
	},

	/**
     * Creates pureComputed that listens for changes between two objects
	 * @param current - The current object with ko observable properties.
	 * @param initial - The initial object with ko observable properties.
	 * @param {string[]} params - Array of strings holding the property names.
	 * @return {Object} Knockout observable object with hasChanges function.
     */
	hasChangesObservable: function (current, initial, params) {
		var holder = {};
		params.forEach(function (param) {
			holder[param + "1"] = current[param];
			holder[param + "2"] = initial[param];
		});

		return ko.pureComputed(function () {
			var hasChanges = false;
			params.forEach(function (param) {
				if (ko.toJSON(holder[param + "1"]) !== ko.toJSON(holder[param + "2"])) {
					hasChanges = true;
				}
			});
			return hasChanges;
		});
	}

};
