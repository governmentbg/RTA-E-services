namespace("demax.inspections.utils");

demax.inspections.utils.OrderUtils = {
	mergeOrderItemsByProduct: function(itemDtos) {
		if (!Array.isArray(itemDtos)) {
			return [];
		}

		var orderItems = ko.utils.arrayMap(itemDtos, function(itemDto) {
			return new demax.inspections.model.orders.OrderItem(itemDto);
		});

		return pastel.plus.util.toArray(orderItems);
	},

	concatIntervals: function(intervals) {
		var intervalsConcat = "";
		intervals = ko.unwrap(intervals);

		intervals.forEach(function(interval) {
			var fromNum = ko.unwrap(interval.fromNum);
			var toNum = ko.unwrap(interval.toNum);

			if (interval.fromNum !== null && interval.toNum !== null) {
				if (intervalsConcat !== "") {
					intervalsConcat += ", ";
				}
				intervalsConcat += getFormattedText(fromNum, toNum);
			}
		});
		
		function getFormattedText(fromNum, toNum) {
			var formattedFromNum = fromNum ? fromNum.toString().match(/(\d+?)(?=(\d{3})+(?!\d)|$)/g).join(" ") : "";
			var formattedToNum = toNum ? toNum.toString().match(/(\d+?)(?=(\d{3})+(?!\d)|$)/g).join(" ") : "";
			
			if (formattedFromNum && formattedToNum) {
				return formattedFromNum + " до " + formattedToNum;
			}
			return "";
		}
		
		return intervalsConcat;
	}
};


