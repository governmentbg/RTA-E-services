namespace("demax.inspections.utils");

demax.inspections.utils.SimplePopupManager = function() {
	var self = this;
	var popupQue = [];

	var POPUP_TYPES = {
		ALERT: "alert",
		CONFIRM: "confirm",
		prompt: "prompt",
		FORM: "form"
	};

	var DEFAULT_SETTINGS = {
		okButtonText: "ok",
		cancelButtonText: "cancel",
		type: "alert"
	};

	this.isVisible = ko.observable(false).extend({
		rateLimit: {
			timeout: 200,
			method: "notifyWhenChangesStop"
		},
		notify: "always"
	});

	this.openedPopup = ko.observable(null);


	this.addPopupToQue = function(settings) {
		var deferred = $.Deferred();

		settings = $.extend({}, DEFAULT_SETTINGS, settings);
		var popupContext = new PopupContext(settings, deferred);
		popupQue.push(popupContext);

		deferred.always(function() {
			removePopupContext(popupContext);
			openNextPopupIfNoneOpen();
		});

		openNextPopupIfNoneOpen();

		return deferred;
	};

	function removePopupContext(popupContext) {
		var popupContextIndexInQue = popupQue.indexOf(popupContext);

		if (popupContextIndexInQue > -1) {
			popupQue.splice(popupContextIndexInQue, 1);
		}

		if (self.openedPopup() == popupContext) {
			self.openedPopup(null);
			self.isVisible(false);
		}
	}

	function openNextPopupIfNoneOpen() {
		if (self.openedPopup() !== null) {
			return;
		}

		var popupContext = popupQue[0];

		if (popupContext instanceof PopupContext) {
			self.openedPopup(popupContext);
			self.isVisible(true);
		} else {
			self.openedPopup(null);
			self.isVisible(false);
		}

	}

	function PopupContext(settings, deferred) {
		var self = this;
		this.settings = settings;
		this.promptInput = ko.observable();
		this.inputs = [];

		if (settings.type === POPUP_TYPES.FORM) {
			settings.inputs.forEach(function (input) {
				self.inputs.push({
					name: input.name,
					property: input.property,
					type: input.type,
					value: ko.observable().extend(input.constraints),
					hasError: ko.observable(false)
				});
			});

			this.validationGroup = ko.validation.group(
				self.inputs.filter(function (input) {
					return input.type !== "date";
				}).map(function (input) {
					return input.value;
				})
			);

			this.dateGroup = self.inputs.filter(function (input) {
				return input.type === "date";
			});

			this.subscriptions = [];
			this.dateGroup.forEach(function (input) {
				self.subscriptions.push(input.value.subscribe(function () {
					input.hasError(false);
				}));
			});
		}

		this.ok = function() {
			if (settings.type === POPUP_TYPES.FORM) {

				var hasErrors = false;

				self.dateGroup.forEach(function (input) {
					if (!input.value()) {
						input.hasError(true);
						hasErrors = true;
					}
				});

				if (self.validationGroup().length > 0) {
					self.validationGroup.showAllMessages();
					hasErrors = true;
				}

				if (hasErrors) {
					return;
				}

				self.subscriptions.forEach(function (subscription) {
					subscription.dispose();
				});

				var result = {};
				self.inputs.forEach(function (input) {
					result[input.property] = input.value();
				});

				deferred.resolve(result);

			} else if (settings.type === POPUP_TYPES.prompt) {
				deferred.resolve(self.promptInput());
			} else {
				deferred.resolve();
			}
		};

		this.cancel = function() {
			deferred.reject();
		};
	}
};
