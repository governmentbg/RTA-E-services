namespace("demax.inspections.utils");

demax.inspections.utils.UserUtils = {
	canViewInspectionDetails: function (orgUnit) {
		var Role = demax.inspections.nomenclature.Role;
		var OrgUnit = demax.inspections.model.OrgUnit;

		var user = demax.inspections.authenticatedUser();	    
		var userRoles = user.roles;

		if (userRoles.indexOf(Role.TECHINSP_IAAA) > -1) {
			return true;
		} else if (userRoles.indexOf(Role.CALL_CENTER) > -1) {
			return true;	
		} else if (userRoles.indexOf(Role.TECHINSP_INSP_RDAA) > -1 
			|| userRoles.indexOf(Role.TECHINSP_CHILD_ORG_UNIT_INSPECTOR) > -1) {
			if (orgUnit instanceof OrgUnit) {
				var isOrgUnitUnderControl = false;

				user.employeeOrgUnit.forEach(function(element) {
					if (element.code === orgUnit.code) {
						isOrgUnitUnderControl = true;
					}
				});	

				return isOrgUnitUnderControl;
			} else {
				return false;
			}
		} else {
			return false;
		}
	},

	getOrgUnits: function() {
		var user = demax.inspections.authenticatedUser();
		var OrgUnits = demax.inspections.nomenclature.permits.PermitRegion;

		if (!user.userIsControl()) {
			return OrgUnits.ALL;
		} else {
			return user.employeeOrgUnit;
		}
	}
};
