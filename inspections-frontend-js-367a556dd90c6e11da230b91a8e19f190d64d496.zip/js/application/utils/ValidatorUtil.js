namespace("demax.inspections.utils");

demax.inspections.utils.ValidatorUtil = {

	containsOnlyNumbers: function(str) {
		if (str == null || str.length === 0) {
			return false;
		}
		for (var i = 0; i < str.length; i++) {
			// If we find a non-digit character we return false.
			if (Number.isNaN(Number(str.charAt(i)))) {
				return false;
			}
		}
		return true;
	},


	validateEgn: function(egn) {
		// var year;
		var month;
		// var day;
		var sum = 0;
		var weightsEgn = [2, 4, 8, 5, 10, 9, 7, 3, 6];
		// year = 0;

		if (egn == null) {
			return false;
		}

		if (egn === undefined || egn === "") {
			return true;
		}

		if (egn.length !== 10 || egn.trim().length !== 10) {
			return false;
		}

		if (!demax.inspections.utils.ValidatorUtil.containsOnlyNumbers(egn)) {
			return false;
		}

		// year = Number(egn.charAt(0) + egn.charAt(1));
		if (Number(egn.charAt(2)) === 0) {
			month = Number(egn.charAt(3));
		} else {
			month = Number(egn.charAt(2) + egn.charAt(3));
		}

		// if (Number(egn.charAt(4)) === 0) {
		// 	day = Number(egn.charAt(5));
		// } else {
		// 	day = Number(egn.charAt(4) + egn.charAt(5));
		// }

		if (month >= 1 && month <= 12) {
			// year += 1900;
		} else if (month >= 21 && month <= 32) {
			// year += 1800;
			month -= 20;
		} else if (month >= 41 && month <= 52) {
			// year += 2000;
			month -= 40;
		} else {
			return false;
		}

		for (var i = 0; i < egn.length - 1; i++) {
			sum += Number(egn.charAt(i)) * weightsEgn[i];
		}

		var m = sum % 11;

		if (m === 10 && Number(egn.charAt(9)) === 0) {
			return true;
		} else if (m === Number(egn.charAt(9))) {
			return true;
		} else {
			return false;
		}
	},

	validateEic: function(eikStr) {
		if (eikStr == null) {
			return false;
		}

		var eikLen = eikStr.length;
		if ((eikLen == 9) || (eikLen == 13)) {

			if (!demax.inspections.utils.ValidatorUtil.containsOnlyNumbers(eikStr)) {
				return false;
			} else {
				var sum = 0;
				for (var i = 0; i < 8; i++) {
					sum += parseInt(eikStr.charAt(i)) * (i + 1);
				}
				var newValue = sum % 11;
				if (newValue == 10) {
					sum = 0;
					for (var j = 0; j < 8; j++) {
						sum += parseInt(eikStr.charAt(j)) * (j + 3);
					}
					newValue = sum % 11;
					if (newValue == 10) {
						newValue = 0;
					}
				}
				if (newValue == parseInt(eikStr.charAt(8))) {
					if (eikLen == 9) {
						return true;
					} else {
						sum = parseInt(eikStr.charAt(8)) * 2 + parseInt(eikStr.charAt(9)) * 7
										+ parseInt(eikStr.charAt(10)) * 3 + parseInt(eikStr.charAt(11)) * 5;
						newValue = sum % 11;
						if (newValue == 10) {
							sum = parseInt(eikStr.charAt(8)) * 4 + parseInt(eikStr.charAt(9)) * 9
											+ parseInt(eikStr.charAt(10)) * 5 + parseInt(eikStr.charAt(11)) * 7;
							newValue = sum % 11;
							if (newValue == 10) {
								newValue = 0;
							}
						}
						if (newValue == parseInt(eikStr.charAt(12))) {
							return true;
						} else {
							return false;
						}
					}
				} else {
					return false;
				}
			}
		} else {
			return false;
		}
	},

	validateEnc: function(encStr) {
		var sum = 0;

		var weightsEnc = [21, 19, 17, 13, 11, 9, 7, 3, 1];

		if (encStr === null) {
			return false;
		}
		if (encStr.length !== 10) {
			return false;
		}
		if (!demax.inspections.utils.ValidatorUtil.containsOnlyNumbers(encStr)) {
			return false;
		}
		for (var i = 0; i < encStr.length - 1; i++) {
			sum += Number(encStr.charAt(i)) * weightsEnc[i];
		}
		var overage = sum % 10;
		if (overage === Number(encStr.charAt(9))) {
			return true;
		} else {
			return false;
		}
	},

	validateBirthDate: function(birthDate) {
		if (birthDate === null) {
			return false;
		}
		var now = moment();
		if (now.subtract(18, "years").isSameOrAfter(birthDate)) {
			return true;
		} else {
			return false;
		}
	}
};