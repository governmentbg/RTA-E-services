namespace("demax.inspections.utils");

demax.inspections.utils.WeightScalePoller = function(settings) {
	settings = settings || {};

	var self = this;
	var url = demax.inspections.settings.peripheralDevicesServerAddress + "/Weight";
	var timeoutBetweenRequests = settings.timeoutBetweenRequests || 400;
	var timeouts = [];
	var xhrs = [];
	var maxFailedIgnorableExceptions = settings.maxFailedIgnorableExceptions || 20;
	var currentFailedIgnorableExceptions = 0;

	this.isPolling = ko.observable(false);
	this.weight = ko.isObservable(settings.weight) ? settings.weight : ko.observable(0);

	this.isLoading = ko.observable(false).extend({
		rateLimit: {
			timeout: 200,
			method: "notifyWhenChangesStop"
		},
		notify: "always"
	});

	this.startPolling = function() {
		self.isPolling(true);
		getWeight();
	};

	this.stopPolling = function() {
		currentFailedIgnorableExceptions = 0;
		self.isLoading(false);
		self.isPolling(false);

		timeouts.forEach(function(timeout) {
			clearTimeout(timeout);
		});

		xhrs.forEach(function(xhr) {
			xhr.abort();
		});
	};

	function getWeight() {
		xhrs.push($.get(url).done(function(resp) {
			var unroundedWeight = resp / 1000;
			var roundedWeight = pastel.plus.util.roundNumber(unroundedWeight, 2);
			self.weight(roundedWeight);
			self.isLoading(false);
			currentFailedIgnorableExceptions = 0;
			timeouts.push(setTimeout(getWeight, timeoutBetweenRequests));
		}).fail(function(xhr) {
			if (xhr.statusText == "abort") {
				return;
			}

			self.weight(0);

			var responseText = xhr.responseText;
			if (typeof(xhr.responseText) == "string") {
				if (responseText.indexOf("ScaleIgnorableException") > -1) {
					currentFailedIgnorableExceptions++;
					if (currentFailedIgnorableExceptions > maxFailedIgnorableExceptions) {
						stopPollingAndNotifyUser();
					} else {
						self.isLoading(true);
						timeouts.push(setTimeout(getWeight, timeoutBetweenRequests));
					}
				} else if (responseText.indexOf("ScaleErrorExcepton") > -1) {
					stopPollingAndNotifyUser("Неразпознат проблем по време на измерването от везната.");
				} else if (responseText.indexOf("ScaleOverloadedException") > -1) {
					stopPollingAndNotifyUser("Везната е претоварена. Максимална тежест - 6кг.");
				} else if (responseText.indexOf("PlateRemovedException") > -1) {
					stopPollingAndNotifyUser("Блюдото не е на везната.");
				} else if (responseText.indexOf("ScaleOverloadedOrDamagedException") > -1) {
					stopPollingAndNotifyUser("Блюдото не е на везната или везната е претоварена.");
				} else if (responseText.indexOf("ScaleNotRespondingException") > -1) {
					stopPollingAndNotifyUser("Везната не отговаря.");
				} else {
					stopPollingAndNotifyUser();
				}
			} else {
				stopPollingAndNotifyUser();
			}
		}));
	}

	function stopPollingAndNotifyUser(message) {
		message = message || "Проблем при връзката с везната";
		self.stopPolling();
		demax.inspections.popupManager.error(message);
	}
};
