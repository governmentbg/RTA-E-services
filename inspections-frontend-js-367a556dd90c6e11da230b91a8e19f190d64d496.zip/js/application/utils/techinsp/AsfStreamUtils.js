namespace("demax.inspections.utils.techinsp");

demax.inspections.utils.techinsp.AsfStreamUtils = {

	getAsfIp: function(fullWebmStreamUrl) {
		var ip = fullWebmStreamUrl.replace("http://", "");
		ip = ip.substring(0, ip.indexOf(":"));

		return ip;
	},
	buildAsxFile: function(inspLiveStreamSetup) {
		var ip = this.getAsfIp(inspLiveStreamSetup.restreamAddress);
		var feedNum = inspLiveStreamSetup.camRequest.feedNum;
		var resolution = inspLiveStreamSetup.camRequest.resolution;

		var feedNumTwoDigitFormat = feedNum;

		if ((feedNumTwoDigitFormat + "").length < 2) {
			feedNumTwoDigitFormat = "0" + feedNumTwoDigitFormat;
		}

		var asfStreamUrl = "mmsh://" + ip + ":8" + resolution + feedNumTwoDigitFormat + "/test" + feedNum + "-" + resolution + ".asf";

		var asxFileContent = "<ASX version = '3.0'><Entry><Ref href =\""
			+ asfStreamUrl
			+ "\"/></Entry></ASX>";

		return asxFileContent;
	},

	downloadAsxFile: function(inspLiveStreamSetup, fileName) {
		var asxFileContent = this.buildAsxFile(inspLiveStreamSetup);
		var asxBlob = new Blob([asxFileContent]);

		pastel.plus.util.blob.downloadBlob(asxBlob, fileName);
	}
};
