namespace("demax.inspections.viewmodel");

demax.inspections.viewmodel.LayoutVM = function () {
	var self = this;
	var restClient = demax.inspections.restClient;
	this.currentHash = ko.observable("");
	this.isChangingPassword = ko.observable(false);
	this.passwordChangeParams = ko.validatedObservable(new demax.inspections.model.PasswordChangeParams(), { deep: true });
	this.permitProblemsCount = ko.observable(0);

	this.inspOrderSideButton = {
		isActive: ko.pureComputed(function () {
			return self.currentHash().indexOf("inspection-order") > -1
				|| self.currentHash().indexOf("bills-of-lading-list") > -1;
		}),
		isMenuOpen: ko.observable(false)
	};

	this.hardwareSideButton = {
		isActive: ko.pureComputed(function () {
			return self.currentHash().indexOf("hardware/") > - 1;
		}),
		isMenuOpen: ko.observable(false)
	};

	this.consumablesSideButton = {
		isActive: ko.pureComputed(function () {
			return self.currentHash().indexOf("consumables/") > - 1;
		}),
		isMenuOpen: ko.observable(false)
	};

	this.reportsSideButton = {
		isActive: ko.pureComputed(function () {
			return self.currentHash().indexOf("techinsp/reports") > - 1 && self.currentHash().indexOf("techinsp/reports/inspections") < 0;
		}),
		isMenuOpen: ko.observable(false)
	};

	this.reportsPermitSideButton = {
		isActive: ko.pureComputed(function () {
			return self.currentHash().indexOf("/techinsp/reports/permits") > - 1;
		}),
		isMenuOpen: ko.observable(false)
	};

	this.techInspMessagesSideButton = {
		isActive: ko.pureComputed(function () {
			return self.currentHash().indexOf("techinsp/messages") > -1;
		}),
		isMenuOpen: ko.observable(false)
	};

	this.isInProgressInspectionMenuActive = ko.pureComputed(function () {
		var currentHash = ko.unwrap(self.currentHash);
		if (currentHash && currentHash.indexOf("techinsp/in-progress-inspection") > -1) {
			return true;
		}
		return false;
	});

	this.isFinishedInspectionMenuActive = ko.pureComputed(function () {
		var currentHash = ko.unwrap(self.currentHash);
		if (currentHash && currentHash.indexOf("techinsp/finished-inspection") > -1) {
			return true;
		}
		return false;
	});

	this.init = function () {

		demax.inspections.currentHash = ko.observable();
		demax.inspections.events.subscribe(demax.inspections.Event.ROUTE_CHANGED, function (event, route) {
			self.currentHash(route.url);
			demax.inspections.currentHash(route.url);
		});
		self.currentHash.subscribe(function (newHash) {
			if (newHash.indexOf("inspection-order") < 0
				&& newHash.indexOf("bills-of-lading-list") < 0) {
				self.inspOrderSideButton.isMenuOpen(false);
			} else {
				self.inspOrderSideButton.isMenuOpen(true);
			}

			if (newHash.indexOf("hardware/") < 0) {
				self.hardwareSideButton.isMenuOpen(false);
			} else {
				self.hardwareSideButton.isMenuOpen(true);
			}

			if (newHash.indexOf("consumables/") < 0) {
				self.consumablesSideButton.isMenuOpen(false);
			} else {
				self.consumablesSideButton.isMenuOpen(true);
			}

			if (newHash.indexOf("reports") < 0) {
				self.reportsSideButton.isMenuOpen(false);
			} else {
				self.reportsSideButton.isMenuOpen(true);
			}

			if (newHash.indexOf("techinsp/messages") < 0) {
				self.techInspMessagesSideButton.isMenuOpen(false);
			} else {
				self.techInspMessagesSideButton.isMenuOpen(true);
			}
		});

		setupOnKeyUpEvents();
		if (demax.inspections.authenticatedUser().isUserOfGroup([demax.inspections.nomenclature.Role.CALL_CENTER, 
			demax.inspections.nomenclature.Role.ROLE_SUPER_ADMIN])) {
			loadWaitingProblemsCount();
		}

	};

	this.isPackagingVouchersActive = ko.pureComputed(function () {
		return self.currentHash().indexOf("exam-order") > -1;
	});

	this.isPermitsActive = ko.pureComputed(function () {
		return self.currentHash().indexOf("permits") > -1 
			&& self.currentHash().indexOf("consumables") < 0
			&& self.currentHash().indexOf("hardware") < 0
			&& self.currentHash().indexOf("reports/permits") < 0;
	});

	this.isDashboardActive = ko.pureComputed(function () {
		return self.currentHash().indexOf("dashboard") > -1;
	});

	this.shouldHaveNestedInspectionMenu = ko.pureComputed(function () {
		var Group = demax.inspections.nomenclature.Group;
		var user = demax.inspections.authenticatedUser();

		if (user === null || user === undefined) {
			return false;
		}

		return user.isUserOfGroup(Group.PACKAGING_INSPECTIONS)
			&& user.isUserOfGroup(Group.PACKAGING_VOUCHERS);
	});

	this.toggleChangePasswordModal = function () {
		if (self.isChangingPassword()) {
			self.isChangingPassword(false);
		} else {
			self.passwordChangeParams(new demax.inspections.model.PasswordChangeParams());
			self.isChangingPassword(true);
		}
	};

	this.doChangePassword = function () {
		self.passwordChangeParams().validatePasswords();
		if (!self.passwordChangeParams.isValid()) {
			self.passwordChangeParams.errors.showAllMessages();
			return;
		}
		var requestBody = self.passwordChangeParams().toQueryParams();
		restClient.postResource("api/users/current/change-password", ko.toJSON(requestBody))
			.done(function () {
				self.toggleChangePasswordModal();
				demax.inspections.popupManager.success({ message: "Паролата е сменена успешно!" });
			}).handleErrors({
				UserCurrentPasswordNotEqualToProvidedOldPasswordException: function () {
					self.passwordChangeParams().errorMessage("Въведената стара парола не съвпада с текущата.");
				},
				UserCurrentPasswordIsEqualToNewPasswordException: function () {
					self.passwordChangeParams().errorMessage("Въведената нова парола съвпада с текущата.");
				}
			});
	};

	this.logout = function () {
		restClient.postResource("logout").done(function () {
			window.location.href = "login.html";
		});
	};

	function setupOnKeyUpEvents() {
		$(document).on("keyup.layoutVM", function (event) {
			var currentPopup = demax.inspections.popupManager.openedPopup();
			switch (event.keyCode) {
				case pastel.util.KeyCodes.ENTER:
					if (currentPopup != null) {
						currentPopup.ok();
					} else {
						demax.inspections.events.publish(demax.inspections.Event.KEYPRESS_ENTER);
					}
					break;
				case pastel.util.KeyCodes.ESCAPE:
					if (currentPopup != null) {
						currentPopup.cancel();
					} else {
						demax.inspections.events.publish(demax.inspections.Event.KEYPRESS_ESC);
					}
					break;
			}

		});
	}

	function loadWaitingProblemsCount() {
		restClient.getResource("api/permit-problems/count")
			.done(function (response) {
				self.permitProblemsCount(response);
			});
	}
};
