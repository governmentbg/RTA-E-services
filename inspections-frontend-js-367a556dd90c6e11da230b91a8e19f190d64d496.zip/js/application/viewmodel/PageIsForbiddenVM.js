namespace("demax.inspections.viewmodel");

demax.inspections.viewmodel.PageIsForbiddenVM = function() {
	
};