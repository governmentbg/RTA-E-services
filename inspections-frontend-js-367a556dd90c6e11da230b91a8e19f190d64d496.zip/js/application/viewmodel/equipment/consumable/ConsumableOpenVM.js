namespace("demax.inspections.viewmodel.equipment.consumable");

demax.inspections.viewmodel.equipment.consumable.ConsumableOpenVM = function() {
	var self = this;
	var restClient = demax.inspections.restClient;

	var PrinterConsumableStatus = demax.inspections.nomenclature.equipment.consumable.PrinterConsumableStatus;

	var URL = {
		CONSUMABLE_BY_ID: "api/consumables/{0}",
		CREATE_CARTRIDGE_REPORT: "api/consumables/{0}/reports"
	};

	this.isDefectiveOptions = [
		{ text: "Да", value: true },
		{ text: "Не", value: false }
	];

	this.isLoading = restClient.isLoading;

	this.isEditing = ko.observable(false);
	this.isCreatingReport = ko.observable(false);

	this.consumable = ko.observable();

	this.init = function(params) {
		loadConsumableById(params.id);
	};

	this.consumableTypeText = ko.pureComputed(function() {
		var consumable = ko.unwrap(self.consumable);
		if (consumable && consumable.type) {
			return consumable.type.displayText.toLowerCase();
		}
		return "";
	});

	this.consumableStatusText = ko.pureComputed(function() {
		var consumable = ko.unwrap(self.consumable);
		if (consumable && consumable.status) {
			return consumable.status.displayText;
		}
		return "";
	});

	this.calculatedPagesForPayment = ko.pureComputed(function() {
		var consumable = ko.unwrap(self.consumable);
		if (consumable && consumable.printedPages && consumable.inspectionNeededPages) {
			var pagesForPayment = consumable.printedPages - consumable.inspectionNeededPages;
			if (pagesForPayment < 0) {
				pagesForPayment = 0;
			}
			return pagesForPayment;
		}
		return 0;
	});

	this.reportPagesForPayment = ko.observable().extend({
		required: true,
		number: true,
		min: 0
	});

	this.beginCartridgeReportCreation = function() {
		self.isCreatingReport(true);
		self.reportPagesForPayment(ko.unwrap(self.calculatedPagesForPayment));
	};
	
	this.beginDrumReportCreation = function() {
		demax.inspections.popupManager.confirm({
			cssClass: "popInfo",
			message: "Сигурни ли сте, че искате да отчетете барабана?",
			okButtonCss: "btn-primary"
		}).done(function() {
			self.reportPagesForPayment(0);
			self.createReport();
		});
	};
	
	this.cancelReportCreation = function() {
		self.isCreatingReport(false);
	};

	this.createReport = function() {
		var validationErrors = ko.validation.group([self.reportPagesForPayment]);

		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			demax.inspections.popupManager.warn("Има невалидни полета!");
			return;
		}
		var requestBody = {
			pagesForPayment: ko.unwrap(self.reportPagesForPayment())
		};
		var url = pastel.util.StringHelper.format(URL.CREATE_CARTRIDGE_REPORT, self.consumable().id);

		restClient.postResource(url, ko.toJSON(requestBody)).done(function() {
			self.isCreatingReport(false);
			loadConsumableById(self.consumable().id);
		}).handleErrors({
			NoSuchEntityException: function() {
				demax.inspections.popupManager.error("Тонер с ИД " + self.consumable().id + " не съществува!");
			},
			PrinterCartridgeReportCreationStatusMismatchException: function() {
				demax.inspections.popupManager.error("Тонерът трябва да бъде в статус \"Инсталиран\"!");
			}
		});
	};

	this.editReturnedAt = ko.observable();
	this.editDefectiveValue = ko.observable(false);
	this.editReturnedNotes = ko.observable();

	this.startEditing = function() {
		self.isEditing(true);
		this.editReturnedAt(moment());
	};

	this.cancelEdit = function() {
		self.isEditing(false);
	};

	this.saveEditedInformation = function() {
		var dto = {
			statusCode: PrinterConsumableStatus.RETURNED.code,
			returnedAt: self.editReturnedAt() ? self.editReturnedAt().format(demax.inspections.settings.serverDateFormat) : null,
			defective: self.editDefectiveValue(),
			returnedNotes: self.editReturnedNotes() ? self.editReturnedNotes() : null
		};

		var url = pastel.util.StringHelper.format(URL.CONSUMABLE_BY_ID, self.consumable().id);
		restClient.patchResource(url, ko.toJSON(dto)).done(function() {
			self.isEditing(false);
			loadConsumableById(self.consumable().id);
		});
	};

	function loadConsumableById(consumableId) {
		restClient.getResource(pastel.util.StringHelper.format(URL.CONSUMABLE_BY_ID, consumableId))
			.done(function(consumableDto) {
				self.consumable(new demax.inspections.model.equipment.consumable.PrinterConsumable(consumableDto));
			});
	}
};
