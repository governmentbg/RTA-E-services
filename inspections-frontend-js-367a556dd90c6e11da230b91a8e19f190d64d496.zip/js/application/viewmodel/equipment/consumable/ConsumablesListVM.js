namespace("demax.inspections.viewmodel.equipment.consumable");

demax.inspections.viewmodel.equipment.consumable.ConsumablesListVM = function() {
	var self = this;
	var subscriptions = [];
	var restClient = demax.inspections.restClient;

	var OrgUnit = demax.inspections.model.OrgUnit;
	var PrinterConsumableStatus = demax.inspections.nomenclature.equipment.consumable.PrinterConsumableStatus;
	var PrinterConsumableType = demax.inspections.nomenclature.equipment.consumable.PrinterConsumableType;
	var PrinterConsumableSearchFilters = demax.inspections.model.equipment.consumable.PrinterConsumableSearchFilters;

	var URL = {
		CONSUMABLES: "api/consumables",
		PRINTER_CONSUMABLES_EXCEL: "api/consumables/xls"
	};

	var thisNamespace = ".consumablesListVM";

	this.isLoading = restClient.isLoading;

	this.pageSizes = [20, 50, 100];
	this.printerConsumableTypes = PrinterConsumableType.ALL;
	this.printerConsumableStatuses = PrinterConsumableStatus.ALL;

	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: self.pageSizes[0]
	});

	this.consumables = ko.observableArray();
	this.consumablesCount = ko.observable();
	this.filters = new PrinterConsumableSearchFilters();

	this.orgUnits = ko.observableArray();

	this.init = function() {
		loadOrgUnits().done(function() {
			restoreMemento();
			loadConsumables();

			subscriptions.push(self.pagination.queryParamsObject.subscribe(function() {
				self.filters.loadLastUsedFilters();
				loadConsumables();
			}));

			demax.inspections.events.subscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace, onEnter);
		});
	};

	this.performNewSearch = function() {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadConsumables();
		} else {
			self.pagination.page(1);
		}
	};

	this.refresh = function() {
		self.filters.loadLastUsedFilters();
		loadConsumables();
	};

	this.exportExcel = function() {
		var queryParams = ko.unwrap(self.filters.queryParams);
		var queryString = convertQueryParamsObjectToQueryParamsString(queryParams);

		window.open(URL.PRINTER_CONSUMABLES_EXCEL + queryString);
	};

	this.toggleStatusSelected = function(status) {
		if (self.filters.statuses.indexOf(status) > -1) {
			self.filters.statuses.remove(status);
		} else {
			self.filters.statuses.push(status);
		}
	};

	this.goToPermitDetails = function(consumable) {
		demax.inspections.router.setHash("permits/details/" + consumable.permit.id, { isTechinspPermit: true });
	};

	function convertQueryParamsObjectToQueryParamsString(queryParams) {
		var queryString = "";
		var appendParameterToQueryString = function(name, value) {
			queryString += (queryString.indexOf("?") < 0 ? "?" : "&") + name + "=" + value;
		};
		for (var key in queryParams) {
			if (queryParams[key]) {
				if ($.isArray(queryParams[key])) {
					$.each(queryParams[key], function(i, value) {
						appendParameterToQueryString(key, value);
					});
				} else {
					appendParameterToQueryString(key, queryParams[key]);
				}
			}
		}
		return queryString;
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}
			if (memento.filterParams.type) {
				self.filters.type(memento.filterParams.type);
			}
			if (memento.filterParams.statuses) {
				self.filters.statuses(memento.filterParams.statuses);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(self.orgUnits.find("code", memento.filterParams.orgUnit));
			}
		}
		self.filters.saveLastUsedFilters();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	function loadConsumables() {
		var pageParams = self.pagination.queryParamsObject();
		var searchParams = self.filters.toQueryParams();
		var requestParams = $.extend({}, pageParams, searchParams);

		restClient.getResource(URL.CONSUMABLES, requestParams)
			.done(function(response) {
				self.consumables(ko.utils.arrayMap(response.items, function(itemDto) {
					return new demax.inspections.model.equipment.consumable.PrinterConsumableListItem(itemDto);
				}));
				self.consumablesCount(response.totalCount);
			});
	}

	function loadOrgUnits() {
		return demax.inspections.nomenclature.NomenclatureService.getOrgUnitsWithoutIaaa()
			.done(function(orgUnitDtos) {
				self.orgUnits(ko.utils.arrayMap(orgUnitDtos, function(orgUnitDto) {
					return new OrgUnit(orgUnitDto);
				}));
			});
	}

	function onEnter() {
		var isLoading = self.isLoading();

		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	this.dispose = function() {
		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();
		saveMemento();
		demax.inspections.events.unsubscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace);
	};
};
