namespace("demax.inspections.viewmodel.equipment.consumable");

demax.inspections.viewmodel.equipment.consumable.CreateRequestVM = function() {
	var self = this;
	var subscriptions = [];
	var restClient = demax.inspections.restClient;

	var URL = {
		PERMIT_SHIPPING_INFO: "api/permits/{0}/shipping-info",
		CONSUMABLE_TRANSFERS: "api/consumable-transfers"
	};

	this.permitNumber = ko.observable().extend({
		rateLimit: { timeout: 350, method: "notifyWhenChangesStop" },
		required: true,
		number: true
	});
	this.isLoading = restClient.isLoading;
	this.isLoadingPermitShippmentInfo = ko.observable().extend({
		rateLimit: { timeout: 350, method: "notifyWhenChangesStop" }
	});
	this.permitShippingInfo = ko.observable(new demax.inspections.model.equipment.consumable.PermitShippingInfo({}));
	this.permitShippingInfoErrorMessage = ko.observable();
	this.tonersCount = ko.observable(0);
	this.drumsCount = ko.observable(0);
	this.tonersCount.extend({
		min: {
			onlyIf: function() {
				return self.drumsCount() == false;
			},
			params: 1
		},
		required: {
			onlyIf: function() {
				return self.drumsCount() == false;
			}
		}
	});
	this.drumsCount.extend({
		min: {
			onlyIf: function() {
				return self.tonersCount() == false;
			},
			params: 1
		},
		required: {
			onlyIf: function() {
				return self.tonersCount() == false;
			}
		}
	});

	this.selectedCourier = ko.observable(demax.inspections.nomenclature.Courier.SPEEDY);
	this.selectedCourierServiceType = ko.observable(demax.inspections.nomenclature.CourierServiceType.STANDARD);
	this.selectedCourierDeliveryType = ko.observable(demax.inspections.nomenclature.CourierDeliveryType.DOOR_TO_DOOR);
	this.selectedCourierDeliveryTime = ko.observable(moment(new Date()));
	this.isDeliveryTimeValid = ko.observable();

	this.packetsCount = ko.observable().extend({
		required: true,
		min: 1,
		max : {
			onlyIf : function() {
				return self.selectedCourier().code == demax.inspections.nomenclature.Courier.SPEEDY.code;
			},
			params: 10
		}
	});

	this.weightKg = ko.observable().extend({
		required: true,
		min: 1
	});

	this.init = function(params) {
		subscriptions.push(self.permitNumber.subscribe(function(newValue) {
			if (newValue) {
				loadPermitShippingInfo(newValue);
			} else {
				self.permitShippingInfo(new demax.inspections.model.equipment.consumable.PermitShippingInfo({}));
				self.permitShippingInfoErrorMessage(undefined);
			}
		}));
		
		if (params.permitNumber) {
			self.permitNumber(params.permitNumber);
		}
	};

	this.getCurrentSelectedPermitHref = function() {
		if (self.permitShippingInfo() && self.permitShippingInfo().permitId) {
			return "#/consumables/supplies/permits/" + self.permitShippingInfo().permitId;
		}
	};

	this.createBillOfLading= function() {
		var validationErrors = ko.validation.group([self.permitNumber, self.tonersCount, self.drumsCount, self.selectedCourierDeliveryType,
			self.packetsCount, self.weightKg]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			demax.inspections.popupManager.warn("Има невалидни полета!");
			return;
		}
		var permitShippingInfoErrors = ko.validation.group([self.permitShippingInfo().address,
			self.permitShippingInfo().recipientPersonName, self.permitShippingInfo().recipientPersionPhone,
			self.permitShippingInfo().ktpCityName]);
		if (ko.unwrap(permitShippingInfoErrors()).length > 0) {
			demax.inspections.popupManager.warn("Информацията за получател липсва или е непълна.");
			return;
		}
		var requestDto = createRequestDto();
		restClient.postResource(URL.CONSUMABLE_TRANSFERS, JSON.stringify(requestDto))
			.done(function() {
				demax.inspections.popupManager.success({message: "Успешно създадохте заявка за изпращане на консумативи."}).done(function() {
					window.location.href = "#/consumables/requests";
				});
			}).handleErrors({
				BillOfLadingRequestSpeedyOrEcontInSameCityException: function() {
					demax.inspections.popupManager.error("Не може да бъде създадена заявка към Спиди или Еконт за град София!");
				},
				ConsumableBillOfLadingWithStatusNotSentExistsForPermitException: function() {
					demax.inspections.popupManager.error("Заявка в статус \"Неизпратена\" вече съществува за Разрешение №" 
							+ self.permitNumber());
				}
			});
	};

	function loadPermitShippingInfo(permitNumber) {
		self.isLoadingPermitShippmentInfo(true);
		var url = pastel.util.StringHelper.format(URL.PERMIT_SHIPPING_INFO, permitNumber);
		restClient.getResource(url).done(function(resp) {
			self.permitShippingInfoErrorMessage(null);
			self.permitShippingInfo(new demax.inspections.model.equipment.consumable.PermitShippingInfo(resp));
		}).handleErrors({
			NoSuchEntityException: function() {
				self.permitShippingInfoErrorMessage("Разрешението не е намерено");
			},
			PermitIsNotValidException: function() {
				self.permitShippingInfoErrorMessage("Разрешението е невалидно!");
			},
			PermitHasNoAdditionalInfoException: function() {
				self.permitShippingInfoErrorMessage("Разрешението няма информация за получател!");
			}
		}).fail(function() {
			self.permitShippingInfo(new demax.inspections.model.equipment.consumable.PermitShippingInfo());
		}).always(function() {
			self.isLoadingPermitShippmentInfo(false);
		});
	}

	function createRequestDto() {
		var permitShippingInfo = self.permitShippingInfo() ? self.permitShippingInfo().toDto() : null;
		var deliveryType = self.selectedCourierDeliveryType() ? self.selectedCourierDeliveryType().code : null;
		var courierCode = self.selectedCourier() ? self.selectedCourier().code : null;
		var courierServiceTypeCode = self.selectedCourierServiceType() ? self.selectedCourierServiceType().code : null;
		var fixedTimeDelivery = self.selectedCourierDeliveryTime() ? self.selectedCourierDeliveryTime()
			.format(demax.inspections.settings.serverTimeFormat) : null;
		var cartridgesCount = self.tonersCount() ? parseInt(self.tonersCount()) : 0;
		var drumsCount = self.drumsCount() ? parseInt(self.drumsCount()) : 0;
		var packetsCount = self.packetsCount() ? parseInt(self.packetsCount()) : null;
		var weightKg= self.weightKg() ? parseInt(self.weightKg()) : null;

		return {
			permitShippingInfo: permitShippingInfo,
			deliveryType: deliveryType,
			courierCode: courierCode,
			courierServiceTypeCode: courierServiceTypeCode,
			cartridgesCount: cartridgesCount,
			drumsCount: drumsCount,
			fixedTimeDelivery: fixedTimeDelivery,
			packetsCount: packetsCount,
			weightKg: weightKg
		};
	}

	this.dispose = function() {
		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();
	};
};
