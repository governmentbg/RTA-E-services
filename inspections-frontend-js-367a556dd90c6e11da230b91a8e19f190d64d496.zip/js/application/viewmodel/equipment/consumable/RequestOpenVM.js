namespace("demax.inspections.viewmodel.equipment.consumable");

demax.inspections.viewmodel.equipment.consumable.RequestOpenVM = function() {
	var self = this;
	var restClient = demax.inspections.restClient;

	var URL = {
		CONSUMABLE_TRANSFERS: "api/consumable-transfers/"
	};

	this.isLoading = restClient.isLoading;

	this.loadedBillOfLading = ko.observable();

	this.init = function(params) {
		loadRequestById(params.id);
	};

	function loadRequestById(id) {
		restClient.getResource(URL.CONSUMABLE_TRANSFERS + id)
			.done(function(resp) {
				self.loadedBillOfLading(new demax.inspections.model.equipment.consumable.ConsumableTransferBillOfLadingDto(resp));
			});
	}

	this.printBillOfLadingPdf = function() {
		if (self.loadedBillOfLading().hasBolPdf()) {
			var id = self.loadedBillOfLading().id;
			var url = "api/bills-of-lading/" + id + "/pdf";
			window.open(url);
		}
	};
};
