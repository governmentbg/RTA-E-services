namespace("demax.inspections.viewmodel.equipment.consumable");

demax.inspections.viewmodel.equipment.consumable.RequestsListVM = function() {
	var self = this;
	var subscriptions = [];
	var restClient = demax.inspections.restClient;
	var URL = {
		CONSUMABLE_TRANSFERS: "api/consumable-transfers/",
		CONSUMABLE_TRANSFERS_SEND_BOL: "api/consumable-transfers/bill-of-ladings/{0}/sent",
		CONSUMABLE_TRANSFERS_SEND_ALL: "api/consumable-transfers/bill-of-ladings",
		BILL_OF_LADING_PRINT_PDF : "api/bills-of-lading/{0}/pdf",
		BILL_OF_LADING_CANCEL: "api/bills-of-lading/{0}/cancel"
	};
	var BolStatus = demax.inspections.nomenclature.BillOfLadingStatus;
	var ConsumableRequestsSearchFilters = demax.inspections.model.equipment.consumable.ConsumableRequestsSearchFilters;

	var thisNamespace = ".consumableRequestsListVm";

	this.isLoading = restClient.isLoading;
	this.isSendingBol = ko.observable(false).extend({
		rateLimit: {timeout: 250, method: "notifyWhenChangesStop"}
	});

	this.openedBillOfLadingDetails = ko.observable(null);
	this.isShowingOpenedBillOfLadingDetails = ko.observable(false);
	this.requests = ko.observableArray([]);
	this.requestsCount = ko.observable();
	this.statusOptions = ko.observableArray(BolStatus.WITHOUT_REQUESTED);
	this.filters = new ConsumableRequestsSearchFilters();

	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: 10
	});

	this.init = function() {
		demax.inspections.logger("initing RequestsListVM");

		restoreMemento();
		loadRequests();

		subscriptions.push(self.pagination.queryParamsObject.subscribe(function() {
			self.filters.loadLastUsedFilters();
			loadRequests();
		}));

		demax.inspections.events.subscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	};

	this.performNewSearch = function() {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadRequests();
		} else {
			self.pagination.page(1);
		}
	};
	
	this.refresh = function() {
		self.filters.loadLastUsedFilters();
		loadRequests();
	};
	
	this.openBillOfLadingDetails = function(data) {
		loadBillOfLadingById(data.id);
	};

	this.getViewRequestHref = function(data) {
		return "#/consumables/requests/" + data.id;
	};

	this.closeOpenedBillOfLadingDetails = function() {
		self.isShowingOpenedBillOfLadingDetails(false);
		self.openedBillOfLadingDetails(null);
	};

	this.sendAllBillOfLadings = function() {
		restClient.postResource(URL.CONSUMABLE_TRANSFERS_SEND_ALL)
			.done(function() {
				loadRequests();
			});
	};

	this.sendBillOfLading = function() {
		var id = self.openedBillOfLadingDetails().id;
		var url = pastel.util.StringHelper.format(URL.CONSUMABLE_TRANSFERS_SEND_BOL, id);
		self.isSendingBol(true);
		restClient.postResource(url)
			.done(function() {
				loadRequests();
			})
			.always(function() {
				self.isShowingOpenedBillOfLadingDetails(false);
				self.isSendingBol(false);
			});
	};

	this.printBillOfLadingPdf = function(data) {
		var url = pastel.util.StringHelper.format(URL.BILL_OF_LADING_PRINT_PDF, data.id);
		window.open(url);
	};

	this.cancelBillOfladingPdf = function(data) {
		var url = pastel.util.StringHelper.format(URL.BILL_OF_LADING_CANCEL, data.id);
		restClient.patchResource(url)
			.done(function() {
				loadRequests();
			});
	};

	function loadRequests() {
		var pageParams = self.pagination.queryParamsObject();
		var searchParams = self.filters.toQueryParams();
		var params = $.extend({}, pageParams, searchParams);
		
		self.requestsCount(0);
		self.requests([]);
		restClient.getResource(URL.CONSUMABLE_TRANSFERS, params)
			.done(function(resp) {
				self.requests(ko.utils.arrayMap(resp.items, function(dto) {
					return new demax.inspections.model.equipment.consumable.RequestListItem(dto);
				}));
				self.requestsCount(resp.totalCount);
			});
	}

	function loadBillOfLadingById(id) {
		restClient.getResource(URL.CONSUMABLE_TRANSFERS + id)
			.done(function(resp) {
				self.isShowingOpenedBillOfLadingDetails(true);
				self.openedBillOfLadingDetails(new demax.inspections.model.equipment.consumable.ConsumableTransferBillOfLadingDto(resp));
			});
	}

	function onEnter() {
		var isLoading = self.isLoading();

		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}
			if (memento.filterParams.receiver) {
				self.filters.receiver(memento.filterParams.receiver);
			}
			if (memento.filterParams.status) {
				self.filters.status(memento.filterParams.status);
			}
			if (memento.filterParams.createdAt) {
				self.filters.createdAt(memento.filterParams.createdAt);
			}
		}
		self.filters.saveLastUsedFilters();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	this.dispose = function() {
		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();

		saveMemento();
		demax.inspections.events.unsubscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace);
	};
};
