namespace("demax.inspections.viewmodel.equipment.hardware");

demax.inspections.viewmodel.equipment.hardware.AddHardwareVM = function() {
	var self = this;
	var subscriptions = [];
	var restClient = demax.inspections.restClient;

	var DeviceType = demax.inspections.nomenclature.equipment.hardware.DeviceType;
	var Warehouse = demax.inspections.nomenclature.Warehouse;

	this.availableWarehouses = Warehouse.AVAILABLE_WHEN_CREATING_HARDWARE;

	this.deviceTypes = DeviceType.ALLOWED_FOR_CREATION;

	this.params = ko.validatedObservable(new demax.inspections.model.equipment.hardware.HardwareCreationParams(), {deep: true});

	this.isLoading = restClient.isLoading;

	this.init = function() {
		subscriptions.push(self.params().deviceType.subscribe(function() {
			self.params().reset();
		}));
	};

	this.addHardware = function() {
		if (!self.params.isValid()) {
			self.params.errors.showAllMessages();
			return;
		}
		demax.inspections.restClient.postResource("api/hardware-devices", self.params().toJsonRequest())
			.done(function() {
				demax.inspections.popupManager.success({ message:"Успешно добавено ново устройство."}).done(function() {
					demax.inspections.router.setHash("hardware/devices");
				}).fail(function() {
					demax.inspections.router.setHash("hardware/devices");
					
				});
			}).handleErrors({
				HardwareDeviceWithSerialNumberAlreadyExistsException: function() {
					demax.inspections.popupManager.error(self.params().deviceType().description
							+ " със сериен номер " + self.params().serialNumber() + " вече съществува!");
				}, HardwareDeviceMacAddressNotSpecifiedException: function() {
					demax.inspections.popupManager.error("Полето MAC адрес е задължително за това устройство.");
				}
			});
	};
	this.dispose = function() {
		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
	};
};
