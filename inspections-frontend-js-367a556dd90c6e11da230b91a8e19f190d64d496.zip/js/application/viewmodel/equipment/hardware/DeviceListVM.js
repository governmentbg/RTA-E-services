namespace("demax.inspections.viewmodel.equipment.hardware");

demax.inspections.viewmodel.equipment.hardware.DeviceListVM = function() {
	var self = this;
	var subscriptions = [];
	var DeviceLocationType = demax.inspections.nomenclature.equipment.hardware.DeviceLocationType;
	var HardwareDeviceSearchFilters = demax.inspections.model.equipment.hardware.HardwareDeviceSearchFilters;
	var URL = {
		DEVICES: "api/hardware-devices",
		DEVICES_EXCEL: "api/hardware-devices/xls"
	};
	var restClient = demax.inspections.restClient;

	var thisNamespace = ".hardwareDeviceListVm";

	this.isLoading = restClient.isLoading;

	this.pageSizes = [20, 50, 100];
	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: self.pageSizes[0]
	});

	this.locationTypes = [DeviceLocationType.WAREHOUSE, DeviceLocationType.INSPECTION_POINT];
	this.orgUnits = ko.observableArray();
	this.devices = ko.observable(0);
	this.devicesCount = ko.observable();

	this.filters = new HardwareDeviceSearchFilters();

	this.getViewHardwareHref = function(data) {
		return "#/hardware/devices/edit/" + data.id + "/" + data.type.code;
	};

	this.init = function() {
		loadOrgUnits().done(function() {
			restoreMemento();
			loadDevices();
		});

		subscriptions.push(self.filters.locationType.subscribe(function(newValue) {
			if (newValue == self.locationTypes[0]) {
				self.filters.orgUnit(null);
			} else if (newValue == self.locationTypes[1]) {
				self.filters.warehouse(null);
			} else {
				self.filters.warehouse(null);
				self.filters.orgUnit(null);
			}
		}));
		
		subscriptions.push(self.pagination.queryParamsObject.subscribe(function() {
			self.filters.loadLastUsedFilters();
			loadDevices();
		}));

		demax.inspections.events.subscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	};

	this.performNewSearch = function() {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadDevices();
		} else {
			self.pagination.page(1);
		}
	};

	this.refresh = function() {
		self.filters.loadLastUsedFilters();
		loadDevices();
	};

	this.exportExcel = function() {
		var queryParams = ko.unwrap(self.filters.toQueryParams());
		var urlQueryParams = $.param(queryParams);

		window.open(URL.DEVICES_EXCEL + "?" + urlQueryParams);
	};

	this.goToPermitDetails = function(device) {
		demax.inspections.router.setHash("permits/details/" + device.permit.id, { isTechinspPermit: true });
	};

	function loadOrgUnits() {
		return demax.inspections.nomenclature.NomenclatureService.getOrgUnitsWithoutIaaa()
			.done(function(response) {
				self.orgUnits(ko.utils.arrayMap(response, function(orgUntDto) {
					return new demax.inspections.model.OrgUnit(orgUntDto);
				}));
			});
	}

	function loadDevices() {
		var pageParams = self.pagination.queryParamsObject();
		var searchParams = self.filters.toQueryParams();
		var params = $.extend({}, pageParams, searchParams);

		self.devices([]);
		self.devicesCount(0);
		restClient.getResource(URL.DEVICES, params)
			.done(function(response) {
				self.devices(ko.utils.arrayMap(response.items, function(deviceDto) {
					return new demax.inspections.model.equipment.hardware.HardwareDeviceListItem(deviceDto);
				}));
				self.devicesCount(response.totalCount);
			});
	}

	function onEnter() {
		var isLoading = self.isLoading();

		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}
			if (memento.filterParams.type) {
				self.filters.type(memento.filterParams.type);
			}
			if (memento.filterParams.status) {
				self.filters.status(memento.filterParams.status);
			}
			if (memento.filterParams.locationType) {
				self.filters.locationType(memento.filterParams.locationType);
			}
			if (memento.filterParams.warehouse) {
				self.filters.warehouse(memento.filterParams.warehouse);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(self.orgUnits.find("code", memento.filterParams.orgUnit));
			}
		}
		self.filters.saveLastUsedFilters();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	this.dispose = function() {
		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});

		saveMemento();
		demax.inspections.events.unsubscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace);
	};
};
