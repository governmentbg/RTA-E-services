namespace("demax.inspections.viewmodel.equipment.hardware");

demax.inspections.viewmodel.equipment.hardware.DeviceTransferCreationVM = function() {
	var self = this;

	var URL = {
		HARDWARE_DEVICE_TRANSFERS: "api/hardware-device-transfers",
		HARDWARE_DEVICE_TRANSFERS_PDF: "api/hardware-device-transfers/{0}/pdf",
		WAREHOUSE_SHIPPING_INFO: "api/warehouses/{0}/shipping-info",
		DEVICES_BY_SERIAL_NUMBER: "api/hardware-devices/{0}"
	};
	var restClient = demax.inspections.restClient;

	var subscriptions = [];

	this.isLoading = restClient.isLoading;

	this.barcodeToCheck = ko.observable().extend({notify: "always"});

	this.selectedWarehouse = ko.observable().extend({
		required: true
	});
	this.selectedWarehouseShippingInfo = ko.observable(new demax.inspections.model.equipment.hardware.WarehouseShippingInfo());
	this.isEditingSelectedWarehouseShippingInfoRecipientName = ko.observable(false);
	this.selectedWarehouseShippingInfoRecipientNameEditValue = ko.observable().extend({
		required: true
	});
	this.isEditingSelectedWarehouseShippingInfoRecipientPhone = ko.observable(false);
	this.selectedWarehouseShippingInfoRecipientPhoneEditValue = ko.observable().extend({
		required: true
	});

	this.selectedCourier = ko.observable(demax.inspections.nomenclature.Courier.SPEEDY);
	this.selectedCourierServiceType = ko.observable(demax.inspections.nomenclature.CourierServiceType.STANDARD);
	this.selectedCourierDeliveryType = ko.observable(demax.inspections.nomenclature.CourierDeliveryType.DOOR_TO_DOOR);
	this.selectedCourierDeliveryTime = ko.observable(moment(new Date()));
	this.isDeliveryTimeValid = ko.observable();

	this.packetsCount = ko.observable().extend({
		required: true,
		min: 1,
		max : {
			onlyIf : function() {
				return self.selectedCourier().code == demax.inspections.nomenclature.Courier.SPEEDY.code;
			},
			params: 10
		}
	});

	this.weightKg = ko.observable().extend({
		required: true,
		min: 1
	});

	this.hardwareDevices = ko.observableArray().extend({
		required: true,
		minLength: 1
	});

	this.disabledCouriers = ko.pureComputed(function() {
		var disabledCouriers = [];
		var selectedWarehouse = ko.unwrap(self.selectedWarehouse);
		if (selectedWarehouse) {
			disabledCouriers = selectedWarehouse.disabledCouriers;
		}
		return disabledCouriers;
	});

	this.init = function() {
		subscriptions.push(self.selectedWarehouse.subscribe(function(newWarehouse) {
			if (newWarehouse) {
				self.isEditingSelectedWarehouseShippingInfoRecipientName(false);
				self.selectedWarehouseShippingInfoRecipientNameEditValue("");
				self.isEditingSelectedWarehouseShippingInfoRecipientPhone(false);
				self.selectedWarehouseShippingInfoRecipientPhoneEditValue("");
				loadWarehouseShippingInfo(newWarehouse.id);
			} else {
				self.selectedWarehouseShippingInfo(null);
			}
		}));

		self.barcodeScannerMannager = new pastel.plus.util.BarcodeScannerManager({
			minBarcodeLength: 5,
			canScanLetters: true,
			nameSpace: "DeviceTransferCreationVM",
			scannerInputStorer: self.barcodeToCheck
		});
		self.barcodeScannerMannager.start();

		subscriptions.push(self.barcodeToCheck.subscribe(function(newValue) {
			addScannedBarcode(newValue);
		}));
		self.addHardwareDevice();
	};

	this.addHardwareDevice = function() {
		var hardwareDevice = new demax.inspections.model.equipment.hardware.HardwareDeviceItem();
		self.hardwareDevices.push(hardwareDevice);
		return hardwareDevice;
	};

	this.removeHardwareDevice = function(hardwareDevice) {
		if (ko.unwrap(self.hardwareDevices).length < 1) {
			return;
		}
		self.hardwareDevices.remove(hardwareDevice);
	};

	this.toggleEditingOfSelectedWarehouseShippingInfoRecipientName = function() {
		var warehouseShippintInfo = ko.unwrap(self.selectedWarehouseShippingInfo);
		self.isEditingSelectedWarehouseShippingInfoRecipientName(!ko.unwrap(self.isEditingSelectedWarehouseShippingInfoRecipientName));
		if (ko.unwrap(self.isEditingSelectedWarehouseShippingInfoRecipientName)) {
			self.selectedWarehouseShippingInfoRecipientNameEditValue(ko.unwrap(warehouseShippintInfo.recipientPersonName));
			self.selectedWarehouseShippingInfoRecipientNameEditValue.isModified(false);
		}
	};

	this.toggleEditingOfSelectedWarehouseShippingInfoRecipientPhone = function() {
		var warehouseShippintInfo = ko.unwrap(self.selectedWarehouseShippingInfo);
		self.isEditingSelectedWarehouseShippingInfoRecipientPhone(!ko.unwrap(self.isEditingSelectedWarehouseShippingInfoRecipientPhone));
		if (ko.unwrap(self.isEditingSelectedWarehouseShippingInfoRecipientPhone)) {
			self.selectedWarehouseShippingInfoRecipientPhoneEditValue(ko.unwrap(warehouseShippintInfo.recipientPersonPhone));
			self.selectedWarehouseShippingInfoRecipientPhoneEditValue.isModified(false);
		}
	};

	this.acceptSelectedWarehouseShippingInfoRecipientNameEditValue = function() {
		var validationErrors = ko.validation.group([self.selectedWarehouseShippingInfoRecipientNameEditValue]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			demax.inspections.popupManager.warn("Невалидно име");
			return;
		}
		var editedName = ko.unwrap(self.selectedWarehouseShippingInfoRecipientNameEditValue);
		var warehouseShippintInfo = ko.unwrap(self.selectedWarehouseShippingInfo);
		warehouseShippintInfo.recipientPersonName(editedName);
		self.toggleEditingOfSelectedWarehouseShippingInfoRecipientName();
	};

	this.acceptSelectedWarehouseShippingInfoRecipientPhoneEditValue = function() {
		var validationErrors = ko.validation.group([self.selectedWarehouseShippingInfoRecipientPhoneEditValue]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			demax.inspections.popupManager.warn("Невалиден телефон");
			return;
		}
		var editedPhone = ko.unwrap(self.selectedWarehouseShippingInfoRecipientPhoneEditValue);
		var warehouseShippintInfo = ko.unwrap(self.selectedWarehouseShippingInfo);
		warehouseShippintInfo.recipientPersonPhone(editedPhone);
		self.toggleEditingOfSelectedWarehouseShippingInfoRecipientPhone();
	};

	this.loadDevicesBySerialNumber = function(serialNumber, originalHardwareDevice) {
		var deferred = $.Deferred();
		if (!ko.unwrap(originalHardwareDevice.isUpdatable)) {
			deferred.reject();
			return deferred;
		}
		restClient.getResource(pastel.util.StringHelper.format(URL.DEVICES_BY_SERIAL_NUMBER, serialNumber))
			.done(function(response) {
				if (response.totalCount == 1) {
					var deviceOption = new demax.inspections.model.equipment.hardware.HardwareDeviceOption(response.items[0]);
					self.hardwareDeviceOptionSelected(deviceOption, originalHardwareDevice);
					deferred.reject();
				} else if (response.totalCount < 1) {
					deferred.resolve([]);
				} else {
					var deviceOptions = ko.utils.arrayMap(response.items, function(deviceDto) {
						return new demax.inspections.model.equipment.hardware.HardwareDeviceOption(deviceDto);
					});
					deferred.resolve(deviceOptions);
				}
			}).fail(function() {
				deferred.reject();
			});
		return deferred;
	};

	this.hardwareDeviceOptionSelected = function(selectedDeviceOption, originalHardwareDevice) {
		if (originalHardwareDevice) {
			var hardwareDevice = null;
			$.each(ko.unwrap(self.hardwareDevices), function(i, device) {
				var deviceId = ko.unwrap(device.id);
				var deviceTypeCode = ko.unwrap(device.type) ? ko.unwrap(device.type).code : null;
				if (deviceId == ko.unwrap(selectedDeviceOption.id)
						&& deviceTypeCode == selectedDeviceOption.type.code) {
					hardwareDevice = device;
					return false;
				}
			});
			if (hardwareDevice) {
				demax.inspections.popupManager.warn("Устройството вече е добавено в списъка!");
			} else {
				originalHardwareDevice.updateFromOption(selectedDeviceOption);
			}
		}
	};

	var isCreateDeliveryTransferProtocol = false;

	this.canCreateAndPrint = ko.pureComputed(function() {
		return self.isDeliveryTimeValid();
	});

	this.createAndPrintDeliveryTransferProtocol = function() {
		if (!self.canCreateAndPrint()) {
			return;
		}

		var validationErrors = ko.validation.group([self.hardwareDevices, self.selectedWarehouse, self.selectedWarehouseShippingInfo,
			self.selectedCourierDeliveryType, self.packetsCount, self.weightKg]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			self.selectedWarehouseShippingInfoRecipientNameEditValue.isModified(true);
			self.selectedWarehouseShippingInfoRecipientPhoneEditValue.isModified(true);
			demax.inspections.popupManager.warn("Има невалидни полета!");
			return;
		}

		if (shouldHaveSpeedyOfficeAddress() && !isValidSpeedyOfficeAddress()) {
			demax.inspections.popupManager.warn("Невалиден адрес за офис на Спиди!");
			return;
		}

		if (isCreateDeliveryTransferProtocol) {
			return;
		}
		isCreateDeliveryTransferProtocol = true;

		var requestDto = createRequestDto();

		restClient.postResource(URL.HARDWARE_DEVICE_TRANSFERS, JSON.stringify(requestDto))
			.done(function(response) {
				var pdfUrl = pastel.util.StringHelper.format(URL.HARDWARE_DEVICE_TRANSFERS_PDF, response.id);
				demax.inspections.popupManager.success({
					okButtonText: "Разпечатай протокол",
					message: "Протоколът е създаден успешно."
				}).done(function() {
					window.open(pdfUrl);
					demax.inspections.router.setHash("hardware/device-transfers");
				});
			}).handleErrors({
				HardwareDeviceIsAtInspectionStationException: function(error, errorObject) {
					if (errorObject.deviceId) {
						demax.inspections.popupManager.error("Устройство със сериен номер " + errorObject.serialNumber
							+ " се намира в пункт за прегледи.");
					} else if (errorObject.simCardId) {
						demax.inspections.popupManager.error("Сим карта със сериен номер " + errorObject.serialNumber
							+ " се намира в пункт за прегледи.");
					}
				},
				HardwareDeviceIsNotAtWarehouseTsarigradskoShoseException: function(error, errorObject) {
					if (errorObject.deviceId) {
						demax.inspections.popupManager.error("Устройство със сериен номер " + errorObject.serialNumber
							+ " не се намира в София Цариградско шосе голям или малък склад.");
					} else if (errorObject.simId) {
						demax.inspections.popupManager.error("Сим карта със сериен номер " + errorObject.serialNumber
							+ " не се намира в София Цариградско шосе голям или малък склад.");
					}
				},
				InvalidHardwareDeviceLocationException: function(error, errorObject) {
					if (errorObject.deviceId) {
						demax.inspections.popupManager.error("Устройство със сериен номер " + errorObject.serialNumber
							+ " има невалидно местоположение!");
					} else if (errorObject.simCardId) {
						demax.inspections.popupManager.error("Сим карта със сериен номер " + errorObject.serialNumber
							+ " има невалидно местоположение!");
					}
				},
				BillOfLadingRequestSpeedyOrEcontInSameCityException: function() {
					demax.inspections.popupManager.error("Не може да бъде създадена заявка към Спиди или Еконт за град София!");
				}
			}).always(function() {
				isCreateDeliveryTransferProtocol = false;
			});
	};

	function createRequestDto() {
		var warehouseShippingInfo = ko.unwrap(self.selectedWarehouseShippingInfo) ?
			ko.unwrap(self.selectedWarehouseShippingInfo).toDto() : null;
		var deliveryType = ko.unwrap(self.selectedCourierDeliveryType) ? ko.unwrap(self.selectedCourierDeliveryType).code : null;
		var courierCode = ko.unwrap(self.selectedCourier) ? ko.unwrap(self.selectedCourier).code : null;
		var courierServiceTypeCode = ko.unwrap(self.selectedCourierServiceType) ? ko.unwrap(self.selectedCourierServiceType).code : null;
		var packetsCount = ko.unwrap(self.packetsCount) ? ko.unwrap(self.packetsCount) : null;
		var weightKg = ko.unwrap(self.weightKg) ? ko.unwrap(self.weightKg) : null;

		var hardwareDevices = [];
		$.each(ko.unwrap(self.hardwareDevices), function(i, hardwareDevice) {
			hardwareDevices.push({
				id: ko.unwrap(hardwareDevice.id),
				typeCode: ko.unwrap(hardwareDevice.type) ? ko.unwrap(hardwareDevice.type).code : null
			});
		});

		return {
			warehouseShippingInfo: warehouseShippingInfo,
			deliveryType: deliveryType,
			courierCode: courierCode,
			courierServiceTypeCode: courierServiceTypeCode,
			packetsCount: packetsCount,
			weightKg: weightKg,
			devices: hardwareDevices,
			fixedTimeDelivery: self.selectedCourierDeliveryTime().format(demax.inspections.settings.serverTimeFormat)
		};
	}

	this.isLoadingWarehouseShippingInfo = ko.observable(false).extend({
		rateLimit: { timeout: 250, method: "notifyWhenChangesStop" }
	});

	function addScannedBarcode(barcode) {
		var hasUpdatableItem = false;
		$.each(self.hardwareDevices(), function(index, value) {
			if (value.isUpdatable()) {
				value.serialNumber("");
				value.serialNumber(barcode);
				hasUpdatableItem = true;
				return false;
			}
		});
		if (!hasUpdatableItem) {
			var hardwareDeviceItem = self.addHardwareDevice();
			if (hardwareDeviceItem.hasComponentLoaded()) {
				hardwareDeviceItem.serialNumber(barcode);
			} else {
				subscriptions.push(hardwareDeviceItem.hasComponentLoaded.subscribe(function() {
					hardwareDeviceItem.serialNumber(barcode);
				}));
			}
		}
	}

	function loadWarehouseShippingInfo(warehouseId) {
		self.isLoadingWarehouseShippingInfo(true);
		restClient.getResource(pastel.util.StringHelper.format(URL.WAREHOUSE_SHIPPING_INFO, warehouseId))
			.done(function(warehouseShippingInfo) {
				self.selectedWarehouseShippingInfo(new demax.inspections.model.equipment.hardware.WarehouseShippingInfo(warehouseShippingInfo));
			}).fail(function() {
				self.selectedWarehouseShippingInfo(new demax.inspections.model.equipment.hardware.WarehouseShippingInfo());
			}).always(function() {
				self.isLoadingWarehouseShippingInfo(false);
			});
	}

	function shouldHaveSpeedyOfficeAddress() {
		if (self.selectedCourier().code == demax.inspections.nomenclature.Courier.SPEEDY.code
				&& self.selectedCourierDeliveryType().code == demax.inspections.nomenclature.CourierDeliveryType.DOOR_TO_OFFICE.code) {
			return true;
		}
		return false;
	}

	function isValidSpeedyOfficeAddress() {
		if (self.selectedWarehouseShippingInfo().speedyOfficeAddress.length < 5) {
			return false;
		}
		return true;
	}

	this.dispose = function() {
		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();
		self.barcodeScannerMannager.dispose();
	};
};
