namespace("demax.inspections.viewmodel.equipment.hardware");

demax.inspections.viewmodel.equipment.hardware.EditHardwareVM = function() {
	var self = this;

	var DeviceStatus = demax.inspections.nomenclature.equipment.hardware.DeviceStatus;
	var restClient = demax.inspections.restClient;

	this.hardwareDevice = ko.observable(null);
	this.isLoading = restClient.isLoading;
	this.isEditing = ko.observable(false);
	this.warehouses = demax.inspections.nomenclature.Warehouse.ALL;
	this.statuses = ko.observableArray([]);
	this.params = ko.validatedObservable(new demax.inspections.model.equipment.hardware.HardwareEditParams({}), {deep: true});
	this.tempIpAddress = ko.observable();
	this.tempWarehouse = ko.observable();

	this.canBeEdited = ko.pureComputed(function() {
		if (self.hardwareDevice() == null || self.hardwareDevice().location == null) {
			return false;
		}
		return (self.hardwareDevice().status.id == "4" 
				|| self.hardwareDevice().status.id == "2"
				|| self.hardwareDevice().status.id == "1")
			&& self.hardwareDevice().location.code == "С";
	});

	this.init = function(params) {
		loadHardwareDevice(params.id, params.code);
	};

	this.saveChanges = function() {
		if (!self.params.isValid()) {
			self.params.errors.showAllMessages();
			return;
		}
		var url = pastel.util.StringHelper.format("api/hardware-devices/{0}", self.hardwareDevice().id);
		restClient.patchResource(url, self.params().toJsonRequest()).done(function() {
			loadHardwareDevice(self.hardwareDevice().id, self.hardwareDevice().deviceType.code);
			self.isEditing(false);
		}).handleErrors({
			HardwareDeviceUpdateException: function() {
				demax.inspections.popupManager.error("Проблем с запазването на промените.");
			}
		});
	};

	this.editHardware = function() {
		self.isEditing(true);
		self.params(new demax.inspections.model.equipment.hardware.HardwareEditParams(self.hardwareDevice()));
	};

	this.cancelEditing = function() {
		self.isEditing(false);
	};

	function loadHardwareDevice(id, code) {
		var url = pastel.util.StringHelper.format("api/hardware-devices/{0}/{1}", id, code);
		restClient.getResource(url).done(function(resp) {
			self.hardwareDevice(new demax.inspections.model.equipment.hardware.HardwareDevice(resp));
			self.params(new demax.inspections.model.equipment.hardware.HardwareEditParams(self.hardwareDevice()));
			if (self.hardwareDevice().status == DeviceStatus.FOR_REPAIR) {
				self.statuses(DeviceStatus.EDITABLE_STATUSES_WHEN_IN_FOR_REPAIR);
			} else if (self.hardwareDevice().status == DeviceStatus.AVAILABLE) {
				self.statuses(DeviceStatus.EDITABLE_STATUSES_WHEN_IN_AVAILABLE);
			}
		});
	}
};
