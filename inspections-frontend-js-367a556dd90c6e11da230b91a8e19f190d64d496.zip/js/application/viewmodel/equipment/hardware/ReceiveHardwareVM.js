namespace("demax.inspections.viewmodel.equipment.hardware");

demax.inspections.viewmodel.equipment.hardware.ReceiveHardwareVM = function() {
	var self = this;
	var subscriptions = [];
	var URL = {
		RECEIVE_HARDWARE_DEVICES: "api/warehouses/{0}/hardware-devices",
		DEVICES_BY_SERIAL_NUMBER: "api/hardware-devices/{0}"
	};
	var restClient = demax.inspections.restClient;

	this.isLoading = restClient.isLoading;
	
	this.barcodeToCheck = ko.observable().extend({notify: "always"});

	this.selectedWarehouse = ko.observable().extend({
		required: true
	});

	this.hardwareDevices = ko.observableArray().extend({
		required: true,
		minLength: 1
	});

	this.init = function() {
		self.barcodeScannerMannager = new pastel.plus.util.BarcodeScannerManager({
			minBarcodeLength: 5,
			canScanLetters: true,
			nameSpace: "ReceiveHardwareVM",
			scannerInputStorer: self.barcodeToCheck
		});
		self.barcodeScannerMannager.start();
		
		subscriptions.push(self.barcodeToCheck.subscribe(function(newValue) {
			addScannedBarcode(newValue);
		}));
		self.addHardwareDevice();
	};

	this.addHardwareDevice = function() {
		var hardwareDevice = new demax.inspections.model.equipment.hardware.HardwareDeviceItem();
		self.hardwareDevices.push(hardwareDevice);
		return hardwareDevice;
	};

	this.removeHardwareDevice = function(hardwareDevice) {
		if (ko.unwrap(self.hardwareDevices).length < 2) {
			return;
		}
		self.hardwareDevices.remove(hardwareDevice);
	};

	this.loadDevicesBySerialNumber = function(serialNumber, originalHardwareDevice) {
		var deferred = $.Deferred();
		if (!ko.unwrap(originalHardwareDevice.isUpdatable)) {
			deferred.reject();
			return deferred;
		}
		restClient.getResource(pastel.util.StringHelper.format(URL.DEVICES_BY_SERIAL_NUMBER, serialNumber))
			.done(function(response) {
				if (response.totalCount == 1) {
					var deviceOption = new demax.inspections.model.equipment.hardware.HardwareDeviceOption(response.items[0]);
					self.hardwareDeviceOptionSelected(deviceOption, originalHardwareDevice);
					deferred.reject();
				} else if (response.totalCount < 1) {
					deferred.resolve([]);
				} else {
					var deviceOptions = ko.utils.arrayMap(response.items, function(deviceDto) {
						return new demax.inspections.model.equipment.hardware.HardwareDeviceOption(deviceDto);
					});
					deferred.resolve(deviceOptions);
				}
			}).fail(function() {
				deferred.reject();
			});
		return deferred;
	};

	this.hardwareDeviceOptionSelected = function(selectedDeviceOption, originalHardwareDevice) {
		if (originalHardwareDevice) {
			var hardwareDevice = null;
			$.each(ko.unwrap(self.hardwareDevices), function(i, device) {
				var deviceId = ko.unwrap(device.id);
				var deviceTypeCode = ko.unwrap(device.type) ? ko.unwrap(device.type).code : null;
				if (deviceId == ko.unwrap(selectedDeviceOption.id)
						&& deviceTypeCode == selectedDeviceOption.type.code) {
					hardwareDevice = device;
					return false;
				}
			});
			if (hardwareDevice) {
				demax.inspections.popupManager.warn("Устройството вече е добавено в списъка!");
			} else {
				originalHardwareDevice.updateFromOption(selectedDeviceOption);
			}
		}
	};

	var isReceivingHardwareDevices = false;

	this.receiveHardwareDevices = function() {
		var validationErrors = ko.validation.group([self.hardwareDevices, self.selectedWarehouse]);

		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			demax.inspections.popupManager.warn("Има невалидни полета!");
			return;
		}

		if (isReceivingHardwareDevices) {
			return;
		}
		isReceivingHardwareDevices = true;

		var requestDto = createRequestDto();

		var warehouseId = ko.unwrap(self.selectedWarehouse) ? ko.unwrap(self.selectedWarehouse).id : null;
		var url = pastel.util.StringHelper.format(URL.RECEIVE_HARDWARE_DEVICES, warehouseId);
		restClient.putResource(url, JSON.stringify(requestDto))
			.done(function() {
				demax.inspections.popupManager.info("Устройствата са приети успешно.")
					.done(function() {
						demax.inspections.router.setHash("hardware/devices");
					});
			}).handleErrors({
				HardwareDeviceIsAtInspetionStationException: function(error, errorObject) {
					if (errorObject.deviceId) {
						demax.inspections.popupManager.error("Устройство със сериен номер " + errorObject.serialNumber
							+ " се намира в пункт за прегледи.");
					} else if (errorObject.simЪьиаId) {
						demax.inspections.popupManager.error("Сим карта със сериен номер " + errorObject.serialNumber
							+ " се намира в пункт за прегледи.");
					}
				},
				HardwareDeviceIsAlreadyInThisWarehouseException: function(error, errorObject) {
					if (errorObject.deviceId) {
						demax.inspections.popupManager.error("Устройство със сериен номер " + errorObject.serialNumber
							+ " вече се намира в Склад Цариградско шосе малък или голям.");
					} else if (errorObject.simId) {
						demax.inspections.popupManager.error("Сим карта със сериен номер " + errorObject.serialNumber
							+ " вече се намира в Склад Цариградско шосе малък или голям.");
					}
				}
			}).always(function() {
				isReceivingHardwareDevices = false;
			});
	};

	function createRequestDto() {
		var hardwareDevices = [];
		$.each(ko.unwrap(self.hardwareDevices), function(i, hardwareDevice) {
			hardwareDevices.push({
				id: ko.unwrap(hardwareDevice.id),
				typeCode: ko.unwrap(hardwareDevice.type) ? ko.unwrap(hardwareDevice.type).code : null
			});
		});

		return {
			hardwareDevices: hardwareDevices
		};
	}
	
	function addScannedBarcode(barcode) {
		var hasUpdatableItem = false;
		$.each(self.hardwareDevices(), function(index, value) {
			if (value.isUpdatable()) {
				value.serialNumber("");
				value.serialNumber(barcode);
				hasUpdatableItem = true;
				return false;
			}
		});
		if (!hasUpdatableItem) {
			var hardwareDeviceItem = self.addHardwareDevice();
			if (hardwareDeviceItem.hasComponentLoaded()) {
				hardwareDeviceItem.serialNumber(barcode);
			} else {
				subscriptions.push(hardwareDeviceItem.hasComponentLoaded.subscribe(function() {
					hardwareDeviceItem.serialNumber(barcode);
				}));	
			}
		}
	}
	
	this.dispose = function() {
		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();
		self.barcodeScannerMannager.dispose();
	};
};
