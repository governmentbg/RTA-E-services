namespace("demax.inspections.viewmodel.equipment.hardware");

demax.inspections.viewmodel.equipment.hardware.RequestsListVM = function() {
	var self = this;
	var subscriptions = [];
	var BolStatus = demax.inspections.nomenclature.BillOfLadingStatus;
	var Warehouse = demax.inspections.nomenclature.Warehouse;
	var HardwareDeviceTransferSearchFilters = demax.inspections.model.equipment.hardware.HardwareDeviceTransferSearchFilters;
	var URL = {
		HARDWARE_DEVICE_TRANSFERS: "api/hardware-device-transfers/",
		HARDWARE_DEVICE_TRANSFERS_SENT_BILL_OF_LADING: "api/hardware-device-transfers/bill-of-ladings/{0}/sent",
		BILLS_OF_LADING_PRINT_PDF : "api/bills-of-lading/{0}/pdf"
	};
	var restClient = demax.inspections.restClient;

	var thisNamespace = ".hardwareRequestsListVm";

	this.isLoading = restClient.isLoading;
	this.isSendingBol = ko.observable(false).extend({
		rateLimit: {timeout: 250, method: "notifyWhenChangesStop"}
	});

	this.openedBillOfLadingDetails = ko.observable(null);
	this.isShowingOpenedBillOfLadingDetails = ko.observable(false);
	this.requests = ko.observableArray([]);
	this.requestsCount = ko.observable();
	this.warehouseOptions = Warehouse.POSSIBLE_HARDWARE_RECEIVERS;
	this.statusOptions = ko.observableArray(BolStatus.WITHOUT_REQUESTED);
	this.filters = new HardwareDeviceTransferSearchFilters();
	
	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: 10
	});

	this.init = function() {
		demax.inspections.logger("initing RequestListVM");
		
		restoreMemento();
		loadRequests();

		subscriptions.push(self.pagination.queryParamsObject.subscribe(function() {
			self.filters.loadLastUsedFilters();
			loadRequests();
		}));

		demax.inspections.events.subscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	};
	
	this.performNewSearch = function() {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadRequests();
		} else {
			self.pagination.page(1);
		}
	};

	this.refresh = function() {
		self.filters.loadLastUsedFilters();
		loadRequests();
	};

	this.openBillOfLadingDetails = function(data) {
		loadRequestById(data.id);
	};

	this.getViewRequestHref = function(data) {
		return "#/hardware/device-transfers/" + data.id;
	};

	this.closeOpenedBillOfLadingDetails = function() {
		self.isShowingOpenedBillOfLadingDetails(false);
		self.openedBillOfLadingDetails(null);
	};

	this.sendBillOfLading = function() {
		self.isSendingBol(true);
		var id = self.openedBillOfLadingDetails().id;
		var url = pastel.util.StringHelper.format(URL.HARDWARE_DEVICE_TRANSFERS_SENT_BILL_OF_LADING, id);

		restClient.postResource(url)
			.done(function() {
				loadRequests();
			})
			.always(function() {
				self.isShowingOpenedBillOfLadingDetails(false);
				self.isSendingBol(false);
			});
	};

	this.printBillOfLadingPdf = function(data) {
		var url = pastel.util.StringHelper.format(URL.BILLS_OF_LADING_PRINT_PDF, data.id);
		window.open(url);
	};

	this.cancelBillOfLading = function(billOfLading) {
		restClient.patchResource("api/bills-of-lading/" + billOfLading.id + "/cancel").done(function() {
			loadRequests();
		});
	};

	function loadRequests() {
		var pageParams = self.pagination.queryParamsObject();
		var searchParams = self.filters.toQueryParams();
		var requestParams = $.extend({}, pageParams, searchParams);

		restClient.getResource(URL.HARDWARE_DEVICE_TRANSFERS, requestParams)
			.done(function(response) {
				self.requests(ko.utils.arrayMap(response.items, function(dto) {
					return new demax.inspections.model.equipment.hardware.HardwareDeviceTransferRequestListItem(dto);
				}));
				self.requestsCount(response.totalCount);
			});
	}

	function loadRequestById(id) {
		restClient.getResource(URL.HARDWARE_DEVICE_TRANSFERS + id)
			.done(function(resp) {
				self.isShowingOpenedBillOfLadingDetails(true);
				self.openedBillOfLadingDetails(new demax.inspections.model.equipment.hardware.HardwareDeviceTransferBillOfLadingDto(resp));
			});
	}

	function onEnter() {
		var isLoading = self.isLoading();

		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}
			if (memento.filterParams.warehouse) {
				self.filters.warehouse(memento.filterParams.warehouse);
			}
			if (memento.filterParams.createdAt) {
				self.filters.createdAt(memento.filterParams.createdAt);
			}
			if (memento.filterParams.status) {
				self.filters.status(memento.filterParams.status);
			}
		}
		self.filters.saveLastUsedFilters();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	this.dispose = function() {
		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();

		saveMemento();
		demax.inspections.events.unsubscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace);
	};
};
