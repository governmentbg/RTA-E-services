namespace("demax.inspections.viewmodel.equipment.hardware");

demax.inspections.viewmodel.equipment.hardware.ViewRequestVM = function() {
	var self = this;
	var restClient = demax.inspections.restClient;
	var URL = {
		HARDWARE_DEVICE_TRANSFERS: "api/hardware-device-transfers/",
		HARDWARE_DEVICE_TRANSFERS_PDF: "api/hardware-device-transfers/{0}/pdf"
	};

	this.isLoading = restClient.isLoading;
	this.loadedBillOfLading = ko.observable();

	this.init = function(params) {
		loadRequestById(params.id);
	};

	function loadRequestById(id) {
		restClient.getResource(URL.HARDWARE_DEVICE_TRANSFERS + id)
			.done(function(resp) {
				self.loadedBillOfLading(new demax.inspections.model.equipment.hardware.HardwareDeviceTransferBillOfLadingDto(resp));
			});
	}

	this.printBillOfLadingPdf = function() {
		if (self.loadedBillOfLading().hasBolPdf()) {
			var id = self.loadedBillOfLading().id;
			var url = "api/bills-of-lading/" + id + "/pdf";
			window.open(url);
		}
	};

	this.printProtocolPdf = function() {
		var id = self.loadedBillOfLading().protocols[0].id;
		var pdfUrl = pastel.util.StringHelper.format(URL.HARDWARE_DEVICE_TRANSFERS_PDF, id);
		window.open(pdfUrl);
	};
};
