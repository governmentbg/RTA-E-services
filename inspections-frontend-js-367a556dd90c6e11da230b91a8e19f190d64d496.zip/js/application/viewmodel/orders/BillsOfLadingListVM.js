namespace("demax.inspections.viewmodel.orders");

demax.inspections.viewmodel.orders.BillsOfLadingListVM = function() {
	var self = this;
	var URL = {
		BILLS_OF_LADING: "api/inspection-bills-of-lading/"
	};
	var restClient = demax.inspections.restClient;
	var BolStatus = demax.inspections.nomenclature.BillOfLadingStatus;
	var BillOfLadingLight = demax.inspections.model.orders.BillOfLadingLight;
	var BillOfLadingSearchFilters = demax.inspections.model.orders.BillOfLadingSearchFilters;
	var InspectionBillOfLading = demax.inspections.model.orders.InspectionBillOfLading;
	var subscriptions = [];

	var thisNamespace = ".billsOfLadingListVM";
	
	this.billsOfLading = ko.observableArray();
	this.statusOptions = pastel.plus.util.toArray(BolStatus);
	this.orgUnits = ko.observableArray();
	this.totalBillsOfLadingCount = ko.observable(0);
	this.openedBillOfLading = ko.observable(null);
	this.isShowingOpenedBillOfLading = ko.observable(false);

	this.filters = new BillOfLadingSearchFilters();

	this.hasTriedLoading = ko.observable(false);
	this.isLoading = restClient.isLoading;

	this.pagination = new pastel.plus.component.pagination.Pagination({
		orderBy: "id",
		direction: "desc",
		page: 1,
		pageSize: 27
	});

	this.getBillOfLadingHref = function(billOfLading) {
		return "#/bill-of-lading/" + billOfLading.id;
	};

	this.createDailyBillsOfLading = function() {
		restClient.postResource(URL.BILLS_OF_LADING + "daily")
			.always(function() {
				loadBillsOfLading();
			});
	};

	this.cancelBillOfLading = function(billOfLading) {
		restClient.patchResource("api/bills-of-lading/" + billOfLading.id + "/cancel").done(function() {
			loadBillsOfLading();
		});
	};

	this.init = function() {
		subscriptions.push(self.isShowingOpenedBillOfLading.subscribe(function(isShowingBol) {
			if (!isShowingBol) {
				self.openedBillOfLading(null);
			}
		}));

		loadOrgUnits().done(function() {
			restoreMemento();
			loadBillsOfLading();
		});
		
		subscriptions.push(self.pagination.queryParamsObject.subscribe(function() {
			self.filters.loadLastUsedFilters();
			loadBillsOfLading();
		}));

		demax.inspections.events.subscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	};
	
	this.performNewSearch = function() {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadBillsOfLading();
		} else {
			self.pagination.page(1);
		}
	};
	
	this.refresh = function() {
		self.filters.loadLastUsedFilters();
		loadBillsOfLading();
	};

	this.openBillOfLadingDetails = function(billOfLading) {
		loadBillOfLading(billOfLading.id).done(function() {
			self.isShowingOpenedBillOfLading(true);
		});
	};

	this.closeOpenedBillOfLadingDetails = function() {
		self.isShowingOpenedBillOfLading(false);
	};

	this.sendAndPrintBillOfLading = function() {
		var bolId = self.openedBillOfLading().id;
		var url = URL.BILLS_OF_LADING + bolId + "/send";
		demax.inspections.restClient.putResource(url).done(function() {
			var bolInList = ko.utils.arrayFirst(self.billsOfLading(), function(bol) {
				return bol.id == bolId;
			});
			bolInList.status(demax.inspections.nomenclature.BillOfLadingStatus.SENT);
			self.isShowingOpenedBillOfLading(false);
		}).handleErrors({
			BillOfLadingStatusMismatchException: function() {
				demax.inspections.popupManager.warn("Товарителницата трябва да бъде със статус \"неизпратена\".");
			}
		});
	};

	this.printBillOfLadingPdf = function(billOfLading) {
		var url = "api/bills-of-lading/" + billOfLading.id + "/pdf";
		return demax.inspections.blobClient.openBlob(url);
	};

	function loadBillOfLading(billOfLadingId) {
		var url = URL.BILLS_OF_LADING + billOfLadingId;
		return demax.inspections.restClient.getResource(url).done(function(inspectionBolDto) {
			self.openedBillOfLading(new InspectionBillOfLading(inspectionBolDto));
		});
	}

	function loadOrgUnits() {
		return demax.inspections.nomenclature.NomenclatureService.getOrgUnitsWithoutIaaa().done(function(response) {
			self.orgUnits(ko.utils.arrayMap(response, function(orgUnitDto) {
				return new demax.inspections.model.OrgUnit(orgUnitDto);
			}));
		});
	}

	function loadBillsOfLading() {
		var pageParams = self.pagination.queryParamsObject();
		var searchParams = self.filters.toQueryParams();
		var params = $.extend({}, pageParams, searchParams);
		
		self.billsOfLading([]);
		self.totalBillsOfLadingCount(0);
		return restClient.getResource(URL.BILLS_OF_LADING, params).done(function(response) {
			self.billsOfLading.removeAll();
			self.billsOfLading(ko.utils.arrayMap(response.items, function(value) {
				return new BillOfLadingLight(value);
			}));
			self.totalBillsOfLadingCount(response.totalCount);
		}).always(function() {
			self.hasTriedLoading(true);
		});
	}

	function onEnter() {
		var isLoading = self.isLoading(); 

		if (isLoading) {
			return;
		}

		self.performNewSearch();	
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(self.orgUnits.find("code", memento.filterParams.orgUnit));
			}
			if (memento.filterParams.date) {
				self.filters.date(memento.filterParams.date);
			}
			if (memento.filterParams.status) {
				self.filters.status(memento.filterParams.status);
			}
		}
		self.filters.saveLastUsedFilters();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	this.dispose = function() {
		saveMemento();

		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();

		demax.inspections.events.unsubscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace);
	};
};
