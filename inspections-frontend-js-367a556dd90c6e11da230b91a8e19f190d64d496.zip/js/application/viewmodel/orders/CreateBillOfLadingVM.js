namespace("demax.inspections.viewmodel.orders");

demax.inspections.viewmodel.orders.CreateBillOfLadingVM = function() {
	var self = this;
	var subscriptions = [];
	var currentWentAndPackageCountEstimationXHR = null;
	var popupManager = demax.inspections.popupManager;
	var restClient = demax.inspections.restClient;

	var URL = {
		INSPECTION_BILLS_OF_LADING: "api/inspection-bills-of-lading/"
	};

	this.orgUnitOptions = ko.observableArray([]);
	this.selectedOrgUnit = ko.observable(null);
	this.selectedCourier = ko.observable(demax.inspections.nomenclature.Courier.SPEEDY);
	this.selectedCourierServiceType = ko.observable(demax.inspections.nomenclature.CourierServiceType.EXPRESS);
	this.selectedCourierDeliveryTime = ko.observable(moment(new Date()));	
	this.isDeliveryTimeValid = ko.observable();
	
	this.hasMadeWeightError = ko.observable(false);
	this.hasMadePackageCountError = ko.observable(false);

	this.estimatedWeight = ko.observable(0);
	this.estimatedPackageCount = ko.observable(0);

	this.isLoading = restClient.isLoading;

	this.bolWeight = ko.observable().extend({
		number: true,
		min: 1,
		required: true
	});

	this.packageCount = ko.observable().extend({
		digit: true,
		min: 1,
		required: true
	});

	this.init = function(params) {
		demax.inspections.logger("initing CreateBillOfLadingVM");
		
		loadOrgUnits(params.orgUnitCode);

		subscriptions.push(self.selectedOrgUnit.subscribe(function(newSelectedOrgUnit) {
			if (newSelectedOrgUnit !== null && newSelectedOrgUnit !== undefined) {
				getEstimatedWeightAndPackageCountForOrgUnit(newSelectedOrgUnit.code);
			}
		}));

		subscriptions.push(self.bolWeight.subscribe(function() {
			self.hasMadeWeightError(!self.bolWeight.isValid());
		}));

		subscriptions.push(self.packageCount.subscribe(function() {
			self.hasMadePackageCountError(!self.packageCount.isValid());
		}));

	};

	this.canClickCreate = ko.pureComputed(function() {
		var isWeightValid = self.bolWeight.isValid();
		var isPackageCountValid = self.packageCount.isValid();
		var isLoading = self.isLoading();

		var selectedOrgUnit = self.selectedOrgUnit();
		var isOrgUnitValid = selectedOrgUnit !== null && selectedOrgUnit !== undefined;
		var isDeliveryTimeValid = self.isDeliveryTimeValid();
		
		return isWeightValid && isPackageCountValid && isOrgUnitValid && !isLoading && isDeliveryTimeValid;
	});

	this.createInspectionBillOfLading = function() {
		if (!self.isDeliveryTimeValid()) {
			return;
		}
		var data = {
			courierCode: self.selectedCourier().code,
			courierServiceTypeCode: self.selectedCourierServiceType().code,
			orgUnitCode: self.selectedOrgUnit().code,
			weight: parseFloat(self.bolWeight(), 10),
			packageCount: parseInt(self.packageCount(), 10),
			fixedTimeDelivery: self.selectedCourierDeliveryTime().format(demax.inspections.settings.serverTimeFormat)
		};

		restClient.postResource(URL.INSPECTION_BILLS_OF_LADING, JSON.stringify(data)).done(function() {
			demax.inspections.router.setHash("#/bills-of-lading-list");
		}).handleErrors({
			UnsentBillOfLadingsException: function() {
				popupManager.warn("Има неизпратени товарителници от минали дни.");
			},
			BillOfLadingAlreadyExistsException: function() {
				popupManager.warn("Вече съществува товарителница за днес за избраната организационна единица.");
			}
		});
	};

	function getEstimatedWeightAndPackageCountForOrgUnit(orgUnitCode) {
		var data = {
			orgUnitCode: orgUnitCode
		};

		var url = URL.INSPECTION_BILLS_OF_LADING + "expected-org-unit-weight-and-package-count";

		self.estimatedWeight(0);
		self.estimatedPackageCount(0);

		if (currentWentAndPackageCountEstimationXHR !== null) {
			currentWentAndPackageCountEstimationXHR.abort();
		}

		currentWentAndPackageCountEstimationXHR = restClient.getResource(url, data).done(function(resp) {
			self.estimatedWeight(resp.weight);
			self.bolWeight(resp.weight);

			self.estimatedPackageCount(resp.packageCount);
			self.packageCount(resp.packageCount);
		});
	}

	function loadOrgUnits(preselectedOrgUnitCode) {
		
		demax.inspections.nomenclature.NomenclatureService.getOrgUnitsWithoutIaaa().done(function(resp) {
			self.orgUnitOptions(ko.utils.arrayMap(resp, function(orgUntOptionDto) {
				return new demax.inspections.model.OrgUnit(orgUntOptionDto);
			}));
			
			if (preselectedOrgUnitCode != null && preselectedOrgUnitCode != undefined) {
				self.orgUnitOptions().forEach(function(orgUnit) {
					if (orgUnit.code == preselectedOrgUnitCode) {
						self.selectedOrgUnit(orgUnit);
						return;
					}
				});
			}
		});
	}

	this.dispose = function() {
		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();
	};

};
