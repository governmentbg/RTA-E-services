namespace("demax.inspections.viewmodel.orders");

demax.inspections.viewmodel.orders.ExamOrderVM = function() {
	var self = this;

	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;

	var CONTROLLER_ADDRESS = "api/exam-orders/";
	var ORDER_API_ADDRESS = null;

	var ExamOrder = demax.inspections.model.orders.ExamOrder;
	var ExamOrderStatus = demax.inspections.nomenclature.orders.ExamOrderStatus;
	var Role = demax.inspections.nomenclature.Role;
	var Courier = demax.inspections.nomenclature.Courier;
	var Group = demax.inspections.nomenclature.Group;
	var BillOfLadingLight = demax.inspections.model.orders.BillOfLadingLight;

	var authenticatedUser = demax.inspections.authenticatedUser();

	var popupManager = demax.inspections.popupManager;

	this.examOrderId = ko.observable();
	this.isExamOrderNotFound = ko.observable(false);
	this.supervisorComponent = ko.observable(null);

	this.order = ko.observable(null);
	this.selectedCourier = ko.observable(Courier.SPEEDY);
	this.selectedCourierServiceType = ko.observable(demax.inspections.nomenclature.CourierServiceType.EXPRESS);
	this.selectedCourierDeliveryTime = ko.observable(moment(new Date()));
	this.isPackagingVouchersRole = authenticatedUser.roles.indexOf(Role.PACKAGING_VOUCHERS) > -1;
	this.isDeliveryTimeValid = ko.observable();

	this.isLoading = ko.pureComputed(function() {
		return restClient.isLoading() || blobClient.isLoading();
	});

	this.init = function(params) {
		demax.inspections.logger("initing ExamOrderVM");
		self.examOrderId(params.id);
		ORDER_API_ADDRESS = CONTROLLER_ADDRESS + params.id + "/";
		loadExamOrder(params.id);
	};

	this.editIntervals = function(orderIntervalsGroup) {
		orderIntervalsGroup.intervalsCopy = ko.observableArray([]);
		orderIntervalsGroup.hasError = ko.observable(false);
		orderIntervalsGroup.isEditingIntervals(true);
	};

	this.saveIntervals = function(orderIntervalsGroup) {
		if (orderIntervalsGroup.hasError()) {
			return;
		}

		var supervisorComponentTitle = "Запазване на редактираните интервали";
		self.supervisorComponent().getCredentials(supervisorComponentTitle).done(function(credentials) {
			var url = CONTROLLER_ADDRESS + self.order().id + "/intervals/supervisor";
			var data = {
				intervals: orderIntervalsGroup.intervalsCopy().map(function(interval) {
					return interval.toDto();
				})
			};

			$.extend(data, credentials);
			demax.inspections.restClient.patchResource(url, JSON.stringify(data)).done(function() {
				loadExamOrder(self.order().id);
			}).always(function() {
				orderIntervalsGroup.isEditingIntervals(false);
			});
			orderIntervalsGroup.intervalsCopy([]);
			orderIntervalsGroup.intervalsCopy = undefined;
		});
	};

	this.cancelEditing = function(orderIntervalsGroup) {
		orderIntervalsGroup.isEditingIntervals(false);
		orderIntervalsGroup.intervalsCopy = undefined;
	};

	this.printBillOfLading = function(bolDemaxDbId) {
		var url = "api/bills-of-lading/" + bolDemaxDbId + "/pdf";

		blobClient.downloadBlob(url).handleErrors({
			InvalidBillOfLadingIdException: function() {
				popupManager.warn("Невалидна товарителница подадена за печатане.");
			}
		});
	};

	this.sendAndPrintBillOfLading = function() {
		if (!self.canSaveAndPrint()) {
			return;
		}

		var data = {
			courierCode: self.selectedCourier().code,
			courierServiceTypeCode: self.selectedCourierServiceType().code,
			fixedTimeDelivery: self.selectedCourierDeliveryTime().format(demax.inspections.settings.serverTimeFormat)
		};

		var url = ORDER_API_ADDRESS + "bill-of-lading";

		restClient.postResource(url, JSON.stringify(data))
			.done(function(bolDto) {
				var bol = new BillOfLadingLight(bolDto);
				self.order().billOfLading(bol);
				self.order().status(ExamOrderStatus.SEND);

				if (self.selectedCourier() != Courier.DEMAX) {
					self.printBillOfLading(bol.id);
				}
			}).handleErrors({
				ExamOrderProductMismatchException: function() {
					popupManager.error("В поръчката няма ваучери за практически изпит.");
				},
				ExamOrderStatusMismatchException: function() {
					popupManager.error("Поръчката не е със статус \"платена\".");
				}
			});
	};

	this.isOrderPaid = ko.pureComputed(function() {
		return self.order() !== undefined ? self.order().status() === ExamOrderStatus.PAID : false;
	});

	this.intervalsText = ko.pureComputed(function() {
		var text = "Интервали";
		var expectedText = text + " (предполагаеми)";
		return self.order() !== undefined && !self.order().areIntervalsApproximate() ? text : expectedText;
	});

	this.canViewBankStatement = ko.pureComputed(function() {
		var orderStatus = self.order && self.order() && self.order().status();

		var isSuitableStatus = orderStatus === ExamOrderStatus.PAID || orderStatus === ExamOrderStatus.SEND;
		var hasBankStatement = self.order() !== null ? self.order().hasBankStatement : false;
		var hasPermissionToViewBankStatement = authenticatedUser.isUserOfGroup(Group.BANK_STATEMENT_VIEWER);

		return isSuitableStatus && hasBankStatement && hasPermissionToViewBankStatement;
	});

	this.isEditingIntervals = ko.pureComputed(function() {
		var isEditing = false;
		self.order().examOrderItems.forEach(function(orderItem) {
			isEditing |= orderItem.isEditingIntervals();
		});

		return isEditing;
	});

	this.canSaveAndPrint = ko.pureComputed(function() {
		var order = self.order();
		var courier = self.selectedCourier();
		var courierService = self.selectedCourierServiceType();
		if (order === null) {
			return false;
		}

		if (!self.isDeliveryTimeValid()) {
			return false;
		}
		var hasCourier = courier !== null;
		var hasCourierServiceType = courierService !== null;
		var hasAllIntervals = order.doAllOrderItemsHaveAllIntervals();
		var hasPermissionToSend = authenticatedUser.isUserOfGroup(Group.VOUCHER_SENDER);
		var isOrderPaid = self.isOrderPaid();
		var isEdittingIntervals = self.isEditingIntervals();

		return hasCourier
			&& hasCourierServiceType
			&& hasAllIntervals
			&& hasPermissionToSend
			&& isOrderPaid
			&& !isEdittingIntervals;
	});

	this.isOrderPaidAndUserAuthorizedToSend = ko.pureComputed(function () {
		var order = self.order();
		if (order === null) {
			return false;
		}

		var hasPermissionToSend = authenticatedUser.isUserOfGroup(Group.VOUCHER_SENDER);
		var isOrderPaid = self.isOrderPaid();

		return hasPermissionToSend && isOrderPaid;
	});

	this.canEditIntervals = ko.pureComputed(function () {
		var isOrderPaid = self.isOrderPaid();
		var hasPermissionToEditIntervals = authenticatedUser.isUserOfGroup(Group.EXAM_ORDER_INTERVAL_EDITOR);

		return isOrderPaid && hasPermissionToEditIntervals;
	});

	this.canPrintInvoicePdf = ko.pureComputed(function() {
		var stage = self.order().status().stage;
		var hasStatusPaidOrSent = stage == ExamOrderStatus.PAID.stage || stage == ExamOrderStatus.SEND.stage;
		var hasPermissionToPrintInvoice = authenticatedUser.isUserOfGroup(Group.INVOICE_VIEWER);

		return hasStatusPaidOrSent && hasPermissionToPrintInvoice;
	});

	this.downloadBankStatement = function() {
		if (self.canViewBankStatement()) {
			var url = CONTROLLER_ADDRESS + self.order().id + "/bank-statement/pdf";

			blobClient.downloadBlob(url).handleErrors({
				ExamOrderStatusMismatchException: function() {
					popupManager.warn("Поръчката трябва да бъде със статус платена или изпратена.");
				},
				MissingBankStatementException: function() {
					popupManager.warn("Поръчката няма платежно.");
				}
			});
		}
	};

	this.printInvoicePdf = function() {
		blobClient.downloadBlob(ORDER_API_ADDRESS + "invoice/pdf");
	};

	this.sendButtonText = ko.pureComputed(function() {
		if (self.selectedCourier() == Courier.DEMAX) {
			return "Изпращане";
		} else {
			return "Изпращане и печат на товарителнца";
		}
	});

	this.dispose = function() {
		blobClient.cancelAll();
		restClient.cancelAll();
	};

	function loadExamOrder(id) {
		restClient.getResource(CONTROLLER_ADDRESS + id)
			.done(function(examOrderDto) {
				var order = new ExamOrder(examOrderDto);
				order.examOrderItems.forEach(function(orderItem) {
					orderItem.isEditingIntervals = ko.observable(false);
				});
				self.order(order);
			}).handleErrors({
				NoSuchEntityException: function() {
					self.isExamOrderNotFound(true);
				}
			});
	}
};
