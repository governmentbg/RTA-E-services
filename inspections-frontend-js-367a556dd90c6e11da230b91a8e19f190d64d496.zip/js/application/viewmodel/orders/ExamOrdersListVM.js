namespace("demax.inspections.viewmodel.orders");

demax.inspections.viewmodel.orders.ExamOrdersListVM = function() {
	var self = this;
	var subscriptions = [];
	var URL = {
		EXAM_ORDERS: "api/exam-orders",
		EXAM_ORDER_ID: "api/exam-orders/{0}",
		EXAM_ORDER_CITIES: "api/exam-orders/cities"
	};
	var ExamOrderStatus = demax.inspections.nomenclature.orders.ExamOrderStatus;
	var ExamOrderLight = demax.inspections.model.orders.ExamOrderLight;
	var ExamOrderSearchFilters = demax.inspections.model.orders.ExamOrderSearchFilters;
	var restClient = demax.inspections.restClient;

	var thisNamespace = ".examOrdersListVM";

	this.statusOptions = pastel.plus.util.toArray(ExamOrderStatus).filter(function(examOrderStatus) {
		return demax.inspections.authenticatedUser().isUserOfGroup(examOrderStatus.access);
	});
	this.orders = ko.observableArray();
	this.cities = ko.observableArray();
	this.selectedCityName = ko.observable();
	this.totalOrdersCount = ko.observable(0);
	this.filters = new ExamOrderSearchFilters();

	this.isLoading = restClient.isLoading;
	this.hasTriedLoading = ko.observable(false);

	this.pagination = new pastel.plus.component.pagination.Pagination({
		orderBy: "id",
		direction: "desc",
		page: 1,
		pageSize: 10
	});

	this.getOrderHref = function(order) {
		return "#/exam-order/" + order.id;
	};

	this.init = function() {
		demax.inspections.logger("initing InspectionOrdersListVM");
		
		loadCities().done(function() {
			restoreMemento();
			loadOrders();
		});
		
		subscriptions.push(self.pagination.queryParamsObject.subscribe(function() {
			self.filters.loadLastUsedFilters();
			loadOrders();
		}));

		demax.inspections.events.subscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	};
	
	this.performNewSearch = function() {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadOrders();
		} else {
			self.pagination.page(1);
		}
	};
	
	this.clear = function() {
		self.selectedCityName("");
		self.filters.clear();
	};
	
	
	this.refresh = function() {
		self.filters.loadLastUsedFilters();
		loadOrders();
	};

	function loadCities() {
		return restClient.getResource(URL.EXAM_ORDER_CITIES).done(function(response) {
			self.cities(ko.utils.arrayMap(response, function(cityDto) {
				return new demax.inspections.model.City(cityDto);
			}));
		});
	}

	function loadOrders() {
		var pageParams = self.pagination.queryParamsObject();
		var searchParams = self.filters.toQueryParams();
		var params = $.extend({}, pageParams, searchParams);
		
		self.orders([]);
		self.totalOrdersCount(0);
		return restClient.getResource(URL.EXAM_ORDERS, params).done(function(response) {
			self.orders(ko.utils.arrayMap(response.items, function(orderDto) {
				return new ExamOrderLight(orderDto);
			}));
			self.totalOrdersCount(response.totalCount);
		}).always(function() {
			self.hasTriedLoading(true);
		});
	}

	function onEnter() {
		var isLoading = self.isLoading();

		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}
			if (memento.filterParams.selectedCity) {
				self.filters.selectedCity(memento.filterParams.selectedCity);
			}
			if (memento.filterParams.date) {
				self.filters.date(memento.filterParams.date);
			}
			if (memento.filterParams.status) {
				self.filters.status(memento.filterParams.status);
			}
		}
		self.filters.saveLastUsedFilters();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	this.dispose = function() {
		saveMemento();

		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();

		demax.inspections.events.unsubscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace);
	};
};
