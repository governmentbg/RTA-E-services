namespace("demax.inspections.viewmodel.orders");

demax.inspections.viewmodel.orders.InspectionBillOfLadingVM = function() {
	var self = this;
	var CONTROLLER_ADDRESS = "api/inspection-bills-of-lading/";
	var BOL_API_ADDRESS = null;

	var InspectionBillOfLading = demax.inspections.model.orders.InspectionBillOfLading;
	var restClient = demax.inspections.restClient;

	this.billOfLadingId = ko.observable(null);
	this.isBillOfLadingNotFound = ko.observable(false);
	this.isLoading = restClient.isLoading;
	this.billOfLading = ko.observable(null);

	this.init = function(params) {
		demax.inspections.logger("initing InspectionBillOfLadingVM");
		self.billOfLadingId(params.id);
		BOL_API_ADDRESS = CONTROLLER_ADDRESS + params.id;
		loadBillOfLading();
	};

	this.getProtocolHref = function(protocol) {
		return "#/inspection-order-protocol/" + protocol.id;
	};

	this.printBillOfLading = function() {
		var url ="api/bills-of-lading/" + self.billOfLadingId() + "/pdf";
		demax.inspections.blobClient.openBlob(url);
	};

	function loadBillOfLading() {
		restClient.getResource(BOL_API_ADDRESS).done(function(inspectionBolDto) {
			self.billOfLading(new InspectionBillOfLading(inspectionBolDto));
		}).handleErrors({
			NoSuchEntityException: function() {
				self.isBillOfLadingNotFound(true);
			}
		});
	}

};
