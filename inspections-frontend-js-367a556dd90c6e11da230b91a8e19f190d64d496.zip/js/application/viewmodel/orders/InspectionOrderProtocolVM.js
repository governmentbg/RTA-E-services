namespace("demax.inspections.viewmodel.orders");

demax.inspections.viewmodel.orders.InspectionOrderProtocolVM = function() {
	var self = this;

	var InspectionOrderStatus = demax.inspections.nomenclature.orders.InspectionOrderStatus;
	var InspectionProtocol = demax.inspections.model.orders.InspectionProtocol;
	var restClient = demax.inspections.restClient;

	this.selectedProtocolId = ko.observable("");
	this.protocol = ko.observable(null);
	this.selectedDate = ko.observable(null);
	this.orderStatusOptions = pastel.plus.util.toArray(InspectionOrderStatus).filter(function (inspectionOrderStatus) {
		return inspectionOrderStatus.stage >= InspectionOrderStatus.SEND.stage;				    
	});

	this.selectedOrderStatus = ko.observable(null);
	this.multimatchSearch = ko.observable(null);
	this.isLoading = restClient.isLoading;
	this.isProtocolNotFound = ko.observable(false);

	this.filteredOrders = ko.pureComputed(function() {
		var filteredOrders = [];
		var protocol = self.protocol();
		var multimatchSearch = self.multimatchSearch();
		var selectedDate = self.selectedDate();
		var selectedOrderStatus = self.selectedOrderStatus();

		if (protocol !== null && Array.isArray(protocol.orders)) {
			protocol.orders.forEach(function(order) {
				var multimatchSearchIsMet = true;
				var selectedDateIsMet = true;
				var selectedStatusIsMet = true;

				if (typeof(multimatchSearch) == "string" && multimatchSearch.trim().length > 0) {
					var idMatches = (order.id + "").startsWith(multimatchSearch);
					var eikMatches = (order.eik + "").startsWith(multimatchSearch);
					var companyNameMatches = order.companyName.startsWith(multimatchSearch);
					var permitNumberMatches = (order.permitNumber + "").startsWith(multimatchSearch);

					multimatchSearchIsMet = idMatches || eikMatches || companyNameMatches || permitNumberMatches;
				}

				if (selectedDate !== null && typeof(selectedDate) == "object" && selectedDate._isAMomentObject) {
					selectedDateIsMet = selectedDate.diff(order.createdAt, "days") == 0;
				}

				if (selectedOrderStatus !== null && selectedOrderStatus !== undefined) {
					selectedStatusIsMet = selectedOrderStatus.code == order.status.code;
				}

				if (selectedDateIsMet && selectedStatusIsMet && multimatchSearchIsMet) {
					filteredOrders.push(order);
				}
			});
		}

		return filteredOrders;
	});

	this.init = function(params) {
		demax.inspections.logger("initing InspectionOrderProtocolVM");

		self.selectedProtocolId(params.id);

		loadProtocol();
	};

	this.getOrderHref = function(order) {
		return "#/inspection-order/" + order.id;
	};

	function loadProtocol() {
		restClient.getResource("api/inspection-protocols/" + self.selectedProtocolId()).done(function(resp) {
			self.protocol(new InspectionProtocol(resp));
		}).handleErrors({
			NoSuchEntityException: function() {
				self.isProtocolNotFound(true);
			}
		});
	}
};
