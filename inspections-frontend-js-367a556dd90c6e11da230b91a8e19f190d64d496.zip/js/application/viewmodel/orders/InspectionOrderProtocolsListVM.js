namespace("demax.inspections.viewmodel.orders");

demax.inspections.viewmodel.orders.InspectionOrderProtocolsListVM = function() {
	var self = this;
	
	var subscriptions = [];
	var currentProtocolLoadingXHR = null;
	var InspectionProtocolSearchFilters = demax.inspections.model.orders.InspectionProtocolSearchFilters;
	var InspectionProtocolLight = demax.inspections.model.orders.InspectionProtocolLight;
	var restClient = demax.inspections.restClient;

	var thisNamespace = ".inspectionOrdersProtocolsListVM";

	this.pagination = new pastel.plus.component.pagination.Pagination({
		orderBy: "id",
		direction: "desc",
		page: 1,
		pageSize: 10
	});

	this.isLoading = restClient.isLoading;
	this.hasTriedLoading = ko.observable(false);
	this.deliveryProtocols = ko.observableArray([]);
	this.deliveryProtocolsCount = ko.observable(0);

	this.orgUnitOptions = ko.observableArray([]);
	
	this.filters = new InspectionProtocolSearchFilters();

	this.init = function() {
		demax.inspections.logger("initing InspectionOrderProtocolsListVM");

		loadOrgUnits().done(function() {
			restoreMemento();
			loadProtocols();
		});
		subscriptions.push(self.pagination.queryParamsObject.subscribe(function() {
			self.filters.loadLastUsedFilters();
			loadProtocols();
		}));

		demax.inspections.events.subscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	};

	this.getProtocolHref = function(protocol) {
		return "#/inspection-order-protocol/" + protocol.id;
	};
	
	this.performNewSearch = function() {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadProtocols();
		} else {
			self.pagination.page(1);
		}
	};
	
	this.refresh = function() {
		self.filters.loadLastUsedFilters();
		loadProtocols();
	};

	function loadOrgUnits() {
		return demax.inspections.nomenclature.NomenclatureService.getOrgUnitsWithoutIaaa().done(function(resp) {
			self.orgUnitOptions(ko.utils.arrayMap(resp, function(orgUntOptionDto) {
				return new demax.inspections.model.OrgUnit(orgUntOptionDto);
			}));
		});
	}

	function loadProtocols() {
		var pageParams = self.pagination.queryParamsObject();
		var searchParams = self.filters.toQueryParams();
		var requestParams = $.extend({}, pageParams, searchParams);
		
		self.deliveryProtocols([]);
		self.deliveryProtocolsCount(0);

		if (currentProtocolLoadingXHR !== null) {
			currentProtocolLoadingXHR.abort();
		}

		currentProtocolLoadingXHR = restClient.getResource("api/inspection-protocols", requestParams)
			.done(function(resp) {
				self.deliveryProtocols(ko.utils.arrayMap(resp.items, function(protocolDto) {
					return new InspectionProtocolLight(protocolDto);
				}));
				self.deliveryProtocolsCount(resp.totalCount);
			}).always(function() {
				currentProtocolLoadingXHR = null;
				self.hasTriedLoading(true);
			});
	}

	function onEnter() {
		var isLoading = self.isLoading();

		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.protocolNumber) {
				self.filters.protocolNumber(memento.filterParams.protocolNumber);
			}
			if (memento.filterParams.date) {
				self.filters.date(memento.filterParams.date);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(self.orgUnitOptions.find("code", memento.filterParams.orgUnit));
			}
		}
		self.filters.saveLastUsedFilters();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	this.dispose = function() {
		saveMemento();

		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();

		demax.inspections.events.unsubscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace);
	};
};
