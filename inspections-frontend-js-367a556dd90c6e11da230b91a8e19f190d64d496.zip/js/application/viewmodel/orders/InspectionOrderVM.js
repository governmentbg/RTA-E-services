namespace("demax.inspections.viewmodel.orders");

demax.inspections.viewmodel.orders.InspectionOrderVM = function() {
	var self = this;

	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;

	var CONTROLLER_ADDRESS = "api/inspection-orders/";
	var ORDER_API_ADDRESS = null;
	var popupManager = demax.inspections.popupManager;

	var Group = demax.inspections.nomenclature.Group;
	var Role = demax.inspections.nomenclature.Role;
	var InspectionOrderStatus = demax.inspections.nomenclature.orders.InspectionOrderStatus;
	var InspectionOrder = demax.inspections.model.orders.InspectionOrder;

	var authenticatedUser = demax.inspections.authenticatedUser();

	var thisNamespace = ".inspectionOrderVm";

	this.selectedOrderId = ko.observable(null);
	this.order = ko.observable(null);
	this.isOrderNotFound = ko.observable(false);
	this.isOrderForbiddenForUser = ko.observable(false);
	this.supervisorComponent = ko.observable(null);
	this.weightMeasureComponent = ko.observable(null);
	this.isPackagingInspectionRole = authenticatedUser.isUserOfGroup([Role.PACKAGING_INSPECTIONS]);

	this.orderItemInEditForQuantity = ko.observable(null);
	this.newQuantity = ko.observable(0);

	this.isLoading = ko.pureComputed(function() {
		return restClient.isLoading() || blobClient.isLoading();
	});

	this.init = function(params) {
		demax.inspections.logger("initing InspectionOrderVM");

		self.selectedOrderId(params.id);
		ORDER_API_ADDRESS = CONTROLLER_ADDRESS + self.selectedOrderId() + "/";

		demax.inspections.events.subscribe(demax.inspections.Event.SET_ORDER_PAID, function() {
			if (self.order() !== undefined && self.order().status().code == InspectionOrderStatus.ISSUED.code) {
				loadOrder();
			}
		});

		loadOrder();

		demax.inspections.events.subscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	};

	this.isOrderPaid = ko.pureComputed(function() {
		return self.order() !== null ? self.order().status() === InspectionOrderStatus.PAID : false;
	});

	this.isOrderIssued = ko.pureComputed(function() {
		return self.order() !== null ? self.order().status() === InspectionOrderStatus.ISSUED : false;
	});

	this.hasPermissionToEditQuantity = ko.pureComputed(function() {
		return authenticatedUser.isUserOfGroup(Group.INSPECTION_ORDER_EDITOR);
	});

	this.isOrderSent = ko.pureComputed(function() {
		return self.order !== null ? self.order().status() === InspectionOrderStatus.SEND : false;
	});

	this.shouldShowDeliveryDetails = ko.pureComputed(function() {
		return !self.shouldShowWeightMeasureComponent();
	});

	this.shouldShowWeightMeasureComponent = ko.pureComputed(function() {
		var isOrderPaid = self.isOrderPaid();
		var hasPermissionToSetToLabel = authenticatedUser.isUserOfGroup(Group.INSPECTION_ORDER_LABELER);

		return isOrderPaid && hasPermissionToSetToLabel;
	});

	this.editOrderItemQuantity = function(orderItem) {
		self.orderItemInEditForQuantity(orderItem);
		self.newQuantity(orderItem.quantity());
	};

	this.cancelEditOrderItemQuantity = function() {
		self.orderItemInEditForQuantity(null);
	};

	this.saveOrderItemQuantity = function(orderItem) {
		var newQuantity = self.newQuantity();
		self.orderItemInEditForQuantity(null);

		var url = ORDER_API_ADDRESS + "quantity/call-center";
		var data = {
			quantity: newQuantity,
			productTypeId: orderItem.productId
		};

		restClient.patchResource(url, JSON.stringify(data)).done(function() {
			orderItem.quantity(newQuantity);
		}).handleErrors({
			InspectionOrderStatusMismatchException: function(message) {
				if (message.indexOf("Can only update product quantity for status") > -1) {
					popupManager.error("Може да се сменя количеството само за поръчки със статус \"заявена\".");
				} else if (message.indexOf("Can only change quantity for order which have items for product") > -1) {
					popupManager.error("Поръчката не съдържа продукти от типа, за който се опитвате да промените количеството");
				}
			}
		});
	};

	this.isEditingIntervals = ko.pureComputed(function() {
		var order = self.order();
		if (order === null) {
			return false;
		}

		var isEditing = false;
		order.orderItems.forEach(function(orderItem) {
			isEditing |= orderItem.isEditingIntervals();
		});

		return isEditing;
	});

	this.editIntervals = function(orderIntervalsGroup) {
		orderIntervalsGroup.intervalsCopy = ko.observableArray([]);
		orderIntervalsGroup.hasError = ko.observable(false);
		orderIntervalsGroup.isEditingIntervals(true);
	};

	this.cancelEditing = function(orderIntervalsGroup) {
		orderIntervalsGroup.isEditingIntervals(false);
		orderIntervalsGroup.intervalsCopy = undefined;
	};

	this.saveIntervals = function(orderIntervalsGroup) {
		if (orderIntervalsGroup.hasError()) {
			return;
		}

		var supervisorComponentTitle = "Промяна на интервали";
		self.supervisorComponent().getCredentials(supervisorComponentTitle).done(function(credentials) {
			var url = ORDER_API_ADDRESS + "update-intervals/supervisor";
			var data = {
				intervals: orderIntervalsGroup.intervalsCopy().map(function(interval) {
					return interval.toDto();
				})
			};

			data.productTypeId = orderIntervalsGroup.productId;

			$.extend(data, credentials);
			restClient.patchResource(url, JSON.stringify(data)).done(function() {
				loadOrder();
			}).handleErrors({
				InspectionOrderStatusMismatchException: function() {
					popupManager.error("Интервали могат да се променят само на поръчки със статус \"Платена\".");
				},
				InspectionOrderProductMismatchException: function(message) {
					if (message.indexOf("Can't change intervals.") > -1) {
						popupManager.error("Интервалите за продукта от избрания тип, не могат да бъдат променяни.");
					} else {
						popupManager.error("Поръчката не съдържа продукти от избрания тип.");
					}
				}
			}).always(function() {
				orderIntervalsGroup.isEditingIntervals(false);
			});
			orderIntervalsGroup.intervalsCopy([]);
			orderIntervalsGroup.intervalsCopy = undefined;
		});
	};

	this.setStatusToLabel = function() {
		var weightComponent = self.weightMeasureComponent();
		var data = {
			weight: weightComponent.weight()
		};
		var url = ORDER_API_ADDRESS + "set-status-to-label";

		if (!weightComponent.isWeightValid()) {

			var supervisorComponentTitle = "Печат на етикет, когато теглото не отговаря на очакваните норми";
			self.supervisorComponent().getCredentials(supervisorComponentTitle).done(function(credentials) {
				$.extend(data, credentials);
				setStatusToLabel(url + "/supervisor", data);
			});
		} else {
			setStatusToLabel(url, data);
		}
	};

	this.canSetStatusToLabel = ko.pureComputed(function() {
		var isOrderPaid = self.isOrderPaid();
		var hasPermissionToSetToLabel = authenticatedUser.isUserOfGroup(Group.INSPECTION_ORDER_LABELER);

		return isOrderPaid && hasPermissionToSetToLabel;
	});


	this.hasPermissionToEditIntervals = ko.pureComputed(function() {
		var hasPermissionToEditIntervals = authenticatedUser.isUserOfGroup(Group.INSPECTION_ORDER_INTERVAL_EDITOR);

		return hasPermissionToEditIntervals;
	});
	this.canViewBankStatement = ko.pureComputed(function() {
		// var orderStatus = self.order().status();

		var hasBankStatement = self.order() !== null ? self.order().hasBankStatement : false;
		var hasPermissionToViewBankStatement = authenticatedUser.isUserOfGroup(Group.BANK_STATEMENT_VIEWER);

		return hasBankStatement && hasPermissionToViewBankStatement;
	});

	this.viewBankStatement = function() {
		blobClient.openBlob(ORDER_API_ADDRESS + "bank-statement/pdf").handleErrors({
			MissingBankStatementException: function() {
				popupManager.error("Поръчката няма платежно.");
			}
		});
	};

	this.canPrintLabelPdf = ko.pureComputed(function() {
		var doesOrderHaveLabel = self.order().status().stage >= InspectionOrderStatus.PRINT_LABEL.stage;
		var hasPermissionToPrintLabel = authenticatedUser.isUserOfGroup(Group.INSPECTION_ORDER_LABELER);

		return doesOrderHaveLabel && hasPermissionToPrintLabel;
	});

	this.canPrintInvoicePdf = ko.pureComputed(function() {
		var stage = self.order().status().stage;
		var hasStatusPaidOrSent = stage == InspectionOrderStatus.PAID.stage || stage == InspectionOrderStatus.SEND.stage;
		var hasPermissionToPrintInvoice = authenticatedUser.isUserOfGroup(Group.INVOICE_VIEWER);

		return hasStatusPaidOrSent && hasPermissionToPrintInvoice;
	});

	this.printLabelPdf = function() {
		var resultPromise = $.Deferred();
		getPdfBase64().done(function(base64Pdf) {
			printLabelOnLocalPrinter(base64Pdf).done(function() {
				resultPromise.resolve();
			}).fail(function() {
				resultPromise.reject();
			});
		}).fail(function() {
			resultPromise.reject();
		});

		return resultPromise;
	};

	this.printInvoicePdf = function() {
		blobClient.downloadBlob(ORDER_API_ADDRESS + "invoice/pdf");
	};

	function setStatusToLabel(url, data) {
		if (self.isLoading()) {
			return;	
		}
		restClient.patchResource(url, JSON.stringify(data)).done(function() {
			self.order().status(InspectionOrderStatus.PRINT_LABEL);

			self.printLabelPdf().always(function() {
				demax.inspections.router.setHash("inspection-orders-packaging");
			});
		}).handleErrors({
			InspectionOrderStatusMismatchException: function() {
				popupManager.error("Поръчката трябва да е със статус платена, при смяна на статуса към етикет.");
			},
			OrderWeightException: function() {
				popupManager.error("Теглото не е в допустима норма.");
			}
		});
	}

	function loadOrder() {
		self.order(null);
		restClient.getResource(ORDER_API_ADDRESS).done(function(resp) {
			var order = new InspectionOrder(resp);
			setIsEdittingPropToItems(order.orderItems);
			self.order(order);
		}).handleErrors({
			NoSuchEntityException: function() {
				self.isOrderNotFound(true);
			},
			NoAuthorityException: function() {
				self.isOrderForbiddenForUser(true);
			}
		});
	}

	function setIsEdittingPropToItems(orderItems) {
		orderItems.forEach(function(orderItem) {
			orderItem.isEditingIntervals = ko.observable(false);
		});
	}

	function getPdfBase64() {
		return restClient.getResource(ORDER_API_ADDRESS + "get-label-pdf")
			.handleErrors({
				InspectionOrderStatusMismatchException: function() {
					popupManager.error("Поръчката за принтиране не е със статус етикет.");
				}
			});
	}

	function printLabelOnLocalPrinter(base64Pdf) {
		var data = {
			pdfBytes: base64Pdf
		};

		var url = demax.inspections.settings.peripheralDevicesServerAddress + "/Print";

		return $.post(url, JSON.stringify(data))
			.fail(function() {
				popupManager.error("Грешка при принтирането на етикет към поръчка.");
			});
	}

	function onEnter() {
		var isLoading = self.isLoading();
		var supervisorComponent = self.supervisorComponent();
		var isShowingSupervisorBox = supervisorComponent != null && supervisorComponent.isVisible();
		var canSetStatusToLabel = self.canSetStatusToLabel();

		if (isLoading || isShowingSupervisorBox || !canSetStatusToLabel) {
			return;
		}

		self.setStatusToLabel();
	}

	this.dispose = function () {
		demax.inspections.events.unsubscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace);
		blobClient.cancelAll();
		restClient.cancelAll();
	};
};
