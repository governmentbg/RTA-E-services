namespace("demax.inspections.viewmodel.orders");

demax.inspections.viewmodel.orders.InspectionOrdersListVM = function () {
	var self = this;
	var subscriptions = [];
	var URL = {
		INSPECTION_ORDERS: "api/inspection-orders",
		INSPECTION_ORDERS_ID: "api/inspection-orders/{0}"
	};
	var InspectionOrderStatus = demax.inspections.nomenclature.orders.InspectionOrderStatus;
	var InspectionOrderLight = demax.inspections.model.orders.InspectionOrderLight;
	var InspectionOrderSearchFilters = demax.inspections.model.orders.InspectionOrderSearchFilters;
	var restClient = demax.inspections.restClient;

	var thisNamespace = ".inspectionOrdersListVM";

	this.statusOptions = pastel.plus.util.toArray(InspectionOrderStatus.EVERY_STATUS).filter(function (inspectionOrderStatus) {
		return demax.inspections.authenticatedUser().isUserOfGroup(inspectionOrderStatus.access);
	});

	this.orgUnits = ko.observableArray();
	this.orders = ko.observableArray();
	this.totalOrdersCount = ko.observable(0);
	this.filters = new InspectionOrderSearchFilters();
	this.isLoading = restClient.isLoading;

	this.pagination = new pastel.plus.component.pagination.Pagination({
		orderBy: "id",
		direction: "desc",
		page: 1,
		pageSize: 10
	});

	this.getOrderHref = function (order) {
		return "#/inspection-order/" + order.id;
	};

	this.init = function (params) {
		demax.inspections.logger("initing InspectionOrdersListVM");

		if (params && params.permitNumber
			&& demax.inspections.authenticatedUser().isUserOfGroup([demax.inspections.nomenclature.Role.CALL_CENTER])) {
			self.filters.searchText(params.permitNumber);
		}

		loadOrgUnits().done(function () {
			restoreMemento();
			loadOrders();
		});

		subscriptions.push(self.pagination.queryParamsObject.subscribe(function () {
			self.filters.loadLastUsedFilters();
			loadOrders();
		}));

		demax.inspections.events.subscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	};

	this.performNewSearch = function () {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadOrders();
		} else {
			self.pagination.page(1);
		}
	};

	this.refresh = function () {
		self.filters.loadLastUsedFilters();
		loadOrders();
	};

	function loadOrders() {
		var pageParams = self.pagination.queryParamsObject();
		var searchParams = self.filters.toQueryParams();
		var requestParams = $.extend({}, pageParams, searchParams);

		self.orders([]);
		self.totalOrdersCount(0);
		return restClient.getResource(URL.INSPECTION_ORDERS, requestParams).done(function (response) {
			self.orders(ko.utils.arrayMap(response.items, function (orderDto) {
				return new InspectionOrderLight(orderDto);
			}));
			self.totalOrdersCount(response.totalCount);
		});
	}

	function loadOrgUnits() {
		return demax.inspections.nomenclature.NomenclatureService.getOrgUnitsWithoutIaaa().done(function (orgUnitDtos) {
			self.orgUnits(ko.utils.arrayMap(orgUnitDtos, function (orgUnitDto) {
				return new demax.inspections.model.OrgUnit(orgUnitDto);
			}));
		});
	}

	function onEnter() {
		var isLoading = self.isLoading();

		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(self.orgUnits.find("code", memento.filterParams.orgUnit));
			}
			if (memento.filterParams.date) {
				self.filters.date(memento.filterParams.date);
			}
			if (memento.filterParams.status) {
				self.filters.status(memento.filterParams.status);
			}
		}
		self.filters.saveLastUsedFilters();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	this.dispose = function () {
		saveMemento();

		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();

		demax.inspections.events.unsubscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace);
	};
};
