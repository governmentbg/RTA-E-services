namespace("demax.inspections.viewmodel.orders");

demax.inspections.viewmodel.orders.InspectionOrdersPackagingVM = function() {
	var self = this;
	var URL = {
		INSPECTION_ORDERS: "api/inspection-orders",
		INSPECTION_ORDERS_ID: "api/inspection-orders/{0}",
		INSPECTION_PROTOCOLS: "api/inspection-protocols/",
		INSPECTION_OREDER_ID_PROTOCOL: "api/inspection-orders/{0}/bill-of-lading",
		ORG_UNITS_INSPECTION_ORDERS: "api/org-units/inspection-orders",
		BILL_OF_LADING: "api/bills-of-lading/"
		
	};
	var InspectionOrderLight = demax.inspections.model.orders.InspectionOrderLight;
	var InspectionOrderPackagingSearchFilters = demax.inspections.model.orders.InspectionOrderPackagingSearchFilters;
	var OrgUnit = demax.inspections.model.OrgUnit;
	var restClient = demax.inspections.restClient;
	var popupManager = demax.inspections.popupManager;
	var subscriptions = [];
	var user = demax.inspections.authenticatedUser();	   

	this.paidOrders = ko.observableArray();
	this.labelOrders = ko.observableArray();
	this.orgUnitsInspectionOrders = ko.observableArray();
	this.totalPaidOrdersCount = ko.observable(0);
	this.totalLabelOrdersCount = ko.observable(0);
	this.allOrgUnitsPaidOrdersCount = ko.observable(0);
	this.allOrgUnitsLabelOrdersCount = ko.observable(0);
	
	this.filters = ko.observable(new InspectionOrderPackagingSearchFilters());

	this.isLoadingPaid = ko.observable(false);

	this.isLoadingLabel = ko.observable(false);
	
	this.isLoadingOrgUnits = ko.observable(false);

	this.paginationPaid = new pastel.plus.component.pagination.Pagination({
		orderBy: "id",
		direction: "desc",
		page: 1,
		pageSize: 3
	});

	this.paginationLabel = new pastel.plus.component.pagination.Pagination({
		orderBy: "id",
		direction: "desc",
		page: 1,
		pageSize: 3
	});

	this.canCreateProtocolAndAddToBol = ko.pureComputed(function() {
		var selectedOrgUnit = self.filters().orgUnit();
		var labelOrders = self.labelOrders();
		var isLoading = self.isLoadingLabel();
		var hasSelectedOrgUnit = selectedOrgUnit !== undefined && selectedOrgUnit !== null;
		var hasOrders = Array.isArray(labelOrders) && labelOrders.length > 0;
		var isIaaaSpeedyUser = user.username === "iaaa.speedy";

		return hasSelectedOrgUnit && hasOrders && !isLoading && !isIaaaSpeedyUser;
	});

	this.getOrderHref = function(order) {
		return "#/inspection-order/" + order.id;
	};

	this.init = function() {
		loadOrgUnitsInspectionOrders();
		
		subscriptions.push(self.paginationPaid.queryParamsObject.subscribe(function() {
			loadPaidOrders();
		}));
		
		subscriptions.push(self.paginationLabel.queryParamsObject.subscribe(function() {
			loadLabelOrders();
		}));
		
		subscriptions.push(self.filters().orgUnit.subscribe(function() {
			self.filters().searchText("");
			if (self.paginationLabel.page() == 1) {
				loadLabelOrders();
			} else {
				self.paginationLabel.page(1);
			}
			
			if (self.paginationPaid.page() == 1) {
				loadPaidOrders();
			} else {
				self.paginationPaid.page(1);
			}
		}));
		
		subscriptions.push(self.filters().date.subscribe(function() {
			loadPaidOrders();
		}));
	};
	
	this.performNewSearch = function() {
		if (self.paginationPaid.page() == 1) {
			loadPaidOrders();
		} else {
			self.paginationPaid.page(1);
		}
	};

	this.selectOrgUnit = function(data) {
		self.filters().orgUnit(data.orgUnit);
	};
	
	this.createProtocolAndAddToBol = function() {
		var orgUnit = self.filters().orgUnit();
		var data = {
			orgUnitCode: orgUnit.code
		};
		self.isLoadingLabel(true);
		restClient.postResource(URL.INSPECTION_PROTOCOLS + "org-unit/", JSON.stringify(data)).done(function(protocolId) {
			loadLabelOrders();
			demax.inspections.blobClient.openBlob(URL.INSPECTION_PROTOCOLS + protocolId + "/pdf").always(function() {
				self.isLoadingLabel(false);
			});
		}).handleErrors({
			NoSuchEntityException: function(message) {
				if (message.indexOf("OrgUnit") > -1) {
					popupManager.error("Не съществува организационна единица с код " + orgUnit.code);
				} else if (message.indexOf("InspectionDeliveryProtocolBillOfLading") > -1) {
					popupManager.confirm({
						message: "Няма налична товарителница за  " + orgUnit.name,
						okButtonText: "Създай товарителница",
						cancelButtonText: "Затвори",
						cssClass: "popError",
						okButtonCss: "btn-success"
					}).done(function() {
						demax.inspections.router.setHash("create-bill-of-lading/", {orgUnitCode: self.filters().orgUnit().code});
					});
				}
			},
			InspectionOrderStatusMismatchException: function() {
				popupManager.error("Няма поръчки за " + orgUnit.name + " със статус етикет.");
			}
		}).fail(function() {
			self.isLoadingLabel(false);
		});
	};

	this.createBolAndProtocolForOneOrder = function (data) {

		popupManager.confirm({
			message: "Сигурни ли сте че искате да изпратите поръчката директно към КТП?",
			okButtonText: "Да",
			cancelButtonText: "Не",
			cssClass: "popError",
			okButtonCss: "btn-success"
		}).done(function () {
			var url = pastel.util.StringHelper.format(URL.INSPECTION_OREDER_ID_PROTOCOL, data.id);

			self.isLoadingLabel(true);
			restClient.postResource(url).done(function (dto) {
				loadLabelOrders();
				demax.inspections.blobClient.openBlob(URL.INSPECTION_PROTOCOLS + dto.protocolId + "/pdf").always(function () {
					demax.inspections.blobClient.openBlob(URL.BILL_OF_LADING + dto.billOfLadingId + "/pdf").always(function () {
						self.isLoadingLabel(false);
					});
				});
			}).handleErrors({
				BillOfLadingAlreadyExistsException: function () {
					popupManager.error("Вече има създадена товарителница!");
				},
				InspectionOrderStatusMismatchException: function () {
					popupManager.error("Поръчата не е в статус етикет!");
				}
			}).fail(function () {
				self.isLoadingLabel(false);
			});

		});
	};
		

	function loadOrgUnitsInspectionOrders() {
		self.isLoadingOrgUnits(true);

		return restClient.getResource(URL.ORG_UNITS_INSPECTION_ORDERS).done(function(orgUnitDtos) {
			if (orgUnitDtos.length > 0 && orgUnitDtos[0].orgUnit) {
				if (self.constructor.memento) {
					restoreMemento();
				} else {
					self.filters().orgUnit(new OrgUnit(orgUnitDtos[0].orgUnit));
				}
				var totalPaidOrders = 0;
				var totalLabelOrders = 0;
				self.orgUnitsInspectionOrders(ko.utils.arrayMap(orgUnitDtos, function(orgUnitDto) {
					totalPaidOrders += orgUnitDto.paidInspectionOrdersCount;
					totalLabelOrders += orgUnitDto.labelInspectionOrdersCount;
					return new demax.inspections.model.OrgUnitInspectionOrder(orgUnitDto);
				}));
				self.allOrgUnitsPaidOrdersCount(totalPaidOrders);
				self.allOrgUnitsLabelOrdersCount(totalLabelOrders);
			} else {
				self.filters().orgUnit(new OrgUnit({}));
			}
			
		}).always(function() {
			self.isLoadingOrgUnits(false);
		});
	}

	function loadPaidOrders() {
		var pageParams = self.paginationPaid.queryParamsObject();
		var searchParams = self.filters().toPaidQueryParams();
		var params = $.extend({}, pageParams, searchParams);
		
		self.isLoadingPaid(true);

		return restClient.getResource(URL.INSPECTION_ORDERS, params).done(function(response) {
			self.paidOrders(ko.utils.arrayMap(response.items, function(inspectionOrderLightDto) {
				return new InspectionOrderLight(inspectionOrderLightDto);
			}));
			self.totalPaidOrdersCount(response.totalCount);
		}).always(function() {
			self.isLoadingPaid(false);
		});
	}

	function loadLabelOrders() {
		var pageParams = self.paginationLabel.queryParamsObject();
		var searchParams = self.filters().toLabelQueryParams();
		var params = $.extend({}, pageParams, searchParams);
		
		if (params.orgUnitCode === null || params.orgUnitCode === undefined) {
			self.labelOrders.removeAll();
			self.totalLabelOrdersCount(0);
			return;
		}
		self.isLoadingLabel(true);
		return restClient.getResource(URL.INSPECTION_ORDERS, params).done(function(response) {
			self.labelOrders(ko.utils.arrayMap(response.items, function(inspectionOrderLightDto) {
				return new InspectionOrderLight(inspectionOrderLightDto);
			}));
			self.totalLabelOrdersCount(response.totalCount);
		}).always(function() {
			self.isLoadingLabel(false);
		});
	}
	
	var restoreMemento = function() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			self.paginationPaid.page(memento.paginationPaidPage);
			self.paginationLabel.page(memento.paginationLabelPage);
			self.filters().searchText(memento.searchFilters.searchText);
			self.filters().orgUnit(memento.searchFilters.orgUnit);
			self.filters().date(memento.searchFilters.date);
			self.allOrgUnitsPaidOrdersCount(memento.allOrgUnitsPaidOrdersCount);
			self.allOrgUnitsLabelOrdersCount(memento.allOrgUnitsLabelOrdersCount);
		}
	};

	var saveMemento = function() {
		var memento = {
			paginationPaidPage: self.paginationPaid.page(),
			paginationLabelPage: self.paginationLabel.page(),
			searchFilters: self.filters().copyProperties(),
			allOrgUnitsPaidOrdersCount: self.allOrgUnitsPaidOrdersCount(),
			allOrgUnitsLabelOrdersCount: self.allOrgUnitsLabelOrdersCount()
		};
		self.constructor.memento = memento;
	};
	
	this.dispose = function() {
		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		saveMemento();
	};
};
