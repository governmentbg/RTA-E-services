namespace("demax.inspections.viewmodel.permits");

demax.inspections.viewmodel.permits.AppliedDocumentVM = function () {
	var self = this;
	this.DocumentTypeCodes = demax.inspections.nomenclature.permits.DocumentTypeCodes;

	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;

	self.permitId = ko.observable();
	var PermitStatus = demax.inspections.nomenclature.permits.PermitStatus;
	this.filesArray = ko.observableArray();

	var AppliedDocument = demax.inspections.model.permits.documents.AppliedDocument;
	var KnockoutPropertyUtil = demax.inspections.utils.KnockoutPropertyUtil;
	var Role = demax.inspections.nomenclature.Role;

	var URL = {
		BASE_URL: "api/permits/{permitId}/documents",
		GET_BY_ID: "api/permits/{permitId}/documents/{docId}",
		GET_PDF_BY_ID: "api/permits/{permitId}/documents/{docId}/pdf",
		GET_DOC_TYPES: "api/nomenclatures/permit-document-types",
		GET_PERMIT_STATUS_NUM: "api/permits/{permitId}/status-number",
		EDIT_NEW_DOCUMENT: "api/permits/{permitId}/documents/{docId}/new",
		EDIT_APPROVED_DOCUMENT: "api/permits/{permitId}/documents/{docId}/approved"
	};

	this.isEditing = ko.observable(false);
	this.isRdaaAndCanEdit = ko.observable(false);

	var user = demax.inspections.authenticatedUser();
	var editableFields = ["docNumber", "issuer", "issuedOn", "validFrom", "validTo", "remarks", "hasDocument"];

	this.isAddingNew = ko.observable(false);
	this.isPreview = ko.observable(false);

	var PermitDocumentStatuses = demax.inspections.nomenclature.permits.PermitDocumentStatus;
	this.statusOptions = ko.observableArray(PermitDocumentStatuses.REAL_STATUSES);

	this.documentTypes = ko.observableArray([]);
	this.document = ko.observable();
	this.documentCopy = ko.observable();
	this.file = ko.observable().extend({
		required: {
			onlyIf: function () {
				return self.document() && !self.document().hasDocument() && self.document().docType()
					&& self.document().docType().code !== self.DocumentTypeCodes.INSPECTION_STATION_PLAN_CODE
					&& self.document().docType().code !== self.DocumentTypeCodes.BANK_VOUCHER_CODE;
			},
			message: "Моля, качете сканирано копие на документа"
		}
	});
	this.hasValidToDate = ko.pureComputed(function() {
		if (self.document() && self.document().docType()) {
			if (!self.document().docType().hasValidToDate) {
				return true;
			} else {
				return false;
			}
		} else {
			return true;
		}
	});
	this.hasValidFromDate = ko.pureComputed(function() {
		if (self.document() && self.document().docType()) {
			if (!self.document().docType().hasValidFromDate) {
				return true;
			} else {
				return false;
			}
		} else {
			return true;
		}
	});
	this.hasIssueDate = ko.pureComputed(function() {
		if (self.document() && self.document().docType()) {
			if (!self.document().docType().hasIssueDate) {
				return true;
			} else {
				return false;
			}
		} else {
			return true;
		}
	});

	this.hasValidFromChanged = ko.computed(function () {
		if (self.document() && (self.document().validFrom())) {
			self.document().updateValidityByValidFrom();
		} 
	});

	this.hasIssuedOnChanged = ko.computed(function () {
		if (self.document() && (self.document().issuedOn())) {
			self.document().updateValidityByIssuedOn();
		} 
	});

	this.permitNumber = ko.observable();

	this.isLoading = ko.pureComputed(function() {
		return restClient.isLoading() || blobClient.isLoading();
	});

	this.init = function (params) {

		setUrls(params.id, params.docId);

		restClient.getResource(URL.GET_PERMIT_STATUS_NUM)
			.done(function (result) {
				self.permitNumber(result.number ? result.number : " - ");
				self.isRdaaAndCanEdit(user.roles.indexOf(Role.TECHINSP_INSP_RDAA) > -1
					&& (result.status === PermitStatus.CREATED.code || result.status === PermitStatus.DRAFT.code));
			}).handleErrors({
				NoSuchEntityException: function () {
					demax.inspections.popupManager.error("Разрешението не е намерено")
						.done(function () {
							demax.inspections.router.setHash("permits");
						});
				}
			});

		restClient.getResource(URL.GET_DOC_TYPES)
			.done(function (response) {
				self.documentTypes(ko.utils.arrayMap(response, function (docType) {
					return new demax.inspections.model.permits.documents.DocumentType(docType);
				}));
				self.permitId(params.id);

				if (params.docId) {
					restClient.getResource(URL.GET_BY_ID)
						.done(function (dto) {
							self.document(new AppliedDocument(dto, self.documentTypes()));
							self.documentCopy(new AppliedDocument(dto, self.documentTypes()));
						});
					self.isPreview(true);
				} else {
					setupAddView();
				}
			});
	};

	this.saveDocument = function () {
		if (self.isLoading()) {
			return;
		}

		var validationErrors = self.document().isApproved() ? 
			ko.validation.group([self.document().status()])
			: ko.validation.group([self.document().docType, self.document().docNumber,
				self.document().issuer, self.document().issuedOn, self.document().validFrom,
				self.document().validTo, self.document().remarks, self.file]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			return;
		}

		if (self.isAddingNew() && self.document().validTo() && self.document().validTo().isBefore(moment())) {
			demax.inspections.popupManager.warn("Датата \"Валиден до\" не може да бъде преди днешна дата!");
			return;
		}

		if (self.isEditing() && !self.isAddingNew()) {
			var request;
			if (self.document().isApproved()) {
				request = restClient.putResource(URL.EDIT_APPROVED_DOCUMENT, { "statusCode": self.document().status().code });
			} else {
				request = restClient.putResource(URL.EDIT_NEW_DOCUMENT, self.document().toRequestBody(self.file()));
			}
			
			request.done(function () {
				updateCopy();
				self.isEditing(false);
			});
		} else if (self.isAddingNew()) {
			restClient.postResource(URL.BASE_URL, self.document().toRequestBody(self.file()))
				.done(function () {
					demax.inspections.popupManager.success({ message: "Успешно добавен нов документ." })
						.done(goBackToPermitDetails);
				});
		}
	};

	this.downloadPdf = function () {
		blobClient.downloadBlob(URL.GET_PDF_BY_ID, "ДОКУМЕНТ-НОМЕР-" + self.document().docNumber()).handleErrors({
			FileNotFoundExpcetion: function () {
				demax.inspections.popupManager.warn("Няма качено сканирано копие на документ!");
			}
		});
	};

	this.fileSelect = function (element, event) {
		var file = event.target.files[0];
		self.filesArray.removeAll();
		self.filesArray.push(file);

		if (!file.type.match("(pdf|jpg|jpeg|png)")) {
			demax.inspections.popupManager.error("Моля прикачете PDF, JPG или PNG файл!");
			clearFile();
			return;
		}
		if (file.size > 5000000) {
			demax.inspections.popupManager.error("Моля прикачете файл с размер по-малък от 5MB!");
			clearFile();
			return;
		}
		var reader = new FileReader();
		reader.onload = (function () {
			return function (e) {
				var base64 = e.target.result;
				self.file(base64.substring(base64.indexOf(",") + 1));
			};
		})(file);
		reader.readAsDataURL(file);
		event.target.value = "";
	};

	function clearFile() {
		self.file(null);
		self.filesArray.removeAll();
	}

	this.goBack = function () {
		if (hasChanges()) {
			demax.inspections.popupManager.confirm({
				message: "Сигурни ли сте, че искате да затворите страницата?",
				okButtonText: "Да",
				cancelButtonText: "Не",
				cssClass: "popInfo",
				okButtonCss: "btn-success"
			}).done(goBackToPermitDetails);
		} else {
			goBackToPermitDetails();
		}
	};

	this.handleCancel = function () {
		var cancelFunction = goBackToPermitDetails;

		if (self.isPreview()) {
			cancelFunction = function () {
				rollBackFields();
				self.switchIsEditing();
			};
		}
		
		if (hasChanges()) {
			demax.inspections.popupManager.confirm({
				message: "Сигурни ли сте, че искате да продължите? Вашите промени ще бъдат изтрити.",
				okButtonText: "Да",
				cancelButtonText: "Не",
				cssClass: "popInfo",
				okButtonCss: "btn-success"
			}).done(cancelFunction);
		} else {
			cancelFunction();
		}
	};

	this.docPicture = ko.pureComputed(function () {
		var docPicture = [];
		if (self.filesArray().length > 0) {
			$.each(ko.unwrap(self.filesArray), function (i, selectedFile) {
				docPicture.push(new demax.inspections.model.FileAttachment(selectedFile));
			});
			return docPicture;
		}
	});

	this.removeDocPicture = function () {
		clearFile();
	};

	function rollBackFields() {
		if (self.document().isApproved()) {
			KnockoutPropertyUtil.copyProperties(self.documentCopy(), self.document(), ["status"]);
		} else {
			KnockoutPropertyUtil.copyProperties(self.documentCopy(), self.document(), editableFields);
			self.document().docType(self.documentCopy().docType());
		}
	}

	function hasChanges() {
		if (self.document().isApproved()) {
			return KnockoutPropertyUtil.hasChanges(self.document(), self.documentCopy(), ["status"]);
		} else {
			return KnockoutPropertyUtil.hasChanges(self.document(), self.documentCopy(), editableFields);
		}
	}

	function updateCopy() {
		if (self.document().isApproved()) {
			self.documentCopy().status(self.document().status());
		} else {
			if (self.file()) {
				self.documentCopy().hasDocument(true);
			}
			self.documentCopy().docNumber(self.document().docNumber());
			self.documentCopy().docType(self.document().docType());
			self.documentCopy().issuer(self.document().issuer());
			self.documentCopy().issuedOn(self.document().issuedOn());
			self.documentCopy().validFrom(self.document().validFrom());
			self.documentCopy().validTo(self.document().validTo());
			self.documentCopy().remarks(self.document().remarks());

		}
	}

	this.switchIsEditing = function () {
		this.isEditing(!this.isEditing());
	};

	this.dispose = function() {
		blobClient.cancelAll();
		restClient.cancelAll();
		this.hasValidFromChanged.dispose();
		this.hasIssuedOnChanged.dispose();
	};

	function goBackToPermitDetails() {
		demax.inspections.router.setHash("permits/details/" + self.permitId());
	}

	function setupAddView() {
		self.isAddingNew(true);
		self.isEditing(true);
		self.document(new AppliedDocument());
		self.documentCopy(new AppliedDocument());
	}

	function setUrls(permitId, docId) {
		Object.keys(URL).forEach(function (key) {
			URL[key] = URL[key].replace("{permitId}", permitId).replace("{docId}", docId);
		});
	}
};
