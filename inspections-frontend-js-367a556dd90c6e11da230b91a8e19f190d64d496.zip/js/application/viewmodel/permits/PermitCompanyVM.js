namespace("demax.inspections.viewmodel.permits");

demax.inspections.viewmodel.permits.PermitCompanyVM = function () {
	var self = this;
	var Pagination = pastel.plus.component.pagination.Pagination;
	var nomenclatureService = demax.inspections.nomenclature.NomenclatureService;
	var restClient = demax.inspections.restClient;
	var popupManager = demax.inspections.popupManager;
	var router = demax.inspections.router;
	var paginationSubscription = null;
	var regionSubscription = null;
	var URL = {
		GET_COMPANY: "api/companies",
		GET_COMPANY_VERSIONS: "api/companies/versions"
	};

	this.PAGE_SIZE = 5;
	this.companyVersionsPage = ko.observable(1);
	this.permitIsNew = ko.observable(false);
	this.permitNumber = ko.observable();

	this.isLoading = restClient.isLoading;

	this.companyVersionsPagination = new Pagination({
		page: self.companyVersionsPage(),
		pageSize: self.PAGE_SIZE
	});

	this.canEdit = ko.observable(false);
	this.selectedRegion = ko.observable();
	this.company = ko.observable();
	this.originalCompanyEik;
	this.permit = null;
	this.companyVersions = ko.observableArray();
	this.companyVersionsCount = ko.observable();
	this.regions = ko.observableArray();
	this.cities = ko.observableArray();
	this.companyCityNameInput = ko.observable();

	this.init = function (params) {
		if (params.permit) {
			self.permit = params.permit;
			self.permitNumber(params.permit.permitNumber ? params.permit.permitNumber : " - ");
			self.permitIsNew(self.permit.id ? false : true);
			nomenclatureService.getRegions().done(function (regions) {
				self.regions(regions);
				if (self.permit.company === null) {
					self.company(new demax.inspections.model.permits.PermitCompany());
				} else {
					self.originalCompanyEik = self.permit.company.eik;
					self.company(self.permit.company);
					prepareCompanyForEdit(self.permit.company);
				}

			});

			self.countries = [new demax.inspections.model.Country({
				code: "BGR",
				name: "България"
			})];
		}
	};

	this.dispose = function () {
		if (paginationSubscription) {
			paginationSubscription.dispose();
		}
		if (regionSubscription) {
			regionSubscription.dispose();
		}
	};

	this.saveCompany = function () {
		if (self.companyCityNameInput().trim().length <= 0) {
			self.company().city.setError("Градът е задължителен!");
		} else if (self.company().city().name !== self.companyCityNameInput()) {
			self.company().city.setError("Градът трябва да бъде в правилната област!");
		}

		var validationErrors = self.company().getValidationGroup();

		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			return;
		}

		restClient.postResource("api/companies", self.company().toJson())
			.done(function (companyDto) {
				self.company(new demax.inspections.model.permits.PermitCompany(companyDto));
				updatePermitIfCompanyIsSaved();
			}).handleErrors({
				EntityAlreadyExistsException: function () {
					popupManager.info("Фирмате вече съществува");
				},

				InvalidIdentityNumber: function () {
					popupManager.info("Невалидно ЕГН на МОЛ");
				},

				InvalidEicNumber: function () {
					popupManager.info("Невалиден ЕИК/Булстат");
				},
				NoSuchEntityException: function () {
					popupManager.info("Няма намерен град");
				}
			});

	};

	function updatePermitIfCompanyIsSaved() {
		if (self.permitIsNew()) {
			self.permit.company = self.company();
			self.goToPermit();
		} else {
			if (self.originalCompanyEik !== self.company().eik()) {
				restClient.patchResource("api/permits/" + self.permit.id + "/company", self.company().eik())
					.done(function () {
						self.goToPermit();
					})
					.handleErrors({
						NoSuchEntityException: function () {
							popupManager.info("Няма намерена фирма");
						}
					});
			} else {
				self.goToPermit();
			}
		}
	}

	this.goToPermit = function () {
		if (self.permitIsNew()) {
			router.setHash("permits/create", {
				permit: self.permit
			});
		} else {
			router.setHash("permits/details/" + self.permit.id);
		}
	};

	this.searchCompany = function () {
		if (!demax.inspections.utils.ValidatorUtil.validateEic(self.company().eik())) {
			popupManager.info("Въведете валиден ЕИК");
			return;
		}

		restClient.getResource(URL.GET_COMPANY, {
			identityNumber: self.company().eik()
		}).done(function (company) {
			self.company(new demax.inspections.model.permits.PermitCompany(company));
			prepareCompanyForEdit();
		}).handleErrors({
			NoSuchEntityException: function () {
				var company = new demax.inspections.model.permits.PermitCompany();
				company.eik(self.company().eik());
				self.company(company);
				self.companyVersions([]);
				self.canEdit(true);
				popupManager.info("Няма намерена фирма");
			}
		});
	};

	function prepareCompanyForEdit() {
		self.canEdit(true);
		self.selectedRegion(self.company().regionCode());
		self.companyCityNameInput(self.company().city().name);
		setCompanyVersions(self.company().eik());
		nomenclatureService.getCitiesByRegion(self.selectedRegion()).done(function (cities) {
			self.cities(cities);
		});
	}

	function setCompanyVersions(eik) {
		if (paginationSubscription) {
			paginationSubscription.dispose();
		}

		loadCompanyVersions(eik, 1).done(function () {
			paginationSubscription = self.companyVersionsPagination.queryParamsObject.subscribe(function (params) {
				self.companyVersionsPagination.page(params.page);
				loadCompanyVersions(eik, params.page);
			});
		});
	}

	function loadCompanyVersions(eik, page) {
		return restClient.getResource(URL.GET_COMPANY_VERSIONS, {
			identityNumber: eik,
			page: page,
			size: self.PAGE_SIZE
		}).done(function (companyVersions) {
			self.companyVersions(companyVersions.items.map(function (companyVersion) {
				return new demax.inspections.model.permits.PermitCompanyVersion(companyVersion);
			}));
			self.companyVersionsCount(companyVersions.totalCount);
		});
	}

	this.getFilteredCities = function (filterValue) {
		var deffered = $.Deferred();

		if (self.company().city() && filterValue === self.company().city().name) {
			deffered.reject();
		} else {
			var filteredCities = [];
			filterValue = filterValue.toLowerCase();
			if (self.cities().length > 0) {
				self.cities().forEach(function (city) {
					if (city.name.toLowerCase().indexOf(filterValue) > -1) {
						filteredCities.push(city);
					}
				});
			}
		}

		deffered.resolve(filteredCities);
		return deffered.promise();
	};

	regionSubscription = this.selectedRegion.subscribe(function () {
		if (self.selectedRegion() && self.company().regionCode() !== self.selectedRegion()) {
			self.company().regionCode(self.selectedRegion());
			nomenclatureService.getCitiesByRegion(self.selectedRegion()).done(function (cities) {
				self.companyCityNameInput(undefined);
				self.cities(cities);
			});
		}
	});

	this.onSelectedCity = function (selectedCity) {
		self.company().city(selectedCity);
		self.companyCityNameInput(selectedCity.name);
	};

};