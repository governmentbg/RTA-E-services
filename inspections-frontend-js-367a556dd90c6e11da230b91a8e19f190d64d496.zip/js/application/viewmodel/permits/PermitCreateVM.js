namespace("demax.inspections.viewmodel.permits");

demax.inspections.viewmodel.permits.PermitCreateVM = function () {
	var self = this;
	var PermitCreate = demax.inspections.model.permits.PermitCreate;
	var nomenclatureService = demax.inspections.nomenclature.NomenclatureService;
	var popupManager = demax.inspections.popupManager;
	var restClient = demax.inspections.restClient;
	var subscriptions = [];

	var PERMITS_URL = "api/permits";

	var user = demax.inspections.authenticatedUser();

	this.permit = ko.observable();
	this.isLoading = restClient.isLoading;
	this.ktpCityNameInput = ko.observable();
	this.cities = ko.observableArray([]);
	this.applicationDateError = ko.observable();
	this.ktpCityError = ko.observable();

	var errorHandlers = {
		ValidationException: function (error) {
			if (error.indexOf("Invalid city code")) {
				popupManager.error("Невалиден град");
			}
		},
		NoSuchEntityException: function (error) {
			if (error.indexOf("No employee found for current user") > -1) {
				popupManager.error("Не е намерен служител към настоящия потребител");
			} else if (error.indexOf("No Company with identity number") > -1) {
				popupManager.error("Няма намерена фирма с посоченото от вас ЕИК");
			} else if (error.indexOf("PermitStatus") > -1) {
				popupManager.error("Не е намерен необходимият статус");
			} else if (error.indexOf("City") > -1) {
				popupManager.error("Града не е намерен");
			}
		},
		NoAuthorityException: function (error) {
			if (error.indexOf("User is not in the same organization unit") > -1) {
				popupManager.error("Нямате право да създавате разрешения за този Областен отдел");
			}
			popupManager.error("Нямате достъп до това Разрешение.");
		}
	};

	this.init = function (params) {
		if (params.permit) {
			self.permit(params.permit);
			self.ktpCityNameInput(params.permit.ktpCity().name);
			self.permit().getValidationGroup().showAllMessages(false);
		} else {
			self.permit(new PermitCreate());
			self.permit().permitOrgUnit = user.employeeOrgUnit;
		}

		subscriptions.push(self.permit().applicationDate.subscribe(function () {
			self.applicationDateError(false);
		}));

		subscriptions.push(self.permit().ktpCity.subscribe(function () {
			self.ktpCityError(false);
		}));


		var orgUnitCode = undefined;

		if (user.employeeOrgUnit !== undefined) {
			orgUnitCode = user.employeeOrgUnit[0].code;
		}

		nomenclatureService.getCitiesByOrgUnitCode(orgUnitCode)
			.done(function (cities) {
				self.cities(cities);
				if (self.permit().ktpCity.code) {
					self.cities().forEach(function (city) {
						if (city.code === self.permit().ktpCity.code) {
							self.permit().ktpCity(city);
							return;
						}
					});
				}
			});
	};

	this.dispose = function () {
		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();
	};

	this.goToCompanyView = function () {
		demax.inspections.router.setHash("permits/create/company", { permit: self.permit() });
	};

	this.savePermit = function () {
		if (self.isLoading()) {
			return;
		}

		if (self.permit().company === null) {
			popupManager.error("Добавете фирма");
			return;
		}

		var hasError = false;

		if (!self.permit().applicationDate()) {
			self.applicationDateError(true);
			hasError = true;
		}

		if (!self.permit().ktpCity().name) {
			self.ktpCityError("Полето е задължително");
			hasError = true;
		} else if (self.permit().ktpCity().name !== self.ktpCityNameInput()) {
			self.ktpCityError("Невалиден град. Въведете град отново");
			hasError = true;
		}

		var group = self.permit().getValidationGroup();
		if (group().length > 0) {
			group.showAllMessages();
			return;
		}

		if (hasError) {
			return;
		}

		restClient.postResource(PERMITS_URL, self.permit().toJson())
			.done(function (permitId) {
				demax.inspections.popupManager.success({ message: "Успешно създадено новo Разрешение." })
					.always(function () {
						demax.inspections.router.setHash("permits/details/" + permitId);
					});
			}).handleErrors(errorHandlers);
	};

	this.getFilteredCities = function (filterValue) {
		var deffered = $.Deferred();

		if (self.permit().ktpCity() && filterValue === self.permit().ktpCity().name) {
			deffered.reject();
		} else {
			var filteredCities = [];
			filterValue = filterValue.toLowerCase();
			if (self.cities().length > 0) {
				self.cities().forEach(function (city) {
					if (city.name.toLowerCase().indexOf(filterValue) > -1) {
						filteredCities.push(city);
					}
				});
			}
		}

		deffered.resolve(filteredCities);
		return deffered.promise();
	};

	this.onSelectedCity = function (selectedCity) {
		self.permit().ktpCity(selectedCity);
		self.ktpCityNameInput(selectedCity.name);
	};
};