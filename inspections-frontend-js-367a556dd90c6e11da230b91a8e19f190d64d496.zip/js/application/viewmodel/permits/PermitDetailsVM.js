namespace("demax.inspections.viewmodel.permits");

demax.inspections.viewmodel.permits.PermitDetailsVM = function () {
	var self = this;
	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;

	var nomenclatureService = demax.inspections.nomenclature.NomenclatureService;
	var Pagination = pastel.plus.component.pagination.Pagination;
	var PermitInfo = demax.inspections.model.permits.PermitInfo;
	var PermitStatusChange = demax.inspections.model.permits.PermitStatusChange;
	var PermitRejectionParams = demax.inspections.model.permits.PermitRejectionParams;
	var FilePickerBox = demax.inspections.utils.FilePickerBox;
	var popupManager = demax.inspections.popupManager;
	var subscriptions = [];
	var permitEditSubscriptions = [];
	var PERMIT_INSPECTION_PERIOD = 14;
	var PERMIT_REISSUING_PERIOD = 14;
	this.PAGE_SIZE = 5;

	var URL = {
		PERMIT_DETAILS: "api/permits/{id}",
		TECHINSP_PERMIT_DETAILS: "api/permits/{0}/techinsp",
		PERMIT_DETAILS_APPLIED_DOCUMENTS: "api/permits/{id}/documents",
		PERMIT_DETAILS_INSPECTORS: "api/permits/{id}/inspectors",
		PERMIT_DETAILS_PERMIT_LINES: "api/permits/{id}/lines",
		PERMIT_PROBLEMS_COUNT: "api/permit-problems/count",
		SEND_PERMIT_TO_IAAA: "api/permits/{id}/send-to-iaaa",
		APPROVE_PERMIT: "api/permits/{id}/approve",
		REJECT_PERMIT: "api/permits/{id}/reject",
		RETURN_PERMIT: "api/permits/{id}/return",
		REISSUE_PERMIT: "api/permits/{id}/reissue",
		CHANGE_ADDITIONAL_INFO: "api/permits/{id}/additional-info",
		UPDATE_PERMIT_INFO: "api/permits/{id}/info",
		CHANGE_GPS_INFO: "api/permits/{id}/update-gps",
		CREATE_DRAFT: "api/permits/{id}",
		PERMIT_PDF: "api/permits/{id}/pdf",
		PERMIT_LIGHT_PDF: "api/permits/{id}/pdf-light",
		PERMIT_LIGHT_PDF_DUPLICATE: "api/permits/{id}/pdf-light-duplicate",
		CHANGE_PERMIT_STATUS: "api/permits/{id}/status",
		DELETE_LINE: "api/permits/{id}/lines/",
		DELETE_DOCUMENT: "api/permits/{id}/documents/",
		GET_REJECTION_FILE_BY_ID: "api/permits/{id}/rejection/file",
		DELETE_PERMIT: "api/permits/{id}",
		PERMIT_INSPECTIONS: "api/permits/{id}/inspections",
		GET_INSPECTION_FILE_BY_ID: "api/permits/{id}/inspections/{0}/file"
	};

	var errorHandlers = {
		NoSuchEntityException: function (error) {
			if (error.indexOf("PermitVersion with id") > -1) {
				popupManager.error("Няма такова Разрешение");
			} else if (error.indexOf("PermitStatus with id") > -1) {
				popupManager.error("Необходимият статус не е намерен");
			} else if (error.indexOf("City") > -1) {
				popupManager.error("Града не е намерен");
			}
		},
		NoAuthorityException: function (error) {
			if (error.indexOf("User is not in the same organization unit")) {
				popupManager.error("Потребителя не от необходимия областен отдел");
			} else {
				popupManager.error("Нямате достъп до това Разрешение");
			}
		},
		PermitDraftIsNotEditedException: function () {
			popupManager.error("Няма промени по Разрешението");
		},
		InvalidPermitStatusException: function () {
			popupManager.error("Разрешението не е валидно");
		},
		PermitIsNotLastValidVersion: function () {
			popupManager.error("Разрешението не е последната валидна версия");
		},
		// shouldn"t be thrown because, all fields are validated
		ValidationException: function () {
			popupManager.error("Някой от въведените полета не е валидно");
		},
		EmailException: function () {
			// Even if email service fails, the permit is successfully approved.
			popupManager.warn("Успешно одобрено Разрешително, но възникна проблем с услугата за изпращане на имейли.")
				.done(function () {
					window.location.reload();
				});
			demax.inspections.logger("An error occured while sending emails.");
		},
		PermitErrorsException: function (message, errorDto) {

			self.permitInfoValidator(getPermitInfoValidator());
			self.permitInfoValidator().hasErrors(true);

			self.permitInfoValidator().subjectError = errorDto.errors.subjectError;

			self.permitInfoValidator().listsErrors = errorDto.errors.listsErrors;

			if (errorDto.errors.inspectorsErrors) {

				self.permitInfoValidator().inspectorsErrors = [];
				Object.keys(errorDto.errors.inspectorsErrors).forEach(function (inspectorName) {
					errorDto.errors.inspectorsErrors[inspectorName].forEach(function (error) {
						self.permitInfoValidator().inspectorsErrors.push(
							{
								name: inspectorName,
								code: error.code
							}
						);
					});
				});
			}

			if (errorDto.errors.linesErrors) {

				self.permitInfoValidator().linesErrors = [];
				Object.keys(errorDto.errors.linesErrors).forEach(function (lineNumber) {
					errorDto.errors.linesErrors[lineNumber].forEach(function (error) {
						self.permitInfoValidator().linesErrors.push(
							{
								number: lineNumber,
								code: error.code
							}
						);
					});
				});
			}

			self.permitInfoValidator.valueHasMutated();
		}
	};



	this.isLoading = ko.pureComputed(function () {
		return restClient.isLoading() || blobClient.isLoading();
	});

	this.permit = ko.observable();
	this.cities = ko.observableArray([]);
	this.ktpCityNameInput = ko.observable();
	this.permitInfoEdit = ko.observable(new PermitInfo(null));
	this.permitStatusChange = ko.observable(new PermitStatusChange());
	this.permitInfoValidator = ko.observable();
	this.ktpCityError = ko.observable();
	this.applicationDateError = ko.observable();
	this.closeDateError = ko.observable();
	this.revokeDateError = ko.observable();

	this.documentsCount = ko.observable();
	this.inspectorsCount = ko.observable();
	this.permitLinesCount = ko.observable();
	this.ordersCount = ko.observable();
	this.problemsCount = ko.observable();
	this.waitingPermitProblemsCount = ko.observable();
	
	this.isRdaaAndCanEdit = ko.observable(false);
	this.isRdaaOrIaaaAndCanEdit = ko.observable(false);
	this.isPermitApproved = ko.observable(true);
	this.isPermitValid = ko.observable(false);
	this.isPermitInvalid = ko.observable(false);
	this.canCreateDraft = ko.observable(false);
	this.isProcessing = ko.observable(false);
	this.isPermitCreated = ko.observable(false);

	// Reason box
	this.isReasonBoxVisible = ko.observable(false);
	this.filePicker = new FilePickerBox({
		size: 2000 * 1000,
		filename: "^(?=.*\\S+.*).{1,256}$"
	});
	this.permitRejectionParams = new PermitRejectionParams();

	this.documentsPage = ko.observable(1);
	this.inspectorsPage = ko.observable(1);
	this.isPermitInfoEditing = ko.observable(false);
	this.isAdditionalInfoEditing = ko.observable(false);
	this.ktpInfo = ko.observable();
	this.isAddingInspection = ko.observable(false);
	this.newInspection = ko.observable();

	this.isNotEditing = ko.pureComputed(function () {
		return !(self.isPermitInfoEditing() || self.isAddingInspection());
	});

	this.documentsPagination = new Pagination({
		page: self.documentsPage(),
		pageSize: self.PAGE_SIZE
	});
	this.inspectorsPagination = new Pagination({
		page: self.inspectorsPage(),
		pageSize: self.PAGE_SIZE
	});
	this.permitLinesPagination = new Pagination({
		page: 1,
		pageSize: self.PAGE_SIZE
	});

	this.PermitStatus = demax.inspections.nomenclature.permits.PermitStatus;
	this.PermitErrors = demax.inspections.nomenclature.permits.PermitErrors;
	this.user = demax.inspections.authenticatedUser();

	// Detected changes
	this.ChangeCodes = demax.inspections.nomenclature.permits.ChangeCodes;

	this.permitInfoChanges = ko.observable({});
	this.inspectorChanges = ko.observable({});
	this.documentChanges = ko.observable({});
	this.lineChanges = ko.observable({});
	this.inspectionChanges = ko.observable({});

	this.changesWithText = ko.observableArray([]);

	this.init = function (params) {

		var url;
		if (params.isTechinspPermit) {
			url = pastel.util.StringHelper.format(URL.TECHINSP_PERMIT_DETAILS, params.id);
		} else {
			setUrls(params.id);
			url = URL.PERMIT_DETAILS;
		}

		restClient.getResource(url)
			.done(function (dto) {

				if (params.isTechinspPermit) {
					setUrls(dto.id);
					history.replaceState(null, "", "#/permits/details/" + dto.id);
				}

				self.permit(new demax.inspections.model.permits.PermitDetails(dto));
				if (dto.detectedChanges && !dto.detectedChanges.empty) {
					self.permitInfoChanges(dto.detectedChanges.permitInfoChanges);
					self.inspectorChanges(dto.detectedChanges.inspectorChanges);
					self.documentChanges(dto.detectedChanges.documentChanges);
					self.lineChanges(dto.detectedChanges.lineChanges);
					self.inspectionChanges(dto.detectedChanges.inspectionChanges);

					Object.keys(self.permitInfoChanges()).forEach(function (key) {
						self.changesWithText.push(self.ChangeCodes.getText(key, self.permitInfoChanges()[key]));
					});
					Object.keys(self.inspectionChanges()).forEach(function (id) {
						Object.keys(self.inspectionChanges()[id]).forEach(function (key) {
							self.changesWithText.push(self.ChangeCodes.getText(key, self.inspectionChanges()[id][key]));
						});
					});
					Object.keys(self.inspectorChanges()).forEach(function (id) {
						Object.keys(self.inspectorChanges()[id].infoChanges).forEach(function (key) {
							self.changesWithText.push(self.ChangeCodes.getText(key, self.inspectorChanges()[id].infoChanges[key]));
						});
						Object.keys(self.inspectorChanges()[id].documentChanges).forEach(function (docId) {
							Object.keys(self.inspectorChanges()[id].documentChanges[docId]).forEach(function (docKey) {
								self.changesWithText.push(self.ChangeCodes.getText(docKey, self.inspectorChanges()[id].documentChanges[docId][docKey]));
							});
						});
					});
					Object.keys(self.documentChanges()).forEach(function (id) {
						Object.keys(self.documentChanges()[id]).forEach(function (key) {
							self.changesWithText.push(self.ChangeCodes.getText(key, self.documentChanges()[id][key]));
						});
					});
					Object.keys(self.lineChanges()).forEach(function (id) {
						Object.keys(self.lineChanges()[id]).forEach(function (key) {
							self.changesWithText.push(self.ChangeCodes.getText(key, self.lineChanges()[id][key]));
						});
					});


				}

				var permitStatusCode = self.permit().status.code;
				var avaliableStatusChangeCodes = self.PermitStatus.AVALIABLE_STATUS_CHANGES_BY_IAAA.map(function (status) {
					return status.code;
				});
				self.isPermitValid((permitStatusCode === self.PermitStatus.VALID.code || permitStatusCode === self.PermitStatus.REVOKING_IN_PROCESS.code)
					&& self.permit().versionNumber === null);
				self.isPermitInvalid(permitStatusCode === self.PermitStatus.INVALID.code);
				self.isPermitCreated(permitStatusCode === self.PermitStatus.CREATED.code);
				self.isPermitDraft = permitStatusCode === self.PermitStatus.DRAFT.code;
				self.isProcessing(permitStatusCode === self.PermitStatus.PROCESSING.code);
				self.isRdaaAndCanEdit(self.user.userIsRdaa() && (self.isPermitCreated() || self.isPermitDraft));
				self.isRdaaOrIaaaAndCanEdit(self.isRdaaAndCanEdit()
					|| (self.user.userIsIaaa() && self.permit().versionNumber === null
						&& avaliableStatusChangeCodes.indexOf(permitStatusCode) > -1));
				self.isPermitApproved(!(self.isPermitCreated() || self.isPermitDraft
					|| permitStatusCode === self.PermitStatus.REQUESTED.code
					|| self.isProcessing()));

				nomenclatureService.getCitiesByOrgUnitCode(self.permit().orgUnit.code)
					.done(function (cities) {
						self.cities(cities);
						if (dto.ktpCity) {
							self.cities().forEach(function (city) {
								if (city.code === dto.ktpCity.code) {
									self.permit().ktpCity = city;
									return;
								}
							});
						}
					});

				if (dto.orders) {
					self.ordersCount(dto.orders.totalCount);
				}
				if (dto.problems) {
					self.problemsCount(dto.problems.totalCount);
				}

				if (self.user.userIsCallCenter()) {
					getWaitingProblemsCount();
				}

				getAppliedDocumentsPage(1);
				subscriptions.push(self.documentsPagination.queryParamsObject.subscribe(function (params) {
					self.documentsPage(params.page);
					getAppliedDocumentsPage(params.page);
				}));

				getInspectorsPage(1);
				subscriptions.push(self.inspectorsPagination.queryParamsObject.subscribe(function (params) {
					self.inspectorsPage(params.page);
					getInspectorsPage(params.page);
				}));

				getPermitLinesPage(1);
				subscriptions.push(self.permitLinesPagination.queryParamsObject.subscribe(function (params) {
					getPermitLinesPage(params.page);
				}));

			}).handleErrors(errorHandlers);
	};

	this.downloadRejectionFile = function () {
		blobClient.downloadBlob(URL.GET_REJECTION_FILE_BY_ID, self.permit().rejection.filename);
	};

	this.downloadInspectionFile = function (inspection) {

		blobClient.getBlob(pastel.util.StringHelper.format(URL.GET_INSPECTION_FILE_BY_ID, inspection.id))
			.done(function (blob, xhr) {

				if (blob === null || blob === undefined) {
					popupManager.warn("Огледа няма файл");
				} else {

					var filename = inspection.inspectionProtocolNumber;
					var contentType = xhr.getResponseHeader("content-type");

					if (contentType.indexOf("application/pdf") > -1) {
						filename += ".pdf";
					} else if (contentType.indexOf("image/jpeg") > -1) {
						filename += ".jpeg";
					} else if (contentType.indexOf("image/png") > -1) {
						filename += ".png";
					}

					pastel.plus.util.blob.downloadBlob(blob, filename);
				}
			}).handleErrors(errorHandlers);
	};

	this.dispose = function () {
		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();
		blobClient.cancelAll();
	};

	this.inputText = ko.pureComputed(function () {
		if (self.permitRejectionParams()) {
			return true;
		} else {
			return false;
		}
	});

	this.inputFile = ko.pureComputed(function () {
		if (self.permitRejectionParams()) {
			return true;
		} else {
			return false;
		}
	});

	this.sendToIaaa = function () {

		if (self.isLoading()) {
			return;
		}

		demax.inspections.popupManager.confirm({
			message: "Сигурни ли сте, че искате да изпратите Разрешението към ИААА?",
			okButtonText: "Изпрати",
			cancelButtonText: "Затвори",
			cssClass: "popInfo",
			okButtonCss: "btn-success"
		}).done(function () {

			self.permitInfoValidator(getPermitInfoValidator());

			if (self.permitInfoValidator().hasErrors()) {
				return;
			}

			restClient.putResource(URL.SEND_PERMIT_TO_IAAA, {
				id: self.permit().id
			}).done(function () {
				popupManager.success({
					message: "Успешно изпратено към ИААА."
				}).done(function () {
					window.location.reload();
				});
			}).handleErrors(errorHandlers);
		});
	};

	this.approvePermit = function () {

		var settings;

		if (self.permit().status.code === self.PermitStatus.REQUESTED.code) {
			settings = {
				title: "Потвърждение",
				message: "Сигурни ли сте, че искате да одобрите Разрешението?",
				message2: "Моля, попълнете начална дата на валидност на Разрешението.",
				isDateInput: true,
				hasError: false,
				errorMessage: "Това поле е задължително."
			};

			openDatePopUp(settings, "validFrom", moment().startOf("day"), "Успешно одобрено Разрешението.");
		} else if (self.permit().statusChange.code === self.PermitStatus.CLOSED.code) {
			settings = {
				title: "Потвърждение",
				message: "Сигурни ли сте, че искате да закриете Разрешението?",
				message2: "Моля, попълнете дата на закриване на Разрешението.",
				isDateInput: true,
				hasError: false,
				errorMessage: "Това поле е задължително."
			};

			var date = self.permit().validFrom ? self.permit().validFrom : self.permit().issuedOn;

			openDatePopUp(settings, "closeDate", date, "Успешно закрито Разрешение.");
		} else if (self.permit().statusChange.code === self.PermitStatus.REVOKED.code) {
			demax.inspections.popupManager.confirm({
				message: "Сигурни ли сте, че искате да отнемете Разрешението?",
				okButtonText: "Да",
				cancelButtonText: "Не",
				cssClass: "popInfo",
				okButtonCss: "btn-primary"
			}).done(function () {
				restClient.putResource(URL.APPROVE_PERMIT, {
					id: self.permit().id
				})
					.done(function () {
						popupManager.success({
							message: "Успешно отнето Разрешение."
						}).done(function () {
							window.location.reload();
						});
					})
					.handleErrors(errorHandlers);
			});
		} else {
			demax.inspections.popupManager.confirm({
				message: "Сигурни ли сте, че искате да одобрите Разрешението?",
				okButtonText: "Да",
				cancelButtonText: "Не",
				cssClass: "popInfo",
				okButtonCss: "btn-primary"
			}).done(function () {
				restClient.putResource(URL.APPROVE_PERMIT, {
					id: self.permit().id
				}).done(function () {
					popupManager.success({
						message: "Успешно одобрено Разрешение."
					}).done(function () {
						window.location.reload();
					});
				}).handleErrors(errorHandlers);
			});
		}
	};

	function openDatePopUp(settings, dateParam, minDate, successMessage) {

		var subscription = demax.inspections.popupManager.isVisible.subscribe(function () {
			subscription.dispose();

			var element = $("#popup-dp");
			var picker = $(element).data("DateTimePicker");

			picker.minDate(minDate);
		});

		demax.inspections.popupManager.prompt(settings)
			.done(function (inputDate) {
				if (!inputDate) {
					settings.hasError = true;
					openDatePopUp(settings, dateParam);
					return;
				}

				var body = {
					id: self.permit().id
				};
				body[dateParam] = inputDate.format(demax.inspections.settings.serverDateFormat);

				restClient.putResource(URL.APPROVE_PERMIT, body)
					.done(function () {
						popupManager.success({
							message: successMessage
						}).done(function () {
							window.location.reload();
						});
					}).handleErrors(errorHandlers);
			});
	}

	this.submitReasonBox = function () {
		var validationErrors = ko.validation.group([self.permitRejectionParams.reason]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			return;
		}

		var file = self.filePicker.file();
		if (file) {
			self.permitRejectionParams.file = file;
			self.permitRejectionParams.filename = self.filePicker.filename();
		}

		self.permitRejectionParams.submit();
	};

	this.showReasonBox = function (whichType) {
		if (self.isReasonBoxVisible() && whichType === self.permitRejectionParams.type()) {
			self.isReasonBoxVisible(false);
		} else {
			self.isReasonBoxVisible(true);
			if (whichType === self.permitRejectionParams.REJECT_PERMIT) {
				self.permitRejectionParams.setSubmitFunction(doRejectPermit);
			} else {
				self.permitRejectionParams.setSubmitFunction(doReturnPermit);
			}
			self.permitRejectionParams.type(whichType);
		}
	};

	this.hideReasonBox = function () {
		self.isReasonBoxVisible(false);
	};

	function doRejectPermit() {
		demax.inspections.popupManager.confirm({
			message: "Сигурни ли сте, че искате да отхвърлите Разрешението?",
			okButtonText: "Да",
			cancelButtonText: "Не",
			cssClass: "popError",
			okButtonCss: "btn-primary"
		}).done(function () {
			restClient.putResource(URL.REJECT_PERMIT, self.permitRejectionParams.toRequestBody())
				.done(function () {
					popupManager.success({
						message: "Успешно отхвърлихте Разрешение."
					}).done(function () {
						demax.inspections.router.setHash("permits");
					});
				}).handleErrors(errorHandlers);
		});
	}

	function doReturnPermit() {
		demax.inspections.popupManager.confirm({
			message: "Сигурни ли сте, че искате да върнете Разрешението за корекция?",
			okButtonText: "Да",
			cancelButtonText: "Не",
			cssClass: "popError",
			okButtonCss: "btn-primary"
		}).done(function () {
			restClient.putResource(URL.RETURN_PERMIT, self.permitRejectionParams.toRequestBody())
				.done(function () {
					popupManager.success({
						message: "Успешно върнато Разрешение за корекция."
					}).done(function () {
						demax.inspections.router.setHash("permits");
					});
				}).handleErrors(errorHandlers);
		});
	}

	this.reissuePermit = function () {

		if (self.permit().draftId) {
			popupManager.warn("Разрешението има съществуваща чернова. Може да бъде изтрита за да можете да преиздадете разрешението");
			return;
		}

		var settings = {
			message: "Сигурни ли сте, че искате това Разрешение да бъде преиздадено? Това ще увеличи валидността му с 5 години.",
			okButtonText: self.permit().status.code !== self.PermitStatus.EXPIRED.code && self.permit().validTo.isAfter(moment().add(PERMIT_REISSUING_PERIOD, "days")) ?
				"Изпрати" : "Продължи",
			inputs: [
				{
					name: "Номер на заявление",
					property: "applicationNumber",
					type: "text",
					constraints: {
						required: true,
						maxLength: 20
					}
				},
				{
					name: "Дата на заявление",
					property: "applicationDate",
					type: "date"
				}
			]
		};

		demax.inspections.popupManager.form(settings)
			.done(function (inputs) {
				restClient.putResource(URL.REISSUE_PERMIT, {
					id: self.permit().id,
					applicationNumber: inputs.applicationNumber,
					applicationDate: inputs.applicationDate.format(demax.inspections.settings.serverDateFormat)
				}).done(function (permitId) {
					demax.inspections.router.setHash("permits/details/" + permitId);
				}).handleErrors(errorHandlers);
			});
	};

	this.changePermitStatus = function () {

		if (validatePermitStatusChange()) {
			return;
		}

		if (permitStatusHasChanges()) {

			demax.inspections.popupManager.confirm({
				message: "Сигурни ли сте, че искате да промените статуса към: '" + self.permitStatusChange().status().name + "' ?",
				okButtonText: "Да",
				cancelButtonText: "Не",
				cssClass: "popInfo",
				okButtonCss: "btn-primary"
			}).done(function () {
				restClient.putResource(URL.CHANGE_PERMIT_STATUS, self.permitStatusChange().toJson())
					.done(function (permitId) {
						demax.inspections.router.setHash("permits/details/" + permitId);
					})
					.handleErrors(errorHandlers)
					.always(function () {
						cancelPermitInfoEdit();
					});
			});
		} else {
			cancelPermitInfoEdit();
		}
	};

	this.savePermitInfoEdit = function () {

		var hasErrors = false;

		if (!self.permitInfoEdit().applicationDate()) {
			self.applicationDateError(true);
			hasErrors = true;
		}

		hasErrors = validatePermitStatusChange() || hasErrors;

		if (self.ktpCityNameInput() == "" || !self.permitInfoEdit().ktpCity().name) {
			self.ktpCityError("Полето е задължително");
			hasErrors = true;
		} else if (self.permitInfoEdit().ktpCity().name !== self.ktpCityNameInput()) {
			self.ktpCityError("Невалиден град. Въведете град отново");
			hasErrors = true;
		}

		var group = self.isPermitCreated() ? self.permitInfoEdit().getValidationGroupForCreatedPermit() : self.permitInfoEdit().getValidationGroupForDraftPermit();
		if (group().length > 0) {
			group.showAllMessages();
			hasErrors = true;
		}

		if (hasErrors) {
			return;
		}

		if (permitInfoHasChanges()) {

			var body = self.permitInfoEdit().toParams();

			if (self.permitStatusChange().status()) {
				body.statusChangeCode = self.permitStatusChange().status().code;

				var settings = {
					okButtonText: "Да",
					cancelButtonText: "Не",
					cssClass: "popInfo",
					okButtonCss: "btn-primary"
				};

				if (self.PermitStatus.REVOKED === self.permitStatusChange().status()) {
					body.closeReason = self.permitStatusChange().revokeReason();
					body.closeDate = self.permitStatusChange().revokeDate().format(demax.inspections.settings.serverDateFormat);

					settings.message = "Сигурни ли сте, че искате да отнемете Разрешението?";

				} else if (self.PermitStatus.CLOSED === self.permitStatusChange().status()) {
					body.closeReason = self.permitStatusChange().closeApplicationNumber();

					settings.message = "Сигурни ли сте, че искате да закриете Разрешението?";

				}

				demax.inspections.popupManager.confirm(settings)
					.done(function () {
						sendUpdatePermitInfoRequest(body);
					}).fail(function () {
						cancelPermitInfoEdit();
					});

			} else {
				sendUpdatePermitInfoRequest(body);
			}
		} else {
			cancelPermitInfoEdit();
		}
	};

	function sendUpdatePermitInfoRequest(body) {
		restClient.patchResource(URL.UPDATE_PERMIT_INFO, JSON.stringify(body))
			.done(function () {

				self.permit().ktpCity = self.permitInfoEdit().ktpCity();
				self.permit().ktpAddress = self.permitInfoEdit().ktpAddress();
				self.permit().contactKtpPhone = self.permitInfoEdit().contactKtpPhone();
				self.permit().contactKtpEmail = self.permitInfoEdit().contactKtpEmail();

				if (self.isPermitCreated()) {
					self.permit().applicationNumber = self.permitInfoEdit().applicationNumber();
					self.permit().applicationDate = self.permitInfoEdit().applicationDate();
				} else {
					self.permit().statusChange = self.permitStatusChange().status();
					if (self.permit().statusChange) {
						if (self.permit().statusChange == self.PermitStatus.REVOKED) {
							self.permit().closeReason = self.permitStatusChange().revokeReason();
							self.permit().closeDate = self.permitStatusChange().revokeDate();
						} else if (self.permit().statusChange == self.PermitStatus.CLOSED) {
							self.permit().closeReason = self.permitStatusChange().closeApplicationNumber();
							self.permit().closeDate = undefined;
						}
					} else {
						self.permit().statusChange = self.PermitStatus.getNullStatus();
						self.permit().closeReason = null;
						self.permit().closeDate = null;
					}
				}

				self.permit.valueHasMutated();
				popupManager.success({
					message: "Успешно обновихте Разрешението."
				});

			})
			.handleErrors(errorHandlers)
			.always(function () {
				cancelPermitInfoEdit();
			});
	}

	this.saveKtpChanges = function () {
		var validators = ko.validation.group([
			self.ktpInfo().contactPersonName,
			self.ktpInfo().contactPersonPhone,
			self.ktpInfo().contactPersonStationaryPhone,
			self.ktpInfo().contactPersonEmail,
			self.ktpInfo().gpsN,
			self.ktpInfo().gpsE
		]);

		if (ko.unwrap(validators()).length > 0) {
			validators.showAllMessages();
			return;
		}

		var body = self.ktpInfo().toEditDto();

		if (ktpInfoHasChanges()) {
			demax.inspections.popupManager.confirm({
				message: "Сигурни ли сте, че искате да промените данните за КТП?",
				okButtonText: "Да",
				cancelButtonText: "Не",
				cssClass: "popInfo",
				okButtonCss: "btn-primary"
			}).done(function () {
				restClient.patchResource(URL.CHANGE_ADDITIONAL_INFO, JSON.stringify(body))
					.done(function () {
						popupManager.success({
							message: "Успешно променихте данните за КТП."
						}).done(function () {
							self.permit().additionalInfo(self.ktpInfo());
							self.toggleAdditionalInfoEditing();
						});
					})
					.handleErrors(errorHandlers);
			});
		} else {
			self.toggleAdditionalInfoEditing();
		}
	};

	this.cancelKtpChanges = function () {
		if (ktpInfoHasChanges()) {
			demax.inspections.popupManager.confirm({
				message: "Промените Ви ще бъдат загубени. Сигурни ли сте че искате да продължите?",
				okButtonText: "Да",
				cancelButtonText: "Не",
				cssClass: "popError",
				okButtonCss: "btn-primary"
			}).done(function () {
				self.toggleAdditionalInfoEditing();
			});
		} else {
			self.toggleAdditionalInfoEditing();
		}
	};

	this.createDraft = function () {
		demax.inspections.popupManager.confirm({
			message: "Сигурни ли сте, че искате да създадете чернова?",
			okButtonText: "Да",
			cancelButtonText: "Не",
			cssClass: "popInfo",
			okButtonCss: "btn-primary"
		}).done(function () {
			restClient.postResource(URL.CREATE_DRAFT).done(function (draftId) {
				demax.inspections.router.setHash("permits/details/" + draftId);
			});
		});
	};

	this.viewProblems = function () {
		demax.inspections.router.setHash("problems", {
			permitNumber: self.permit().permitNumber
		});
	};

	this.viewWaitingProblems = function () {
		demax.inspections.router.setHash("problems", {
			permitNumber: self.permit().permitNumber,
			status: 1
		});
	};

	this.viewInspectionOrders = function () {
		demax.inspections.router.setHash("inspection-orders-list", {
			permitNumber: self.permit().permitNumber
		});
	};

	this.toggleAdditionalInfoEditing = function () {
		if (self.isAdditionalInfoEditing()) {
			self.isAdditionalInfoEditing(false);
		} else {
			self.isAdditionalInfoEditing(true);
			self.ktpInfo(new demax.inspections.model.permits.PermitDetailsAdditionalInfo(self.permit().additionalInfo().toEditDto()));
		}
	};

	this.goToDraft = function () {
		demax.inspections.router.setHash("permits/details/" + self.permit().draftId);
	};

	this.getFilteredCities = function (filterValue) {
		var deffered = $.Deferred();

		if (self.permitInfoEdit().ktpCity() && filterValue === self.permitInfoEdit().ktpCity().name) {
			deffered.reject();
		} else {
			var filteredCities = [];
			filterValue = filterValue.toLowerCase();
			if (self.cities().length > 0) {
				self.cities().forEach(function (city) {
					if (city.name.toLowerCase().indexOf(filterValue) > -1) {
						filteredCities.push(city);
					}
				});
			}
		}

		deffered.resolve(filteredCities);
		return deffered.promise();
	};

	// Delete Methods for List Boxes

	this.deleteLine = function (permitLine) {
		popupManager.confirm({
			cssClass: "popError",
			message: "Изтриването на линията води до изпращане на автоматична заявка за демонтаж на техниката в КТП. Сигурни ли сте, че искате да продължите?",
			okButtonCss: "btn-primary"
		}).done(function () {
			restClient.deleteResource(URL.DELETE_LINE + permitLine.id).done(function () {
				demax.inspections.popupManager.success({ message: "Линията е изтрита успешно." });
				getPermitLinesPage(1);
			});
		});
	};

	this.deleteDocument = function (document) {
		popupManager.confirm({
			cssClass: "popInfo",
			message: "Сигурни ли сте, че искате да изтриете документа?",
			okButtonCss: "btn-primary"
		}).done(function () {
			restClient.deleteResource(URL.DELETE_DOCUMENT + document.id).done(function () {
				demax.inspections.popupManager.success({ message: "Документа е изтрит успешно." });
				getAppliedDocumentsPage(1);
			});
		});
	};

	this.deleteInspection = function (inspection) {
		demax.inspections.popupManager.confirm({
			message: "Сигурни ли сте, че искате да премахнете огледа?",
			okButtonText: "Да",
			cancelButtonText: "Не",
			cssClass: "popInfo",
			okButtonCss: "btn-primary"
		}).done(function () {
			restClient.deleteResource(URL.PERMIT_INSPECTIONS + "/" + inspection.id).done(function () {
				self.permit().inspections(
					self.permit().inspections().filter(function (i) {
						return i.id !== inspection.id;
					})
				);
			});
		});
	};

	this.deleteNewPermitInspector = function (data) {
		if (self.isRdaaAndCanEdit && data.isNewInspector) {
			var url = URL.PERMIT_DETAILS + "/inspectors/" + data.id;

			demax.inspections.popupManager.confirm({
				message: "Сигурни ли сте, че искате да премахнете избрания специалист?",
				okButtonText: "Да",
				cancelButtonText: "Не",
				cssClass: "popInfo",
				okButtonCss: "btn-primary"
			}).done(function () {
				restClient.deleteResource(url).done(function () {
					demax.inspections.popupManager.success({ message: "Инспекторът е изтрит успешно." });
					getInspectorsPage(1);
				});
			});
		}
	};

	// Delete Methods for List Boxes END

	this.editCompany = function () {
		demax.inspections.router.setHash("permits/details/" + self.permit().id + "/company", {
			permit: self.permit()
		});
	};

	this.showAddingInspection = function () {
		self.isAddingInspection(true);
		self.newInspection(new demax.inspections.model.permits.PermitInspectionParams());
		self.filePicker.file = self.newInspection().file;
	};

	this.hideAddingInspection = function () {
		self.isAddingInspection(false);
		self.newInspection(null);
	};

	this.saveInspection = function () {

		if (!self.newInspection().inspectionDate()) {
			self.newInspection().inspectionDateError(true);
		}

		if (!self.newInspection().inspectionProtocolDate()) {
			self.newInspection().inspectionProtocolDateError(true);
		}
		
		var group = self.newInspection().getValidationGroup();
		if (group().length > 0) {
			group.showAllMessages();
			return;
		}

		if (self.newInspection().hasError()) {
			return;
		}

		restClient.postResource(URL.PERMIT_INSPECTIONS, self.newInspection().toJson())
			.done(function (inspectionId) {
				demax.inspections.popupManager.success({ message: "Успешно добавен оглед" })
					.done(function () {
						self.inspectionChanges()[inspectionId] = {};
						self.permit().inspections.push(
							{
								id: inspectionId,
								inspectionDate: self.newInspection().inspectionDate(),
								inspectionProtocolNumber: self.newInspection().inspectionProtocolNumber(),
								inspectionPaymentNumber: self.newInspection().inspectionPaymentNumber(),
								inspectionProtocolDate: self.newInspection().inspectionProtocolDate(),
								conclusion: self.newInspection().conclusion()
							}
						);

						self.hideAddingInspection();
					});
			}).handleErrors(errorHandlers);
	};

	this.goToAddDocument = function () {
		demax.inspections.router.setHash("permits/details/" + self.permit().id + "/documents/new");
	};

	this.goToPreviewDocument = function (docId) {
		demax.inspections.router.setHash("permits/details/" + self.permit().id + "/documents/" + docId);
	};

	this.goToAddPermitLine = function () {
		demax.inspections.router.setHash("permits/details/" + self.permit().id + "/lines/new", {
			permitNumber: self.permit().permitNumber,
			permitStatusCode: self.permit().status.code
		});
	};

	this.goToAddProblem = function () {
		demax.inspections.router.setHash("problems/add", {
			permitNumber: self.permit().permitNumber
		});
	};

	this.goToPreviewPermitLine = function (line) {
		demax.inspections.router.setHash("permits/details/" + self.permit().id + "/lines/" + line.id, {
			permitNumber: self.permit().permitNumber,
			permitStatusCode: self.permit().status.code
		});
	};

	this.getPreviewInspectorUrl = function (id) {
		return "#/permits/details/" + self.permit().id + "/inspectors/" + id;
	};

	this.getAddInspectorUrl = function () {
		return "#/permits/details/" + self.permit().id + "/inspectors/new";
	};

	self.goToDepriveOfRights = function () {
		demax.inspections.router.setHash("permits/details/" + self.permit().id + "/deprive-of-rights");
	};

	this.deletePermit = function () {
		popupManager.confirm({
			cssClass: "popInfo",
			message: "Сигурни ли сте, че искате да изтриете разрешението?",
			okButtonCss: "btn-primary"
		}).done(function () {
			restClient.deleteResource(URL.DELETE_PERMIT).done(function () {
				demax.inspections.popupManager.success({ message: "Разрешението е изтритo успешно." })
					.done(function () {
						demax.inspections.router.setHash("permits");
					});
			});
		});
	};

	this.showPermitInfoEdit = function () {
		if (self.user.userIsRdaa()) {
			self.permitInfoEdit(new PermitInfo(self.permit()));
			if (self.permit().ktpCity) {
				self.ktpCityNameInput(self.permit().ktpCity.name);
			}
			self.permitInfoValidator(null);

			permitEditSubscriptions.push(self.permitInfoEdit().ktpCity.subscribe(function () {
				self.ktpCityError(false);
			}));

			permitEditSubscriptions.push(self.permitInfoEdit().applicationDate.subscribe(function () {
				self.applicationDateError(false);
			}));
		}

		self.permitStatusChange().setProperties(self.permit());

		permitEditSubscriptions.push(self.permitStatusChange().closeDate.subscribe(function () {
			self.closeDateError(false);
		}));

		permitEditSubscriptions.push(self.permitStatusChange().revokeDate.subscribe(function () {
			self.revokeDateError(false);
		}));

		self.isPermitInfoEditing(true);
	};

	this.cancelPermitInfoEditAsking = function () {
		if ((self.user.userIsRdaa() && permitInfoHasChanges())
			|| (self.user.userIsIaaa()
				&& (self.permitStatusChange().status() !== self.permit().status))) {
			demax.inspections.popupManager.confirm({
				message: "Промените Ви ще бъдат загубени. Сигурни ли сте че искате да продължите?",
				okButtonText: "Да",
				cancelButtonText: "Не",
				cssClass: "popError",
				okButtonCss: "btn-primary"
			}).done(function () {
				cancelPermitInfoEdit();
			});
		} else {
			cancelPermitInfoEdit();
		}
	};

	function cancelPermitInfoEdit() {
		self.isPermitInfoEditing(false);
		self.permitStatusChange().setProperties(self.permit());

		permitEditSubscriptions.forEach(function (subscription) {
			subscription.dispose();
		});
	}

	this.onSelectedCity = function (selectedCity) {
		self.permitInfoEdit().ktpCity(selectedCity);
		self.ktpCityNameInput(selectedCity.name);
	};


	this.clearInput = function (observable) {
		observable(null);
	};

	this.openPermitPdf = function () {
		demax.inspections.popupManager.confirm({
			message: "Сигурни ли сте, че искате да разпечатате Разрешението и списъците с линии и специалисти?",
			okButtonText: "Да",
			cancelButtonText: "Не",
			cssClass: "popInfo",
			okButtonCss: "btn-primary"
		}).done(function () {

			blobClient.downloadBlob(URL.PERMIT_PDF).handleErrors({
				PermitInspectorInvalidOrMissingStampException: function() {
					popupManager.warn("Липсват или има невадлидни печати на специалист/и.");
				}
			});
		});
	};

	this.openPermitLightPdf = function () {
		demax.inspections.popupManager.confirm({
			message: "Сигурни ли сте, че искате да разпечатате Разрешението?",
			okButtonText: "Да",
			cancelButtonText: "Не",
			cssClass: "popError",
			okButtonCss: "btn-primary"
		}).done(function () {
			blobClient.downloadBlob(URL.PERMIT_LIGHT_PDF);
		});
	};

	this.openPermitLightPdfDuplicate = function () {
		demax.inspections.popupManager.confirm({
			message: "Сигурни ли сте, че искате да разпечатате Дубликат на Разрешението?",
			okButtonText: "Да",
			cancelButtonText: "Не",
			cssClass: "popError",
			okButtonCss: "btn-primary"
		}).done(function () {
			blobClient.downloadBlob(URL.PERMIT_LIGHT_PDF_DUPLICATE);
		});
	};

	this.permitInfoHasChanges = function (changeCodeObject) {
		return self.permitInfoChanges()[changeCodeObject.code] != null;
	};

	this.inspectorHasChanges = function (id) {
		return self.inspectorChanges()[id] != null;
	};

	this.lineHasChanges = function (id) {
		return self.lineChanges()[id] != null;
	};

	this.documentHasChanges = function (id) {
		return self.documentChanges()[id] != null;
	};

	this.inspectionHasChanges = function (id) {
		return self.inspectionChanges()[id] != null;
	};

	this.setDatePickerMinDate = function (elementId) {
		var element = $("#" + elementId);
		var picker = $(element).data("DateTimePicker");

		var date = self.permit().validFrom ? self.permit().validFrom : self.permit().issuedOn;

		picker.minDate(date);
	};

	this.setDatePickerMaxDate = function (elementId) {
		if (self.isPermitCreated()) {

			var element = $("#" + elementId);
			var picker = $(element).data("DateTimePicker");
			
			var date = moment(self.permit().applicationDate);
			date.add(PERMIT_INSPECTION_PERIOD, "days");
			
			picker.maxDate(date);
		}
	};

	this.sendConsumable = function () {
		demax.inspections.router.setHash("consumables/requests/new", { permitNumber: self.permit().permitNumber });
	};

	function setUrls(id) {
		Object.keys(URL).forEach(function (key) {
			URL[key] = URL[key].replace("{id}", id);
		});
	}

	function getAppliedDocumentsPage(page) {
		return restClient.getResource(URL.PERMIT_DETAILS_APPLIED_DOCUMENTS, {
			page: page
		}).done(function (documents) {
			self.permit().documents(documents.items.map(function (document) {
				return new demax.inspections.model.permits.PermitDetailsAppliedDocument(document);
			}));
			self.documentsCount(documents.totalCount);
		}).handleErrors(errorHandlers);
	}

	function getInspectorsPage(page) {
		return restClient.getResource(URL.PERMIT_DETAILS_INSPECTORS, {
			page: page
		}).done(function (inspectors) {
			self.permit().inspectors(inspectors.items.map(function (inspector) {
				return new demax.inspections.model.permits.PermitDetailsPermitInspector(inspector);
			}));
			self.inspectorsCount(inspectors.totalCount);
		}).handleErrors(errorHandlers);
	}

	function getPermitLinesPage(page) {
		return restClient.getResource(URL.PERMIT_DETAILS_PERMIT_LINES, {
			page: page
		})
			.done(function (permitLines) {
				self.permit().permitLines(permitLines.items.map(function (permitLine) {
					return new demax.inspections.model.permits.PermitDetailsPermitLine(permitLine);
				}));
				self.permitLinesCount(permitLines.totalCount);
			}).handleErrors(errorHandlers);
	}

	function getWaitingProblemsCount() {
		return restClient.getResource(URL.PERMIT_PROBLEMS_COUNT, {
			searchTerm: self.permit().permitNumber,
			status: 1
		})
			.done(function (waitingPermitProblemsCount) {
				self.waitingPermitProblemsCount(waitingPermitProblemsCount);
			});
	}

	function ktpInfoHasChanges() {
		for (var prop in self.ktpInfo()) {
			if (self.ktpInfo()[prop] instanceof Function) {
				if (self.ktpInfo()[prop]() !== self.permit().additionalInfo()[prop]()) {
					if (self.ktpInfo()[prop]() instanceof Object) {
						continue;
					}
					return true;
				}
			}
		}
	}

	function validatePermitStatusChange() {
		var hasErrors = false;

		if (self.permitStatusChange().status() === self.PermitStatus.REVOKED && !self.permitStatusChange().revokeDate()) {
			self.revokeDateError(true);
			hasErrors = true;
		}

		if (self.permitStatusChange().status() === self.PermitStatus.CLOSED && !self.permitStatusChange().closeDate() && self.user.userIsIaaa()) {
			self.closeDateError(true);
			hasErrors = true;
		}

		if (self.permitStatusChange().status()) {
			var group = self.permitStatusChange().getValidationGroup();
			if (group().length > 0) {
				group.showAllMessages();
				hasErrors = true;
			}
		}

		return hasErrors;
	}

	function permitStatusHasChanges() {

		// RDAA
		if (self.user.userIsRdaa() && self.permit().status === self.PermitStatus.DRAFT) {
			if (self.permitStatusChange().status() === self.permit().statusChange) {
				if (self.permitStatusChange().status() === self.PermitStatus.REVOKED) {
					if (self.permit().closeDate && self.permitStatusChange().revokeDate() ?
						!self.permit().closeDate.isSame(self.permitStatusChange().revokeDate())
						: self.permit().closeDate != self.permitStatusChange().revokeDate()) {
						return true;
					}

					if (self.permit().closeReason !== self.permitStatusChange().revokeReason()) {
						return true;
					}
				} else if (self.permitStatusChange().status() === self.PermitStatus.CLOSED) {
					if (self.permit().closeDate && self.permitStatusChange().closeDate() ?
						!self.permit().closeDate.isSame(self.permitStatusChange().closeDate())
						: self.permit().closeDate != self.permitStatusChange().closeDate()) {
						return true;
					}

					if (self.permit().closeReason !== self.permitStatusChange().closeApplicationNumber()) {
						return true;
					}
				}

				return false;
			} else if (!self.permitStatusChange().status() && self.permit().statusChange.code === "") {
				return false;
			} else {
				return true;
			}
		} else if (self.user.userIsIaaa()) {
			// IAAA
			if (self.permitStatusChange().status() !== self.permit().status) {
				return true;
			} else {
				if (self.permitStatusChange().status() === self.PermitStatus.REVOKED) {
					if (self.permit().closeDate && self.permitStatusChange().revokeDate() ?
						!self.permit().closeDate.isSame(self.permitStatusChange().revokeDate())
						: self.permit().closeDate != self.permitStatusChange().revokeDate()) {
						return true;
					}

					if (self.permit().closeReason !== self.permitStatusChange().revokeReason()) {
						return true;
					}
				} else if (self.permitStatusChange().status() === self.PermitStatus.CLOSED) {
					if (self.permit().closeDate && self.permitStatusChange().closeDate() ?
						!self.permit().closeDate.isSame(self.permitStatusChange().closeDate())
						: self.permit().closeDate != self.permitStatusChange().closeDate()) {
						return true;
					}

					if (self.permit().closeReason !== self.permitStatusChange().closeApplicationNumber()) {
						return true;
					}
				}
			}
		}

		return false;
	}

	function permitInfoHasChanges() {

		//longer code because it"s easier for debugging
		if (self.permit().applicationNumber !== self.permitInfoEdit().applicationNumber()) {
			return true;
		}

		if (self.permit().applicationDate ? !self.permit().applicationDate.isSame(self.permitInfoEdit().applicationDate()) : self.permitInfoEdit().applicationDate()) {
			return true;
		}

		if (permitStatusHasChanges()) {
			return true;
		}

		if (self.permit().ktpAddress !== self.permitInfoEdit().ktpAddress()) {
			return true;
		}

		if (self.permit().contactKtpPhone !== self.permitInfoEdit().contactKtpPhone()) {
			return true;
		}

		if (self.permit().contactKtpEmail !== self.permitInfoEdit().contactKtpEmail()) {
			return true;
		}

		if (self.permit().ktpCity && self.permitInfoEdit().ktpCity() ?
			self.permit().ktpCity.code !== self.permitInfoEdit().ktpCity().code
			: !self.permit().ktpCity && !self.permitInfoEdit().ktpCity()) {
			return true;
		}

		return false;
	}

	function getPermitInfoValidator() {

		var validator = {};
		validator.hasErrors = ko.observable(false);

		validator.documents = ko.observable();
		validator.inspectors = ko.observable();
		validator.lines = ko.observable();

		validator.ktpCity = ko.observable();
		validator.ktpAddress = ko.observable();
		validator.contactKtpPhone = ko.observable();
		validator.contactKtpEmail = ko.observable();

		if (self.isPermitCreated()) {
			validator.applicationNumber = ko.observable();
			validator.applicationDate = ko.observable();

			if (!self.permit().applicationNumber || self.permit().applicationNumber.trim() === "") {
				validator.hasErrors(true);
				validator.applicationNumber(true);
			}

			if (!self.permit().applicationDate) {
				validator.hasErrors(true);
				validator.applicationDate(true);
			}
		}

		if (!self.permit().ktpCity || !self.permit().ktpCity.code) {
			validator.hasErrors(true);
			validator.ktpCity(true);
		}

		if (!self.permit().ktpAddress || self.permit().ktpAddress.trim() === "") {
			validator.hasErrors(true);
			validator.ktpAddress(true);
		}

		if (!self.permit().contactKtpPhone || self.permit().contactKtpPhone.trim() === "") {
			validator.hasErrors(true);
			validator.contactKtpPhone(true);
		}

		// if (!self.permit().contactKtpEmail || self.permit().contactKtpEmail.trim() === "") {
		// 	validator.hasErrors(true);
		// 	validator.contactKtpEmail(true);
		// }

		return validator;
	}
};