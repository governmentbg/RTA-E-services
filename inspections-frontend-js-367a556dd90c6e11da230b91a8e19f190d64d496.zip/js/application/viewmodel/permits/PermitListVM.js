namespace("demax.inspections.viewmodel.permits");

demax.inspections.viewmodel.permits.PermitListVM = function () {
	var self = this;
	var subscriptions = [];

	var PermitSearchFilter = demax.inspections.model.permits.PermitSearchFilters;
	var PermitStatuses = demax.inspections.nomenclature.permits.PermitStatus;
	var userUtil = demax.inspections.utils.UserUtils;
	var KtpCategories = demax.inspections.nomenclature.permits.KtpCategory;
	var restClient = demax.inspections.restClient;

	var Event = demax.inspections.Event;
	var eventsQueue = demax.inspections.events;


	var URL = {
		LICENSES: "api/permits",
		PERMITS_COUNT_BY_SEARCH: "api/permits/count-by-search"
	};

	var thisNamespace = ".permitListVm";

	this.isLoading = restClient.isLoading;

	this.pageSizes = [20, 50, 100];
	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: self.pageSizes[0]
	});

	self.user = demax.inspections.authenticatedUser();

	this.orgUnits = ko.observableArray(userUtil.getOrgUnits());
	this.ktpCategories = ko.observableArray(KtpCategories.ALL);
	this.statusOptions = ko.observableArray(
		!self.user.userIsRdaa() ? PermitStatuses.EVERY_STATUS_WITHOUT_CREATED_AND_DRAFT : PermitStatuses.EVERY_STATUS);
	this.permits = ko.observable(0);
	this.permitsCount = ko.observable();
	this.permitsWithoutPrintedListsCount = ko.observable();
	this.PermitStatuses = PermitStatuses;

	this.filters = new PermitSearchFilter();

	this.getPreviewPermitHref = function (data) {
		return "#/permits/details/" + data.id;
	};

	this.init = function () {

		restoreMemento();
		loadPermits();
		loadPermitWithoutPrintedListsCount();
		subscribeToKeyEvents();

		subscriptions.push(self.pagination.queryParamsObject.subscribe(function () {
			self.filters.loadLastUsedFilters();
			loadPermits();
		}));

	};

	this.performNewSearch = function () {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadPermits();
		} else {
			self.pagination.page(1);
		}
	};

	this.refresh = function () {
		self.filters.loadLastUsedFilters();
		loadPermits();
	};

	this.showPermitsWithoutPrintedLists = function () {
		self.filters.isListPrinted(false);
		self.filters.status(PermitStatuses.VALID);
		self.performNewSearch();
	};

	function loadPermits() {
		var pageParams = self.pagination.queryParamsObject();
		var searchParams = self.filters.toQueryParams();
		var params = $.extend({}, pageParams, searchParams);

		self.permits([]);
		self.permitsCount(0);
		restClient.getResource(URL.LICENSES, params)
			.done(function (response) {
				self.permits(ko.utils.arrayMap(response.items, function (permitDto) {
					return new demax.inspections.model.permits.PermitListItem(permitDto);
				}));
				self.permitsCount(response.totalCount);
			});
	}

	function loadPermitWithoutPrintedListsCount() {
		var searchParams1 = self.filters.toQueryParams();
		searchParams1.isListPrinted = false;
		searchParams1.statusCode = PermitStatuses.VALID.code;
		var params = $.extend({}, searchParams1);
		restClient.getResource(URL.PERMITS_COUNT_BY_SEARCH, params)
			.done(function (response) {
				self.permitsWithoutPrintedListsCount(response);
			});
	}

	function onEnter() {
		var isLoading = self.isLoading();
		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}
			if (memento.filterParams.ktpCategory) {
				self.filters.ktpCategory(memento.filterParams.ktpCategory);
			}
			if (memento.filterParams.status) {
				self.filters.status(memento.filterParams.status);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(memento.filterParams.orgUnit);
			}
		}
		self.filters.saveLastUsedFilters();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	function subscribeToKeyEvents() {
		eventsQueue.subscribe(Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	}

	function unsubscribeFromKeyEvents() {
		eventsQueue.unsubscribe(Event.KEYPRESS_ENTER + thisNamespace);
	}

	this.dispose = function () {
		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});

		saveMemento();
		unsubscribeFromKeyEvents();
		restClient.cancelAll();
	};
};
