namespace("demax.inspections.viewmodel.permits.inspectors");

demax.inspections.viewmodel.permits.inspectors.DepriveInspectorsOfRightsVM = function () {
	var self = this;
	var restClient = demax.inspections.restClient;
	var KnockoutPropertyUtil = demax.inspections.utils.KnockoutPropertyUtil;

	var URL = {
		PERMIT_STATUS_NUMBER: "api/permits/{0}/status-number",
		DEPRIVE_OF_RIGHTS: "api/permits/{0}/inspectors/deprive-of-rights",
		DEPRIVE_OF_RIGHTS_CHECK: "api/permits/{0}/inspectors/deprive-of-rights-check"
	};

	this.permitId = ko.observable();
	this.permitNumber = ko.observable();

	this.rows = ko.observableArray();
	this.initialRows = ko.observableArray();

	this.isLoading = restClient.isLoading;
	this.checkedInspectorIds = ko.observableArray();

	this.init = function (params) {
		this.permitId(params.id);

		var depriveUrl = pastel.util.StringHelper.format(URL.DEPRIVE_OF_RIGHTS, self.permitId());
		var permitNumberUrl = pastel.util.StringHelper.format(URL.PERMIT_STATUS_NUMBER, self.permitId());

		restClient.getResource(permitNumberUrl)
			.done(function (result) {
				self.permitNumber(result.number);
			});

		restClient.getResource(depriveUrl)
			.done(function (result) {
				result.forEach(function (item) {
					self.rows.push(new demax.inspections.model.permits.inspectors.InspectorWithPermitNumbersDto(item));
					self.initialRows.push(new demax.inspections.model.permits.inspectors.InspectorWithPermitNumbersDto(item));
				});
			});

	};

	this.save = function () {

		if (self.checkedInspectorIds().length) {

			restClient.getResource(pastel.util.StringHelper.format(URL.DEPRIVE_OF_RIGHTS_CHECK, self.permitId()), {
				inspectorIds: self.checkedInspectorIds().join(",")
			}).done(function(permitNumbers) {
					
				var popUpOptions = {
					cssClass: "popInfo",
					message: "Сигурни ли сте, че искате да отнемете правата на избраните специалисти? Техните права ще бъдат отнети и от останалите разрешения, в които участват.",
					okButtonCss: "btn-primary"
				};

				if (permitNumbers.length > 0) {
					popUpOptions.message += " Поради това следните разрешения ще бъдат невалидни:";
					popUpOptions.message2 = permitNumbers.join(", ");
				}

				demax.inspections.popupManager.confirm(popUpOptions)
					.done(function () {
						var url = pastel.util.StringHelper.format(URL.DEPRIVE_OF_RIGHTS, self.permitId());

						var list = [];
						self.rows().forEach(function (row) {
							if (row.isChecked()) {
								list.push(row.getEntry());
							}
						});

						restClient.putResource(url, JSON.stringify(list))
							.done(function (newPermitVersionId) {
								if (self.permitId() !== newPermitVersionId) {
									demax.inspections.router.setHash("permits/details/" + newPermitVersionId);
								}
							});
					});
			});
		} else {
			demax.inspections.popupManager.info("Моля изберете поне един от специалистите");
		}

	};

	this.cancel = function () {
		var url = "permits/details/" + self.permitId();
		if (rowsHaveChanges()) {
			demax.inspections.popupManager.confirm({
				cssClass: "popInfo",
				message: "Сигурни ли сте, че искате да отхвърлите промените си?",
				okButtonCss: "btn-primary"
			}).done(function () {
				demax.inspections.router.setHash(url);
			});
		} else {
			demax.inspections.router.setHash(url);
		}
	};

	this.dispose = function () {
		restClient.cancelAll();
	};

	this.checkAll = function () {
		if (self.allIsChecked()) {
			self.checkedInspectorIds([]);
			self.rows().forEach(function (inspector) {
				inspector.isChecked(false);
			});
		} else {
			self.checkedInspectorIds([]);
			self.rows().forEach(function (inspector) {
				inspector.isChecked(true);
				self.checkedInspectorIds.push(inspector.id);
			});
		}
	};

	self.allIsChecked = ko.pureComputed(function () {
		return self.checkedInspectorIds().length === self.rows().length;
	});


	this.checkInspector = function (inspector) {
		var index = self.checkedInspectorIds.indexOf(inspector.id);
		if (index > -1) {
			self.checkedInspectorIds.splice(index, 1);
		} else {
			self.checkedInspectorIds.push(inspector.id);
		}
		inspector.check();
	};

	function rowsHaveChanges() {
		return KnockoutPropertyUtil.hasChangesArray(self.rows(), self.initialRows());
	}

};