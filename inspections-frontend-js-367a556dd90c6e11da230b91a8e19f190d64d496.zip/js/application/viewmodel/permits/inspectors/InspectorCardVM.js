namespace("demax.inspections.viewmodel.permits.inspectors");

demax.inspections.viewmodel.permits.inspectors.InspectorCardVM = function () {
	var self = this;
	var restClient = demax.inspections.restClient;
	var KnockoutPropertyUtil = demax.inspections.utils.KnockoutPropertyUtil;

	this.card = new demax.inspections.model.permits.inspectors.InspectorCardParams();
	this.initialCard = new demax.inspections.model.permits.inspectors.InspectorCardParams();

	this.subjectId = null;
	this.cardId = null;
	this.permitId = ko.observable();
	this.inspectorId = ko.observable();
	this.permitNumber = ko.observable();

	this.isLoading = restClient.isLoading;
	this.isNew = ko.observable(false);
	this.canEdit = ko.observable(false);
	this.isEditing = ko.observable(false);

	var user = demax.inspections.authenticatedUser();
	var editableParams = ["cardNumber", "serialNumber", "commonName", "remarks", "isActive"];

	var URL = {
		CREATE_CARD: "api/permits/{0}/subjects/{1}/cards",
		UPDATE_CARD: "api/permits/{0}/subjects/{1}/cards/{2}",
		GET_CARD: "api/permits/{0}/subjects/{1}/cards/{2}",
		GET_PERMIT_STATUS_NUM: "api/permits/{0}/status-number",
		GET_INSPECTOR_EDUCATION: "api/permits/{0}/inspectors/{1}/education"
	};

	var errorHandlers = {
		NoSuchEntityException: function (error) {
			if (error.indexOf("PermitVersion") > -1) {
				demax.inspections.popupManager.error("Няма намерено Разрешение с такъв номер.").done(function () {
					demax.inspections.router.setHash("permits");
				});
			} else if (error.indexOf("PermitInspectorVersion") > -1) {
				demax.inspections.popupManager.error("Няма намерен инспектор с такъв номер.").done(function () {
					demax.inspections.router.setHash("permits/details/" + self.permitId());
				});
			} else if (error.indexOf("PermitInspectorCard") > -1) {
				demax.inspections.popupManager.error("Няма намерен карта с такъв номер.").done(function () {
					self.redirect();
				});
			} else if (error.indexOf("Subject") > -1) {
				demax.inspections.popupManager.error("Няма намерен субект.").done(function () {
					self.redirect();
				});
			}
		},
		PermitInspectorInvalidStatusException: function () {
			demax.inspections.popupManager.error("Инспекторът има невалиден статус.");
		},
		EntityAlreadyExistsException: function () {
			demax.inspections.popupManager.error("Вече съществува карта с такъв номер.");
		},
		SubjectIsNotChairmanException: function () {
			demax.inspections.popupManager.error("Инспекторът не е председател в нито едно разрешение!");
		}, 
		PermitDoesNotContainSubject: function () {
			demax.inspections.popupManager.error("Инспекторът не се съдържа в това разрешение!");
		}
	};

	this.init = function (params) {
		self.permitId(params.id);
		self.inspectorId(params.inspectorId);
		self.cardId = params.cardId;
		self.subjectId = params.subjectId;

		restClient.getResource(pastel.util.StringHelper.format(URL.GET_PERMIT_STATUS_NUM, params.id))
			.done(function (result) {
				self.permitNumber(result.number ? result.number : " - ");
			}).handleErrors({
				NoSuchEntityException: function () {
					demax.inspections.popupManager.error("Не е намерено Разрешение с ID " + params.id)
						.done(function () {
							demax.inspections.router.setHash("permits");
						});
				}
			});

		if (self.cardId) {
			restClient.getResource(pastel.util.StringHelper.format(URL.GET_CARD, self.permitId(), self.subjectId, self.cardId))
				.done(function (result) {
					self.card.setUpCard(result);
					self.initialCard.setUpCard(result);
				}).handleErrors({
					NoSuchEntityException: function () {
						demax.inspections.popupManager.error("Не е намерена карта.")
							.done(function () {
								self.redirect();
							});
					}
				});
		} else {
			setUpCreation();
			restClient.getResource(pastel.util.StringHelper.format(URL.GET_INSPECTOR_EDUCATION, self.permitId(), self.inspectorId()))
				.done(function (result) {
					self.card.setUpEducation(result);
				}).handleErrors({
					NoSuchEntityException: function () {
						demax.inspections.popupManager.error("Не е намерена карта.")
							.done(function () {
								self.redirect();
							});
					}
				});
		}

	};

	this.goBackToSpecialist = function () {
		if (cardHasChanges()) {
			demax.inspections.popupManager.confirm({
				cssClass: "popInfo",
				message: "Сигурни ли сте, че искате да отхвърлите промените си?",
				okButtonCss: "btn-primary"
			}).done(function () {
				self.redirect();
			});
		} else {
			self.redirect();
		}
	};

	self.redirect = function () {
		demax.inspections.router.setHash(self.specialistHref());
	};

	self.specialistHref = ko.pureComputed(function () {
		return "#" + pastel.util.StringHelper.format("permits/details/{0}/inspectors/{1}", self.permitId(), self.inspectorId());
	});

	this.toggleEditing = function () {
		if (self.isEditing() && cardHasChanges()) {
			demax.inspections.popupManager.confirm({
				cssClass: "popInfo",
				message: "Сигурни ли сте, че искате да отхвърлите промените си?",
				okButtonCss: "btn-primary"
			}).done(function () {
				rollBackChanges();
				self.isEditing(false);
			});
		} else if (self.isEditing() && !cardHasChanges()) {
			self.isEditing(false);
		} else {
			self.isEditing(true);
		}
	};

	this.saveOrUpdate = function () {
		if (self.cardId) {

			if (!cardHasChanges()) {
				self.toggleEditing();
				return;
			}

			var validationErrors = ko.validation.group([self.card.serialNumber, self.card.cardNumber,
				self.card.commonName, self.card.isActive]);
			if (ko.unwrap(validationErrors()).length > 0) {
				validationErrors.showAllMessages();
				return;
			}

			var url2 = pastel.util.StringHelper.format(URL.UPDATE_CARD, self.permitId(), self.subjectId, self.cardId);
			restClient.putResource(url2, self.card.toRequestBodyForUpdate())
				.done(function () {
					applyChanges();
					self.isEditing(false);
				}).handleErrors(errorHandlers);
		} else {

			validationErrors = ko.validation.group([self.card.serialNumber, self.card.cardNumber,
				self.card.commonName]);
			if (ko.unwrap(validationErrors()).length > 0) {
				validationErrors.showAllMessages();
				return;
			}

			var url3 = pastel.util.StringHelper.format(URL.CREATE_CARD, self.permitId(), self.subjectId);
			restClient.postResource(url3, self.card.toRequestBody())
				.done(function () {
					self.redirect();
				}).handleErrors(errorHandlers);
		}
	};

	this.isEditingAndCanEdit = ko.pureComputed(function () {
		return (self.isEditing() && self.canEdit());
	});

	this.canEdit = ko.pureComputed(function () {
		return user.userIsCallCenter() && (self.isNew() || self.isEditing() || self.card.isActive());
	});

	this.dispose = function() {
		restClient.cancelAll();
	};

	function cardHasChanges() {
		return KnockoutPropertyUtil.hasChanges(self.card, self.initialCard, editableParams);
	}

	function rollBackChanges() {
		KnockoutPropertyUtil.copyProperties(self.initialCard, self.card, editableParams);
	}

	function applyChanges() {
		KnockoutPropertyUtil.copyProperties(self.card, self.initialCard, editableParams);
	}

	function setUpCreation() {
		self.isNew(true);
		self.isEditing(true);
	}

};
