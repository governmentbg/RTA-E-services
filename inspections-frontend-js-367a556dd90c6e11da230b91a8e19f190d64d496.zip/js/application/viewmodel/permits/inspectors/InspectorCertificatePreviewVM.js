namespace("demax.inspections.viewmodel.permits.inspectors");

demax.inspections.viewmodel.permits.inspectors.InspectorCertificatePreview = function () {
	var self = this;
	var restClient = demax.inspections.restClient;
	var URLS = {
		BASE_URL: "api/permits/{0}/inspectors/{1}/certifications/{2}",
		PERMIT_STATUS_NUMBER_URL: "api/permits/{0}/status-number"
	};
	this.certificate = ko.observable();
	this.permitNumber = ko.observable();
	this.inspectorId = ko.observable();
	this.permitId = ko.observable();
	this.isLoading = restClient.isLoading;

	var errorHandlers = {
		NoSuchEntityException: function (error) {
			if (error.indexOf("PermitVersion") > -1) {
				demax.inspections.popupManager.error("Няма намерено Разрешение с такъв номер").done(function () {
					demax.inspections.router.setHash("permits");
				});
			} else if (error.indexOf("PermitInspectorVersion") > -1) {
				demax.inspections.popupManager.error("Няма намерен инспектор с такъв номер").done(function () {
					demax.inspections.router.setHash("permits/details/" + self.permitId());
				});
			} else if (error.indexOf("InspectorCertification") > -1) {
				demax.inspections.popupManager.error("Няма намерено удостоверение с такъв номер").done(function () {
					demax.inspections.router.setHash("permits/details/" + self.permitId() + "/inspectors/" + self.inspectorId());
				});
			}
		},
		InspectorNotFoundForPermitException: function () {
			demax.inspections.popupManager.error("Инспекторът не принадлежи към посоченото разрешение").done(function () {
				demax.inspections.router.setHash("permits/details/" + self.permitId());
			});
		}
	};

	this.init = function (params) {
		self.inspectorId(params.inspectorId);
		self.permitId(params.id);

		loadCertificateDetails(params.id, params.inspectorId, params.certificateId);
		getPermitNumber(params.id);
	};

	this.goBackToSpecialist = function () {
		demax.inspections.router.setHash(self.specialistHref());
	};

	self.specialistHref = ko.pureComputed(function () {
		return "#" + pastel.util.StringHelper.format("permits/details/{0}/inspectors/{1}", self.permitId(), self.inspectorId());
	});

	function loadCertificateDetails(permitVersionId, inspectorVersionId, certificateId) {
		restClient.getResource(pastel.util.StringHelper.format(URLS.BASE_URL, permitVersionId, inspectorVersionId, certificateId))
			.done(function (result) {
				self.certificate(new demax.inspections.model.permits.inspectors.InspectorCertificateDetails(result));
			}).handleErrors(errorHandlers);
	}

	function getPermitNumber(permitVersionId) {
		restClient.getResource(pastel.util.StringHelper.format(URLS.PERMIT_STATUS_NUMBER_URL, permitVersionId))
			.done(function (result) {
				self.permitNumber(result.number ? result.number : " - ");
			});
	}
};