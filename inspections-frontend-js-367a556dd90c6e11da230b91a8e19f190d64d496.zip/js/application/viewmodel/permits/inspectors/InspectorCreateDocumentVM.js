namespace("demax.inspections.viewmodel.permits.inspectors");

demax.inspections.viewmodel.permits.inspectors.InspectorCreateDocumentVM = function () {
	var self = this;
	var KnockoutPropertyUtil = demax.inspections.utils.KnockoutPropertyUtil;
	this.user = demax.inspections.authenticatedUser();
	this.isEditing = ko.observable(true);
	this.isEditPage = ko.observable(false);
	this.isEditableStatus = ko.observable(false);
	this.selectedFiles = ko.observableArray();
	this.document = new demax.inspections.model.permits.inspectors.InspectorDocumentCreate();
	this.documentPreview = new demax.inspections.model.permits.inspectors.InspectorDocumentCreate();
	this.imageDownloadUrl = undefined;
	this.inspectorWithEducation = new demax.inspections.model.permits.inspectors.InspectorWithEducation();
	this.createDocumentUrl = ko.observable();
	this.updateDocumentUrl = ko.observable();
	this.inspectorUrl = ko.observable();
	this.inspectorRedirectUrl = ko.observable();

	var PermitDocumentStatuses = demax.inspections.nomenclature.permits.PermitDocumentStatus;
	this.statusOptions = ko.observableArray(PermitDocumentStatuses.REAL_STATUSES);

	this.isLoading = ko.pureComputed(function () {
		return restClient.isLoading() || blobClient.isLoading();
	});

	this.permitId = ko.observable();
	this.inspectorId = ko.observable();
	this.permitNumber = ko.observable();
	this.hasValidToDate = ko.pureComputed(function () {
		if (self.document && self.document.documentType()) {
			if (!self.document.documentType().hasValidToDate) {
				return true;
			} else {
				return false;
			}
		} else {
			return true;
		}
	});
	this.disableButton = ko.observable(false);

	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;

	var PermitStatus = demax.inspections.nomenclature.permits.PermitStatus;

	var URLS = {
		DOCUMENT_DETAILS: "api/permit-inspectors/subjects/{0}/documents/{1}",
		INSPECTOR_DETAILS: "api/permits/{0}/inspectors/{1}/education",
		CREATE_DOCUMENT: "api/permits/{0}/inspectors/{1}/documents",
		EDIT_NEW_DOCUMENT: "api/permits/{0}/inspectors/{1}/documents/{2}/new",
		EDIT_APPROVED_DOCUMENT: "api/permits/{0}/inspectors/{1}/documents/{2}/approved",
		INSPECTOR_URL: "api/permits/{0}/inspectors/{1}",
		GET_PERMIT_STATUS_NUMBER: "api/permits/{0}/status-number",
		INSPECTOR_REDIRECT: "permits/details/{0}/inspectors/{1}",
		GET_DOCUMENT_TYPES: "api/nomenclatures/permit-document-types/inspectors"
	};
	var isCloned = false;
	var errorHandlers = {
		NoSuchEntityException: function (message) {
			if (message.indexOf("PermitVersion") > -1) {
				demax.inspections.popupManager.error("Няма намерено Разрешение с такъв номер").done(function () {
					demax.inspections.router.setHash(self.inspectorRedirectUrl());
				});
			} else if (message.indexOf("PermitInspectorVersion") > -1) {
				demax.inspections.popupManager.error("Няма намерен инспектор с такъв номер").done(function () {
					demax.inspections.router.setHash("permits/details/" + self.permitId());
				});
			}
		},
		NoAuthorityException: function () {
			demax.inspections.popupManager.error("Потребителят няма право да добавя нови документи");
		},
		InspectorNotFoundForPermitException: function () {
			demax.inspections.popupManager.error("Инспекторът не обвързан с това Разрешение");
		},
		PermitInspectorAlreadyHasDraftSnapshotException: function () {
			demax.inspections.popupManager.error("Този инспектор е добавен в друго Разрешението, което е в процес на обработка");
		},
		SubjectDocumentNotFoundForInspectorException: function () {
			demax.inspections.popupManager.error("Не е намерен документ за този инспектор");
		},
		PermitInspectorInvalidStatusException: function () {
			demax.inspections.popupManager.error("Инспекторът има невалиден статус.");
		},
		SubjectDocumentNotFoundForSubjectException: function () {
			demax.inspections.popupManager.error("Не е намерен документ за този инспектор");
		}
	};
	this.documentTypes = ko.observableArray();


	this.fileSelect = function (_element, event) {
		var file = event.target.files[0];
		self.selectedFiles.removeAll();
		self.selectedFiles.push(file);

		if (!file.type.match("(pdf|jpg|jpeg|png)")) {
			demax.inspections.popupManager.error("Моля прикачете PDF, JPG или PNG файл!");
			clearFile();
			return;
		}
		if (file.size > 5000000) {
			demax.inspections.popupManager.error("Моля прикачете файл с размер по-малък от 5MB!");
			clearFile();
			return;
		}
		var reader = new FileReader();
		reader.onload = (function () {
			return function (e) {
				var base64 = e.target.result;
				self.document.image(base64.substring(base64.indexOf(",") + 1));
			};
		})(file);
		reader.readAsDataURL(file);
	};

	this.init = function (params) {

		restClient.getResource(URLS.GET_DOCUMENT_TYPES)
			.done(function (documentTypes) {
				documentTypes.forEach(function (type) {
					self.documentTypes.push(new demax.inspections.model.permits.documents.DocumentType(type));
				});

				restClient.getResource(pastel.util.StringHelper.format(URLS.INSPECTOR_DETAILS, params.id, params.inspectorId))
					.done(function (inspectorDto) {
						self.inspectorWithEducation.setUpInspector(inspectorDto);
						params.subjectId = self.inspectorWithEducation.subjectId();

						if (params.documentId) {
							self.isEditing(false);
							self.isEditPage(true);
							//load document details from service
							restClient.getResource(pastel.util.StringHelper.format(URLS.DOCUMENT_DETAILS, params.subjectId, params.documentId))
								.done(function (document) {
									self.documentPreview.setUpInspectorDocument(document, self.documentTypes());

									if (document.isApproved) {
										self.updateDocumentUrl(pastel.util.StringHelper.format(URLS.EDIT_APPROVED_DOCUMENT, params.id, params.inspectorId, params.documentId));
									} else {
										self.updateDocumentUrl(pastel.util.StringHelper.format(URLS.EDIT_NEW_DOCUMENT, params.id, params.inspectorId, params.documentId));
									}

									self.imageDownloadUrl = pastel.util.StringHelper.format(URLS.DOCUMENT_DETAILS, params.subjectId, params.documentId) + "/image";
								})
								.handleErrors(errorHandlers);
						} else {
							self.createDocumentUrl(pastel.util.StringHelper.format(URLS.CREATE_DOCUMENT, params.id, params.inspectorId));
						}

					})
					.handleErrors(errorHandlers);
			});

		self.inspectorUrl(pastel.util.StringHelper.format(URLS.INSPECTOR_URL, params.id, params.inspectorId));
		self.permitId(params.id);
		self.inspectorId(params.inspectorId);
		self.inspectorRedirectUrl(pastel.util.StringHelper.format(URLS.INSPECTOR_REDIRECT, params.id, params.inspectorId));

		restClient.getResource(pastel.util.StringHelper.format(URLS.GET_PERMIT_STATUS_NUMBER, self.permitId()))
			.done(function (result) {
				self.permitNumber(result.number ? result.number : "-");
				var isEditable = PermitStatus.DRAFT.code === result.status || PermitStatus.CREATED.code === result.status;
				self.isEditableStatus(isEditable);
			}).handleErrors(errorHandlers);
	};

	this.hasValidityLength = ko.computed(function () {
		if (self.document && self.document.issuedOn()) {
			self.document.updateValidityIfNeeded();
		} 
	});

	this.toggleEditing = function () {
		if (!self.isEditing() && !isCloned) {
			cloneObject(self.documentPreview, self.document);
			isCloned = true;
		}
		if (!self.isEditPage()) {
			return;
		}
		self.isEditing(!self.isEditing());
	};

	this.saveDocument = function () {
		if (self.isLoading()) {
			return;
		}

		var validationErrors = self.document.isApproved() ?
			ko.validation.group([self.document.status])
			: ko.validation.group([
				self.document.documentNumber, self.document.documentType, self.document.issuer,
				self.document.remarks, self.document.issuedOn, self.document.validTo, self.isEditPage() ? {} : self.document.image]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			demax.inspections.popupManager.warn("Има невалидни полета!");
			return;
		}

		if (!self.isEditPage() && self.document.documentType().hasValidToDate && self.document.validTo().isBefore(moment())) {
			demax.inspections.popupManager.warn("Датата \"Валиден до\" не може да бъде преди днешна дата!");
			return;
		}

		if (self.isEditPage() && self.isEditing()) {
			if (self.document.isApproved()) {
				restClient.putResource(self.updateDocumentUrl(), { "statusCode": self.document.status().code })
					.done(function (inspectorId) {
						demax.inspections.popupManager.success({ message: "Успешно променихте данните на документа" }).done(function () {
							demax.inspections.router.setHash(pastel.util.StringHelper.format(URLS.INSPECTOR_REDIRECT, self.permitId(), inspectorId));
						});
					}).handleErrors(errorHandlers);
			} else {
				restClient.putResource(self.updateDocumentUrl(), self.document.toDto())
					.done(function () {
						demax.inspections.popupManager.success({ message: "Успешно променихте данните на документа" }).done(function () {
							demax.inspections.router.setHash(self.inspectorRedirectUrl());
						});
					}).handleErrors(errorHandlers);
			}
		} else {
			restClient.postResource(self.createDocumentUrl(), self.document.toDto())
				.done(function (inspectorId) {
					demax.inspections.popupManager.success({ message: "Успешно добавихте документ към специалист" }).done(function () {
						demax.inspections.router.setHash(pastel.util.StringHelper.format(URLS.INSPECTOR_REDIRECT, self.permitId(), inspectorId));
					});
				}).handleErrors(errorHandlers);
		}
	};

	this.docPicture = ko.pureComputed(function () {
		var docPicture = [];
		$.each(ko.unwrap(self.selectedFiles), function (i, selectedFile) {
			docPicture.push(new demax.inspections.model.FileAttachment(selectedFile));
		});
		return docPicture;
	});

	this.removeDocPicture = function () {
		clearFile();
	};


	function clearFile() {
		self.document.image(null);
		self.selectedFiles.removeAll();
	}

	this.downloadImage = function () {
		blobClient.downloadBlob(self.imageDownloadUrl).fail(function () {
			demax.inspections.popupManager.error("Проблем със свалянето на снимката!");
		});
	};

	this.cancel = function () {
		if (checkForChanges()) {
			demax.inspections.popupManager.confirm(
				{
					message: self.isEditPage() ?
						"Въведените данни ще бъдат изгубени. Сигурни ли сте че искате да прекъснете променянето на документа?"
						: "Въведените данни ще бъдат изгубени. Сигурни ли сте че искате да прекъснете добавянето на нов документ?",
					okButtonText: "Да",
					cancelButtonText: "Не",
					cssClass: "popInfo",
					okButtonCss: "btn-success"
				})
				.done(function () {
					if (self.isEditPage()) {
						self.toggleEditing();
					} else {
						demax.inspections.router.setHash(self.inspectorRedirectUrl());
					}
				});
		} else {
			if (self.isEditPage()) {
				self.toggleEditing();
			} else {
				demax.inspections.router.setHash(self.inspectorRedirectUrl());
			}
		}
	};

	this.dispose = function () {
		restClient.cancelAll();
		blobClient.cancelAll();
		this.hasValidityLength.dispose();
	};

	function cloneObject(from, to) {
		KnockoutPropertyUtil.copyProperties(from, to,
			[
				"documentNumber",
				"issuer",
				"remarks",
				"issuedOn",
				"validTo",
				"image",
				"status",
				"isApproved"
			]
		);

		to.documentType(from.documentType());
	}

	function checkForChanges() {
		return KnockoutPropertyUtil.hasChanges(self.document, self.documentPreview,
			[
				"documentNumber",
				"documentType",
				"issuer",
				"remarks",
				"issuedOn",
				"validTo",
				"image",
				"status"
			]
		);
	}
};