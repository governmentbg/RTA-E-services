namespace("demax.inspections.viewmodel.permits.inspectors");

demax.inspections.viewmodel.permits.inspectors.InspectorStampVM = function () {
	var self = this;
	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;
	var KnockoutPropertyUtil = demax.inspections.utils.KnockoutPropertyUtil;
	var InspectorStampType = demax.inspections.nomenclature.permits.inspectors.InspectorStampType;
	var InspectorStampStatus = demax.inspections.nomenclature.permits.inspectors.InspectorStampStatus;

	this.stamp = new demax.inspections.model.permits.inspectors.InspectorStampParams();
	this.initialStamp = new demax.inspections.model.permits.inspectors.InspectorStampParams();

	this.permitId = ko.observable();
	this.inspectorId = null;
	this.stampId = null;
	this.permitNumber = ko.observable();

	this.selectedFiles = ko.observableArray();
	this.imageDownloadUrl = undefined;
	this.isLoading = restClient.isLoading;
	this.isNew = ko.observable(false);
	this.canEdit = ko.observable(false);
	this.isEditing = ko.observable(false);
	self.stampTypes = ko.observableArray(InspectorStampType.ALL);
	self.stampStatuses = ko.observableArray(InspectorStampStatus.ALL);

	self.stampHistory = ko.observableArray();

	var user = demax.inspections.authenticatedUser();
	var editableParams = ["stampTypeId", "remarks", "revokedOn", "statusCode", "image"];

	var URL = {
		CREATE_STAMP: "api/permits/{0}/inspectors/{1}/stamps",
		UPDATE_STAMP: "api/permits/{0}/inspectors/{1}/stamps/{2}",
		GET_STAMP: "api/permits/{0}/inspectors/{1}/stamps/{2}",
		GET_STAMP_HISTORY: "api/permits/{0}/inspectors/{1}/stamps/{2}/history",
		GET_INSPECTOR_EDUCATION: "api/permits/{0}/inspectors/{1}/education",
		GET_PERMIT_STATUS_NUM: "api/permits/{0}/status-number"
	};

	var errorHandlers = {
		NoSuchEntityException: function (error) {
			if (error.indexOf("PermitVersion") > -1) {
				demax.inspections.popupManager.error("Няма намерено Разрешение с такъв номер.").done(function () {
					self.redirect();
				});
			} else if (error.indexOf("PermitInspectorVersion") > -1) {
				demax.inspections.popupManager.error("Няма намерен инспектор с такъв номер.").done(function () {
					demax.inspections.router.setHash("permits/details/" + self.permitId());
				});
			} else if (error.indexOf("PermitInspectorStampType") > -1) {
				demax.inspections.popupManager.error("Няма намерен такъв тип печат.").done(function () {
					self.redirect();
				});
			} else if (error.indexOf("PermitInspectorStampStatus") > -1) {
				demax.inspections.popupManager.error("Няма намерен такъв тип статус.").done(function () {
					self.redirect();
				});
			} else if (error.indexOf("PermitInspectorStampVersion") > -1) {
				demax.inspections.popupManager.error("Няма намерен печат с такъв номер.").done(function () {
					self.redirect();
				});
			}
		},
		PermitInspectorInvalidStatusException: function () {
			demax.inspections.popupManager.error("Невалиденен статус на инспектор!");
		},
		InspectorNotFoundForPermitException: function () {
			demax.inspections.popupManager.error("Инспекторът не обвързан с това Разрешение");
		},
		PermitInspectorAlreadyHasInspectionStampException: function () {
			demax.inspections.popupManager.error("Инспекторът вече има валиден Печат за преглед!");
		}
	};

	this.init = function (params) {

		self.permitId(params.id);
		self.inspectorId = params.inspectorId;
		self.stampId = params.stampId;

		restClient.getResource(pastel.util.StringHelper.format(URL.GET_PERMIT_STATUS_NUM, params.id))
			.done(function (result) {
				self.permitNumber(result.number ? result.number : " - ");
			}).handleErrors({
				NoSuchEntityException: function () {
					demax.inspections.popupManager.error("Не е намерено Разрешение с ID " + params.id)
						.done(function () {
							demax.inspections.router.setHash("permits");
						});
				}
			});

		if (self.stampId) {
			setUpPreview();
			var getStampUrl = pastel.util.StringHelper.format(URL.GET_STAMP, self.permitId(), self.inspectorId, self.stampId);
			restClient.getResource(getStampUrl)
				.done(function (result) {
					self.stamp.setUpStamp(result);
					self.initialStamp.setUpStamp(result);
					self.imageDownloadUrl = getStampUrl + "/image";
					var getStampHistoryUrl = pastel.util.StringHelper.format(URL.GET_STAMP_HISTORY, self.permitId(),
						self.inspectorId, self.stampId);
					restClient.getResource(getStampHistoryUrl)
						.done(function (stamps) {
							var stampVersions = stamps.map(function (stamp) {
								return new demax.inspections.model.permits.inspectors.InspectorStampVersionDto(stamp);
							});

							self.stampHistory(stampVersions);
						});
				}).handleErrors({
					NoSuchEntityException: function () {
						demax.inspections.popupManager.error("Не е намерена печат.")
							.done(function () {
								self.redirect();
							});
					}
				});
		} else {
			setUpCreation();
			restClient.getResource(pastel.util.StringHelper.format(URL.GET_INSPECTOR_EDUCATION, self.permitId(), self.inspectorId))
				.done(function (result) {
					self.stamp.setUpEducation(result);
				}).handleErrors({
					NoSuchEntityException: function () {
						demax.inspections.popupManager.error("Не е намерен печат.")
							.done(function () {
								self.redirect();
							});
					}
				});
		}

	};

	self.isADR = ko.pureComputed(function () {
		return self.stamp.stampTypeId() === InspectorStampType.ADR.id;
	});

	this.redirect = function () {
		var url = "permits/details/{0}/inspectors/{1}";
		demax.inspections.router.setHash(pastel.util.StringHelper.format(url, self.permitId(), self.inspectorId));
	};

	this.reader = new FileReader();
	this.reader.onload = function (event) {
		var base64 = event.target.result;
		self.stamp.image(base64.substring(base64.indexOf(",") + 1));
	};

	this.selectedFiles.subscribe(function () {
		if (self.selectedFiles()[0]) {
			self.reader.readAsDataURL(self.selectedFiles()[0]);
		}
	});

	this.protocolPicture = ko.pureComputed(function () {
		var protocolPicture = [];
		$.each(ko.unwrap(self.selectedFiles), function (i, selectedFile) {
			protocolPicture.push(new demax.inspections.model.FileAttachment(selectedFile));
		});
		return protocolPicture;
	});

	this.removeProtocolPicture = function (attachment) {
		if (attachment instanceof demax.inspections.model.FileAttachment) {
			self.selectedFiles.remove(attachment.file);
			self.stamp.image(undefined);
		}
	};

	this.downloadImage = function () {
		blobClient.downloadBlob(self.imageDownloadUrl).handleErrors({
			PermitInspectorStampDoesNotHaveProtocolException: function () {
				demax.inspections.popupManager.warn("Няма приемо-предавателн протокол за този печат!");
			}
		});
	};

	this.downloadVersionImage = function (data) {
		var getStampUrl = pastel.util.StringHelper.format(URL.GET_STAMP, self.permitId(), self.inspectorId, data.id);

		blobClient.downloadBlob(getStampUrl + "/image").handleErrors({
			PermitInspectorStampDoesNotHaveProtocolException: function () {
				demax.inspections.popupManager.warn("Няма приемо-предавателн протокол за този печат!");
			}
		});
	};

	this.goBackToSpecialist = function () {
		if (stampHasChanges()) {
			demax.inspections.popupManager.confirm({
				cssClass: "popInfo",
				message: "Сигурни ли сте, че искате да отхвърлите промените си?",
				okButtonCss: "btn-primary"
			}).done(function () {
				self.redirect();
			});
		} else {
			self.redirect();
		}
	};

	this.toggleEditing = function () {
		if (self.isEditing() && stampHasChanges()) {
			demax.inspections.popupManager.confirm({
				cssClass: "popInfo",
				message: "Сигурни ли сте, че искате да отхвърлите промените си?",
				okButtonCss: "btn-primary"
			}).done(function () {
				rollBackChanges();
				self.isEditing(false);
			});
		} else if (self.isEditing() && !stampHasChanges()) {
			self.isEditing(false);
		} else {
			self.isEditing(true);
		}
	};

	this.saveOrUpdate = function () {
		if (self.stampId) {

			if (!stampHasChanges()) {
				self.toggleEditing();
				return;
			}

			var validationErrors = ko.validation.group([
				self.stamp.stampTypeId, self.stamp.remarks, self.stamp.stampNumber, self.stamp.revokedOn
			]);
			if (ko.unwrap(validationErrors()).length > 0) {
				validationErrors.showAllMessages();
				return;
			}

			var url1 = pastel.util.StringHelper.format(URL.UPDATE_STAMP, self.permitId(), self.inspectorId, self.stampId);
			restClient.putResource(url1, self.stamp.toRequestBodyForUpdate())
				.done(function (id) {
					if (id != self.stampId) {
						var url = "permits/details/" + self.permitId() + "/inspectors/" + self.inspectorId + "/stamps/" + id;
						demax.inspections.router.setHash(url);
					} else {
						applyChanges();
						self.isEditing(false);
					}
				}).handleErrors(errorHandlers);
		} else {

			validationErrors = ko.validation.group([self.stamp.stampTypeId, self.stamp.remarks, self.stamp.stampNumber]);
			if (ko.unwrap(validationErrors()).length > 0) {
				validationErrors.showAllMessages();
				return;
			}

			var url2 = pastel.util.StringHelper.format(URL.CREATE_STAMP, self.permitId(), self.inspectorId);
			restClient.postResource(url2, self.stamp.toRequestBody())
				.done(function () {
					self.redirect();
				}).handleErrors(errorHandlers);
		}
	};

	this.dispose = function () {
		restClient.cancelAll();
	};

	function rollBackChanges() {
		KnockoutPropertyUtil.copyProperties(self.initialStamp, self.stamp, editableParams);
	}

	function applyChanges() {
		KnockoutPropertyUtil.copyProperties(self.stamp, self.initialStamp, editableParams);
	}

	function stampHasChanges() {
		return KnockoutPropertyUtil.hasChanges(self.stamp, self.initialStamp, editableParams);
	}

	function setUpCreation() {
		self.isNew(true);
		self.isEditing(true);
		setUpPreview();
	}

	function setUpPreview() {
		if (user.userIsIaaa()) {
			self.canEdit(true);
		}
	}

};