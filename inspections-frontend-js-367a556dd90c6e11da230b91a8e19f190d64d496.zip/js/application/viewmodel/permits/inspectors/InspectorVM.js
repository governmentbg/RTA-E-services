namespace("demax.inspections.viewmodel.permits.inspectors");

demax.inspections.viewmodel.permits.inspectors.InspectorVM = function () {
	var self = this;
	var PAGE_SIZE = 5;
	var restClient = demax.inspections.restClient;
	var KnockoutPropertyUtil = demax.inspections.utils.KnockoutPropertyUtil;
	var nomenclatureService = demax.inspections.nomenclature.NomenclatureService;
	var PermitStatus = demax.inspections.nomenclature.permits.PermitStatus;
	var Pagination = pastel.plus.component.pagination.Pagination;

	var URL = {
		SEARCH_EGN: "api/permit-inspectors/search/with-education",
		CREATE_INSPECTOR: "api/permits/{0}/inspectors",
		UPDATE_INSPECTOR: "api/permits/{0}/inspectors/{1}",
		GET_INSPECTOR: "api/permits/{0}/inspectors/{1}",
		INSPECTOR_SPECIALITIES: "api/permit-inspectors/specialities",
		GET_PERMIT_DETAILS: "api/permits/{0}",
		DEPRIVE_OF_RIGHTS: "api/permits/{0}/inspectors/{1}/deprive-of-rights",
		INSPECTOR_CERTIFICATIONS_BY_SUBJECT_ID: "api/permit-inspectors/subjects/{0}/certificates",
		INSPECTOR_CERTIFICATIONS_BY_SUBJECT_ID_PAGED: "api/permit-inspectors/subjects/{0}/certificates/paged",
		INSPECTOR_CERTIFICATION_BY_INSPECTOR_ID: "api/permits/{0}/inspectors/{1}/certifications",
		INSPECTOR_CERTIFICATION_BY_ID: "api/permits/{0}/inspectors/{1}/certifications/{2}",
		INSPECTOR_DOCUMENTS_BY_SUBJECT_ID: "api/permit-inspectors/subjects/{0}/documents",
		INSPECTOR_DOCUMENTS_BY_INSPECTOR_ID: "api/permits/{0}/inspectors/{1}/documents",
		DELETE_DOCUMENT: "api/permits/{0}/inspectors/{1}/documents/{2}"
	};

	var subscriptions = [];
	var editableParams = ["numberInList", "isIncluded", "isChairman", "speciality", "remarks", 
		"birthDate", "country", "region", "city", "address", "firstName", "surname", "familyName", "educationLevel"];

	this.searchText = ko.observable("").extend({
		identityNumber: true
	});
	this.inspector = new demax.inspections.model.permits.inspectors.Inspector();
	this.initialInspector = new demax.inspections.model.permits.inspectors.Inspector();
	this.permitId = ko.observable();
	this.inspectorId = null;
	this.permitNumber = ko.observable();
	this.permitStatus = ko.observable();

	this.countries = ko.observableArray();
	this.regions = ko.observableArray();
	this.cities = ko.observableArray();
	this.educationLevels = ko.observableArray();
	this.inspectorCityNameInput = ko.observable();
	this.inspectorDocuments = ko.observableArray();
	this.inspectorStamps = ko.observableArray();
	this.inspectorCards = ko.observableArray();
	this.inspectorCertifications = ko.observableArray();

	this.inspectorSpecialities = ko.observableArray();

	// Inspector flags
	this.isNew = ko.observable(false);
	this.isEditing = ko.observable(false);
	this.isInspectorFound = ko.observable(false);
	this.canEgnBeEdited = ko.observable(true);
	this.shouldDisableIsChairman = ko.observable(false);
	this.selectedCountry = ko.observable();
	this.selectedRegion = ko.observable();
	this.selectedEducationLevel = ko.observable();

	this.documentsPage = ko.observable(1);
	this.documentsCount = ko.observable();
	this.certificatesCount = ko.observable();
	this.certificatesPage = ko.observable(1);
	this.documentsPagination = new Pagination({
		page: self.documentsPage(),
		pageSize: PAGE_SIZE
	});
	this.certificatesPagination = new Pagination({
		page: self.certificatesPage(),
		pageSize: PAGE_SIZE
	});

	this.user = demax.inspections.authenticatedUser();

	// Permit flags
	this.isPermitDraft = ko.observable(false);
	this.isPermitCreated = ko.observable(false);
	this.isPermitValid = ko.observable(false);

	// Change detection
	this.ChangeCodes = demax.inspections.nomenclature.permits.ChangeCodes;
	this.inspectorChanges = ko.observable();

	// Update certifications holders
	self.newCertifications = ko.observableArray();
	self.isUpdateCertificationsPopupVisible = ko.observable(false);


	self.blockSingleAjaxAutoCompleteOptionsVisibilityUpdate = ko.observable(false);

	this.isLoading = restClient.isLoading;

	this.init = function (params) {
		loadInspectorSpecialities();
		self.permitId(params.id);
		self.inspectorId = params.inspectorId;

		subscriptions.push(self.selectedRegion.subscribe(function () {
			if (self.selectedRegion()) {
				var result;
				self.regions().forEach(function (region) {
					if (region.code === self.selectedRegion()) {
						result = region;
					}
				});
				self.inspector.region(result);
				loadCities();
			} else {
				self.inspector.region(undefined);
			}
		}));

		subscriptions.push(self.selectedEducationLevel.subscribe(function () {
			if (self.selectedEducationLevel()) {
				var result;
				self.educationLevels().forEach(function(educationLevel) {
					if (educationLevel.code === self.selectedEducationLevel()) {
						result = educationLevel;
					}
				});
				self.inspector.educationLevel(result);
			} else {
				self.inspector.educationLevel(undefined);
			}
		}));

		subscriptions.push(self.selectedCountry.subscribe(function () {
			if (self.inspector.country() && self.selectedCountry()) {
				var result;
				self.countries().forEach(function(country) {
					if (country.code === self.selectedCountry()) {
						result = country;
					}
				});
				self.inspector.country(result);
			} else {
				self.inspector.country(undefined);
			}
		}));

		restClient.getResource(pastel.util.StringHelper.format(URL.GET_PERMIT_DETAILS, self.permitId()))
			.done(function (result) {
				self.permitNumber(result.permitNumber ? result.permitNumber : " - ");
				self.permitStatus(result.statusCode ? PermitStatus.getByCode(result.statusCode) : PermitStatus.getNullStatus());

				self.isPermitValid(
					self.permitStatus().code === PermitStatus.VALID.code
					|| self.permitStatus().code === PermitStatus.REVOKING_IN_PROCESS.code
				);

				self.isPermitCreated(self.permitStatus().code === PermitStatus.CREATED.code);

				self.isPermitDraft(self.permitStatus().code === PermitStatus.DRAFT.code);


			}).handleErrors({
				NoSuchEntityException: function () {
					demax.inspections.popupManager.error("Не е намерено Разрешение с ID " + self.permitId())
						.done(function () {
							demax.inspections.router.setHash("permits");
						});
				}
			});
		subscriptions.push(self.inspector.speciality.subscribe(function (newVal) {
			if (newVal && newVal.indexOf("Д") > -1) {
				self.inspector.isChairman(false);
				self.shouldDisableIsChairman(true);
			} else {
				self.shouldDisableIsChairman(false);
			}
		}));
		if (self.inspectorId) {
			self.isNew(false);
			restClient.getResource(pastel.util.StringHelper.format(URL.GET_INSPECTOR, self.permitId(), self.inspectorId))
				.done(function (result) {
					self.inspector.setUpInspector(result);
					self.initialInspector.setUpInspector(result);
					var stamps = result.stamps.map(function (e) {
						return new demax.inspections.model.permits.inspectors.InspectorStampDto(e);
					});
					self.inspectorStamps(stamps);
					self.inspectorCards(result.cards);
					self.inspectorChanges(result.inspectorChanges);
					getInspectorDocumentsPage(1).done(function (result) {
						self.documentsCount(result.totalCount);
						subscriptions.push(self.documentsPagination.queryParamsObject.subscribe(function (params) {
							self.documentsPage(params.page);
							getInspectorDocumentsPage(params.page);
						}));
					});
					getInspectorCertificationsPage(1, PAGE_SIZE).done(function (result) {
						self.certificatesCount(result.totalCount);
						subscriptions.push(self.certificatesPagination.queryParamsObject.subscribe(function (params) {
							self.certificatesPage(params.page);
							getInspectorCertificationsPage(params.page, PAGE_SIZE);
						}));
					});
				}).handleErrors({
					NoSuchEntityException: function () {
						demax.inspections.popupManager.error("Не е намерен специалист към дадено Разрешение.")
							.done(function () {
								demax.inspections.router.setHash("permits");
							});
					}
				});
		} else {
			self.isNew(true);
			self.inspector.isIncluded(true);
			self.initialInspector.isIncluded(true);
			self.isEditing(true);
			loadCountries();
			loadRegions();
			loadEducationLevels();
		}

	};

	this.searchForSubject = function () {
		var searchValidationError = ko.validation.group([self.searchText]);
		if (ko.unwrap(searchValidationError()).length > 0) {
			searchValidationError.showAllMessages();
			return;
		}
		if (self.inspector.identityNumber() && self.searchText() !== self.inspector.identityNumber()) {
			self.resetInspector();
			self.inspectorCertifications.removeAll();
			self.selectedEducationLevel(undefined);
			self.selectedRegion(undefined);
			self.inspectorCityNameInput(undefined);
		}

		restClient.getResource(URL.SEARCH_EGN, { identityNumber: self.searchText() })
			.done(function (result) {
				self.inspector.identityNumber(result.identityNumber);
				self.inspector.firstName(result.firstName);
				self.inspector.surname(result.surname);
				self.inspector.familyName(result.familyName);
				self.inspector.subjectId(result.id);
				self.inspector.categories(result.categories);
				self.inspector.subjectVersionId(result.subjectVersionId);
				self.inspector.educationLevel(result.educationLevel);
				if (result.educationLevel) {
					self.selectedEducationLevel(result.educationLevel.code);
				}
				self.inspector.country(result.country);
				if (result.country) {
					self.selectedCountry(result.country.code);
				}
				self.inspector.region(result.region);
				if (result.region) {
					self.selectedRegion(result.region.code);
				} 
				if (result.birthDate) {
					self.inspector.birthDate(moment.fromJacksonDateTimeArray(result.birthDate));
				} else {
					if (demax.inspections.utils.ValidatorUtil.validateEgn(self.inspector.identityNumber()) && self.inspector.country().code === "BGR") {
						self.inspector.birthDate(extractBirthdayFromEgn(result.identityNumber));
					}
				}
				
				self.inspector.city(result.city);
				if (result.city) {
					self.inspectorCityNameInput(result.city.name);
				}
				self.inspector.address(result.address);
				subscriptions.push(self.certificatesPagination.queryParamsObject.subscribe(function (params) {
					self.certificatesPage(params.page);
					getInspectorCertificationsPageForSubject(params.page, PAGE_SIZE);
				}));

				getInspectorDocumentsPage(1).done(function (result) {
					self.documentsCount(result.totalCount);
					subscriptions.push(self.documentsPagination.queryParamsObject.subscribe(function (params) {
						self.documentsPage(params.page);
						getInspectorDocumentsPage(params.page);
					}));
				});

			}).handleErrors({
				ConstraintViolationException: function () {
					demax.inspections.popupManager.error("Въведеното ЕГН не е валидно");
				},
				NoSuchEntityException: function () {
					demax.inspections.popupManager.error("Не е намерено лице с посоченото ЕГН.");
				}
			});
		self.isInspectorFound(true);
		self.toggleCanEgnBeEdited();
	};

	this.cancel = function () {
		var url = "permits/details/" + self.permitId();
		if (inspectorHasChanges()) {
			demax.inspections.popupManager.confirm({
				cssClass: "popInfo",
				message: "Сигурни ли сте, че искате да отхвърлите промените си?",
				okButtonCss: "btn-primary"
			}).done(function () {
				demax.inspections.router.setHash(url);
			});
		} else {
			demax.inspections.router.setHash(url);
		}
	};

	this.saveOrUpdate = function () {
		if (self.isNew() && self.canEgnBeEdited()) {
			return;
		}

		if (self.inspectorId) {
			if (!inspectorHasChanges()) {
				self.isEditing(false);
				return;
			}

			var validationErrors = ko.validation.group([self.inspector.numberInList, self.inspector.isIncluded,
				self.inspector.isChairman, self.inspector.speciality, self.inspector.remarks,
				self.inspector.firstName, self.inspector.surname, self.inspector.familyName, self.inspector.birthDate,
				self.inspector.country, self.inspector.city, self.inspector.region, self.inspector.address, self.inspector.educationLevel]);
			if (ko.unwrap(validationErrors()).length > 0) {
				validationErrors.showAllMessages();
				return;
			}

			if (self.inspector.numberInList() !== self.initialInspector.numberInList() && self.inspectorStamps().length > 0) {
				demax.inspections.popupManager.confirm({
					cssClass: "popInfo",
					message: "Сигурни ли сте, че искате да смените номер в списък? Това автоматично ще направи старите ви печати, ползващи този номер, невалидни при одобрение от ИААА.",
					okButtonCss: "btn-primary"
				}).done(startUpdate);
			} else {
				startUpdate();
			}

		} else {
			validationErrors = ko.validation.group([self.inspector.subjectId, self.inspector.numberInList, self.inspector.isIncluded,
				self.inspector.isChairman, self.inspector.speciality, self.inspector.remarks, self.inspector.birthDate,
				self.inspector.country, self.inspector.city, self.inspector.region, self.inspector.address, self.inspector.educationLevel]);
			if (ko.unwrap(validationErrors()).length > 0) {
				validationErrors.showAllMessages();
				return;
			}

			if (self.inspectorCertifications().length < 1) {
				demax.inspections.popupManager.error("За да създадете Инспектор е нужно поне едно удостоверение!");
				return;
			}

			// Push ids
			self.inspectorCertifications().forEach(function (item) {
				self.inspector.certificationIds.push(item.id);
			});

			restClient.postResource(pastel.util.StringHelper.format(URL.CREATE_INSPECTOR, self.permitId()), self.inspector.toRequestBody())
				.done(function (createdId) {
					demax.inspections.router.setHash("permits/details/" + self.permitId() + "/inspectors/" + createdId);
				}).handleErrors({
					PermitInspectorAlreadyAddedToPermitException: function () {
						demax.inspections.popupManager.error(
							"Лицето с ЕГН " + self.searchText() + " вече е в списъка със специалисти към това Разрешение.");
					},
					DeprivedOfRightsException: function () {
						demax.inspections.popupManager.error(
							"Лицето с ЕГН " + self.searchText() + " има отнети права и не може да бъде добавено към Разрешение.");
					},
					PermitInspectorIsInAnotherCompanyException: function (message, object) {
						demax.inspections.popupManager.customError({
							message: "Лицето с ЕГН " + self.searchText() + " е добавено в друга фирма.",
							permits: object.permits
						});
					},
					PermitInspectorAlreadyHasDraftSnapshotException: function () {
						demax.inspections.popupManager.error(
							"Лицето с ЕГН " + self.searchText() + " се редактира в друго Разрешение и не може да бъде добавено към това Разрешение.");
					},
					DateFromIdentityNumberDoesNotMatchBirthDateException: function () {
						demax.inspections.popupManager.error(
							"Датата на раждане от ЕГН не съвпада с въведената дата на раждане.");
					},
					PermitInspectorShouldBeAdultException: function () {
						demax.inspections.popupManager.error(
							"Лицето трябва да бъде с навършени 18 години. Въведете дата на раждане преди "
							+ moment().subtract(18, "years").format("DD.MM.YYYY") + ".");
					},
					NameShouldBeCapitalLetterCyrillicWithOptionalSpacesHyphensApostrophesException: function() {
						demax.inspections.popupManager.error(
							"Името на лицето трябва да бъде съставено от главни букви от кирилицата и празно място, тире и апостроф при двойните имена."
						);
					},
					PermitInspectorCreateParamsIdentityNumberDoesNotMatchSubjectIdentityNumberException: function() {
						demax.inspections.popupManager.error(
							"Лицето, което опитвате да създадете има различно ЕГН."
						);
					}
				});
		}
	};

	this.goToAddCard = function () {
		var alreadyHasActiveCard = false;
		self.inspectorCards().forEach(function (card) {
			if (card.isActive) {
				alreadyHasActiveCard = true;
				return;
			}
		});
		if (!self.inspector.isChairman()) {
			demax.inspections.popupManager.info("Не може да добавите карта за достъп. Специалистът трябва да бъде председател!");
		} else if (self.inspector.isDeprivedOfRights()) {
			demax.inspections.popupManager.info("Този специалист е с Отнети права!");
		} else if (self.inspector.excludedOn()) {
			demax.inspections.popupManager.info("Не може да добавите карта към специалист. Този специалист е със статус Изключен!");
		} else if (alreadyHasActiveCard) {
			demax.inspections.popupManager.info("Този специалист вече има една активна карта!");
		} else {
			var url = pastel.util.StringHelper.format(
				"permits/details/{0}/inspectors/{1}/subjects/{2}/cards/new",
				self.permitId(), self.inspectorId, self.inspector.subjectId()
			);
			demax.inspections.router.setHash(url);
		}
	};

	this.goToPreviewCard = function (card) {
		var url = pastel.util.StringHelper.format(
			"permits/details/{0}/inspectors/{1}/subjects/{2}/cards/{3}",
			self.permitId(), self.inspectorId, self.inspector.subjectId(), card.id
		);
		demax.inspections.router.setHash(url);
	};

	this.goToAddStamp = function () {
		if (self.inspector.isDeprivedOfRights()) {
			demax.inspections.popupManager.info("Този специалист е с Отнети права!");
		} else if (self.inspector.excludedOn()) {
			demax.inspections.popupManager.info("Не може да добавите печат към специалист. Този специалист е със статус Изключен!");
		} else {
			demax.inspections.router.setHash("permits/details/" + self.permitId() + "/inspectors/" + self.inspectorId + "/stamps/new");
		}
	};

	this.goToPreviewStamp = function (stamp) {
		demax.inspections.router.setHash("permits/details/" + self.permitId() + "/inspectors/" + self.inspectorId + "/stamps/" + stamp.id);
	};

	this.goToAddDocument = function () {
		demax.inspections.router.setHash("permits/details/" + self.permitId() + "/inspectors/" + self.inspectorId + "/documents/new", { subjectId: self.inspector.subjectId() });
	};

	this.goToPreviewDocument = function (document) {
		demax.inspections.router.setHash("permits/details/" + self.permitId() + "/inspectors/" + self.inspectorId + "/documents/" + document.id);
	};

	this.toggleEditing = function () {
		if (self.isEditing() && inspectorHasChanges()) {
			demax.inspections.popupManager.confirm({
				cssClass: "popInfo",
				message: "Сигурни ли сте, че искате да отхвърлите промените си?",
				okButtonCss: "btn-primary"
			}).done(function () {
				rollBackChanges();
				self.isEditing(false);
			});
		} else if (self.isEditing() && !inspectorHasChanges()) {
			self.isEditing(false);
		} else {
			self.isEditing(true);
			if (self.regions().length === 0 && self.countries().length === 0) {
				loadCountries();
				loadRegions().done(loadCities);
			}
			if (self.inspector.city()) {
				self.inspectorCityNameInput(self.inspector.city().name);
			}
			if (self.educationLevels().length === 0) {
				loadEducationLevels();
			}
			if (!self.inspector.birthDate() && self.inspector.identityNumber()) {
				self.inspector.birthDate(extractBirthdayFromEgn(self.inspector.identityNumber()));
			}
		}
	};

	this.inspectorInfoHasChanges = function (element) {
		return self.inspectorChanges() && self.inspectorChanges().infoChanges[element.code] != null;
	};

	this.inspectorCertificationHasChanges = function (element) {
		return self.inspectorChanges() && self.inspectorChanges().certificationChanges[element.code] != null;
	};
	
	this.getInspectorCertificationChanges = function (element) {
		return self.inspectorChanges().certificationChanges[element.code];
	};

	this.documentHasChanges = function (id) {
		return self.inspectorChanges() && self.inspectorChanges().documentChanges[id] != null;
	};

	this.shouldShowCardAddButton = ko.pureComputed(function () {
		return self.user.userIsCallCenter() && self.isPermitValid();
	});

	this.shouldShowStampAddButton = ko.pureComputed(function () {
		return self.user.userIsIaaa() && self.isPermitValid();
	});

	// Update certifications functionality
	this.canRemoveCertification = function (cert) {
		return cert.canEdit && (this.isPermitCreated() || this.isPermitDraft());
	};

	this.removeCertification = function (cert) {
		if (self.isNew()) {
			self.inspectorCertifications.remove(function (x) {
				return x.id === cert.id;
			});
		} else if (cert.canEdit) {
			demax.inspections.popupManager.confirm({
				cssClass: "popInfo",
				message: "Сигурни ли сте, че искате да изтриете Удостоверение?",
				okButtonCss: "btn-primary"
			}).done(function () {
				restClient.deleteResource(pastel.util.StringHelper
					.format(URL.INSPECTOR_CERTIFICATION_BY_ID, self.permitId(), self.inspectorId, cert.id))
					.done(function (id) {
						if (id != self.inspectorId) {
							var url2 = "permits/details/" + self.permitId() + "/inspectors/" + id;
							demax.inspections.router.setHash(url2);
						} else {
							getInspectorCertificationsPage(1, PAGE_SIZE);
						}
					});
			});
		}
	};

	this.deleteDocument = function(document) {
		demax.inspections.popupManager.confirm({
			cssClass: "popInfo",
			message: "Сигурни ли сте, че искате да изтриете документа?",
			okButtonCss: "btn-primary"
		}).done(function () {
			restClient.deleteResource(pastel.util.StringHelper.format(URL.DELETE_DOCUMENT, self.permitId(), self.inspectorId, document.id))
				.done(function () {
					getInspectorDocumentsPage(1).done(function (result) {
						self.documentsCount(result.totalCount);
						subscriptions.push(self.documentsPagination.queryParamsObject.subscribe(function (params) {
							self.documentsPage(params.page);
							getInspectorDocumentsPage(params.page);
						}));
					});
				});
		});
	};

	this.shouldShowUpdateCertificationsButton = ko.pureComputed(function () {
		return self.inspector.subjectId() && (self.isPermitDraft() || self.isPermitCreated());
	});

	this.showUpdateCertificationsPopup = function () {
		restClient.getResource(pastel.util.StringHelper
			.format(URL.INSPECTOR_CERTIFICATIONS_BY_SUBJECT_ID, self.inspector.subjectId()))
			.done(function (result) {
				self.newCertifications(
					result.map(function (cert) {
						return new demax.inspections.model.permits.inspectors.InspectorCertification(cert);
					}).filter(function (cert) {
						return !certificationIsContained(cert);
					})
				);
				self.isUpdateCertificationsPopupVisible(true);
			});
	};

	function certificationIsContained(cert) {
		var isContained = false;
		self.inspectorCertifications().forEach(function (item) {
			if (item.id === cert.id) {
				isContained = true;
			}
		});
		return isContained;
	}

	this.hideUpdateCertificationsPopup = function () {
		self.newCertifications([]);
		this.isUpdateCertificationsPopupVisible(false);
	};

	this.addNewCertificationsToInspector = function () {
		if (self.inspectorId) {
			var url = pastel.util.StringHelper.format(URL.INSPECTOR_CERTIFICATION_BY_INSPECTOR_ID, self.permitId(), self.inspectorId);
			restClient.postResource(url, JSON.stringify(getSelectedCertificationsIds()))
				.done(function (id) {

					if (id != self.inspectorId) {
						var url2 = "permits/details/" + self.permitId() + "/inspectors/" + id;
						demax.inspections.router.setHash(url2);
					} else {
						getInspectorCertificationsPage(1, PAGE_SIZE).done(function () {
							self.hideUpdateCertificationsPopup();
						});
					}

				});
		} else {
			self.newCertifications().forEach(function (item) {
				if (item.isChecked()) {
					item.canEdit = true;
					self.inspectorCertifications.push(item);
				}
			});
			self.hideUpdateCertificationsPopup();
		}
	};

	function getSelectedCertificationsIds() {
		var ids = [];
		self.newCertifications().forEach(function (item) {
			if (item.isChecked()) {
				ids.push(item.id);
			}
		});
		return ids;
	}

	// Update certifications functionality END

	this.dispose = function () {
		restClient.cancelAll();
		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});
	};

	function startUpdate() {
		
		restClient.putResource(pastel.util.StringHelper.format(URL.UPDATE_INSPECTOR, self.permitId(), self.inspectorId), self.inspector.toRequestBodyForUpdate())
			.done(function (id) {
				if (id != self.inspectorId) {
					var url2 = "permits/details/" + self.permitId() + "/inspectors/" + id;
					demax.inspections.router.setHash(url2);
				} else {
					applyChanges();
					self.isEditing(false);
				}
			})
			.handleErrors({
				PermitInspectorOrderNumberChangeException: function () {
					demax.inspections.popupManager.error("Не можете да променяте номер в списък на специалист, който има валиден печат.");
				},
				DateFromIdentityNumberDoesNotMatchBirthDateException: function () {
					demax.inspections.popupManager.error(
						"Датата на раждане от ЕГН не съвпада с въведената дата на раждане.");
				},
				PermitInspectorShouldBeAdultException: function () {
					demax.inspections.popupManager.error(
						"Лицето трябва да бъде с навършени 18 години. Въведете дата на раждане преди "
						+ moment().subtract(18, "years").format("DD.MM.YYYY") + ".");
				}
			});
	}

	function inspectorHasChanges() {
		var hasSearchText = self.isNew() && self.searchText() && self.searchText().trim();

		return hasSearchText || KnockoutPropertyUtil.hasChanges(self.inspector, self.initialInspector, editableParams);
	}

	function rollBackChanges() {
		KnockoutPropertyUtil.copyProperties(self.initialInspector, self.inspector, editableParams);
	}

	function applyChanges() {
		KnockoutPropertyUtil.copyProperties(self.inspector, self.initialInspector, editableParams);
	}

	function loadInspectorSpecialities() {
		restClient.getResource(URL.INSPECTOR_SPECIALITIES).done(function (result) {
			self.inspectorSpecialities(result);
		});
	}

	function getInspectorDocumentsPage(page) {
		var url = "";
		if (self.inspectorId) {
			url = pastel.util.StringHelper.format(URL.INSPECTOR_DOCUMENTS_BY_INSPECTOR_ID, self.inspectorId, self.permitId());
		} else {
			url = pastel.util.StringHelper.format(URL.INSPECTOR_DOCUMENTS_BY_SUBJECT_ID, self.inspector.subjectId());
		}
		return restClient.getResource(url, { page: page })
			.done(function (result) {
				self.inspectorDocuments(result.items.map(function (doc) {
					return new demax.inspections.model.permits.inspectors.InspectorDocument(doc);
				}));
			});
	}

	function getInspectorCertificationsPageForSubject(page, pageSize) {
		return restClient.getResource(pastel.util.StringHelper
			.format(URL.INSPECTOR_CERTIFICATIONS_BY_SUBJECT_ID_PAGED, self.inspector.subjectId()), { page: page, pageSize: pageSize })
			.done(function (result) {
				self.inspectorCertifications(result.items.map(function (cert) {
					return new demax.inspections.model.permits.inspectors.InspectorCertification(cert);
				}));
			});
	}

	function getInspectorCertificationsPage(page, pageSize) {
		return restClient.getResource(pastel.util.StringHelper
			.format(URL.INSPECTOR_CERTIFICATION_BY_INSPECTOR_ID, self.permitId(), self.inspectorId), { page: page, pageSize: pageSize })
			.done(function (result) {
				self.inspectorCertifications(result.items.map(function (cert) {
					return new demax.inspections.model.permits.inspectors.InspectorCertification(cert);
				}));
			});
	}

	this.getFilteredCities = function (filterValue) {
		var deffered = $.Deferred();

		if (self.inspector.city() && filterValue === self.inspector.city().name) {
			deffered.reject();
		} else {
			var filteredCities = [];
			filterValue = filterValue.toLowerCase();
			if (self.cities().length > 0) {
				self.cities().forEach(function (city) {
					if (city.name.toLowerCase().indexOf(filterValue) > -1) {
						filteredCities.push(city);
					}
				});
			}
		}

		deffered.resolve(filteredCities);
		return deffered.promise();
	};
	
	function loadCountries() {
		nomenclatureService.getCountries().done(function (countries) {
			self.countries(countries);
			if (self.inspector.country()) {
				self.selectedCountry(self.inspector.country().code);
			} else {
				var result;
				self.countries().forEach(function (country) {
					if (country.code.indexOf("BGR") > -1) {
						result = country;
					}
				});
				self.selectedCountry(result.code);
			}
		});
	}

	function loadRegions() {
		return nomenclatureService.getRegions().done(function (regions) {
			self.regions(regions);
			if (self.inspector.region()) {
				self.selectedRegion(self.inspector.region().code);
			}
		});
	}

	function loadCities() {
		nomenclatureService.getCitiesByRegion(self.selectedRegion()).done(function (cities) {
			self.blockSingleAjaxAutoCompleteOptionsVisibilityUpdate(true);
			self.cities(cities);
			if (self.inspector.city()) {
				var result = self.cities().find(function(city) {
					return city.code === self.inspector.city().code;
				});
				if (result) {
					self.inspectorCityNameInput(result.name);
				} else {
					self.inspectorCityNameInput("");
					self.inspector.city = ko.observable();
				}
			}
		});
	}

	function loadEducationLevels() {
		return nomenclatureService.getEducationLevels().done(function (educationLevels) {
			self.educationLevels(educationLevels);
			if (self.inspector.educationLevel()) {
				self.selectedEducationLevel(self.inspector.educationLevel().code);
			}
		});
	}

	function extractBirthdayFromEgn(egn) {
		var dateFromEgn = demax.inspections.utils.GeneralUtil.convertIdentityNumberToDate(egn);
		var dateFromEgnString = moment(dateFromEgn, "YYYY-MM-DD");
		return dateFromEgnString;
	}

	this.onSelectedCity = function (selectedCity) {
		self.inspector.city(selectedCity);
		self.inspectorCityNameInput(selectedCity.name);
	};
	
	this.toggleCanEgnBeEdited = function () {
		self.canEgnBeEdited(!self.canEgnBeEdited());
	};

	this.resetInspector = function() {
		self.inspector.subjectId(undefined);
		self.inspector.firstName(undefined);
		self.inspector.surname(undefined);
		self.inspector.familyName(undefined);
		self.inspector.subjectVersionId(undefined);
		self.inspector.educationLevel(undefined);
		self.inspector.identityNumber(undefined);
		self.inspector.address(undefined);
		self.inspector.country(undefined);
		self.inspector.region(undefined);
		self.inspector.city(undefined);
		self.inspector.birthDate(undefined);
		self.inspector.numberInList(undefined);
		self.inspector.isChairman(undefined);
		self.inspector.speciality(undefined);
		self.inspector.remarks(undefined);
		self.inspector.includedOn(undefined);
		self.inspector.excludedOn(undefined);
		self.inspector.lastModifiedOn(undefined);
	
		self.inspector.includedOnFormatted(undefined);
		self.inspector.excludedOnFormatted(undefined);
		self.inspector.lastModifiedOnFormatted(undefined);
	
		self.inspector.isDeprivedOfRights(undefined);
		self.inspector.deprivedOn(undefined);
		self.inspector.depriveReason(undefined);
	
		self.inspector.deprivedOnFormatted(undefined);
		self.inspector.chairmanDesignationDateFormated(undefined);
		self.inspector.categories(undefined);
		self.inspector.inspectionTypes(undefined);
	
		self.inspector.certificationIds = [];
	};
};