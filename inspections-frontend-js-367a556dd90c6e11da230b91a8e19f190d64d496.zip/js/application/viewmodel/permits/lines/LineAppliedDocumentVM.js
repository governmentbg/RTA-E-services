namespace("demax.inspections.viewmodel.permits.lines");

demax.inspections.viewmodel.permits.lines.LineAppliedDocumentVM = function () {
	var self = this;
	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;

	var AppliedDocument = demax.inspections.model.permits.documents.AppliedDocument;
	var KnockoutPropertyUtil = demax.inspections.utils.KnockoutPropertyUtil;
	var Role = demax.inspections.nomenclature.Role;
	var PermitStatus = demax.inspections.nomenclature.permits.PermitStatus;

	var popupManager = demax.inspections.popupManager;

	var URL = {
		BASE_URL: "api/permits/{permitId}/lines/{lineId}/documents",
		GET_DOC_TYPES: "api/nomenclatures/permit-document-types/lines",
		GET_PERMIT_STATUS_NUM: "api/permits/{permitId}/status-number",
		GET_PERMIT_LINE_DOCUMENT: "api/permits/{permitId}/lines/{lineId}/documents/{documentId}",
		GET_PDF_BY_ID: "api/permits/{permitId}/lines/{lineId}/documents/{documentId}/pdf",
		EDIT_NEW_DOCUMENT: "api/permits/{permitId}/lines/{lineId}/documents/{documentId}/new",
		EDIT_APPROVED_DOCUMENT: "api/permits/{permitId}/lines/{lineId}/documents/{documentId}/approved"
	};

	var permitId;
	var lineId;
	var documentId;

	var user = demax.inspections.authenticatedUser();
	var editableFields = ["docNumber", "issuer", "issuedOn", "validFrom", "validTo", "remarks", "docType", "brand", "model", "deviceType", "serialNumber"];

	this.DocumentTypeCodes = demax.inspections.nomenclature.permits.DocumentTypeCodes;
	this.documentTypes = ko.observableArray([]);

	var PermitDocumentStatuses = demax.inspections.nomenclature.permits.PermitDocumentStatus;
	this.statusOptions = ko.observableArray(PermitDocumentStatuses.REAL_STATUSES);

	this.document = ko.observable();
	this.documentCopy = ko.observable();
	this.permitNumber = ko.observable();
	this.filesArray = ko.observableArray();

	this.isEditing = ko.observable(false);
	this.isAddingNew = ko.observable(false);
	this.isPreview = ko.observable(false);

	this.isRdaaAndCanEdit = ko.observable(false);

	this.file = ko.observable().extend({
		required: {
			onlyIf: function () {
				return self.document() && !self.document().hasDocument();
			},
			message: "Моля, качете сканирано копие на документа"
		}
	});

	this.hasValidToDate = ko.pureComputed(function () {
		if (self.document() && self.document().docType()) {
			if (!self.document().docType().hasValidToDate) {
				return true;
			} else {
				return false;
			}
		} else {
			return true;
		}
	});

	this.hasValidFromDate = ko.pureComputed(function () {
		if (self.document() && self.document().docType()) {
			if (!self.document().docType().hasValidFromDate) {
				return true;
			} else {
				return false;
			}
		} else {
			return true;
		}
	});

	this.hasIssueDate = ko.pureComputed(function () {
		if (self.document() && self.document().docType()) {
			if (!self.document().docType().hasIssueDate) {
				return true;
			} else {
				return false;
			}
		} else {
			return true;
		}
	});

	this.hasBrandModel = ko.pureComputed(function () {
		if (self.document()) {
			return self.document().shouldShowBrandAndModel();
		} else {
			return false;
		}
	});

	this.hasValidFromChanged = ko.computed(function () {
		if (self.document() && (self.document().validFrom())) {
			self.document().updateValidityByValidFrom();
		} 
	});

	this.hasIssuedOnChanged = ko.computed(function () {
		if (self.document() && (self.document().issuedOn())) {
			self.document().updateValidityByIssuedOn();
		} 
	});

	this.isLoading = ko.pureComputed(function () {
		return restClient.isLoading() || blobClient.isLoading();
	});

	var errorHandlers = {
		NoSuchEntityException: function (message) {
			if (message.indexOf("PermitVersion") > -1) {
				popupManager.error("Разрешението не е намерено");
			} else if (message.indexOf("AppliedDocumentType") > -1) {
				popupManager.error("Видът на документа не е намерен");
			}
		},
		PermitLineNotFoundException: function () {
			demax.inspections.popupManager.error("Не е намерена линия към това разрешение");
		},
		PermitLineDocumentNotFoundException: function () {
			demax.inspections.popupManager.error("Не е намерен документ към тази линия");
		},
		InvalidPermitStatusException: function () {
			demax.inspections.popupManager.error("Разрешението няма необходимия статус (чернова или създаден)");
		}
	};

	this.init = function (params) {
		setUrls(params.id, params.lineId, params.documentId);

		permitId = params.id;
		lineId = params.lineId;
		documentId = params.documentId;

		restClient.getResource(URL.GET_PERMIT_STATUS_NUM)
			.done(function (result) {
				self.permitNumber(result.number ? result.number : " - ");
				self.isRdaaAndCanEdit(user.roles.indexOf(Role.TECHINSP_INSP_RDAA) > -1
					&& (result.status === PermitStatus.CREATED.code || result.status === PermitStatus.DRAFT.code));
			}).handleErrors({
				NoSuchEntityException: function () {
					demax.inspections.popupManager.error("Разрешението не е намерено")
						.done(function () {
							demax.inspections.router.setHash("permits");
						});
				}
			});

		restClient.getResource(URL.GET_DOC_TYPES)
			.done(function (docTypes) {
				self.documentTypes(ko.utils.arrayMap(docTypes, function (docType) {
					return new demax.inspections.model.permits.documents.DocumentType(docType);
				}));

				if (documentId) {
					restClient.getResource(URL.GET_PERMIT_LINE_DOCUMENT)
						.done(function (docDto) {
							self.document(new AppliedDocument(docDto, self.documentTypes()));
							self.documentCopy(new AppliedDocument(docDto, self.documentTypes()));
						}).handleErrors(errorHandlers);
					self.isPreview(true);
				} else {
					setupAddView();
				}

			});
	};

	this.fileSelect = function (_element, event) {
		var file = event.target.files[0];
		self.filesArray.removeAll();
		self.filesArray.push(file);

		if (!file.type.match("(pdf|jpg|jpeg|png)")) {
			demax.inspections.popupManager.error("Моля прикачете PDF, JPG или PNG файл!");
			clearFile();
			return;
		}
		if (file.size > 5242880) {
			demax.inspections.popupManager.error("Моля прикачете файл с размер по-малък от 5MB!");
			clearFile();
			return;
		}
		var reader = new FileReader();
		reader.onload = (function () {
			return function (e) {
				var base64 = e.target.result;
				self.file(base64.substring(base64.indexOf(",") + 1));
			};
		})(file);
		reader.readAsDataURL(file);
	};

	this.downloadPdf = function () {
		blobClient.downloadBlob(URL.GET_PDF_BY_ID, "ДОКУМЕНТ-НОМЕР-" + self.document().docNumber()).handleErrors({
			FileNotFoundExpcetion: function () {
				demax.inspections.popupManager.warn("Няма качено сканирано копие на документ!");
			}
		});
	};

	this.saveDocument = function () {
		var validationErrors = self.document().isApproved() ?
			ko.validation.group([self.document().status()])
			: ko.validation.group([self.document().docType, self.document().docNumber,
				self.document().issuer, self.document().issuedOn, self.document().validFrom,
				self.document().validTo, self.document().remarks, self.document().brand,
				self.document().model, self.document().deviceType,
				self.document().serialNumber, self.file]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			return;
		}

		if (self.isEditing() && !self.isAddingNew()) {
			var request;
			if (self.document().isApproved()) {
				request = restClient.putResource(URL.EDIT_APPROVED_DOCUMENT, { "statusCode": self.document().status().code });
			} else {
				request = restClient.putResource(URL.EDIT_NEW_DOCUMENT, self.document().toRequestBody(self.file()));
			}

			request.done(function (newLineId) {
				if (newLineId) {
					lineId = newLineId;
				}
				demax.inspections.popupManager.success({ message: "Успешно редактиран документ." })
					.done(goBackToPermitLineDetails);
			});

		} else if (self.isAddingNew()) {
			restClient.postResource(URL.BASE_URL, self.document().toRequestBody(self.file()))
				.done(function (newLineId) {
					lineId = newLineId;
					demax.inspections.popupManager.success({ message: "Успешно добавен нов документ." })
						.done(goBackToPermitLineDetails);
				});
		}
	};

	this.handleCancel = function () {
		var cancelFunction = goBackToPermitLineDetails;

		if (self.isPreview()) {
			cancelFunction = function () {
				rollBackFields();
				self.switchIsEditing();
			};
		}

		if (hasChanges()) {
			demax.inspections.popupManager.confirm({
				message: "Сигурни ли сте, че искате да продължите? Вашите промени ще бъдат изтрити.",
				okButtonText: "Да",
				cancelButtonText: "Не",
				cssClass: "popInfo",
				okButtonCss: "btn-success"
			}).done(cancelFunction);
		} else {
			cancelFunction();
		}
	};

	this.goBack = function () {
		if (hasChanges()) {
			popupManager.confirm({
				message: "Сигурни ли сте, че искате да затворите страницата?",
				okButtonText: "Да",
				cancelButtonText: "Не",
				cssClass: "popInfo",
				okButtonCss: "btn-success"
			}).done(goBackToPermitLineDetails);
		} else {
			goBackToPermitLineDetails();
		}
	};

	this.docPicture = ko.pureComputed(function () {
		var docPicture = [];
		if (self.filesArray().length > 0) {
			$.each(ko.unwrap(self.filesArray), function (i, selectedFile) {
				docPicture.push(new demax.inspections.model.FileAttachment(selectedFile));
			});
			return docPicture;
		}
	});

	this.removeDocPicture = function () {
		clearFile();
	};

	this.switchIsEditing = function () {
		this.isEditing(!this.isEditing());
	};

	function setUrls(permitId, lineId, documentId) {
		Object.keys(URL).forEach(function (key) {
			URL[key] = URL[key].replace("{permitId}", permitId).replace("{lineId}", lineId).replace("{documentId}", documentId);
		});
	}

	function clearFile() {
		self.file(null);
		self.filesArray.removeAll();
	}

	function goBackToPermitLineDetails() {
		demax.inspections.router.setHash("permits/details/" + permitId + "/lines/" + lineId);
	}

	self.getPermitDetailsUrl = function () {
		return "#/permits/details/" + permitId;
	};

	self.getPermitLineDetailsUrl = function () {
		return "#/permits/details/" + permitId + "/lines/" + lineId;
	};

	function rollBackFields() {
		if (self.document().isApproved()) {
			KnockoutPropertyUtil.copyProperties(self.documentCopy(), self.document(), ["statusCode"]);
		} else {
			KnockoutPropertyUtil.copyProperties(self.documentCopy(), self.document(), editableFields);
			self.document().docType(self.documentCopy().docType());
		}
	}

	function hasChanges() {
		if (self.document().isApproved()) {
			return KnockoutPropertyUtil.hasChanges(self.document(), self.documentCopy(), ["statusCode"]);
		} else {
			return KnockoutPropertyUtil.hasChanges(self.document(), self.documentCopy(), editableFields);
		}
	}

	function setupAddView() {
		self.isAddingNew(true);
		self.isEditing(true);
		self.document(new AppliedDocument());
		self.documentCopy(new AppliedDocument());
	}

	this.dispose = function () {
		blobClient.cancelAll();
		restClient.cancelAll();
	};
};