namespace("demax.inspections.viewmodel.permits.lines");

demax.inspections.viewmodel.permits.lines.PermitLineHardwareVM = function () {
	var self = this;
	var restClient = demax.inspections.restClient;

	var URLS = {
		BASE_URL: "api/permits/{0}/lines/{1}/hardware",
		GET_PERMIT_STATUS_NUM: "api/permits/{0}/status-number",
		PERMIT_LINES_REDIRECT: "/permits/details/{0}/lines/{1}",
		DEVICES_BY_SERIAL_NUMBER: "api/hardware-devices/{0}/for-line"
	};

	var subscriptions = [];

	this.isLoading = restClient.isLoading;
	this.hardwareDevices = ko.observableArray();
	this.permitId = ko.observable();
	this.permitLineId = ko.observable();
	this.permitNumber = ko.observable();
	this.barcodeToCheck = ko.observable().extend({ notify: "always" });

	var errorHandlers = {
		NoSuchEntityException: function (message) {
			if (message.indexOf("PermitVersion") > -1) {
				demax.inspections.popupManager("Версията на разрешение " + self.permitId() + " не е намерена")
					.done(function () {
						demax.inspections.router.setHash("permits");
					});
			} else if (message.indexOf("PermitLineVersion") > -1) {
				demax.inspections.popupManager("Версията на линия " + self.permitLineId() + " не е намерена")
					.done(function () {
						demax.inspections.router.setHash("permits");
					});
			} else if (message.indexOf("Store") > -1) {
				demax.inspections.popupManager("Търсеният слад не е намерен");
			}
		},
		PermitLineDoesNotBelongToPermitException: function () {
			demax.inspections.popupManager.error("Линията не принадлежи към разрежилтено с номер " + self.permitNumber());
		},
		HardwareDeviceIsAlreadyAddedToPermitLineException: function () {
			demax.inspections.popupManager.error("Устройството което се опитвате да добавите вече е добавено към линията");
		},
		HardwareDeviceHasWrongStatusException: function () {
			demax.inspections.popupManager.error("Устройството което се оптивате да добавите трябва да е със статус наличен или нов");
		}
	};

	this.init = function (params) {
		self.permitId(params.id);
		self.permitLineId(params.lineId);

		restClient.getResource(pastel.util.StringHelper.format(URLS.GET_PERMIT_STATUS_NUM, params.id))
			.done(function (result) {
				self.permitNumber(result.number);
			}).handleErrors(errorHandlers);

		self.barcodeScannerMannager = new pastel.plus.util.BarcodeScannerManager({
			minBarcodeLength: 5,
			canScanLetters: true,
			nameSpace: "PermitLineHardwareVM",
			scannerInputStorer: self.barcodeToCheck
		});
		self.barcodeScannerMannager.start();

		subscriptions.push(self.barcodeToCheck.subscribe(function (newValue) {
			addScannedBarcode(newValue);
		}));

		self.addHardwareDevice();
	};


	this.loadDevicesBySerialNumber = function (serialNumber, originalHardwareDevice) {
		var deferred = $.Deferred();
		if (!ko.unwrap(originalHardwareDevice.isUpdatable)) {
			deferred.reject();
			return deferred;
		}
		demax.inspections.restClient.getResource(pastel.util.StringHelper.format(URLS.DEVICES_BY_SERIAL_NUMBER, serialNumber))
			.done(function (response) {
				if (response.totalCount == 1) {
					var deviceOption = new demax.inspections.model.equipment.hardware.HardwareDeviceOption(response.items[0]);
					self.hardwareDeviceOptionSelected(deviceOption, originalHardwareDevice);
					deferred.reject();
				} else if (response.totalCount < 1) {
					deferred.resolve([]);
				} else {
					var deviceOptions = ko.utils.arrayMap(response.items, function (deviceDto) {
						return new demax.inspections.model.equipment.hardware.HardwareDeviceOption(deviceDto);
					});
					deferred.resolve(deviceOptions);
				}
			}).fail(function () {
				deferred.reject();
			});
		return deferred;
	};

	this.hardwareDeviceOptionSelected = function (selectedDeviceOption, originalHardwareDevice) {
		if (originalHardwareDevice) {
			var hardwareDevice = null;
			$.each(ko.unwrap(self.hardwareDevices), function (i, device) {
				var deviceId = ko.unwrap(device.id);
				var deviceTypeCode = ko.unwrap(device.type) ? ko.unwrap(device.type).code : null;
				if (deviceId == ko.unwrap(selectedDeviceOption.id)
					&& deviceTypeCode == selectedDeviceOption.type.code) {
					hardwareDevice = device;
					return false;
				}
			});
			if (hardwareDevice) {
				demax.inspections.popupManager.warn("Устройството вече е добавено в списъка!");
			} else {
				originalHardwareDevice.updateFromOption(selectedDeviceOption);
			}
		}
	};

	this.addHardwareDevice = function () {
		var hardwareDevice = new demax.inspections.model.equipment.hardware.HardwareDeviceItem();
		self.hardwareDevices.push(hardwareDevice);
		return hardwareDevice;
	};

	this.removeHardwareDevice = function (hardwareDevice) {
		if (ko.unwrap(self.hardwareDevices).length < 1) {
			return;
		}
		self.hardwareDevices.remove(hardwareDevice);
	};

	this.save = function () {
		if (!checkDevicesListForChanges()) {
			demax.inspections.router.setHash(pastel.util.StringHelper.format(URLS.PERMIT_LINES_REDIRECT, self.permitId(), self.permitLineId()));
			return;
		}
		if (checkForEmptyRows()) {
			return;
		}
		demax.inspections.popupManager.confirm({
			cssClass: "popInfo",
			message: "Сигурни ли сте, че искате да запазите промените?",
			okButtonCss: "btn-primary"
		}).done(function () {
			var requestDto = createRequestDto();
			restClient.putResource(pastel.util.StringHelper.format(URLS.BASE_URL, self.permitId(), self.permitLineId()), JSON.stringify(requestDto))
				.done(function () {
					demax.inspections.popupManager.success({ message: "Успешно променихте устойствата към линията" }).done(function () {
						demax.inspections.router.setHash(pastel.util.StringHelper.format(URLS.PERMIT_LINES_REDIRECT, self.permitId(), self.permitLineId()));
					});
				}).handleErrors(errorHandlers);
		});
	};

	this.cancel = function () {
		if (!checkDevicesListForChanges()) {
			demax.inspections.router.setHash(pastel.util.StringHelper.format(URLS.PERMIT_LINES_REDIRECT, self.permitId(), self.permitLineId()));
			return;
		}
		demax.inspections.popupManager.confirm({
			cssClass: "popInfo",
			message: "Сигурни ли сте, че искате да се върнете назад? Промените ви ще бъдат загубени.",
			okButtonCss: "btn-primary"
		}).done(function () {
			demax.inspections.router.setHash(pastel.util.StringHelper.format(URLS.PERMIT_LINES_REDIRECT, self.permitId(), self.permitLineId()));
		});
	};

	function createRequestDto() {
		var hardwareDevices = [];
		$.each(ko.unwrap(self.hardwareDevices), function (i, hardwareDevice) {
			hardwareDevices.push({
				id: ko.unwrap(hardwareDevice.id),
				typeCode: ko.unwrap(hardwareDevice.type) ? ko.unwrap(hardwareDevice.type).code : null
			});
		});
		return hardwareDevices;
	}

	function checkDevicesListForChanges() {
		if (self.hardwareDevices().length > 0) {
			for (var i = 0; i < self.hardwareDevices().length; i++) {
				if (self.hardwareDevices()[i].id() !== null) {
					return true;
				}
			}
			return false;
		} else {
			return false;
		}
	}

	function checkForEmptyRows() {
		if (self.hardwareDevices().length > 0) {
			for (var i = 0; i < self.hardwareDevices().length; i++) {
				if (self.hardwareDevices()[i].id() == null || self.hardwareDevices()[i].type() == null) {
					demax.inspections.popupManager.error("Моля попълнете или изтрийте празните полета");
					return true;
				}
			}
			return false;
		} else {
			return false;
		}
	}

	function addScannedBarcode(barcode) {
		var hasUpdatableItem = false;
		$.each(self.hardwareDevices(), function (index, value) {
			if (value.isUpdatable() && index === self.hardwareDevices().length - 1) {
				value.serialNumber("");
				value.serialNumber(barcode);
				hasUpdatableItem = true;
				return false;
			}
		});
		if (!hasUpdatableItem) {
			var hardwareDeviceItem = self.addHardwareDevice();
			if (hardwareDeviceItem.hasComponentLoaded()) {
				hardwareDeviceItem.serialNumber(barcode);
			} else {
				subscriptions.push(hardwareDeviceItem.hasComponentLoaded.subscribe(function () {
					hardwareDeviceItem.serialNumber(barcode);
				}));
			}
		}
	}

	this.dispose = function () {
		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});
		self.barcodeScannerMannager.dispose();
	};
};