namespace("demax.inspections.viewmodel.permits.lines");

demax.inspections.viewmodel.permits.lines.PermitLineVM = function () {
	var self = this;
	var restClient = demax.inspections.restClient;
	var nomenclatureService = demax.inspections.nomenclature.NomenclatureService;
	var InspectionTypes = demax.inspections.nomenclature.techinsp.InspectionTypes;
	var popupManager = demax.inspections.popupManager;

	self.warehouses = demax.inspections.nomenclature.Warehouse.ALL;
	self.deviceStatuses = demax.inspections.nomenclature.equipment.hardware.DeviceStatus.EDITABLE_STATUSES_WHEN_IN_AVAILABLE;

	var URL = {
		BASE: "api/permits/{permitId}/lines",
		GET_LINE: "api/permits/{permitId}/lines/{lineId}",
		EDIT_LINE: "api/permits/{permitId}/lines/{lineId}",
		HARDWARE: "api/permits/{permitId}/lines/{lineId}/hardware",
		DOCUMENTS: "api/permits/{permitId}/lines/{lineId}/documents",
		PERMIT_STATUS_NUMBER_URL: "api/permits/{permitId}/status-number",
		GET_PERMIT_DETAILS: "api/permits/{permitId}",
		INSTALL_PROTOCOL: "api/permit-lines/{lineId}/install-protocol",
		RETRIEVE_PROTOCOL: "api/permit-lines/{lineId}/retrieve-protocol"
	};
	var subscriptions = [];

	var errorHandlers = {
		InvalidVehicleCategoryCodesException: function () {
			demax.inspections.popupManager.error("Някои от категориите са невалидни");
		},
		InvalidInspectionTypeCodesException: function () {
			demax.inspections.popupManager.error("Някои от видовете прегледи са невалидни");
		},
		NoVehicleCategorySelectedForInspectionTypeException: function () {
			demax.inspections.popupManager.error("Не са добавени нужните категории за някои от видовете прегледи");
		},
		ValidationException: function() {
			demax.inspections.popupManager.error("Не e добавен " + InspectionTypes.VEHICLE.text);
		}
	};

	this.PAGE_SIZE = 5;
	this.isLoading = restClient.isLoading;
	this.permitNumber = ko.observable();
	this.permitId = ko.observable();
	this.isNew = ko.observable();
	this.isEditing = ko.observable(false);
	this.line = new demax.inspections.model.permits.lines.PermitLineVersion();
	this.lineDto = ko.observable();
	this.user = demax.inspections.authenticatedUser();
	this.lineId;
	this.permitHardware = ko.observableArray();
	this.hardwareCount = ko.observable();
	this.permitLineDocuments = ko.observableArray();
	this.permitLineDocumentsCount = ko.observable();
	this.isRdaaAndCanEdit = ko.observable(false);
	this.isCallCenter = ko.observable(false);
	this.PermitStatus = demax.inspections.nomenclature.permits.PermitStatus;
	this.vehicleInspectionTypeDto = new InspectionTypeDto(InspectionTypes.VEHICLE.code);
	this.permitStatusCode = ko.observable();

	this.typesViewMap = [
		ko.observableArray([]),
		ko.observableArray([]),
		ko.observableArray([]),
		ko.observableArray([])
	];

	this.categoriesViewMap = {
		L: ko.observableArray([]),
		M: ko.observableArray([]),
		N: ko.observableArray([]),
		O: ko.observableArray([]),
		A: ko.observableArray([])
	};

	var allCategoryObjectsMap = {};
	var inspectionTypeDtoMap = {};
	this.hardwarePagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: self.PAGE_SIZE
	});
	this.documentsPagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: self.PAGE_SIZE
	});

	// Remove hardware
	self.selectedForRemove = ko.observable();
	self.removeHardwareParams = ko.observable();
	self.isPopupVisible = ko.observable(false);

	this.init = function (params) {
		self.permitId(params.id);		
		setUrls(params.id, params.lineId);
		self.isCallCenter(self.user.userIsCallCenter());

		if (params.permitNumber && params.permitStatusCode) {
			self.permitNumber(params.permitNumber ? params.permitNumber : " - ");
			self.permitStatusCode(params.permitStatusCode);
			
			self.isRdaaAndCanEdit(self.user.userIsRdaa
				&& (params.permitStatusCode == self.PermitStatus.CREATED.code || params.permitStatusCode == self.PermitStatus.DRAFT.code));
		} else {
			restClient.getResource(URL.GET_PERMIT_DETAILS)
				.done(function (result) {
					self.permitNumber(result.permitNumber ? result.permitNumber : " - ");

					self.isRdaaAndCanEdit(self.user.userIsRdaa
						&& (result.statusCode == self.PermitStatus.CREATED.code || result.statusCode == self.PermitStatus.DRAFT.code));
					self.permitStatusCode(result.statusCode);

				}).handleErrors({
					NoSuchEntityException: function () {
						demax.inspections.popupManager.error("Не е намерено Разрешение с ID " + self.permitId())
							.done(function () {
								demax.inspections.router.setHash("permits");
							});
					}
				});
		}

		if (params.lineId) {
			this.lineId = params.lineId;
			self.isNew(false);

			restClient.getResource(URL.GET_LINE).done(function (dto) {
				self.line.setPropertiesFromDto(dto);
				self.lineDto(dto);

				getPermitLineDocumentsPage(1)
					.done(function (result) {
						self.permitLineDocumentsCount(result.totalCount);
						subscriptions.push(self.documentsPagination.queryParamsObject.subscribe(function (params) {
							getPermitLineDocumentsPage(params.page);
						}));
					});
				
				if (self.isCallCenter()) {
					getPermitLineHardwarePage(1)
						.done(function (result) {
							self.hardwareCount(result.totalCount);
							subscriptions.push(self.hardwarePagination.queryParamsObject.subscribe(function (params) {
								getPermitLineHardwarePage(params.page);
							}));
						});
				}
			});
		} else {
			self.isNew(true);
			self.isRdaaAndCanEdit(self.user.userIsRdaa);
		}

		self.typesViewMap[0]()[0] = self.vehicleInspectionTypeDto;
		inspectionTypeDtoMap[self.vehicleInspectionTypeDto.code] = self.typesViewMap[0]()[0];
		self.typesViewMap[1]()[0] = new InspectionTypeDto(InspectionTypes.BUS.code);
		inspectionTypeDtoMap[InspectionTypes.BUS.code] = self.typesViewMap[1]()[0];
		self.typesViewMap[1]()[1] = new InspectionTypeDto(InspectionTypes.BUSCHILDREN.code);
		inspectionTypeDtoMap[InspectionTypes.BUSCHILDREN.code] = self.typesViewMap[1]()[1];
		self.typesViewMap[2]()[0] = new InspectionTypeDto(InspectionTypes.TAXI.code);
		inspectionTypeDtoMap[InspectionTypes.TAXI.code] = self.typesViewMap[2]()[0];
		self.typesViewMap[2]()[1] = new InspectionTypeDto(InspectionTypes.TROL.code);
		inspectionTypeDtoMap[InspectionTypes.TROL.code] = self.typesViewMap[2]()[1];
		self.typesViewMap[2]()[2] = new InspectionTypeDto(InspectionTypes.TRAM.code);
		inspectionTypeDtoMap[InspectionTypes.TRAM.code] = self.typesViewMap[2]()[2];
		self.typesViewMap[2]()[3] = new InspectionTypeDto(InspectionTypes.SG.code);
		inspectionTypeDtoMap[InspectionTypes.SG.code] = self.typesViewMap[2]()[3];
		self.typesViewMap[3]()[0] = new InspectionTypeDto(InspectionTypes.SEMT.code);
		inspectionTypeDtoMap[InspectionTypes.SEMT.code] = self.typesViewMap[3]()[0];
		self.typesViewMap[3]()[1] = new InspectionTypeDto(InspectionTypes.ADR.code);
		inspectionTypeDtoMap[InspectionTypes.ADR.code] = self.typesViewMap[3]()[1];
		self.typesViewMap[3]()[2] = new InspectionTypeDto(InspectionTypes.GAS.code);
		inspectionTypeDtoMap[InspectionTypes.GAS.code] = self.typesViewMap[3]()[2];

		nomenclatureService.getAllVehicleCategoryCodes()
			.done(function (categoryCodes) {
				nomenclatureService.getInspectionTypesAndCategories()
					.done(function (types) {

						categoryCodes.forEach(function (code) {

							var category = { code: code, selected: ko.observable(false), types: [] };
							allCategoryObjectsMap[code] = category;

							for (var i = 0; i < types.length; i++) {
								var type = types[i];
								var inspectionType = inspectionTypeDtoMap[type.inspectionTypeCode];

								if (type.categoryCodes.indexOf(code) > -1) {
									inspectionType.categories.push(category);
									category.types.push(inspectionType);
								}
							}

							if (code.startsWith("L")) {
								self.categoriesViewMap["L"].push(category);
							} else if (code.startsWith("M")) {
								self.categoriesViewMap["M"].push(category);
							} else if (code.startsWith("N")) {
								self.categoriesViewMap["N"].push(category);
							} else if (code.startsWith("O")) {
								self.categoriesViewMap["O"].push(category);
							} else if (code.startsWith("A") || code.startsWith("T")) {
								self.categoriesViewMap["A"].push(category);
							}
						});

						Object.keys(self.categoriesViewMap).forEach(function (key) {
							self.categoriesViewMap[key].sort(function (a, b) {
								return a.code === b.code ? 0
									: a.code < b.code ? -1 : 1;
							});
						});

						if (params.lineId) {
							if (self.lineDto()) {
								setCodesOfExistingLine();
							} else {
								var subscription = self.lineDto.subscribe(function () {
									subscription.dispose();
									setCodesOfExistingLine();
								});
							}
						}
					});
			});
	};

	this.dispose = function () {
		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();
	};

	this.selectCategory = function (category) {
		category.selected(!category.selected());
		category.types.forEach(function (type) {
			type.computeSelected();
		});
	};

	this.selectInspectionType = function (type) {
		if (type.canSelect || type.categories.length === 0) {
			type.selected(!type.selected());
		} else {
			var categoryCodes = type.categories.map(function (category) {
				return category.code;
			}).join(", ");

			demax.inspections.popupManager.info("Изберете поне една от категориите:  " + categoryCodes);
		}
	};

	this.saveLine = function () {

		var params = getAndValidateParams();

		restClient.postResource(URL.BASE, JSON.stringify(params)).done(function () {
			demax.inspections.popupManager.success({ message: "Линията е добавена успешно." })
				.done(function () {
					demax.inspections.router.setHash("permits/details/" + self.permitId());
				});
		}).handleErrors(errorHandlers);
	};

	this.editLine = function () {

		var params = getAndValidateParams();

		restClient.putResource(URL.EDIT_LINE, JSON.stringify(params)).done(function () {
			demax.inspections.popupManager.success({ message: "Линията е променена успешно." })
				.done(function () {
					demax.inspections.router.setHash("permits/details/" + self.permitId());
				});
		}).handleErrors(errorHandlers);
	};

	function getAndValidateParams() {

		if (!self.vehicleInspectionTypeDto.selected()) {
			demax.inspections.popupManager.error("Изберете " + InspectionTypes.VEHICLE.text);
			return;
		}

		var params = {
			categoryCodes: [],
			inspectionTypeCodes: []
		};

		Object.keys(self.categoriesViewMap).forEach(function (key) {
			self.categoriesViewMap[key]().forEach(function (category) {
				if (category.selected()) {
					params.categoryCodes.push(category.code);
				}
			});
		});

		if (params.categoryCodes.length === 0) {
			demax.inspections.popupManager.error("Изберете поне една категория");
			return;
		}

		self.typesViewMap.forEach(function (typeArr) {
			typeArr().forEach(function (type) {
				if (type.selected()) {
					params.inspectionTypeCodes.push(type.code);
				}
			});
		});

		return params;
	}

	this.toggleEditing = function () {
		self.isEditing(!self.isEditing());
		unSelectAllCategories();
		setCodesOfExistingLine();
	};

	this.cancelEditing = function () {
		var params = {
			categoryCodes: [],
			inspectionTypeCodes: []
		};

		Object.keys(self.categoriesViewMap).forEach(function (key) {
			self.categoriesViewMap[key]().forEach(function (category) {
				if (category.selected()) {
					params.categoryCodes.push(category.code);
				}
			});
		});

		self.typesViewMap.forEach(function (typeArr) {
			typeArr().forEach(function (type) {
				if (type.selected()) {
					params.inspectionTypeCodes.push(type.code);
				}
			});
		});

		if (self.lineDto().vehicleCategoryCodes.length !== params.categoryCodes.length
			|| self.lineDto().inspectionTypeCodes.length !== params.inspectionTypeCodes.length) {
			showChangesPopup(self.toggleEditing);
			return;
		}
		for (var i1 = 0; i1 < self.lineDto().vehicleCategoryCodes.length; i1++) {
			if (params.categoryCodes.indexOf(self.lineDto().vehicleCategoryCodes[i1]) == -1) {
				showChangesPopup(self.toggleEditing);
				return;
			}
		}
		for (var i2 = 0; i2 < self.lineDto().inspectionTypeCodes.length; i2++) {
			if (params.inspectionTypeCodes.indexOf(self.lineDto().inspectionTypeCodes[i2]) == -1) {
				showChangesPopup(self.toggleEditing);
				return;
			}
		}
		self.toggleEditing();
	};

	self.getAddHardwareUrl = function () {
		return "#/permits/details/" + self.permitId() + "/lines/" + self.lineId + "/hardware";
	};

	self.showRemoveHardwarePopup = function (permitHardware) {
		self.isPopupVisible(true);
		self.selectedForRemove(permitHardware);
	};

	self.hideRemoveHardwarePopup = function () {
		self.isPopupVisible(false);
		self.selectedForRemove(null);
	};

	self.removeHardwareFromLine = function () {
		
		if (self.removeHardwareParams.statusId == undefined 
				|| self.removeHardwareParams.warehouseId == undefined) {
			demax.inspections.popupManager.error("Моля въведете склад и статус!");
			return;
		}

		var url = URL.HARDWARE + "/" + self.selectedForRemove().id();
		var params = { 
			deviceTypeCode: self.selectedForRemove().type().code,
			statusId: self.removeHardwareParams.statusId,
			warehouseId: self.removeHardwareParams.warehouseId 
		};
		restClient.patchResource(url, JSON.stringify(params))
			.done(function () {
				self.hideRemoveHardwarePopup();
				self.hardwarePagination.page(1);
				getPermitLineHardwarePage();
			});
	};

	self.removeDocumentFromLine = function (selectedDocument) {
		popupManager.confirm({
			cssClass: "popInfo",
			message: "Сигурни ли сте, че искате да изтриете документ към линия?",
			okButtonCss: "btn-primary"
		}).done(function () {
			var url = URL.DOCUMENTS + "/" + selectedDocument.id;
			restClient.deleteResource(url)
				.done(function() {
					self.permitLineDocuments.remove(function(document) {
						return document.id === selectedDocument.id;
					});
				});
		});
	};

	self.installationTransferProtocol = function () {
		window.open(URL.INSTALL_PROTOCOL);
	};


	self.retrivalTransferProtocol = function () {
		window.open(URL.RETRIEVE_PROTOCOL);
	};


	self.getAddDocumentUrl = function () {
		return "#/permits/details/" + self.permitId() + "/lines/" + self.lineId + "/documents/new";
	};

	self.getPreviewDocumentUrl = function (docId) {
		return "#/permits/details/" + self.permitId() + "/lines/" + self.lineId + "/documents/" + docId;
	};

	function setUrls(permitId, lineId) {
		Object.keys(URL).forEach(function (key) {
			URL[key] = URL[key].replace("{permitId}", permitId).replace("{lineId}", lineId);
		});
	}

	function InspectionTypeDto(code) {
		var self = this;

		this.code = code;
		this.categories = [];
		this.selected = ko.observable(false);
		this.canSelect = false;

		this.computeSelected = function () {
			if (self.categories.length > 0) {
				var canSelect = false;

				self.categories.forEach(function (category) {
					canSelect = canSelect || category.selected();
				});

				self.selected(canSelect ? self.selected() : false);
				self.canSelect = canSelect;
			} else {
				self.canSelect = true;
			}
		};
	}

	function getPermitLineHardwarePage() {
		var pageParams = self.hardwarePagination.queryParamsObject();
		return restClient.getResource(URL.HARDWARE, pageParams)
			.done(function (result) {
				self.permitHardware(result.items.map(function (hardware) {
					return new demax.inspections.model.equipment.hardware.HardwareDeviceItem(hardware);
				}));
			}).handleErrors({
				NoSuchEntityException: function (message) {
					if (message.indexOf("PermitVersion") > -1) {
						popupManager.error("Разрешението не е намерено");
					}
				},
				PermitLineNotFoundException: function () {
					popupManager.error("Не е намерена линия към това разрешение");
				}
			});
	}

	function getPermitLineDocumentsPage() {
		var docaPageParams = self.documentsPagination.queryParamsObject();
		return restClient.getResource(URL.DOCUMENTS, docaPageParams)
			.done(function (result) {
				self.permitLineDocuments(result.items.map(function (doc) {
					return new demax.inspections.model.permits.lines.PermitLineDocumentDto(doc);
				}));
			}).handleErrors({

			});
	}

	function setCodesOfExistingLine() {
		self.lineDto().vehicleCategoryCodes.forEach(function (code) {
			var category = allCategoryObjectsMap[code];
			if (category) {
				category.selected(true);
			}
		});

		self.lineDto().inspectionTypeCodes.forEach(function (code) {
			var inspectionType = inspectionTypeDtoMap[code];
			if (inspectionType) {
				inspectionType.selected(true);
			}
		});

		Object.keys(self.typesViewMap).forEach(function (key) {
			self.typesViewMap[key]().forEach(function (type) {
				type.computeSelected();
			});
		});
	}

	function showChangesPopup(callback) {
		popupManager.confirm({
			cssClass: "popInfo",
			message: "Сигурни ли сте, че искате да отхвърлите промените си?",
			okButtonCss: "btn-primary"
		}).done(function () {
			callback();
		});
	}

	function unSelectAllCategories() {
		Object.keys(self.categoriesViewMap).forEach(function (key) {
			self.categoriesViewMap[key]().forEach(function (category) {
				category.selected(false);
			});
		});

		self.typesViewMap.forEach(function (typeArr) {
			typeArr().forEach(function (type) {
				type.selected(false);
			});
		});
	}
};
