namespace("demax.inspections.viewmodel.permits.reports");

demax.inspections.viewmodel.permits.reports.HtmlReportVM = function () {
	var self = this;
	var restClient = demax.inspections.restClient;
	var CONTENT_PLACEHOLDER = "CONTENT";
	var downloadElement = document.createElement("a");
	downloadElement.style.display = "none";

	var URLS = {
		HTML_BASE: "views/components/html-report-base.html",
		VALID_PERMITS: "api/reports/permits/html/valid",
		GAS_PERMITS: "api/reports/permits/html/gas",
		CATEGORY_V_PERMITS: "api/reports/permits/html/category-v",
		CATEGORY_L_PERMITS: "api/reports/permits/html/category-l",
		SEMT_CERTIFICATES: "api/reports/html/semt-certificates",
		SEMT_PERMITS: "api/reports/permits/html/semt"
	};

	this.isLoading = restClient.isLoading;

	this.init = function() {
		restClient.getResource(URLS.HTML_BASE)
			.done(function(html) {
				self.htmlBase = html;
			});
	};

	this.downloadAllValidPermitsHtml = function() {
		restClient.getResource(URLS.VALID_PERMITS)
			.done(function(dtos) {
				var permits = dtos.map(function(dto) {
					return new demax.inspections.model.permits.reports.PermitHtmlReportDto(dto);
				});
				
				var args = {};
				args.content = "<h1>Справка за всички валидни разрешения към дата " + getDateNow() + " / " + permits.length + " бр.</h1>";
				args.permits = permits;
				args.columns = ["Разрешение №", "Издадено на (фирма)", "Адрес на КТП", "Населено място (КТП)", "Област", "Категории (линия)"];
				args.properties = ["permitNumber", "companyName", "address", "city", "region", "categories"];
				args.filename = "all-valid-permits.html";

				downloadPermitHtml(args);
			});
	};

	this.downloadGasPermitsHtml = function() {
		restClient.getResource(URLS.GAS_PERMITS)
			.done(function(dtos) {
				var permits = dtos.map(function(dto) {
					return new demax.inspections.model.permits.reports.GasPermitHtmlReportDto(dto);
				});

				var args = {};
				args.content = "<h1>Списък на контролно-технически пунктове, получили разрешение за извършване на проверка на газови уредби към дата " 
					+ getDateNow() + " / " + permits.length + " бр.</h1>";
				args.permits = permits;
				args.columns = ["Разрешение №", "Издадено на (фирма)", "Адрес на КТП", "Населено място (КТП)", "Област", "Телефонен номер(а)", "Категория (КТП)", "Категории (линия)"];
				args.properties = ["permitNumber", "companyName", "address", "city", "region", "phoneNumber", "ktpCategory", "categories"];
				args.filename = "gas-permits.html";

				downloadPermitHtml(args);
			});
	};

	this.downloadCategoryVPermitsHtml = function() {
		restClient.getResource(URLS.CATEGORY_V_PERMITS)
			.done(function(dtos) {
				var permits = dtos.map(function(dto) {
					return new demax.inspections.model.permits.reports.CategoryVPermitHtmlReportDto(dto);
				});

				var args = {};
				args.content = "<h1>Списък на фирмите, получили разрешение за извършване на периодични прегледи и проверки на ППС, превозващи определени опасни товари (КТП - V категория) "
					+ "и продължаване срока на валидност на удостоверение за одобрение на ППС, превозващи определени опасни товари към дата " + getDateNow() + " / " + permits.length + " бр.</h1>";
				args.permits = permits;
				args.columns = ["Разрешение №", "Издадено на (фирма)", "Адрес на КТП", "Населено място (КТП)", "Област", "Телефонен номер(а)"];
				args.properties = ["permitNumber", "companyName", "address", "city", "region", "phoneNumber"];
				args.filename = "category-v-permits.html";

				downloadPermitHtml(args);
			});
	};

	this.downloadCategoryLPermitsHtml = function() {
		restClient.getResource(URLS.CATEGORY_L_PERMITS)
			.done(function(dtos) {
				var permits = dtos.map(function(dto) {
					return new demax.inspections.model.permits.reports.CategoryLPermitHtmlReportDto(dto);
				});

				var args = {};
				args.content = "<h1>Списък на КТП за L категория МПС към дата " + getDateNow() + " / " + permits.length + " бр.</h1>";
				args.permits = permits;
				args.columns = ["Разрешение №", "Издадено на (фирма)", "Адрес на КТП", "Населено място (КТП)", "Област", "Телефонен номер(а)", "Категория (КТП)", "Категории (линия)"];
				args.properties = ["permitNumber", "companyName", "address", "city", "region", "phoneNumber", "ktpCategory", "categories"];
				args.filename = "category-l-permits.html";

				downloadPermitHtml(args);
			});
	};

	this.downloadSemtPermitsHtml = function() {
		restClient.getResource(URLS.SEMT_PERMITS)
			.done(function(dtos) {
				var permits = dtos.map(function(dto) {
					return new demax.inspections.model.permits.reports.SemtPermitHtmlReportDto(dto);
				});

				var args = {};
				args.content = "<h1>Списък на контролно-технически пунктове, получили разрешение за извършване на проверка на техническата изправност на превозните средства и издаване "
					+ "и заверка на Сертификати за техническа изправност на пътни превозни средства по Резолюция ITF/TMB/TR/MQ/2008/12 към дата "
					+ getDateNow() + " / " + permits.length + " бр.</h1>";
				args.permits = permits;
				args.columns = ["Разрешение №", "Издадено на (фирма)", "Адрес на КТП", "Населено място (КТП)", "Област", "Телефонен номер(а)"];
				args.properties = ["permitNumber", "companyName", "address", "city", "region", "phoneNumber"];
				args.filename = "semt-permits.html";

				downloadPermitHtml(args);
			});
	};

	this.downloadSemtCertificatesHtml = function() {
		restClient.getResource(URLS.SEMT_CERTIFICATES)
			.done(function(dtos) {
				var certificates = dtos.map(function(dto) {
					return new demax.inspections.model.permits.reports.SemtCertificateHtmlReportDto(dto);
				});

				var content = "<h1>Списък на валидните ЕКМТ сертификати след " + getDateNow() +"</h1>";

				content += "<div class=\"table\"><div class=\"row header\">"
					+ createCellDiv("Рег. №")
					+ createCellDiv("VIN/Рама №")
					+ createCellDiv("Еко категория")
					+ createCellDiv("Сертификат валиден до")
					+ "</div>";
		
				certificates.sort(function(a, b) {
					return a.registrationNumber.localeCompare(b.registrationNumber);
				}).forEach(function(certificate) {
					content += "<div class=\"row\">"
						+ createCellDiv(certificate.registrationNumber)
						+ createCellDiv(certificate.vinFrameNumber)
						+ createCellDiv(certificate.ecoCategory)
						+ createCellDiv(certificate.nextInspectionDate)
						+ "</div>";
				});

				content += "</div>";

				var html = self.htmlBase.replace(CONTENT_PLACEHOLDER, content);
				
				download("semt-certificates", html);
			});	
	};

	function downloadPermitHtml(args) {

		var content = args.content;
		var permitMap = {};

		args.permits.forEach(function(permit) {
			if (permitMap[permit.region] === undefined) {
				permitMap[permit.region] = [];
			}

			permitMap[permit.region].push(permit);
		});

		Object.keys(permitMap).sort().forEach(function(region) {
			content += "<div class=\"oblastWrp\">"
				+ "<h2><span>област</span><span>" + region + "</span></h2>"
				+ "<div class=\"table\"><div class=\"row header\">";
			args.columns.forEach(function(column) {
				content += createCellDiv(column);
			});
			content += "</div>";

			permitMap[region].sort(function(a, b) {
				if (a.permitNumber > b.permitNumber) {
					return 1;
				} else if (a.permitNumber < b.permitNumber) {
					return -1;
				} else {
					return 0;
				}
			}).forEach(function(permit) {
				content += "<div class=\"row\">";
				args.properties.forEach(function(property) {
					content += createCellDiv(permit[property] ? permit[property] : "-");
				});
				content += "</div>";
			});

			content += "</div></div>";
		});

		var html = self.htmlBase.replace(CONTENT_PLACEHOLDER, content);
		
		download(args.filename, html);
	}

	function createCellDiv(text) {
		return "<div class=\"cell\">" + text + "</div>";
	}

	function download(filename, text) {
		downloadElement.setAttribute("href", "data:text/html;charset=utf-8," + encodeURIComponent(text));
		downloadElement.setAttribute("download", filename);

		downloadElement.click();
	}

	function getDateNow() {
		return moment().format(demax.inspections.settings.momentDateFormat);
	}
};