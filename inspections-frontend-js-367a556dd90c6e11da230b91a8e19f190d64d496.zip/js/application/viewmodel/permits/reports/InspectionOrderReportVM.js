namespace("demax.inspections.viewmodel.permits.reports");

demax.inspections.viewmodel.permits.reports.InspectionOrderReportVM = function () {
	var self = this;

	var subscriptions = [];
	var InspectionOrderReportSearchFilters = demax.inspections.model.orders.InspectionOrderReportSearchFilters;
	var OrgUnits = demax.inspections.nomenclature.permits.PermitRegion;
	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;

	var Event = demax.inspections.Event;
	var eventsQueue = demax.inspections.events;

	var URLS = {
		GET_INSPECTION_ORDERS_REPORT_LIST: "api/reports/permits/orders",
		GET_INSPECTION_ORDERS_REPORT_XLSX: "api/reports/permits/orders/xlsx",
		GET_INSPECTION_ORDER_BANK_STATEMENT: "api/inspection-orders/{0}/bank-statement/pdf",
		GET_INSPECTION_ORDER_STATUSES: "api/nomenclatures/inspection-orders-statuses"
	};

	var thisNamespace = ".inspectionOrderReportVm";

	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: 20
	});

	this.isLoading = restClient.isLoading;
	self.isLoading = ko.pureComputed(function() {
		return restClient.isLoading() || blobClient.isLoading();
	});

	this.user = demax.inspections.authenticatedUser();
	this.filters = new InspectionOrderReportSearchFilters();
	this.orgUnits = ko.observableArray(OrgUnits.ALL);
	this.orders = ko.observableArray();
	this.ordersCount = ko.observable();
	this.statuses = ko.observableArray();

	this.init = function () {
		restoreMemento();
		subscribeToKeyEvents();

		restClient.getResource(URLS.GET_INSPECTION_ORDER_STATUSES)
			.done(function(statuses) {
				self.statuses(statuses);
			});

		subscriptions.push(self.pagination.queryParamsObject.subscribe(function () {
			self.filters.loadLastUsedFilters();
			loadOrders();
		}));
	};

	this.performNewSearch = function () {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadOrders();
		} else {
			self.pagination.page(1);
		}
	};

	this.exportExcel = function () {
		self.filters.loadLastUsedFilters();
		var queryParams = ko.unwrap(self.filters.toQueryParams());
		var urlQueryParams = $.param(queryParams);
		blobClient.downloadBlob(URLS.GET_INSPECTION_ORDERS_REPORT_XLSX + "?" + urlQueryParams);
	};

	this.viewBankStatement = function (order) {
		window.open(pastel.util.StringHelper.format(URLS.GET_INSPECTION_ORDER_BANK_STATEMENT, order.id));
	};

	function onEnter() {
		var isLoading = self.isLoading();
		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function subscribeToKeyEvents() {
		eventsQueue.subscribe(Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	}

	function unsubscribeFromKeyEvents() {
		eventsQueue.unsubscribe(Event.KEYPRESS_ENTER + thisNamespace);
	}

	this.dispose = function () {
		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});

		saveMemento();
		unsubscribeFromKeyEvents();
		restClient.cancelAll();
	};

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(memento.filterParams.orgUnit);
			}
			if (memento.filterParams.hasBankStatement) {
				self.filters.hasBankStatement(memento.filterParams.hasBankStatement);
			}
			if (memento.filterParams.orderStatus) {
				self.filters.orderStatus(memento.filterParams.orderStatus);
			}
			if (memento.filterParams.dateRange) {
				self.filters.dateRange(memento.filterParams.dateRange);
			}
		}

		self.filters.saveLastUsedFilters();
		loadOrders();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	function loadOrders() {
		var searchParams = self.filters.toQueryParams();
		if ($.isEmptyObject(searchParams)) {
			self.orders([]);
			return;
		}
		var pageParams = self.pagination.queryParamsObject();
		var params = $.extend({}, pageParams, searchParams);

		self.orders([]);
		self.ordersCount(0);
		restClient.getResource(URLS.GET_INSPECTION_ORDERS_REPORT_LIST, params)
			.done(function (response) {
				self.orders(response.items.map(function (order) {
					return new demax.inspections.model.orders.InspectionOrderReportListItem(order);
				}));
				self.ordersCount(response.totalCount);
			});
	}

};