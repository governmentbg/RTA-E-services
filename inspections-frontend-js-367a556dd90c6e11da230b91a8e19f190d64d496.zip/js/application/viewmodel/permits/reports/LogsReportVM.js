namespace("demax.inspections.viewmodel.permits.reports");

demax.inspections.viewmodel.permits.reports.LogsReportVM = function () {
	var self = this;
	var subscriptions = [];
	var LogsReportSearchFilters = demax.inspections.model.permits.reports.LogsReportSearchFilters;
	var LogsReportListItem = demax.inspections.model.permits.reports.LogsReportListItem;
	var LogQueryTypes = demax.inspections.nomenclature.logs.LogQueryType;
	var LogObjectTypes = demax.inspections.nomenclature.logs.LogObjectType;
	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;
	var thisNamespace = ".logsReportVm";

	var Event = demax.inspections.Event;
	var eventsQueue = demax.inspections.events;

	var URLS = {
		GET_LOGS_REPORT_LIST: "api/reports/logs",
		GET_LOGS_REPORT_XLSX: "api/reports/logs/xlsx"
	};

	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: 20
	});

	this.isLoading = ko.pureComputed(function () {
		return restClient.isLoading() || blobClient.isLoading();
	});

	this.user = demax.inspections.authenticatedUser();
	this.filters = new LogsReportSearchFilters();

	this.queryTypes = ko.observableArray(LogQueryTypes.ALL);
	this.objectTypes = ko.observableArray(LogObjectTypes.ALL);

	this.logs = ko.observableArray();
	this.logsCount = ko.observable();

	this.reportTitle = ko.observable();

	this.init = function () {
		restoreMemento();
		subscribeToKeyEvents();

		subscriptions.push(self.pagination.queryParamsObject.subscribe(function () {
			self.filters.loadLastUsedFilters();
			loadLogs();
		}));
	};

	function loadLogs() {
		var searchParams = self.filters.toQueryParams();
		if ($.isEmptyObject(searchParams)) {
			self.logs([]);
			return;
		}
		var pageParams = self.pagination.queryParamsObject();
		var params = $.extend({}, pageParams, searchParams);

		self.logs([]);
		self.logsCount(0);
		restClient.getResource(URLS.GET_LOGS_REPORT_LIST, params)
			.done(function (response) {
				self.logs(ko.utils.arrayMap(response.items, function (logDto) {
					return new LogsReportListItem(logDto);
				}));
				self.logsCount(response.totalCount);
				self.reportTitle(calculateReportTitle());
			});
	}

	this.performNewSearch = function () {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadLogs();
		} else {
			self.pagination.page(1);
		}
	};

	this.exportExcel = function () {
		self.filters.loadLastUsedFilters();
		var queryParams = ko.unwrap(self.filters.toQueryParams());
		var urlQueryParams = $.param(queryParams);
		blobClient.downloadBlob(URLS.GET_LOGS_REPORT_XLSX + "?" + urlQueryParams);
	};

	function subscribeToKeyEvents() {
		eventsQueue.subscribe(Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	}

	function unsubscribeFromKeyEvents() {
		eventsQueue.unsubscribe(Event.KEYPRESS_ENTER + thisNamespace);
	}

	function onEnter() {
		var isLoading = self.isLoading();
		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function calculateReportTitle () {
		// Example: Нови специалисти от период 07.02.18 г. - 07.03.18 г. / 3 бр.
		var queryType = self.filters.queryType().description;
		var objectType = self.filters.objectType().description.toLowerCase();
		var rangeAndCount = "от период " + self.filters.getFormattedRange() + " / " + self.logsCount() + " бр.";
		return queryType + " " + objectType + " " + rangeAndCount;
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.queryType) {
				self.filters.queryType(memento.filterParams.queryType);
			}

			if (memento.filterParams.searchType) {
				self.filters.searchType(memento.filterParams.objectType);
			}
			if (memento.filterParams.dateRange) {
				self.filters.dateRange(memento.filterParams.dateRange);
			}
		}
		self.filters.saveLastUsedFilters();
		loadLogs();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	this.dispose = function () {
		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});

		saveMemento();
		unsubscribeFromKeyEvents();
		restClient.cancelAll();
	};

};