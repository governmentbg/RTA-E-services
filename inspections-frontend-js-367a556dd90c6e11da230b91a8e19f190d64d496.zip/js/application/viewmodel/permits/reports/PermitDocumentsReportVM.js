namespace("demax.inspections.viewmodel.permits.reports");

demax.inspections.viewmodel.permits.reports.PermitDocumentsReportVM = function () {
	var self = this;

	var subscriptions = [];
	var PermitDocumentsReportSearchFilters = demax.inspections.model.permits.reports.PermitDocumentsReportSearchFilters;
	var PermitDocumentStatuses = demax.inspections.nomenclature.permits.PermitDocumentStatus;
	var userUtil = demax.inspections.utils.UserUtils;
	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;

	var Event = demax.inspections.Event;
	var eventsQueue = demax.inspections.events;
	var thisNamespace = ".permitDoucmentsReportVm";

	var URLS = {
		GET_PERMIT_DOCUMENTS_REPORT_LIST: "api/reports/permits/documents",
		GET_PERMIT_DOCUMENTS_REPORT_XLSX: "api/reports/permits/documents/xlsx",
		GET_DOC_TYPES: "api/nomenclatures/permit-document-types"
	};

	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: 20
	});

	self.isLoading = ko.pureComputed(function() {
		return restClient.isLoading() || blobClient.isLoading();
	});

	this.permitDocumentStatuses = PermitDocumentStatuses;
	this.user = demax.inspections.authenticatedUser();
	this.filters = new PermitDocumentsReportSearchFilters();
	this.orgUnits = ko.observableArray(userUtil.getOrgUnits());
	this.documents = ko.observableArray();
	this.documentsCount = ko.observable();
	this.statusOptions = ko.observableArray(PermitDocumentStatuses.EVERY_STATUS);
	this.documentTypes = ko.observableArray([]);

	this.init = function (params) {
		!$.isEmptyObject(params) ? applyParams(params) : restoreMemento();

		loadDocumentTypes();

		subscriptions.push(self.pagination.queryParamsObject.subscribe(function () {
			self.filters.loadLastUsedFilters();
			loadDocuments();
		}));

		subscribeToKeyEvents();
	};

	function loadDocuments() {
		var searchParams = self.filters.toQueryParams();
		if ($.isEmptyObject(searchParams)) {
			self.documents([]);
			return;
		}
		var pageParams = self.pagination.queryParamsObject();
		var params = $.extend({}, pageParams, searchParams);

		self.documents([]);
		self.documentsCount(0);
		restClient.getResource(URLS.GET_PERMIT_DOCUMENTS_REPORT_LIST, params)
			.done(function (response) {
				self.documents(ko.utils.arrayMap(response.items, function (documentDto) {
					return new demax.inspections.model.permits.reports.PermitDocumentReportListItem(documentDto);
				}));
				self.documentsCount(response.totalCount);
			});
	}

	function loadDocumentTypes() {
		restClient.getResource(URLS.GET_DOC_TYPES)
			.done(function (response) {
				self.documentTypes(ko.utils.arrayMap(response, function (docType) {
					return new demax.inspections.model.permits.documents.DocumentType(docType);
				}));
			});
	}

	this.getPreviewPermitHref = function (data) {
		return "#/permits/details/" + data.permitVersionId;
	};

	this.performNewSearch = function () {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadDocuments();
		} else {
			self.pagination.page(1);
		}
	};

	this.exportExcel = function () {
		self.filters.loadLastUsedFilters();
		var queryParams = ko.unwrap(self.filters.toQueryParams());
		var urlQueryParams = $.param(queryParams);
		blobClient.downloadBlob(URLS.GET_PERMIT_DOCUMENTS_REPORT_XLSX + "?" + urlQueryParams);
	};

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}
			
			if (memento.filterParams.statusCode) {
				self.filters.statusCode(memento.filterParams.statusCode);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(memento.filterParams.orgUnit);
			}
			if (memento.filterParams.docType) {
				self.filters.docType(memento.filterParams.docType);
			}
		}
		self.filters.saveLastUsedFilters();
		loadDocuments();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	function applyParams(params) {
		self.filters.statusCode(params.status);
		self.performNewSearch();
	}
	
	function onEnter() {
		var isLoading = self.isLoading();
		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function subscribeToKeyEvents() {
		eventsQueue.subscribe(Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	}

	function unsubscribeFromKeyEvents() {
		eventsQueue.unsubscribe(Event.KEYPRESS_ENTER + thisNamespace);
	}

	this.dispose = function () {
		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});

		saveMemento();
		unsubscribeFromKeyEvents();
		restClient.cancelAll();
	};

};