namespace("demax.inspections.viewmodel.permits.reports");

demax.inspections.viewmodel.permits.reports.PermitInspectorsReportVM = function () {
	var self = this;

	var subscriptions = [];
	var PermitInspectorsReportSearchFilters = demax.inspections.model.permits.reports.PermitInspectorsReportSearchFilters;
	var userUtil = demax.inspections.utils.UserUtils;
	var InspectionTypes = demax.inspections.nomenclature.techinsp.InspectionTypes;
	var PermitInspectorStatus = demax.inspections.nomenclature.permits.PermitInspectorStatus;
	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;

	var Event = demax.inspections.Event;
	var eventsQueue = demax.inspections.events;

	var thisNamespace = ".permitInspectorReportVm";

	var URLS = {
		GET_PERMIT_INSPECTORS_REPORT_LIST: "api/reports/permits/inspectors",
		GET_PERMIT_INSPECTORS_REPORT_XLSX: "api/reports/permits/inspectors/xlsx"
	};

	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: 20
	});

	this.isLoading = restClient.isLoading;
	self.isLoading = ko.pureComputed(function() {
		return restClient.isLoading() || blobClient.isLoading();
	});

	this.user = demax.inspections.authenticatedUser();
	this.filters = new PermitInspectorsReportSearchFilters();
	this.orgUnits = ko.observableArray(userUtil.getOrgUnits());
	this.inspectors = ko.observableArray();
	this.inspectorsCount = ko.observable();
	this.inspectionTypes = InspectionTypes.ALL;
	this.inspectorStatuses = PermitInspectorStatus.EVERY_STATUS;
	this.permitInspectorStatus = PermitInspectorStatus;

	this.init = function () {
		restoreMemento();

		subscriptions.push(self.pagination.queryParamsObject.subscribe(function () {
			self.filters.loadLastUsedFilters();
			loadInspectors();
		}));
		
		subscribeToKeyEvents();
	};

	function loadInspectors() {
		var searchParams = self.filters.toQueryParams();
		if ($.isEmptyObject(searchParams)) {
			self.inspectors([]);
			return;
		}
		var pageParams = self.pagination.queryParamsObject();
		var params = $.extend({}, pageParams, searchParams);

		self.inspectors([]);
		self.inspectorsCount(0);
		restClient.getResource(URLS.GET_PERMIT_INSPECTORS_REPORT_LIST, params)
			.done(function (response) {
				self.inspectors(ko.utils.arrayMap(response.items, function (inspectorDto) {
					return new demax.inspections.model.permits.reports.PermitInspectorReportListItem(inspectorDto);
				}));
				self.inspectorsCount(response.totalCount);
			});
	}

	this.performNewSearch = function () {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadInspectors();
		} else {
			self.pagination.page(1);
		}
	};

	this.exportExcel = function () {
		self.filters.loadLastUsedFilters();
		var queryParams = ko.unwrap(self.filters.toQueryParams());
		var urlQueryParams = $.param(queryParams);
		blobClient.downloadBlob(URLS.GET_PERMIT_INSPECTORS_REPORT_XLSX + "?" + urlQueryParams);
	};

	function onEnter() {
		var isLoading = self.isLoading();
		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}
			
			if (memento.filterParams.statusCode) {
				self.filters.statusCode(memento.filterParams.statusCode);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(memento.filterParams.orgUnit);
			}
			if (memento.filterParams.isChairman) {
				self.filters.isChairman(memento.filterParams.isChairman);
			}
			if (memento.filterParams.inspectionType) {
				self.filters.inspectionType(memento.filterParams.inspectionType);
			}
			if (memento.filterParams.hasCard) {
				self.filters.hasCard(memento.filterParams.hasCard);
			}
		}
		self.filters.saveLastUsedFilters();
		loadInspectors();
	}

	function subscribeToKeyEvents() {
		eventsQueue.subscribe(Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	}

	function unsubscribeFromKeyEvents() {
		eventsQueue.unsubscribe(Event.KEYPRESS_ENTER + thisNamespace);
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	this.dispose = function () {
		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});

		saveMemento();
		unsubscribeFromKeyEvents();
		restClient.cancelAll();
	};
};
