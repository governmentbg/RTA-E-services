namespace("demax.inspections.viewmodel.permits.reports");

demax.inspections.viewmodel.permits.reports.PermitLinesReportVM = function () {
	var self = this;

	var subscriptions = [];
	var PermitLinesReportSearchFilters = demax.inspections.model.permits.reports.PermitLinesReportSearchFilters;
	var userUtil = demax.inspections.utils.UserUtils;
	var nomenclatureService = demax.inspections.nomenclature.NomenclatureService;
	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;

	var Event = demax.inspections.Event;
	var eventsQueue = demax.inspections.events;

	var thisNamespace = ".permitLinesReportVm";

	var URLS = {
		GET_PERMIT_LINES_REPORT_LIST: "api/reports/permits/lines",
		GET_PERMIT_LINES_REPORT_XLSX: "api/reports/permits/lines/xlsx",
		GET_LINE_DOC_TYPES: "api/nomenclatures/permit-document-types/lines"
	};

	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: 20
	});

	this.isLoading = ko.pureComputed(function() {
		return restClient.isLoading() || blobClient.isLoading();
	});

	this.user = demax.inspections.authenticatedUser();
	this.filters = new PermitLinesReportSearchFilters();
	this.orgUnits = ko.observableArray(userUtil.getOrgUnits());
	this.categories = ko.observableArray();
	this.inspectionTypes = ko.observableArray();
	this.lines = ko.observableArray();
	this.linesCount = ko.observable();

	this.init = function () {

		nomenclatureService.getAllVehicleCategoryCodes()
			.done(function (categoryCodes) {
				self.categories(categoryCodes);
			});

		nomenclatureService.getInspectionTypes()
			.done(function (inspectionTypes) {
				self.inspectionTypes(inspectionTypes);
			});

		restoreMemento();
		subscribeToKeyEvents();

		subscriptions.push(self.pagination.queryParamsObject.subscribe(function () {
			self.filters.loadLastUsedFilters();
			loadLines();
		}));
	};

	function loadLines() {
		var searchParams = self.filters.toQueryParams();
		if ($.isEmptyObject(searchParams)) {
			self.lines([]);
			return;
		}
		var pageParams = self.pagination.queryParamsObject();
		var params = $.extend({}, pageParams, searchParams);

		self.lines([]);
		self.linesCount(0);
		restClient.getResource(URLS.GET_PERMIT_LINES_REPORT_LIST, params)
			.done(function (response) {
				self.lines(ko.utils.arrayMap(response.items, function (lineDto) {
					return new demax.inspections.model.permits.reports.PermitLineReportListItem(lineDto);
				}));
				self.linesCount(response.totalCount);
			});
	}

	this.getPreviewPermitLineHref = function (data) {
		return "#/permits/details/" + data.permitVersionId + "/lines/" + data.lineVersionId;
	};

	this.performNewSearch = function () {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadLines();
		} else {
			self.pagination.page(1);
		}
	};

	this.exportExcel = function () {
		self.filters.loadLastUsedFilters();
		var queryParams = ko.unwrap(self.filters.toQueryParams());
		var urlQueryParams = $.param(queryParams, true);
		blobClient.downloadBlob(URLS.GET_PERMIT_LINES_REPORT_XLSX + "?" + urlQueryParams);
	};

	function onEnter() {
		var isLoading = self.isLoading();

		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(memento.filterParams.orgUnit);
			}
			if (memento.filterParams.categories) {
				self.filters.categories(memento.filterParams.categories);
			}
			if (memento.filterParams.inspectionTypes) {
				self.filters.inspectionTypes(memento.filterParams.inspectionTypes);
			}
		}
		self.filters.saveLastUsedFilters();
		loadLines();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	function subscribeToKeyEvents() {
		eventsQueue.subscribe(Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	}

	function unsubscribeFromKeyEvents() {
		eventsQueue.unsubscribe(Event.KEYPRESS_ENTER + thisNamespace);
	}

	this.dispose = function () {
		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});

		saveMemento();
		unsubscribeFromKeyEvents();
		restClient.cancelAll();
	};
};