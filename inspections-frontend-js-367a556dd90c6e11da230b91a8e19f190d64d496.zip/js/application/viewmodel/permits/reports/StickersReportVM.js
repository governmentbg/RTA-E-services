namespace("demax.inspections.viewmodel.permits.reports");

demax.inspections.viewmodel.permits.reports.StickersReportVM = function () {
	var self = this;
	var subscriptions = [];
	var StickersReportSearchFilters = demax.inspections.model.permits.reports.StickersReportSearchFilters;
	var StickersReportListItem = demax.inspections.model.permits.reports.StickersReportListItem;
	var OrgUnits = demax.inspections.nomenclature.permits.PermitRegion;
	var StickerStatuses = demax.inspections.nomenclature.orders.stickers.StickerStatus;
	var StickerSearchTypes = demax.inspections.nomenclature.orders.stickers.StickerSearchType;
	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;

	var Event = demax.inspections.Event;
	var eventsQueue = demax.inspections.events;

	var URLS = {
		GET_STICKERS_REPORT_LIST: "api/reports/permits/orders/stickers",
		GET_STICKERS_REPORT_XLSX: "api/reports/permits/orders/stickers/xlsx"
	};

	var thisNamespace = ".stickersReportVm";

	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: 20
	});

	this.isLoading = ko.pureComputed(function() {
		return restClient.isLoading() || blobClient.isLoading();
	});

	this.user = demax.inspections.authenticatedUser();
	this.filters = new StickersReportSearchFilters();

	this.orgUnits = ko.observableArray(OrgUnits.ALL);
	this.statuses = ko.observableArray(StickerStatuses.ALL);
	this.searchTypes = ko.observableArray(StickerSearchTypes.ALL);

	this.stickers = ko.observableArray();
	this.stickersCount = ko.observable();

	this.init = function () {
		restoreMemento();
		subscribeToKeyEvents();

		subscriptions.push(self.pagination.queryParamsObject.subscribe(function () {
			self.filters.loadLastUsedFilters();
			loadStickers();
		}));
	};

	function loadStickers() {
		var searchParams = self.filters.toQueryParams();
		if ($.isEmptyObject(searchParams)) {
			self.stickers([]);
			return;
		}
		var pageParams = self.pagination.queryParamsObject();
		var params = $.extend({}, pageParams, searchParams);

		self.stickers([]);
		self.stickersCount(0);
		restClient.getResource(URLS.GET_STICKERS_REPORT_LIST, params)
			.done(function (response) {
				self.stickers(ko.utils.arrayMap(response.items, function (cardDto) {
					return new StickersReportListItem(cardDto);
				}));
				self.stickersCount(response.totalCount);
			});
	}

	this.performNewSearch = function () {
		var validationErrors = ko.validation.group([
			self.filters.searchText, self.filters.searchType, self.filters.fromDate, self.filters.toDate
		]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			demax.inspections.popupManager.warn("Има невалидни полета!");
			return;
		}

		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadStickers();
		} else {
			self.pagination.page(1);
		}
	};

	this.exportExcel = function () {
		self.filters.loadLastUsedFilters();
		var queryParams = ko.unwrap(self.filters.toQueryParams());
		var urlQueryParams = $.param(queryParams);
		blobClient.downloadBlob(URLS.GET_STICKERS_REPORT_XLSX + "?" + urlQueryParams);
	};

	function onEnter() {
		var isLoading = self.isLoading();
		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}

			if (memento.filterParams.searchType) {
				self.filters.searchType(memento.filterParams.searchType);
			}
			
			if (memento.filterParams.status) {
				self.filters.status(memento.filterParams.status);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(memento.filterParams.orgUnit);
			}
			if (memento.filterParams.fromDate) {
				self.filters.fromDate(memento.filterParams.fromDate);
			}
			if (memento.filterParams.toDate) {
				self.filters.toDate(memento.filterParams.toDate);
			}
		}
		self.filters.saveLastUsedFilters();
		loadStickers();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	function subscribeToKeyEvents() {
		eventsQueue.subscribe(Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	}

	function unsubscribeFromKeyEvents() {
		eventsQueue.unsubscribe(Event.KEYPRESS_ENTER + thisNamespace);
	}

	this.dispose = function () {
		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});

		saveMemento();
		unsubscribeFromKeyEvents();
		restClient.cancelAll();
	};

};