namespace("demax.inspections.viewmodel.permits.reports");

demax.inspections.viewmodel.permits.reports.SubjectCardsReportVM = function () {
	var self = this;
	var subscriptions = [];
	var SubjectCardsReportSearchFilters = demax.inspections.model.permits.reports.SubjectCardsReportSearchFilters;
	var OrgUnits = demax.inspections.nomenclature.permits.PermitRegion;
	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;
	
	var Event = demax.inspections.Event;
	var eventsQueue = demax.inspections.events;

	var URLS = {
		GET_SUBJECT_CARDS_REPORT_LIST: "api/reports/subjects/cards",
		GET_SUBJECT_CARDS_REPORT_XLSX: "api/reports/subjects/cards/xlsx"
	};

	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: 20
	});

	var thisNamespace = ".subjectCardsReportVm";

	this.isLoading = ko.pureComputed(function() {
		return restClient.isLoading() || blobClient.isLoading();
	});

	this.user = demax.inspections.authenticatedUser();
	this.filters = new SubjectCardsReportSearchFilters();
	this.orgUnits = ko.observableArray(OrgUnits.ALL);
	this.statuses = ko.observableArray([
		{ name: "активирана", value: true },
		{ name: "деактивирана", value: false }
	]);
	this.cards = ko.observableArray();
	this.cardsCount = ko.observable();

	this.init = function () {
		restoreMemento();
		subscribeToKeyEvents();

		subscriptions.push(self.pagination.queryParamsObject.subscribe(function () {
			self.filters.loadLastUsedFilters();
			loadCards();
		}));
	};

	function loadCards() {
		var searchParams = self.filters.toQueryParams();
		if ($.isEmptyObject(searchParams)) {
			self.cards([]);
			return;
		}
		var pageParams = self.pagination.queryParamsObject();
		var params = $.extend({}, pageParams, searchParams);

		self.cards([]);
		self.cardsCount(0);
		restClient.getResource(URLS.GET_SUBJECT_CARDS_REPORT_LIST, params)
			.done(function (response) {
				self.cards(ko.utils.arrayMap(response.items, function (cardDto) {
					return new demax.inspections.model.permits.reports.SubjectCardsReportListItem(cardDto);
				}));
				self.cardsCount(response.totalCount);
			});
	}

	this.getPreviewPermitHref = function (data) {
		return "#/permits/details/" + data.id;
	};

	this.performNewSearch = function () {
		var validationErrors = ko.validation.group([self.filters.searchText]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			demax.inspections.popupManager.warn("Има невалидни полета!");
			return;
		}

		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadCards();
		} else {
			self.pagination.page(1);
		}
	};

	this.exportExcel = function () {
		self.filters.loadLastUsedFilters();
		var queryParams = ko.unwrap(self.filters.toQueryParams());
		var urlQueryParams = $.param(queryParams);
		blobClient.downloadBlob(URLS.GET_SUBJECT_CARDS_REPORT_XLSX + "?" + urlQueryParams);
	};

	function onEnter() {
		var isLoading = self.isLoading();
		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}
			
			if (memento.filterParams.isActive) {
				self.filters.isActive(memento.filterParams.isActive);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(memento.filterParams.orgUnit);
			}
		}
		self.filters.saveLastUsedFilters();
		loadCards();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	function subscribeToKeyEvents() {
		eventsQueue.subscribe(Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	}

	function unsubscribeFromKeyEvents() {
		eventsQueue.unsubscribe(Event.KEYPRESS_ENTER + thisNamespace);
	}

	this.dispose = function () {
		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});

		saveMemento();
		unsubscribeFromKeyEvents();
		restClient.cancelAll();
	};

};