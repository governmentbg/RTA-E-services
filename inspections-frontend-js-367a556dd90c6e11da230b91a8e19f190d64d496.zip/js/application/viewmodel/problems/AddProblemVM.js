namespace("demax.inspections.viewmodel.problems");

demax.inspections.viewmodel.problems.AddProblemVM = function () {
	var self = this;
	var PermitProblemCreationRequest = demax.inspections.model.problems.PermitProblemCreationRequest;
	var PermitProblemDetails = demax.inspections.model.problems.PermitProblemDetails;
	var restClient = demax.inspections.restClient;

	self.permitNum = ko.observable().extend({
		required: true
	});
	self.request = new PermitProblemCreationRequest();
	self.details = new PermitProblemDetails();
 
	self.isLoading = restClient.isLoading;

	var URL = {
		PERMIT_PROBLEMS: "api/permit-problems",
		PERMIT_BY_NUM: "api/permits/by-number/{0}/problems"
	};

	this.init = function (params) {
		if (params.permitNumber) {
			self.permitNum(params.permitNumber);
			loadPermit();
		}
	};

	this.searchPermit = function () {
		var validationErrors = ko.validation.group([self.permitNum]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			demax.inspections.popupManager.warn("Има невалидни полета!");
			return;
		}

		loadPermit();
	};

	this.saveProblem = function () {
		if (self.isLoading()) {
			return;
		}

		var validationErrors = ko.validation.group([self.permitNum, self.request.permitId, self.request.problemDesc]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			demax.inspections.popupManager.warn("Има невалидни полета!");
			return;
		}

		restClient.postResource(URL.PERMIT_PROBLEMS, self.request.toRequestBody())
			.done(function () {
				demax.inspections.popupManager.success({ message: "Успешно добавен нов проблем." }).done(function () {
					demax.inspections.router.setHash("problems");
				}).fail(function () {
					demax.inspections.router.setHash("problems");
				});
			}).handleErrors({
				NoSuchEntityException: function (message) {
					if (message.indexOf("Permit") > -1) {
						demax.inspections.popupManager.error("Разрешение с номер " + self.permitNum() + " не е намерено!");
					}
					if (message.indexOf("subject") > -1) {
						demax.inspections.popupManager.error("Не е намарено лицето към настоящия потребител");
					}
					if (message.indexOf("user") > -1) {
						demax.inspections.popupManager.error("Настоящият потребител не е намерен");
					}
				}
			});
	};

	this.handleCancelButton = function () {
		if (hasChanges()) {
			demax.inspections.popupManager.confirm({
				message: "Сигурни ли сте, че искате да затворите страницата?",
				okButtonText: "Да",
				cancelButtonText: "Не",
				cssClass: "popError",
				okButtonCss: "btn-success"
			}).done(function () {
				demax.inspections.router.setHash("problems");
			});
		} else {
			demax.inspections.router.setHash("problems");
		}
	};

	function loadPermit() {
		var url = pastel.util.StringHelper.format(URL.PERMIT_BY_NUM, self.permitNum());
		restClient.getResource(url)
			.done(function (detailsDto) {
				self.details.loadDetails(detailsDto);
				self.request.permitId(detailsDto.id);
			}).handleErrors({
				NoSuchEntityException: function () {
					demax.inspections.popupManager.error("Разрешение с номер " + self.permitNum() + " не е намерено!").done(function() {
						clearFields();
					});
				},
				PermitIsNotValidException: function() {
					demax.inspections.popupManager.error("Разрешение с номер " + self.permitNum() + " не е валидно");
				}
			});
	}

	function hasChanges() {
		return self.permitNum.isModified() || self.request.problemDesc.isModified() || self.request.expectedCheckDate();
	}

	function clearFields() {
		self.request.clearAllFields();
		self.details.clearAllFields();
	}

};