namespace("demax.inspections.viewmodel.problems");

demax.inspections.viewmodel.problems.EditProblemVM = function () {
	var self = this;
	var PermitProblemEditDetails = demax.inspections.model.problems.PermitProblemEditDetails;
	var restClient = demax.inspections.restClient;

	self.permitProblem = ko.observable(null);

	self.isLoading = restClient.isLoading;

	var URL = {
		PERMIT_PROBLEMS: "api/permit-problems",
		PERMIT_PROBLEM_BY_ID: "api/permit-problems/{0}"
	};

	this.init = function (params) {
		getPermitProblem(params.id);
	};

	function getPermitProblem(id) {
		var url = pastel.util.StringHelper.format(URL.PERMIT_PROBLEM_BY_ID, id);
		restClient.getResource(url)
			.done(function (detailsDto) {
				self.permitProblem(new PermitProblemEditDetails(detailsDto));
			}).handleErrors({
				NoSuchEntityException: function () {
					demax.inspections.router.setHash("problems");
					demax.inspections.popupManager.error("Разрешение с id " + id + " не е намерено!");
				}
			});
	}

	this.handleCancelButton = function () {
		if (hasChanges()) {
			demax.inspections.popupManager.confirm({
				message: "Сигурни ли сте, че искате да затворите страницата?",
				okButtonText: "Да",
				cancelButtonText: "Не",
				cssClass: "popError",
				okButtonCss: "btn-success"
			}).done(function () {
				demax.inspections.router.setHash("problems");
			});
		} else {
			demax.inspections.router.setHash("problems");
		}
	};

	function hasChanges() {
		return self.permitProblem().checkedOn() || self.permitProblem().checkedBy() || self.permitProblem().checkDescription();
	}

	this.canEdit = (function () {
		return demax.inspections.authenticatedUser().isUserOfGroup([demax.inspections.nomenclature.Role.CALL_CENTER]);
	})();

	this.updateProblem = function () {
		if (self.isLoading()) {
			return;
		}
		var validationErrors = ko.validation.group([self.permitProblem().checkedOn, self.permitProblem().checkedBy,
			self.permitProblem().checkDescription]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			demax.inspections.popupManager.warn("Има невалидни полета!");
			return;
		}

		var url = pastel.util.StringHelper.format(URL.PERMIT_PROBLEM_BY_ID, self.permitProblem().id);
		restClient.putResource(url, self.permitProblem().toRequestBody())
			.done(function () {
				demax.inspections.popupManager.success({ message: "Успешно променен проблем." }).done(function () {
					location.reload();
				}).fail(function () {
					demax.inspections.router.setHash("problems");
				});
			}).handleErrors({
				NoSuchEntityException: function () {
					demax.inspections.popupManager.error("Проблем с ид: " + self.permitProblem().id + " не е намерен!");
				}
			});
	};

	this.updateProblemDescription = function () {
		if (self.isLoading()) {
			return;
		}

		var validationErrors = ko.validation.group([self.permitProblem().problemDesc]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			return;
		}

		var dto = {};

		if (self.permitProblem().problemDesc()) {
			dto.problemDescription = self.permitProblem().problemDesc();
		}

		if (self.permitProblem().checkDescription()) {
			dto.checkDescription = self.permitProblem().checkDescription();
		}

		var url = pastel.util.StringHelper.format(URL.PERMIT_PROBLEM_BY_ID, self.permitProblem().id);
		restClient.patchResource(url, JSON.stringify(dto))
			.done(function () {
				demax.inspections.popupManager.success({ message: "Успешно променен проблем." }).done(function () {
					location.reload();
				}).fail(function () {
					demax.inspections.router.setHash("problems");
				});
			}).handleErrors({
				NoSuchEntityException: function () {
					demax.inspections.popupManager.error("Проблем с ид: " + self.permitProblem().id + " не е намерен!");
				}
			});
	};

};