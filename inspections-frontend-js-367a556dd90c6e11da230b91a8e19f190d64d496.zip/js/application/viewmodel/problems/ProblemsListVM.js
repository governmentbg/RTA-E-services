namespace("demax.inspections.viewmodel.problems");

demax.inspections.viewmodel.problems.ProblemsListVM = function () {
	var self = this;
	var subscriptions = [];
	var restClient = demax.inspections.restClient;
	var PermitProblemStatuses = demax.inspections.nomenclature.problems.ProblemStatuses;
	var PermitProblemSearchFilter = demax.inspections.model.problems.ProblemSearchFilters;
	var ParamStatuses = demax.inspections.nomenclature.problems.ProblemStatuses;

	var URLS = {
		BASE_URL: "api/permit-problems"
	};

	var thisNamespace = ".permitProblemsListVm";

	this.isLoading = restClient.isLoading;
	this.shouldShowAddButton = ko.observable(false);
	this.pageSizes = [20, 50, 100];
	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: self.pageSizes[0]
	});

	this.problemsCount = ko.observable();
	this.problems = ko.observableArray([]);
	this.statusOptions = ko.observable(PermitProblemStatuses.EVERY_STATUS);
	this.filters = new PermitProblemSearchFilter();
	this.orgUnits = ko.observableArray();

	this.getPreviewProblemHref = function (data) {
		return "#/problems/preview/" + data.id;
	};

	this.getPerviewPermitHref = function (data) {
		return "#/permits/details/" + data.permitVersionId;
	};

	this.init = function(params) {
		loadOrgUnits().done(function () {
			restoreMemento();
			loadProblems();
		});

		self.shouldShowAddButton(demax.inspections.authenticatedUser().isUserOfGroup([demax.inspections.nomenclature.Role.CALL_CENTER]));
		if (params && params.permitNumber) {
			self.filters.searchText(params.permitNumber);
			if (params.status) {
				self.filters.status(ParamStatuses.getById(params.status));
			}
			loadProblems();
		}
		
		subscriptions.push(self.pagination.queryParamsObject.subscribe(function() {
			self.filters.loadLastUsedFilters();
			loadProblems();
		}));

		demax.inspections.events.subscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	};

	function loadProblems() {
		var pageParams = self.pagination.queryParamsObject();
		var searchParams = self.filters.toQueryParams();
		var params = $.extend({}, pageParams, searchParams);
		restClient.getResource(URLS.BASE_URL, params)
			.done(function (response) {
				self.problems(ko.utils.arrayMap(response.items, function (problemDto) {
					return new demax.inspections.model.problems.ProblemListItem(problemDto);
				}));
				self.problemsCount(response.totalCount);
			});
	}

	function onEnter() {
		var isLoading = self.isLoading();

		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	this.refresh = function() {
		self.filters.loadLastUsedFilters();
		loadProblems();
	};

	this.performNewSearch = function() {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadProblems();
		} else {
			self.pagination.page(1);
		}
	};

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.searchText) {
				self.filters.searchText(memento.filterParams.searchText);
			}
			if (memento.filterParams.dateCreated) {
				self.filters.dateCreated(memento.filterParams.dateCreated);
			}
			if (memento.filterParams.status) {
				self.filters.status(memento.filterParams.status);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(self.orgUnits.find("code", memento.filterParams.orgUnit));
			}
		}
		self.filters.saveLastUsedFilters();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	function loadOrgUnits() {
		return demax.inspections.nomenclature.NomenclatureService.getOrgUnitsWithoutIaaa().done(function (orgUnitDtos) {
			self.orgUnits(ko.utils.arrayMap(orgUnitDtos, function (orgUnitDto) {
				return new demax.inspections.model.OrgUnit(orgUnitDto);
			}));
		});
	}

	this.dispose = function() {
		saveMemento();

		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});

		demax.inspections.events.unsubscribe(demax.inspections.Event.KEYPRESS_ENTER + thisNamespace);
		// router.removeListener(paramEventListener);
		restClient.cancelAll();
	};

};