namespace("demax.inspections.viewmodel.techinsp");

demax.inspections.viewmodel.techinsp.DashboardVM = function () {
	var self = this;
	var restClient = demax.inspections.restClient;

	self.PermitStatus = demax.inspections.nomenclature.permits.PermitStatus;
	self.PermitDocumentStatus = demax.inspections.nomenclature.permits.PermitDocumentStatus;
	self.inspectorCertificationTypes = demax.inspections.nomenclature.permits.InspectorCertificationType;
	
	self.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: 5
	});

	self.permitDocumentsExpired = ko.observableArray();
	self.permitDocumentsExpiring = ko.observableArray();
	self.permitLineDocumentsExpired = ko.observableArray();
	self.permitLineDocumentsExpiring = ko.observableArray();
	self.inspectorDocumentsExpired = ko.observableArray();
	self.inspectorCertificatesExpired = ko.observableArray();
	self.inspectorDocumentsExpiring = ko.observableArray();
	self.inspectorCertificatesExpiring = ko.observableArray();

	self.isPermitDocumentsExpiringVisible = ko.observable(false);
	self.isPermitDocumentsExpiredVisible = ko.observable(false);
	self.isLineDocumentsExpiringVisible = ko.observable(false);
	self.isLineDocumentsExpiredVisible = ko.observable(false);
	self.isInspectorDocumentsExpiredVisible = ko.observable(false);
	self.isInspectorCertificatesExpiredVisible = ko.observable(false);
	self.isInspectorDocumentsExpiringVisible = ko.observable(false);
	self.isInspectorCertificatesExpiringVisible = ko.observable(false);


	self.dashboard = ko.observable();
	self.isLoading = ko.pureComputed(function () {
		return restClient.isLoading();
	});


	var URLS = {
		DASHBOARD: "api/dashboard",
		INSPECTOR_DOCUMENTS: "api/dashboard/inspectors/documents",
		INSPECTOR_CERTIFICATES: "api/dashboard/inspectors/certifications",
		PERMIT_DOCUMENTS: "api/dashboard/permits/documents",
		LINE_DOCUMENTS: "api/dashboard/lines/documents"
	};

	this.init = function () {
		restClient.getResource(URLS.DASHBOARD)
			.done(function (result) {
				self.dashboard(new demax.inspections.model.techinsp.DashboardInfo(result));
				loadPermitDocuments(self.PermitDocumentStatus.EXPIRING.code);
				loadPermitDocuments(self.PermitDocumentStatus.EXPIRED.code);
				loadLineDocuments(self.PermitDocumentStatus.EXPIRING.code);
				loadLineDocuments(self.PermitDocumentStatus.EXPIRED.code);
				loadInspectorDocuments(self.PermitDocumentStatus.EXPIRING.code);
				loadInspectorDocuments(self.PermitDocumentStatus.EXPIRED.code);
				loadInspectorCertificates(self.PermitDocumentStatus.EXPIRING.code);
				loadInspectorCertificates(self.PermitDocumentStatus.EXPIRED.code);
			});
	};

	function resetTables () {
		self.isPermitDocumentsExpiringVisible(false);
		self.isPermitDocumentsExpiredVisible(false);
		self.isLineDocumentsExpiringVisible(false);
		self.isLineDocumentsExpiredVisible(false);
		self.isInspectorDocumentsExpiredVisible(false);
		self.isInspectorDocumentsExpiringVisible(false);
		self.isInspectorCertificatesExpiredVisible(false);
		self.isInspectorCertificatesExpiringVisible(false);
	}

	self.getExpiringInspectorDocuments = function () {
		resetTables();
		self.isInspectorDocumentsExpiringVisible(true);
	};

	self.getExpiredInspectorDocuments = function () {
		resetTables();
		self.isInspectorDocumentsExpiredVisible(true);
	};

	function loadInspectorDocuments(statusCode) {
		
		var search = {
			statusCode: statusCode
		};

		var pageParams = self.pagination.queryParamsObject();
		var params = $.extend({}, pageParams, search);

		restClient.getResource(URLS.INSPECTOR_DOCUMENTS, params)
			.done(function (response) {
				if (statusCode === self.PermitDocumentStatus.EXPIRING.code) {
					self.dashboard().inspectorDocuments.expireAfterDays(response.totalCount);
					self.inspectorDocumentsExpiring(ko.utils.arrayMap(response.items, function (documentDto) {
						return new demax.inspections.model.permits.reports.PermitInspectorDocumentsReportListItem(documentDto);
					}));
				} else {
					self.dashboard().inspectorDocuments.expired(response.totalCount);
					self.inspectorDocumentsExpired(ko.utils.arrayMap(response.items, function (documentDto) {
						return new demax.inspections.model.permits.reports.PermitInspectorDocumentsReportListItem(documentDto);
					}));
				}
			});
	}

	self.getExpiringPermitDocuments = function () {
		resetTables();
		self.isPermitDocumentsExpiringVisible(true);
	};

	self.getExpiredPermitDocuments = function () {
		resetTables();
		self.isPermitDocumentsExpiredVisible(true);
	};

	function loadPermitDocuments(statusCode) {
		
		var search = {
			statusCode: statusCode
		};

		var pageParams = self.pagination.queryParamsObject();
		var params = $.extend({}, pageParams, search);

		restClient.getResource(URLS.PERMIT_DOCUMENTS, params)
			.done(function (response) {
				if (statusCode === self.PermitDocumentStatus.EXPIRING.code) {
					self.dashboard().permitDocuments.expireAfterDays(response.totalCount);
					self.permitDocumentsExpiring(ko.utils.arrayMap(response.items, function (documentDto) {
						return new demax.inspections.model.permits.reports.PermitDocumentReportListItem(documentDto);
					}));
				} else {
					self.dashboard().permitDocuments.expired(response.totalCount);
					self.permitDocumentsExpired(ko.utils.arrayMap(response.items, function (documentDto) {
						return new demax.inspections.model.permits.reports.PermitDocumentReportListItem(documentDto);
					}));
				}
			});
	}

	self.getExpiringLineDocuments = function () {
		resetTables();
		self.isLineDocumentsExpiringVisible(true);
	};

	self.getExpiredLineDocuments = function () {
		resetTables();
		self.isLineDocumentsExpiredVisible(true);
	};

	function loadLineDocuments(statusCode) {
		
		var search = {
			statusCode: statusCode
		};

		var pageParams = self.pagination.queryParamsObject();
		var params = $.extend({}, pageParams, search);

		restClient.getResource(URLS.LINE_DOCUMENTS, params)
			.done(function (response) {
				if (statusCode === self.PermitDocumentStatus.EXPIRING.code) {
					self.dashboard().lineDocuments.expireAfterDays(response.totalCount);
					self.permitLineDocumentsExpiring(ko.utils.arrayMap(response.items, function (documentDto) {
						return new demax.inspections.model.permits.reports.PermitLineDocumentReportListItem(documentDto);
					}));
				} else {
					self.dashboard().lineDocuments.expired(response.totalCount);
					self.permitLineDocumentsExpired(ko.utils.arrayMap(response.items, function (documentDto) {
						return new demax.inspections.model.permits.reports.PermitLineDocumentReportListItem(documentDto);
					}));
				}
			});
	}

	self.getExpiringInspectionCertificates = function () {
		resetTables();
		self.isInspectorCertificatesExpiringVisible(true);
	};

	self.getExpiredInspectionCertificates = function () {
		resetTables();
		self.isInspectorCertificatesExpiredVisible(true);
	};

	this.getPreviewPermitHref = function (data) {
		return "#/permits/details/" + data.permitVersionId;
	};

	function loadInspectorCertificates(statusCode) {
		
		var search = {
			statusCode: statusCode
		};

		var pageParams = self.pagination.queryParamsObject();
		var params = $.extend({}, pageParams, search);

		restClient.getResource(URLS.INSPECTOR_CERTIFICATES, params)
			.done(function (response) {
				if (statusCode === self.PermitDocumentStatus.EXPIRING.code) {
					self.dashboard().inspectorCertificates.expireAfterDays(response.totalCount);
					self.inspectorCertificatesExpiring(ko.utils.arrayMap(response.items, function (documentDto) {
						return new demax.inspections.model.permits.reports.DashboardInspectorCertificationListItem(documentDto);
					}));
				} else {
					self.dashboard().inspectorCertificates.expired(response.totalCount);
					self.inspectorCertificatesExpired(ko.utils.arrayMap(response.items, function (documentDto) {
						return new demax.inspections.model.permits.reports.DashboardInspectorCertificationListItem(documentDto);
					}));
				}
			});
	}

	self.goToPermitReportsWithStatus = function (status) {
		demax.inspections.router.setHash("techinsp/reports/permits", { status: status });
	};

	this.getPreviewPermitLineHref = function (data) {
		return "#/permits/details/" + data.permitVersionId + "/lines/" + data.lineVersionId + "/documents/" + data.id;
	};

	this.getPreviewPermitInspectorHref = function (data) {
		return "#/permits/details/" + data.id;
	};

};