namespace("demax.inspections.viewmodel.techinsp");

demax.inspections.viewmodel.techinsp.DiagnosticsVM = function() {
	var self = this;
	var subscriptions = [];
	var OrgUnit = demax.inspections.model.OrgUnit;
	var DiagnosticSearchFilters = demax.inspections.model.techinsp.DiagnosticSearchFilters;
	var DiagnosticListItem = demax.inspections.model.techinsp.DiagnosticListItem;
	var DiagnosticCamerStatus = demax.inspections.nomenclature.techinsp.DiagnosticCameraStatus;
	var DiagnosticConnectivityStatus = demax.inspections.nomenclature.techinsp.DiagnosticConnectivityStatus;
	var DiagnosticSoftwareStatusOption = demax.inspections.nomenclature.techinsp.DiagnosticSoftwareStatusOption;
	var Pagination = pastel.plus.component.pagination.Pagination;
	var restClient = demax.inspections.restClient;

	var Event = demax.inspections.Event;
	var eventsQueue = demax.inspections.events;
	
	var URL = {
		PERMIT_LINES_DIAGNOSTICS: "api/permit-lines/diagnostics"
	};

	var thisNamespace = ".diagnosticsVm";
	
	this.isLoading = restClient.isLoading;
	this.orgUnits = ko.observableArray([]);
	this.diagnosticCameraStatuses = pastel.plus.util.toArray(DiagnosticCamerStatus);
	this.diagnosticConnectivityStatuses = pastel.plus.util.toArray(DiagnosticConnectivityStatus);
	this.diagnosticSoftwareStatusOption = pastel.plus.util.toArray(DiagnosticSoftwareStatusOption);
	
	this.diagnosticItems = ko.observable([]);
	this.diagnosticItemsCount = ko.observable(0);
	
	this.filters = ko.validatedObservable(new DiagnosticSearchFilters(), {deep: true});
	this.pagination = new Pagination({
		page: 1,
		pageSize: 10
	});
	
	this.init = function() {
		loadOrgUnits().done(function() {
			restoreMemento();
			loadDiagnostics();
		});
		subscribeToKeyEvents();

		subscriptions.push(self.pagination.queryParamsObject.subscribe(function() {
			self.filters().loadLastUsedFilters();
			loadDiagnostics();
		}));
	};

	this.performNewSearch = function() {
		self.filters().saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadDiagnostics();
		} else {
			self.pagination.page(1);
		}
	};
	
	this.refresh = function() {
		self.filters().loadLastUsedFilters();
		loadDiagnostics();
	};

	function loadDiagnostics() {
		if (!self.filters.isValid()) {
			self.filters.errors.showAllMessages();
			return;
		}
		var pageParams = self.pagination.queryParamsObject();
		var searchParams = self.filters().toQueryParams();
		var requestParams = $.extend({}, pageParams, searchParams);
		
		self.diagnosticItems([]);
		self.diagnosticItemsCount(0);
		
		restClient.getResource(URL.PERMIT_LINES_DIAGNOSTICS, requestParams)
			.done(function(resp) {
				self.diagnosticItems(ko.utils.arrayMap(resp.items, function(itemDto) {
					return new DiagnosticListItem(itemDto);
				}));
				self.diagnosticItemsCount(resp.totalCount);
			}).handleErrors({
				NoSuchEntityException: function() {
					demax.inspections.popupManager.error("Разрешение с номер " + self.filters().permitNumber() + " не съществува!");
				}
			});
	}
	
	function loadOrgUnits() {
		return demax.inspections.nomenclature.NomenclatureService.getOrgUnitsWithoutIaaa()
			.done(function(orgUnitDtos) {
				self.orgUnits(ko.utils.arrayMap(orgUnitDtos, function(orgUnitDto) {
					return new OrgUnit(orgUnitDto);
				}));
			});
	}

	function onEnter() {
		var isLoading = self.isLoading();
		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.cameraStatus) {
				self.filters().cameraStatus(memento.filterParams.cameraStatus);
			}
			if (memento.filterParams.connectivityStatus) {
				self.filters().connectivityStatus(memento.filterParams.connectivityStatus);
			}
			if (memento.filterParams.softwareStatus) {
				self.filters().softwareStatus(memento.filterParams.softwareStatus);
			}
			if (memento.filterParams.orgUnit) {
				self.filters().orgUnit(self.orgUnits.find("code", memento.filterParams.orgUnit));
			}
		}
		self.filters().saveLastUsedFilters();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters().getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	function subscribeToKeyEvents() {
		eventsQueue.subscribe(Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	}

	function unsubscribeFromKeyEvents() {
		eventsQueue.unsubscribe(Event.KEYPRESS_ENTER + thisNamespace);
	}
	
	this.dispose = function() {
		saveMemento();
		unsubscribeFromKeyEvents();

		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();
	};
};