namespace("demax.inspections.viewmodel.techinsp");

demax.inspections.viewmodel.techinsp.FinishedInspectionsListVM = function() {
	var self = this;
	var FinishedInspectionSearchFilters = demax.inspections.model.techinsp.FinishedInspectionSearchFilters;
	var FinishedInspectionSpecificSearchFilters = demax.inspections.model.techinsp.FinishedInspectionSpecificSearchFilters;
	var FinishedInspectionListItem = demax.inspections.model.techinsp.FinishedInspectionListItem;
	var InspectionConclusion = demax.inspections.nomenclature.techinsp.InspectionConclusion;
	var InspectionStatusOption = demax.inspections.nomenclature.techinsp.InspectionStatusOption;
	var InspectionSpecificSearchFilter = demax.inspections.nomenclature.techinsp.InspectionSpecificSearchFilter;
	var URL = {
		PERMIT_INSPECTORS: "api/permit-inspectors",
		FINISHED_INSPECTIONS: "api/inspections/finished",
		FINISHED_INSPECTIONS_SPECIFIC: "api/inspections/finished-specific-search",
		FINISHED_INSPECTIONS_SPECIFIC_ROLE: "api/inspections/finished-specific-role-search",
		INSPECTION_VIDEO_BY_ID: "api/inspections/{0}/short-video",
		EXPORT_FINISHED_INSPECTIONS: "api/inspections/finished/xls",
		EXPORT_FINISHED_INSPECTIONS_SPECIFIC: "api/inspections/finished-specific-search/xls",
		EXPORT_FINISHED_INSPECTIONS_SPECIFIC_ROLE: "api/inspections/finished-specific-role-search/xls"
	};
	var restClient = demax.inspections.restClient;
	var subscriptions = [];
	var isChairmanSelected = ko.observable(false);
	var isCommissionMemberSelected = ko.observable(false);
	var lastUsedFilters = null;
	var MAX_ALLOWED_INSPECTIONS_COUNT_FOR_EXPORT = 500000;

	this.isLoading = restClient.isLoading;
	this.chairmanInput = ko.observable();
	this.commissionMemberInput = ko.observable();

	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: 20
	});

	this.orgUnits = ko.observableArray([]);
	this.inspectionSpecificSearchFilterOptions = [];
	this.inspectionConclusionOptions = pastel.plus.util.toArray(InspectionConclusion);
	this.inspectionStatusOptions = pastel.plus.util.toArray(InspectionStatusOption);

	this.inspections = ko.observableArray([]);
	this.inspectionsCount = ko.observable(0);

	this.filters = ko.validatedObservable(new FinishedInspectionSearchFilters(), {deep: true});
	this.specificFilters = ko.validatedObservable(new FinishedInspectionSpecificSearchFilters(), {deep: true});
	
	this.isChairmanBeingEdited = ko.observable(false);
	this.isCommissionMemberBeingEdited = ko.observable(false);

	this.init = function(params) {
		self.inspectionSpecificSearchFilterOptions = pastel.plus.util
			.toArray(InspectionSpecificSearchFilter.getByUserRoles(demax.inspections.authenticatedUser().roles));

		loadOrgUnits().done(function() {
			!$.isEmptyObject(params) ? applyParams(params) : restoreMemento();
			
			subscriptions.push(self.pagination.queryParamsObject.subscribe(function() {
				if (lastUsedFilters.selectedSpecificSearchFilter === undefined) {
					self.filters(new FinishedInspectionSearchFilters(lastUsedFilters));
					loadInspections(self.filters().toQueryParams(), URL.FINISHED_INSPECTIONS);
				} else {
					self.specificFilters(new FinishedInspectionSpecificSearchFilters(lastUsedFilters));
					loadInspections(self.specificFilters().toQueryParams(), getRequestUrl(lastUsedFilters));
				}
			}));
			if (lastUsedFilters.input) {
				doPerformSpecificInspectionsSearch();
			} else {
				loadInspections(self.filters().toQueryParams(), URL.FINISHED_INSPECTIONS);
			}

		});

		subscriptions.push(self.chairmanInput.subscribe(function(newValue) {
			if (typeof(newValue) != "string" || newValue.trim().length < 1) {
				self.filters().chairman(null);
			}
			isChairmanSelected(false);
		}));
		subscriptions.push(self.commissionMemberInput.subscribe(function(newValue) {
			if (typeof(newValue) != "string" || newValue.trim().length < 1) {
				self.filters().commissionMember(null);
			}
			isCommissionMemberSelected(false);
		}));
	};

	this.downloadVideo = function(data) {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_VIDEO_BY_ID,
			data.protocolNumber);
		demax.inspections.blobClient.downloadBlob(url).fail(
			function() {
				demax.inspections.popupManager.error("Проблем със свалянето на видеото!");
			}).always(function() {
		});
	};

	this.performNewSearch = function() {
		if (!self.filters.isValid()) {
			self.filters.errors.showAllMessages();
			return;
		}
		lastUsedFilters = self.filters().copyProperties();
		self.specificFilters(new FinishedInspectionSpecificSearchFilters());
		if (self.pagination.page() == 1) {
			loadInspections(self.filters().toQueryParams(), URL.FINISHED_INSPECTIONS);
		} else {
			self.pagination.page(1);
		}
	};

	this.performNewSpecificSearch = function() {
		if (!self.specificFilters.isValid()) {
			self.specificFilters.errors.showAllMessages();
			return;
		}
		lastUsedFilters = self.specificFilters().copyProperties();
		self.filters(new FinishedInspectionSearchFilters(0));
		if (self.pagination.page() == 1) {
			doPerformSpecificInspectionsSearch();
		} else {
			self.pagination.page(1);
		}
	};

	this.clear = function() {
		self.filters(new FinishedInspectionSearchFilters());
		self.chairmanInput(null);
		self.commissionMemberInput(null);
		lastUsedFilters = null;
	};

	this.clearSpecificFilters = function() {
		self.specificFilters(new FinishedInspectionSpecificSearchFilters());
		lastUsedFilters = null;
	};
	
	this.exportExcel = function() {
		if (self.inspectionsCount() > MAX_ALLOWED_INSPECTIONS_COUNT_FOR_EXPORT) {
			demax.inspections.popupManager.error("Максималния брой на технически прегледи за експорт е " 
					+ MAX_ALLOWED_INSPECTIONS_COUNT_FOR_EXPORT);
			return;
		}
		var url = "";
		var queryParams = {};
		
		if (lastUsedFilters.selectedSpecificSearchFilter != undefined) {
			var selectedSpecificFilter = self.specificFilters().selectedSpecificSearchFilter();
			if (selectedSpecificFilter.code == InspectionSpecificSearchFilter.OWNER_IDENTITY_NUMBER.code
				|| selectedSpecificFilter.code == InspectionSpecificSearchFilter.INSPECTION_PERSON_EGN.code) {
				url = URL.EXPORT_FINISHED_INSPECTIONS_SPECIFIC_ROLE;
			} else {
				url = URL.EXPORT_FINISHED_INSPECTIONS_SPECIFIC;
			}
			queryParams = self.specificFilters().toQueryParams();
		} else {
			url = URL.EXPORT_FINISHED_INSPECTIONS;
			queryParams = self.filters().toQueryParams();
		}
		var urlQueryParams = $.param(queryParams, true);

		window.open(url + "?" + urlQueryParams);
	};

	this.loadChairmansByName = function() {
		var deferred = $.Deferred();
		if (isChairmanSelected()) {
			return deferred.reject();
		}
		var queryParams = {
			nameSearch: self.chairmanInput(),
			isChairman: true
		};
		restClient.getResource(URL.PERMIT_INSPECTORS, queryParams)
			.done(function(response) {
				if (response.totalCount < 1) {
					deferred.resolve([]);
				} else {
					var chairmanOptions = ko.utils.arrayMap(response, function(dto) {
						return new demax.inspections.model.techinsp.KtpMemberOption(dto);
					});
					deferred.resolve(chairmanOptions);
				}
			}).fail(function() {
				deferred.reject();
			});
		return deferred;
	};

	this.loadCommissionMembersByName = function() {
		var deferred = $.Deferred();
		if (isCommissionMemberSelected()) {
			return deferred.reject();
		}
		var queryParams = {
			nameSearch: self.commissionMemberInput(),
			isChairman: false
		};
		restClient.getResource(URL.PERMIT_INSPECTORS, queryParams)
			.done(function(response) {
				if (response.totalCount < 1) {
					deferred.resolve([]);
				} else {
					var commissionMemberOptions = ko.utils.arrayMap(response, function(dto) {
						return new demax.inspections.model.techinsp.KtpMemberOption(dto);
					});
					deferred.resolve(commissionMemberOptions);
				}
			}).fail(function() {
				deferred.reject();
			});
		return deferred;
	};

	this.chairmanOptionSelected = function(selectedOption) {
		if (selectedOption) {
			self.isChairmanBeingEdited(true);
			self.chairmanInput(selectedOption.name);
			self.filters().chairman(selectedOption);
			isChairmanSelected(true);
		}
	};

	this.clearChairmanEntryData = ko.computed(function() {
		if (!self.isChairmanBeingEdited() && self.chairmanInput() && !isChairmanSelected()) {
			self.chairmanInput("");
		}
	});

	this.commissionMemberOptionSelected = function(selectedOption) {
		if (selectedOption) {
			self.isCommissionMemberBeingEdited(true);
			self.commissionMemberInput(selectedOption.name);
			self.filters().commissionMember(selectedOption);
			isCommissionMemberSelected(true);
		}
	};

	this.clearCommissionMemberEntryData = ko.computed(function() {
		if (!self.isCommissionMemberBeingEdited() && self.commissionMemberInput() && !isCommissionMemberSelected()) {
			self.commissionMemberInput("");
		}
	});

	function loadInspections(queryParams, url) {
		var pageParams = self.pagination.queryParamsObject();
		var requestParams = $.extend({}, pageParams, queryParams);

		self.inspections([]);
		self.inspectionsCount(0);
		restClient.getResource(url, requestParams)
			. done(function(resp) {
				self.inspections(ko.utils.arrayMap(resp.items, function(itemDto) {
					return new FinishedInspectionListItem(itemDto);
				}));
				self.inspectionsCount(resp.totalCount);
			}).handleErrors({
				NoSuchEntityException: function() {
					demax.inspections.popupManager.error("Разрешение с номер " + self.filters().ktpNum() + " не съществува!");
				}
			});
	}

	function doPerformSpecificInspectionsSearch() {
		var selectedSpecificFilter = self.specificFilters().selectedSpecificSearchFilter();

		var url = URL.FINISHED_INSPECTIONS_SPECIFIC;
		if (selectedSpecificFilter.code == InspectionSpecificSearchFilter.OWNER_IDENTITY_NUMBER.code
			|| selectedSpecificFilter.code == InspectionSpecificSearchFilter.INSPECTION_PERSON_EGN.code) {
			url = URL.FINISHED_INSPECTIONS_SPECIFIC_ROLE;
		}
		loadInspections(self.specificFilters().toQueryParams(), url);
	}

	function loadOrgUnits() {
		return demax.inspections.nomenclature.NomenclatureService.getOrgUnitsWithoutIaaa()
			.done(function(orgUnitDtos) {
				self.orgUnits(ko.utils.arrayMap(orgUnitDtos, function(orgUnitDto) {
					return new demax.inspections.model.OrgUnit(orgUnitDto);
				}));
			});
	}

	function getRequestUrl(lastUsedFilters) {
		switch (lastUsedFilters.selectedSpecificSearchFilter.code) {
			case "OWNER_IDENTITY_NUMBER" : {
				return URL.FINISHED_INSPECTIONS_SPECIFIC_ROLE;
			}
			case "INSPECTION_PERSON_EGN" : {
				return URL.FINISHED_INSPECTIONS_SPECIFIC_ROLE;
			}
			default : {
				return URL.EXPORT_FINISHED_INSPECTIONS_SPECIFIC;
			}
		}
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.ktpNum) {
				self.filters().ktpNum(memento.filterParams.ktpNum);
			}
			if (memento.filterParams.chairman) {
				self.filters().chairman(memento.filterParams.chairman);
			}
			if (memento.filterParams.commissionMember) {
				self.filters().commissionMember(memento.filterParams.commissionMember);
			}
			if (memento.filterParams.dateRange) {
				self.filters().dateRange(memento.filterParams.dateRange);
			}
			if (memento.filterParams.orgUnit) {
				self.filters().orgUnit(self.orgUnits.find("code", memento.filterParams.orgUnit));
			}
			if (memento.filterParams.conclusion) {
				self.filters().conclusion(memento.filterParams.conclusion);
			}
			if (memento.filterParams.isSuspicious) {
				self.filters().isSuspicious(memento.filterParams.isSuspicious);
			}
			if (memento.filterParams.isSemt) {
				self.filters().isSemt(memento.filterParams.isSemt);
			}
			if (memento.filterParams.status) {
				self.filters().status(memento.filterParams.status);
			}
			if (memento.filterParams.input) {
				self.specificFilters().input(memento.filterParams.input);
			}
			if (memento.filterParams.selectedSpecificSearchFilter) {
				self.specificFilters().selectedSpecificSearchFilter(memento.filterParams.selectedSpecificSearchFilter);
			}
		}

		if (memento && memento.filterParams.input) {
			lastUsedFilters = self.specificFilters().copyProperties();
		} else {
			lastUsedFilters = self.filters().copyProperties();
		}
		
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = lastUsedFilters;

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	this.dispose = function() {
		saveMemento();

		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();
	};

	function applyParams(params) {
		var obj = { 
			input: params.vin,
			selectedSpecificSearchFilter: InspectionSpecificSearchFilter.VIN_OR_RAMA
		}; 
		self.specificFilters(new FinishedInspectionSpecificSearchFilters(obj));
		lastUsedFilters = self.specificFilters().copyProperties();
	}
};
