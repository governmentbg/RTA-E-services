namespace("demax.inspections.viewmodel.techinsp");

demax.inspections.viewmodel.techinsp.InProgressInspectionsListVM = function () {
	var self = this;

	var OrgUnit = demax.inspections.model.OrgUnit;
	var InProgressInspectionSearchFilters = demax.inspections.model.techinsp.InProgressInspectionSearchFilters;
	var InProgressInspectionListItem = demax.inspections.model.techinsp.InProgressInspectionListItem;
	var restClient = demax.inspections.restClient;

	var Event = demax.inspections.Event;
	var eventsQueue = demax.inspections.events;
	var URL = {
		IN_PROGRESS_TECHINSP: "api/inspections/inprogress"
	};
	var subscriptions = [];
	var thisNamespace = ".inProgressInspectionsListVm";
	this.isLoading = restClient.isLoading;
	
	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: 20
	});
	
	this.orgUnits = ko.observableArray();
	self.user = demax.inspections.authenticatedUser();

	this.inspections = ko.observableArray([]);
	this.inspectionsCount = ko.observable();

	this.filters = new InProgressInspectionSearchFilters();

	this.init = function () {
		if (self.user.userIsRdaa()) {
			restoreMemento();
			loadInspections();
		} else {
			loadOrgUnits().done(function () {
				restoreMemento();
				loadInspections();
			});
		}
		subscribeToKeyEvents();

		subscriptions.push(self.pagination.queryParamsObject.subscribe(function () {
			self.filters.loadLastUsedFilters();
			loadInspections();
		}));
	};

	this.performNewSearch = function () {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadInspections();
		} else {
			self.pagination.page(1);
		}
	};

	this.refresh = function () {
		self.filters.loadLastUsedFilters();
		loadInspections();
	};

	this.getInspectionLiveStreamHref = function (inspection) {
		return "#/techinsp/inspection/" + inspection.id + "/live-stream";
	};

	function loadInspections() {
		var pageParams = self.pagination.queryParamsObject();
		var searchParams = self.filters.toQueryParams();
		var requestParams = $.extend({}, pageParams, searchParams);

		self.inspections([]);
		self.inspectionsCount(0);
		restClient.getResource(URL.IN_PROGRESS_TECHINSP, requestParams)
			.done(function (resp) {
				self.inspections(ko.utils.arrayMap(resp.items, function (itemDto) {
					return new InProgressInspectionListItem(itemDto);
				}));
				self.inspectionsCount(resp.totalCount);
			});
	}

	function loadOrgUnits() {
		return demax.inspections.nomenclature.NomenclatureService.getOrgUnitsWithoutIaaa()
			.done(function (orgUnitDtos) {
				self.orgUnits(ko.utils.arrayMap(orgUnitDtos, function (orgUnitDto) {
					return new OrgUnit(orgUnitDto);
				}));
			});
	}

	function onEnter() {
		var isLoading = self.isLoading();
		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.ktpNum) {
				self.filters.ktpNum(memento.filterParams.ktpNum);
			}
			if (memento.filterParams.regNum) {
				self.filters.regNum(memento.filterParams.regNum);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(self.orgUnits.find("code", memento.filterParams.orgUnit));
			}
		}
		self.filters.saveLastUsedFilters();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	function subscribeToKeyEvents() {
		eventsQueue.subscribe(Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	}

	function unsubscribeFromKeyEvents() {
		eventsQueue.unsubscribe(Event.KEYPRESS_ENTER + thisNamespace);
	}

	this.dispose = function () {
		saveMemento();

		subscriptions.forEach(function (subscription) {
			subscription.dispose();
		});
		unsubscribeFromKeyEvents();
		restClient.cancelAll();
	};
};
