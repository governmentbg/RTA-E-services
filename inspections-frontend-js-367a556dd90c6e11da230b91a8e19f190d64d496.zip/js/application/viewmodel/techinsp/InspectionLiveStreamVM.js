namespace("demax.inspections.viewmodel.techinsp");

demax.inspections.viewmodel.techinsp.InspectionLiveStreamVM = function() {
	var self = this;

	
	var URL = {
		INSPECTIONS_CONTROLLER_ADDRESS: "api/inspections/",
		CAM_REQUEST_CONTROLLER_ADDRESS: "api/cam-requests/",
		INSPECTION_SECONDARY: "api/inspections/{0}/secondary-inspection",
		INSPECTION_CANCEL_SECONDARY: "api/inspections/{0}/cancel-secondary-inspection",
		PING_LIVE_STREAM_ADDRESS: "api/cam-requests/ping"
	};

	var AsfStreamUtils = demax.inspections.utils.techinsp.AsfStreamUtils;
	var InspectionLiveStreamSetupResponse = demax.inspections.model.techinsp.InspectionLiveStreamSetupResponse;
	var CamRequestStatus = demax.inspections.nomenclature.techinsp.CamRequestStatus;
	var InProgressInspectionListItem = demax.inspections.model.techinsp.InProgressInspectionListItem;
	var user = demax.inspections.authenticatedUser();

	var restClient = demax.inspections.restClient;
	var popupManager = demax.inspections.popupManager;

	var PAGE_BEFORE_UNLOAD_EVENT = "beforeunload";
	var CAM_REQUEST_STATUS_CHECK_INTERVAL = 2500;

	var timeouts = [];
	var informStreamIsNoLongerRequiredWasCalled = false;
	var setupLiveStreamWasCalled = false;

	this.inspectionId = ko.observable(null);
	this.inspection = ko.observable(null);
	this.isInspectionNotFound = ko.observable(false);
	this.liveStreamSetupDetails = ko.observable();
	this.webmStreams = ko.observableArray();
	this.isLoading = restClient.isLoading;
	this.asxFileName = "inspection" + "Stream" + moment(new Date()).format("DDMMYYYY") + ".asx";


	this.init = function(params) {
		demax.inspections.logger("initing InspectionLiveStreamVM");

		window.addEventListener(PAGE_BEFORE_UNLOAD_EVENT, informStreamIsNoLongerRequired);

		self.inspectionId(params.id);

		loadInspection().done(function() {
			setupLiveStreamWasCalled = true;
			setupLiveStream().done(function() {
				trackCamRequestStatusUntilOpen();
			});
		});
	};

	this.isCamRequestOpen = ko.pureComputed(function() {
		var liveStreamSetupDetails = self.liveStreamSetupDetails();
		if (!(liveStreamSetupDetails instanceof InspectionLiveStreamSetupResponse)) {
			return false;
		}

		var camRequest = liveStreamSetupDetails.camRequest;

		return camRequest.status() === CamRequestStatus.OPENED;
	}).extend({
		rateLimit: { timeout: 3500, method: "notifyWhenChangesStop" }
	});

	this.downloadAsxFile = function() {
		AsfStreamUtils.downloadAsxFile(self.liveStreamSetupDetails(), self.asxFileName);
	};

	this.refreshWebmStreams = function () {
		var webmSteamsStash = self.webmStreams();   
		self.webmStreams([]);
		self.webmStreams(webmSteamsStash);
	};

	self.canCreateSecondaryIspection = ko.pureComputed(function () {
		return !self.inspection().hasSecondaryInspection && self.isInspectionInProgress();
	});

	self.canCancelSecondaryIspection = ko.pureComputed(function () {
		return self.inspection().hasSecondaryInspection && self.inspection().secondaryInspection.isActive 
			&& self.isInspectionInProgress();
	});


	self.isInspectionInProgress = ko.pureComputed(function() {
		return self.inspection() 
			&& self.inspection().status === demax.inspections.nomenclature.InspectionStatus.INPROGRESS;
	}); 

	self.canSeeSecondaryInspectionDetailedInfo = ko.pureComputed(function () {
		return user.userHasSecondaryInspectionRole() && self.inspection();
	});

	this.createSecondaryInspection = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_SECONDARY, self.inspectionId());

		demax.inspections.popupManager.confirm({
			message: "Сигурни ли сте, че искате да направите Вторичен Преглед!",
			okButtonText: "Да",
			cancelButtonText: "Не",
			cssClass: "popError",
			okButtonCss: "btn-primary"
		}).done(function () {
			restClient.postResource(url).done(function () {
				loadInspection();
			}).handleErrors({
				InspectionNotInprogressStatusException: function () {
					demax.inspections.popupManager.error("Прегледът е приключил!");
				}
			});
		});

	};

	this.cancelSecondaryInspection = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_CANCEL_SECONDARY, self.inspectionId());

		demax.inspections.popupManager.confirm({
			message: "Сигурни ли сте, че искате да прекратите Вторичен Преглед!",
			okButtonText: "Да",
			cancelButtonText: "Не",
			cssClass: "popError",
			okButtonCss: "btn-primary"
		}).done(function () {
			restClient.patchResource(url).done(function () {
				loadInspection();
			}).handleErrors({
				InspectionNotInprogressStatusException: function () {
					demax.inspections.popupManager.error("Прегледът е приключил!");
				},
				NoSecondaryInspectionForInspectionException: function () {
					demax.inspections.popupManager.error("Няма вторичен преглед за протоколо номер: "
						+ self.inspectionId());
				},
				SecondaryInspectionIsNotActiveException: function () {
					demax.inspections.popupManager.error("Вторичният преглед е прекратен: "
						+ self.inspectionId());
				}
			});
		});
	};

	function trackCamRequestStatusUntilOpen() {
		if (!self.isCamRequestOpen()) {
			refreshCamRequestDetails().always(function() {
				if (!self.isCamRequestOpen()) {
					timeouts.push(setTimeout(trackCamRequestStatusUntilOpen, CAM_REQUEST_STATUS_CHECK_INTERVAL));
				}
			});
		}
	}

	function refreshCamRequestDetails() {
		return restClient.getResource(URL.CAM_REQUEST_CONTROLLER_ADDRESS, self.liveStreamSetupDetails().camRequest.getId())
			.done(function (resp) {
				self.liveStreamSetupDetails().camRequest.status(CamRequestStatus[resp.statusCode]);
			}).handleErrors({
				NoSuchEntityException: function () {
					popupManager.error("Не е намеренa заявката за преглед на камера.");
				}
			});

	}

	function setupLiveStream() {
		return restClient.putResource(URL.INSPECTIONS_CONTROLLER_ADDRESS + self.inspectionId() + "/setup-live-stream").done(function(resp) {
			self.liveStreamSetupDetails(new InspectionLiveStreamSetupResponse(resp));
			pingLiveStream();

			if (!self.liveStreamSetupDetails().isAsf) {
				setWebmStreams(self.liveStreamSetupDetails());
			}
		}).handleErrors({
			NoSuchEntityException: function(message) {
				if (message.indexOf("Inspection") > -1) {
					popupManager.error("Не е намерен техническият преглед.");
				} else if (message.indexOf("ActiveHost") > -1) {
					popupManager.error("Не е намерен активен пункт за избраният преглед. Прегледът е приключен или системата се синхронизира. При синхронизация моля опитайте отново след малко.");
				}
			},
			NoCamerasForActiveHostException: function() {
				popupManager.error("Линията за преглед няма камери.");
			},
			NoIdleCamRequestException: function() {
				popupManager.error("Няма свободни канали за наблюдение на преглед.");
			}
		});
	}

	function setWebmStreams(inspLiveStreamSetup) {
		var restreamAddress = inspLiveStreamSetup.restreamAddress;

		for (var i = 0; i < inspLiveStreamSetup.camRequest.resolution; i++) {
			var webmStream = restreamAddress + "/consume/feed" + inspLiveStreamSetup.camRequest.feedNum + "/" + i;

			self.webmStreams.push(webmStream);
		}
	}

	function informStreamIsNoLongerRequired() {
		if (!setupLiveStreamWasCalled) {
			return;
		}

		if (informStreamIsNoLongerRequiredWasCalled) {
			return;
		}

		var url = "";

		if (self.liveStreamSetupDetails()) {
			url = URL.CAM_REQUEST_CONTROLLER_ADDRESS + "reduce-connections-and-close-if-zero";
			var data = JSON.stringify(self.liveStreamSetupDetails().camRequest.getId());
			restClient.putResource(url, data);
		} else {
			var inspectionId = self.inspectionId();
			if (inspectionId != null) {
				url = URL.CAM_REQUEST_CONTROLLER_ADDRESS + inspectionId + "/reduce-connections-and-close-if-zero";
				restClient.putResource(url);
			}
		}
	}

	function loadInspection() {
		var url = URL.INSPECTIONS_CONTROLLER_ADDRESS + self.inspectionId() + "/light";

		return restClient.getResource(url).done(function(resp) {
			self.inspection(new InProgressInspectionListItem(resp));
		}).handleErrors({
			NoSuchEntityException: function() {
				self.isInspectionNotFound(true);
			}
		});
	}

	function pingLiveStream() {
		var data = JSON.stringify(self.liveStreamSetupDetails().camRequest.getId());
		timeouts.push(
			setTimeout(
				function () {
					restClient.putResource(URL.PING_LIVE_STREAM_ADDRESS, data); 
					pingLiveStream();
				}
				, 10000
			)
		);
	}

	this.dispose = function() {
		restClient.cancelAll();
		window.removeEventListener(PAGE_BEFORE_UNLOAD_EVENT, informStreamIsNoLongerRequired);
		informStreamIsNoLongerRequired();

		timeouts.forEach(function(timeout) {
			clearTimeout(timeout);
		});
	};
};
