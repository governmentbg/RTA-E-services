namespace("demax.inspections.viewmodel.techinsp");

demax.inspections.viewmodel.techinsp.InspectionVM = function () {
	var self = this;
	var restClient = demax.inspections.restClient;
	var KnockoutPropertyUtil = demax.inspections.utils.KnockoutPropertyUtil;
	var nomenclatureService = demax.inspections.nomenclature.NomenclatureService;
	var user = demax.inspections.authenticatedUser();

	var URL = {
		INSPECTION_BY_ID: "api/inspections/{0}",
		INSPECTION_PROTOCOL_PDF: "api/inspections/{0}/protocol/pdf",
		INSPECTION_GAS_PROTOCOL_PDF: "api/inspections/{0}/gas-protocol/pdf",
		INSPECTION_ADR_PROTOCOL_PDF: "api/inspections/{0}/adr-protocol/pdf",
		INSPECTION_CISTERN_PROTOCOL_PDF: "api/inspections/{0}/cistern-protocol/pdf",
		INSPECTION_CERTIFICATE_PDF: "api/inspections/{0}/certificate/pdf",
		INSPECTION_GAS_CERTIFICATE_PDF: "api/inspections/{0}/gas-certificate/pdf",
		INSPECTION_INTERNATIONAL_CERTIFICATE_PDF: "api/inspections/{0}/international-certificate",
		INSPECTION_SEMT_PDF: "api/inspections/{0}/semt/pdf",
		INSPECTION_SEMT: "api/inspections/{0}/semt",
		INSPECTION_SEMT_STATUS_APPROVE: "api/inspections/{0}/semt/approve",
		INSPECTION_SEMT_STATUS_DECLINE: "api/inspections/{0}/semt/decline",
		INSPECTION_SEMT_STATUS_REISSUE: "api/inspections/{0}/semt/reissue",
		INSPECTION_SEMT_REGISTRATION_NUMBER: "api/inspections/{0}/semt/reg-num",
		INSPECTION_SECONDARY: "api/inspections/{0}/secondary-inspection",
		INSPECTION_CANCEL_SECONDARY: "api/inspections/{0}/cancel-secondary-inspection",
		ODOMETER_HISTORY_BY_INSPECTION_ID: "api/inspections/{0}/odometer-history",
		VIDEO_DOWNLOAD_REQUEST: "api/video-download-requests"
	};
	var inspectionId = null;

	this.isLoading = restClient.isLoading;

	this.inspection = ko.observable();
	this.inspectionCopy = ko.observable();
	this.isSemtEdit = ko.observable(false);

	this.ecoCategories = ko.observableArray();
	this.odometerHistory = ko.observableArray();
	this.SemtStatus = demax.inspections.model.techinsp.SemtStatus;
	self.isShowOdometerHistoryPopUpVisible = ko.observable(false);
	this.signaturePopupVm = new demax.inspections.viewmodel.techinsp.InspectionVM.SignaturePopupVM();

	this.init = function (params) {
		inspectionId = params.id;
		loadInspection(inspectionId);
	};

	this.viewSignature = function () {
		self.signaturePopupVm.open(inspectionId);
	};

	this.hideOdometerHistory = function () {
		self.isShowOdometerHistoryPopUpVisible(false);
	};

	this.showOdometerHistory = function () {
		if (self.odometerHistory().length < 1) {
			loadOdometerHistory(inspectionId);
		} else {
			self.isShowOdometerHistoryPopUpVisible(true);
		}
	};

	this.requestFullVideo = function () {
		restClient.postResource(URL.VIDEO_DOWNLOAD_REQUEST + "/" + inspectionId)
			.done(function () {
				demax.inspections.popupManager.success({
					message: "Видеото беше успешно заявено."
				});
			}).handleErrors({
				NoSuchEntityException: function (error) {
					if (error.indexOf("Inspection") >= 0) {
						demax.inspections.popupManager.error("Технически преглед с номер на протокол "
							+ inspectionId + " не съществува!");
					}
				},
				UserHasAlreadyRequestedThisVideoException: function () {
					demax.inspections.popupManager.error("Вече имате направена заявка за пълното видео на технически преглед с протокол "
						+ inspectionId);
				}
			});
	};

	this.openInspectionProtocolPdf = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_PROTOCOL_PDF, inspectionId);
		return demax.inspections.blobClient.openBlob(url).fail(function () {
			demax.inspections.popupManager.error("Възникна грешка при взимане на протокола.");
		});
	};

	this.openInspectionGasProtocolPdf = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_GAS_PROTOCOL_PDF, inspectionId);
		return demax.inspections.blobClient.openBlob(url).fail(function () {
			demax.inspections.popupManager.error("Възникна грешка при взимане на протокола.");
		});
	};

	this.openInspectionCertificatePdf = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_CERTIFICATE_PDF, inspectionId);
		return demax.inspections.blobClient.openBlob(url).fail(function () {
			demax.inspections.popupManager.error("Възникна грешка при взимане на удостоверението.");
		});
	};

	this.openInspectionGasCertificatePdf = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_GAS_CERTIFICATE_PDF, inspectionId);
		return demax.inspections.blobClient.openBlob(url).fail(function () {
			demax.inspections.popupManager.error("Възникна грешка при взимане на удостоверението.");
		});
	};

	this.openInspectionAdrProtocolPdf = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_ADR_PROTOCOL_PDF, inspectionId);
		return demax.inspections.blobClient.openBlob(url).fail(function () {
			demax.inspections.popupManager.error("Възникна грешка при взимане на ADR протокол.");
		});
	};

	this.openInspectionCisternProtocolPdf = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_CISTERN_PROTOCOL_PDF, inspectionId);
		return demax.inspections.blobClient.openBlob(url).fail(function () {
			demax.inspections.popupManager.error("Възникна грешка при взимане на протокол за цистерна.");
		});
	};

	this.openInspectionInternationalCertificatePdf = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_INTERNATIONAL_CERTIFICATE_PDF, inspectionId);
		return demax.inspections.blobClient.openBlob(url).fail(function () {
			demax.inspections.popupManager.error("Възникна грешка при взимане на международния сертификат.");
		});
	};

	this.openSemtPdf = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_SEMT_PDF, inspectionId);
		return demax.inspections.blobClient.openBlob(url).fail(function () {
			demax.inspections.popupManager.error("Възникна грешка при взимане на международния сертификат.");
		});
	};

	this.editSemt = function () {
		self.isSemtEdit(true);
	};

	self.canCreateSecondaryIspection = ko.pureComputed(function () {
		return !self.inspection().hasSecondaryInspection && self.isInspectionInProgress();
	});

	self.canCancelSecondaryIspection = ko.pureComputed(function () {
		return self.inspection().hasSecondaryInspection && self.inspection().secondaryInspection.isActive
			&& self.isInspectionInProgress();
	});

	self.isInspectionInProgress = ko.pureComputed(function () {
		return self.inspection()
			&& self.inspection().status === demax.inspections.nomenclature.InspectionStatus.INPROGRESS;
	});

	self.canSeeShortSecondaryInspectionInfo = ko.pureComputed(function () {
		return user.userIsIaaa() && !user.userHasSecondaryInspectionRole() && self.inspection()
			&& self.inspection().hasSecondaryInspection
			&& self.inspection().status === demax.inspections.nomenclature.InspectionStatus.COMPLETED;
	});

	self.canSeeSecondaryInspectionDetailedInfo = ko.pureComputed(function () {
		return user.userHasSecondaryInspectionRole() && self.inspection();
	});

	self.shouldShowEditSemtButtons = ko.pureComputed(function () {
		return user.userIsIaaa() && self.inspection().semtDetails.status.code !== self.SemtStatus.DECLINED.code;
	});

	self.shouldShowInternationalCertificationButton = ko.pureComputed(function () {
		if (self.inspection()) {
			var typeCode = self.inspection().type.code;
			var category = self.inspection().vehicle.categoryCode;
			var allowedCategory = category != "O1" && category != "O2" ? true : false;
	
			return allowedCategory && (user.userIsIaaa() || user.userIsRdaa) && (typeCode == "VEHICLE" || typeCode == "ADR");
		}
		return false;
	});

	self.shouldDisableEngineFields = ko.pureComputed(function () {
		var category = self.inspection().vehicle.categoryCode;
		return category && category.indexOf("O") > -1;
	});

	self.shouldDisableRegistrationNumberField = ko.pureComputed(function () {
		var code = self.inspection().semtDetails.status.code;
		return code !== self.SemtStatus.APPROVED.code && code !== self.SemtStatus.CHANGED_NUMBER.code;
	});

	this.cancelEditSemt = function () {
		KnockoutPropertyUtil.copyProperties(
			self.inspectionCopy().semtDetails,
			self.inspection().semtDetails,
			[
				"registrationNumber",
				"compilianceNumber",
				"ecoCategory",
				"makeModelLat",
				"engineNumber",
				"engineType"
			]
		);
		self.isSemtEdit(false);
	};

	this.shouldShowRejectOrIssue = ko.pureComputed(function () {
		var current = self.inspection().semtDetails.status.code;
		var allowed = [self.SemtStatus.LATE.code, self.SemtStatus.NEW.code];
		return !self.isSemtEdit() && allowed.indexOf(current) > -1;
	});

	this.isShowOdometerHistoryPopUpButtonVisible = ko.pureComputed(function () {
		return (user.userIsIaaa() || user.userIsCallCenter() || user.userIsControl()
				|| user.userIsRdaa() || user.userIsAdmin());
	});

	this.canRequestFullVideo = ko.pureComputed(function () {
		return (user.userIsIaaa() || user.userIsCallCenter() || user.userIsControl()
				|| user.userIsAdmin());
	});

	this.createSecondaryInspection = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_SECONDARY, inspectionId);

		demax.inspections.popupManager.confirm({
			message: "Сигурни ли сте, че искате да направите Вторичен Преглед!",
			okButtonText: "Да",
			cancelButtonText: "Не",
			cssClass: "popError",
			okButtonCss: "btn-primary"
		}).done(function () {
			restClient.postResource(url).done(function () {
				loadInspection(inspectionId);
			}).handleErrors({
				InspectionNotInprogressStatusException: function () {
					demax.inspections.popupManager.error("Прегледът е приключил!");
				}
			});
		});

	};

	this.cancelSecondaryInspection = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_CANCEL_SECONDARY, inspectionId);

		demax.inspections.popupManager.confirm({
			message: "Сигурни ли сте, че искате да прекратите Вторичен Преглед!",
			okButtonText: "Да",
			cancelButtonText: "Не",
			cssClass: "popError",
			okButtonCss: "btn-primary"
		}).done(function () {
			restClient.patchResource(url).done(function () {
				loadInspection(inspectionId);
			}).handleErrors({
				InspectionNotInprogressStatusException: function () {
					demax.inspections.popupManager.error("Прегледът е приключил!");
				},
				NoSecondaryInspectionForInspectionException: function () {
					demax.inspections.popupManager.error("Няма вторичен преглед за протоколо номер: "
						+ inspectionId);
				},
				SecondaryInspectionIsNotActiveException: function () {
					demax.inspections.popupManager.error("Вторичният преглед е прекратен: "
						+ inspectionId);
				}
			});
		});
	};

	this.declineSemt = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_SEMT_STATUS_DECLINE, inspectionId);

		return restClient.patchResource(url).done(function () {
			loadInspection(inspectionId);
			self.isSemtEdit(false);
		}).handleErrors({
			MissingSemtCertificateException: function () {
				demax.inspections.popupManager.error("Лиспва СЕМТ/ЕКМТ сертификат за технически преглед с номер на протокол "
					+ inspectionId);
			},
			InvalidSemtCertificateStatusException: function () {
				demax.inspections.popupManager.error("Невалиден статус на СЕМТ/ЕКМТ сертификат за технически преглед с номер на протокол "
					+ inspectionId);
			}
		});
	};

	this.issueSemt = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_SEMT_STATUS_APPROVE, inspectionId);

		return restClient.patchResource(url).done(function () {
			loadInspection(inspectionId);
			self.isSemtEdit(false);
		}).handleErrors({
			CannotEditOldInspectionSemtException: function () {
				demax.inspections.popupManager.warn("Не може да редактирате СЕМТ към преглед, понеже има по-нов преглед в системата!");
			},
			MissingSemtCertificateException: function () {
				demax.inspections.popupManager.error("Лиспва СЕМТ/ЕКМТ сертификат за технически преглед с номер на протокол "
					+ inspectionId);
			},
			InvalidSemtCertificateStatusException: function () {
				demax.inspections.popupManager.error("Невалиден статус на СЕМТ/ЕКМТ сертификат за технически преглед с номер на протокол "
					+ inspectionId);
			}
		});
	};

	this.reissueSemt = function () {
		var url = pastel.util.StringHelper.format(URL.INSPECTION_SEMT_STATUS_REISSUE, inspectionId);


		demax.inspections.popupManager.confirm({
			message: "Сигурни ли сте, че искате да отпечатате ново СЕМТ сертификат!",
			okButtonText: "Да",
			cancelButtonText: "Не",
			cssClass: "popError",
			okButtonCss: "btn-primary"
		}).done(function () {
			restClient.patchResource(url).done(function () {
				loadInspection(inspectionId);
			}).handleErrors({
				CannotEditOldInspectionSemtException: function () {
					demax.inspections.popupManager.warn("Не може да редактирате СЕМТ към преглед, понеже има по-нов преглед в системата!");
				},
				MissingSemtCertificateException: function () {
					demax.inspections.popupManager.error("Лиспва СЕМТ/ЕКМТ сертификат за технически преглед с номер на протокол "
						+ inspectionId);
				},
				InvalidSemtCertificateStatusException: function () {
					demax.inspections.popupManager.error("Невалиден статус на СЕМТ/ЕКМТ сертификат за технически преглед с номер на протокол "
						+ inspectionId);
				},
				SemtPrintAlreadyExistsException: function () {
					demax.inspections.popupManager.error("Вече е направен нов дубликат днес.");
				}
			});
		});
	};

	function changeRegistrationNumber() {
		var validationErrors = ko.validation.group([self.inspection().semtDetails.registrationNumber]);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			return;
		}
		var url = pastel.util.StringHelper.format(URL.INSPECTION_SEMT_REGISTRATION_NUMBER, inspectionId);

		var regNum = {
			registrationNumber: self.inspection().semtDetails.registrationNumber()
		};
		restClient.patchResource(url, JSON.stringify(regNum)).done(function () {
			loadInspection(inspectionId);
			self.isSemtEdit(false);
		}).handleErrors({
			CannotEditOldInspectionSemtException: function () {
				demax.inspections.popupManager.warn("Не може да редактирате СЕМТ към преглед, понеже има по-нов преглед в системата!");
			},
			InvalidSemtCertificateStatusException: function () {
				demax.inspections.popupManager.warn("Възникна грешка при промяна на регистрационен номер!");
			}
		});
	}


	this.isInspectionUnderUserControl = function () {
		return demax.inspections.utils.UserUtils.canViewInspectionDetails(self.inspection().permit.orgUnit);
	};


	function updateAllFields() {
		var semt = self.inspection().semtDetails;
		var arr = [semt.compilianceNumber, semt.ecoCategory, semt.makeModelLat];
		if (!self.shouldDisableEngineFields()) {
			arr.push([semt.engineNumber, semt.engineType]);
		}
		var validationErrors = ko.validation.group(arr);
		if (ko.unwrap(validationErrors()).length > 0) {
			validationErrors.showAllMessages();
			return;
		}
		var params = self.inspection().semtDetails.toQueryParams();

		var url = pastel.util.StringHelper.format(URL.INSPECTION_SEMT, inspectionId);
		restClient.putResource(url, JSON.stringify(params)).done(function () {
			loadInspection(inspectionId);
			self.isSemtEdit(false);
		}).handleErrors({
			CannotEditOldInspectionSemtException: function () {
				demax.inspections.popupManager.warn("Не може да редактирате СЕМТ към преглед, понеже има по-нов преглед в системата!");
			},
			MissingSemtCertificateException: function () {
				demax.inspections.popupManager.warn("Към прегледът не е намерен СЕМТ!");
			},
			InvalidSemtCertificateStatusException: function () {
				demax.inspections.popupManager.warn("Невалиден статус на СЕМТ!");
			},
			InvalidSemtEngineException: function () {
				demax.inspections.popupManager.warn("Невалидни данни за двигател на СЕМТ!");
			}

		});

	}

	this.saveSemt = function () {
		if (self.inspection().semtDetails.status.code === self.SemtStatus.NEW.code 
			|| self.inspection().semtDetails.status.code === self.SemtStatus.LATE.code) {
			updateAllFields();
		} else {
			changeRegistrationNumber();
		}

	};

	function loadInspection(inspectionId) {
		return restClient.getResource(pastel.util.StringHelper.format(URL.INSPECTION_BY_ID, inspectionId))
			.done(function (inspectionDto) {
				self.inspection(new demax.inspections.model.techinsp.Inspection(inspectionDto));
				self.inspectionCopy(new demax.inspections.model.techinsp.Inspection(inspectionDto));
				loadEcoCategories();
			});
	}

	function loadEcoCategories() {
		if (self.inspection().hasSemt) {
			nomenclatureService.getEcoCategories().done(function (ecoCategories) {
				self.ecoCategories(ko.utils.arrayMap(ecoCategories, function (category) {
					return new demax.inspections.model.EcoCategory(category);
				}));
			});
		}
	}

	function loadOdometerHistory(id) {
		return restClient.getResource(pastel.util.StringHelper.format(URL.ODOMETER_HISTORY_BY_INSPECTION_ID, id))
			.done(function (odometerHistory) {
				self.odometerHistory(ko.utils.arrayMap(odometerHistory, function (item) {
					return new demax.inspections.model.techinsp.OdometerHistory(item);
				}));
				self.isShowOdometerHistoryPopUpVisible(true);
			}).handleErrors({
				NoAuthorityException: function () {
					demax.inspections.popupManager.error("Прегледът има невалиден статус!");
				}
			});
	}

	self.searchByVin = function (vinInput) {
		demax.inspections.router.setHash("techinsp/finished-inspections-list", { vin: vinInput });
	};
};

demax.inspections.viewmodel.techinsp.InspectionVM.SignaturePopupVM = function () {
	var self = this;

	var URL = {
		INSPECTION_SIGNATURE: "api/inspections/{0}/signature"
	};

	this.signature = ko.observable();
	this.errorText = ko.observable();
	this.isVisible = ko.observable(false);
	this.isLoading = ko.observable(false).extend({
		rateLimit: {
			timeout: 250,
			method: "notifyWhenChangesStop"
		}
	});

	this.open = function (inspectionId) {
		reset();
		loadSignature(inspectionId);
		self.isVisible(true);
	};

	this.close = function () {
		self.isVisible(false);
	};

	function reset() {
		self.signature(null);
		self.errorText(null);
	}

	function loadSignature(inspectionId) {
		self.isLoading(true);
		return demax.inspections.restClient.getResource(pastel.util.StringHelper.format(URL.INSPECTION_SIGNATURE, inspectionId))
			.done(function (signatureDto) {
				self.signature(signatureDto.sha1);
			}).handleErrors({
				InspectionSignatureNotFoundException: function () {
					self.errorText("Не е намерена сигнатура.");
				}
			}).always(function () {
				self.isLoading(false);
			});
	}
};