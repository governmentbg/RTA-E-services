namespace("demax.inspections.viewmodel.techinsp");

demax.inspections.viewmodel.techinsp.OnlineComputersListVM = function() {
	var self = this;
	var URL = {
		ONLINE_COMPUTERS: "api/active-computers"
	};

	var thisNamespace = ".onlineComputersListVm";

	var OnlineComputersSearchFilters = demax.inspections.model.techinsp.OnlineComputersSearchFilters;
	var subscriptions = [];
	var restClient = demax.inspections.restClient;

	var Event = demax.inspections.Event;
	var eventsQueue = demax.inspections.events;

	this.isLoading = ko.observable(false).extend({
		rateLimit: { timeout: 250, method: "notifyWhenChangesStop" }
	});

	this.orgUnits = ko.observableArray();

	this.onlineComputers = ko.observableArray();
	this.filters = new OnlineComputersSearchFilters();

	this.init = function() {
		loadOrgUnits().done(function() {
			restoreMemento();
			loadOnlineComputers();
		});
		subscribeToKeyEvents();
	};

	this.performNewSearch = function() {
		self.filters.saveLastUsedFilters();
		loadOnlineComputers();
	};
	
	this.refresh = function() {
		self.filters.loadLastUsedFilters();
		loadOnlineComputers();
	};

	this.openInspectionStatuinConfig = function(onlineComputer) {
		if (onlineComputer) {
			demax.inspections.popupManager.info("Моля, направете си тунел към IP: " + onlineComputer.ipAddress
				+ ", за да можете да се свържете към сервизното меню.")
				.done(function() {
					window.open(onlineComputer.serviceMenuUrl);
				});
		}
	};

	function onEnter() {
		var isLoading = self.isLoading();
		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function saveMemento() {
		var filterParams = self.filters.getLastUsedFilters();
	
		var memento = {
			filterParams: filterParams
		};

		self.constructor.memento = memento;
	}

	function restoreMemento() {
		var memento = self.constructor.memento;

		if (memento !== undefined) {
			if (memento.filterParams.permitNumber) {
				self.filters.permitNumber(memento.filterParams.permitNumber);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(self.orgUnits.find("code", memento.filterParams.orgUnit));
			}
		}
	}

	function loadOrgUnits() {
		return demax.inspections.nomenclature.NomenclatureService.getOrgUnitsWithoutIaaa()
			.done(function(response) {
				self.orgUnits(ko.utils.arrayMap(response, function(orgUnitDto) {
					return new demax.inspections.model.OrgUnit(orgUnitDto);
				}));
			});
	}

	function loadOnlineComputers() {
		var requestParams = self.filters.toQueryParams();

		return restClient.getResource(URL.ONLINE_COMPUTERS, requestParams)
			.done(function(response) {
				self.onlineComputers(ko.utils.arrayMap(response, function(itemDto) {
					return new demax.inspections.model.techinsp.OnlineComputer(itemDto);
				}));
			});
	}

	function subscribeToKeyEvents() {
		eventsQueue.subscribe(Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	}

	function unsubscribeFromKeyEvents() {
		eventsQueue.unsubscribe(Event.KEYPRESS_ENTER + thisNamespace);
	}
	
	this.dispose = function() {
		$.each(subscriptions, function(i, subscription) {
			subscription.dispose();
		});
		saveMemento();
		unsubscribeFromKeyEvents();
		restClient.cancelAll();
	};

};
