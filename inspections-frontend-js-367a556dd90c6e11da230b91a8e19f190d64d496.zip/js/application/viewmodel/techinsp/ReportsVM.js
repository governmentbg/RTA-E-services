namespace("demax.inspections.viewmodel.techinsp");

demax.inspections.viewmodel.techinsp.ReportsVM = function() {
	var self = this;
	var subscriptions = [];
	var restClient = demax.inspections.restClient;
	var blobClient = demax.inspections.blobClient;

	var Pagination = pastel.plus.component.pagination.Pagination;
	var OrgUnit = demax.inspections.model.OrgUnit;
	var SemtStatus = demax.inspections.model.techinsp.SemtStatus;
	var InspectionConclusion = demax.inspections.nomenclature.techinsp.InspectionConclusion;
	var InspectionReportCompareOption = demax.inspections.nomenclature.techinsp.InspectionReportCompareOption;
	var InspectionReportSearchFilters = demax.inspections.model.techinsp.InspectionReportSearchFilters;
	var InspectionTypesCountReport = demax.inspections.model.techinsp.InspectionTypesCountReport;
	var InspectionReportIssuesCountListItem = demax.inspections.model.techinsp.InspectionReportIssuesCountListItem;
	var VehicleInspectionsCountReportListItem = demax.inspections.model.techinsp.VehicleInspectionsCountReportListItem;
	var InspectionUnusedStickersReport = demax.inspections.model.techinsp.InspectionUnusedStickersReport;
	var IssuedSemtReportListItem = demax.inspections.model.techinsp.IssuedSemtReportListItem;

	var EcoCategoryLightReport = demax.inspections.nomenclature.techinsp.EcoCategoryLightReport;
	var PublishedByReport = demax.inspections.nomenclature.techinsp.PublishedByReport;

	this.ecoCategoriesOptions = EcoCategoryLightReport.ALL;
	this.publishedByOptions = PublishedByReport.ALL;
	this.semtStatuses = SemtStatus.ALL;
	
	var thisNamespace = ".reportsVm";

	var Event = demax.inspections.Event;
	var eventsQueue = demax.inspections.events;


	var URL = {
		INSPECTIONS_REPORTS: "api/inspections/reports",
		INSPECTION_TYPE_COUNT_BY_KTP_NUMBER_REPORT_XLS: "api/inspections/reports/types-count-by-ktp-number/xls",
		INSPECTION_TYPE_COUNT_BY_KTP_NUMBER_EXTENDED_REPORT_XLS: "api/inspections/reports/types-count-by-ktp-number-extended/xls",
		INSPECTION_TYPES_COUNT_REPORT_XLS: "api/inspections/reports/types-count/xls",
		INSPECTION_TYPES_COUNT_BY_KTP_REPORT_XLS: "api/inspections/reports/types-count-by-ktp/xls",
		ISSUED_SEMTS_REPORT_XLS: "api/inspections/reports/issued-semts/xls",
		INSPECTION_ORDERS_UNUSED_STICKERS_REPORT: "api/inspections/reports/unused-stickers-report",
		ISSUES_COUNT_REPORT_XLS: "api/inspections/reports/issues-count/xls",
		VEHICLE_INSPECTION_COUNT_REPORT: "api/inspections/reports/vehicle-inspections-count/xls"
	};

	this.filters = ko.validatedObservable(null, {deep: true});
	this.orgUnits = new ko.observableArray();
	this.vehicleCategoryCodes = ko.observableArray();
	this.inspectionConclusionOptions = pastel.plus.util.toArray(InspectionConclusion);
	this.inspectionReportCompareOptions = pastel.plus.util.toArray(InspectionReportCompareOption);
	this.reportItems = ko.observable(null);
	this.selectedReportType = ko.observable();

	this.isLoading = restClient.isLoading;
	this.isDelaying = ko.observable(false);

	this.pagination = new Pagination({
		page: 1,
		pageSize: 20
	});

	this.init = function() {
		loadOrgUnits();
		loadVehicleCategoryCodes();
		subscribeToKeyEvents();

		subscriptions.push(self.selectedReportType.subscribe(function(newValue) {
			self.reportItems(null);
			self.filters(new InspectionReportSearchFilters(newValue));
			if (newValue == "unused-stickers") {
				self.filters().dateRange(null);
			}
		}));
	};

	this.clear = function() {
		self.filters(new InspectionReportSearchFilters(self.selectedReportType()));
		self.reportItems(null);
	};

	this.generateReport = function() {
		if (!self.filters.isValid()) {
			self.filters.errors.showAllMessages();
			return;
		}
		delay();
		self.pagination.page(1);

		switch (self.selectedReportType()) {
			case "types-count-by-ktp-number":
				{
					self.reportItems(new InspectionTypesCountReport());
					self.filters().setTypesCountByKtpNumberReportDescription();
					restClient.getResource(URL.INSPECTIONS_REPORTS + "/types-count-by-ktp-number", self.filters().toQueryParams())
						.done(function(response) {
							self.reportItems(new InspectionTypesCountReport(response));
						}).handleErrors({
							InvalidInspectionReportArgumentsException: function() {
								demax.inspections.popupManager.error("Невалидни данни за заявката!");
								self.reportItems(null);
							}
						});
				}
				break;
			case "types-count":
				{
					self.reportItems(new InspectionTypesCountReport());
					self.filters().setTypesCountReportDescription();
					restClient.getResource(URL.INSPECTIONS_REPORTS + "/types-count", self.filters().toQueryParams())
						.done(function(response) {
							self.reportItems(new InspectionTypesCountReport(response));
						}).handleErrors({
							InvalidInspectionReportArgumentsException: function() {
								demax.inspections.popupManager.error("Невалидни данни за заявката!");
								self.reportItems(null);
							}
						});
				}
				break;

			case "issues-count" :
				{
					self.reportItems([]);
					self.filters().setIssuesCountReportDescription();
					restClient.getResource(URL.INSPECTIONS_REPORTS + "/issues-count", self.filters().toQueryParams())
						.done(function(response) {
							self.reportItems(ko.utils.arrayMap(response, function(itemDto) {
								return new InspectionReportIssuesCountListItem(itemDto);
							}));
						}).handleErrors({
							NoSuchEntityException: function() {
								demax.inspections.popupManager.error("КТП с номер " + self.filters().ktpNumber() + " не съществува!");
								self.reportItems(null);
							},
							InvalidInspectionReportArgumentsException: function() {
								demax.inspections.popupManager.error("Невалидни данни за заявката!");
								self.reportItems(null);
							}
						});
				}
				break;

			case "passed-after-issues-count" :
				{
					self.reportItems([]);
					self.filters().setPassedAfterIssuesCountReportDescription();
					restClient.getResource(URL.INSPECTIONS_REPORTS + "/passed-after-issues-count", self.filters().toQueryParams())
						.done(function(response) {
							self.reportItems(response);
						}).handleErrors({
							InvalidInspectionReportArgumentsException: function() {
								demax.inspections.popupManager.error("Невалидни данни за заявката!");
								self.reportItems(null);
							}
						});
				}
				break;

			case "vehicle-inspections-count" :
				{
					self.reportItems([]);
					self.filters().setVehicleInspectionsCountReportDescription();
					restClient.getResource(URL.INSPECTIONS_REPORTS + "/vehicle-inspections-count", self.filters().toQueryParams())
						.done(function(response) {
							self.reportItems(ko.utils.arrayMap(response, function(itemDto) {
								return new VehicleInspectionsCountReportListItem(itemDto);
							}));
						}).handleErrors({
							NoSuchEntityException: function() {
								demax.inspections.popupManager.error("КТП с номер " + self.filters().ktpNumber() + " не съществува!");
								self.reportItems(null);
							},
							InvalidInspectionReportArgumentsException: function() {
								demax.inspections.popupManager.error("Невалидни данни за заявката!");
								self.reportItems(null);
							}
						});
				}
				break;
			case "unused-stickers" :
				{	
					self.reportItems([]);
					self.filters().setUnusedStickersReportDescription();
					restClient.getResource(URL.INSPECTION_ORDERS_UNUSED_STICKERS_REPORT, self.filters().toQueryParams())
						.done(function(response) {
							self.reportItems(new InspectionUnusedStickersReport(response));
						}).handleErrors({
							NoSuchEntityException: function() {
								demax.inspections.popupManager.error("КТП с номер " + self.filters().ktpNumber() + " не съществува!");
								self.reportItems(null);
							}
						});
				}
				break;
			case "issued-semts-count" :
				{
					self.reportItems([]);
					self.filters().setIssuedSemtsReportDescription();
					restClient.getResource(URL.INSPECTIONS_REPORTS + "/issued-semt-count", self.filters().toQueryParams())
						.done(function(response) {
							self.reportItems(ko.utils.arrayMap(response, function(itemDto) {
								return new IssuedSemtReportListItem(itemDto);
							}));
						}).handleErrors({
							InvalidInspectionReportArgumentsException: function() {
								demax.inspections.popupManager.error("Невалидни данни за заявката!");
								self.reportItems(null);
							},
							InvalidSemtCertificateStatusException: function() {
								demax.inspections.popupManager.error("Невалидни данни за заявката!");
								self.reportItems(null);
							}
						});
				}
				break;
		}
	};

	this.exportReportXls = function(reportUrl) {
		var reportData = {
			title: self.filters().getReportTitle(),
			rows: getReportRows(self.reportItems(), reportUrl)
		};
		var url = URL.INSPECTIONS_REPORTS + "/" + reportUrl;
		var options = {
			method: "POST",
			data: reportData
		};
		demax.inspections.utils.DocumentUtil.downloadDocument(url, options);
	};

	this.exportIssuedSemtsReportXls = function() {
		self.exportExcel(URL.ISSUED_SEMTS_REPORT_XLS, self.filters().toQueryParams(), self.filters().getReportTitle());
	};

	this.exportTypeCountByKtpNumberReportXls = function() {
		self.exportExcel(URL.INSPECTION_TYPE_COUNT_BY_KTP_NUMBER_REPORT_XLS, self.filters().toQueryParams(), self.filters().getReportTitle());
	};

	this.exportTypeCountByKtpNumberExtendedReportXls = function() {
		self.exportExcel(URL.INSPECTION_TYPE_COUNT_BY_KTP_NUMBER_EXTENDED_REPORT_XLS, self.filters().toQueryParams(), self.filters().getReportTitle());
	};

	this.exportTypesCountReportXls = function() {
		self.exportExcel(URL.INSPECTION_TYPES_COUNT_REPORT_XLS, self.filters().toQueryParams(), self.filters().getReportTitle());
	};

	this.exportTypesCountByKtpReportXls = function() {
		self.exportExcel(URL.INSPECTION_TYPES_COUNT_BY_KTP_REPORT_XLS, self.filters().toQueryParams(), self.filters().getReportTitle());
	};

	this.exportIssuesCountReportXls = function() {
		self.exportExcel(URL.ISSUES_COUNT_REPORT_XLS, self.filters().toQueryParams(), self.filters().getReportTitle());
	};

	this.exportVehicleInspectionCountReportXls = function() {
		self.exportExcel(URL.VEHICLE_INSPECTION_COUNT_REPORT, self.filters().toQueryParams(), self.filters().getReportTitle());
	};

	this.exportExcel = function(url, params, title) {
		var queryParams = ko.unwrap(params);
		var urlQueryParams = $.param(queryParams);
		var titleAndDescription = "&title=" + title;
		blobClient.downloadBlob(url + "?" + urlQueryParams+titleAndDescription);
	};

	function onEnter() {
		var isLoading = self.isLoading();
		if (isLoading) {
			return;
		}

		self.generateReport();
	}

	function getReportRows(reportItems, url) {
		var items = null;
		if (url == "types-count-by-ktp/xls") {
			items = reportItems.typesCountByKtpItems();
		} else if (url == "types-count/xls") {
			items = reportItems.typesCountItems();
		} else {
			items = reportItems;
		}
		return ko.utils.arrayMap(items, function(item) {
			return item.toReportRow();
		});
	}

	function delay() {
		self.isDelaying(true);
		setTimeout(function() {
			self.isDelaying(false);
		}, 450);
	}

	function loadOrgUnits() {
		demax.inspections.nomenclature.NomenclatureService.getOrgUnitsWithoutIaaa()
			.done(function(response) {
				self.orgUnits(ko.utils.arrayMap(response, function(orgUnitDto) {
					return new OrgUnit(orgUnitDto);
				}));
			});
	}

	function loadVehicleCategoryCodes() {
		demax.inspections.nomenclature.NomenclatureService.getAllVehicleCategoryCodes()
			.done(function (categoryCodes) {
				categoryCodes.forEach(function (code) {
					self.vehicleCategoryCodes.push(code);
				});
			});
	}

	function subscribeToKeyEvents() {
		eventsQueue.subscribe(Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	}

	function unsubscribeFromKeyEvents() {
		eventsQueue.unsubscribe(Event.KEYPRESS_ENTER + thisNamespace);
	}

	this.dispose = function() {
		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		unsubscribeFromKeyEvents();
		restClient.cancelAll();
	};
};
