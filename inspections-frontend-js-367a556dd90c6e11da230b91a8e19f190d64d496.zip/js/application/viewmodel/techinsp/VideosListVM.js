namespace("demax.inspections.viewmodel.techinsp");

demax.inspections.viewmodel.techinsp.VideosListVM = function() {
	var self = this;

	var OrgUnit = demax.inspections.model.OrgUnit;
	var VideoDownloadRequestSearchFilters = demax.inspections.model.techinsp.VideoDownloadRequestSearchFilters;
	var VideoDownloadRequestListItem = demax.inspections.model.techinsp.VideoDownloadRequestListItem;
	var VideoDownloadRequestStatus = demax.inspections.nomenclature.techinsp.VideoDownloadRequestStatus;
	var restClient = demax.inspections.restClient;
	var subscriptions = [];

	var Event = demax.inspections.Event;
	var eventsQueue = demax.inspections.events;

	var Pagination = pastel.plus.component.pagination.Pagination;
	var URL = {
		VIDEO_DOWNLOAD_REQUEST: "api/video-download-requests"
	};

	var thisNamespace = ".videosListVm";

	this.isLoading = restClient.isLoading;
	this.isRequestingVideo = ko.observable(false);

	this.pagination = new Pagination({
		page: 1,
		pageSize: 20
	});

	this.orgUnits = ko.observableArray();
	this.statuses = VideoDownloadRequestStatus.ALL_WITHOUT_DELETED;

	this.protocolNumberForRequesting = ko.observable("").extend({
		number: true
	});
	this.videoRequests = ko.observableArray([]);
	this.videoRequestsCount = ko.observable();

	this.filters = new VideoDownloadRequestSearchFilters();

	this.init = function() {
		loadOrgUnits().done(function() {
			restoreMemento();
			loadVideoDownloadRequests();
		});
		subscribeToKeyEvents();

		subscriptions.push(self.pagination.queryParamsObject.subscribe(function() {
			self.filters.loadLastUsedFilters();
			loadVideoDownloadRequests();
		}));
	};

	this.performNewSearch = function() {
		self.filters.saveLastUsedFilters();
		if (self.pagination.page() == 1) {
			loadVideoDownloadRequests();
		} else {
			self.pagination.page(1);
		}
	};
	
	this.refresh = function() {
		self.filters.loadLastUsedFilters();
		loadVideoDownloadRequests();
	};

	this.downloadVideo = function(data) {
		if (!data.isDownloading()) {
			var url = URL.VIDEO_DOWNLOAD_REQUEST + "/" + data.protocolNumber
					+ "/zip";
			data.isDownloading(true);
			demax.inspections.blobClient.downloadBlob(url).fail(
				function() {
					demax.inspections.popupManager
						.error("Проблем със свалянето на видеото!");
				}).always(function() {
				data.isDownloading(false);
			});
		}
	};
	
	this.requestFullVideo = function() {
		if (!self.protocolNumberForRequesting()) {
			return;
		}
		self.isRequestingVideo(true);
		restClient.postResource(URL.VIDEO_DOWNLOAD_REQUEST + "/" + self.protocolNumberForRequesting())
			.done(function() {
				self.performNewSearch();
			}).handleErrors({
				NoSuchEntityException: function(error) {
					if (error.indexOf("Inspection") >= 0) {
						demax.inspections.popupManager.error("Технически преглед с номер на протокол "
								+ self.protocolNumberForRequesting() + " не съществува!");
					}
				},
				UserHasAlreadyRequestedThisVideoException: function() {
					demax.inspections.popupManager.error("Вече имате направена заявка за пълното видео на технически преглед с протокол "
							+ self.protocolNumberForRequesting());
				}
			}).always(function() {
				self.isRequestingVideo(false);
			});
	};

	function loadVideoDownloadRequests() {
		var pageParams = self.pagination.queryParamsObject();
		var searchParams = self.filters.toQueryParams();
		var requestParams = $.extend({}, pageParams, searchParams);
		
		self.videoRequests([]);
		self.videoRequestsCount(0);

		restClient.getResource(URL.VIDEO_DOWNLOAD_REQUEST, requestParams)
			.done(function(response) {
				self.videoRequests(ko.utils.arrayMap(response.items, function(itemDto) {
					return new VideoDownloadRequestListItem(itemDto);
				}));
				self.videoRequestsCount(response.totalCount);
			});
	}

	function loadOrgUnits() {
		return demax.inspections.nomenclature.NomenclatureService.getOrgUnitsWithoutIaaa()
			.done(function(response) {
				self.orgUnits(ko.utils.arrayMap(response, function(orgUnitDto) {
					return new OrgUnit(orgUnitDto);
				}));
			});
	}

	function onEnter() {
		var isLoading = self.isLoading();
		if (isLoading) {
			return;
		}

		self.performNewSearch();
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			if (memento.pageParams) {
				self.pagination.page(memento.pageParams.page);
				self.pagination.pageSize(memento.pageParams.pageSize);
			}
			if (memento.filterParams.ktpNum) {
				self.filters.ktpNum(memento.filterParams.ktpNum);
			}
			if (memento.filterParams.regNum) {
				self.filters.regNum(memento.filterParams.regNum);
			}
			if (memento.filterParams.protocolNum) {
				self.filters.protocolNum(memento.filterParams.protocolNum);
			}
			if (memento.filterParams.hologramNum) {
				self.filters.hologramNum(memento.filterParams.hologramNum);
			}
			if (memento.filterParams.orgUnit) {
				self.filters.orgUnit(self.orgUnits.find("code", memento.filterParams.orgUnit));
			}
			if (memento.filterParams.status) {
				self.filters.status(memento.filterParams.status);
			}
		}
		self.filters.saveLastUsedFilters();
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = self.filters.getLastUsedFilters();

		var memento = {
			pageParams: pageParams ? pageParams : {},
			filterParams: filterParams ? filterParams : {}
		};
		self.constructor.memento = memento;
	}

	function subscribeToKeyEvents() {
		eventsQueue.subscribe(Event.KEYPRESS_ENTER + thisNamespace, onEnter);
	}

	function unsubscribeFromKeyEvents() {
		eventsQueue.unsubscribe(Event.KEYPRESS_ENTER + thisNamespace);
	}

	this.dispose = function() {
		saveMemento();
		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		unsubscribeFromKeyEvents();
		restClient.cancelAll();
	};
};
