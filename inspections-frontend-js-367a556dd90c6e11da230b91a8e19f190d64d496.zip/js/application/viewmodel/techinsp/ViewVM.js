namespace("demax.inspections.viewmodel.techinsp");

demax.inspections.viewmodel.techinsp.ViewVM = function() {
	var self = this;
	var restClient = demax.inspections.restClient;

	var URL = {
		INSPECTION_BY_ID: "api/inspections/{0}"
	};

	this.isLoading = restClient.isLoading;

	this.inspection = ko.observable();

	this.init = function(params) {
		loadInspection(params.id);
	};

	function loadInspection(inspectionId) {
		return restClient.getResource(pastel.util.StringHelper.format(URL.INSPECTION_BY_ID, inspectionId))
			.done(function(inspectionDto) {
				self.inspection(new demax.inspections.model.techinsp.Inspection(inspectionDto));
			});
	}
};
