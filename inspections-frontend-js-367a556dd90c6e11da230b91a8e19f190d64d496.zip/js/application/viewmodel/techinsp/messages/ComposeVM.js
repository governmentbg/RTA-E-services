namespace("demax.inspections.viewmodel.techinsp.messages");

demax.inspections.viewmodel.techinsp.messages.ComposeVM = function() {
	var self = this;
	var restClient = demax.inspections.restClient;
	var subscriptions = [];

	var URL = {
		MESSAGE_BY_ID: "api/messages/{0}",
		DRAFT_MESSAGES: "api/messages/draft",
		DRAFT_MESSAGE_BY_ID: "api/messages/{0}/draft",
		SENT_MESSAGES: "api/messages/sent"
	};

	this.isLoading = ko.observable(false);

	var timeOutId;
	subscriptions.push(restClient.isLoading.subscribe(function (value) {
		if (value === false) {
			window.clearTimeout(timeOutId);
			self.isLoading(false);
		} else {
			timeOutId = window.setTimeout(function() {
				self.isLoading(true);
			}, 1000);
		}
	}));

	this.tabs = [{
		id: "wysiwyg_editor",
		text: "Съдържание"
	}, {
		id: "html_editor",
		text: "HTML тагове"
	}];
	this.selectedTab = ko.observable(self.tabs[0]);

	this.senders = ["Демакс АД", "Изпълнителна агенция \"Автомобилна администрация\""];
	this.orgUnits = ko.observableArray();
	this.message = ko.observable(new demax.inspections.model.techinsp.messages.MessageRequest());
	this.selectedFiles = ko.observableArray();
	
	this.shouldShowToolbar = ko.pureComputed(function() {
		return self.selectedTab().id == self.tabs[0].id;
	});

	this.isEditing = ko.observable(false);

	this.messageAttachments = ko.pureComputed(function() {
		var message = ko.unwrap(self.message);
		var messageAttachments = [];
		$.each(ko.unwrap(message.attachments), function(i, attachment) {
			messageAttachments.push(attachment);
		});
		$.each(ko.unwrap(self.selectedFiles), function (i, selectedFile) {
			messageAttachments.push(new demax.inspections.viewmodel.techinsp.messages.ComposeVM.FileAttachment(selectedFile));
		});
		return messageAttachments;
	});

	this.init = function(params) {
		loadOrgUnits().always(function() {
			if (params && params.id != null) {
				loadMessageById(params.id);
			}
		});
	};

	this.dispose = function() {
		$.each(subscriptions, function(i, subscription) {
			subscription.dispose();
		});
		restClient.cancelAll();
	};

	this.selectTab = function(tab) {
		self.selectedTab(tab);
	};

	this.saveMessageAsDraft = function() {
		var requestDto = ko.unwrap(self.message).toDto();

		if (!self.message().sender()) {
			demax.inspections.popupManager.warn("Въведете подател");
			return;
		}

		var formData = new FormData();
		formData.append("message", new Blob([JSON.stringify(requestDto)], {
			type: "application/json"
		}));

		var selectedFiles = ko.unwrap(self.selectedFiles);
		$.each(selectedFiles, function(i, file) {
			formData.append("attachments", file);
		});

		restClient.postResource(URL.DRAFT_MESSAGES, formData, {
			contentType: false,
			processData: false
		}).done(function() {
			demax.inspections.router.setHash("techinsp/messages/draft");
		});
	};

	this.updateDraftMessage = function() {
		var message = ko.unwrap(self.message);

		if (!self.message().sender()) {
			demax.inspections.popupManager.warn("Въведете подател");
			return;
		}

		if (message && ko.unwrap(message.statusCode) == "draft") {
			var url = pastel.util.StringHelper.format(URL.DRAFT_MESSAGE_BY_ID, ko.unwrap(message.id));
			var requestDto = message.toDto();

			var formData = new FormData();
			formData.append("message", new Blob([JSON.stringify(requestDto)], {
				type: "application/json"
			}));

			var selectedFiles = ko.unwrap(self.selectedFiles);
			$.each(selectedFiles, function(i, file) {
				formData.append("attachments", file);
			});

			restClient.putResource(url, formData, {
				contentType: false,
				processData: false
			}).done(function() {
				demax.inspections.router.setHash("techinsp/messages/draft");
			});
		}
	};

	this.saveAndSendMessage = function() {
		var message = ko.unwrap(self.message);

		if (!self.message().sender()) {
			demax.inspections.popupManager.warn("Въведете подател");
			return;
		}

		var requestDto = message.toDto();
		if (ko.unwrap(self.isEditing) === true && ko.unwrap(message.id) && ko.unwrap(message.statusCode) === "draft") {
			requestDto.statusCode = "sent";
		}

		var formData = new FormData();
		formData.append("message", new Blob([JSON.stringify(requestDto)], {
			type: "application/json"
		}));

		var selectedFiles = ko.unwrap(self.selectedFiles);
		$.each(selectedFiles, function(i, file) {
			formData.append("attachments", file);
		});

		var url = URL.SENT_MESSAGES;

		var request = null;
		if (ko.unwrap(self.isEditing) === true && ko.unwrap(message.id) && ko.unwrap(message.statusCode) === "draft") {
			url = pastel.util.StringHelper.format(URL.DRAFT_MESSAGE_BY_ID, ko.unwrap(message.id));
			request = restClient.putResource(url, formData, {
				contentType: false,
				processData: false
			});
		} else {
			request = restClient.postResource(url, formData, {
				contentType: false,
				processData: false
			});
		}

		request.done(function() {
			demax.inspections.router.setHash("techinsp/messages/sent");
		});
	};

	this.removeAttachment = function(attachment) {
		if (attachment instanceof demax.inspections.viewmodel.techinsp.messages.ComposeVM.FileAttachment) {
			self.selectedFiles.remove(attachment.file);
		} else {
			var message = ko.unwrap(self.message);
			message.attachments.remove(attachment);
		}
	};

	function loadOrgUnits() {
		return demax.inspections.nomenclature.NomenclatureService.getOrgUnitsWithoutIaaa()
			.done(function(response) {
				self.orgUnits(ko.utils.arrayMap(response, function(orgUnitDto) {
					return new demax.inspections.model.OrgUnit(orgUnitDto);
				}));
			});
	}

	function loadMessageById(messageId) {
		var url = pastel.util.StringHelper.format(URL.MESSAGE_BY_ID, messageId);
		return restClient.getResource(url)
			.done(function(messageDto) {
				ko.unwrap(self.message).setFromDto(messageDto);
				self.isEditing(true);
			});
	}
};

demax.inspections.viewmodel.techinsp.messages.ComposeVM.FileAttachment = function(file) {
	this.file = file;
	this.mimeType = file.type;
	this.filename = file.name;
};
