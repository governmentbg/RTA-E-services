namespace("demax.inspections.viewmodel.techinsp.messages");

demax.inspections.viewmodel.techinsp.messages.DraftListVM = function() {

	var self = this;
	var restClient = demax.inspections.restClient;

	var URL = {
		DRAFT_MESSAGES: "api/messages/draft"
	};

	var subscriptions = [];

	this.isLoading = restClient.isLoading;

	this.pageSizes = [50];

	this.pagination = new pastel.plus.component.pagination.Pagination({
		page: 1,
		pageSize: self.pageSizes[0]
	});

	this.messages = ko.observableArray();
	this.messagesCount = ko.observable();

	this.checkedMessageIds = ko.observableArray();

	this.filters = {
		searchText: ko.observable().extend({
			rateLimit: {timeout: 500, method: "notifyWhenChangesStop"}
		}),

		queryParams: ko.pureComputed(function() {
			var searchText = undefined;
			if (ko.unwrap(self.filters.searchText)) {
				searchText = ko.unwrap(self.filters.searchText);
			}
			return {
				subject: searchText
			};
		}),

		clear: function() {
			self.filters.searchText(null);
		}
	};

	this.requestParams = ko.pureComputed(function() {
		var pageParams = self.pagination.queryParamsObject();
		var queryParams = ko.unwrap(self.filters.queryParams);

		return $.extend({}, pageParams, queryParams);
	}).extend({
		deferred: true
	});

	this.init = function() {
		restoreMemento();

		subscriptions.push(self.filters.queryParams.subscribe(function() {
			self.pagination.page(1);
		}));

		subscriptions.push(self.requestParams.subscribe(loadMessages));

		loadMessages();
	};

	this.dispose = function() {
		subscriptions.forEach(function(subscription) {
			subscription.dispose();
		});
		saveMemento();
		restClient.cancelAll();
	};

	this.deleteSelectedMessages = function() {
		demax.inspections.popupManager.confirm({
			message: "Сигурни ли сте, че искате да изтриети избраните съобщения?"
		}).done(function() {
			var messageIds = ko.unwrap(self.checkedMessageIds);
			var messageParameters = "";
			$.each(messageIds, function(i, messageId) {
				if (i > 0) {
					messageParameters += "&";
				}
				messageParameters += "messageIds=" + messageId;
			});
			var url = URL.DRAFT_MESSAGES + "?" + messageParameters;
			demax.inspections.restClient.deleteResource(url)
				.always(function() {
					loadMessages();
					self.checkedMessageIds([]);
				});
		});
	};

	function loadMessages() {
		var requestParams = self.requestParams();
		return demax.inspections.restClient.getResource(URL.DRAFT_MESSAGES, requestParams)
			.done(function (response) {
				self.messages(ko.utils.arrayMap(response.items, function(messageDto) {
					return new demax.inspections.model.techinsp.messages.MessageListItem(messageDto);
				}));
				self.messagesCount(response.totalCount);
			});
	}

	function saveMemento() {
		var pageParams = self.pagination.queryParamsObject();
		var filterParams = ko.unwrap(self.filters.queryParams);

		var memento = {
			pageParams: pageParams,
			filterParams: filterParams
		};
		self.constructor.memento = memento;
	}

	function restoreMemento() {
		var memento = self.constructor.memento;
		if (memento !== undefined) {
			self.pagination = new pastel.plus.component.pagination.Pagination({
				page: memento.pageParams.page,
				pageSize: memento.pageParams.pageSize,
				orderBy: memento.pageParams.orderBy,
				direction: memento.pageParams.direction
			});
			self.filters.searchText(memento.filterParams.subject);
		}
	}
};
