namespace("demax.inspections.viewmodel.techinsp.messages");

demax.inspections.viewmodel.techinsp.messages.ViewVM = function() {
	var self = this;
	var restClient = demax.inspections.restClient;

	var URL = {
		MESSAGE_BY_ID: "api/messages/{0}",
		DRAFT_MESSAGE_STATUS: "api/messages/{0}/draft/status"
	};

	this.isLoading = restClient.isLoading;

	this.message = ko.observable();

	this.init = function(params) {
		loadMessage(params.id);
	};

	this.sendDraftMessage = function() {
		var url = pastel.util.StringHelper.format(URL.DRAFT_MESSAGE_STATUS, ko.unwrap(self.message).id);
		var requestBody = {
			statusCode: "sent"
		};

		restClient.patchResource(url, JSON.stringify(requestBody))
			.done(function() {
				demax.inspections.router.setHash("techinsp/messages/sent");
			});
	};

	function loadMessage(messageId) {
		var url = pastel.util.StringHelper.format(URL.MESSAGE_BY_ID, messageId);
		return demax.inspections.restClient.getResource(url)
			.done(function (messageDto) {
				self.message(new demax.inspections.model.techinsp.messages.MessageListItem(messageDto));
			});
	}
};
