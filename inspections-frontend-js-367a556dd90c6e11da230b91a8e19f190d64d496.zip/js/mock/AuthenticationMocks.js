$(function() {
	var Role = demax.inspections.nomenclature.Role;
	$.mockjax({
		url: "api/users/current",
		type: "GET",
		responseTime: 10,
		responseText: {
			name: "Mock Mockov Mockovski",
			authorities: [Role.CALL_CENTER],
		}
	});
});
