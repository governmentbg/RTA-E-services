$(function() {
	$.mockjax({
		url: /^api\/exam-orders\/([\d]+)\/bill-of-lading/,

		type: "POST",
		responseText: {
			id: 1,
			billOfLadingId: 2,
			courierServiceTypeCode: "EXPRESS",
			courierCode: "SPEEDY"
		}
	});
});
