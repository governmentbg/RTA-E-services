$(function() {
	var CamRequestStatus = demax.inspections.nomenclature.techinsp.CamRequestStatus;

	$.mockjax({
		url: /^api\/inspections\/([\d]+)\/setup-live-stream/,
		type: "PUT",
		responseText: {
			"restreamAddress": "http://192.168.4.10:8080",
			"isAsf": true,
			"camRequest": {
				"feedNum": 2,
				"resolution": 1,
				"statusCode": CamRequestStatus.REQ_OPEN.code
			}
		}
	});

	$.mockjax({
		url: /^api\/cam-requests(.+?)?/,
		type: "GET",
		responseText: {
			"feedNum": 2,
			"resolution": 1,
			"statusCode": CamRequestStatus.OPENED.code
		}
	});


});
