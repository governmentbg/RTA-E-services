$(function() {
	$.mockjax({
		url: "api/exam-orders",
		type: "GET",
		responseTime: 1000,
		responseText: {
			items: getVoucherOrderDtos(),
			totalCount: 2
		}
	});
	
	$.mockjax({
		url: "api/inspection-orders",
		type: "GET",
		responseTime: 1000,
		responseText: {
			items: getInspectionOrderDtos(),
			totalCount: 2
		}
	});

	$.mockjax({
		url: "api/exam-orders/25",
		type: "GET",
		responseTime: 1000,
		responseText: getExamOrderDto(25, demax.inspections.nomenclature.StatusCode.PAID)
	});
	
	function getExamOrderDtos() {
		var examOrderDtos = [];
		var firstVoucherDto = {
			id: 25,
			createdAt: '23.05.18',
			companyName: 'BG SERVICE',
			eik: 1121221232,
			permitNumber: 11123232,
			statusCode: demax.inspections.nomenclature.StatusCode.PAID.code,
			receptionCityName: 'Sofia',
			receptionAddress: 'test address sofia...',
			orderItems: [{
				fromNum: 1,
				toNum: 20,
				quantity: 20
			}]
		};

		var secondVoucherDto = {
			id: 27,
			createdAt: '27.05.18',
			companyName: 'BG SERVICE 1',
			eik: 666767676,
			permitNumber: 7676767676,
			statusCode: demax.inspections.nomenclature.StatusCode.SEND.code,
			receptionCityName: 'Sofiata',
			receptionAddress: 'test address 2 sofia...',
			orderItems: [{
				fromNum: 1,
				toNum: 20,
				quantity: 20
			}]
		};

		examOrderDtos.push(firstVoucherDto);
		examOrderDtos.push(secondVoucherDto);
		
		return examOrderDtos;
	}

	function getExamOrderDto(id, statusCode) {
		return {
			id: id,
			orderCreationDate: '23.05.18',
			receptionCityName: 'Sofia',
			receptionAddress: 'test address sofia...',
			receptionPersonName: "test person name",
			receptionPersonPhoneNumber: "0988923834",
			billOfLading: "",
			statusCode: statusCode.code,
			accountantName: "test accountant",
			accountantCode: "2411600",
			invoiceDateTime: "17.10.17",
			invoiceNumber: "12232144",
			courierService: demax.inspections.nomenclature.CourierService.SPEEDY,
			courierServiceType: demax.inspections.nomenclature.CourierServiceType.STANDART,

			examOrderCustomerDto: {
				companyName: 'BG SERVICE',
				eik: 1121221232,
				cityName: "Sofia",
				phoneNumber: "0872892392",
				address: "Test address customer",
				mol: "test mol",
				municipality: "Sofia",
				vatNumber: "1122332"
				
			},
			
			examOrderItemDtos: [
				{
					id: 1,
					fromNum: 1,
					toNum: 20,
					quantity: 20,
					productId: 124,
					productName: 'Voucheri prakticheski izpiti'
				},
				{
					id: 2,
					fromNum: 21,
					toNum: 40,
					quantity: 20,
					productId: 124,
					productName: 'Voucheri prakticheski izpiti'
				}
			]
		};
	};

	function getInspectionOrderDtos() {
		var inspectionOrderDtos = [];		
		var firstInspectionDto = {
			id: 25,
			createdAt: '23.05.18',
			companyName: 'BG SERVICE',
			eik: 1121221232,
			permitNumber: 11123232,
			statusCode: demax.inspections.nomenclature.StatusCode.PAID.code,
			receptionName: 'OO Sofia',
			quantity: 250,
			weight: 500
		};

		var secondInspectionDto = {
			id: 27,
			createdAt: '27.05.18',
			companyName: 'BG SERVICE 1',
			eik: 666767676,
			permitNumber: 7676767676,
			statusCode: demax.inspections.nomenclature.StatusCode.SEND.code,
			receptionName: 'OO Sofia',
			quantity: 300,
			weight: 500
		};
		
		inspectionOrderDtos.push(firstInspectionDto);
		inspectionOrderDtos.push(secondInspectionDto);
		return inspectionOrderDtos;
	}
});
