package bg.demax.motor.exam.result.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MotorExamResultRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MotorExamResultRestApplication.class, args);
	}
}
