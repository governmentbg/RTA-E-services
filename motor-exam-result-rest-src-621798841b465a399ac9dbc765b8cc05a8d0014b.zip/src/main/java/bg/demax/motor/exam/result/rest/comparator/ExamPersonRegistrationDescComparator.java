package bg.demax.motor.exam.result.rest.comparator;

import java.util.Comparator;

import bg.demax.motor.exam.result.entity.ExamPerson;

public class ExamPersonRegistrationDescComparator implements Comparator<ExamPerson> {

	@Override
	public int compare(ExamPerson o1, ExamPerson o2) {
		return o2.getRegisteredAt().compareTo(o1.getRegisteredAt());
	}
}
