package bg.demax.motor.exam.result.rest.config;

public interface ApplicationConstants {

	String SPRING_PROFILE_UNIT_TEST = "utest";
	String SPRING_PROFILE_DEVELOPMENT = "dev";
	String SPRING_PROFILE_DRIVE = "drive";
	String SPRING_PROFILE_PRODUCTION = "production";

	String[] APPLICATION_ENTITY_PACKAGES_TO_SCAN = { "bg.demax.payment.service.db.entity",
													 "bg.demax.motor.exam.result.entity",
													 "bg.demax.exams.entity",
													 "bg.demax.security.entity",
													 "bg.demax.pub.entity",
													 "bg.demax.motor.exam.permit.entity",
													 "bg.demax.motor.exam.result.practical.entity",
													 "bg.demax.motor.exam.result.rest.db.entity"};

	String APPLICATION_REPOSITORY_PACKAGES_TO_SCAN = "bg.demax.motor.exam.result.rest.db.repository";
	
	String APPLICATION_COMPONENT_PACKAGES_TO_SCAN = "bg.demax.legacy.util";

	String APPLICATION_CODE = "MERW";
}