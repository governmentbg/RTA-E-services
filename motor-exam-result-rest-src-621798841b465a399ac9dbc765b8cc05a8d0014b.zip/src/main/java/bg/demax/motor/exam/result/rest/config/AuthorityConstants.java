package bg.demax.motor.exam.result.rest.config;

public interface AuthorityConstants {

	String ROLE_MOTOR_EXAM_REST_API = "ROLE_MOTOR_EXAM_REST_API";
}
