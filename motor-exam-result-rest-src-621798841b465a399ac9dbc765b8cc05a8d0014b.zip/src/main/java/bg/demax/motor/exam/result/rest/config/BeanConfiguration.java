package bg.demax.motor.exam.result.rest.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import bg.demax.hibernate.GenericFinder;
import bg.demax.hibernate.GenericGateway;
import bg.demax.hibernate.GenericSearchSupport;
import bg.demax.hibernate.PagingAndSortingSupport;
import bg.demax.pub.finder.SubjectFinder;
import bg.demax.pub.finder.SystemVariableFinder;
import bg.demax.pub.service.SubjectService;
import bg.demax.pub.service.SystemVariableService;
import bg.demax.pub.settings.ApplicationSettingsFactory;

@Configuration
public class BeanConfiguration {

	@Bean
	public ApplicationSettingsFactory getApplicationSettingsFactory() {
		ApplicationSettingsFactory applicationSettingsFactory = new ApplicationSettingsFactory();
		applicationSettingsFactory.setDefaultApplicationCode(ApplicationConstants.APPLICATION_CODE);
		applicationSettingsFactory.setSystemVariableService(systemVariableService());

		return applicationSettingsFactory;
	}

	@Bean
	public SystemVariableService systemVariableService() {
		return new SystemVariableService();
	}

	@Bean
	public SubjectService subjectService() {
		return new SubjectService();
	}

	@Bean
	public SubjectFinder subjectFinder() {
		return new SubjectFinder();
	}

	@Bean
	public SystemVariableFinder systemVariableFinder() {
		return new SystemVariableFinder();
	}

	@Bean
	public GenericFinder genericFinder() {
		return new GenericFinder();
	}

	@Bean
	public GenericGateway genericGateway() {
		return new GenericGateway();
	}

	@Bean
	public GenericSearchSupport genericSearchSupport() {
		return new GenericSearchSupport();
	}

	@Bean
	public PagingAndSortingSupport pagingAndSortingSupport() {
		return new PagingAndSortingSupport();
	}
}
