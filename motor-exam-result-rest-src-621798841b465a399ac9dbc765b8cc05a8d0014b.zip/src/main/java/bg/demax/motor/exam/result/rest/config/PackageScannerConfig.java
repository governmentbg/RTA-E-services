package bg.demax.motor.exam.result.rest.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(ApplicationConstants.APPLICATION_COMPONENT_PACKAGES_TO_SCAN)
public class PackageScannerConfig {
	
}
