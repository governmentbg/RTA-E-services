package bg.demax.motor.exam.result.rest.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import bg.demax.motor.exam.result.rest.db.CustomTransactionRetryInterceptor;
import bg.demax.security.RoleHierarchyImpl;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = ApplicationConstants.APPLICATION_REPOSITORY_PACKAGES_TO_SCAN, 
						entityManagerFactoryRef = "entityManagerFactory")
@Profile("!" + ApplicationConstants.SPRING_PROFILE_UNIT_TEST)
public class PostgreConfiguration {

	@Value("${hibernate.hbm2ddl.auto}")
	private String hibernateHbm2dll;

	@Value("${hibernate.show_sql}")
	private String hibernateShowSql;

	@Value("${hibernate.format_sql}")
	private String hibernateFormatSql;

	@Value("${hibernate.use_sql_comments}")
	private String hibernateUseSqlComments;

	@Value("${hibernate.dialect}")
	private String hibernateDialect;

	@Value("${spring.datasource.url}")
	private String url;

	@Value("${spring.datasource.username}")
	private String username;

	@Value("${spring.datasource.password}")
	private String password;

	@Value("${spring.datasource.driver_class_name}")
	private String driverClassName;

	@Bean
	public LocalSessionFactoryBean entityManagerFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(dataSource());
		sessionFactory.setPackagesToScan(ApplicationConstants.APPLICATION_ENTITY_PACKAGES_TO_SCAN);
		sessionFactory.setHibernateProperties(hibernateProperties());
		return sessionFactory;
	}

	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource driverManaverDataSource = new DriverManagerDataSource();
		driverManaverDataSource.setUrl(url);
		driverManaverDataSource.setUsername(username);
		driverManaverDataSource.setPassword(password);
		driverManaverDataSource.setDriverClassName(driverClassName);
		return driverManaverDataSource;
	}

	@Bean
	public CustomTransactionRetryInterceptor customTransactionRetryInterceptor() {
		CustomTransactionRetryInterceptor retryInterceptor = new CustomTransactionRetryInterceptor();
		retryInterceptor.setMaxRetries(5);
		retryInterceptor.setOrder(1);
		retryInterceptor.setRandomSleepMillis(2000);
		return retryInterceptor;
	}
	
	@Bean
	public RoleHierarchy roleHierarchy(){
		return RoleHierarchyImpl.getInstance();
	}

	private Properties hibernateProperties() {
		Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty("hibernate.hbm2ddl.auto", hibernateHbm2dll);
		hibernateProperties.setProperty("hibernate.show_sql", hibernateShowSql);
		hibernateProperties.setProperty("hibernate.format_sql", hibernateFormatSql);
		hibernateProperties.setProperty("hibernate.use_sql_comments", hibernateUseSqlComments);
		hibernateProperties.setProperty("hibernate.dialect", hibernateDialect);
		hibernateProperties.setProperty("hibernate.temp.use_jdbc_metadata_defaults", "false");
		hibernateProperties.setProperty("org.hibernate.envers.default_schema", "audit");
		hibernateProperties.setProperty("org.hibernate.envers.audit_table_suffix", "_aud");
		return hibernateProperties;
	}
}
