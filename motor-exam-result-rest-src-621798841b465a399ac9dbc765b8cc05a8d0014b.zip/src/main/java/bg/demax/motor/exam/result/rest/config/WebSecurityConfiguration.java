package bg.demax.motor.exam.result.rest.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsChecker;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;

import bg.demax.security.auth.CryptoTokenAuthenticationFilter;
import bg.demax.security.auth.PreAuthenticationChecker;
import bg.demax.security.service.CryptoTokenAuthenticationService;

@Configuration
@EnableWebSecurity
@ComponentScan("bg.demax.security")
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Autowired
	private CryptoTokenAuthenticationService cryptoTokenAuthenticationService;
	
	private CryptoTokenAuthenticationFilter cryptoTokenAuthenticationFilter;

	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception {
		PreAuthenticatedAuthenticationProvider preAuthenticatedAuthenticationProvider = new PreAuthenticatedAuthenticationProvider();
		preAuthenticatedAuthenticationProvider.setPreAuthenticatedUserDetailsService(cryptoTokenAuthenticationService);
		preAuthenticatedAuthenticationProvider.setUserDetailsChecker(userDetailsChecker());
		auth.authenticationProvider(preAuthenticatedAuthenticationProvider);
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		cryptoTokenAuthenticationFilter = new CryptoTokenAuthenticationFilter();
		cryptoTokenAuthenticationFilter.setAuthenticationManager(authenticationManager());
		
		http.addFilterBefore(cryptoTokenAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
		
		http.csrf().disable();
		
		http.authorizeRequests()
			.and()
			.exceptionHandling()
			.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED));
		
		http.authorizeRequests()
			.anyRequest()
			.hasAnyAuthority(AuthorityConstants.ROLE_MOTOR_EXAM_REST_API);
	}
	
	@Bean
	public UserDetailsChecker userDetailsChecker() {
		UserDetailsChecker UserDetailsChecker = new PreAuthenticationChecker();
		return UserDetailsChecker;
	}
}
