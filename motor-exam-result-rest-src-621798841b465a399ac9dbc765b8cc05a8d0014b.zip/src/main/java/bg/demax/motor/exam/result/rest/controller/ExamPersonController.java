package bg.demax.motor.exam.result.rest.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.rest.dto.ExamPersonRegistrationResponseDto;
import bg.demax.motor.exam.result.rest.dto.ExamPersonEnrolmentDto;
import bg.demax.motor.exam.result.rest.dto.ExamPersonRegistrationRequestDto;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;

@RestController
@RequestMapping("/api/exam-people")
public class ExamPersonController {

	@Autowired
	private ExamPersonService examPersonService;
	
	@GetMapping("/for-theoretical-exam-enrolment/{personalIdentityNumber}")
	public List<ExamPersonEnrolmentDto> getExamPeopleForExamEnrolment(
			@PathVariable("personalIdentityNumber") String personalIdentityNumber,
			@RequestParam(required = false, name = "categoryId") Integer categoryId) {
		return examPersonService.getExamPeopleForExamEnrolment(personalIdentityNumber, ExamRequirement.ID_EXTERNAL_THEORETICAL, categoryId);
	}

	@PostMapping
	public ExamPersonRegistrationResponseDto registerExamPerson(@Valid @RequestBody ExamPersonRegistrationRequestDto requestDto) throws ConstraintCheckFailureException {
		return examPersonService.registerExamPerson(requestDto);
	}

	@PostMapping("/cancel-learning/{examPersonId}")
	public void cancelLearning(@PathVariable("examPersonId") long examPersonId) throws ConstraintCheckFailureException {
		examPersonService.cancelLearning(examPersonId);	
	}
}
