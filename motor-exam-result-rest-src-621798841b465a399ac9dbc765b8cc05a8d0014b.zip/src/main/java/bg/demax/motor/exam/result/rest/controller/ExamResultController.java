package bg.demax.motor.exam.result.rest.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.rest.dto.CreateExamResultDto;
import bg.demax.motor.exam.result.rest.dto.ExamResultInProtocolDto;
import bg.demax.motor.exam.result.rest.service.ExamResultService;

@RestController
@RequestMapping("/api/exam-results")
public class ExamResultController {
	
	@Autowired
	private ExamResultService examResultService;
	
	@PostMapping(value = {"/",""}, consumes = "application/json; charset=utf-8",produces = "application/json; charset=utf-8")
	public ExamResultInProtocolDto createExamResult(@RequestBody @Valid CreateExamResultDto dto) throws ConstraintCheckFailureException {
		ExamResultInProtocolDto examResultInProtocolDto = examResultService.createExamResult(dto);
		return examResultInProtocolDto;
	}
	
	@DeleteMapping("/{examResultId}")
	public void delete(@PathVariable("examResultId") Long examResultId) throws ConstraintCheckFailureException {
		examResultService.deleteExamResult(examResultId);
	}
}