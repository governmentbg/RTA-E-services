package bg.demax.motor.exam.result.rest.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.motor.exam.result.rest.controller.params.ProtocolQueryParams;
import bg.demax.motor.exam.result.rest.dto.ProtocolDto;
import bg.demax.motor.exam.result.rest.service.ProtocolService;

@RestController
@RequestMapping("/api/protocols")
public class ProtocolController {

	@Autowired
	private ProtocolService protocolService;
	
	@GetMapping
	public List<ProtocolDto> getProtocols(@Valid ProtocolQueryParams params) {
		return protocolService.getProtocols(params);
	}
}
