package bg.demax.motor.exam.result.rest.controller.advice;

import java.time.LocalDateTime;
import java.util.Collections;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.rest.dto.ErrorMessageDto;
import bg.demax.motor.exam.result.rest.exception.ApplicationConstraintCheckFailureException;
import bg.demax.motor.exam.result.rest.exception.ApplicationException;
import bg.demax.motor.exam.result.rest.exception.ApplicationNotFoundException;

@RestControllerAdvice
public class GlobalControllerAdvice extends ResponseEntityExceptionHandler {
	
	private static final Logger logger = LogManager.getLogger(GlobalControllerAdvice.class);
	private static final String NO_MESSAGE = "_NO_MESSAGE_";

	@ExceptionHandler(ApplicationException.class)
	@ResponseStatus(value = HttpStatus.CONFLICT)
	public ErrorMessageDto resourceNotFoundException(ApplicationException ex, WebRequest request) {
		ErrorMessageDto message = new ErrorMessageDto(HttpStatus.CONFLICT.value(), 
													  LocalDateTime.now(), 
													  ex.getClass().getSimpleName(),
													  ex.getMessage(),
													  request.getDescription(false));
		return message;
	}
	
	@ExceptionHandler(ApplicationNotFoundException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public ErrorMessageDto resourceNotFoundException(ApplicationNotFoundException ex, WebRequest request) {
		ErrorMessageDto message = new ErrorMessageDto(HttpStatus.NOT_FOUND.value(), 
													  LocalDateTime.now(), 
													  ex.getClass().getSimpleName(),
													  ex.getMessage(),
													  request.getDescription(false));
		return message;
	}

	@ExceptionHandler(ConstraintCheckFailureException.class)
	@ResponseStatus(value = HttpStatus.PRECONDITION_FAILED)
	public ErrorMessageDto constraintCheckFailureException(ConstraintCheckFailureException ex, WebRequest request) {
		StringBuilder errorMessage = new StringBuilder();
		
		ex.getViolations().forEach(violation ->{
			errorMessage.append(violation.getMessage());
		});
		
		ErrorMessageDto message = new ErrorMessageDto(HttpStatus.PRECONDITION_FAILED.value(), 
													  LocalDateTime.now(), 
													  ex.getClass().getSimpleName(),
													  errorMessage.toString(),
													  request.getDescription(false));
		return message;
	}
	
	@ExceptionHandler(ApplicationConstraintCheckFailureException.class)
	@ResponseStatus(value = HttpStatus.PRECONDITION_FAILED)
	public ErrorMessageDto constraintCheckFailureException(ApplicationConstraintCheckFailureException ex, WebRequest request) {
		ConstraintCheckFailureException cause = (ConstraintCheckFailureException) ex.getCause();

		StringBuilder errorMessage = new StringBuilder();
		cause.getViolations().forEach(violation ->{
			errorMessage.append(violation.getMessage());
		});
		
		ErrorMessageDto message = new ErrorMessageDto(HttpStatus.PRECONDITION_FAILED.value(), 
													  LocalDateTime.now(), 
													  ex.getClass().getSimpleName(),
													  errorMessage.toString(),
													  request.getDescription(false));
		return message;
	}

	@ExceptionHandler
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ErrorMessageDto handleUnhandledExceptions(Exception ex, HttpServletRequest request, WebRequest webRequest) {
		if (!ex.getClass().getCanonicalName().equals("org.apache.catalina.connector.ClientAbortException")) {
			logger.error("Caught unhandled exception: ", ex);
		}
		setResponseTypeToJson(request);
		ErrorMessageDto dto = new ErrorMessageDto(HttpStatus.INTERNAL_SERVER_ERROR.value(), 
				  LocalDateTime.now(), 
				  "Exception",
				  "Unexpected server error.",
				  NO_MESSAGE);
		return dto;
	}

	private void setResponseTypeToJson(HttpServletRequest request) {
		request.setAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE, 
				Collections.singleton(MediaType.APPLICATION_JSON));
	}
}
