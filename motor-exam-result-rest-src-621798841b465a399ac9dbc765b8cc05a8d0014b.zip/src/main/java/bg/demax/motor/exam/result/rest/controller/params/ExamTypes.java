package bg.demax.motor.exam.result.rest.controller.params;

public enum ExamTypes {
	EXTERNAL_THEORETICAL, EXTERNAL_PRACTICAL
}
