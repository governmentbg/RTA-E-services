package bg.demax.motor.exam.result.rest.controller.params;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProtocolQueryParams {

	@NotBlank
	private String orgUnitCode;

	@NotNull
	private ExamTypes examType;

	@NotNull
	private ReservationTypes reservationType;

	@NotNull
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate fromExamDate;

	@NotNull
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate toExamDate;
}
