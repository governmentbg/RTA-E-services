package bg.demax.motor.exam.result.rest.controller.params;

public enum ReservationTypes {
	PUBLIC, IAAA_TAXI
}
