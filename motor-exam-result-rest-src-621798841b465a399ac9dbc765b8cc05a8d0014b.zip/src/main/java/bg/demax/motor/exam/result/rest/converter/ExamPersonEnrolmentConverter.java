package bg.demax.motor.exam.result.rest.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.rest.dto.ExamPersonEnrolmentDto;
import bg.demax.motor.exam.result.rest.dto.OrgUnitDto;

@Component
public class ExamPersonEnrolmentConverter implements Converter<ExamPerson, ExamPersonEnrolmentDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public ExamPersonEnrolmentDto convert(ExamPerson from) {
		ExamPersonEnrolmentDto dto = new ExamPersonEnrolmentDto();
		dto.setExamPersonId(from.getId());
		dto.setLearningPlanName(getLearnningPlanName(from.getLearningPlan()));
		dto.setTheoreticalExamResult(getTheroreticalExamResult(from));

		OrgUnitDto orgUnitDto = conversionService.convert(from.getCompany().getOrgUnit(), OrgUnitDto.class);
		dto.setOrgUnit(orgUnitDto);

		return dto;
	}

	private String getLearnningPlanName(LearningPlan learningPlan) {
		StringBuilder theroreticalExamResult = new StringBuilder();

		theroreticalExamResult.append(learningPlan.getTargetCategory().getName());
		theroreticalExamResult.append(", ");
		theroreticalExamResult.append(learningPlan.getDescription());

		return theroreticalExamResult.toString();
	}

	private String getTheroreticalExamResult(ExamPerson from) {
		StringBuilder theroreticalExamResult = new StringBuilder();
		from.getExamResults().forEach(result -> {
			if (result.getProtocol().getExamType().getId() == ExamRequirement.ID_EXTERNAL_THEORETICAL) {
				if (result.getPassed() != null) {
					theroreticalExamResult.append(result.getPassed() == true ? "ДА" : "НЕ");
				}
			}
		});
		return theroreticalExamResult.toString();
	}
}
