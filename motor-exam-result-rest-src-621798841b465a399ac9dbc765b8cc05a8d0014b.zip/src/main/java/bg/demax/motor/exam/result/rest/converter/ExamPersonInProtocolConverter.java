package bg.demax.motor.exam.result.rest.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.rest.dto.ExamPersonDto;
import bg.demax.motor.exam.result.rest.dto.OrgUnitDto;

@Component
public class ExamPersonInProtocolConverter implements Converter<ExamPerson, ExamPersonDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public ExamPersonDto convert(ExamPerson from) {
		ExamPersonDto dto = new ExamPersonDto();
		dto.setExamPersonId(from.getId());
		dto.setLearningPlanName(getLearnningPlanName(from.getLearningPlan()));
		setTheoreticalExamResultAndExamDate(dto, from);

		OrgUnitDto orgUnitDto = conversionService.convert(from.getCompany().getOrgUnit(), OrgUnitDto.class);
		dto.setOrgUnit(orgUnitDto);

		return dto;
	}

	private String getLearnningPlanName(LearningPlan learningPlan) {
		StringBuilder theroreticalExamResult = new StringBuilder();

		theroreticalExamResult.append(learningPlan.getTargetCategory().getName());
		theroreticalExamResult.append(", ");
		theroreticalExamResult.append(learningPlan.getDescription());

		return theroreticalExamResult.toString();
	}

	private void setTheoreticalExamResultAndExamDate(ExamPersonDto dto, ExamPerson from) {
		StringBuilder theroreticalExamResult = new StringBuilder();
		from.getExamResults().forEach(result -> {
			if (result.getProtocol().getExamType().getId() == ExamRequirement.ID_EXTERNAL_THEORETICAL) {
				if (result.getPassed() != null) {
					theroreticalExamResult.append(result.getPassed() == true ? "ДА" : "НЕ");
					dto.setExamDate(result.getProtocol().getExamTime());
				}
			}
		});
		dto.setTheoreticalExamResult(theroreticalExamResult.toString());
	}
}
