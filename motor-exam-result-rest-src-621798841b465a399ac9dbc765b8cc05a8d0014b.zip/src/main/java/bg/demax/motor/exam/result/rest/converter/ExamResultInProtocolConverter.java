package bg.demax.motor.exam.result.rest.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.rest.dto.ExamPersonDto;
import bg.demax.motor.exam.result.rest.dto.ExamResultInProtocolDto;
import bg.demax.motor.exam.result.rest.dto.ProtocolDto;

@Component
public class ExamResultInProtocolConverter implements Converter<ExamResult, ExamResultInProtocolDto>{
	
	@Autowired
	private ConversionService conversionService;

	@Override
	public ExamResultInProtocolDto convert(ExamResult examResult) {
		
		ExamResultInProtocolDto dto = new ExamResultInProtocolDto();
		
		dto.setExamResultId(examResult.getId());
		dto.setExamPerson(conversionService.convert(examResult.getExamPerson(), ExamPersonDto.class));
		dto.setProtocol(conversionService.convert(examResult.getProtocol(), ProtocolDto.class));
		
		return dto;
	}
}
