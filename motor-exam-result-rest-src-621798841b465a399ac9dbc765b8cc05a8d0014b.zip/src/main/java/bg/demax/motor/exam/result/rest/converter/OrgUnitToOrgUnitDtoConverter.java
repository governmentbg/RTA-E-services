package bg.demax.motor.exam.result.rest.converter;

import org.springframework.stereotype.Component;

import bg.demax.legacy.util.convert.Converter;
import bg.demax.motor.exam.result.rest.dto.OrgUnitDto;
import bg.demax.pub.entity.OrgUnit;

@Component
public class OrgUnitToOrgUnitDtoConverter implements Converter<OrgUnit, OrgUnitDto> {

	@Override
	public OrgUnitDto convert(OrgUnit orgUnit) {
		OrgUnitDto dto = new OrgUnitDto();
		dto.setCode(orgUnit.getCode());
		dto.setName(orgUnit.getShortName());
		return dto;
	}
}
