package bg.demax.motor.exam.result.rest.converter;

import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.rest.dto.OrgUnitDto;
import bg.demax.motor.exam.result.rest.dto.ProtocolDto;
import bg.demax.motor.exam.result.rest.util.EntityUtil;

@Component
public class ProtocolToProtocolDtoConverter implements Converter<Protocol, ProtocolDto> {

	@Autowired
	private ConversionService conversionService;

	@Override
	public ProtocolDto convert(Protocol protocol) {
		ProtocolDto dto = new ProtocolDto();
		dto.setId(protocol.getId());
		dto.setExamDateTime(protocol.getExamTime());

		String numberString;
		if (protocol.getNumber() == null) {
			numberString = "---";
		} else {
			numberString = String.valueOf(protocol.getNumber());
		}
		DateTimeFormatter protocolDateFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
		dto.setNumber(numberString + " / " + protocol.getExamTime().format(protocolDateFormatter));

		if (protocol.getExamRoom() != null) {
			dto.setRoomName(protocol.getExamRoom().getAddress());
		}
		int examResultsCount = protocol.getExamResults().size();
		int remainingSeats = EntityUtil.getSeatplaces(protocol) - examResultsCount;
		dto.setRemainingSeats(remainingSeats);

		if (protocol.getOrgUnit() != null) {
			OrgUnitDto orgUnitDto = conversionService.convert(protocol.getOrgUnit(), OrgUnitDto.class);
			dto.setOrgUnit(orgUnitDto);
		}
		return dto;
	}
}
