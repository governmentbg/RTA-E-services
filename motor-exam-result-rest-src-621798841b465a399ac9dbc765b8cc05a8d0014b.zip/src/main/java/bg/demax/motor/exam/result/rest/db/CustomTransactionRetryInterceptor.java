package bg.demax.motor.exam.result.rest.db;

import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.postgresql.util.PSQLException;
import org.springframework.core.Ordered;
import org.springframework.transaction.annotation.Transactional;

@Aspect
public class CustomTransactionRetryInterceptor implements Ordered {

	private final Log logger = LogFactory.getLog(getClass());

	private int order = 1;
	private int maxRetries = -1;
	private int randomSleepMillis = -1;

	private static ThreadLocal<Boolean> mEntered = new ThreadLocal<Boolean>();
	private static ThreadLocal<String> mActiveManager = new ThreadLocal<String>();
	private static AtomicLong transactionSerial = new AtomicLong();

	@Override
	public int getOrder() {
		return this.order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public void setMaxRetries(int maxRetries) {
		this.maxRetries = maxRetries;
	}

	public void setRandomSleepMillis(int randomSleepMillis) {
		this.randomSleepMillis = randomSleepMillis;
	}

	private Throwable getRootCause(Throwable ex) {
		while (ex.getCause() != null) {
			ex = ex.getCause();
		}

		return ex;
	}

	@Around("@annotation(org.springframework.transaction.annotation.Transactional) and @annotation(annotation)")
	public Object retry(ProceedingJoinPoint call, Transactional annotation) throws Throwable {

		if (mEntered.get() != null) {
			if (!mActiveManager.get().equals(annotation.value())) {
				logger.warn("!!! WARNING: INVOKING OTHER DB FROM RUNNING TRANSACTION !!!");
			}
			return call.proceed(); // retry only top level transactions
		}

		mEntered.set(new Boolean(true));
		mActiveManager.set(annotation.value());
		long currentTransactionSerial = transactionSerial.addAndGet(1);

		try {
			int numAttempts = 0;

			do {
				numAttempts++;

				try {
					Object returnValue = call.proceed();
					return returnValue;
				} catch (Throwable ex) {
					boolean bRetry = false;

					if (getRootCause(ex) instanceof PSQLException) {
						PSQLException psqlException = (PSQLException) getRootCause(ex);
						if (psqlException.getSQLState().equals("40001")) { // serialization error
							logger.warn("WARNING: SN: " + currentTransactionSerial
								+ ", TRANSACTION ROLLBACK DUE TO SERIALIZATION ERROR, RETRYING !!!");
							bRetry = true;
						} else if (psqlException.getSQLState().equals("40P01")) { // deadlock
							logger.warn("WARNING: SN: " + currentTransactionSerial
									+ ", TRANSACTION ROLLBACK DUE TO DEADLOCK, RETRYING !!!");
							bRetry = true;
						}
					}

					if (!bRetry || (numAttempts >= maxRetries && maxRetries > 0)) {
						if ((numAttempts >= maxRetries && maxRetries > 0)) {
							logger.warn("WARNING: SN:" + currentTransactionSerial
									+ ", TRANSACTION RETRY LIMIT REACHED, THROWING !!!");
						}

						throw ex;
					}

					if (randomSleepMillis > 0) {
						Thread.sleep(Math.round(Math.random() * randomSleepMillis));
					}
				}
			} while (true);
		} finally {
			mEntered.set(null);
			mActiveManager.set(null);
		}
	}
}
