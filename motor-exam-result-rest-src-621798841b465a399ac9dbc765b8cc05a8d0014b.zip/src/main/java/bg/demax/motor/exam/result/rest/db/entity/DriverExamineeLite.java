package bg.demax.motor.exam.result.rest.db.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import bg.demax.motor.exam.result.entity.ExamResult;
import lombok.Getter;
import lombok.Setter;

@Entity
@Immutable
@Table(schema = "theoretical_exams", name = "driver_examinees")
@PrimaryKeyJoinColumn(name = "examinee_id")
@Getter
@Setter
public class DriverExamineeLite extends TheoreticalExamineeLite {

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "exam_result_id", nullable = false)
	private ExamResult examResult;


}
