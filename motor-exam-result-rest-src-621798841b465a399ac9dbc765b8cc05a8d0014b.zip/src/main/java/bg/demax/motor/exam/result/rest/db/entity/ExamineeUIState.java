package bg.demax.motor.exam.result.rest.db.entity;
 
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
 
import org.hibernate.annotations.NaturalId;
 
@Entity
@Table(schema = "theoretical_exams", name = "n_examinee_ui_states")
public class ExamineeUIState {
    
    public static final int START = 1;
    public static final int CONFIRMATION = 2;
    public static final int TUTORIAL = 3;
    public static final int EXAM = 4;
    public static final int RESULT = 5;
    public static final int FINISHED = 6;
    public static final int REVIEW = 7;
    public static final int ASSESSING = 8;
    public static final int STAGE_RESULT = 9;
 
    @Id
    private Integer id = null;
 
    @NaturalId
    @Column(name = "name", nullable = false, length = 32, unique = true)
    private String name;
 
    public Integer getId() {
        return id;
    }
 
    public void setId(Integer id) {
        this.id = id;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
}