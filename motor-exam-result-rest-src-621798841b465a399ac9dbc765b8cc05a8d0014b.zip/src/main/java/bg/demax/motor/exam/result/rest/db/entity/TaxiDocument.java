package bg.demax.motor.exam.result.rest.db.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.pub.entity.Employee;
import bg.demax.pub.entity.Municipality;
import bg.demax.pub.entity.OrgUnit;
import bg.demax.pub.entity.SubjectVersion;
import lombok.Getter;
import lombok.Setter;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(schema = "motor_exam_result", name = "taxi_documents")
@Getter
@Setter
public class TaxiDocument {
	
	public static final int VALIDITY_DURATION_YEARS = 5;
	public static final LocalDate MIN_DRIVER_PROLONG_DATE = LocalDate.of(2018, 6, 30);
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Access(AccessType.PROPERTY)
	private Long id = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "subj_version_id")
	private SubjectVersion subjectVersion;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "mun_code", nullable = false, referencedColumnName = "code"),
				 @JoinColumn(name = "region_code", nullable = false, referencedColumnName = "region_code") })
	private Municipality municipality;
	
	@Column(name = "document_number")
	private Integer documentNumber;
	
	@Column(name = "previous_document_number")
	private Integer previousDocumentNumber;
	
	@Column(name = "valid_from")
	private LocalDate validFrom;
	
	@Column(name = "valid_till")
	private LocalDate validTill;
	
	@Column(name = "protocol_number")
	private Integer protocolNumber;
	
	@Column(name = "protocol_date")
	private LocalDateTime protocolDate;
	
	@Column(name = "cancellation_remark")
	private String cancellationRemark;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "org_unit_code", insertable = false, updatable = false)
	private OrgUnit orgUnit;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "org_unit_code")
	private Employee employee;
	
	@Column(name = "creation_timestamp")
	private LocalDateTime creationTimeStamp;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status", insertable = false, updatable = false)
	private TaxiDocumentStatus status;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "doc_type", insertable = false, updatable = false)
	private TaxiDocumentType type;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "exam_result_id")
	private ExamResult examResult;
	
	@Column(name = "provided_document_file_path")
	private String providedDocumentFilePath;
}
