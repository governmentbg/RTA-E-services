package bg.demax.motor.exam.result.rest.db.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Getter;
import lombok.Setter;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(schema = "motor_exam_result", name = "n_taxi_document_staus")
@Getter
@Setter
@Immutable
public class TaxiDocumentStatus {
	public static final String VALID = "VALID";
	public static final String DUPLICATE = "DUPLICATE";

	@Id
	@Column(name = "code", nullable = false)
	private String code;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "is_valid")
	private boolean valid;
}
