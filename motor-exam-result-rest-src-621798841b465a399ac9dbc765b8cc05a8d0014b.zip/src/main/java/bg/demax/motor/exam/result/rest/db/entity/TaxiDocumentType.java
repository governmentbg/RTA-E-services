package bg.demax.motor.exam.result.rest.db.entity;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Getter;
import lombok.Setter;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(schema = "motor_exam_result", name = "n_taxi_document_type")
@Getter
@Setter
@Immutable
public class TaxiDocumentType {
	
	public static final int DRIVER_ID = 1;
	public static final int DRIVER_PROLONG_ID = 2;
	public static final int MANAGER_ID = 3;

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Access(AccessType.PROPERTY)
	private Integer id;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "is_valid")
	private boolean valid;
}
