package bg.demax.motor.exam.result.rest.db.entity;



import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Getter;
import lombok.Setter;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Table(schema = "theoretical_exams", name = "examinees")
@Getter
@Setter
@Immutable
public class TheoreticalExamineeLite {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Access(AccessType.PROPERTY)
	private Long id = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ui_state_id", nullable = true)
	private ExamineeUIState uiState = null;

}
