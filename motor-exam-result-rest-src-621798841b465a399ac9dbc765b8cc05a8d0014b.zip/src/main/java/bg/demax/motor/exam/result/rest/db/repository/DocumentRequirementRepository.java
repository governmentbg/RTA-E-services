package bg.demax.motor.exam.result.rest.db.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.motor.exam.result.entity.DocumentRequirement;

@Repository
public interface DocumentRequirementRepository extends JpaRepository<DocumentRequirement, Long> {

}
