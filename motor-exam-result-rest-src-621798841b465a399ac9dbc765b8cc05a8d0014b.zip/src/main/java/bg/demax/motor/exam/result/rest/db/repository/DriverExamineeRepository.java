package bg.demax.motor.exam.result.rest.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.rest.db.entity.DriverExamineeLite;

@Repository
public interface DriverExamineeRepository extends JpaRepository<DriverExamineeLite, Long> {

	@Query("select 1 from DriverExamineeLite de "
			+"join de.examResult er "
			+"where er = :examResult "
			+"and (de.uiState.id not in (:finishedStates) "
			+"or de.uiState is NULL) "
			+"and er.remark not like '%NOT_PRESENT%' " )
	Integer isExamResultInProtocolInProgress(@Param("examResult") ExamResult examResult, 
											 @Param("finishedStates") List<Integer> inFinishedStates);

}
