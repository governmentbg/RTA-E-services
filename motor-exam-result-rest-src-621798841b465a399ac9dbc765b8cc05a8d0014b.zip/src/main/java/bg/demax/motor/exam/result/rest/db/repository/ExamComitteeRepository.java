package bg.demax.motor.exam.result.rest.db.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import bg.demax.motor.exam.result.entity.ExamCommittee;

@Repository
public interface ExamComitteeRepository extends JpaRepository<ExamCommittee, Long>{

}
