package bg.demax.motor.exam.result.rest.db.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.exams.entity.SubCategory;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.pub.entity.Subject;

@Repository
public interface ExamPersonRepository extends JpaRepository<ExamPerson, Long> {
	
	static final String DESCRIPTION_157 = "'%157%'"; //TODO move to entity
	static final String DESCRIPTION_426 = "'%426%'"; // TODO move to entity

	@Query("SELECT DISTINCT ep "
			+ "FROM ExamPerson ep "
			+ "JOIN ep.subjectVersion sv "
			+ "JOIN sv.subject s "
			+ "JOIN ep.learningPlan lp "
			+ "JOIN lp.targetCategory tc "
			+ "JOIN lp.requirements r "
			+ "WHERE ep.completedAt is NULL "
			+ "AND r.id = :examRequirenentId "
			+ "AND s.identityNumber like :personalIdentityNumber "
			+ "ORDER BY ep.id ASC")
	List<ExamPerson> findForExamEnrolmentByPersonalIdentityNumberAndExamRequirementId(
			@Param("personalIdentityNumber") String personalIdentityNumber,
			@Param("examRequirenentId") Long examRequirenentId);
	
	@Query("SELECT DISTINCT ep "
			+ "FROM ExamPerson ep "
			+ "JOIN ep.subjectVersion sv "
			+ "JOIN sv.subject s "
			+ "JOIN ep.learningPlan lp "
			+ "JOIN lp.targetCategory tc "
			+ "JOIN lp.requirements r "
			+ "WHERE ep.completedAt is NULL "
			+ "AND r.id = :examRequirenentId "
			+ "AND s.identityNumber like :personalIdentityNumber "
			+ "AND tc.id = :categoryId "
			+ "ORDER BY ep.id ASC")
	List<ExamPerson> findForExamEnrolmentByPersonalIdentityNumberAndExamRequirementId(
			@Param("personalIdentityNumber") String personalIdentityNumber,
			@Param("examRequirenentId") Long examRequirenentId,
			@Param("categoryId") Integer categoryId);

	@Query("from ExamPerson "
			+ "where subjectVersion.subject.identityNumber = :identityNumber "
			+ "and (learningPlan.description like " + DESCRIPTION_157
			+ " or learningPlan.description like " + DESCRIPTION_426
			+ " ) order by registeredAt desc")
	ExamPerson getLatestWithLicenceLostLearningPlan(@Param("identityNumber") String identityNumber);

	@Query("SELECT ep FROM ExamPerson ep "
			+ "WHERE ep.subjectVersion.subject.identityNumber = :identityNumber "
			+ "AND completedAt IS NOT NULL")
	List<ExamPerson> getCompletedExamPeopleForidentityNumber(@Param("identityNumber") String identityNumber);

	@Query("from ExamPerson where subjectVersion.subject.identityNumber = :identityNumber "
			+ "and learningPlan.description like :description "
			+ "order by registeredAt desc")
	ExamPerson getLatestWithDescriptionLearningPlan(@Param("identityNumber") String identityNumber,
													@Param("description") String description);

	@Query("from ExamPerson "
			+ "where subjectVersion.subject = :subject "
			+ "and learningPlan.targetCategory = :category")
	Set<ExamPerson> getAllForSubjectAndCategory(@Param("subject") Subject subject,
												@Param("category") SubCategory targetCategory);

	@Query("SELECT ep FROM ExamPerson ep "
			+ "WHERE ep.subjectVersion.subject.identityNumber = :identityNumber "
			+ "AND completedAt IS NOT NULL "
			+ "AND ep.learningPlan.targetCategory = :subCategory "
			+ "AND ep.completedAt >= :completedAtAfter "
			+ "ORDER BY ep.completedAt DESC ")
	List<ExamPerson> getLatestCompletedForIdentNumAndCategoryAfter(@Param("identityNumber") String identityNumber, 
			@Param("subCategory") SubCategory subCategory, 
			@Param("completedAtAfter") LocalDateTime completedAtAfter);

	@Query("SELECT ep FROM ExamPerson ep "
			+ "WHERE ep.subjectVersion.subject.identityNumber = :identityNumber "
			+ "AND completedAt IS NOT NULL "
			+ "AND ep.learningPlan.targetCategory = :subCategory "
			+ "ORDER BY ep.completedAt DESC ")
	List<ExamPerson> getLatestCompletedForIdentNumAndCategoryAfter(@Param("identityNumber") String identityNumber, 
			@Param("subCategory") SubCategory subCategory);

	@Query("FROM ExamPerson ep "
			+ "WHERE ep.subjectVersion.subject = :subject "
			+ "AND ep.completedAt IS NULL ")
	List<ExamPerson> getActiveForSubject(@Param("subject") Subject subject);

	@Query("SELECT DISTINCT p FROM ExamPerson p "
			+ "JOIN p.examResults er "
			+ "JOIN er.protocol proto WITH proto.examTime < CURRENT_DATE() "
			+ "WHERE p.subjectVersion.subject = :subject AND p.learningPlan = :learningPlan "
			+ "AND p.completedAt IS NULL "
			+ "AND p.company.number != :excludedPermitNumber")
	List<ExamPerson> getActiveForSubjectAndLearningPlanWithExams(
			@Param("subject") Subject subject, 
			@Param("learningPlan") LearningPlan learningPlan, 
			@Param("excludedPermitNumber") int excludedPermitNumber);
	
	@Query("SELECT DISTINCT p FROM ExamPerson p "
			+ "JOIN p.examResults er "
			+ "JOIN er.protocol proto WITH proto.examTime < CURRENT_DATE() "
			+ "WHERE p.subjectVersion.subject = :subject AND p.learningPlan = :learningPlan "
			+ "AND p.completedAt IS NULL ")
	List<ExamPerson> getActiveForSubjectAndLearningPlanWithExams(
			@Param("subject") Subject subject, 
			@Param("learningPlan") LearningPlan learningPlan);
}
