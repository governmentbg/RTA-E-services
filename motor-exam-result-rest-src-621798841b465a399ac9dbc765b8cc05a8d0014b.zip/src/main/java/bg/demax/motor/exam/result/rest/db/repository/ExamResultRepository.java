package bg.demax.motor.exam.result.rest.db.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.exams.entity.SubCategory;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.pub.entity.Subject;

@Repository
public interface ExamResultRepository extends JpaRepository<ExamResult, Long> {

	@Query("FROM ExamResult WHERE examPerson.subjectVersion.subject.identityNumber = :identityNumber "
			+ "AND examPerson.learningPlan.targetCategory = :subCategory "
			+ "AND protocol.examType.id = :examTypeId AND isPassed IS NOT NULL "
			+ "AND (remark IS NULL OR remark NOT LIKE '%АНУЛИРАН%') "
			+ "ORDER BY protocol.examTime DESC")
	List<ExamResult> getLastValid(@Param("identityNumber") String identityNumber,
							@Param("subCategory") SubCategory subCategoryToCheck,
							@Param("examTypeId") long examTypeId);
	
	@Query("from ExamResult "
			+ "where isPassed is not null "
			+ "and examPerson.subjectVersion.subject = :subject "
			+ "and examPerson.learningPlan.targetCategory = :subCategory "
			+ "and protocol.examType.id = :examTypeId "
			+ "and (remark is null or remark not like '%АНУЛИРАН%') "
			+ "and protocol.examTime >= :after "
			+ "order by protocol.examTime desc ")
	List<ExamResult> getLatestValid(@Param("subject") Subject subject,
							 @Param("subCategory") SubCategory subCategoryToCheck,
							 @Param("examTypeId") long examTypeId,
							 @Param("after")LocalDateTime localDateTime);
	
	@Query("from ExamResult "
			+ "where isPassed is not null "
			+ "and examPerson.subjectVersion.subject = :subject "
			+ "and examPerson.learningPlan.targetCategory = :subCategory "
			+ "and protocol.examType.id = :examTypeId "
			+ "and (remark is null or remark not like '%АНУЛИРАН%') "
			+ "order by protocol.examTime desc ")
	List<ExamResult> getLatestValid(@Param("subject") Subject subject,
							 @Param("subCategory") SubCategory subCategoryToCheck,
							 @Param("examTypeId") long examTypeId);

	@Query("from ExamResult where examPerson.subjectVersion.subject = :subject "
			+ "and examPerson.learningPlan.targetCategory = :subCategory "
			+ "and protocol.examType = :examType "
			+ "and protocol.examTime >= :date "
			+ "and isPassed = true ")
	List<ExamResult> findPassedExamResultsAfter(@Param("subject") Subject subject,
			                                    @Param("subCategory") SubCategory subCategoryToCheck,
			                                    @Param("examType") ExamRequirement examType,
			                                    @Param("date") LocalDateTime latestLicenceLossDate);
	
	@Query("from ExamResult where examPerson.subjectVersion.subject = :subject "
			+ "and examPerson.learningPlan.targetCategory = :subCategory "
			+ "and protocol.examType = :examType "
			+ "and isPassed = true ")
	List<ExamResult> findPassedExamResultsAfter(@Param("subject") Subject subject,
			                                    @Param("subCategory") SubCategory subCategoryToCheck,
			                                    @Param("examType") ExamRequirement examType);

	@Query("from ExamResult where examPerson.subjectVersion.subject.identityNumber = :identityNumber "
			+ "and examPerson.learningPlan.targetCategory = :subCategory "
			+ "and protocol.examTime >= :after "
			+ "and isPassed = false "
			+ "and remark like '%АНУЛИРАН%'")
	List<ExamResult> findInvalidatedForidentityNumberAndCategoryAfter(@Param("identityNumber") String identityNumber, 
																@Param("subCategory") SubCategory subCategory, 
																@Param("after") LocalDateTime after);

	
}
