package bg.demax.motor.exam.result.rest.db.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.motor.exam.result.entity.ExamRequirement;

@Repository
public interface ExamTypeRepository extends JpaRepository<ExamRequirement, Long> {

}
