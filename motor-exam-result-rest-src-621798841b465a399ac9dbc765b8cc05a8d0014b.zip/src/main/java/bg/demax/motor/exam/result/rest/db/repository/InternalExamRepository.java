package bg.demax.motor.exam.result.rest.db.repository;

import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.exams.entity.SubCategory;
import bg.demax.motor.exam.result.entity.InternalExam;

@Repository
public interface InternalExamRepository extends JpaRepository<InternalExam, Long> {

	@Query( "from InternalExam where invalidatedAt is null "
			+ "and examPerson.subjectVersion.subject.identityNumber = :identityNumber "
			+ "and examPerson.learningPlan.targetCategory = :subCategory "
			+ "and examType.id = :examTypeId "
			+ "order by date desc")
	InternalExam getLastPassedInternalExamBetween(@Param("identityNumber")String identityNumber,
												  @Param("subCategory") SubCategory subCategoryToCheck,
												  @Param("examTypeId") long examTypeId);
	
	@Query( "from InternalExam where invalidatedAt is null "
			+ "and examPerson.subjectVersion.subject.identityNumber = :identityNumber "
			+ "and examPerson.learningPlan.targetCategory = :subCategory "
			+ "and examType.id = :examTypeId "
			+ "and date >= :from "
			+ "and date <= :to "
			+ "order by date desc")
	InternalExam getLastPassedInternalExamBetween(@Param("identityNumber")String identityNumber,
												  @Param("subCategory") SubCategory subCategoryToCheck,
												  @Param("examTypeId") long examTypeId,
												  @Param("from")LocalDate from, 
												  @Param("to") LocalDate to);

}
