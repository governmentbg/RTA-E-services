package bg.demax.motor.exam.result.rest.db.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.exams.entity.Language;

@Repository
public interface LanguageRepository extends JpaRepository<Language, Integer> {

}
