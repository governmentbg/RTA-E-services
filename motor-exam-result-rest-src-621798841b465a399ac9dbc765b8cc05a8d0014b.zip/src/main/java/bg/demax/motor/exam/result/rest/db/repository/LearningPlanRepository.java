package bg.demax.motor.exam.result.rest.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.motor.exam.result.entity.LearningPlan;

@Repository
public interface LearningPlanRepository extends JpaRepository<LearningPlan, Long> {

	@Query("SELECT DISTINCT lp "
			+ "FROM LearningPlan lp " 
			+ "WHERE lp.targetCategory.id = :categoryId " 
			+ "ORDER BY lp.id ASC ")
	List<LearningPlan> findByCategoryId(@Param("categoryId") int categoryId);
}
