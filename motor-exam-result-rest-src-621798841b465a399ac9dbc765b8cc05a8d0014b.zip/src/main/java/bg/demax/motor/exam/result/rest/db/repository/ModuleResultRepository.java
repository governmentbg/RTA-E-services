package bg.demax.motor.exam.result.rest.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.exams.entity.SubCategory;
import bg.demax.motor.exam.result.entity.ModuleResult;
import bg.demax.motor.exam.result.entity.ModuleResult.ModuleResultId;
import bg.demax.pub.entity.Subject;

@Repository
public interface ModuleResultRepository extends JpaRepository<ModuleResult, ModuleResultId> {

	@Query("from ModuleResult where invalidatedAt is null "
			+ "and passedAt is not null "
			+ "and id.examPerson.subjectVersion.subject.identityNumber = :identityNumber")
	List<ModuleResult> getAllPassedForidentityNumber(@Param("identityNumber") String identityNumber);

	@Query("from ModuleResult "
			+ "where invalidatedAt is null "
			+ "and id.examPerson.subjectVersion.subject = :subject "
			+ "and id.examPerson.learningPlan.targetCategory = :targetCategory "
			+ "and id.moduleRequirement.id = :moduleRequirementId and passedAt is not null "
			+ "order by passedAt desc")
	ModuleResult getLatestPassedModuleResult(@Param("moduleRequirementId") long moduleRequirementId,
											 @Param("subject") Subject subject,
											 @Param("targetCategory") SubCategory subCategoryToCheck);

}
