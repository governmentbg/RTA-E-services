package bg.demax.motor.exam.result.rest.db.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.pub.entity.Municipality;
import bg.demax.pub.entity.Municipality.MunicipalityId;

@Repository
public interface MunicipalityRepository extends JpaRepository<Municipality, MunicipalityId> {

}
