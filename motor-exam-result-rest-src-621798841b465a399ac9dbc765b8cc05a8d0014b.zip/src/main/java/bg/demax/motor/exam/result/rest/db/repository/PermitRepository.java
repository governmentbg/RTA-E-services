package bg.demax.motor.exam.result.rest.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.motor.exam.permit.entity.Permit;
import bg.demax.pub.entity.OrgUnit;

@Repository
public interface PermitRepository extends JpaRepository<Permit, Long> {

	@Query("SELECT p FROM Permit p "
			+ "JOIN FETCH p.company c "
			+ "JOIN FETCH c.subject "
			+ "WHERE p.validTo >= current_date() "
			+ "AND (p.ceaseDate IS NULL OR p.ceaseDate > current_date()) "
			+ "AND p.orgUnit = :orgUnit "
			+ "AND p.company.subject.identityNumber = '" + Permit.IAAA_PERMIT_COMPANY_EIK + "' "
			+ "ORDER BY p.id DESC ")
	List<Permit> getLastIaaaPermitForOrgUnit(@Param("orgUnit") OrgUnit orgUnit);

	@Query("FROM Permit "
			+ "WHERE number = :number "
			+ "AND validTo >= current_date() "
			+ "AND (ceaseDate is null OR ceaseDate > current_date()) "
			+ "AND (status = 'issued' OR status = 'signed') ")
	Permit getLastValidPermit(@Param("number") int number);

}
