package bg.demax.motor.exam.result.rest.db.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.motor.exam.permit.entity.Permit;
import bg.demax.motor.exam.result.practical.entity.PracticalExamRoadDuration;

@Repository
public interface PracticalExamRoadDurationRepository extends JpaRepository<Permit, Long> {

	@Query("from PracticalExamRoadDuration where subCategory.id = :subCategoryId")
	PracticalExamRoadDuration getForSubCategory(@Param("subCategoryId") Integer subCategoryId);
}
