package bg.demax.motor.exam.result.rest.db.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.practical.entity.PracticalExamStateCandidate;
import bg.demax.motor.exam.result.practical.entity.PracticalExamStateCandidateId;

@Repository
public interface PracticalExamStateCandidateRepository extends JpaRepository<PracticalExamStateCandidate, PracticalExamStateCandidateId> {

	@Query("select 1 from PracticalExamState pes "
			+ "where pes.protocol = :protocol "
			+ "and pes.isActive is true ")
	Integer isExamResultInProtocolInProgress(@Param("protocol")Protocol protocol);

}
