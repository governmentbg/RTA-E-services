package bg.demax.motor.exam.result.rest.db.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.motor.exam.result.entity.ProvidedCategory;

@Repository
public interface ProvidedCategoryRepository extends JpaRepository<ProvidedCategory, Long> {

	@Query("from ProvidedCategory "
		 + "where examPerson.subjectVersion.subject.identityNumber = :identityNumber")
	List<ProvidedCategory> getAllForidentityNumberAfter(@Param("identityNumber") String identityNumber);

	@Query("from ProvidedCategory "
			 + "where examPerson.subjectVersion.subject.identityNumber = :identityNumber"
			 + " and date >= :afterDate"
			)
	List<ProvidedCategory> getAllForidentityNumberAfter(@Param("identityNumber")String identityNumber,
												  @Param("afterDate") LocalDateTime latestLostDate);

}
