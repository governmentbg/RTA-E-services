package bg.demax.motor.exam.result.rest.db.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.motor.exam.result.entity.ProvidedDocument;

@Repository
public interface ProvidedDocumentRepository extends JpaRepository<ProvidedDocument, Long> {
	
	public static final long DRIVER_LICENCE_LOSS_157 = 103L; //TODO move to entity
	public static final long DRIVER_LICENCE_LOSS_426 = 532L; //TODO move to entity

	@Query("from ProvidedDocument "
			+ "where examPerson.subjectVersion.subject.identityNumber = :identityNumber "
			+ "and (documentRequirement.id = " + DRIVER_LICENCE_LOSS_157
			+ " or documentRequirement.id = " + DRIVER_LICENCE_LOSS_426
			+ ") order by issueDate desc")
	ProvidedDocument getLatestDrvLicenceLoss(@Param("identityNumber")String identityNumber);

	@Query("from ProvidedDocument where examPerson.subjectVersion.subject.identityNumber = :identityNumber "
			+ "and documentRequirement.id = :documentRequirementId "
			+ "order by issueDate desc")
	ProvidedDocument getLatestDrvLicence(@Param("identityNumber") String identityNumber, 
										 @Param("documentRequirementId") Long documentRequirementId);
}
