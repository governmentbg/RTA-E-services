package bg.demax.motor.exam.result.rest.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.exams.entity.SubCategory;
import bg.demax.motor.exam.result.entity.SubCategoryTransition;
import bg.demax.motor.exam.result.entity.SubCategoryTransition.SubCategoryTransitionId;

@Repository
public interface SubCategoryTransitionRepository extends JpaRepository<SubCategoryTransition, SubCategoryTransitionId> {

	@Query("select distinct sct.id.fromSubCategory from SubCategoryTransition sct where sct.id.toSubCategory = :toCategory")
	List<SubCategory> getParentCategories(@Param("toCategory") SubCategory subCategory);

}
