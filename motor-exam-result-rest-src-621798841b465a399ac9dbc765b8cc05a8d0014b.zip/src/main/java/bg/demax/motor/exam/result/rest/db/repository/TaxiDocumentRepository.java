package bg.demax.motor.exam.result.rest.db.repository;

import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.motor.exam.result.rest.db.entity.TaxiDocument;
import bg.demax.pub.entity.Municipality;

@Repository
public interface TaxiDocumentRepository extends JpaRepository<TaxiDocument, Long>{

	@Query("select 1 FROM TaxiDocument t "
			+ "where t.subjectVersion.id = :subjVersionId "
			+ "and t.protocolDate = :protocolDate ")
	Boolean taxiDocumentAlreadyAssignedToProtocol(@Param("subjVersionId") Long subjVersionId,
												   @Param("protocolDate")  LocalDateTime protocolExamTime);
	
	@Query("select 1 FROM TaxiDocument t "
			+ "where t.subjectVersion.id = :subjVersionId "
			+ "and t.protocolDate = :protocolDate "
			+ "and t.protocolNumber = :protocolNumber "
			)
	Boolean taxiDocumentAlreadyAssignedToProtocol(@Param("subjVersionId") Long subjVersionId, 
													@Param("protocolDate")  LocalDateTime protocolExamTime,
													@Param("protocolNumber")  Integer protocolNumber);

	@Query("select 1 FROM TaxiDocument t "
			+ "where t.subjectVersion.subject.identityNumber = :identNum "
			+ "and t.type.id = :typeId "
			+ "and t.status.code = 'VALID'"
			+ "and t.id != :id "
			+"and t.municipality = :municipality ") 
	Boolean hasActiveTaxiDocumentExtensionForIdentNumber(@Param("id") Long docId,
															@Param("identNum") String identNumber,
															@Param("municipality") Municipality municipality,
															@Param("typeId") int typeId);

}
