package bg.demax.motor.exam.result.rest.dto;

import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateExamResultDto {
	
	@NotNull
	private Long examPersonId;
	
	@NotNull
	private Long protocolId;
	
	private String municipalityCode;
	
	private String municipalityRegionCode;
}
