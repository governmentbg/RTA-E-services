package bg.demax.motor.exam.result.rest.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor
@ToString
public class ErrorMessageDto {
	  private int statusCode;
	  private LocalDateTime timestamp;
	  private String error;
	  private String message;
	  private String description;
}
