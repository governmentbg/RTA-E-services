package bg.demax.motor.exam.result.rest.dto;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExamPersonDto {
	
	private Long examPersonId;
	private String learningPlanName;
    private LocalDateTime examDate; 
    private String theoreticalExamResult;
    private OrgUnitDto orgUnit;
}
