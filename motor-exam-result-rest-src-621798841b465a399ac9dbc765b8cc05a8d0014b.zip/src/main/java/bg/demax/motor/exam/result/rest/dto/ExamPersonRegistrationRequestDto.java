package bg.demax.motor.exam.result.rest.dto;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExamPersonRegistrationRequestDto {

	@NotBlank
	private String personalIdentityNumber;

	@NotBlank
	private String firstName;

	@NotBlank
	private String surname;

	@NotBlank
	private String familyName;

	private String firstNameLatin;
	private String surnameLatin;
	private String familyNameLatin;
	
	@NotBlank
	private String countryCode;

	@NotBlank
	private String regionCode;

	@NotNull
	private Long learningPlanId;

	@NotNull
	private String orgUnitCode;
	
	@NotNull
	@NotEmpty
	private List<@Valid @NotNull ProvidedDocumentRegistrationRequestDto> providedDocuments;

	private List<@Valid @NotNull ProvidedCategoryRegistrationRequestDto> providedCategories;
}
