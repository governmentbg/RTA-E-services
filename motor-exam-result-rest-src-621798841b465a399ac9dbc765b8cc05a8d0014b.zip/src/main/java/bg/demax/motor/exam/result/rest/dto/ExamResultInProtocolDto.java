package bg.demax.motor.exam.result.rest.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExamResultInProtocolDto {
	private Long examResultId;
    private ExamPersonDto examPerson;
    private ProtocolDto protocol;
}
