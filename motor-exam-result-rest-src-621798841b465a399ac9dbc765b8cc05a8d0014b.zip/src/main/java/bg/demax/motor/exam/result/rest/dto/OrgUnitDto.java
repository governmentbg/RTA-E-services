package bg.demax.motor.exam.result.rest.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrgUnitDto {
	
	private String code;
	private String name;
}
