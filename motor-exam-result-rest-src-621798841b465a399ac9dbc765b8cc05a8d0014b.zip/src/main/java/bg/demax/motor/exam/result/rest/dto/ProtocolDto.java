package bg.demax.motor.exam.result.rest.dto;

import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProtocolDto {

	private Long id;
	private String number;

	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDateTime examDateTime;

	private OrgUnitDto orgUnit;
	private String roomName;
	private Integer remainingSeats;
}
