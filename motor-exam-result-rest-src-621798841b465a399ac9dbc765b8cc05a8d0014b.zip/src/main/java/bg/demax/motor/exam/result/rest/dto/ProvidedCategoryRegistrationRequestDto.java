package bg.demax.motor.exam.result.rest.dto;

import java.time.LocalDate;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProvidedCategoryRegistrationRequestDto {

	@NotNull
	@Min(1)
	private Integer subCategoryId;

	@NotNull
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate date;
}
