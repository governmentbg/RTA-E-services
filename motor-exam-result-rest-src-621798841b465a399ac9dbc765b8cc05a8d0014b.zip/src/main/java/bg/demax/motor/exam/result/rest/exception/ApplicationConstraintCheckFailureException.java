package bg.demax.motor.exam.result.rest.exception;

import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;

public class ApplicationConstraintCheckFailureException extends ApplicationException {

	private static final long serialVersionUID = -7657623322858639286L;

	public ApplicationConstraintCheckFailureException(ConstraintCheckFailureException exception) {
		super(exception);
	}
}
