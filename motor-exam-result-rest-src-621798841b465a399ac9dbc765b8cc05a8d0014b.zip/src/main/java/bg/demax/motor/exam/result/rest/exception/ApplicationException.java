package bg.demax.motor.exam.result.rest.exception;

public class ApplicationException extends RuntimeException {

	private static final long serialVersionUID = 6436812137790875899L;

	public ApplicationException(String message) {
		super(message);
	}

	public ApplicationException(String message, Throwable cause) {
		super(message, cause);
	}

	public ApplicationException(String message, Object... args) {
		super(String.format(message, args));
	}

	public ApplicationException(Throwable cause) {
		super(cause);
	}

	public String getError() {
		return this.getClass().getSimpleName();
	}
}
