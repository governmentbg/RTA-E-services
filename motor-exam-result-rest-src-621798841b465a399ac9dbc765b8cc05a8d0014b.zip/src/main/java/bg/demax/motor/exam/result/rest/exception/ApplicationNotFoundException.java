package bg.demax.motor.exam.result.rest.exception;

public class ApplicationNotFoundException extends ApplicationException {

	private static final long serialVersionUID = 1681555098593910787L;

	public ApplicationNotFoundException(String message) {
		super(message);
	}

	public ApplicationNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public ApplicationNotFoundException(String message, Object... args) {
		super(String.format(message, args));
	}

	public ApplicationNotFoundException(Throwable cause) {
		super(cause);
	}

	public String getError() {
		return this.getClass().getSimpleName();
	}
}
