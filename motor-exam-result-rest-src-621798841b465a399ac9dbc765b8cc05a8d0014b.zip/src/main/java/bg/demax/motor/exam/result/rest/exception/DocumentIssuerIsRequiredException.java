package bg.demax.motor.exam.result.rest.exception;

public class DocumentIssuerIsRequiredException extends ApplicationException {

	private static final long serialVersionUID = -696498015379521628L;

	public DocumentIssuerIsRequiredException(long docRequirementId) {
		super("Document issuer is required for document with docRequirementId=" + docRequirementId);
	}
}
