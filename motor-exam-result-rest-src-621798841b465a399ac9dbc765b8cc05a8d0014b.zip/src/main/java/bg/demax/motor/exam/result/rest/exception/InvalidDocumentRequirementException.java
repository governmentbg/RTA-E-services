package bg.demax.motor.exam.result.rest.exception;

public class InvalidDocumentRequirementException extends ApplicationException {

	private static final long serialVersionUID = 7594263459970612809L;

	public InvalidDocumentRequirementException(long learningPlanId, long docRequirementId) {
		super("DocumentRequirement with id " + docRequirementId 
				+ " is not valid for LearningPlan with id " + learningPlanId);
	}
}
