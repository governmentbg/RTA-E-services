package bg.demax.motor.exam.result.rest.exception;

import java.io.Serializable;

public class NoSuchEntityException extends ApplicationNotFoundException {

	private static final long serialVersionUID = -8422653024986391423L;

	public NoSuchEntityException(Class<?> clazz, Serializable id) {
		super(clazz.getSimpleName() + " with id " + id + " not found.");
	}

	public NoSuchEntityException(String message) {
		super(message);
	}
}
