package bg.demax.motor.exam.result.rest.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.rest.db.entity.ExamineeUIState;
import bg.demax.motor.exam.result.rest.db.repository.DriverExamineeRepository;

@Service
public class DriverExamineeService {
	
	@Autowired
	private DriverExamineeRepository driverExamineeRepository;

	@Transactional(readOnly = true)
	public boolean isExamResultInProtocolInProgress(ExamResult examResult) {
		List<Integer> inFinishedStates =  new ArrayList<>();
		inFinishedStates.add(ExamineeUIState.RESULT);
		inFinishedStates.add(ExamineeUIState.FINISHED);
		inFinishedStates.add(ExamineeUIState.REVIEW);
		
		Integer isExamResultInProtocolInProgressNum = driverExamineeRepository
				.isExamResultInProtocolInProgress(examResult, inFinishedStates);
		
		return isExamResultInProtocolInProgressNum == null ? false : true;
	}

}
