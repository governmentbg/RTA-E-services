package bg.demax.motor.exam.result.rest.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.exams.entity.SubCategory;
import bg.demax.exams.util.SubCategoryUtil;
import bg.demax.hibernate.GenericFinder;
import bg.demax.legacy.util.constraint.ConstraintCheckDispatcher;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.motor.exam.permit.entity.Permit;
import bg.demax.motor.exam.result.entity.DocumentRequirement;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.entity.ProvidedCategory;
import bg.demax.motor.exam.result.entity.ProvidedDocument;
import bg.demax.motor.exam.result.rest.comparator.ExamPersonRegistrationDescComparator;
import bg.demax.motor.exam.result.rest.db.repository.ExamPersonRepository;
import bg.demax.motor.exam.result.rest.db.repository.ExamTypeRepository;
import bg.demax.motor.exam.result.rest.db.repository.LearningPlanRepository;
import bg.demax.motor.exam.result.rest.db.repository.PermitRepository;
import bg.demax.motor.exam.result.rest.db.repository.ProvidedCategoryRepository;
import bg.demax.motor.exam.result.rest.db.repository.ProvidedDocumentRepository;
import bg.demax.motor.exam.result.rest.db.repository.RegionRepository;
import bg.demax.motor.exam.result.rest.db.repository.SubCategoryRepository;
import bg.demax.motor.exam.result.rest.dto.ExamPersonEnrolmentDto;
import bg.demax.motor.exam.result.rest.dto.ExamPersonRegistrationRequestDto;
import bg.demax.motor.exam.result.rest.dto.ExamPersonRegistrationResponseDto;
import bg.demax.motor.exam.result.rest.dto.ProvidedCategoryRegistrationRequestDto;
import bg.demax.motor.exam.result.rest.dto.ProvidedDocumentRegistrationRequestDto;
import bg.demax.motor.exam.result.rest.exception.ApplicationException;
import bg.demax.motor.exam.result.rest.exception.DocumentIssuerIsRequiredException;
import bg.demax.motor.exam.result.rest.exception.InvalidDocumentRequirementException;
import bg.demax.motor.exam.result.rest.exception.NoSuchEntityException;
import bg.demax.motor.exam.result.rest.util.ExamPersonUtil;
import bg.demax.motor.exam.result.rest.validation.AdditionalPracticalTrainingIsPassedArgs;
import bg.demax.motor.exam.result.rest.validation.AdditionalPracticalTrainingIsRequiredArgs;
import bg.demax.motor.exam.result.rest.validation.CategoryIsNotAlreadyAcquiredArgs;
import bg.demax.motor.exam.result.rest.validation.ExamAgeIsValidArgs;
import bg.demax.motor.exam.result.rest.validation.ExamPersonIsNotInFutureProtocolArgs;
import bg.demax.motor.exam.result.rest.validation.ExamPersonIsNotInProtocolInProgressArgs;
import bg.demax.motor.exam.result.rest.validation.ExternalExamIsNotPassedArgs;
import bg.demax.motor.exam.result.rest.validation.ExternalExamIsPassedArgs;
import bg.demax.motor.exam.result.rest.validation.LearningPlanIsFulfilledArgs;
import bg.demax.motor.exam.result.rest.validation.PermitHasCategoryArgs;
import bg.demax.motor.exam.result.rest.validation.PermitSupportsExamTypeArgs;
import bg.demax.motor.exam.result.rest.validation.PreviousExternalExamsForLearnningPlanPassedArgs;
import bg.demax.motor.exam.result.rest.validation.ProvidedCategoryIsStillValidArgs;
import bg.demax.motor.exam.result.rest.validation.TrainingIsPassedArgs;
import bg.demax.motor.exam.result.rest.validation.check.registration.ExamPersonRegistrationIsValidArgs;
import bg.demax.motor.exam.result.rest.validation.check.registration.IndividualTrainingIsNotMandatoryArgs;
import bg.demax.motor.exam.result.rest.vo.UnavailableCandidateVo.UnavailabilityReason;
import bg.demax.pub.entity.Country;
import bg.demax.pub.entity.OrgUnit;
import bg.demax.pub.entity.Region;
import bg.demax.pub.entity.Subject;
import bg.demax.pub.entity.SubjectDictionary;
import bg.demax.pub.entity.SubjectVersion;
import bg.demax.pub.service.SubjectService;

@Service
public class ExamPersonService {

	@Autowired
	private GenericFinder genericFinder;

	@Autowired
	private ExamPersonRepository examPersonRepository;

	@Autowired
	private ProvidedDocumentRepository providedDocumentRepository;

	@Autowired
	private ConstraintCheckDispatcher constraintCheckDispatcher;

	@Autowired
	private ExamTypeRepository examTypeRepository;

	@Autowired
	private ProvidedCategoryRepository providedCategoryRepository;

	@Autowired
	private SubCategoryRepository subCategoryRepository;

	@Autowired
	private ConversionService conversionService;

	@Autowired
	private SubjectService subjectService;

	@Autowired
	private PermitRepository permitRepository;

	@Autowired
	private LearningPlanRepository learningPlanRepository;

	@Autowired
	private RegionRepository regionRepository;
	
	@Transactional(readOnly = true)
	public List<ExamPersonEnrolmentDto> getExamPeopleForExamEnrolment(String personalIdentityNumber, long examTypeId,
			Integer categoryId) {

		List<ExamPerson> examPeople;
		if (categoryId != null) {
			examPeople = examPersonRepository.findForExamEnrolmentByPersonalIdentityNumberAndExamRequirementId(
					personalIdentityNumber, examTypeId, categoryId);
		} else {
			examPeople = examPersonRepository
					.findForExamEnrolmentByPersonalIdentityNumberAndExamRequirementId(personalIdentityNumber, examTypeId);
		}

		List<ExamPerson> availableExamPeople = new LinkedList<>();
		for (ExamPerson examPerson : examPeople) {
			UnavailabilityReason unavailabilityReason = getUnmetRequirementForExam(examPerson, examTypeId, LocalDate.now());
			if (unavailabilityReason == null) {
				availableExamPeople.add(examPerson);
			}
		}

		List<ExamPersonEnrolmentDto> dtos = conversionService.convertList(availableExamPeople, ExamPersonEnrolmentDto.class);
		return dtos;
	}

	public UnavailabilityReason getUnmetRequirementForExam(ExamPerson examPerson, long examTypeId, LocalDate checkDate) {
		try {
			constraintCheckDispatcher.check(new ExamAgeIsValidArgs(examPerson, examTypeId, checkDate));
		} catch (ConstraintCheckFailureException e) {
			return UnavailabilityReason.AGE;
		}

		try {
			constraintCheckDispatcher
					.check(new TrainingIsPassedArgs(examPerson, examTypeId == ExamRequirement.ID_EXTERNAL_PRACTICAL, checkDate));
		} catch (ConstraintCheckFailureException e) {
			try {
				constraintCheckDispatcher
						.check(new PreviousExternalExamsForLearnningPlanPassedArgs(examPerson, checkDate, examTypeId)); // if true
																														// he can
																														// be
																														// added
																														// to
																														// protocol
			} catch (ConstraintCheckFailureException ex) {
				return UnavailabilityReason.INTERNAL_EXAM;
			}
		}

		try {
			constraintCheckDispatcher.check(new ExternalExamIsNotPassedArgs(examPerson, checkDate, examTypeId));
		} catch (ConstraintCheckFailureException e) {
			return UnavailabilityReason.PASSED;
		}

		try {
			constraintCheckDispatcher.check(new ExamPersonIsNotInProtocolInProgressArgs(examPerson));
		} catch (ConstraintCheckFailureException e) {
			return UnavailabilityReason.IN_PROGRESS;
		}

		try {
			constraintCheckDispatcher.check(
					new ExamPersonIsNotInFutureProtocolArgs(examPerson, examTypeId == ExamRequirement.ID_EXTERNAL_PRACTICAL));
		} catch (ConstraintCheckFailureException e) {
			return UnavailabilityReason.IN_PROGRESS;
		}

		if (examTypeId == ExamRequirement.ID_EXTERNAL_PRACTICAL) {
			try {
				constraintCheckDispatcher
						.check(new ExternalExamIsPassedArgs(examPerson, checkDate, ExamRequirement.ID_EXTERNAL_THEORETICAL));
			} catch (ConstraintCheckFailureException e) {
				return UnavailabilityReason.THEORY_NOT_PASSED;
			}
		}

		if (examTypeId == ExamRequirement.ID_EXTERNAL_PRACTICAL) {
			boolean isAdditionalTrainingRequired = false;
			try {
				constraintCheckDispatcher.check(new AdditionalPracticalTrainingIsRequiredArgs(examPerson));
				isAdditionalTrainingRequired = true;
			} catch (ConstraintCheckFailureException e) {
			}
			if (isAdditionalTrainingRequired) {
				try {
					constraintCheckDispatcher.check(new AdditionalPracticalTrainingIsPassedArgs(examPerson));
				} catch (ConstraintCheckFailureException e) {
					return UnavailabilityReason.ADDITIONAL_TRAINING;
				}
			}
		}

		Permit permit = examPerson.getCompany();
		try {
			constraintCheckDispatcher.check(new PermitHasCategoryArgs(permit, examPerson.getLearningPlan().getTargetCategory()));
		} catch (ConstraintCheckFailureException e) {
			return UnavailabilityReason.PERMIT_CATEGORY_MISSING;
		}

		try {
			constraintCheckDispatcher.check(
					new PermitSupportsExamTypeArgs(permit, (ExamRequirement) examTypeRepository.findById(examTypeId).get()));
		} catch (ConstraintCheckFailureException e) {
			return UnavailabilityReason.PERMIT_EXAM_TYPE_NOT_ALLOWED;
		}

		try {
			constraintCheckDispatcher.check(new CategoryIsNotAlreadyAcquiredArgs(examPerson.getLearningPlan(),
					getAcquiredCategories(examPerson.getSubjectVersion().getSubject())));
		} catch (ConstraintCheckFailureException e) {
			return UnavailabilityReason.CATEGORY_IS_ALREАDY_ACQUIRED;
		}

		return null;
	}

	@Transactional(readOnly = true)
	public Map<SubCategory, LocalDateTime> getAcquiredCategories(Subject subject) {
		return getAcquiredCategoriesUntil157(subject.getIdentityNumber(), new HashSet<ProvidedCategory>());
	}

	@Transactional(readOnly = true)
	public Map<SubCategory, LocalDateTime> getAcquiredCategoriesUntil157(String identityNumber,
			Collection<ProvidedCategory> providedCategories) {
		return getAcquiredCategories(identityNumber, providedCategories, DocumentRequirement.ID_DRIVER_LICENCE_LOSS_157);
	}

	private Map<SubCategory, LocalDateTime> getAcquiredCategories(String identityNumber,
			Collection<ProvidedCategory> providedCategories, Long drivingLicenceLostId) {
		LocalDateTime latestLostDate = null;
		if (drivingLicenceLostId != null && drivingLicenceLostId == ProvidedDocumentRepository.DRIVER_LICENCE_LOSS_157) {
			latestLostDate = getLatest157Date(identityNumber);
		} else if (drivingLicenceLostId != null && drivingLicenceLostId == ProvidedDocumentRepository.DRIVER_LICENCE_LOSS_426) {
			latestLostDate = getLatest426Date(identityNumber);
		}

		Map<SubCategory, LocalDateTime> acquiredCategories = new HashMap<>();

		List<ExamPerson> examPeople = examPersonRepository.getCompletedExamPeopleForidentityNumber(identityNumber);

		for (ExamPerson examPerson : examPeople) {
			if (latestLostDate == null || !examPerson.getRegisteredAt().isBefore(latestLostDate)) {
				LearningPlan learningPlan = examPerson.getLearningPlan();
				SubCategory subCategory = learningPlan.getTargetCategory();
				if (!acquiredCategories.containsKey(subCategory)) {
					LocalDateTime latestAcquireDate = getLatestCategoryAcquireDate(learningPlan.getTargetCategory(),
							latestLostDate, examPeople);
					if (latestAcquireDate != null) {
						acquiredCategories.put(subCategory, latestAcquireDate);
					}
				}
			}
		}
		List<ProvidedCategory> previouslyProvidedCategories;
		if (latestLostDate == null) {
			previouslyProvidedCategories = providedCategoryRepository.getAllForidentityNumberAfter(identityNumber);
		} else {
			previouslyProvidedCategories = providedCategoryRepository.getAllForidentityNumberAfter(identityNumber,
					latestLostDate);
		}
		for (ProvidedCategory providedCategory : previouslyProvidedCategories) {
			try {
				constraintCheckDispatcher.check(new ProvidedCategoryIsStillValidArgs(providedCategory));
				SubCategory provided = providedCategory.getCategory();
				LocalDateTime acquireDate = providedCategory.getDate().atStartOfDay();
				if (latestLostDate == null || !acquireDate.isBefore(latestLostDate)) {
					if ((!acquiredCategories.containsKey(provided) || acquiredCategories.get(provided).isBefore(acquireDate))) {
						acquiredCategories.put(provided, acquireDate);
					}
				}
			} catch (ConstraintCheckFailureException e) {
			}
		}

		for (ProvidedCategory providedCategory : providedCategories) {
			try {
				constraintCheckDispatcher.check(new ProvidedCategoryIsStillValidArgs(providedCategory));
				SubCategory subCategory = subCategoryRepository.findById(providedCategory.getCategory().getId()).get();
				LocalDateTime acquireDate = providedCategory.getDate().atStartOfDay();
				if (!acquiredCategories.containsKey(subCategory) || acquiredCategories.get(subCategory).isBefore(acquireDate)) {
					acquiredCategories.put(subCategory, acquireDate);
				}
			} catch (ConstraintCheckFailureException e) {
			}
		}

		return SubCategoryUtil.expandWithDerivativeCategories(acquiredCategories);
	}

	private LocalDateTime getLatestCategoryAcquireDate(SubCategory subCategory, LocalDateTime latestLostDate,
			List<ExamPerson> examPeople) {
		LocalDateTime latestAcquireDate = null;
		for (ExamPerson examPerson : examPeople) {
			LearningPlan learningPlan = examPerson.getLearningPlan();
			SubCategory otherSubCategory = learningPlan.getTargetCategory();
			if (otherSubCategory.equals(subCategory)
					&& (latestLostDate == null || !examPerson.getRegisteredAt().isBefore(latestLostDate))) {
				boolean isPassed = false;
				try {
					constraintCheckDispatcher.check(new LearningPlanIsFulfilledArgs(examPerson));
					isPassed = true;
				} catch (ConstraintCheckFailureException e) {
				}

				if (isPassed && (latestAcquireDate == null || latestAcquireDate.isBefore(examPerson.getCompletedAt()))) {
					latestAcquireDate = examPerson.getCompletedAt();
				}
			}
		}

		return latestAcquireDate;
	}

	@Transactional(readOnly = true)
	public LocalDate getLatestLicenceLossDate(String identityNumber) {

		ProvidedDocument latestDrvLicenceLossOrder = providedDocumentRepository.getLatestDrvLicenceLoss(identityNumber);
		if (latestDrvLicenceLossOrder != null) {
			return latestDrvLicenceLossOrder.getIssueDate();
		}
		ExamPerson examPerson = examPersonRepository.getLatestWithLicenceLostLearningPlan(identityNumber);
		if (examPerson != null) {
			return examPerson.getRegisteredAt().toLocalDate();
		}
		return null;
	}

	public ExamPerson getExamPerson(Long id) {
		return examPersonRepository.findById(id).get();
	}

	@Transactional(readOnly = true)
	public LocalDateTime getLatest157Date(String identityNumber) {
		ProvidedDocument latestDrvLicenceLossOrder = providedDocumentRepository.getLatestDrvLicence(identityNumber,
				ProvidedDocumentRepository.DRIVER_LICENCE_LOSS_157);
		if (latestDrvLicenceLossOrder != null) {
			return latestDrvLicenceLossOrder.getIssueDate().atStartOfDay();
		}
		ExamPerson examPerson = examPersonRepository.getLatestWithDescriptionLearningPlan(identityNumber,
				ExamPersonRepository.DESCRIPTION_426);
		if (examPerson != null) {
			return examPerson.getRegisteredAt();
		}
		return null;
	}

	@Transactional(readOnly = true)
	public LocalDateTime getLatest426Date(String identityNumber) {
		ProvidedDocument latestDrvLicenceLossOrder = providedDocumentRepository.getLatestDrvLicence(identityNumber,
				ProvidedDocumentRepository.DRIVER_LICENCE_LOSS_426);
		if (latestDrvLicenceLossOrder != null) {
			return latestDrvLicenceLossOrder.getIssueDate().atStartOfDay();
		}
		ExamPerson examPerson = examPersonRepository.getLatestWithDescriptionLearningPlan(identityNumber,
				ExamPersonRepository.DESCRIPTION_426);
		if (examPerson != null) {
			return examPerson.getRegisteredAt();
		}
		return null;
	}

	@Transactional(readOnly = true)
	public boolean canBeAddedToTheoreticalProtocolByIaaa(ExamPerson examPerson) {
		List<ExamPerson> examPeoples = new LinkedList<>(examPersonRepository.getAllForSubjectAndCategory(
				examPerson.getSubjectVersion().getSubject(), examPerson.getLearningPlan().getTargetCategory()));
		Collections.sort(examPeoples, new ExamPersonRegistrationDescComparator());
		boolean isInTheoreticalProtocol = false;
		LocalDateTime now = LocalDateTime.now();
		for (ExamPerson person : examPeoples) {
			Set<ExamResult> results = new HashSet<>(person.getExamResults());
			for (ExamResult examResult : results) {
				Protocol protocol = examResult.getProtocol();

				if (!protocol.getExamType().isPractical()) {

					if (protocol.getExamTime().isAfter(now)) {
						continue;
					}

					if (examResult.isPassed() != null && examResult.isPassed() == false) {
						return true;
					} else if (examResult.isPassed() != null && examResult.isPassed() == true) {
						return true;
					}

				}
			}
		}

		return isInTheoreticalProtocol;
	}

	@Transactional(rollbackFor = ConstraintCheckFailureException.class)
	public ExamPersonRegistrationResponseDto registerExamPerson(ExamPersonRegistrationRequestDto requestDto) throws ConstraintCheckFailureException {
		Country country = genericFinder.findById(Country.class, requestDto.getCountryCode());
		if (country == null) {
			throw new NoSuchEntityException(Country.class, requestDto.getCountryCode());
		}

		Optional<Region> regionOptional = regionRepository.findById(requestDto.getRegionCode());
		if (!regionOptional.isPresent()) {
			throw new NoSuchEntityException(Region.class, requestDto.getRegionCode());
		}
		Region region = regionOptional.get();
		
		OrgUnit orgUnit = genericFinder.findById(OrgUnit.class, requestDto.getOrgUnitCode());
		if (orgUnit == null) {
			throw new NoSuchEntityException(OrgUnit.class, requestDto.getOrgUnitCode());
		}
		
		List<Permit> iaaaPermits = permitRepository.getLastIaaaPermitForOrgUnit(orgUnit);
		if (iaaaPermits == null || iaaaPermits.isEmpty()) {
			throw new NoSuchEntityException(Permit.class, "orgUnitCode=" + requestDto.getOrgUnitCode());
		}
		Permit permit = iaaaPermits.get(0);

		Optional<LearningPlan> learningPlanOptional = learningPlanRepository.findById(requestDto.getLearningPlanId());
		if (!learningPlanOptional.isPresent()) {
			throw new NoSuchEntityException(LearningPlan.class, requestDto.getLearningPlanId());
		}
		LearningPlan learningPlan = learningPlanOptional.get();
		
		SubjectVersion subjectVersion = new SubjectVersion();
		subjectVersion.setFirstNameCyr(new SubjectDictionary(requestDto.getFirstName()));
		subjectVersion.setSurnameCyr(new SubjectDictionary(requestDto.getSurname()));
		subjectVersion.setFamilyNameCyr(new SubjectDictionary(requestDto.getFamilyName()));
		if (requestDto.getFirstNameLatin() != null && !requestDto.getFirstNameLatin().trim().isEmpty()) {
			subjectVersion.setFirstNameLat(new SubjectDictionary(requestDto.getFirstNameLatin()));
		}
		if (requestDto.getSurnameLatin() != null && !requestDto.getSurnameLatin().trim().isEmpty()) {
			subjectVersion.setSurnameLat(new SubjectDictionary(requestDto.getSurnameLatin()));
		}
		if (requestDto.getFamilyNameLatin() != null && !requestDto.getFamilyNameLatin().trim().isEmpty()) {
			subjectVersion.setFamilyNameLat(new SubjectDictionary(requestDto.getFamilyNameLatin()));
		}

		Subject subject = new Subject();
		subject.setIdentityNumber(requestDto.getPersonalIdentityNumber());
		subject.setCurrentVersion(subjectVersion);
		subject.setCountry(country);
		subject = subjectService.saveSubject(subject);

		ExamPerson examPerson = new ExamPerson();
		examPerson.setCompany(permit);
		examPerson.setIndividualTraining(false);
		examPerson.setIndividualTrainingStartDate(null);
		examPerson.setLearningPlan(learningPlan);
		examPerson.setRegion(region);
		examPerson.setRegisteredAt(LocalDateTime.now());
		examPerson.setSubjectVersion(subject.getCurrentVersion());
		examPerson.setTheoryGroup(null);
		examPerson.setTheoryGroupAddDate(null);

		examPerson = examPersonRepository.save(examPerson);
		
		List<DocumentRequirement> documentRequirements = learningPlan.getDocumentRequirements();

		if (documentRequirements.size() != requestDto.getProvidedDocuments().size()) {
			throw new ApplicationException("LearningPlan documentRequirements is not of the same size as the providedDocuments.");
		}
		Set<ProvidedDocument> providedDocuments = new HashSet<>();
		for (ProvidedDocumentRegistrationRequestDto providedDocumentDto : requestDto.getProvidedDocuments()) {
			long docRequirementId = providedDocumentDto.getDocumentRequirementId();
			DocumentRequirement documentRequirement = findDocumentRequirementById(docRequirementId, documentRequirements);
			if (documentRequirement == null) {
				throw new InvalidDocumentRequirementException(learningPlan.getId(), docRequirementId);
			}
			if (documentRequirement.isIssuerRequired() 
					&& (providedDocumentDto.getIssuedBy() == null || providedDocumentDto.getIssuedBy().isEmpty())) {
				throw new DocumentIssuerIsRequiredException(docRequirementId);
			}
			
			ProvidedDocument providedDocument = new ProvidedDocument();
			providedDocument.setDocumentRequirement(documentRequirement);
			providedDocument.setExamPerson(examPerson);
			providedDocument.setSerialNumber(providedDocumentDto.getNumber().trim());
			providedDocument.setIssueDate(providedDocumentDto.getIssueDate());
			if (providedDocumentDto.getIssuedBy() != null && !providedDocumentDto.getIssuedBy().trim().isEmpty()) {
				providedDocument.setIssuedBy(providedDocumentDto.getIssuedBy().trim());
			}
			providedDocument = providedDocumentRepository.save(providedDocument);
			providedDocuments.add(providedDocument);
		}
		examPersonRepository.flush();
		
		if (requestDto.getProvidedCategories() != null && !requestDto.getProvidedCategories().isEmpty()) {
			Map<SubCategory, LocalDateTime> acquiredCategories = this.getAcquiredCategories(subject);
			
			for (ProvidedCategoryRegistrationRequestDto providedCategoryDto : requestDto.getProvidedCategories()) {
				boolean isSubCategoryAquired = isSubCategoryIdInCollection(providedCategoryDto.getSubCategoryId(), 
						acquiredCategories.keySet());
				
				if (!isSubCategoryAquired) {
					Optional<SubCategory> subCategoryOptional = subCategoryRepository
							.findById(providedCategoryDto.getSubCategoryId());
					if (!subCategoryOptional.isPresent()) {
						throw new NoSuchEntityException(SubCategory.class, providedCategoryDto.getSubCategoryId());
					}
					SubCategory subCategory = subCategoryOptional.get();

					ProvidedCategory providedCategory = new ProvidedCategory();
					providedCategory.setCategory(subCategory);
					providedCategory.setDate(providedCategoryDto.getDate());
					providedCategory.setExamPerson(examPerson);
					
					providedCategory = providedCategoryRepository.save(providedCategory);
					examPerson.getProvidedCategories().add(providedCategory);
				}
			}
		}
		
		boolean isIndividualTrainingMandatory = isIndividualTrainingMandatory(examPerson);
		if (isIndividualTrainingMandatory) {
			examPerson.setIndividualTraining(true);
		}
		
		constraintCheckDispatcher.check(new ExamPersonRegistrationIsValidArgs(examPerson));
		
		return new ExamPersonRegistrationResponseDto(examPerson.getId());
	}

	private boolean isSubCategoryIdInCollection(int subCategoryId, Collection<SubCategory> subCategories) {
		for (SubCategory subCategory : subCategories) {
			if (subCategory.getId().intValue() == subCategoryId) {
				return true;
			}
		}
		return false;
	}

	private boolean isIndividualTrainingMandatory(ExamPerson examPerson) {
		boolean isIndividualTrainingMandatory = true;
		try {
			constraintCheckDispatcher.check(new IndividualTrainingIsNotMandatoryArgs(examPerson, true));
			isIndividualTrainingMandatory = false;
		} catch (ConstraintCheckFailureException e) {
		}
		return isIndividualTrainingMandatory;
	}

	private DocumentRequirement findDocumentRequirementById(long docRequirementId,
			List<DocumentRequirement> documentRequirements) {
		for (DocumentRequirement documentRequirement : documentRequirements) {
			if (documentRequirement.getId().equals(docRequirementId)) {
				return documentRequirement;
			}
		}
		return null;
	}

	public List<ExamPerson> getExamPeopleWithDerivativeLearningPlan(Collection<ExamPerson> examPeople, LearningPlan learningPlan) {
		List<ExamPerson> examPeopleWithDerivativeLearningPlan = new LinkedList<>();
		SubCategory subCategory = learningPlan.getTargetCategory();
		for (ExamPerson examPerson : examPeople) {
			SubCategory activeCategory = examPerson.getLearningPlan().getTargetCategory();
			if (activeCategory.equals(subCategory)) {
				examPeopleWithDerivativeLearningPlan.add(examPerson);
			}
		}
		return examPeopleWithDerivativeLearningPlan;
	}

	public List<ExamPerson> getActiveForPerson(Subject subject) {
		List<ExamPerson> activeExamPeople = examPersonRepository.getActiveForSubject(subject);
		activeExamPeople.removeAll(getWithInvalidPermit(activeExamPeople));
		return activeExamPeople;
	}
	
	public List<ExamPerson> getActiveAndMovableForPersonAndLearningPlan(Subject subject, LearningPlan learningPlan, Integer excludedPermitNumber) {
		if (subject.getId() == null) {
			return new LinkedList<>();
		}
		List<ExamPerson> examPeople;
		if (excludedPermitNumber != null) {
			examPeople = examPersonRepository.getActiveForSubjectAndLearningPlanWithExams(subject, learningPlan, excludedPermitNumber.intValue());
		} else {
			examPeople = examPersonRepository.getActiveForSubjectAndLearningPlanWithExams(subject, learningPlan);
		}
		examPeople.removeAll(getWithInvalidPermit(examPeople));
		List<ExamPerson> filtered = new LinkedList<>();
		for (ExamPerson examPerson : examPeople) {
			//FIXME: is this not a check candidate?
			if (ExamPersonUtil.canMoveExamPersonToAnotherCompany(examPerson)) {
				filtered.add(examPerson);
			}
		}
		return filtered;
	}
	
	public List<ExamPerson> getWithInvalidPermit(List<ExamPerson> examPeople) {
		List<ExamPerson> examPeopleWithInvalidPermit = new LinkedList<>();
		for (ExamPerson examPerson : examPeople) {
			Permit permit = permitRepository.getLastValidPermit(examPerson.getCompany().getNumber());
			if (permit == null) {
				examPeopleWithInvalidPermit.add(examPerson);
			}
		}
		return examPeopleWithInvalidPermit;
	}
	
	@Transactional(rollbackFor = ConstraintCheckFailureException.class)
	public void cancelLearning(long examPersonId) throws ConstraintCheckFailureException {
		Optional<ExamPerson> examPersonOptional = examPersonRepository.findById(examPersonId);
		if (!examPersonOptional.isPresent()) {
			throw new NoSuchEntityException(ExamPerson.class, examPersonId);
		}
		ExamPerson examPerson = examPersonOptional.get();
		constraintCheckDispatcher.check(new ExamPersonIsNotInFutureProtocolArgs(examPerson, true),
										new ExamPersonIsNotInFutureProtocolArgs(examPerson, false));
		if (examPerson.getCompletedAt() == null) {
			examPerson.setCompletedAt(LocalDateTime.now());
		}
	}

	public Map<SubCategory, LocalDateTime> getAcquiredCategoriesIncluding157(String identNum,
			Collection<ProvidedCategory> providedCategories) {
		return getAcquiredCategories(identNum, providedCategories, null);
	}
	
	public Map<SubCategory, LocalDateTime> getAcquiredCategoriesIncluding426(String identNum,
			Collection<ProvidedCategory> providedCategories) {
		return getAcquiredCategories(identNum, providedCategories, null);
	}
}
