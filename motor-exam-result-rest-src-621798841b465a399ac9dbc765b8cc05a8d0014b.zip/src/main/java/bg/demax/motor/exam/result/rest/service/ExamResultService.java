package bg.demax.motor.exam.result.rest.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.exams.entity.Language;
import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.ConstraintCheckDispatcher;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.motor.exam.result.entity.ExamCommittee;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.practical.entity.PracticalExamRoadDuration;
import bg.demax.motor.exam.result.rest.db.repository.ExamPersonRepository;
import bg.demax.motor.exam.result.rest.db.repository.ExamResultRepository;
import bg.demax.motor.exam.result.rest.db.repository.LanguageRepository;
import bg.demax.motor.exam.result.rest.db.repository.MunicipalityRepository;
import bg.demax.motor.exam.result.rest.db.repository.PracticalExamRoadDurationRepository;
import bg.demax.motor.exam.result.rest.db.repository.ProtocolRepository;
import bg.demax.motor.exam.result.rest.db.repository.RegionRepository;
import bg.demax.motor.exam.result.rest.db.repository.SubCategoryTransitionRepository;
import bg.demax.motor.exam.result.rest.dto.CreateExamResultDto;
import bg.demax.motor.exam.result.rest.dto.ExamResultInProtocolDto;
import bg.demax.motor.exam.result.rest.exception.ApplicationException;
import bg.demax.motor.exam.result.rest.exception.NoSuchEntityException;
import bg.demax.motor.exam.result.rest.util.EntityUtil;
import bg.demax.motor.exam.result.rest.util.ExamResultUtil;
import bg.demax.motor.exam.result.rest.validation.ExamMaterialIsCorrectArgs;
import bg.demax.motor.exam.result.rest.validation.IaaaCanAddExamPersonToProtocolArgs;
import bg.demax.motor.exam.result.rest.validation.PersonAlreadyHasActiveDocumentInMunicipalityArgs;
import bg.demax.motor.exam.result.rest.validation.PersonIsNotInSameProtocolArgs;
import bg.demax.motor.exam.result.rest.validation.ProtocolHasEnoughCapacityArgs;
import bg.demax.motor.exam.result.rest.validation.ProtocolIsNotLockedArgs;
import bg.demax.motor.exam.result.rest.validation.TaxiDocumentAlreadyAssignedToProtocolArgs;
import bg.demax.pub.entity.Municipality;
import bg.demax.pub.entity.Municipality.MunicipalityId;
import bg.demax.pub.entity.Region;
import bg.demax.pub.entity.Subject;

@Service
public class ExamResultService {
	
	@Autowired
	private SubCategoryTransitionRepository subCategoryTransition;
	
	@Autowired
	private ExamResultRepository examResultRepository;
	
	@Autowired
	private ExamPersonRepository examPersonRepository;
	
	@Autowired
	private ProtocolRepository protocolRepository; 
	
	@Autowired
	private ConstraintCheckDispatcher constraintCheckDispatcher;
	
	@Autowired
	private MunicipalityRepository municipalityRepository;
	
	@Autowired
	private RegionRepository regionRepository;
	
	@Autowired
	private ConversionService conversionService;
	
	@Autowired
	private LanguageRepository languageRepository;
	
	@Autowired
	private PracticalExamRoadDurationRepository practicalExamRoadDurationRepository;

	@Transactional(readOnly = true)
	public ExamResult getLatestValidPracticalExam(Subject subject, SubCategory subCategory, LocalDateTime localDateTime) {
		List<SubCategory> subCategoriesToCheck = subCategoryTransition.getParentCategories(subCategory);
		subCategoriesToCheck.add(0, subCategory);

		Map<LocalDateTime, ExamResult> results = new HashMap<>();

		for (SubCategory subCategoryToCheck : subCategoriesToCheck) {
			ExamResult lastResultForCategory;
			if(localDateTime == null) {
				List<ExamResult> lastResultsForCategory = examResultRepository.getLatestValid(subject, subCategoryToCheck,
						ExamRequirement.ID_EXTERNAL_PRACTICAL, localDateTime);
				if (lastResultsForCategory != null && !lastResultsForCategory.isEmpty()) {
					lastResultForCategory = lastResultsForCategory.get(0);
				} else {
					lastResultForCategory = null;
				}
			} else {
				List<ExamResult> lastResultsForCategory = examResultRepository.getLatestValid(subject, subCategoryToCheck,
						ExamRequirement.ID_EXTERNAL_PRACTICAL);
				if (lastResultsForCategory != null && !lastResultsForCategory.isEmpty()) {
					lastResultForCategory = lastResultsForCategory.get(0);
				} else {
					lastResultForCategory = null;
				}
			}
			if (lastResultForCategory != null) {
				results.put(lastResultForCategory.getProtocol().getExamTime(), lastResultForCategory);
			}
		}

		if (results.isEmpty()) {
			return null;
		}

		List<LocalDateTime> dates = new LinkedList<>(results.keySet());
		Collections.sort(dates);
		Collections.reverse(dates);

		ExamResult latestPracticalResult = results.get(dates.get(0));
		return latestPracticalResult;
	}

	@Transactional(rollbackFor = ConstraintCheckFailureException.class)
	public ExamResultInProtocolDto createExamResult(@Valid CreateExamResultDto dto) throws ConstraintCheckFailureException {
		Optional<ExamPerson> examPersonOptional = examPersonRepository.findById(dto.getExamPersonId());
		if (!examPersonOptional.isPresent()) {
			throw new NoSuchEntityException(ExamPerson.class, dto.getExamPersonId());
		}
		ExamPerson examPerson = examPersonOptional.get();

		Optional<Protocol> protocolOptional = protocolRepository.findById(dto.getProtocolId());
		if (!protocolOptional.isPresent()) {
			throw new NoSuchEntityException(Protocol.class, dto.getProtocolId());
		}
		Protocol protocol = protocolOptional.get();
		
		Optional<Language> languageOptional = languageRepository.findById(Language.BG);
		if (!languageOptional.isPresent()) {
			throw new NoSuchEntityException(Language.class, Language.BG);
		}
		Language language = languageOptional.get();
		
		ExamResult examResult = new ExamResult();
		examResult.setIsElectronicTest(true);
		examResult.setCode78(false);
		examResult.setProtocol(protocol);
		examResult.setExamPerson(examPerson);
		examResult.setDate(LocalDate.now());
		examResult.setLanguage(language);
		
		constraintCheckDispatcher.check(new PersonIsNotInSameProtocolArgs(protocol, examResult),
										new ProtocolHasEnoughCapacityArgs(examResult, protocol),
										new ProtocolIsNotLockedArgs(protocol),
										new IaaaCanAddExamPersonToProtocolArgs(protocol, examPerson),
										new ExamMaterialIsCorrectArgs(examResult));
		

		if (EntityUtil.isTaxiDriver(examPerson) || EntityUtil.isTaxiManager(examPerson)) {
			
			String identityNumber = examPerson.getSubjectVersion().getSubject().getIdentityNumber();
			Region region = regionRepository.findById(dto.getMunicipalityRegionCode()).get();
			MunicipalityId searchId = new MunicipalityId(dto.getMunicipalityCode(), region);
			Municipality municipality = municipalityRepository.findById(searchId).get();
			String remark = examResult.getRemark(); 
			
			if(remark == null) {
				remark = "";
			}
			
			examResult.setRemark(remark + " ОБЩИНА: " + municipality.getName() + "; ");
			constraintCheckDispatcher.check(new TaxiDocumentAlreadyAssignedToProtocolArgs(examResult.getExamPerson().getSubjectVersion(), examResult.getProtocol()),
											new PersonAlreadyHasActiveDocumentInMunicipalityArgs(identityNumber, EntityUtil.isTaxiManager(examPerson), municipality));
		}
		
		if (protocol.getExamType().isPractical() && examResult.getId() == null) {
			addToExamCommitteeDuration(examResult);
		}

		
		examResult = examResultRepository.save(examResult);
		
		ExamResultInProtocolDto examResultInProtocolDto = conversionService.convert(examResult, ExamResultInProtocolDto.class);
		
		return examResultInProtocolDto;
	}

	private void addToExamCommitteeDuration(ExamResult examResult) {
		Protocol protocol = examResult.getProtocol();
		ExamCommittee committee = protocol.getExamCommittee();
		SubCategory subCategory = examResult.getExamPerson().getLearningPlan().getTargetCategory();

		int minutesToAdd = 0;
		if (protocol.getExamResults().size() > 1) {
			minutesToAdd += 5;
		}
		if (ExamResultUtil.getGroundNeeded(examResult) && !ExamResult.ATTR_RESULT_YES.equalsIgnoreCase(ExamResultUtil.getGroundResult(examResult))) {
			minutesToAdd += 10;
		}
		if (ExamResultUtil.getRoadNeeded(examResult)) {
			PracticalExamRoadDuration practicalExamRoadDuration = practicalExamRoadDurationRepository.getForSubCategory(subCategory.getId());
			if (practicalExamRoadDuration != null) {
				minutesToAdd += practicalExamRoadDuration.getMinDurationMinutes();
			}
		}

		committee.setDuration(committee.getDuration() + minutesToAdd);
	}

	@Transactional(rollbackFor = ConstraintCheckFailureException.class)
	public void deleteExamResult(long examResultId) throws ConstraintCheckFailureException {
		Optional<ExamResult> examResultOptional = examResultRepository.findById(examResultId);
		if (!examResultOptional.isPresent()) {
			throw new NoSuchEntityException(ExamResult.class, examResultId);
		}
		ExamResult examResult = examResultOptional.get();
		Protocol protocol = examResult.getProtocol();
		if (protocol == null) {
			throw new ApplicationException("Invalid exam result state. No protocol in ExamResult.");
		}

		constraintCheckDispatcher.check(new ProtocolIsNotLockedArgs(examResult.getProtocol()));
		
		//TODO return payment?
		
		if(protocol.getExamType().isPractical()) {
			subtractFromExamCommitteeDuration(examResult);
		}
		
		protocol.getExamResults().remove(examResult);
		examResultRepository.delete(examResult);
	}

	private void subtractFromExamCommitteeDuration(ExamResult examResult) {
		Protocol protocol = examResult.getProtocol();
		ExamCommittee committee = protocol.getExamCommittee();
		SubCategory subCategory = examResult.getExamPerson().getLearningPlan().getTargetCategory();

		int minutesToRemove = 0;
		if (protocol.getExamResults().size() > 1) {
			minutesToRemove += 5;
		}
		if (ExamResultUtil.getGroundNeeded(examResult) && !ExamResult.ATTR_RESULT_YES.equalsIgnoreCase(ExamResultUtil.getGroundResult(examResult))) {
			minutesToRemove += 10;
		}
		if (ExamResultUtil.getRoadNeeded(examResult)) {
			PracticalExamRoadDuration practicalExamRoadDuration = practicalExamRoadDurationRepository.getForSubCategory(subCategory.getId());
			if (practicalExamRoadDuration != null) {
				minutesToRemove += practicalExamRoadDuration.getMinDurationMinutes();
			}
		}

		committee.setDuration(committee.getDuration() - minutesToRemove);
	}
}
