package bg.demax.motor.exam.result.rest.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.exams.entity.SubCategory;
import bg.demax.motor.exam.result.entity.CategoryRequirement;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.rest.db.repository.LearningPlanRepository;

@Service
public class LearningPlanService {

	@Autowired
	private LearningPlanRepository learningPlanRepository;
	
	@Transactional(readOnly = true)
	public List<LearningPlan> filterOccluded(Collection<LearningPlan> learningPlans) {
		List<LearningPlan> filteredLearningPlans = new LinkedList<>();

		for (LearningPlan learningPlan : learningPlans) {
			boolean isOcclusionFound = false;
			for (LearningPlan otherLearningPlan : learningPlans) {
				if (!learningPlan.equals(otherLearningPlan)) {
					if (hasOcclusion(otherLearningPlan, learningPlan)) {
						isOcclusionFound = true;
						break;
					}
				}
			}

			if (!isOcclusionFound) {
				filteredLearningPlans.add(learningPlan);
			}
		}

		return filteredLearningPlans;
	}
	
	/**
	 * This method checks the reachability from one category to another. One
	 * category is reachable from another, if and only if there is a learning
	 * plan path between them
	 * 
	 * @param category1
	 * @param category2
	 * @return
	 */
	private boolean isCategoryReachable(SubCategory category1, SubCategory category2) {
		if (category1.equals(category2)) {
			return true;
		}

		Map<SubCategory, Set<SubCategory>> firstOrder = getFirstLevelOrder();

		Set<SubCategory> reachableCategories = new HashSet<>();
		reachableCategories.add(category1);

		boolean isReachableCategoriesCountChanged;
		do {
			isReachableCategoriesCountChanged = false;
			Set<SubCategory> expandedReachableCategories = new HashSet<>(reachableCategories);

			for (SubCategory subCategory : reachableCategories) {
				if (firstOrder.containsKey(subCategory)) {
					expandedReachableCategories.addAll(firstOrder.get(subCategory));
					expandedReachableCategories.addAll(subCategory.getChildren());
				}
			}

			if (expandedReachableCategories.size() > reachableCategories.size()) {
				reachableCategories = expandedReachableCategories;
				isReachableCategoriesCountChanged = true;
			}
		} while (isReachableCategoriesCountChanged);

		return reachableCategories.contains(category2);
	}

	/**
	 * Checks whether lp1 occludes lp2. This is the case if every necessary
	 * category in lp2 is reachable from a category in lp1 or lp2 has no
	 * necessary categories but lp1 has some.
	 * 
	 * @param learningPlan1
	 * @param learningPlan2
	 * @return
	 */
	private boolean hasOcclusion(LearningPlan learningPlan1, LearningPlan learningPlan2) {
		if (learningPlan1.equals(learningPlan2)) {
			return false;
		}

		if (!learningPlan1.getTargetCategory().equals(learningPlan2.getTargetCategory())) {
			return false;
		}

		if (learningPlan1.getCategoryRequirements().isEmpty()) {
			return false;
		}

		if (learningPlan2.getCategoryRequirements().isEmpty()) {
			return true;
		}

		for (CategoryRequirement categoryRequirementLp2 : learningPlan2.getCategoryRequirements()) {
			boolean bMatch = false;
			for (CategoryRequirement categoryRequirementLp1 : learningPlan1.getCategoryRequirements()) {
				if (isCategoryReachable(categoryRequirementLp1.getCategory(), categoryRequirementLp2.getCategory())) {
					bMatch = true;
					break;
				}
			}

			if (!bMatch)
				return false;
		}

		for (CategoryRequirement categoryRequirementLp1 : learningPlan1.getCategoryRequirements()) {
			boolean bMatch = false;
			for (CategoryRequirement categoryRequirementLp2 : learningPlan2.getCategoryRequirements()) {
				if (isCategoryReachable(categoryRequirementLp1.getCategory(), categoryRequirementLp2.getCategory())) {
					bMatch = true;
					break;
				}
			}

			if (bMatch)
				return false;
		}

		return true;
	}
	
	private Map<SubCategory, Set<SubCategory>> getFirstLevelOrder() {
		Map<SubCategory, Set<SubCategory>> firstLevelOrder = new HashMap<>();
		List<LearningPlan> learningPlans = learningPlanRepository.findAll();

		for (LearningPlan learningPlan : learningPlans) {
			for (CategoryRequirement categoryRequirement : learningPlan.getCategoryRequirements()) {
				Set<SubCategory> set = firstLevelOrder.get(learningPlan.getTargetCategory());
				if (set == null)
					set = new HashSet<>();

				set.add(categoryRequirement.getCategory());

				firstLevelOrder.put(learningPlan.getTargetCategory(), set);
			}
		}

		return firstLevelOrder;
	}
}
