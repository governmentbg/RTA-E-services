package bg.demax.motor.exam.result.rest.service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.motor.exam.result.entity.ModuleRequirement;
import bg.demax.motor.exam.result.entity.ModuleResult;
import bg.demax.motor.exam.result.rest.db.repository.ModuleResultRepository;

@Service
public class ModuleResultService {
	
	@Autowired
	private ModuleResultRepository moduleResultRepository;

	@Transactional(readOnly = true)
	public Map<ModuleRequirement, LocalDate> getAllPassedModules(String identityNumber) {
		List<ModuleResult> moduleResults = moduleResultRepository.getAllPassedForidentityNumber(identityNumber);
		Map<ModuleRequirement, LocalDate> passedModules = new HashMap<>();
		for(ModuleResult moduleResult : moduleResults) {
			ModuleRequirement module = moduleResult.getId().getModuleRequirement();
			LocalDate date = moduleResult.getPassedAt().toLocalDate();
			if(passedModules.containsKey(module)) {
				LocalDate currentDate = passedModules.get(module);
				if(currentDate.isBefore(date)) {
					passedModules.put(module, date);
				}
			} else {
				passedModules.put(module, date);
			}
		}
		return passedModules;
	}
}
