package bg.demax.motor.exam.result.rest.service;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.exams.entity.SubCategory;
import bg.demax.motor.exam.result.entity.ExamCommittee;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.practical.entity.PracticalExamRoadDuration;
import bg.demax.motor.exam.result.rest.db.repository.ExamComitteeRepository;
import bg.demax.motor.exam.result.rest.db.repository.PracticalExamRoadDurationRepository;

@Service
public class PracticalExamDurationService {
	
	@Autowired
	private ExamComitteeRepository examComitteeRepository;
	
	@Autowired
	private PracticalExamRoadDurationRepository practicalExamRoadDurationRepository;

	@Transactional(readOnly = true)
	public int getPracticalProtocolDuration(Protocol protocol) {
		ExamCommittee committee = examComitteeRepository.findById(protocol.getExamCommittee().getId()).get();
		int duration = committee.getDuration();
		Set<Protocol> protocols = committee.getProtocols();
		for(Protocol committeeProtocol : protocols) {
			if(!committeeProtocol.getExamType().isPractical()) {
				duration -= 60;
			}
		}
		
		return duration;
	}

	@Transactional(readOnly = true)
	public PracticalExamRoadDuration getForSubCategory(SubCategory subCategory) {
		return practicalExamRoadDurationRepository.getForSubCategory(subCategory.getId());
	}
}
