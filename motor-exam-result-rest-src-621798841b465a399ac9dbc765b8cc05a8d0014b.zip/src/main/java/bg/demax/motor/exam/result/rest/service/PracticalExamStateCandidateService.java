package bg.demax.motor.exam.result.rest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.rest.db.repository.PracticalExamStateCandidateRepository;

@Service
public class PracticalExamStateCandidateService {
	
	@Autowired
	private PracticalExamStateCandidateRepository practicalExamStateCandidateRepository;

	public boolean isExamResultInProtocolInProgress(ExamResult examResult) {
		Integer isExamResultInProtocolInProgressNum = practicalExamStateCandidateRepository
				.isExamResultInProtocolInProgress(examResult.getProtocol());
		return isExamResultInProtocolInProgressNum == null ? false : true;
	}

}
