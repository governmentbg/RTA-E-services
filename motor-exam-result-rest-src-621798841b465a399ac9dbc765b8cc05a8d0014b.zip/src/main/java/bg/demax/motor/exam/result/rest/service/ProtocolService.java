package bg.demax.motor.exam.result.rest.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.rest.controller.params.ProtocolQueryParams;
import bg.demax.motor.exam.result.rest.db.repository.ProtocolRepository;
import bg.demax.motor.exam.result.rest.dto.ProtocolDto;
import bg.demax.motor.exam.result.rest.service.specification.ProtocolSpecificationBuilder;
import bg.demax.motor.exam.result.rest.util.EntityUtil;

@Service
public class ProtocolService {

	@Autowired
	private ProtocolRepository protocolRepository;
	
	@Autowired
	private ConversionService conversionService;
	
	@Transactional(readOnly = true)
	public List<ProtocolDto> getProtocols(@Valid ProtocolQueryParams params) {
		Specification<Protocol> protocolSpecification = ProtocolSpecificationBuilder.getSearchSpecification(params);
		List<Protocol> protocols = protocolRepository.findAll(protocolSpecification, Sort.by(Direction.ASC, "examTime"));
		protocols = protocols.stream().filter((protocol) -> {
			int examResultsCount = protocol.getExamResults().size();
			int remainingSeats = EntityUtil.getSeatplaces(protocol) - examResultsCount;
			if (remainingSeats < 1) {
				return false;
			}
			return true;
		}).collect(Collectors.toList());
		return conversionService.convertList(protocols, ProtocolDto.class);
	}
}
