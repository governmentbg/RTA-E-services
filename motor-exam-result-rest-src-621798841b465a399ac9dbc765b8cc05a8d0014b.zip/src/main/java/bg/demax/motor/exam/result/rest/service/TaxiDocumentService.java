package bg.demax.motor.exam.result.rest.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.motor.exam.result.rest.db.repository.TaxiDocumentRepository;
import bg.demax.pub.entity.Municipality;

@Service
public class TaxiDocumentService {
	
	@Autowired
	public TaxiDocumentRepository taxiDocumentRepository;
	
	@Transactional(readOnly = true)
	public Boolean taxiDocumentAlreadyAssignedToProtocol(Long subjVersionId, LocalDateTime protocolExamTime,
			Integer protocolNumber) {
		if(protocolNumber == null) {
			return taxiDocumentRepository.taxiDocumentAlreadyAssignedToProtocol(subjVersionId, protocolExamTime) == null ? false : true;
		}
		return taxiDocumentRepository.taxiDocumentAlreadyAssignedToProtocol(subjVersionId, protocolExamTime, protocolNumber) == null ? false : true;
	}

	@Transactional(readOnly = true)
	public Boolean hasActiveDocumentInMunicipality(Long docId, String identNumber, Municipality mun, int type) {
		return taxiDocumentRepository.hasActiveTaxiDocumentExtensionForIdentNumber(docId, identNumber, mun, type) == null ? false : true;
	}

}
