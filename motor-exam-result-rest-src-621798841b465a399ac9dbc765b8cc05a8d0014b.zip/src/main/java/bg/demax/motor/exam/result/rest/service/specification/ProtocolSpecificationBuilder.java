package bg.demax.motor.exam.result.rest.service.specification;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Predicate;
import javax.validation.Valid;

import org.springframework.data.jpa.domain.Specification;

import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.entity.ReservationType;
import bg.demax.motor.exam.result.rest.controller.params.ExamTypes;
import bg.demax.motor.exam.result.rest.controller.params.ProtocolQueryParams;
import bg.demax.motor.exam.result.rest.controller.params.ReservationTypes;

public class ProtocolSpecificationBuilder {

	public static Specification<Protocol> getSearchSpecification(@Valid ProtocolQueryParams params) {
		return (root, query, builder) -> {
			final List<Predicate> predicates = new ArrayList<>();
			
			if (params != null) {
				predicates.add(builder.equal(root.get("isReadyForExam"), false));
				predicates.add(builder.equal(root.get("orgUnit").get("code"), params.getOrgUnitCode()));
				
				long examTypeId;
				if (params.getExamType() == ExamTypes.EXTERNAL_THEORETICAL) {
					examTypeId = ExamRequirement.ID_EXTERNAL_THEORETICAL;
				} else if (params.getExamType() == ExamTypes.EXTERNAL_PRACTICAL) {
					examTypeId = ExamRequirement.ID_EXTERNAL_PRACTICAL;
				} else {
					throw new RuntimeException("Unknown exam type parameter.");
				}
				predicates.add(builder.equal(root.get("examType").get("id"), examTypeId));
				
				int reservationTypeId;
				if (params.getReservationType() == ReservationTypes.PUBLIC) {
					reservationTypeId = ReservationType.ID_PUBLIC;
				} else if (params.getReservationType() == ReservationTypes.IAAA_TAXI) {
					reservationTypeId = ReservationType.ID_IAAA;
				} else {
					throw new RuntimeException("Unknown reservation type parameter.");
				}
				predicates.add(builder.equal(root.get("reservationType").get("id"), reservationTypeId));
				
				LocalDateTime fromExamDateTime = params.getFromExamDate().atStartOfDay();
				LocalDateTime toExamDateTime = params.getToExamDate().atTime(LocalTime.MAX);
				predicates.add(
					builder.between(root.get("examTime"), fromExamDateTime, toExamDateTime)
				);

				return builder.and(predicates.toArray(new Predicate[predicates.size()]));
			} else {
				return null;
			}
		};
	}
}
