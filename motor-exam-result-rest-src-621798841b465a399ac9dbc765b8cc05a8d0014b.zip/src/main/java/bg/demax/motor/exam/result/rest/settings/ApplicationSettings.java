package bg.demax.motor.exam.result.rest.settings;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationSettings {

	private boolean isEvenMondayCheckEnabled = true;
	private int minimalDaysInFirstWeek = 4;
	private boolean isTrainingDurationCheckEnabled = true;
	private boolean isVoucherPaymentEnabled = true;
	private boolean isExamPaymentEnabled = true;
	private boolean isRequiredDocumentsValidationEnabled = true;
	private String epayEmail = null;
	private String epaySecret = null;
	private String epayUrl = null;
	private String easypayUrl = null;
	private String epayIban = null;
	private String epayBic = null;
	private String epayKin = null;
	private String epayMerchant = null;
	private int addCandidateToProtocolThreshold = 2;
	private int addCandidateToProtocolThresholdSofia = 4;
	private boolean isSixMonthsCheckEnabled157 = true;
	private boolean isThreeYearsCheckEnabled426 = true;
	private int createProtocolMinDays = 1;
	private int createProtocolMaxDays = 15;
	private int maxConcurrentConnectionsPerUserIaaa = 0;
	private int maxConcurrentConnectionsPerUserAvtoizpit = 0;
	private double exceedingCpmBanThresholdIaaa = 0;
	private double exceedingCpmBanThresholdAvtoizpit = 0;
	private int tempBanTimeIaaa = 0;
	private int tempBanTimeAvtoizpit = 0;

	private boolean isMvrCheckEnabled;
	private String mvrRegixLawReason;
	private String mvrRegixServiceType;
	private String mvrRegixPersonIdentifier;
	private String mvrRegixAdministrationOid;
	private String mvrRegixAdministrationName;
	private boolean isDocumentTypeNumberEnabled;
}
