package bg.demax.motor.exam.result.rest.util;

public enum AllowedExamMaterial {
	BOTH, TABLET, PAPER
}