package bg.demax.motor.exam.result.rest.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import bg.demax.exams.entity.SubCategory;
import bg.demax.motor.exam.result.entity.AgeRequirement;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.entity.ModuleRequirement;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.entity.Requirement;

public class EntityUtil {
	
	public static boolean hasExamOfType(LearningPlan learningPlan, long examTypeId) {
		for(ExamRequirement examRequirement : getExamRequirements(learningPlan)) {
			if(examRequirement.getId() == examTypeId) {
				return true;
			}
		}
		return false;
	}
	
	public static boolean isTaxiDriver(ExamPerson examPerson) {
		return examPerson.getLearningPlan().getTargetCategory().getId() == SubCategory.TAXI_DRIVER;
	}
	
	public static boolean isTaxiManager(ExamPerson examPerson) {
		return examPerson.getLearningPlan().getTargetCategory().getId() == SubCategory.TAXI_MANAGER;
	}

	@SuppressWarnings("unchecked")
	public static List<AgeRequirement> getAgeRequirements(LearningPlan learningPlan) {
		return (List<AgeRequirement>) getReqForType(AgeRequirement.class, learningPlan.getRequirements());
	}
	
	@SuppressWarnings("unchecked")
	public static List<ExamRequirement> getExamRequirements(LearningPlan learningPlan) {
		return (List<ExamRequirement>) getReqForType(ExamRequirement.class, learningPlan.getRequirements());
	}
	
	@SuppressWarnings("unchecked")
	public static List<ModuleRequirement> getModuleRequirements(LearningPlan learningPlan) {
		return (List<ModuleRequirement>) getReqForType(ModuleRequirement.class, learningPlan.getRequirements());
	}
	
	public static List<? extends Requirement> getReqForType(Class<?> c, Set<Requirement> requirements) {
		List<Requirement> ret = new ArrayList<>();

		for (Requirement r : requirements) {
			if (c.isInstance(r)) {
				ret.add(r);
			}
		}

		return ret;
	}
	
	public static int getSeatplaces(Protocol protocol) {
		int seatPlaces = 0;
		if (protocol != null && protocol.getExamRoom() != null) {
			Integer maxEtestCount = protocol.getMaxEtestCount();
			seatPlaces = protocol.getExamRoom().getSeatplaces();

			if (maxEtestCount != null && maxEtestCount.intValue() > 0 && seatPlaces > maxEtestCount.intValue()) {
				seatPlaces = maxEtestCount;
			}

			if (seatPlaces > 28) {
				seatPlaces = 28;
			}
		}

		return seatPlaces;
	}
}
