package bg.demax.motor.exam.result.rest.util;

import java.util.HashSet;
import java.util.Set;

import bg.demax.motor.exam.result.entity.ExamCommittee;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.entity.ReservationType;

public class ExamCommitteeUtil {
	
	public static final int THEORETICAL_EXAM_DURATION_MINUTES = 60;
	public static final int PRACTICAL_EXAM_RESERVED_ADDITIONAL_DURATION_MINUTES = 15;
	public static final int PRACTICAL_EXAM_TIME_MINUTES = 300;
	
	public static int getFreeSeatplaces(ExamCommittee examCommittee) {
		int totalSeatPlaces = 0;
		int takenSeatPlaces = 0;
		Set<Protocol> protocols = new HashSet<>(examCommittee.getProtocols());
		for(Protocol protocol : protocols) {
			if(!protocol.getExamType().isPractical()) {
				int seatPlaces = 0;
				if(protocol.getExamRoom() != null) {
					seatPlaces = protocol.getExamRoom().getExamSeats();
				}
				if (protocol.getMaxEtestCount() != null) {
					seatPlaces = Math.max(seatPlaces, protocol.getMaxEtestCount());
				}
				if(seatPlaces > 25) {
					seatPlaces = 25;
				}
				totalSeatPlaces += seatPlaces;
				takenSeatPlaces += protocol.getExamResults().size();
			}
		}
		return totalSeatPlaces - takenSeatPlaces;
	}
	
	public static int getRemainingTime(int duration, Protocol protocol) {
		boolean isPracticalReservationType = protocol.getExamType().isPractical() && protocol.getReservationType().getId() == ReservationType.ID_RESERVATION;
		
		if(duration > 0) {
			duration += 5;
		}
		int remainingTime = PRACTICAL_EXAM_TIME_MINUTES - duration;
		if(isPracticalReservationType){
			remainingTime += PRACTICAL_EXAM_RESERVED_ADDITIONAL_DURATION_MINUTES;
		}
		if(remainingTime < 0) {
			remainingTime = 0;
		}
		return remainingTime;
	}
}
