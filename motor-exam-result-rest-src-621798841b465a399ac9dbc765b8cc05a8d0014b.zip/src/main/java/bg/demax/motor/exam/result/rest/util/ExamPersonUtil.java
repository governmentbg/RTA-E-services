package bg.demax.motor.exam.result.rest.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.LearningPlan;

public class ExamPersonUtil {
	
	public static final LocalDate getLatest157Date(Collection<ExamPerson> examPeople) {
		LocalDate now = LocalDate.now();
		LocalDate latest157Date = null;
		String orderNumber = null;

		LocalDateTime latest157LearningPlanRegistration = null;
		for (ExamPerson examPerson : examPeople) {
			String drivingLicenceLossOrder = examPerson.getDrivingLicenceLossNumber();
			LocalDate drivingLicenceLossDate = examPerson.getDrivingLicenceLossDate();
			if (drivingLicenceLossOrder != null && drivingLicenceLossDate.isBefore(now)) {
				if (latest157Date == null) {
					orderNumber = drivingLicenceLossOrder;
					latest157Date = drivingLicenceLossDate;
				} else {
					if (orderNumber.equals(drivingLicenceLossOrder)) {
						if (latest157Date.isAfter(drivingLicenceLossDate)) {
							latest157Date = examPerson.getDrivingLicenceLossDate();
						}
					} else {
						if (latest157Date.isBefore(drivingLicenceLossDate)) {
							latest157Date = examPerson.getDrivingLicenceLossDate();
							orderNumber = examPerson.getDrivingLicenceLossNumber();
						}
					}
				}
			}

			// if we don't have information about 157 orders then use the last
			// initial category as deadline
			LearningPlan learningPlan = examPerson.getLearningPlan();
			if (learningPlan.is157() && learningPlan.getCategoryRequirements().isEmpty()) {
				if (latest157LearningPlanRegistration == null 
						|| (examPerson.getCompletedAt() != null && latest157LearningPlanRegistration.isBefore(examPerson.getCompletedAt()))) {
					latest157LearningPlanRegistration = examPerson.getRegisteredAt();
				}
			}
		}

		if (latest157Date == null && latest157LearningPlanRegistration != null) {
			latest157Date = latest157LearningPlanRegistration.toLocalDate();
		}

		return latest157Date;
	}
	
	public static boolean canMoveExamPersonToAnotherCompany(ExamPerson examPerson) {
		boolean hasTheory = LearningPlanUtil.hasExamOfType(examPerson.getLearningPlan(), ExamRequirement.ID_EXTERNAL_THEORETICAL);
		boolean hasPractice = LearningPlanUtil.hasExamOfType(examPerson.getLearningPlan(), ExamRequirement.ID_EXTERNAL_PRACTICAL);
		Set<ExamResult> examResults = new HashSet<>(examPerson.getExamResults());
		if(examResults.isEmpty()) {
			return false;
		}
		
		boolean hasAttendedTheoreticalExam = false;
		boolean hasAttendedPracticalExam = false;
		LocalDateTime now = LocalDateTime.now();
		for(ExamResult examResult : examResults) {
			if(!examResult.getProtocol().getExamTime().isBefore(now)) {
				return false;
			}
			if(examResult.getProtocol().getExamType().isPractical()) {
				hasAttendedPracticalExam = true;
			} else {
				hasAttendedTheoreticalExam = true;
			}
		}
		if(hasPractice) {
			return hasAttendedPracticalExam;
		} else if(hasTheory) {
			return hasAttendedTheoreticalExam;
		}
		return true;
	}
}
