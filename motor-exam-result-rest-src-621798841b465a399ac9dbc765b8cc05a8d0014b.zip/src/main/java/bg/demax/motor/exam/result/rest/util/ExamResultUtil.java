package bg.demax.motor.exam.result.rest.util;

import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.Protocol;

public class ExamResultUtil {
	
	private static final String[] NOT_PRESENT_STRINGS = { ".*NOT_PRESENT.*", ".*[Нн][Ее][Яя][Вв][Ии][Лл] [Сс][Ее].*", ".*[Нн][Ее] [Сс][Ее] [Яя][Вв][Ии][Лл].*", ".*[Нн][Сс][Яя].*" };
	
	public static boolean isAttended(ExamResult examResult) {
		String remark = examResult.getRemark();
		if(remark == null) {
			return true;
		}
		for(String notPresentString : NOT_PRESENT_STRINGS) {
			if(remark.matches(notPresentString)) {
				return false;
			}
		}
		return true;
	}
	
	public static boolean getRoadNeeded(ExamResult examResult) {
		Protocol protocol = examResult.getProtocol();
		ExamPerson examPerson = examResult.getExamPerson();
		
		if (!protocol.getExamType().isPractical())
			return false;

		if (examPerson == null || examPerson.getLearningPlan() == null)
			return false;

		String catName = examPerson.getLearningPlan().getTargetCategory().getName();

		if (catName.equals("Ткт"))
			return false;

		return true;
	}

	public static boolean getGroundNeeded(ExamResult examResult) {
		Protocol protocol = examResult.getProtocol();
		ExamPerson examPerson = examResult.getExamPerson();
		
		if (protocol == null || protocol.getExamType() == null || !protocol.getExamType().isPractical())
			return false;

		if (examPerson == null || examPerson.getLearningPlan() == null)
			return false;

		String catName = examPerson.getLearningPlan().getTargetCategory().getName();

		if (catName.matches(".*A.*") || catName.matches(".*E.*") || catName.equals("Ткт") || catName.matches(".*96.*"))
			return true;

		return false;
	}

	public static String getGroundResult(ExamResult examResult) {
		return examResult.getAttributes().get("ground_result");
	}
}
