package bg.demax.motor.exam.result.rest.util;

import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.LearningPlan;

public class LearningPlanUtil {

	public static boolean hasExamOfType(LearningPlan learningPlan, long examTypeId) {
		for (ExamRequirement examRequirement : learningPlan.getExamRequirements()) {
			if (examRequirement.getId() == examTypeId) {
				return true;
			}
		}
		return false;
	}
}
