package bg.demax.motor.exam.result.rest.util;

import java.time.LocalDate;

import bg.demax.pub.entity.Subject;

public class SubjectUtil {

	public static LocalDate getSubjectBirthDate(Subject subject) {
		LocalDate birthDate = subject.getBirthDate();
		if (birthDate == null && subject.getCountry().getCode().equals("BGR")) {
			birthDate = subject.getBirthDateFromIdentityNumber();
		}
		return birthDate;
	}

	public static String getidentityNumberbFromBirthDate(LocalDate birthDate) {
		if (birthDate == null) {
			return "";
		}

		int year = birthDate.getYear();
		int month = birthDate.getMonthValue();
		int day = birthDate.getDayOfMonth();

		if (year < 1900) {
			month += 20;
		} else if (year >= 2000 && year <= 2099) {
			month += 40;
		}

		String identityNumberb = String.valueOf(year).substring(2, 4) + String.format("%02d", month) + String.format("%02d", day);

		return identityNumberb;
	}
}
