package bg.demax.motor.exam.result.rest.validation;

import bg.demax.motor.exam.result.entity.ExamPerson;

public class AdditionalPracticalTrainingIsPassedArgs extends ExamPersonArg {

	private static final long serialVersionUID = -1964306594452954872L;

	public AdditionalPracticalTrainingIsPassedArgs(ExamPerson examPerson) {
		super(examPerson);
	}

}
