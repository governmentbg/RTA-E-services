package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.ModuleRequirement;
import bg.demax.motor.exam.result.entity.ModuleResult;
import bg.demax.motor.exam.result.rest.db.repository.ModuleResultRepository;
import bg.demax.motor.exam.result.rest.db.repository.SubCategoryTransitionRepository;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;
import bg.demax.motor.exam.result.rest.service.ExamResultService;
import bg.demax.motor.exam.result.rest.util.ExamResultUtil;
import bg.demax.motor.exam.result.rest.validation.violations.AdditionalPracticalTrainingNotPassed;
import bg.demax.pub.entity.Subject;

@Component
public class AdditionalPracticalTrainingIsPassedCheck extends AbstractConstraintCheck<AdditionalPracticalTrainingIsPassedArgs> {
	
	@Autowired
	private SubCategoryTransitionRepository subCategoryTransitionRepository	;
	
	@Autowired
	private ModuleResultRepository moduleResultRepository;
	
	@Autowired
	private ExamResultService examResultService;
	
	@Autowired
	private ExamPersonService examPersonService;
	
	@Override
	@Transactional(readOnly = true)
	public void validate(AdditionalPracticalTrainingIsPassedArgs args) throws ConstraintCheckFailureException {
		if(!hasPassedAdditionalPracticalTraining(args.getExamPerson())) {
			throw new ConstraintCheckFailureException(new AdditionalPracticalTrainingNotPassed());
		}
	}
	
	private boolean hasPassedAdditionalPracticalTraining(ExamPerson examPerson) {
		//fixme:DAO
		examPerson = examPersonService.getExamPerson(examPerson.getId());
		Subject subject = examPerson.getSubjectVersion().getSubject();
		SubCategory subCategory = examPerson.getLearningPlan().getTargetCategory();
		LocalDateTime latestPracticalExamFailDate = getLatestPracticalExamFailDate(subject, subCategory, examPersonService.getLatest157Date(subject.getIdentityNumber()));
		if (latestPracticalExamFailDate == null) {
			return true;
		}
		LocalDateTime latestAdditionalTrainingPassDate = getLatestAdditionalTrainingPassDate(examPerson);
		if (latestAdditionalTrainingPassDate == null || latestAdditionalTrainingPassDate.isBefore(latestPracticalExamFailDate)) {
			return false;
		}
		return true;
	}
	
	private LocalDateTime getLatestPracticalExamFailDate(Subject subject, SubCategory subCategory, LocalDateTime localDateTime) {
		ExamResult examResult = examResultService.getLatestValidPracticalExam(subject, subCategory, localDateTime);
		if(examResult != null) {
			boolean isAttended = ExamResultUtil.isAttended(examResult);
			if(isAttended && examResult.isPassed() != null && examResult.isPassed() == false) {
				return examResult.getProtocol().getExamTime();
			}
		}
		return null;
	}

	private LocalDateTime getLatestAdditionalTrainingPassDate(ExamPerson examPerson) {
		LocalDateTime latestPassDate = null;
		List<SubCategory> subCategoriesToCheck = subCategoryTransitionRepository.getParentCategories(examPerson.getLearningPlan().getTargetCategory());
		subCategoriesToCheck.add(0, examPerson.getLearningPlan().getTargetCategory());
		for(SubCategory subCategoryToCheck : subCategoriesToCheck) {
			//fixme: DAO
			ModuleResult moduleResult = moduleResultRepository.getLatestPassedModuleResult(ModuleRequirement.ID_ADDITIONAL_PRACTICAL_TRAINING, examPerson.getSubjectVersion().getSubject(), subCategoryToCheck);
			if(moduleResult != null) {
				if(latestPassDate == null || latestPassDate.isBefore(moduleResult.getPassedAt())) {
					latestPassDate = moduleResult.getPassedAt();
				}
			}
		}
		return latestPassDate;
	}

}
