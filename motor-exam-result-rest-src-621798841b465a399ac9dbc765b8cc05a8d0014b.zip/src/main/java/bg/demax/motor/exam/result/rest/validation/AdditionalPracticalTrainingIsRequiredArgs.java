package bg.demax.motor.exam.result.rest.validation;

import bg.demax.motor.exam.result.entity.ExamPerson;

public class AdditionalPracticalTrainingIsRequiredArgs extends ExamPersonArg {

	private static final long serialVersionUID = -17775963558373383L;

	public AdditionalPracticalTrainingIsRequiredArgs(ExamPerson examPerson) {
		super(examPerson);
	}
}
