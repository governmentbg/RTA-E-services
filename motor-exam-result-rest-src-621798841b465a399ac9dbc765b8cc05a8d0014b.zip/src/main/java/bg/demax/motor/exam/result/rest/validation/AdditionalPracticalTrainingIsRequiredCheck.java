package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;
import bg.demax.motor.exam.result.rest.service.ExamResultService;
import bg.demax.motor.exam.result.rest.util.EntityUtil;
import bg.demax.motor.exam.result.rest.util.ExamResultUtil;
import bg.demax.motor.exam.result.rest.validation.violations.AdditionalPracticalTrainingNotNeeded;
import bg.demax.pub.entity.Subject;

@Component
public class AdditionalPracticalTrainingIsRequiredCheck extends AbstractConstraintCheck<AdditionalPracticalTrainingIsRequiredArgs>{

	@Autowired
	private ExamPersonService examPersonService;
	
	@Autowired
	private ExamResultService examResultService;
	
	@Override
	public void validate(AdditionalPracticalTrainingIsRequiredArgs args) throws ConstraintCheckFailureException {
		ExamPerson examPerson = examPersonService.getExamPerson(args.getExamPerson().getId());
		boolean hasPracticalExam = hasPracticalExam(examPerson);
		if (!hasPracticalExam) {
			throw new ConstraintCheckFailureException(new AdditionalPracticalTrainingNotNeeded());
		}
		Subject subject = examPerson.getSubjectVersion().getSubject();
		SubCategory subCategory = examPerson.getLearningPlan().getTargetCategory();
		
		LocalDateTime latest157Date = examPersonService.getLatest157Date(subject.getIdentityNumber());
		
		if(!hasFailedLastPracticalExam(subject, subCategory, latest157Date)) {
			throw new ConstraintCheckFailureException(new AdditionalPracticalTrainingNotNeeded());
		}
	}
	
	private boolean hasFailedLastPracticalExam(Subject subject, SubCategory subCategory, LocalDateTime afterDate) {
		ExamResult latestPracticalResult = examResultService.getLatestValidPracticalExam(subject, subCategory, afterDate);
		if(latestPracticalResult != null) {
			boolean isBefore2002 = isExamBefore2002(latestPracticalResult.getProtocol());
			boolean isAttended = ExamResultUtil.isAttended(latestPracticalResult);
			
			return isAttended && !isBefore2002 && latestPracticalResult.isPassed() != null && latestPracticalResult.isPassed() == false;
		}
		return false;
	}
	
	private boolean hasPracticalExam(ExamPerson examPerson) {
		for (ExamRequirement examRequirement : EntityUtil.getExamRequirements(examPerson.getLearningPlan())) {
			if (examRequirement.getId() == ExamRequirement.ID_EXTERNAL_PRACTICAL) {
				return true;
			}
		}
		return false;
	}
	
	private boolean isExamBefore2002(Protocol protocol) {
		return protocol.getExamTime().toLocalDate().isBefore(LocalDate.of(2003, 1, 1));
	}

}
