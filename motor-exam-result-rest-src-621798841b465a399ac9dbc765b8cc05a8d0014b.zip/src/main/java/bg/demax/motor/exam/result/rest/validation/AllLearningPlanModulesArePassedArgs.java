package bg.demax.motor.exam.result.rest.validation;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.LearningPlan;
import lombok.Getter;

@Getter
public class AllLearningPlanModulesArePassedArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = 902295272646526961L;

	private String identityNumber;
	private LearningPlan learningPlan;
	private boolean isPractical;

	public AllLearningPlanModulesArePassedArgs(String identityNumber, LearningPlan learningPlan, boolean isPractical) {
		this.identityNumber = identityNumber;
		this.learningPlan = learningPlan;
		this.isPractical = isPractical;
	}
	
	public AllLearningPlanModulesArePassedArgs(ExamPerson examPerson, boolean isPractical) {
		this.identityNumber = examPerson.getSubjectVersion().getSubject().getIdentityNumber();
		this.learningPlan = examPerson.getLearningPlan();
		this.isPractical = isPractical;
	}
}
