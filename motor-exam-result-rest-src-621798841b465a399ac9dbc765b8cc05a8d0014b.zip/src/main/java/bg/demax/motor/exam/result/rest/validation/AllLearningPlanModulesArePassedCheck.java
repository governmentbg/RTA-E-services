package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.entity.ModuleRequirement;
import bg.demax.motor.exam.result.rest.service.ModuleResultService;
import bg.demax.motor.exam.result.rest.util.EntityUtil;
import bg.demax.motor.exam.result.rest.validation.violations.RequiredModuleNotPassed;

@Component
public class AllLearningPlanModulesArePassedCheck extends AbstractConstraintCheck<AllLearningPlanModulesArePassedArgs> {

	@Autowired
	private ModuleResultService moduleResultService;
	
	@Override
	public void validate(AllLearningPlanModulesArePassedArgs args) throws ConstraintCheckFailureException {
		LearningPlan learningPlan = args.getLearningPlan();
		String identityNumber = args.getIdentityNumber();
		boolean isPractical = args.isPractical();
		
		//fixme: DAO
		Map<ModuleRequirement, LocalDate> passedModules = moduleResultService.getAllPassedModules(identityNumber);
		for(ModuleRequirement moduleRequirement : EntityUtil.getModuleRequirements(learningPlan)) {
			if(moduleRequirement.isTheoretical() != isPractical && !passedModules.containsKey(moduleRequirement)) {
				throw new ConstraintCheckFailureException(new RequiredModuleNotPassed());
			}
		}
	}

}
