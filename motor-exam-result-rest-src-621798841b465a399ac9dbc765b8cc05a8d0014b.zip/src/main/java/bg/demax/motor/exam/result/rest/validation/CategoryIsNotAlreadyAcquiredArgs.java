package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDateTime;
import java.util.Map;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.LearningPlan;
import lombok.Getter;

@Getter
public class CategoryIsNotAlreadyAcquiredArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = 4244624675475288168L;
	
	private LearningPlan learningPlan;
	private Map<SubCategory, LocalDateTime> acquiredCategories;

	public CategoryIsNotAlreadyAcquiredArgs(LearningPlan learningPlan, Map<SubCategory, LocalDateTime> acquiredCategories) {
		this.learningPlan = learningPlan;
		this.acquiredCategories = acquiredCategories;
	}
}
