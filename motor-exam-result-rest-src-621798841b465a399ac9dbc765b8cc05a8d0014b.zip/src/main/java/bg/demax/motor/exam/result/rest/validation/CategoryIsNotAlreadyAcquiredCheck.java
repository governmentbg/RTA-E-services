package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Component;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.rest.validation.violations.PersonAlreadyHasCategory;

@Component
public class CategoryIsNotAlreadyAcquiredCheck extends AbstractConstraintCheck<CategoryIsNotAlreadyAcquiredArgs> {

	@Override
	public void validate(CategoryIsNotAlreadyAcquiredArgs args) throws ConstraintCheckFailureException {
		LearningPlan learningPlan = args.getLearningPlan();
		Map<SubCategory, LocalDateTime> acquiredCategories = args.getAcquiredCategories();
		
		if (learningPlan.is157() || learningPlan.is171()) {//|| learningPlan.is426()) { //TODO @All add this to entity
			return;
		}

		LocalDateTime now = LocalDateTime.now();
		for (Entry<SubCategory, LocalDateTime> acquiredCategoryEntry : acquiredCategories.entrySet()) {
			SubCategory acquiredSubCategory = acquiredCategoryEntry.getKey();
			LocalDateTime acquireDate = acquiredCategoryEntry.getValue();
			if (acquiredSubCategory.equals(learningPlan.getTargetCategory())) {
				if (acquireDate.isBefore(now)) {
					throw new ConstraintCheckFailureException(new PersonAlreadyHasCategory());
				}
			}
		}
	}

}
