package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import lombok.Getter;

@Getter
public class ExamAgeIsValidArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -5716588540850471335L;

	private ExamPerson examPerson;
	private long examTypeId;
	private LocalDate examDate;

	public ExamAgeIsValidArgs(ExamPerson examPerson, long examTypeId, LocalDate examDate) {
		this.examPerson = examPerson;
		this.examTypeId = examTypeId;
		this.examDate = examDate;
	}
}
