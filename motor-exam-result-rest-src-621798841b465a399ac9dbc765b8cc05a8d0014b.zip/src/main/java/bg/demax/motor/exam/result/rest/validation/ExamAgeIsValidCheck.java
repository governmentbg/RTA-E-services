package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;

import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.AgeRequirement;
import bg.demax.motor.exam.result.entity.AgeRequirementType;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.YearMonthDuration;
import bg.demax.motor.exam.result.rest.util.EntityUtil;
import bg.demax.motor.exam.result.rest.util.SubjectUtil;
import bg.demax.motor.exam.result.rest.validation.violations.AgeRequirementViolation;

@Component
public class ExamAgeIsValidCheck extends AbstractConstraintCheck<ExamAgeIsValidArgs> {

	@Override
	public void validate(ExamAgeIsValidArgs args) throws ConstraintCheckFailureException {
		ExamPerson examPerson = args.getExamPerson();
		long examTypeId = args.getExamTypeId();
		LocalDate examDate = args.getExamDate();
		
		boolean isPractical = examTypeId == ExamRequirement.ID_EXTERNAL_PRACTICAL;
		LocalDate birthDate = SubjectUtil.getSubjectBirthDate(examPerson.getSubjectVersion().getSubject());
		if (birthDate == null) {
			return;
		}
		for (AgeRequirement ageRequirement : EntityUtil.getAgeRequirements(examPerson.getLearningPlan())) {
			if ((isPractical && ageRequirement.getType().getId() == AgeRequirementType.ID_PRACTICAL_EXAM)
					|| (!isPractical && ageRequirement.getType().getId() == AgeRequirementType.ID_THEORETICAL_EXAM)) {
				YearMonthDuration requiredAge = ageRequirement.getDuration();
				LocalDate possibleRegistrationDate = birthDate.plusYears(requiredAge.getYears()).plusMonths(requiredAge.getMonths());
				if (possibleRegistrationDate.isAfter(examDate)) {
					throw new ConstraintCheckFailureException(new AgeRequirementViolation());
				}
			}
		}
	}

}
