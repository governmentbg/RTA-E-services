package bg.demax.motor.exam.result.rest.validation;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamResult;
import lombok.Getter;

@Getter
public class ExamMaterialIsCorrectArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = 1981056632658524196L;

	private ExamResult examResult;

	public ExamMaterialIsCorrectArgs(ExamResult examResult) {
		this.examResult = examResult;
	}
}
