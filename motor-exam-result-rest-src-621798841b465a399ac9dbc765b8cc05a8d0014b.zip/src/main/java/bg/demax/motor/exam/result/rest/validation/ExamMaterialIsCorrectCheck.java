package bg.demax.motor.exam.result.rest.validation;

import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.rest.validation.violations.WrongExamMaterialType;

@Component
public class ExamMaterialIsCorrectCheck extends AbstractConstraintCheck<ExamMaterialIsCorrectArgs> {
	
	@Override
	public void validate(ExamMaterialIsCorrectArgs args) throws ConstraintCheckFailureException {
		ExamResult examResult = args.getExamResult();
		if (examResult.getIsElectronicTest() != null && !isNextExamMaterialCorrect(examResult)) {
			throw new ConstraintCheckFailureException(new WrongExamMaterialType());
		}
	}
	
	private boolean isNextExamMaterialCorrect(ExamResult examResult) {
		if(examResult.getIsElectronicTest() == false) {
			return false;
		}
		return true;
	}

}
