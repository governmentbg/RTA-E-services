package bg.demax.motor.exam.result.rest.validation;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import lombok.Getter;

@Getter
public abstract class ExamPersonArg extends ConstraintCheckArgs {

	private static final long serialVersionUID = 4227610284290864076L;

	private ExamPerson examPerson;

	public ExamPersonArg(ExamPerson examPerson) {
		this.examPerson = examPerson;
	}
}
