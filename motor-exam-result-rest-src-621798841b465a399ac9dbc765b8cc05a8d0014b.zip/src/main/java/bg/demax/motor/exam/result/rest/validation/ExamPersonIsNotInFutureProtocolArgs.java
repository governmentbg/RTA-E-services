package bg.demax.motor.exam.result.rest.validation;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.Protocol;
import lombok.Getter;

@Getter
public class ExamPersonIsNotInFutureProtocolArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -7508226410579966605L;
	
	private ExamPerson examPerson;
	private boolean isPractical;
	private Protocol ignoredProtocol;

	public ExamPersonIsNotInFutureProtocolArgs(ExamPerson examPerson, boolean isPractical) {
		this.examPerson = examPerson;
		this.isPractical = isPractical;
		this.ignoredProtocol = null;
	}

	public ExamPersonIsNotInFutureProtocolArgs(ExamPerson examPerson, boolean isPractical, Protocol ignoredProtocol) {
		this.examPerson = examPerson;
		this.isPractical = isPractical;
		this.ignoredProtocol = ignoredProtocol;
	}
}
