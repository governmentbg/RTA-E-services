package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDateTime;
import java.util.HashSet;

import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.rest.validation.violations.ExamPersonInProtocolInProgress;

@Component
public class ExamPersonIsNotInFutureProtocolCheck extends AbstractConstraintCheck<ExamPersonIsNotInFutureProtocolArgs> {

	@Override
	public void validate(ExamPersonIsNotInFutureProtocolArgs args) throws ConstraintCheckFailureException {
		LocalDateTime now = LocalDateTime.now();
		for(ExamResult examResult : new HashSet<>(args.getExamPerson().getExamResults())) {
			Protocol protocol = examResult.getProtocol();
			if(!protocol.equals(args.getIgnoredProtocol()) && protocol.getExamTime().isAfter(now) 
					&& protocol.getExamType().isPractical() == args.isPractical()) {
				throw new ConstraintCheckFailureException(new ExamPersonInProtocolInProgress());
			}
		}
	}
}
