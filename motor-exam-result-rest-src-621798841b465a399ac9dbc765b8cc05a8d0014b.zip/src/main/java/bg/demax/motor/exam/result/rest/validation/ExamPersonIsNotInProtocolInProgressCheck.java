package bg.demax.motor.exam.result.rest.validation;

import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.rest.service.DriverExamineeService;
import bg.demax.motor.exam.result.rest.service.PracticalExamStateCandidateService;
import bg.demax.motor.exam.result.rest.validation.violations.ExamPersonInProtocolInProgress;

@Component
public class ExamPersonIsNotInProtocolInProgressCheck extends
		AbstractConstraintCheck<ExamPersonIsNotInProtocolInProgressArgs> {

	@Autowired
	private DriverExamineeService driverExamineeService;

	@Autowired
	private PracticalExamStateCandidateService practicalExamStateCandidateService;

	@Override
	public void validate(ExamPersonIsNotInProtocolInProgressArgs args) throws ConstraintCheckFailureException {

		ExamPerson examPerson = args.getExamPerson();

		for (ExamResult examResult : new HashSet<>(examPerson.getExamResults())) {
			if (practicalExamStateCandidateService.isExamResultInProtocolInProgress(examResult)
					|| driverExamineeService.isExamResultInProtocolInProgress(examResult)) {
				throw new ConstraintCheckFailureException(new ExamPersonInProtocolInProgress());
			}
		}
	}
}
