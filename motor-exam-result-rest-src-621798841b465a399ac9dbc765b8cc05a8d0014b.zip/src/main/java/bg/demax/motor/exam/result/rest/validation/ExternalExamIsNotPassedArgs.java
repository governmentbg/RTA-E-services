package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import lombok.Getter;

@Getter
public class ExternalExamIsNotPassedArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -762966074886030895L;

	private ExamPerson examPerson;
	private LocalDate atDate;
	private long examTypeId;

	public ExternalExamIsNotPassedArgs(ExamPerson examPerson, LocalDate atDate, long examTypeId) {
		this.examPerson = examPerson;
		this.atDate = atDate;
		this.examTypeId = examTypeId;
	}
}
