package bg.demax.motor.exam.result.rest.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckDispatcher;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.rest.validation.violations.ExamAlreadyPassed;

@Component
public class ExternalExamIsNotPassedCheck extends AbstractConstraintCheck<ExternalExamIsNotPassedArgs> {

	@Autowired
	private ConstraintCheckDispatcher constraintCheckDispatcher;
	
	@Override
	public void validate(ExternalExamIsNotPassedArgs args) throws ConstraintCheckFailureException {
		boolean isPassed = false;
		try {
			constraintCheckDispatcher.check(new ExternalExamIsPassedArgs(args.getExamPerson(), args.getAtDate(), args.getExamTypeId()));
			isPassed = true;
		} catch (ConstraintCheckFailureException e) {
		}
		if(isPassed) {
			throw new ConstraintCheckFailureException(new ExamAlreadyPassed());
		}		
	}

}
