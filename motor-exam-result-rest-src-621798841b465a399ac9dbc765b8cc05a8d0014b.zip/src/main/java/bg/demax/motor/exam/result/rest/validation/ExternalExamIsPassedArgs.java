package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import lombok.Getter;

@Getter
public class ExternalExamIsPassedArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = 8185940540660732043L;

	private ExamPerson examPerson;
	private LocalDate atDate;
	private long examTypeId;

	public ExternalExamIsPassedArgs(ExamPerson examPerson, LocalDate atDate, long examTypeId) {
		this.examPerson = examPerson;
		this.examTypeId = examTypeId;
		this.atDate = atDate;
	}

}
