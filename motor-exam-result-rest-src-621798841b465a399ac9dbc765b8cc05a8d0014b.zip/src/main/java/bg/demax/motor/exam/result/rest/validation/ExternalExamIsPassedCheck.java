package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.rest.db.repository.ExamResultRepository;
import bg.demax.motor.exam.result.rest.db.repository.ExamTypeRepository;
import bg.demax.motor.exam.result.rest.db.repository.SubCategoryTransitionRepository;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;
import bg.demax.motor.exam.result.rest.util.EntityUtil;
import bg.demax.motor.exam.result.rest.validation.violations.PracticeNotPassed;
import bg.demax.motor.exam.result.rest.validation.violations.TheoryNotPassed;
import bg.demax.pub.entity.Subject;

@Component
public class ExternalExamIsPassedCheck extends AbstractConstraintCheck<ExternalExamIsPassedArgs> {

	@Autowired
	private ExamResultRepository examResultRepository;
	
	@Autowired
	private ExamPersonService examPersonService;
	
	@Autowired
	private ExamTypeRepository examTypeRepository;
	
	@Autowired
	private SubCategoryTransitionRepository subCategoryTransitionRepository;
	
	@Override
	@Transactional(readOnly = true)
	public void validate(ExternalExamIsPassedArgs args) throws ConstraintCheckFailureException {
		ExamPerson examPerson = args.getExamPerson();
		LearningPlan learningPlan = examPerson.getLearningPlan();
		long examTypeId = args.getExamTypeId();
		if(EntityUtil.hasExamOfType(learningPlan, examTypeId)) {
			if(!hasPassedExam(examPerson, args.getAtDate(), examTypeId)) {
				if(examTypeId == ExamRequirement.ID_EXTERNAL_THEORETICAL) {
					throw new ConstraintCheckFailureException(new TheoryNotPassed());
					
				} else {
					throw new ConstraintCheckFailureException(new PracticeNotPassed());
				}
			}
		}	
	}
	
	private boolean hasPassedExam(ExamPerson examPerson, LocalDate atDate, long examTypeId) {		
		Subject subject = examPerson.getSubjectVersion().getSubject();
		SubCategory subCategory = examPerson.getLearningPlan().getTargetCategory();
		ExamRequirement examType = examTypeRepository.findById(examTypeId).get();
		
		LocalDate latestLicenceLossDate = examPersonService.getLatestLicenceLossDate(subject.getIdentityNumber());
		
		LocalDate validAfter = null;

		if (!examType.isPractical() && atDate != null) {
			
			//TODO PANDEMIC CHECK DELETE AFTER TIME SPAN
			LocalDate localAtDate = atDate;
			if (localAtDate.isBefore(LocalDate.of(2020, 6, 13))) {
				validAfter = LocalDate.of(2019, 03, 13);
			} else {
				validAfter = atDate.minusYears(1);
			}
		}
		
		if (validAfter == null || (latestLicenceLossDate != null && latestLicenceLossDate.isAfter(validAfter))) {
			validAfter = latestLicenceLossDate;
		}

		List<SubCategory> subCategoriesToCheck = subCategoryTransitionRepository.getParentCategories(subCategory);
		subCategoriesToCheck.add(0, subCategory);

		for (SubCategory subCategoryToCheck : subCategoriesToCheck) {
			List<ExamResult> examResults = examResultRepository.findPassedExamResultsAfter(subject, subCategoryToCheck,
					examType, validAfter.atStartOfDay());
			if (!examResults.isEmpty()) {
				return true;
			}
		}
		
		return false;
	}

}
