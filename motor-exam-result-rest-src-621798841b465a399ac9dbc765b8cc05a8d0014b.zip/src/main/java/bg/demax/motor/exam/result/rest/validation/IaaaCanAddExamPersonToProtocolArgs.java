package bg.demax.motor.exam.result.rest.validation;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.Protocol;
import lombok.Getter;

@Getter
public class IaaaCanAddExamPersonToProtocolArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -6932786589380161638L;

	private Protocol protocol;
	private ExamPerson examPerson;

	public IaaaCanAddExamPersonToProtocolArgs(Protocol protocol, ExamPerson examPerson) {
		this.protocol = protocol;
		this.examPerson = examPerson;
	}
}
