package bg.demax.motor.exam.result.rest.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.permit.entity.Permit;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.rest.db.repository.PermitRepository;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;
import bg.demax.motor.exam.result.rest.validation.violations.AddingCandidateNotPermitted;

@Component
public class IaaaCanAddExamPersonToProtocolCheck extends AbstractConstraintCheck<IaaaCanAddExamPersonToProtocolArgs> {

	@Autowired
	private ExamPersonService examPersonService;
	
	@Autowired
	private PermitRepository permitRepository;
	
	@Override
	@Transactional(readOnly = true)
	public void validate(IaaaCanAddExamPersonToProtocolArgs args) throws ConstraintCheckFailureException {
		Protocol protocol = args.getProtocol();
		ExamPerson examPerson = args.getExamPerson();
		
		Permit iaaaPermit = permitRepository.getLastIaaaPermitForOrgUnit(protocol.getOrgUnit()).get(0);
		if(iaaaPermit != null && examPerson.getCompany().getNumber() == iaaaPermit.getNumber()) {
			return;
		}
		
		if (protocol.getExamType().isPractical()) {
			throw new ConstraintCheckFailureException(new AddingCandidateNotPermitted());
		}
		
		//FIXME: is this not a check candidate?
		if (!examPersonService.canBeAddedToTheoreticalProtocolByIaaa(examPerson)) {
			throw new ConstraintCheckFailureException(new AddingCandidateNotPermitted());
		}
	}

}
