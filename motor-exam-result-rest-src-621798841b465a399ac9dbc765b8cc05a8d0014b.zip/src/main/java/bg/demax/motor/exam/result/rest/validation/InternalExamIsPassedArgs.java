package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import lombok.Getter;

@Getter
public class InternalExamIsPassedArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -5958552565135640703L;

	private String identityNumber;
	private SubCategory subCategory;
	private LocalDate examDate;
	private boolean isPracticalExam;

	public InternalExamIsPassedArgs(String identityNumber, SubCategory subCategory, LocalDate examDate, boolean isPracticalExam) {
		this.identityNumber = identityNumber;
		this.subCategory = subCategory;
		this.examDate = examDate;
		this.isPracticalExam = isPracticalExam;
	}

	public InternalExamIsPassedArgs(String identityNumber, SubCategory subCategory, boolean isPracticalExam) {
		this.identityNumber = identityNumber;
		this.subCategory = subCategory;
		this.isPracticalExam = isPracticalExam;
		this.examDate = null;
	}
	
	public InternalExamIsPassedArgs(ExamPerson examPerson, LocalDate examDate, boolean isPracticalExam) {
		this.identityNumber = examPerson.getSubjectVersion().getSubject().getIdentityNumber();
		this.subCategory = examPerson.getLearningPlan().getTargetCategory();
		this.examDate = examDate;
		this.isPracticalExam = isPracticalExam;
	}

}
