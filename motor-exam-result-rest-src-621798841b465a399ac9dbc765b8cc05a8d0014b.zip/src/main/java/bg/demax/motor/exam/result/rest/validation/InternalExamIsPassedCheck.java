package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.InternalExam;
import bg.demax.motor.exam.result.rest.db.repository.InternalExamRepository;
import bg.demax.motor.exam.result.rest.db.repository.SubCategoryTransitionRepository;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;
import bg.demax.motor.exam.result.rest.validation.violations.RequiredInternalExamNotPassed;

@Component
public class InternalExamIsPassedCheck extends AbstractConstraintCheck<InternalExamIsPassedArgs> {

	@Autowired
	private InternalExamRepository internalExamRepository;
	
	@Autowired
	private ExamPersonService examPersonService;
	
	@Autowired
	private SubCategoryTransitionRepository subCategoryTransitionRepository;

	@Override
	@Transactional(readOnly = true)
	public void validate(InternalExamIsPassedArgs args) throws ConstraintCheckFailureException {
		String identityNumber = args.getIdentityNumber();
		LocalDate examDate = args.getExamDate();
		SubCategory subCategory = args.getSubCategory();
		long examTypeId = args.isPracticalExam() ? ExamRequirement.ID_INTERNAL_PRACTICAL : ExamRequirement.ID_INTERNAL_THEORETICAL;
		LocalDate latestLicenceLoss = examPersonService.getLatestLicenceLossDate(args.getIdentityNumber());
		
		List<SubCategory> subCategoriesToCheck = subCategoryTransitionRepository.getParentCategories(subCategory);
		subCategoriesToCheck.add(0, subCategory);
		
		for(SubCategory subCategoryToCheck : subCategoriesToCheck) {
			InternalExam lastPassedInternalExam;
			
			if (latestLicenceLoss == null && examDate == null) {
				lastPassedInternalExam = internalExamRepository.getLastPassedInternalExamBetween(identityNumber,
						subCategoryToCheck, examTypeId);
			} else {
				lastPassedInternalExam = internalExamRepository.getLastPassedInternalExamBetween(identityNumber,
						subCategoryToCheck, examTypeId, latestLicenceLoss, examDate);
			}
			
			if(lastPassedInternalExam != null) {
				if(isWithin6Months(lastPassedInternalExam, examDate) || isWithinPandemicExpansionDate(lastPassedInternalExam, examDate)) {
					return;
				}
			}
		}
		
		throw new ConstraintCheckFailureException(new RequiredInternalExamNotPassed());
	}

	//TODO DELETE AFTER THE PANDEMIC END
	private boolean isWithinPandemicExpansionDate(InternalExam lastPassedInternalExam, LocalDate examDate) {
		LocalDate localAtDate = examDate;
		if (localAtDate.isBefore(LocalDate.of(2020, 6, 13))) {
			LocalDate validityDate = lastPassedInternalExam.getDate().plusMonths(8);
			return !validityDate.isBefore(examDate);
		}
		return false;
	}

	private boolean isWithin6Months(InternalExam lastPassedInternalExam, LocalDate examDate) {
		LocalDate validityDate = examDate.plusMonths(6);
		return !validityDate.isBefore(examDate);
	}

}
