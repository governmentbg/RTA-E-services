package bg.demax.motor.exam.result.rest.validation;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import lombok.Getter;

@Getter
public class LearningPlanIsFulfilledArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -854149700881761691L;

	private ExamPerson examPerson;

	public LearningPlanIsFulfilledArgs(ExamPerson examPerson) {
		this.examPerson = examPerson;
	}
}
