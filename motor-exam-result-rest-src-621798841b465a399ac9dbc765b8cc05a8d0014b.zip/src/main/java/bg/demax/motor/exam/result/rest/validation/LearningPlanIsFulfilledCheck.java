package bg.demax.motor.exam.result.rest.validation;

import java.util.HashSet;

import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.rest.util.EntityUtil;
import bg.demax.motor.exam.result.rest.validation.violations.RequiredCategoryNotPresent;

@Component
public class LearningPlanIsFulfilledCheck extends AbstractConstraintCheck<LearningPlanIsFulfilledArgs> {

	@Override
	public void validate(LearningPlanIsFulfilledArgs args) throws ConstraintCheckFailureException {
		ExamPerson examPerson = args.getExamPerson();
		LearningPlan learningPlan = examPerson.getLearningPlan();
		
		boolean hasExternalTheoretical = false;
		boolean hasExternalPractical = false;
		for(ExamRequirement examRequirement : EntityUtil.getExamRequirements(learningPlan)) {
			if(!examRequirement.isInternal()) {
				if(examRequirement.isPractical()) {
					hasExternalPractical = true;
				} else {
					hasExternalTheoretical = true;
				}
			}
		}
		
		boolean isPassed = true;
		if(hasExternalPractical) {
			ExamResult examResult = getPassedExamResultMatchingRequirement(examPerson, ExamRequirement.ID_EXTERNAL_PRACTICAL);
			isPassed &= (examResult != null);
		} else if(hasExternalTheoretical) {
			ExamResult examResult = getPassedExamResultMatchingRequirement(examPerson, ExamRequirement.ID_EXTERNAL_THEORETICAL);
			isPassed &= (examResult != null);
		}
		
		if(!isPassed) {
			throw new ConstraintCheckFailureException(new RequiredCategoryNotPresent());
		}
	}
	
	private ExamResult getPassedExamResultMatchingRequirement(ExamPerson examPerson, long examRequirementId) {
		for (ExamResult examResult : new HashSet<>(examPerson.getExamResults())) {
			if (examResult.getProtocol().getExamType().getId() == examRequirementId && examResult.isPassed() != null && examResult.isPassed() == true) {
				return examResult;
			}
		}
		return null;
	}

}
