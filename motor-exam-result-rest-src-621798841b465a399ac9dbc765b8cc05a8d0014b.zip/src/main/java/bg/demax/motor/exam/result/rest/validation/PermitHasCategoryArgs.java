package bg.demax.motor.exam.result.rest.validation;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.permit.entity.Permit;
import lombok.Getter;

@Getter
public class PermitHasCategoryArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = 813812786123540578L;
	
	private Permit permit;
	private SubCategory subCategory;

	public PermitHasCategoryArgs(Permit permit, SubCategory subCategory) {
		this.permit = permit;
		this.subCategory = subCategory;
	}
}
