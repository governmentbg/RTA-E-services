package bg.demax.motor.exam.result.rest.validation;

import org.springframework.stereotype.Component;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.permit.entity.Permit;
import bg.demax.motor.exam.result.rest.validation.violations.PermitCategoryMissing;

@Component
public class PermitHasCategoryCheck extends AbstractConstraintCheck<PermitHasCategoryArgs> {

	@Override
	public void validate(PermitHasCategoryArgs args) throws ConstraintCheckFailureException {
		Permit permit = args.getPermit();
		SubCategory subCategory = args.getSubCategory();
		
		for(SubCategory permitCategory : permit.getSubCategories()) {
			if(permitCategory.equals(subCategory)) {
				return;
			}
		}
		throw new ConstraintCheckFailureException(new PermitCategoryMissing(subCategory));
	}

}
