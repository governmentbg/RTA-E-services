package bg.demax.motor.exam.result.rest.validation;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.permit.entity.Permit;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import lombok.Getter;

@Getter
public class PermitSupportsExamTypeArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -1854882113646220958L;
	
	private Permit permit;
	private ExamRequirement examRequirement;

	public PermitSupportsExamTypeArgs(Permit permit, ExamRequirement examRequirement) {
		this.permit = permit;
		this.examRequirement = examRequirement;
	}
}
