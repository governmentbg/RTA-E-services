package bg.demax.motor.exam.result.rest.validation;

import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.permit.entity.Permit;
import bg.demax.motor.exam.permit.enums.ExamTypePermission;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.rest.validation.violations.PermitNotAllowedForExamType;

@Component
public class PermitSupportsExamTypeCheck extends AbstractConstraintCheck<PermitSupportsExamTypeArgs> {

	@Override
	public void validate(PermitSupportsExamTypeArgs args) throws ConstraintCheckFailureException {
		Permit permit = args.getPermit();
		ExamRequirement examType = args.getExamRequirement();
		if(examType.isPractical()) {
			if (permit.getForExamType() == ExamTypePermission.THEORY) {
				throw new ConstraintCheckFailureException(new PermitNotAllowedForExamType());
			}
		} else {
			if(permit.getForExamType() == ExamTypePermission.PRACTICE) {
				throw new ConstraintCheckFailureException(new PermitNotAllowedForExamType());
			}
		}		
	}

}
