package bg.demax.motor.exam.result.rest.validation;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.rest.db.entity.TaxiDocumentType;
import bg.demax.pub.entity.Municipality;
import lombok.Getter;

@Getter
public class PersonAlreadyHasActiveDocumentInMunicipalityArgs extends ConstraintCheckArgs {
	
	private static final long serialVersionUID = 8177298342857150351L;
	private String identNumb; 
	private Municipality municipality; 
	private int taxiDocumentType;
	private Long documentId;

	public PersonAlreadyHasActiveDocumentInMunicipalityArgs(Long documentId, String identNumb, Municipality municipality, int taxiDocumentType) {
		this.identNumb = identNumb;
		this.municipality = municipality;
		this.taxiDocumentType = taxiDocumentType;
		this.documentId = documentId;
	}

	public PersonAlreadyHasActiveDocumentInMunicipalityArgs(String identNumb, Boolean isTaxiManager, Municipality municipality) {
		this.identNumb = identNumb;
		this.municipality = municipality;
		this.taxiDocumentType = getDocumentType(isTaxiManager);
		this.documentId = null;
	}

	private int getDocumentType(Boolean isTaxiManager) {
		if(isTaxiManager){
			return TaxiDocumentType.MANAGER_ID;
		} else {
			return TaxiDocumentType.DRIVER_ID;
		}
	}
}
