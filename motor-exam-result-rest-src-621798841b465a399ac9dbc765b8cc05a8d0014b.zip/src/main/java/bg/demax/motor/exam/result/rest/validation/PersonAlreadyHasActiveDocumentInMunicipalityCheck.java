package bg.demax.motor.exam.result.rest.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.rest.db.entity.TaxiDocumentType;
import bg.demax.motor.exam.result.rest.service.TaxiDocumentService;
import bg.demax.motor.exam.result.rest.validation.violations.DriverAlreadyHasActiveTaxiDocument;
import bg.demax.pub.entity.Municipality;

@Component
public class PersonAlreadyHasActiveDocumentInMunicipalityCheck extends AbstractConstraintCheck<PersonAlreadyHasActiveDocumentInMunicipalityArgs> {
	
	@Autowired 
	private TaxiDocumentService taxiDocumentService;

	@Override
	public void validate(PersonAlreadyHasActiveDocumentInMunicipalityArgs args) throws ConstraintCheckFailureException {
		Long docId = args.getDocumentId();
		String identNumber = args.getIdentNumb();
		Municipality mun = args.getMunicipality();
		int type = args.getTaxiDocumentType();
		
		if(type == TaxiDocumentType.DRIVER_ID){
			if(taxiDocumentService.hasActiveDocumentInMunicipality(docId, identNumber, mun, TaxiDocumentType.DRIVER_ID) || 
					taxiDocumentService.hasActiveDocumentInMunicipality(docId, identNumber, mun, TaxiDocumentType.DRIVER_PROLONG_ID)){
				throw new ConstraintCheckFailureException(new DriverAlreadyHasActiveTaxiDocument());
			}
			
		} else {
			if(taxiDocumentService.hasActiveDocumentInMunicipality(docId, identNumber, mun, type)){
				throw new ConstraintCheckFailureException(new DriverAlreadyHasActiveTaxiDocument());
			}
		}
		
	}

}
