package bg.demax.motor.exam.result.rest.validation;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.Protocol;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class PersonIsNotInSameProtocolArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = 4448059902105093114L;

	private Protocol protocol;
	private ExamResult examResult;
}
