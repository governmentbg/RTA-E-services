package bg.demax.motor.exam.result.rest.validation;

import java.util.Set;

import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.rest.validation.violations.PersonIsAlreadyInSameProtocol;

@Component
public class PersonIsNotInSameProtocolCheck extends AbstractConstraintCheck<PersonIsNotInSameProtocolArgs> {

	@Override
	public void validate(PersonIsNotInSameProtocolArgs args) throws ConstraintCheckFailureException {
		ExamResult examResult = args.getExamResult();
		Protocol protocol = args.getProtocol();
		
		String identNum = examResult.getExamPerson().getSubjectVersion().getSubject().getIdentityNumber();
		
		Set<ExamResult> examResults = protocol.getExamResults();
		for (ExamResult er : examResults) {
			String otherIdentNum = er.getExamPerson().getSubjectVersion().getSubject().getIdentityNumber();
			if (otherIdentNum.equals(identNum) && !er.equals(examResult)) {
				throw new ConstraintCheckFailureException(new PersonIsAlreadyInSameProtocol());
			}
		}
	}

}
