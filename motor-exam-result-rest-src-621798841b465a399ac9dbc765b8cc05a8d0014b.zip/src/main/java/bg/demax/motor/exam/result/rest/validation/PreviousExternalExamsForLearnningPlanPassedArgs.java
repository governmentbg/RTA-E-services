package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import lombok.Getter;

@Getter
public class PreviousExternalExamsForLearnningPlanPassedArgs extends ConstraintCheckArgs {
	
	private static final long serialVersionUID = 1745211029870850316L;
	
	private ExamPerson examPerson;
	private LocalDate examDate;
	private long examTypeId;

	public PreviousExternalExamsForLearnningPlanPassedArgs(ExamPerson examPerson, LocalDate examDate, long examTypeId) {
		this.examPerson = examPerson;
		this.examDate = examDate;
		this.examTypeId = examTypeId;
	}
}
