package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.rest.db.repository.ExamResultRepository;
import bg.demax.motor.exam.result.rest.db.repository.ExamTypeRepository;
import bg.demax.motor.exam.result.rest.db.repository.SubCategoryTransitionRepository;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;
import bg.demax.motor.exam.result.rest.validation.violations.NoPastExternalExamsPassed;
import bg.demax.pub.entity.Subject;

@Component
public class PreviousExternalExamsForLearnningPlanPassedCheck extends AbstractConstraintCheck<PreviousExternalExamsForLearnningPlanPassedArgs> {
	
	@Autowired
	private ExamPersonService examPersonService;
	
	@Autowired
	private ExamResultRepository examResultRepository;
	
	@Autowired
	private SubCategoryTransitionRepository subCategoryTransitionRepository;
	
	@Autowired
	private ExamTypeRepository examTypeRepository;
	
	@Override
	@Transactional(readOnly = true)
	public void validate(PreviousExternalExamsForLearnningPlanPassedArgs args) throws ConstraintCheckFailureException {
		
		LocalDate examDate = args.getExamDate();
		ExamPerson examPerson = args.getExamPerson();
		LearningPlan learningPlan =  examPerson.getLearningPlan();
		long examTypeId = args.getExamTypeId();
		
		if(!hasPassedExam(examPerson, learningPlan, examDate, examTypeId)){
			throw new ConstraintCheckFailureException(new NoPastExternalExamsPassed());
		}
	}

	private boolean hasPassedExam(ExamPerson examPerson, LearningPlan learningPlan, LocalDate examDate, long examTypeId) {
		Subject subject = examPerson.getSubjectVersion().getSubject();
		
		LocalDate latestLicenceLossDate = examPersonService.getLatestLicenceLossDate(subject.getIdentityNumber());
		
		SubCategory subCategory = examPerson.getLearningPlan().getTargetCategory();
		ExamRequirement examType = examTypeRepository.findById(examTypeId).get();
		
		List<SubCategory> subCategoriesToCheck = subCategoryTransitionRepository.getParentCategories(subCategory);
		subCategoriesToCheck.add(0, subCategory);

		for (SubCategory subCategoryToCheck : subCategoriesToCheck) {
			List<ExamResult> examResults;
			if(latestLicenceLossDate == null) {
				examResults = examResultRepository.findPassedExamResultsAfter(subject, subCategoryToCheck, examType);
			} else {
				examResults = examResultRepository.findPassedExamResultsAfter(subject, subCategoryToCheck, examType, latestLicenceLossDate.atStartOfDay());
			}
			
			if (!examResults.isEmpty()) {
				return true;
			}
		}

		return false;
	}

}
