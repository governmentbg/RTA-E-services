package bg.demax.motor.exam.result.rest.validation;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.Protocol;
import lombok.Getter;

@Getter
public class ProtocolHasEnoughCapacityArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = 4310091727461431915L;

	private ExamResult examResult;
	private Protocol protocol;

	public ProtocolHasEnoughCapacityArgs(ExamResult examResult, Protocol protocol) {
		this.examResult = examResult;
		this.protocol = protocol;
	}
}
