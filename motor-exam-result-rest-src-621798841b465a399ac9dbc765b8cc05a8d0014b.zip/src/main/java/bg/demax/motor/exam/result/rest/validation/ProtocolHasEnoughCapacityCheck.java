package bg.demax.motor.exam.result.rest.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.practical.entity.PracticalExamRoadDuration;
import bg.demax.motor.exam.result.rest.service.PracticalExamDurationService;
import bg.demax.motor.exam.result.rest.util.ExamCommitteeUtil;
import bg.demax.motor.exam.result.rest.util.ExamResultUtil;
import bg.demax.motor.exam.result.rest.validation.violations.InsufficientCapacity;

@Component
public class ProtocolHasEnoughCapacityCheck extends AbstractConstraintCheck<ProtocolHasEnoughCapacityArgs> {
	
	@Autowired
	private PracticalExamDurationService practicalExamDurationService;
	
	@Override
	public void validate(ProtocolHasEnoughCapacityArgs args) throws ConstraintCheckFailureException {
		if(!canAddExamResult(args.getProtocol(), args.getExamResult())) {
			throw new ConstraintCheckFailureException(new InsufficientCapacity());
		}
	}
	
	private boolean canAddExamResult(Protocol protocol, ExamResult examResult) {
		if (protocol.getExamType().isPractical()) {
			int duration = practicalExamDurationService.getPracticalProtocolDuration(protocol);
			SubCategory subCategory = examResult.getExamPerson().getLearningPlan().getTargetCategory();
			int requiredDuration = 0;
			if (ExamResultUtil.getGroundNeeded(examResult) && !ExamResult.ATTR_RESULT_YES.equalsIgnoreCase(ExamResultUtil.getGroundResult(examResult))) {
				requiredDuration += 10;
			}
			if (ExamResultUtil.getRoadNeeded(examResult)) {
				PracticalExamRoadDuration practicalExamRoadDuration = practicalExamDurationService.getForSubCategory(subCategory);
				if (practicalExamRoadDuration != null) {
					requiredDuration += practicalExamRoadDuration.getMinDurationMinutes();
				}
			}
			return ExamCommitteeUtil.getRemainingTime(duration, protocol) >= requiredDuration;
		} else {
			int examResultsCount = protocol.getExamResults().size();
			int seatplaces = 0;
			if (protocol.getExamRoom() != null) {
				seatplaces = protocol.getExamRoom().getExamSeats();
			}
			Integer maxEtestCount = protocol.getMaxEtestCount();
			if (maxEtestCount != null) {
				seatplaces = Math.max(seatplaces, maxEtestCount);
			}
			if (seatplaces > 25) {
				seatplaces = 25;
			}
			return examResultsCount < seatplaces;
		}
	}
}
