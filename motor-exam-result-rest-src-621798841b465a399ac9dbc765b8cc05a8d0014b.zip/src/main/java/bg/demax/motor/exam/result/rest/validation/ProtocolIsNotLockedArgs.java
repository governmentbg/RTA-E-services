package bg.demax.motor.exam.result.rest.validation;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.Protocol;
import lombok.Getter;

@Getter
public class ProtocolIsNotLockedArgs extends ConstraintCheckArgs {
	private static final long serialVersionUID = 6886289021084594935L;

	private Protocol protocol;

	public ProtocolIsNotLockedArgs(Protocol protocol) {
		this.protocol = protocol;
	}
}
