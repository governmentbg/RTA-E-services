package bg.demax.motor.exam.result.rest.validation;

import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.motor.exam.result.rest.validation.violations.ProtocolIsLocked;

@Component
public class ProtocolIsNotLockedCheck extends AbstractConstraintCheck<ProtocolIsNotLockedArgs> {

	@Override
	public void validate(ProtocolIsNotLockedArgs args) throws ConstraintCheckFailureException {
		Protocol protocol = args.getProtocol();
		if(protocol.getNumber() != null || protocol.getChairman() != null) {
			throw new ConstraintCheckFailureException(new ProtocolIsLocked());
		}
	}
}
