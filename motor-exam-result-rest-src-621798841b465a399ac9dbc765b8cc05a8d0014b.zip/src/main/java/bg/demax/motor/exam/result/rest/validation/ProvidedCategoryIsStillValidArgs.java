package bg.demax.motor.exam.result.rest.validation;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ProvidedCategory;
import lombok.Getter;

@Getter
public class ProvidedCategoryIsStillValidArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -5437452095324732221L;

	private ProvidedCategory providedCategory;

	public ProvidedCategoryIsStillValidArgs(ProvidedCategory providedCategory) {
		this.providedCategory = providedCategory;
	}
}
