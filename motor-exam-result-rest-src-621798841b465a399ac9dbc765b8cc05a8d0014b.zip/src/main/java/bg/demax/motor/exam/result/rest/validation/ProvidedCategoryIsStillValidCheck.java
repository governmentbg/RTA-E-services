package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.entity.ProvidedCategory;
import bg.demax.motor.exam.result.rest.db.repository.ExamResultRepository;
import bg.demax.motor.exam.result.rest.db.repository.SubCategoryTransitionRepository;
import bg.demax.motor.exam.result.rest.validation.violations.ProvidedCategoryIsVoided;
import bg.demax.pub.entity.Subject;

@Component
public class ProvidedCategoryIsStillValidCheck extends AbstractConstraintCheck<ProvidedCategoryIsStillValidArgs> {

	@Autowired
	private ExamResultRepository examResultRepository;
	
	@Autowired
	private SubCategoryTransitionRepository subCategoryTransitionRepository;
	
	@Override
	public void validate(ProvidedCategoryIsStillValidArgs args) throws ConstraintCheckFailureException {
		ProvidedCategory providedCategory = args.getProvidedCategory();
		Subject subject = providedCategory.getExamPerson().getSubjectVersion().getSubject();
		List<SubCategory> subCategories = subCategoryTransitionRepository.getParentCategories(providedCategory.getCategory());
		subCategories.add(0, providedCategory.getCategory());
		LocalDate date = providedCategory.getDate();
		for(SubCategory subCategory : subCategories) {
			List<ExamResult> examResults = examResultRepository.findInvalidatedForidentityNumberAndCategoryAfter(subject.getIdentityNumber(), subCategory, date.atStartOfDay());
			if(!examResults.isEmpty()) {
				for(ExamResult examResult : examResults) {
					if(!examResult.getExamPerson().getLearningPlan().is157()) {
						throw new ConstraintCheckFailureException(new ProvidedCategoryIsVoided());
					}
				}
			}
		}
	}

}
