package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import lombok.Getter;

@Getter
public class RegisteredInValidExamArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -6132103366315907942L;

	private String identityNumber;
	private SubCategory subCategory;
	private boolean isForPracticalTraining;
	private LocalDate afterWhen;

	public RegisteredInValidExamArgs(String identityNumber, SubCategory subCategory, LocalDate afterWhen, boolean isForPracticalTraining) {
		this.identityNumber = identityNumber;
		this.subCategory = subCategory;
		this.isForPracticalTraining = isForPracticalTraining;
		this.afterWhen = afterWhen;
	}

	public RegisteredInValidExamArgs(ExamPerson examPerson, boolean isForPracticalTraining) {
		this.identityNumber = examPerson.getSubjectVersion().getSubject().getIdentityNumber();
		this.subCategory = examPerson.getLearningPlan().getTargetCategory();
		this.isForPracticalTraining = isForPracticalTraining;
	}
}
