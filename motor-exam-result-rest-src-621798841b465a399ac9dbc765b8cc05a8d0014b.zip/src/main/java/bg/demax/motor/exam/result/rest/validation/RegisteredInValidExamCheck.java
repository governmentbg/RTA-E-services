package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.ExamResult;
import bg.demax.motor.exam.result.rest.db.repository.ExamResultRepository;
import bg.demax.motor.exam.result.rest.db.repository.SubCategoryTransitionRepository;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;
import bg.demax.motor.exam.result.rest.validation.violations.NoValidExams;

@Component
public class RegisteredInValidExamCheck extends AbstractConstraintCheck<RegisteredInValidExamArgs> {
	
	@Autowired
	private ExamResultRepository examResultRepository;
	
	@Autowired
	private SubCategoryTransitionRepository subCategoryTransitionRepository;
	
	@Autowired
	private ExamPersonService examPersonService;
	
	@Override
	@Transactional(readOnly = true)
	public void validate(RegisteredInValidExamArgs args) throws ConstraintCheckFailureException {
		SubCategory subCategory = args.getSubCategory();
		String identityNumber = args.getIdentityNumber();
		
		List<SubCategory> subCategoriesToCheck = subCategoryTransitionRepository.getParentCategories(subCategory);
		subCategoriesToCheck.add(0, subCategory);
		
		LocalDate latestLicenceLossDat = examPersonService.getLatestLicenceLossDate(identityNumber);
		
		LocalDate afterWhen = args.getAfterWhen();
		
		for(SubCategory subCategoryToCheck : subCategoriesToCheck) {
			List<ExamResult> examResults = examResultRepository.getLastValid(identityNumber, subCategoryToCheck, args.isForPracticalTraining() ? ExamRequirement.ID_EXTERNAL_PRACTICAL : ExamRequirement.ID_EXTERNAL_THEORETICAL);
			ExamResult examResult = null;
			if (examResults != null && !examResults.isEmpty()) {
				examResult = examResults.get(0);
			}
			
			if(examResult != null && (latestLicenceLossDat == null 
					|| (!examResult.getProtocol().getExamTime().toLocalDate().isBefore(latestLicenceLossDat)))) {
				if (afterWhen == null || examResult.getProtocol().getExamTime().toLocalDate().isAfter(afterWhen)) {
					return;
				}
			}
		}
		
		throw new ConstraintCheckFailureException(new NoValidExams());
	}

}
