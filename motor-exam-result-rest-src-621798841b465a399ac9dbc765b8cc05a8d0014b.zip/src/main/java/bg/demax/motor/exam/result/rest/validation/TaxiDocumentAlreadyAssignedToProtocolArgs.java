package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDateTime;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.Protocol;
import bg.demax.pub.entity.SubjectVersion;
import lombok.Getter;

@Getter
public class TaxiDocumentAlreadyAssignedToProtocolArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = 2225678961630986531L;
	
	private Long subjVersionId;
	private LocalDateTime protocolExamTime;
	private Integer protocolNumber;

	public TaxiDocumentAlreadyAssignedToProtocolArgs(SubjectVersion subjectVersion, Protocol protocol) {
		this.subjVersionId = subjectVersion.getId();
		this.protocolNumber = protocol.getNumber();
		this.protocolExamTime = protocol.getExamTime();
	}
}
