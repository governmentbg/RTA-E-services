package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.rest.service.TaxiDocumentService;
import bg.demax.motor.exam.result.rest.validation.violations.DocumentAlreadyAssignedToProtocol;

@Component
public class TaxiDocumentAlreadyAssignedToProtocolCheck extends AbstractConstraintCheck<TaxiDocumentAlreadyAssignedToProtocolArgs> {

	@Autowired 
	private TaxiDocumentService taxiDocumentService;
	
	@Override
	public void validate(TaxiDocumentAlreadyAssignedToProtocolArgs args) throws ConstraintCheckFailureException {
		
		Long subjVersionId = args.getSubjVersionId();
		LocalDateTime protocolExamTime = args.getProtocolExamTime();
		Integer protocolNumber = args.getProtocolNumber();
		Boolean taxiDocumentAlreadyAssignedToProtocol = taxiDocumentService.taxiDocumentAlreadyAssignedToProtocol(subjVersionId, protocolExamTime, protocolNumber);
		if (taxiDocumentAlreadyAssignedToProtocol){
			 throw new ConstraintCheckFailureException(new DocumentAlreadyAssignedToProtocol());
		}
	}
}
