package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.LearningPlan;
import lombok.Getter;

@Getter
public class TrainingIsPassedArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -8346045123795415960L;

	private String identityNumber;
	private LearningPlan learningPlan;
	private boolean isPractical;
	private LocalDate atDate;

	public TrainingIsPassedArgs(String identityNumber, LearningPlan learningPlan, boolean isPractical, LocalDate atDate) {
		this.identityNumber = identityNumber;
		this.learningPlan = learningPlan;
		this.isPractical = isPractical;
		this.atDate = atDate;
	}

	public TrainingIsPassedArgs(ExamPerson examPerson, boolean isPractical, LocalDate atDate) {
		this.identityNumber = examPerson.getSubjectVersion().getSubject().getIdentityNumber();
		this.learningPlan = examPerson.getLearningPlan();
		this.isPractical = isPractical;
		this.atDate = atDate;
	}
}
