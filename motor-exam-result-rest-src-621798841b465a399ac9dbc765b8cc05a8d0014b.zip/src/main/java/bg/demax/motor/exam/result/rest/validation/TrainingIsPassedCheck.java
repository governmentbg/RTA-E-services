package bg.demax.motor.exam.result.rest.validation;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckDispatcher;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamRequirement;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.rest.util.EntityUtil;
import bg.demax.motor.exam.result.rest.validation.violations.TrainingNotPassed;

@Component
public class TrainingIsPassedCheck extends AbstractConstraintCheck<TrainingIsPassedArgs> {

	@Autowired
	private ConstraintCheckDispatcher constraintCheckDispatcher;
	
	@Override
	public void validate(TrainingIsPassedArgs args) throws ConstraintCheckFailureException  {
		String identityNumber = args.getIdentityNumber();
		LearningPlan learningPlan = args.getLearningPlan();
		if(!isRegisteredInValidExams(identityNumber, learningPlan.getTargetCategory(), args.isPractical(), args.getAtDate())) {
			if(EntityUtil.hasExamOfType(learningPlan, args.isPractical() ? ExamRequirement.ID_INTERNAL_PRACTICAL : ExamRequirement.ID_INTERNAL_THEORETICAL)) {
				if(!hasPassedInternalExam(identityNumber, learningPlan.getTargetCategory(), args.isPractical(), args.getAtDate())) {
					throw new ConstraintCheckFailureException(new TrainingNotPassed());
				}
			} else {
				if(!hasPassedAllModules(identityNumber, learningPlan, args.isPractical())) {
					throw new ConstraintCheckFailureException(new TrainingNotPassed());
				}
			}
		}
	}

	private boolean isRegisteredInValidExams(String identityNumber, SubCategory subCategory, boolean isForPracticalTraining, LocalDate atDate) {
		try {
			LocalDate examAfterWhen = atDate.minusMonths(6);
			constraintCheckDispatcher.check(new RegisteredInValidExamArgs(identityNumber, subCategory, examAfterWhen, isForPracticalTraining));
		} catch (ConstraintCheckFailureException e) {
			return false;
		}
		return true;
	}
	
	private boolean hasPassedInternalExam(String identityNumber, SubCategory subCategory, boolean isPracticalExam, LocalDate atDate) {
		try {
			constraintCheckDispatcher.check(new InternalExamIsPassedArgs(identityNumber, subCategory, atDate, isPracticalExam));
		} catch (ConstraintCheckFailureException e) {
			return false;
		}
		return true;
	}
	
	private boolean hasPassedAllModules(String identityNumber, LearningPlan learningPlan, boolean isPractical) {
		try {
			constraintCheckDispatcher.check(new AllLearningPlanModulesArePassedArgs(identityNumber, learningPlan, isPractical));
		} catch (ConstraintCheckFailureException e) {
			return false;
		}
		return true;
	}
}
