package bg.demax.motor.exam.result.rest.validation.check.registration;

import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.rest.validation.ExamPersonArg;

public class CategoryIsNotInProgressArgs extends ExamPersonArg {

	private static final long serialVersionUID = 484059835048412830L;

	public CategoryIsNotInProgressArgs(ExamPerson examPerson) {
		super(examPerson);
	}
}
