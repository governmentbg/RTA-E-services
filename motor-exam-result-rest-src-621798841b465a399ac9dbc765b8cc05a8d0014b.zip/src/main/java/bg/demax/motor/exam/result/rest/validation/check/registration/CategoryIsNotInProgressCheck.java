package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;
import bg.demax.motor.exam.result.rest.validation.violations.DerivativeCategoryAlreadyInProgress;

@Component
public class CategoryIsNotInProgressCheck extends AbstractConstraintCheck<CategoryIsNotInProgressArgs> {
	
	@Autowired
	private ExamPersonService examPersonService;

	@Override
	public void validate(CategoryIsNotInProgressArgs args) throws ConstraintCheckFailureException {
		ExamPerson examPerson = args.getExamPerson();
		LearningPlan learningPlan = examPerson.getLearningPlan();
		List<ExamPerson> activeExamPeople = examPersonService.getActiveForPerson(examPerson.getSubjectVersion().getSubject());
		activeExamPeople.remove(examPerson);
		List<ExamPerson> activeExamPeopleWithDerivativeLearningPlan = examPersonService
				.getExamPeopleWithDerivativeLearningPlan(activeExamPeople, learningPlan);
		List<ExamPerson> activeMovableExamPeopleWithSameLearningPlan = examPersonService.getActiveAndMovableForPersonAndLearningPlan(examPerson
				.getSubjectVersion().getSubject(), learningPlan, examPerson.getCompany().getNumber());
		activeExamPeopleWithDerivativeLearningPlan.removeAll(activeMovableExamPeopleWithSameLearningPlan);
		if (!activeExamPeopleWithDerivativeLearningPlan.isEmpty()) {
			ExamPerson activeExamPerson = activeExamPeopleWithDerivativeLearningPlan.get(0);
			throw new ConstraintCheckFailureException(new DerivativeCategoryAlreadyInProgress(activeExamPerson));
		}
	}

}
