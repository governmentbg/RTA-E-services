package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.time.LocalDateTime;
import java.util.Map;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.LearningPlan;

public class CategoryRequirementsAreMetArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = 5975409063542667231L;
	
	private LearningPlan learningPlan;
	private Map<SubCategory, LocalDateTime> acquiredCategories;
	private String identNum;

	public CategoryRequirementsAreMetArgs(String identNum, LearningPlan learningPlan, Map<SubCategory, LocalDateTime> acquiredCategories) {
		this.learningPlan = learningPlan;
		this.acquiredCategories = acquiredCategories;
		this.identNum = identNum;
	}

	public LearningPlan getLearningPlan() {
		return learningPlan;
	}

	public Map<SubCategory, LocalDateTime> getAcquiredCategories() {
		return acquiredCategories;
	}

	public String getIdentNum() {
		return identNum;
	}

}
