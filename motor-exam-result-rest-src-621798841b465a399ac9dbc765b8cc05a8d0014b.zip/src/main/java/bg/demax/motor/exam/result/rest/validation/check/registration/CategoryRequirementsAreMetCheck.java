package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.CategoryRequirement;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.entity.YearMonthDuration;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;
import bg.demax.motor.exam.result.rest.validation.violations.RequiredCategoryNotPresent;

@Component
public class CategoryRequirementsAreMetCheck extends AbstractConstraintCheck<CategoryRequirementsAreMetArgs> {

	@Autowired
	private ExamPersonService examPersonService;
	
	@Override
	public void validate(CategoryRequirementsAreMetArgs args) throws ConstraintCheckFailureException {
		LearningPlan learningPlan = args.getLearningPlan();
		Map<SubCategory, LocalDateTime> acquiredCategories = args.getAcquiredCategories();
		
		if (learningPlan.getCategoryRequirements().isEmpty()) {
			return;
		}

		boolean shouldCheckExperience = shouldCheckForExperience(args.getIdentNum());

		if ("AND".equalsIgnoreCase(learningPlan.getCategoryConnectionType())) {
			if(!areAllCategoryRequirementsMet(learningPlan, acquiredCategories, shouldCheckExperience)) {
				throw new ConstraintCheckFailureException(new RequiredCategoryNotPresent());
			}
		} else {
			if(!isAtLeastOneCategoryRequirementMet(learningPlan, acquiredCategories, shouldCheckExperience)) {
				throw new ConstraintCheckFailureException(new RequiredCategoryNotPresent());
			}
		}
	}

	private boolean shouldCheckForExperience(String identNum) {
		LocalDateTime latest157Date = examPersonService.getLatest157Date(identNum);
		return latest157Date == null;
	}
	
	private boolean areAllCategoryRequirementsMet(LearningPlan learningPlan, Map<SubCategory, LocalDateTime> acquiredCategories, boolean shouldCheckExperience) {
		if (learningPlan.is157() || learningPlan.is426())
			shouldCheckExperience = false;

		for (CategoryRequirement categoryRequirement : learningPlan.getCategoryRequirements()) {
			if (!isCategoryRequirementMet(categoryRequirement, acquiredCategories, shouldCheckExperience)) {
				return false;
			}
		}

		return true;
	}
	
	private boolean isAtLeastOneCategoryRequirementMet(LearningPlan learningPlan, Map<SubCategory, LocalDateTime> acquiredCategories, boolean shouldCheckExperience) {
		if (learningPlan.is157() || learningPlan.is426())
			shouldCheckExperience = false;

		for (CategoryRequirement categoryRequirement : learningPlan.getCategoryRequirements()) {
			if (isCategoryRequirementMet(categoryRequirement, acquiredCategories, shouldCheckExperience)) {
				return true;
			}
		}

		return false;
	}
	
	private boolean isCategoryRequirementMet(CategoryRequirement categoryRequirement, Map<SubCategory, LocalDateTime> acquiredCategories, boolean shouldCheckExperience) {
		LocalDateTime now = LocalDateTime.now();
		for (Entry<SubCategory, LocalDateTime> acquiredCategoryEntry : acquiredCategories.entrySet()) {
			SubCategory subCategory = acquiredCategoryEntry.getKey();
			LocalDateTime acquireDate = acquiredCategoryEntry.getValue();
			if (subCategory.equals(categoryRequirement.getCategory())) {
				// fixme: no good way to check experience now (157)
				if (shouldCheckExperience) {
					YearMonthDuration requiredExperience = categoryRequirement.getExperience();
					LocalDateTime expiration = acquireDate
							.plusYears(requiredExperience.getYears())
							.plusMonths(requiredExperience.getMonths());
					if (!expiration.isAfter(now)) {
						return true;
					}
				} else {
					return true;
				}
			}
		}
		return false;
	}
}
