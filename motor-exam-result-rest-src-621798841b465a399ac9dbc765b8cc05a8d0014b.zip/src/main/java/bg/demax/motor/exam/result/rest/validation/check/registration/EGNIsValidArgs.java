package bg.demax.motor.exam.result.rest.validation.check.registration;

import bg.demax.pub.entity.Subject;

public class EGNIsValidArgs extends SubjectCheckArgs {

	private static final long serialVersionUID = 4993517590523002446L;

	public EGNIsValidArgs(Subject subject) {
		super(subject);
	}
}
