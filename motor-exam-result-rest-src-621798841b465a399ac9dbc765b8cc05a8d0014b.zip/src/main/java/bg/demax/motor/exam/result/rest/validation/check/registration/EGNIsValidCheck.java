package bg.demax.motor.exam.result.rest.validation.check.registration;

import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.rest.validation.violations.EGNNotValid;
import bg.demax.pub.entity.Subject;
import bg.demax.pub.validator.util.SubjectIdentNumValidatorUtil;

@Component
public class EGNIsValidCheck extends AbstractConstraintCheck<EGNIsValidArgs> {
	
	@Override
	public void validate(EGNIsValidArgs args) throws ConstraintCheckFailureException {
		Subject subject = args.getSubject();
		boolean isBulgarian = subject.getCountry().getCode().equals("BGR");
		String identificationNumber = subject.getIdentityNumber();
		if(isBulgarian) {
			if(!SubjectIdentNumValidatorUtil.isValidEgn(identificationNumber)) {
				throw new ConstraintCheckFailureException(new EGNNotValid());
			}
		}
	}

}
