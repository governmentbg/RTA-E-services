package bg.demax.motor.exam.result.rest.validation.check.registration;

import bg.demax.pub.entity.Subject;

public class ENCIsValidArgs extends SubjectCheckArgs {

	private static final long serialVersionUID = 8805959445117464157L;

	public ENCIsValidArgs(Subject subject) {
		super(subject);
	}
}
