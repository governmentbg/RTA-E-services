package bg.demax.motor.exam.result.rest.validation.check.registration;

import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.rest.validation.ExamPersonArg;

public class ExamPersonRegistrationIsValidArgs extends ExamPersonArg {

	private static final long serialVersionUID = -1612207426313401737L;

	public ExamPersonRegistrationIsValidArgs(ExamPerson examPerson) {
		super(examPerson);
	}

}
