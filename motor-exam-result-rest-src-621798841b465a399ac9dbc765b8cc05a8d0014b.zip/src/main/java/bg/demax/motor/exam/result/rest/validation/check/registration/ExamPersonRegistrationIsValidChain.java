package bg.demax.motor.exam.result.rest.validation.check.registration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckDispatcher;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.permit.entity.Permit;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.rest.validation.PermitHasCategoryArgs;
import bg.demax.pub.entity.Subject;

@Component
public class ExamPersonRegistrationIsValidChain extends AbstractConstraintCheck<ExamPersonRegistrationIsValidArgs> {

	@Autowired
	private ConstraintCheckDispatcher constraintCheckDispatcher;

	@Override
	public void validate(ExamPersonRegistrationIsValidArgs args) throws ConstraintCheckFailureException {
		ExamPerson examPerson = args.getExamPerson();
		Subject subject = examPerson.getSubjectVersion().getSubject();
		Permit permit = examPerson.getCompany();
		LearningPlan learningPlan = examPerson.getLearningPlan();
		SubCategory subCategory = learningPlan.getTargetCategory();
		
		constraintCheckDispatcher.check(
				new EGNIsValidArgs(subject),
				new ENCIsValidArgs(subject),
				new PermitHasCategoryArgs(permit, subCategory),
				new PermitSupportsLearningPlanArgs(permit, learningPlan),
				new CategoryIsNotInProgressArgs(examPerson),
				new IndividualTrainingIsNotMandatoryArgs(examPerson),
				new PersonCanBeRegisteredWithLearningPlanArgs(examPerson),
				new LearningPlanIsNotOccludedArgs(examPerson)
		);
	}
}
