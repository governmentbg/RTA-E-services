package bg.demax.motor.exam.result.rest.validation.check.registration;

import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.rest.validation.ExamPersonArg;

public class IndividualTrainingIsNotMandatoryArgs extends ExamPersonArg {

	private static final long serialVersionUID = -8535314471383024036L;

	private boolean forceCheck = false;

	public IndividualTrainingIsNotMandatoryArgs(ExamPerson examPerson) {
		this(examPerson, false);
	}

	public IndividualTrainingIsNotMandatoryArgs(ExamPerson examPerson, boolean forceCheck) {
		super(examPerson);
		this.forceCheck = forceCheck;
	}

	public boolean isForceCheck() {
		return forceCheck;
	}

}
