package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckDispatcher;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.rest.db.repository.ExamPersonRepository;
import bg.demax.motor.exam.result.rest.validation.LearningPlanIsFulfilledArgs;
import bg.demax.motor.exam.result.rest.validation.TrainingIsPassedArgs;
import bg.demax.motor.exam.result.rest.validation.violations.MandatoryIndividualTraining;

@Component
public class IndividualTrainingIsNotMandatoryCheck extends AbstractConstraintCheck<IndividualTrainingIsNotMandatoryArgs> {

	@Autowired
	private ExamPersonRepository examPersonRepository;

	@Autowired
	private ConstraintCheckDispatcher constraintCheckDispatcher;

	@Override
	public void validate(IndividualTrainingIsNotMandatoryArgs args) throws ConstraintCheckFailureException {
		ExamPerson examPerson = args.getExamPerson();
		if (!examPerson.isIndividualTraining() || args.isForceCheck()) {
			boolean isMandatory = false;
			try {
				constraintCheckDispatcher.check(new TrainingIsPassedArgs(examPerson, false, LocalDate.now()));
				isMandatory = true;
			} catch (ConstraintCheckFailureException e) {
			}

			isMandatory &= !hasCompletedCategory(examPerson);

			if (isMandatory) {
				throw new ConstraintCheckFailureException(new MandatoryIndividualTraining());
			}
		}
	}

	private boolean hasCompletedCategory(ExamPerson examPerson) {
		String identNum = examPerson.getSubjectVersion().getSubject().getIdentityNumber();
		List<ExamPerson> completedExamPeople = examPersonRepository.getLatestCompletedForIdentNumAndCategoryAfter(identNum,
				examPerson.getLearningPlan().getTargetCategory());
		if (completedExamPeople == null || completedExamPeople.isEmpty())
			return false;
		try {
			ExamPerson completed = completedExamPeople.get(0);
			constraintCheckDispatcher.check(new LearningPlanIsFulfilledArgs(completed));
			return true;
		} catch (ConstraintCheckFailureException e) {
			return false;
		}
	}

}
