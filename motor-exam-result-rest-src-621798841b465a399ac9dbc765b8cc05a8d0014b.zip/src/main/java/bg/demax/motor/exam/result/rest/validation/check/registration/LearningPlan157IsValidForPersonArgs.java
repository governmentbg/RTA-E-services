package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.util.Collection;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.entity.ProvidedCategory;

public class LearningPlan157IsValidForPersonArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -3617381305332683830L;

	private String identNum;
	private LearningPlan learningPlan;
	private Collection<ProvidedCategory> providedCategories;

	public LearningPlan157IsValidForPersonArgs(String identNum, LearningPlan learningPlan,
			Collection<ProvidedCategory> providedCategories) {
		this.learningPlan = learningPlan;
		this.identNum = identNum;
		this.providedCategories = providedCategories;
	}

	public LearningPlan getLearningPlan() {
		return learningPlan;
	}

	public String getIdentNum() {
		return identNum;
	}

	public Collection<ProvidedCategory> getProvidedCategories() {
		return providedCategories;
	}

}
