package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckDispatcher;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.entity.ProvidedCategory;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;

@Component
public class LearningPlan157IsValidForPersonChain extends AbstractConstraintCheck<LearningPlan157IsValidForPersonArgs> {

	@Autowired
	private ExamPersonService examPersonService;
	
	@Autowired
	private ConstraintCheckDispatcher constraintCheckDispatcher;

	@Override
	public void validate(LearningPlan157IsValidForPersonArgs args) throws ConstraintCheckFailureException {
		LearningPlan learningPlan = args.getLearningPlan();
		Collection<ProvidedCategory> providedCategories = args.getProvidedCategories();		
		Map<SubCategory, LocalDateTime> acquiredCategoriesDisregarding157 = examPersonService
				.getAcquiredCategoriesIncluding157(args.getIdentNum(), providedCategories);

		Set<SubCategory> acquiredSubCategories = new HashSet<>();
		for (SubCategory acquiredSubCategory : acquiredCategoriesDisregarding157.keySet()) {
			acquiredSubCategories.add(acquiredSubCategory);
		}
		
		constraintCheckDispatcher.check(
				new LostCategoryIsAcquiredArgs(acquiredSubCategories, learningPlan),
				new SixMonthsHavePassedSince157Args(args.getIdentNum(), learningPlan),
				new PassedCategoryIsNotLostArgs(acquiredSubCategories, learningPlan)
		);
	}

}
