package bg.demax.motor.exam.result.rest.validation.check.registration;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;

public class LearningPlanIsNotOccludedArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = 153165811813069216L;

	private ExamPerson examPerson;

	public LearningPlanIsNotOccludedArgs(ExamPerson examPerson) {
		this.examPerson = examPerson;
	}

	public ExamPerson getExamPerson() {
		return examPerson;
	}

}
