package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckDispatcher;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.rest.db.repository.LearningPlanRepository;
import bg.demax.motor.exam.result.rest.service.LearningPlanService;
import bg.demax.motor.exam.result.rest.validation.init.ConstraintCheckInitializerFactory;
import bg.demax.motor.exam.result.rest.validation.violations.LearningPlanOccluded;
import bg.demax.pub.entity.Subject;

@Component
public class LearningPlanIsNotOccludedCheck extends AbstractConstraintCheck<LearningPlanIsNotOccludedArgs> {

	@Autowired
	private LearningPlanService learningPlanService;
	
	@Autowired
	private LearningPlanRepository learningPlanRepository;
	
	@Autowired
	private ConstraintCheckDispatcher constraintCheckDispatcher;
	
	@Autowired
	private ConstraintCheckInitializerFactory initFactory;
	
	@Override
	public void validate(LearningPlanIsNotOccludedArgs args) throws ConstraintCheckFailureException {
		ExamPerson examPerson = args.getExamPerson();
		LearningPlan learningPlan = examPerson.getLearningPlan();
		SubCategory subCategory = learningPlan.getTargetCategory();
		Subject subject = examPerson.getSubjectVersion().getSubject();
		
		List<LearningPlan> learningPlans = learningPlanRepository.findByCategoryId(subCategory.getId());
		List<LearningPlan> filtered = new LinkedList<>();
		filtered.add(learningPlan);
		
		LearningPlanIsValidForPersonInit initializer = initFactory.getInitializer(LearningPlanIsValidForPersonInit.class);
		
		for(LearningPlan otherLearningPlan : learningPlans) {
			if(!otherLearningPlan.equals(learningPlan)) {
				try {
					constraintCheckDispatcher.check(new LearningPlanIsValidForPersonArgs(subject, otherLearningPlan, 
							examPerson.getProvidedCategories(), examPerson.getDrivingLicenceLossDate())
							.withInitializer(initializer));
					filtered.add(otherLearningPlan);
				} catch (ConstraintCheckFailureException e) {
				}
			}
		}
		
		filtered = learningPlanService.filterOccluded(filtered);
		if(!filtered.contains(learningPlan)) {
			throw new ConstraintCheckFailureException(new LearningPlanOccluded());
		}
	}

}
