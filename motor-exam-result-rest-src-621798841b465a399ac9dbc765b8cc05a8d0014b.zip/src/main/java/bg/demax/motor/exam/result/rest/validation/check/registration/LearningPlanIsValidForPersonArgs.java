package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.time.LocalDate;
import java.util.Collection;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.entity.ProvidedCategory;
import bg.demax.pub.entity.Subject;

public class LearningPlanIsValidForPersonArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = 7343746894616167201L;

	private Subject subject;
	private LearningPlan learningPlan;
	private Collection<ProvidedCategory> providedCategories;
	private LocalDate drvLicenceLossDate;
	private LearningPlanIsValidForPersonInit initializer;

	public LearningPlanIsValidForPersonArgs(ExamPerson examPerson) {
		this.subject = examPerson.getSubjectVersion().getSubject();
		this.learningPlan = examPerson.getLearningPlan();
		this.providedCategories = examPerson.getProvidedCategories();
		this.drvLicenceLossDate = examPerson.getDrivingLicenceLossDate();
	}

	public LearningPlanIsValidForPersonArgs(Subject subject, LearningPlan learningPlan,
			Collection<ProvidedCategory> providedCategories, LocalDate drvLicenceLossDate) {
		this.subject = subject;
		this.learningPlan = learningPlan;
		this.providedCategories = providedCategories;
		this.drvLicenceLossDate = drvLicenceLossDate;
	}

	public Subject getSubject() {
		return subject;
	}

	public LearningPlan getLearningPlan() {
		return learningPlan;
	}

	public Collection<ProvidedCategory> getProvidedCategories() {
		return providedCategories;
	}

	public LocalDate getDrvLicenceLossDate() {
		return drvLicenceLossDate;
	}

	public LearningPlanIsValidForPersonInit getInitializer() {
		return initializer;
	}

	public LearningPlanIsValidForPersonArgs withInitializer(LearningPlanIsValidForPersonInit initializer) {
		this.initializer = initializer;
		return this;
	}

}
