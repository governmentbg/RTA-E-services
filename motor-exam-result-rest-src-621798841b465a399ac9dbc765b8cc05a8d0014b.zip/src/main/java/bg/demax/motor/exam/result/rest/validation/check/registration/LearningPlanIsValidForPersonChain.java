package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckDispatcher;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.entity.ProvidedCategory;
import bg.demax.motor.exam.result.rest.validation.CategoryIsNotAlreadyAcquiredArgs;
import bg.demax.motor.exam.result.rest.validation.init.ConstraintCheckInitializerFactory;
import bg.demax.pub.entity.Subject;

@Component
public class LearningPlanIsValidForPersonChain extends AbstractConstraintCheck<LearningPlanIsValidForPersonArgs> {
	
	@Autowired
	private ConstraintCheckDispatcher constraintCheckDispatcher;
	
	@Autowired
	private ConstraintCheckInitializerFactory initFactory;

	@Override
	public void validate(LearningPlanIsValidForPersonArgs args) throws ConstraintCheckFailureException {
		LearningPlan learningPlan = args.getLearningPlan();
		Subject subject = args.getSubject();
		Collection<ProvidedCategory> providedCategories = args.getProvidedCategories();
		
		LearningPlanIsValidForPersonInit initializer = args.getInitializer();
		if(initializer == null) {
			initializer = initFactory.getInitializer(LearningPlanIsValidForPersonInit.class);
		}
		initializer.init(args);
		
		constraintCheckDispatcher.check(
				new CategoryRequirementsAreMetArgs(subject.getIdentityNumber(), learningPlan, initializer.getAcquiredCategories()),
				new CategoryIsNotAlreadyAcquiredArgs(learningPlan, initializer.getAcquiredCategories()),
				new RegistrationAgeIsValidArgs(learningPlan, subject),
				new LearningPlan157IsValidForPersonArgs(subject.getIdentityNumber(), learningPlan, providedCategories),
				new LearningPlan426IsValidForPersonArgs(subject.getIdentityNumber(), learningPlan, providedCategories)
		);
	}
}
