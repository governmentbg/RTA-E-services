package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import bg.demax.exams.entity.SubCategory;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;
import bg.demax.motor.exam.result.rest.validation.init.ConstraintCheckInitializer;

@Service
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class LearningPlanIsValidForPersonInit implements ConstraintCheckInitializer<LearningPlanIsValidForPersonArgs> {

	@Autowired
	private ExamPersonService examPersonService;

	private Map<SubCategory, LocalDateTime> acquiredCategories;
	private boolean isInitialised = false;

	@Override
	public synchronized void init(LearningPlanIsValidForPersonArgs args) {
		if (!isInitialised) {
			acquiredCategories = examPersonService.getAcquiredCategoriesUntil157(args.getSubject().getIdentityNumber(),
					args.getProvidedCategories());
			acquiredCategories = removeLostCategories(args.getDrvLicenceLossDate(), acquiredCategories);
			isInitialised = true;
		}
	}

	private Map<SubCategory, LocalDateTime> removeLostCategories(LocalDate drivingLicenceLossDate, Map<SubCategory, LocalDateTime> acquiredCategories) {
		acquiredCategories = new HashMap<>(acquiredCategories);
		if (drivingLicenceLossDate != null) {
			Set<SubCategory> lostCategories = new HashSet<>();
			for (Entry<SubCategory, LocalDateTime> entry : acquiredCategories.entrySet()) {
				if (entry.getValue().toLocalDate().isBefore(drivingLicenceLossDate)) {
					lostCategories.add(entry.getKey());
				}
			}
			for (SubCategory lostCategory : lostCategories) {
				acquiredCategories.remove(lostCategory);
			}
		}
		return acquiredCategories;
	}

	public Map<SubCategory, LocalDateTime> getAcquiredCategories() {
		return acquiredCategories;
	}
}
