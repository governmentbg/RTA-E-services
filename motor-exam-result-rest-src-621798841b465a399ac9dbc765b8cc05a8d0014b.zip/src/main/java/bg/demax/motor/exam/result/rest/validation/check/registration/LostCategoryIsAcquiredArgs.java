package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.util.Set;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.LearningPlan;

public class LostCategoryIsAcquiredArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -8017178936323853702L;

	private Set<SubCategory> acquiredCategories;
	private LearningPlan learningPlan;

	public LostCategoryIsAcquiredArgs(Set<SubCategory> acquiredCategories, LearningPlan learningPlan) {
		this.acquiredCategories = acquiredCategories;
		this.learningPlan = learningPlan;
	}

	public Set<SubCategory> getAcquiredCategories() {
		return acquiredCategories;
	}

	public LearningPlan getLearningPlan() {
		return learningPlan;
	}

}
