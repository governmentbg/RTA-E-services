package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.util.Set;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.LearningPlan;

public class PassedCategoryIsNotLostArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = 3243712843780906303L;

	private Set<SubCategory> acquiredSubCategories;
	private LearningPlan learningPlan;

	public PassedCategoryIsNotLostArgs(Set<SubCategory> acquiredSubCategories, LearningPlan learningPlan) {
		this.acquiredSubCategories = acquiredSubCategories;
		this.learningPlan = learningPlan;
	}

	public Set<SubCategory> getAcquiredSubCategories() {
		return acquiredSubCategories;
	}

	public LearningPlan getLearningPlan() {
		return learningPlan;
	}

}
