package bg.demax.motor.exam.result.rest.validation.check.registration;

import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.rest.validation.violations.CategoryAlreadyPassedButLost;

@Component
public class PassedCategoryIsNotLostCheck extends AbstractConstraintCheck<PassedCategoryIsNotLostArgs> {

	@Override
	public void validate(PassedCategoryIsNotLostArgs args) throws ConstraintCheckFailureException {
		LearningPlan learningPlan = args.getLearningPlan();
		if (!learningPlan.is157() && !learningPlan.is426()) {
			if (args.getAcquiredSubCategories().contains(learningPlan.getTargetCategory())) {
				throw new ConstraintCheckFailureException(new CategoryAlreadyPassedButLost());
			}
		}
	}

}
