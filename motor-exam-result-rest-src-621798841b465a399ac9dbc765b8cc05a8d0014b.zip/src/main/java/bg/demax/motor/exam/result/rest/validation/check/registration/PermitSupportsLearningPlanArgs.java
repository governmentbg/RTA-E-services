package bg.demax.motor.exam.result.rest.validation.check.registration;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.permit.entity.Permit;
import bg.demax.motor.exam.result.entity.LearningPlan;

public class PermitSupportsLearningPlanArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = 1758555660944040404L;

	private Permit permit;
	private LearningPlan learningPlan;

	public PermitSupportsLearningPlanArgs(Permit permit, LearningPlan learningPlan) {
		this.permit = permit;
		this.learningPlan = learningPlan;
	}

	public Permit getPermit() {
		return permit;
	}

	public LearningPlan getLearningPlan() {
		return learningPlan;
	}

}
