package bg.demax.motor.exam.result.rest.validation.check.registration;

import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.permit.entity.Permit;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.rest.validation.violations.CannotRegisterWithStateRequest;
import bg.demax.motor.exam.result.rest.validation.violations.CannotRegisterWithoutStateRequest;

@Component
public class PermitSupportsLearningPlanCheck extends AbstractConstraintCheck<PermitSupportsLearningPlanArgs> {

	@Override
	public void validate(PermitSupportsLearningPlanArgs args) throws ConstraintCheckFailureException {
		Permit permit = args.getPermit();
		LearningPlan learningPlan = args.getLearningPlan();

		if (learningPlan.isStateRequest()) {
			if (permit.isStateAcceptance() || permit.isStateAcceptanceOther()) {
				return;
			}
			throw new ConstraintCheckFailureException(new CannotRegisterWithStateRequest());
		} else {
			if (!permit.isStateAcceptance() || permit.isStateAcceptanceOther()) {
				return;
			}
			throw new ConstraintCheckFailureException(new CannotRegisterWithoutStateRequest());
		}
	}

}
