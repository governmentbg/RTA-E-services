package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.time.LocalDate;
import java.util.Collection;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.motor.exam.result.entity.ProvidedCategory;
import bg.demax.pub.entity.Subject;

public class PersonCanBeRegisteredWithLearningPlanArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -5950101584912766998L;

	private Subject subject;
	private LearningPlan learningPlan;
	private Collection<ProvidedCategory> providedCategories;
	private LocalDate drivingLicenceLossDate;
	private int excludedPermitNumber;
	private ExamPerson ignoredExamPerson;
	private PersonCanBeRegisteredWithLearningPlanInit initializer;

	public PersonCanBeRegisteredWithLearningPlanArgs(Subject subject, LearningPlan learningPlan,
			Collection<ProvidedCategory> providedCategories, LocalDate drivingLicenceLossDate, int excludedPermitNumber) {
		this.subject = subject;
		this.learningPlan = learningPlan;
		this.providedCategories = providedCategories;
		this.drivingLicenceLossDate = drivingLicenceLossDate;
		this.excludedPermitNumber = excludedPermitNumber;
		this.ignoredExamPerson = null;
	}

	public PersonCanBeRegisteredWithLearningPlanArgs(ExamPerson examPerson) {
		this.subject = examPerson.getSubjectVersion().getSubject();
		this.learningPlan = examPerson.getLearningPlan();
		this.providedCategories = examPerson.getProvidedCategories();
		this.drivingLicenceLossDate = examPerson.getDrivingLicenceLossDate();
		this.excludedPermitNumber = examPerson.getCompany().getNumber();
		this.ignoredExamPerson = examPerson;
	}

	public Subject getSubject() {
		return subject;
	}

	public LearningPlan getLearningPlan() {
		return learningPlan;
	}

	public Collection<ProvidedCategory> getProvidedCategories() {
		return providedCategories;
	}

	public LocalDate getDrivingLicenceLossDate() {
		return drivingLicenceLossDate;
	}

	public int getExcludedPermitNumber() {
		return excludedPermitNumber;
	}

	public ExamPerson getIgnoredExamPerson() {
		return ignoredExamPerson;
	}

	public PersonCanBeRegisteredWithLearningPlanInit getInitializer() {
		return initializer;
	}

	public PersonCanBeRegisteredWithLearningPlanArgs withInitializer(PersonCanBeRegisteredWithLearningPlanInit initializer) {
		this.initializer = initializer;
		return this;
	}

}
