package bg.demax.motor.exam.result.rest.validation.check.registration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckDispatcher;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.rest.validation.init.ConstraintCheckInitializerFactory;

@Component
public class PersonCanBeRegisteredWithLearningPlanCheck
		extends AbstractConstraintCheck<PersonCanBeRegisteredWithLearningPlanArgs> {

	@Autowired
	private ConstraintCheckDispatcher constraintCheckDispatcher;

	@Autowired
	private ConstraintCheckInitializerFactory initFactory;

	@Override
	public void validate(PersonCanBeRegisteredWithLearningPlanArgs args) throws ConstraintCheckFailureException {
		PersonCanBeRegisteredWithLearningPlanInit initializer = args.getInitializer();
		if (initializer == null) {
			initializer = initFactory.getInitializer(PersonCanBeRegisteredWithLearningPlanInit.class);
		}
		initializer.init(args);

		constraintCheckDispatcher.check(
				new LearningPlanIsValidForPersonArgs(args.getSubject(), args.getLearningPlan(), args.getProvidedCategories(),
						args.getDrivingLicenceLossDate()).withInitializer(initializer.getLearningPlanIsValidForPersonInit()),
				new ThereAreNoActiveCandidatesWithCategoryArgs(args.getSubject(), initializer.getActiveExamPeople(),
						args.getLearningPlan(), args.getExcludedPermitNumber()));
	}

}
