package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.rest.db.repository.ExamPersonRepository;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;
import bg.demax.motor.exam.result.rest.validation.init.ConstraintCheckInitializer;
import bg.demax.motor.exam.result.rest.validation.init.ConstraintCheckInitializerFactory;

@Service
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class PersonCanBeRegisteredWithLearningPlanInit
		implements ConstraintCheckInitializer<PersonCanBeRegisteredWithLearningPlanArgs> {

	@Autowired
	private ExamPersonRepository examPersonRepository;

	@Autowired
	private ExamPersonService examPersonService;
	
	@Autowired
	private ConstraintCheckInitializerFactory initFactory;

	private boolean isInitialised = false;
	private List<ExamPerson> activeExamPeople;
	private LearningPlanIsValidForPersonInit learningPlanIsValidForPersonInit;

	@Override
	public synchronized void init(PersonCanBeRegisteredWithLearningPlanArgs args) {
		if (!isInitialised) {
			activeExamPeople = new LinkedList<>();
			if (args.getSubject().getId() != null) {
				activeExamPeople = examPersonRepository.getActiveForSubject(args.getSubject());
				List<ExamPerson> examPeopleWithInvalidPermit = examPersonService
						.getWithInvalidPermit(activeExamPeople);
				activeExamPeople.removeAll(examPeopleWithInvalidPermit);
				activeExamPeople.remove(args.getIgnoredExamPerson());
			}
			learningPlanIsValidForPersonInit = initFactory.getInitializer(LearningPlanIsValidForPersonInit.class);
			isInitialised = true;
		}
	}

	public List<ExamPerson> getActiveExamPeople() {
		return activeExamPeople;
	}

	public LearningPlanIsValidForPersonInit getLearningPlanIsValidForPersonInit() {
		return learningPlanIsValidForPersonInit;
	}

}
