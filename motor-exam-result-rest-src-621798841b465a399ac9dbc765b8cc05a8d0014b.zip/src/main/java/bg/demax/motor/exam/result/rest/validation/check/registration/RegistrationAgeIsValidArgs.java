package bg.demax.motor.exam.result.rest.validation.check.registration;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.pub.entity.Subject;

public class RegistrationAgeIsValidArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -8935741239242359192L;
	
	private LearningPlan learningPlan;
	private Subject subject;

	public RegistrationAgeIsValidArgs(LearningPlan learningPlan, Subject subject) {
		this.learningPlan = learningPlan;
		this.subject = subject;
	}

	public LearningPlan getLearningPlan() {
		return learningPlan;
	}

	public Subject getSubject() {
		return subject;
	}

}
