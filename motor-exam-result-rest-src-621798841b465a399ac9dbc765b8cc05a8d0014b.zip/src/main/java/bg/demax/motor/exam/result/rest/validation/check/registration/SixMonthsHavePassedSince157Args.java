package bg.demax.motor.exam.result.rest.validation.check.registration;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.LearningPlan;

public class SixMonthsHavePassedSince157Args extends ConstraintCheckArgs {

	private static final long serialVersionUID = 2985474892361100219L;

	private String identNum;
	private LearningPlan learningPlan;

	public SixMonthsHavePassedSince157Args(String identNum, LearningPlan learningPlan) {
		this.identNum = identNum;
		this.learningPlan = learningPlan;
	}

	public String getIdentNum() {
		return identNum;
	}

	public LearningPlan getLearningPlan() {
		return learningPlan;
	}

}
