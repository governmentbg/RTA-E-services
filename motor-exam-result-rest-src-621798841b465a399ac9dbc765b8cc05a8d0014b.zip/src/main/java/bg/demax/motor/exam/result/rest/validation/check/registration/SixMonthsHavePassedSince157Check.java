package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;
import bg.demax.motor.exam.result.rest.settings.ApplicationSettings;
import bg.demax.motor.exam.result.rest.validation.violations.SixMonthsBarrierNotPassed;
import bg.demax.pub.settings.ApplicationSettingsFactory;

@Component
public class SixMonthsHavePassedSince157Check extends AbstractConstraintCheck<SixMonthsHavePassedSince157Args> {

	@Autowired
	private ApplicationSettingsFactory applicationSettingsFactory;

	@Autowired
	private ExamPersonService examPersonService;

	@Override
	public void validate(SixMonthsHavePassedSince157Args args) throws ConstraintCheckFailureException {
		if (args.getLearningPlan().is157()) {
			ApplicationSettings applicationSettings = applicationSettingsFactory
					.getApplicationSettings(ApplicationSettings.class);
			if (applicationSettings.isSixMonthsCheckEnabled157()) {
				LocalDateTime latest157Date = examPersonService.getLatest157Date(args.getIdentNum());
				if (latest157Date != null && applicationSettings.isSixMonthsCheckEnabled157()) {
					LocalDateTime categoryRenewalDate = latest157Date.plusMonths(6);
					if (categoryRenewalDate.isAfter(LocalDateTime.now())) {
						throw new ConstraintCheckFailureException(new SixMonthsBarrierNotPassed());
					}
				}
			}
		}
	}

}
