package bg.demax.motor.exam.result.rest.validation.check.registration;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.pub.entity.Subject;

public abstract class SubjectCheckArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = -53373979899133232L;
	
	private Subject subject;

	public SubjectCheckArgs(Subject subject) {
		this.subject = subject;
	}

	public Subject getSubject() {
		return subject;
	}
}
