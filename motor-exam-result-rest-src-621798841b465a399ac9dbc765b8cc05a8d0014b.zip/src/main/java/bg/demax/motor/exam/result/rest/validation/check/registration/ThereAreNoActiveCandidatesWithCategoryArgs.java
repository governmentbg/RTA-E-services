package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.util.Collection;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.entity.LearningPlan;
import bg.demax.pub.entity.Subject;

public class ThereAreNoActiveCandidatesWithCategoryArgs extends ConstraintCheckArgs {

	private static final long serialVersionUID = 4867599385191869873L;

	private Subject subject;
	private Collection<ExamPerson> activeExamPeople;
	private LearningPlan learningPlan;
	private int excludePermitNumber;

	public ThereAreNoActiveCandidatesWithCategoryArgs(Subject subject, Collection<ExamPerson> activeExamPeople,
			LearningPlan learningPlan, int excludePermitNumber) {
		this.subject = subject;
		this.activeExamPeople = activeExamPeople;
		this.learningPlan = learningPlan;
		this.excludePermitNumber = excludePermitNumber;
	}

	public Subject getSubject() {
		return subject;
	}

	public Collection<ExamPerson> getActiveExamPeople() {
		return activeExamPeople;
	}

	public LearningPlan getLearningPlan() {
		return learningPlan;
	}

	public int getExcludePermitNumber() {
		return excludePermitNumber;
	}

}
