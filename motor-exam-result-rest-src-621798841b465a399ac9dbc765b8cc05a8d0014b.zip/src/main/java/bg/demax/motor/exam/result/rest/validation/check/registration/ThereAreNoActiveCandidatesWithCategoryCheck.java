package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.entity.ExamPerson;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;
import bg.demax.motor.exam.result.rest.validation.violations.ActiveExamPeopleWithDerivativeLearningPlan;

@Component
public class ThereAreNoActiveCandidatesWithCategoryCheck
		extends AbstractConstraintCheck<ThereAreNoActiveCandidatesWithCategoryArgs> {

	@Autowired
	private ExamPersonService examPersonService;

	@Override
	public void validate(ThereAreNoActiveCandidatesWithCategoryArgs args) throws ConstraintCheckFailureException {
		List<ExamPerson> activeExamPeopleWithDerivativeLearningPlan = examPersonService
				.getExamPeopleWithDerivativeLearningPlan(args.getActiveExamPeople(), args.getLearningPlan());
		List<ExamPerson> activeMovableExamPeopleWithSameLearningPlan = examPersonService
				.getActiveAndMovableForPersonAndLearningPlan(args.getSubject(), args.getLearningPlan(),
						args.getExcludePermitNumber());
		activeExamPeopleWithDerivativeLearningPlan.removeAll(activeMovableExamPeopleWithSameLearningPlan);

		if (!activeExamPeopleWithDerivativeLearningPlan.isEmpty()) {
			throw new ConstraintCheckFailureException(new ActiveExamPeopleWithDerivativeLearningPlan());
		}
	}

}
