package bg.demax.motor.exam.result.rest.validation.check.registration;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;
import bg.demax.motor.exam.result.entity.LearningPlan;

public class ThreeYearsHavePassedSince426Args extends ConstraintCheckArgs {

	private static final long serialVersionUID = -4626170379485348815L;

	private String identNum;
	private LearningPlan learningPlan;

	public ThreeYearsHavePassedSince426Args(String identNum, LearningPlan learningPlan) {
		this.identNum = identNum;
		this.learningPlan = learningPlan;
	}

	public String getIdentNum() {
		return identNum;
	}

	public LearningPlan getLearningPlan() {
		return learningPlan;
	}
}
