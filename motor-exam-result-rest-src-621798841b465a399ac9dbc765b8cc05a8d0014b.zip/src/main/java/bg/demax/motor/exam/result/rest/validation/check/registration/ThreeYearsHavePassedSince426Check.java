package bg.demax.motor.exam.result.rest.validation.check.registration;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.demax.legacy.util.constraint.AbstractConstraintCheck;
import bg.demax.legacy.util.constraint.ConstraintCheckFailureException;
import bg.demax.motor.exam.result.rest.service.ExamPersonService;
import bg.demax.motor.exam.result.rest.settings.ApplicationSettings;
import bg.demax.motor.exam.result.rest.validation.violations.ThreeYearsBarrierNotPassed;
import bg.demax.pub.settings.ApplicationSettingsFactory;

@Component
public class ThreeYearsHavePassedSince426Check extends AbstractConstraintCheck<ThreeYearsHavePassedSince426Args> {

	@Autowired
	private ApplicationSettingsFactory applicationSettingsFactory;

	@Autowired
	private ExamPersonService examPersonService;

	@Override
	public void validate(ThreeYearsHavePassedSince426Args args) throws ConstraintCheckFailureException {
		if (args.getLearningPlan().is426()) {
			ApplicationSettings applicationSettings = applicationSettingsFactory
					.getApplicationSettings(ApplicationSettings.class);
			if (applicationSettings.isThreeYearsCheckEnabled426()) {
				LocalDateTime latest426Date = examPersonService.getLatest426Date(args.getIdentNum());
				if (latest426Date != null && applicationSettings.isThreeYearsCheckEnabled426()) {
					LocalDateTime categoryRenewalDate = latest426Date.plusYears(3);
					if (categoryRenewalDate.isAfter(LocalDateTime.now())) {
						throw new ConstraintCheckFailureException(new ThreeYearsBarrierNotPassed());
					}
				}
			}
		}
	}

}
