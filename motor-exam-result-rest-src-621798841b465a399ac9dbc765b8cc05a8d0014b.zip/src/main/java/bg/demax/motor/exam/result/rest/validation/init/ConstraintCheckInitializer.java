package bg.demax.motor.exam.result.rest.validation.init;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;

public interface ConstraintCheckInitializer<T extends ConstraintCheckArgs> {

	void init(T args);
}
