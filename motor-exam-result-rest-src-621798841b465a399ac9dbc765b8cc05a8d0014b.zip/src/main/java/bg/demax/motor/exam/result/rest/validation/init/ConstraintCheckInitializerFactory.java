package bg.demax.motor.exam.result.rest.validation.init;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import bg.demax.legacy.util.constraint.ConstraintCheckArgs;

@Service
public class ConstraintCheckInitializerFactory implements ApplicationContextAware {

	private ApplicationContext applicationContext;

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

	public <T extends ConstraintCheckInitializer<? extends ConstraintCheckArgs>> T getInitializer(Class<T> type) {
		T initializer = applicationContext.getBean(type);
		return initializer;
	}
}
