//package bg.demax.motor.exam.result.rest.validation.violations;
//
//import bg.demax.shared.util.constraint.ConstraintCheckFailure;
//
//public class CheckViolationException extends ConstraintCheckFailure {
//
//}
