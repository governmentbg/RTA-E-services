package bg.demax.motor.exam.result.rest.validation.violations;

import bg.demax.legacy.util.constraint.ConstraintCheckFailure;
import bg.demax.motor.exam.result.entity.ExamPerson;

public class DerivativeCategoryAlreadyInProgress extends ConstraintCheckFailure {

	private ExamPerson examPerson;

	public DerivativeCategoryAlreadyInProgress() {
	}

	public DerivativeCategoryAlreadyInProgress(ExamPerson examPerson) {
		this.examPerson = examPerson;
	}

	public ExamPerson getExamPerson() {
		return examPerson;
	}
}
