package bg.demax.motor.exam.result.rest.validation.violations;

import bg.demax.exams.entity.SubCategory;
import bg.demax.legacy.util.constraint.ConstraintCheckFailure;
import lombok.Getter;

@Getter
public class PermitCategoryMissing extends ConstraintCheckFailure {
	
	private SubCategory category;

	public PermitCategoryMissing(SubCategory subCategory) {
		this.category = subCategory;
	}

}
