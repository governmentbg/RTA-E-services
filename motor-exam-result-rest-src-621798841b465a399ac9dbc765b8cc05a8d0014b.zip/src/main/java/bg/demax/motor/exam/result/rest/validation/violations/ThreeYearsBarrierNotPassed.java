package bg.demax.motor.exam.result.rest.validation.violations;

import bg.demax.legacy.util.constraint.ConstraintCheckFailure;

public class ThreeYearsBarrierNotPassed extends ConstraintCheckFailure {

}
