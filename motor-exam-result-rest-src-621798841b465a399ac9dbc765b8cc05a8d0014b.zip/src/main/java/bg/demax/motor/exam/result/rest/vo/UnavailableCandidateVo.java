package bg.demax.motor.exam.result.rest.vo;

import bg.demax.motor.exam.result.entity.ExamPerson;

public class UnavailableCandidateVo {

	private ExamPerson examPerson;
	private UnavailabilityReason reason;

	public UnavailableCandidateVo(ExamPerson examPerson, UnavailabilityReason reason) {
		this.examPerson = examPerson;
		this.reason = reason;
	}

	public ExamPerson getExamPerson() {
		return examPerson;
	}

	public void setExamPerson(ExamPerson examPerson) {
		this.examPerson = examPerson;
	}

	public UnavailabilityReason getReason() {
		return reason;
	}

	public void setReason(UnavailabilityReason reason) {
		this.reason = reason;
	}

	public static enum UnavailabilityReason {
		AGE("Неподходяща възраст"), INTERNAL_EXAM("Невзет задължителен вътрешен изпит"), PASSED("Изпитът е взет"), IN_PROGRESS(
			"Кандидатът е записан в неприключен протокол"), THEORY_NOT_PASSED("Невзет задължителен теоретичен изпит"), ADDITIONAL_TRAINING(
			"Не е преминат модул за допълнително обучение"), IAAA("Не може да бъде записан от ИААА, проверете вътрешните изпити"),
			PERMIT_CATEGORY_MISSING("Не могат да бъдат явявани кандидати от тази категория"),
			PERMIT_EXAM_TYPE_NOT_ALLOWED("Не могат да бъдат явявани кандидати за този вид изпит"), 
			CATEGORY_IS_ALREАDY_ACQUIRED("Кандидатът вече притежава категорията");

		private String description;

		private UnavailabilityReason(String description) {
			this.description = description;
		}

		public String getDescription() {
			return description;
		}

	}
}
