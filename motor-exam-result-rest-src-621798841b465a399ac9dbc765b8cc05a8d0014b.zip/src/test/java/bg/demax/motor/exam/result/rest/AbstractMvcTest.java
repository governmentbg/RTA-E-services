package bg.demax.motor.exam.result.rest;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;

import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.DefaultMockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.motor.exam.result.rest.config.ApplicationConstants;
import bg.demax.security.UserDetailsImpl;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@SpringBootTest(classes = MotorExamResultRestApplication.class)
@ActiveProfiles(ApplicationConstants.SPRING_PROFILE_UNIT_TEST)
public abstract class AbstractMvcTest {
	
	@Autowired
	private WebApplicationContext webApplicationContext;

	private H2TestDatabaseCleaner dbCleaner = new H2TestDatabaseCleaner();

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private ObjectMapper objectMapper;

	protected MockMvc mockMvc;	

	protected MvcObjectMapper mvcObjectMapper;
	
	@Before
	public void setup() {
		this.mvcObjectMapper = new MvcObjectMapper(objectMapper);

		this.mockMvc = setupMockMvcBuilder(MockMvcBuilders.webAppContextSetup(webApplicationContext), true)
				.build();
	}

	protected DefaultMockMvcBuilder setupMockMvcBuilder(DefaultMockMvcBuilder builder, boolean withCsrf) {
		MockHttpServletRequestBuilder mockServletRequestBuilder = MockMvcRequestBuilders.get("/");
		if (withCsrf) {
			mockServletRequestBuilder.with(csrf());
		}

		return builder
				.defaultRequest(mockServletRequestBuilder.contentType(MediaType.APPLICATION_JSON)
						.header("X-Requested-With", "XMLHttpRequest"))
				.apply(SecurityMockMvcConfigurers.springSecurity());
	}

	protected ResultActions performRequestWithRole(MockHttpServletRequestBuilder request, String userEmail, String role)
			throws Exception {
		request.with(user(userEmail).roles(role));
		return mockMvc.perform(request);
	}

	protected ResultActions performRequestWithUser(MockHttpServletRequestBuilder request, UserDetailsImpl user) throws Exception {
		request.with(user(user));
		return mockMvc.perform(request);
	}

	protected ResultActions performRequestWithUserAndRole(MockHttpServletRequestBuilder request, UserDetailsImpl user)
			throws Exception {
		request.with(user(user));
		return mockMvc.perform(request);
	}

	@After
	public void teardown() {
		dbCleaner.clean(sessionFactory);
	}
}