package bg.demax.motor.exam.result.rest;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.transaction.AfterTransaction;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.motor.exam.result.rest.config.ApplicationConstants;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MotorExamResultRestApplication.class)
@Transactional
@ActiveProfiles(ApplicationConstants.SPRING_PROFILE_UNIT_TEST)
public abstract class AbstractRepositoryTest {

	@Autowired
	private SessionFactory sessionFactory;

	private H2TestDatabaseCleaner dbCleaner = new H2TestDatabaseCleaner();

	protected Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	@AfterTransaction
	public void tearDown() {
		dbCleaner.clean(sessionFactory);
	}
}