package bg.demax.motor.exam.result.rest;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Hibernate;
import org.springframework.aop.TargetClassAware;
import org.springframework.core.GenericTypeResolver;

import bg.demax.legacy.util.convert.ConversionService;
import bg.demax.legacy.util.convert.Converter;

public class ConversionServiceTestingImpl implements ConversionService {

	private Map<ConverterKey, Converter<?, ?>> converters = new HashMap<>();

	public void addConverter(Converter<?, ?> converter) {
		Class<?> converterClass = converter.getClass();
		if (converter instanceof TargetClassAware) {
			converterClass = ((TargetClassAware) converter).getTargetClass();
		}
		Class<?>[] typeArguments = GenericTypeResolver.resolveTypeArguments(converterClass, Converter.class);
		ConverterKey key = new ConverterKey(typeArguments[0], typeArguments[1]);
		converters.put(key, converter);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T convert(Object from, Class<T> toType) {
		Class<?> originalFromType = Hibernate.getClass(from);

		Converter<?, ?> converter = findConverter(originalFromType, toType);

		if (converter == null) {
			throw new RuntimeException("There is no registered converter for " + originalFromType.getName() 
				+ " (or its ancestors) -> " + toType.getName());
		}

		return (T) invokeConverter(converter, from);
	}

	private Converter<?, ?> findConverter(Class<?> fromType, Class<?> toType) {
		Class<?> originalFromType = fromType;
		boolean isInterface = fromType.isInterface();
		Converter<?, ?> converter = null;
		List<Converter<?, ?>> foundConverters = new ArrayList<>();
		while (fromType != null && converter == null) {
			foundConverters.clear();
			ConverterKey key = new ConverterKey(fromType, toType);
			converter = converters.get(key);
			if (converter != null) {
				foundConverters.add(converter);
			}

			if (!isInterface) {
				Class<?>[] interfaces = fromType.getInterfaces();
				for (Class<?> interfaceClass : interfaces) {
					converter = findConverter(interfaceClass, toType);
					if (converter != null) {
						foundConverters.add(converter);
					}
				}
			}

			if (foundConverters.size() > 1) {
				throw new IllegalStateException(String.format("Found %d converters "
						+ "that can produce the requested conversion %s > %s",
						foundConverters.size(), originalFromType.getCanonicalName(), toType.getCanonicalName()));
			} else if (foundConverters.size() == 1) {
				return foundConverters.get(0);
			}

			fromType = fromType.getSuperclass();
		}

		return converter;
	}

	@Override
	public <T, K> List<T> convertList(List<K> items, Class<T> toType) {
		List<T> toList = new ArrayList<>();
		convertCollection(items, toList, toType);
		return toList;
	}

	@Override
	public <T, K> Set<T> convertSet(Set<K> items, Class<T> toType) {
		Set<T> toSet = new LinkedHashSet<>();
		convertCollection(items, toSet, toType);
		return toSet;
	}

	private <T, K> void convertCollection(Collection<K> items, Collection<T> toItems, Class<T> toType) {
		for (K item : items) {
			T convertedItem = convert(item, toType);
			toItems.add(convertedItem);
		}
	}

	@SuppressWarnings("unchecked")
	private Object invokeConverter(@SuppressWarnings("rawtypes") Converter converter, Object from) {
		return converter.convert(from);
	}

	private static final class ConverterKey {

		private Class<?> fromType;
		private Class<?> toType;

		public ConverterKey(Class<?> fromType, Class<?> toType) {
			this.fromType = fromType;
			this.toType = toType;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((fromType == null) ? 0 : fromType.hashCode());
			result = prime * result + ((toType == null) ? 0 : toType.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			ConverterKey other = (ConverterKey) obj;
			if (fromType == null) {
				if (other.fromType != null) {
					return false;
				}
			} else if (!fromType.equals(other.fromType)) {
				return false;
			}
			if (toType == null) {
				if (other.toType != null) {
					return false;
				}
			} else if (!toType.equals(other.toType)) {
				return false;
			}
			return true;
		}
	}

}
