package bg.demax.motor.exam.result.rest;

public interface DbScripts {

	/* motor_exam_permit */
	String EXAM_ROOMS = "/sql/motor_exam_permit/exam_rooms.sql";
//	String N_PERMIT_STATUS = "/sql/motor_exam_permit/n_permit_status.sql";
//	String N_PERMIT_TYPE = "/sql/motor_exam_permit/n_permit_type.sql";
//	String PERMITS = "/sql/motor_exam_permit/permits.sql";
	/* motor_exam_permit */
	
	/* motor_exam_result */
	String M_REQ_EXAM = "/sql/motor_exam_result/m_req_exam.sql";
	String N_RESERVATION_TYPES = "/sql/motor_exam_result/n_reservation_types.sql";
	String PROTOCOLS = "/sql/motor_exam_result/protocols.sql";
	/* motor_exam_result */

	/* exams */
	String CATEGORIES = "/sql/exams/categories.sql";
	String LANGUAGES = "/sql/exams/languages.sql";
	String SUB_CATEGORIES = "/sql/exams/sub_categories.sql";
	/* exams */
	
	/* public */
	String N_APPLICATION_TYPES = "/sql/public/n_application_types.sql";
	String N_CITIES = "/sql/public/n_cities.sql";
	String N_COUNTRIES = "/sql/public/n_countries.sql";
	String N_MUNS = "/sql/public/n_muns.sql";
	String N_ORG_UNITS = "/sql/public/n_org_units.sql";
	String N_REGIONS = "/sql/public/n_regions.sql";
	String SUBJECTS = "/sql/public/subjects.sql";
	/* public */
}
