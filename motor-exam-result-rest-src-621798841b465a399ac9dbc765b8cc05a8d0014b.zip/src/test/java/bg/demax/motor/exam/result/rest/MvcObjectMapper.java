package bg.demax.motor.exam.result.rest;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.test.web.servlet.ResultActions;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

public class MvcObjectMapper {

	protected ObjectMapper objectMapper;

	public MvcObjectMapper() {
		objectMapper = new ObjectMapper();
		objectMapper.disable(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
		objectMapper.disable(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS);
		objectMapper.registerModule(new JavaTimeModule());
		
	}
	
	public MvcObjectMapper(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}

	public <T> T getResponseObjectFromResultActions(ResultActions resultActions, Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {
		String responseJson = resultActions.andReturn().getResponse().getContentAsString();
		return objectMapper.readValue(responseJson, clazz);
	}

	@SuppressWarnings("unchecked")
	public <T> T getResponseObjectFromXmlResultActions(ResultActions resultActions, Class<T> clazz) throws JAXBException {
		byte[] responseXml = resultActions.andReturn().getResponse().getContentAsByteArray();
		JAXBContext jaxbContext = JAXBContext.newInstance(clazz);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		return (T) unmarshaller.unmarshal(new ByteArrayInputStream(responseXml));
	}
	
	@SuppressWarnings("unchecked")
	public <T> TestPageResult<T> getTestPageResultForRequest(ResultActions resultActions, Class<T> clazz) throws Exception {
		String responseJson = resultActions.andReturn().getResponse().getContentAsString();

		return (TestPageResult<T>) getCollectionFromResponseJson(responseJson, clazz, TestPageResult.class);
	}

	public <T, C extends Collection<T>> C getCollectionFromResultActions(ResultActions resultActions, Class<T> itemClazz,
			Class<C> collectionClazz) throws Exception {
		String responseJson = resultActions.andReturn().getResponse().getContentAsString();

		return getCollectionFromResponseJson(responseJson, itemClazz, collectionClazz);
	}

	private <T, C> C getCollectionFromResponseJson(String responseJson, Class<T> itemClazz, Class<C> collectionClazz)
			throws Exception {
		JavaType type = objectMapper.getTypeFactory().constructParametricType(collectionClazz, itemClazz);
		C response = objectMapper.readValue(responseJson, type);

		return response;
	}

	public <T> List<T> getListFromResultActions(ResultActions resultActions, Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {
		String responseJson = resultActions.andReturn().getResponse().getContentAsString();

		JavaType type = objectMapper.getTypeFactory().constructParametricType(List.class, clazz);
		List<T> response = objectMapper.readValue(responseJson, type);

		return response;
	}

	public String getRequestBodyFromObject(Object objectToConvertToJson) throws JsonProcessingException {
		return objectMapper.writeValueAsString(objectToConvertToJson);
	}
	
	public MultiValueMap<String, String> toParams(Object... objects)
			throws IllegalArgumentException, IllegalAccessException {
		MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<>();

		for (Object object : objects) {
			for (Field field : object.getClass().getDeclaredFields()) {
				if (!Modifier.isStatic(field.getModifiers())) {
					field.setAccessible(true);
					Object value = field.get(object);
					if (value != null) {
						if (value instanceof List) {
							List<?> valueList = (List<?>) value;
							for (Object elementValue : valueList) {
								paramMap.add(field.getName(), String.valueOf(elementValue));
							}
						} else {
							paramMap.set(field.getName(), String.valueOf(value));
						}
					}
				}
			}
		}
		return paramMap;
	}

	public static class TestPageResult<T> {

		private List<T> items;
		private long totalCount = -1;

		public TestPageResult() {
		}

		public TestPageResult(List<T> items, long totalCount) {
			this.items = items;
			this.totalCount = totalCount;
		}

		public List<T> getItems() {
			return items;
		}

		public void setItems(List<T> items) {
			this.items = items;
		}

		public long getTotalCount() {
			return totalCount;
		}

		public void setTotalCount(long totalCount) {
			this.totalCount = totalCount;
		}
	}
}
