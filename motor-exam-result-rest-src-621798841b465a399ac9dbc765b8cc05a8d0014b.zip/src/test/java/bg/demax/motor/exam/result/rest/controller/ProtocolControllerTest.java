package bg.demax.motor.exam.result.rest.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import bg.demax.motor.exam.result.rest.AbstractMvcTest;
import bg.demax.motor.exam.result.rest.DbScripts;
import bg.demax.motor.exam.result.rest.TestingUtil;
import bg.demax.motor.exam.result.rest.config.AuthorityConstants;
import bg.demax.motor.exam.result.rest.dto.ProtocolDto;

public class ProtocolControllerTest extends AbstractMvcTest {

	private static final String CONTROLLER_URL = "/api/protocols";

	@Test
	@Sql({ DbScripts.N_COUNTRIES, DbScripts.N_REGIONS, DbScripts.N_MUNS, DbScripts.N_CITIES, DbScripts.N_ORG_UNITS, 
		DbScripts.SUBJECTS, DbScripts.N_APPLICATION_TYPES, DbScripts.CATEGORIES, 
		DbScripts.SUB_CATEGORIES, DbScripts.LANGUAGES, DbScripts.M_REQ_EXAM, DbScripts.EXAM_ROOMS, 
		DbScripts.N_RESERVATION_TYPES, DbScripts.PROTOCOLS })
	public void getProtocols_authorization() throws Exception {
		MockHttpServletRequestBuilder request = get(CONTROLLER_URL)
				.param("orgUnitCode", "РДАА21")
				.param("examType", "EXTERNAL_THEORETICAL")
				.param("reservationType", "PUBLIC")
				.param("fromExamDate", "2020-12-01")
				.param("toExamDate", "2021-01-10");
		mockMvc.perform(request)
			.andExpect(status().isUnauthorized());

		UserDetails user = TestingUtil.getUserDetailsWithAuthorities("adr_rest_client",
				"__TEST_ROLE__");
		request.with(user(user));
		mockMvc.perform(request)
			.andExpect(status().isForbidden());
		
		user = TestingUtil.getUserDetailsWithAuthorities("adr_rest_client",
				AuthorityConstants.ROLE_MOTOR_EXAM_REST_API);
		request.with(user(user));
		mockMvc.perform(request)
			.andExpect(status().isOk())
			.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8));
	}
	
	@Test
	@Sql({ DbScripts.N_COUNTRIES, DbScripts.N_REGIONS, DbScripts.N_MUNS, DbScripts.N_CITIES, DbScripts.N_ORG_UNITS, 
		DbScripts.SUBJECTS, DbScripts.N_APPLICATION_TYPES, DbScripts.CATEGORIES, 
		DbScripts.SUB_CATEGORIES, DbScripts.LANGUAGES, DbScripts.M_REQ_EXAM, DbScripts.EXAM_ROOMS, 
		DbScripts.N_RESERVATION_TYPES, DbScripts.PROTOCOLS })
	public void getProtocols() throws Exception {
		UserDetails user = TestingUtil.getUserDetailsWithAuthorities("adr_rest_client",
				AuthorityConstants.ROLE_MOTOR_EXAM_REST_API);

		MockHttpServletRequestBuilder request = get(CONTROLLER_URL)
				.param("orgUnitCode", "РДАА21")
				.param("examType", "EXTERNAL_THEORETICAL")
				.param("reservationType", "PUBLIC")
				.param("fromExamDate", "2020-12-01")
				.param("toExamDate", "2021-01-10")
				.with(user(user));

		ResultActions resultActions = mockMvc.perform(request)
			.andExpect(status().isOk())
			.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8));

		List<ProtocolDto> protocolDtos = mvcObjectMapper
				.getListFromResultActions(resultActions, ProtocolDto.class);
		assertThat(protocolDtos).isNotNull().hasSize(1);
		ProtocolDto protocolDto = protocolDtos.get(0);
		assertThat(protocolDto).isNotNull();
		assertThat(protocolDto.getId()).isEqualTo(1L);
		assertThat(protocolDto.getExamDateTime()).isEqualTo(LocalDateTime.of(2021, 1, 3, 9, 30));
		assertThat(protocolDto.getNumber()).isEqualTo("--- / 03.01.2021");
		assertThat(protocolDto.getOrgUnit()).isNotNull();
		assertThat(protocolDto.getOrgUnit().getCode()).isNotBlank();
		assertThat(protocolDto.getOrgUnit().getName()).isNotBlank();
		assertThat(protocolDto.getRoomName()).isNotBlank();
		assertThat(protocolDto.getRemainingSeats()).isEqualTo(5);
		
		request = get(CONTROLLER_URL)
				.param("orgUnitCode", "РДАА21")
				.param("examType", "EXTERNAL_THEORETICAL")
				.param("reservationType", "IAAA_TAXI")
				.param("fromExamDate", "2020-12-01")
				.param("toExamDate", "2021-01-10")
				.with(user(user));

		resultActions = mockMvc.perform(request)
			.andExpect(status().isOk())
			.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8));
		
		protocolDtos = mvcObjectMapper
				.getListFromResultActions(resultActions, ProtocolDto.class);
		assertThat(protocolDtos).isNotNull().hasSize(1);
		
		protocolDto = protocolDtos.get(0);
		assertThat(protocolDto).isNotNull();
		assertThat(protocolDto.getId()).isEqualTo(5L);
		assertThat(protocolDto.getExamDateTime()).isEqualTo(LocalDateTime.of(2021, 1, 7, 9, 30));
		assertThat(protocolDto.getNumber()).isEqualTo("--- / 07.01.2021");
		assertThat(protocolDto.getOrgUnit()).isNotNull();
		assertThat(protocolDto.getOrgUnit().getCode()).isNotBlank();
		assertThat(protocolDto.getOrgUnit().getName()).isNotBlank();
		assertThat(protocolDto.getRoomName()).isNotBlank();
		assertThat(protocolDto.getRemainingSeats()).isEqualTo(4);
	}
}
