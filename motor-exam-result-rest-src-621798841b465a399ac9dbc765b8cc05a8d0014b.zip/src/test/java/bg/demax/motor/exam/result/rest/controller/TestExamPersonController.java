package bg.demax.motor.exam.result.rest.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.mockito.Mock;

import bg.demax.legacy.util.constraint.ConstraintCheckDispatcher;
import bg.demax.motor.exam.result.rest.AbstractMvcTest;
import bg.demax.motor.exam.result.rest.db.repository.ExamPersonRepository;
import bg.demax.motor.exam.result.rest.db.repository.ExamTypeRepository;
import bg.demax.motor.exam.result.rest.db.repository.ProvidedCategoryRepository;
import bg.demax.motor.exam.result.rest.db.repository.ProvidedDocumentRepository;
import bg.demax.motor.exam.result.rest.db.repository.SubCategoryRepository;

public class TestExamPersonController extends AbstractMvcTest {
    
	@Mock
	private ExamPersonRepository examPersonRepository;
	
	@Mock
	private ProvidedDocumentRepository providedDocumentRepository;

	@Mock
	private ConstraintCheckDispatcher constraintCheckDispatcher;
	
	@Mock
	private ExamTypeRepository examTypeRepository;
	
	@Mock
	private ProvidedCategoryRepository providedCategoryRepository;
	
	@Mock
	private SubCategoryRepository subCategoryRepository;

    @Test
	public void testNoRoleCheck() throws Exception {
	    mockMvc.perform(post("/api/exam-people/123456789/for-theoretical-exam-enrolment"))
	 			.andExpect(status().isUnauthorized());	
    }
}
