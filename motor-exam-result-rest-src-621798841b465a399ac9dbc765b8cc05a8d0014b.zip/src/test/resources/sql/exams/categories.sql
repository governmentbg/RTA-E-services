INSERT INTO exams.categories(category_id, name, template_name, app_code) VALUES 
(5, 'АДР водачи придобиване', 'ADR_Drivers_Acquire.pdf', 'ADR'),
(6, 'АДР водачи удължаване', 'ADR_Drivers_Renew.pdf', 'ADR'),
(7, 'АДР консултанти придобиване', NULL, 'ADR'),
(8, 'АДР консултанти удължаване', NULL, 'ADR');
