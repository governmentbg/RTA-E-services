INSERT INTO exams.languages(language_id, lang, is_mandatory) VALUES
(1, 'bg', NULL),
(2, 'en', NULL);
