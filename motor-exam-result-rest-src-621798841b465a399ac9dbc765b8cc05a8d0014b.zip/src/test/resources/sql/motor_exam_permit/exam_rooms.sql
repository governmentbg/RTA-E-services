INSERT INTO motor_exam_permit.exam_rooms(id, area, seatplaces, is_exam_capable, orm_version, city_code, address, exam_seats) VALUES
(2928, 24, 5, TRUE, 2, '67653', 'ИААА - СМОЛЯН', 5),
(2929, 24, 4, TRUE, 1, '67653', 'ИААА - СМОЛЯН', 4);
