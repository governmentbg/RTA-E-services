INSERT INTO motor_exam_result.m_requirements(req_id, orm_version) VALUES
(64, 0),
(65, 0),
(66, 0),
(67, 0);

INSERT INTO motor_exam_result.m_req_exam(req_id, name, internal) VALUES 
(64, 'вътрешен теоретичен изпит', true),
(65, 'вътрешен практически изпит', true),
(66, 'теоретичен изпит пред ДАИ', false),
(67, 'практически изпит пред ДАИ', false);
