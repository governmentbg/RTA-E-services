INSERT INTO motor_exam_result.n_reservation_types(id, type, is_valid) VALUES 
(1, 'Изпит на РДАА', TRUE),
(2, 'За резервиране от учебен център', TRUE),
(3, 'За таксиметрова дейност', TRUE),
(4, 'Неопределен', FALSE);
