INSERT INTO motor_exam_result.protocols(id, org_unit, creation_date, close_date, orm_version, chairman_id, number, is_ready_for_exam, exam_room_id, training_ground_id, exam_time, sub_category_id, exam_type, exam_comittee, max_etest_count, reserved_by, reservation_type, exam_room_afternoon_id, remark, payment_id, time_reserved) VALUES
(1, 'РДАА21', '2020-11-20', NULL, 0, NULL, NULL, FALSE, 2928, NULL, '2021-01-03 09:30:00', NULL, 66, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(2, 'РДАА21', '2020-11-21', NULL, 0, NULL, NULL, FALSE, 2929, NULL, '2021-01-04 09:30:00', NULL, 66, NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL),
(3, 'РДАА21', '2020-11-30', NULL, 0, NULL, 1003, FALSE, 2928, NULL, '2021-01-05 09:30:00', NULL, 64, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL),
(4, 'РДАА21', '2021-01-05', NULL, 0, NULL, 1004, FALSE, 2929, NULL, '2021-01-06 09:30:00', NULL, 67, NULL, NULL, NULL, 4, NULL, NULL, NULL, NULL),
(5, 'РДАА21', '2021-01-06', NULL, 0, NULL, NULL, FALSE, 2929, NULL, '2021-01-07 09:30:00', NULL, 66, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL);
