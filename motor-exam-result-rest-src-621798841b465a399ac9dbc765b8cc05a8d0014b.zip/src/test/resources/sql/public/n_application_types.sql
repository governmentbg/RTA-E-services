INSERT INTO public.n_application_types(code, description, is_valid) VALUES
('ADR', 'Информационна система за издаване на АДР удостоверения на водачи', 'Y');
