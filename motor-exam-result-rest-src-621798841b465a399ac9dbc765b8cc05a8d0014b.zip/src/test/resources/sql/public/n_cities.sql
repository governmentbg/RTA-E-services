INSERT INTO public.n_cities(code, city_type, name, name_lat, region_code, mun_code) VALUES
('68134', 1, 'гр.София', 'Sofia', 'SOF', '46'),
('56784', 1, 'гр.Пловдив', 'Plovdiv', 'PDV', '22'),
('67653', 1, 'гр.Смолян', 'Smolyan', 'SML', '31');
