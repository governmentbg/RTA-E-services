INSERT INTO public.n_countries(code, char2_code, num_code, name, name_lat, eu_member, eu_index, erru_member, is_active_erru_member) VALUES
('BGR', 'BG', '100', 'България', 'Bulgaria', 'Y', 'e34', 'Y', 'Y');
