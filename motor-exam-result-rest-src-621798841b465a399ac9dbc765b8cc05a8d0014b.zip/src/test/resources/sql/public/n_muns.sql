INSERT INTO public.n_muns(code, region_code, name, name_lat) VALUES
('46', 'SOF', 'Столична', 'Stolichna'),
('22', 'PDV', 'Пловдив', 'Plovdiv'),
('31', 'SML', 'Смолян', 'Smolyan');
