INSERT INTO public.subjects(id, subject_type, country_code, birth_date, version_id, ident_num, birth_place_city_code, birth_place_city_name) VALUES
(1, 'P', 'BGR', NULL, NULL, '0123456789', NULL, NULL),
(2, 'P', 'BGR', NULL, NULL, '0123456790', NULL, NULL),
(3, 'L', 'BGR', NULL, NULL, '121410441', NULL, NULL);

INSERT INTO public.subj_versions(id, subj_id, manager, manager_egn, city_code, base_address, ver_date, full_name, educ_level_code, has_vat_reg, vat_num, phone_num, first_name_cyr_id, family_name_cyr_id, surname_cyr_id, first_name_lat_id, family_name_lat_id, surname_lat_id, reg_post_code) VALUES 
(1, 1, NULL, NULL, NULL, NULL, '2020-11-27 10:45:20', 'Тест Тестов Тестов', NULL, 'U', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 2, NULL, NULL, NULL, NULL, '2020-11-27 12:00:02', 'Иван Тестов Тестов', NULL, 'U', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 3, NULL, NULL, NULL, NULL, '2020-11-27 12:00:02', 'ИААА', NULL, 'U', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

UPDATE public.subjects SET version_id = 1 
WHERE id = 1;

UPDATE public.subjects SET version_id = 2
WHERE id = 2;

UPDATE public.subjects SET version_id = 3
WHERE id = 3;
