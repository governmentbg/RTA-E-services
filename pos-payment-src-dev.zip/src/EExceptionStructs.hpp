#ifndef EEXCEPTIONSTRUCTS_HPP
#define EEXCEPTIONSTRUCTS_HPP

struct EInvalidRequest : public std::runtime_error {
	EInvalidRequest(string errorMessage) : runtime_error(errorMessage) {}
};

struct EResponseNotFound : public std::runtime_error {
	EResponseNotFound(string errorMessage) : runtime_error(errorMessage) {}
};

struct EPosTerminalBusy : public std::runtime_error {
	EPosTerminalBusy(string errorMessage) : runtime_error(errorMessage) {}
};

#endif