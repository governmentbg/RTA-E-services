#ifndef HTTP_HEADERS
#define HTTP_HEADERS

#define RESPONSE_OK                      \
	"HTTP/1.1 200 OK\r\n"                \
	"Content-Type: application/json\r\n" \
	"Connection: close\r\n\r\n"

#define RESPONSE_BAD_REQUEST             \
	"HTTP/1.1 400 BAD REQUEST\r\n"       \
	"Content-Type: application/json\r\n" \
	"Connection: close\r\n\r\n"

#define RESPONSE_INTERNAL_ERROR              \
	"HTTP/1.1 500 INTERNAL SERVER ERROR\r\n" \
	"Content-Type: application/json\r\n"     \
	"Connection: close\r\n\r\n"

	#define RESPONSE_SERVICE_UNAVAILABLE              \
	"HTTP/1.1 503 SERVICE UNAVAILABLE\r\n" \
	"Content-Type: application/json\r\n"     \
	"Connection: close\r\n\r\n"

#define RESPONSE_NOT_FOUND         \
	"HTTP/1.1 404 NOT FOUND\r\n"         \
	"Content-Type: application/json\r\n" \
	"Connection: close\r\n\r\n"

#endif
