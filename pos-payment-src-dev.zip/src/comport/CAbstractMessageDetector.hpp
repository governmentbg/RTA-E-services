#ifndef CABSTRACT_MESSAGE_DETECTOR
#define CABSTRACT_MESSAGE_DETECTOR

#include <vector>

#include "utils/CLogger.h"

enum EMessageReadingState {
	NOT_STARTED,
	DATA_STARTED,
	DATA_FINISHED,
	MESSAGE_FINISHED,
	NOT_ACKNOWLEDGED
};

class CAbstractMessageDetector {
   public:
	CAbstractMessageDetector() : currentState(NOT_STARTED){};
	~CAbstractMessageDetector(){};
	virtual EMessageReadingState checkAndUpdateState(const char& input) = 0;
	void reset();

   protected:
	EMessageReadingState currentState;
};

#endif