#include "CComPort.hpp"

#include "pos/EPosEnums.hpp"

//------------------------------------------------------------------------------
CComPort::CComPort(const std::string &devName, int baudRate,
				   std::shared_ptr<CAbstractMessageDetector> detector)
	: logger("CComPort: ") {
	this->deviceName = devName;
	this->baudRate = baudRate;
	this->mDetector = detector;
	openDevice();
}

//------------------------------------------------------------------------------
CComPort::~CComPort() { closeDevice(); }

//------------------------------------------------------------------------------
void CComPort::openDevice() {
	if (modemFileDescriptor != -1) {
		closeDevice();
	}

	modemFileDescriptor =
		open(deviceName.c_str(), O_RDWR | O_NOCTTY | O_NDELAY);

	if (modemFileDescriptor == -1) {
		throw std::runtime_error(
			"ERROR: Cannot acquire modem file descriptor!");
	}

	fcntl(modemFileDescriptor, F_SETFL, 0);

	resetTerminalOptions();
}

//------------------------------------------------------------------------------
void CComPort::closeDevice() {
	if (modemFileDescriptor != -1) {
		close(modemFileDescriptor);
		modemFileDescriptor = -1;
	}
}

//------------------------------------------------------------------------------
void CComPort::resetTerminalOptions() {
	struct termios terminalOptions;
	tcgetattr(modemFileDescriptor, &terminalOptions);

	/* set baud rate */
	cfsetispeed(&terminalOptions, baudRate);
	cfsetospeed(&terminalOptions, baudRate);

	terminalOptions.c_iflag &=
		~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
	terminalOptions.c_oflag &= ~OPOST;
	terminalOptions.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
	terminalOptions.c_cflag &= ~(CSIZE | PARENB);
	terminalOptions.c_cflag |= CS8;

	terminalOptions.c_cc[VMIN] = 0;
	terminalOptions.c_cc[VTIME] = 0;

	tcsetattr(modemFileDescriptor, TCSANOW, &terminalOptions);
}

//------------------------------------------------------------------------------
void CComPort::writeToTerminal(const std::vector<uint8_t> &data) {
	LOG_DEBUG << "---> sending data: ";
	for (uint8_t t : data) {
		// cout << "" << std::hex << setw(2) << (int)t;
		LOG_DEBUG << "" << std::hex << (int)t;
	}
	LOG_DEBUG << "\n";
	uint32_t bytesWritten =
		write(modemFileDescriptor, data.data(), data.size());
	if (bytesWritten != data.size()) {
		throw std::runtime_error("ERROR: Writing to terminal failed!");
	}
}

//------------------------------------------------------------------------------
int CComPort::getRealBaud(int termiosBaud) {
	switch (termiosBaud) {
		case B9600:
			return 9600;
		case B19200:
			return 19200;
		case B38400:
			return 38400;
		case B115200:
			return 115200;
		default:
			throw std::runtime_error("invalid baud rate");
	}
}

//------------------------------------------------------------------------------
void CComPort::cleanInputBuffer() {
	uint8_t singleChar = 0;

	LOG_TRACE << "cleaning input buffer: "
			  << "\n";
	while (read(modemFileDescriptor, &singleChar, 1) > 0)
		LOG_TRACE << singleChar;

	LOG_TRACE << "\n";
}

//------------------------------------------------------------------------------
void CComPort::readFromTerminal(uint32_t maxWaitTime,
								std::vector<uint8_t> &data) {
	data.clear();
	if (maxWaitTime <= 0) maxWaitTime = 1;

	uint64_t startTime =
		std::chrono::duration_cast<std::chrono::milliseconds>(
			std::chrono::system_clock::now().time_since_epoch())
			.count();

	LOG_DEBUG << "received <--";
	while (true) {
		// Initialize file descriptor sets
		fd_set read_fds, write_fds, except_fds;
		FD_ZERO(&read_fds);
		FD_ZERO(&write_fds);
		FD_ZERO(&except_fds);
		FD_SET(modemFileDescriptor, &read_fds);

		uint64_t currentTime =
			std::chrono::duration_cast<std::chrono::milliseconds>(
				std::chrono::system_clock::now().time_since_epoch())
				.count();

		struct timeval timeout;
		timeout.tv_sec = 0;

		if (maxWaitTime > (currentTime - startTime))
			timeout.tv_usec = (maxWaitTime - currentTime + startTime) * 1000L;
		else
			timeout.tv_usec = 0;

		uint8_t singleChar = 0;

		if ((timeout.tv_usec > 0) &&
			(select(modemFileDescriptor + 1, &read_fds, &write_fds, &except_fds,
					&timeout) == 1)) {
			if (read(modemFileDescriptor, &singleChar, 1) > 0) {
				// cout << "" << std::hex << setw(3) << (int)singleChar;
				LOG_DEBUG << "" << std::hex << (int)singleChar;
				EMessageReadingState status =
					mDetector->checkAndUpdateState(singleChar);
				if (status == NOT_STARTED) continue;

				data.push_back(singleChar);

				if (status == MESSAGE_FINISHED) {
					return;
				}
			}
		} else {
			if (timeout.tv_usec <= 0)
				LOG_DEBUG << "Read timeout reached: " << timeout.tv_usec
						  << "\n";
			return;
		}
	}
}
