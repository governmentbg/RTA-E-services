#ifndef CCOMPORT_HPP
#define CCOMPORT_HPP

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <exception>
#include <stdexcept>
#include <sys/select.h>
#include <chrono>
#include <string>
#include <iostream>
#include <vector>
#include "utils/CLogger.h"

#include "CAbstractMessageDetector.hpp"



class CComPort
{

private:
  CLogger logger;
  std::shared_ptr<CAbstractMessageDetector> mDetector;

  static const int RETRY_RANDOMIZATION = 3;
  static const int BYTE_READ_RETRY_COUNT = 1000;
  static const int TIME_MARGIN = 50;

  int modemFileDescriptor = -1;
  std::string deviceName;
  int baudRate;

 public:
  void writeToTerminal(const std::vector<uint8_t> &data);
  void readFromTerminal(uint32_t maxWaitTime, std::vector<uint8_t> &data);
  void cleanInputBuffer();

private:
  CComPort(const CComPort &orig) = delete;
  CComPort &operator=(CComPort const &) = delete;

  int getRealBaud(int termiosBaud);
  void openDevice();
  void closeDevice();
  void resetTerminalOptions();

public:
  CComPort(const std::string &devName, int baudRate, std::shared_ptr<CAbstractMessageDetector> detector);
  ~CComPort();
};

#endif
