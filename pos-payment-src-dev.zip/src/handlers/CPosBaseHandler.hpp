#ifndef CPOS_BASE_HANDLER
#define CPOS_BASE_HANDLER

#include<memory>

#include "../utils/CFormatter.h"
#include "civetweb/CivetServer.h"
#include "civetweb/HttpHeaders.h"
#include "pos/CPosTerminal.hpp"
#include "utils/ApplicationConfig.hpp"
#include "utils/CLogger.h"
#include "EExceptionStructs.hpp"


class CPosBaseHandler : public CivetHandler {
   public:
	CPosBaseHandler() {};
	virtual ~CPosBaseHandler(){};
	virtual bool handlePost(CivetServer* server,
							struct mg_connection* conn) = 0;
	virtual bool handleGet(CivetServer* server, struct mg_connection* conn) {
		std::string key;
		CivetServer::getParam(
			conn, APP_CONFIG->getQueryParamRequestId().c_str(), key);

		try {
			SPosResponse response =
				CPosTerminal::getInstance()->getResponse(key);
			sendResponse(conn, RESPONSE_OK,
						 getJsonStringFromPosResponse(response));
			return true;

		} catch (const EResponseNotFound& e) {
			sendResponse(conn, RESPONSE_NOT_FOUND, e.what());
			return false;
		} catch (const std::runtime_error& e) {
			sendResponse(conn, RESPONSE_INTERNAL_ERROR, e.what());
			return false;
		}
	}

   private:
    CLogger logger;
	std::shared_ptr<CPosTerminal> terminal;

   public:
	void sendResponse(mg_connection* conn, const std::string& header,
					  std::string message) {
		if (header.compare(RESPONSE_INTERNAL_ERROR) == 0) {
			logError(message);
			message = CFormatter() << "{error:\"" << message << "\"}";
		}

		mg_printf(conn, "%s", header.c_str());
		mg_printf(conn, "%s", message.c_str());
	}

	void logError(const std::string& message) {
		std::stringstream errorSS;

		errorSS << "An error occured : " << message << "\n";
		// TODO make this work
		LOG_ERROR << errorSS.str();

		// if (APP_CONFIG->getSaveRequestData())
		// 	writeResponseToFile(APP_CONFIG->getRequestFilesRootDir() + "/" +
		// 							requestTime,
		// 						errorSS.str());
	}

	std::string getJsonStringFromPosResponse(const SPosResponse& response) {
		std::stringstream result;
		result << "{";

		if (response.msgCode.size() > 0) 
		result << "\"msgCode\":\"" << response.msgCode << "\",";

		if (response.ecrNum.size() > 0)
		result << "\"ecrNumber\":\"" << response.ecrNum << "\",";

		if (response.functionNum.size() > 0)
			result << "\"functionNumber\":\"" << response.functionNum << "\",";

		if (response.terminalId.size() > 0)
			result << "\"terminalId\":\"" << response.terminalId << "\",";

		if (response.bookkeepingPrd.size() > 0)
			result << "\"bookKeepingPeriod\":\"" << response.bookkeepingPrd
				   << "\",";

		if (response.authCode.size() > 0)
			result << "\"authenticationCode\":\"" << response.authCode << "\",";

		if (response.retReferenceNum.size() > 0)
			result << "\"retrievalReferenceNumber\":\""
				   << response.retReferenceNum << "\",";

		if (response.amount.size() > 0)
			result << "\"amount\":\"" << response.amount << "\",";

		if (response.cashback.size() > 0)
			result << "\"cashback\":\"" << response.cashback << "\",";

		if (response.loyaltyPrm.size() > 0)
			result << "\"loyaltyPremium\":\"" << response.loyaltyPrm << "\",";

		if (response.cardHolderId.size() > 0)
			result << "\"carholderId\":\"" << response.cardHolderId << "\",";

		if (response.reason.size() > 0)
			result << "\"reason\":\"" << response.reason << "\",";

		if (response.message.size() > 0)
			result << "\"message\":\"" << response.message << "\",";

		result << "}";

		std::string resultStr = result.str();
		// remove trailing comma
		resultStr = resultStr.erase((resultStr.length() - 2), 1);
		return resultStr;
	}
};

#endif