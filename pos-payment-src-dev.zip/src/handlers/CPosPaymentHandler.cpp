#include "CPosPaymentHandler.hpp"

#include <jsoncpp/json/json.h>
#include <string.h>

#include "EExceptionStructs.hpp"
#include "civetweb/HttpHeaders.h"
#include "utils/ApplicationConfig.hpp"

bool CPosPaymentHandler::handlePost(CivetServer* server,
									struct mg_connection* conn) {
	std::string request = CivetServer::getPostData(conn);

	try {
		Json::Value jsonRequest;
		Json::Reader jsonReader;

		logger(ELogLevel::DEBUG) << "data: " << request << "\n";

		if (!jsonReader.parse(request, jsonRequest))
			throw std::runtime_error("JSON parsing failed\n");

		if (!jsonRequest[APP_CONFIG->getQueryParamFuncNumber()].isNull() &&
			!jsonRequest[APP_CONFIG->getQueryParamAmount()].isNull()) {
			std::string amount =
				jsonRequest[APP_CONFIG->getQueryParamAmount()].asString();
			uint8_t functionNumber =
				jsonRequest[APP_CONFIG->getQueryParamFuncNumber()]
					.asString()
					.at(0);

			time_t timestamp;
			std::shared_ptr<CPosTerminal> terminal =
				CPosTerminal::getInstance();

			timestamp = terminal->startPaymentThread(functionNumber, amount);

			sendResponse(conn, RESPONSE_OK, std::to_string(timestamp));
			return true;
		} else {
			sendResponse(conn, RESPONSE_BAD_REQUEST, "Bad Request");
			return false;
		}
	} catch (EPosTerminalBusy& e) {
		sendResponse(conn, RESPONSE_SERVICE_UNAVAILABLE, e.what());
	} catch (std::runtime_error& e) {
		sendResponse(conn, RESPONSE_INTERNAL_ERROR, e.what());
		return false;
	}
}
