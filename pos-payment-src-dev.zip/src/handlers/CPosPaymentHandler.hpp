#ifndef CPOS_REQUEST_HANDLER
#define CPOS_REQUEST_HANDLER

#include <memory>

#include "CPosBaseHandler.hpp"
#include "pos/CPosTerminal.hpp"

class CPosPaymentHandler : public CPosBaseHandler {
   public:
	CPosPaymentHandler() : logger("CPosRequestHandler: "){};

	virtual ~CPosPaymentHandler(){};
	virtual bool handlePost(CivetServer* server, struct mg_connection* conn);

   private:
	CLogger logger;
};

#endif