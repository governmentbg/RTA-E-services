#include "CPosPeriodHandler.hpp"

#include <string.h>

#include "utils/ApplicationConfig.hpp"
#include "EExceptionStructs.hpp"

bool CPosPeriodHandler::handlePost(CivetServer* server,
								   struct mg_connection* conn) {
	std::string request = CivetServer::getPostData(conn);

	try {
			time_t timestamp;
			std::shared_ptr<CPosTerminal> terminal =
				CPosTerminal::getInstance();

			timestamp = terminal->startClosePeriodThread();

			sendResponse(conn, RESPONSE_OK, std::to_string(timestamp));
			return true;

	} catch (EPosTerminalBusy& e) {
		sendResponse(conn, RESPONSE_SERVICE_UNAVAILABLE, e.what());
	} catch (std::runtime_error& e) {
		sendResponse(conn, RESPONSE_INTERNAL_ERROR, e.what());
		return false;
	}
	
}