#ifndef CPOS_PERIOD_HANDLER
#define CPOS_PERIOD_HANDLER

#include "CPosBaseHandler.hpp"
#include "civetweb/CivetServer.h"
#include "utils/CLogger.h"

class CPosPeriodHandler : public CPosBaseHandler {
   public:
	CPosPeriodHandler() : logger("CPosRequestHandler: "){};

	virtual ~CPosPeriodHandler(){};
	virtual bool handlePost(CivetServer* server, struct mg_connection* conn);

   private:
	CLogger logger;
};

#endif