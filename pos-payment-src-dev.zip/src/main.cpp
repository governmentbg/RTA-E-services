#include <civetweb/CivetServer.h>

#include <chrono>
#include <iostream>
#include <memory>
#include <vector>

#include "comport/CComPort.hpp"
#include "handlers/CPosPaymentHandler.hpp"
#include "handlers/CPosPeriodHandler.hpp"
#include "pos/CPosMessageDetector.hpp"
#include "pos/CPosTerminal.hpp"
#include "pos/EPosEnums.hpp"
#include "utils/ApplicationConfig.hpp"
#include "utils/CLogger.h"

CLogger logger("main: ");

void initLogging() {
	std::map<string, ELogLevel> stringToDbgLevel = {
		{"DEBUG", ELogLevel::DEBUG}, {"INFO", ELogLevel::INFO},
		{"WARN", ELogLevel::WARN},	 {"ERROR", ELogLevel::ERROR},
		{"TRACE", ELogLevel::TRACE}, {"SILENT", ELogLevel::SILENT}};
	if (APP_CONFIG->getLogLevel().empty())
		CLogger::setMaxLogLevel(ELogLevel::ERROR);
	else {
		if (stringToDbgLevel.find(APP_CONFIG->getLogLevel()) !=
			stringToDbgLevel.end())
			CLogger::setMaxLogLevel(
				stringToDbgLevel[APP_CONFIG->getLogLevel()]);
		else {
			LOG_ERROR << "Invalid log error: " << APP_CONFIG->getLogLevel()
					  << "\n";
			CLogger::setMaxLogLevel(ELogLevel::DEBUG);
		}
	}
}

int main(int argc, char** argv) try {
	// std::shared_ptr<CComPort> comport(new CComPort("/dev/ttyACM0", 9600,
	// mDetector));

	// CPosTerminal terminal(comport);

	// SPosRequest request = {
	// 	'4',	// msgCode
	// 	"03",	// ecr
	// 	'1',	// function number
	// 	"1",	// amount
	// 	"",		// cashback
	// 	"",		// loyalty premium
	// 	"",		// loyalty scheme
	// 	"",		// installments
	// 	"975",	// currency code
	// 	"9999"	// operator number
	// };

	// terminal.sendRequest(request2);

	if (argc != 2) {
		std::cout << "Call this program like this:" << std::endl;
		std::cout << "./posdemo settings.json" << std::endl;
	}

	ApplicationConfig::setConfigPath(argv[1]);
	initLogging();

	std::string port = APP_CONFIG->getPort();
	const char* options[] = {"document_root",
							 APP_CONFIG->getDocumentRoot().c_str(),
							 "listening_ports", port.c_str(), 0};

	std::vector<std::string> cpp_options;
	for (uint8_t i = 0; i < (sizeof(options) / sizeof(options[0]) - 1); i++) {
		cpp_options.push_back(options[i]);
	}

	std::mutex processingMutex;

	CivetServer server(cpp_options);
	CPosPaymentHandler posPaymentHandler;
	CPosPeriodHandler posPeriodHandler;
	server.addHandler(APP_CONFIG->getRequestAmountUri(), posPaymentHandler);
	// server.addHandler(APP_CONFIG->getClosePeriodUri(), posPeriodHandler);

	while (true) {
		sleep(1);
	}

	printf("Bye!\n");

	return 0;

} catch (std::exception& e) {
	std::cout << e.what() << std::endl;
}