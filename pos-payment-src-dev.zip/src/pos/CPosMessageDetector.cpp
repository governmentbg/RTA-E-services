#include "CPosMessageDetector.hpp"

#include "pos/EPosEnums.hpp"

CPosMessageDetector::CPosMessageDetector(std::string loggerName)
	: logger(loggerName) {}

CPosMessageDetector::~CPosMessageDetector() {}

EMessageReadingState CPosMessageDetector::checkAndUpdateState(
	const char& input) {
	switch (input) {
		case ACKNOWLEDGE:
			LOG_DEBUG << "IN ACKNOWLEDGE \n";
			if (currentState == NOT_STARTED ||
				currentState == MESSAGE_FINISHED) {
				LOG_DEBUG << "IN NOT_STARTED \n";
				currentState = MESSAGE_FINISHED;
				break;
			}

			if (currentState != NOT_STARTED) {
				LOG_DEBUG << "IN != NOT_STARTED \n";
				currentState = NOT_STARTED;
				throw std::runtime_error(
					"Communication with pos is not started");
			}
			break;

		case STX:
			LOG_DEBUG << "IN STX \n";
			if (currentState == NOT_STARTED ||
				currentState == MESSAGE_FINISHED) {
				currentState = DATA_STARTED;
			} else {
				currentState = NOT_STARTED;
				throw std::runtime_error("Communication is already started");
			}
			break;

		case ETX:
			LOG_DEBUG << "IN ETX \n";
			if (currentState == DATA_STARTED) {
				currentState = DATA_FINISHED;
			} else {
				currentState = NOT_STARTED;
				throw std::runtime_error(
					"Communication is not started and cannot end");
			}
			break;

		case NAK:
			LOG_DEBUG << "IN NAK \n";
			currentState = MESSAGE_FINISHED;
			break;

		default:
			LOG_DEBUG << "IN DEFAULT \n";
			if (currentState == DATA_FINISHED) currentState = MESSAGE_FINISHED;
			break;
	}

	return currentState;
}