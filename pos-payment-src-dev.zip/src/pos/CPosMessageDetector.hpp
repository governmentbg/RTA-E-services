#ifndef CPOS_MESSAGE_DETECTOR
#define CPOS_MESSAGE_DETECTOR

#include "comport/CAbstractMessageDetector.hpp"

class CPosMessageDetector : public CAbstractMessageDetector {
   public:
	CPosMessageDetector(std::string loggerName);
	~CPosMessageDetector();
	virtual EMessageReadingState checkAndUpdateState(const char& input);

   private:
	CLogger logger;
};

#endif