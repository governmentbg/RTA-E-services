#include "pos/CPosTerminal.hpp"

#include <algorithm>
#include <functional>
#include <regex>

#include "EExceptionStructs.hpp"
#include "EPosEnums.hpp"
#include "pos/CPosMessageDetector.hpp"
#include "utils/ApplicationConfig.hpp"

void printResponse(SPosResponse response) {
	std::cout << "msgCode: " << response.msgCode << std::endl;
	std::cout << "ecrNum: " << response.ecrNum << std::endl;
	std::cout << "funcNum: " << response.functionNum << std::endl;
	std::cout << "terminalId: " << response.terminalId << std::endl;
	std::cout << "bookkeeping: " << response.bookkeepingPrd << std::endl;
	std::cout << "authCode: " << response.authCode << std::endl;
	std::cout << "retRefeNum: " << response.retReferenceNum << std::endl;
	std::cout << "amount: " << response.amount << std::endl;
	std::cout << "cashback" << response.cashback << std::endl;
	std::cout << "loyaltyPrm: " << response.loyaltyPrm << std::endl;
	std::cout << "carholderId: " << response.cardHolderId << std::endl;
	std::cout << "reason: " << response.reason << std::endl;
}

CPosTerminal::CPosTerminal() : logger{"PosTerminal: "} {
	std::shared_ptr<CAbstractMessageDetector> mDetector =
		std::make_shared<CPosMessageDetector>("CPosMessageDetector: ");
	comport = std::make_shared<CComPort>(APP_CONFIG->getDeviceName(),
										 APP_CONFIG->getBaudRate(), mDetector);
	currentState = IDLE;
	lastRequests.empty();
	startCleaningThread();
}

CPosTerminal::CPosTerminal(std::shared_ptr<CComPort> comPort)
	: comport{comPort}, logger("PosTerminal: ") {
	currentState = IDLE;
	startCleaningThread();
}

SPosResponse CPosTerminal::sendRequest(const SPosRequest& request) {
	std::vector<uint8_t> requestData = buildData(request);
	std::vector<uint8_t> data;

	comport->cleanInputBuffer();
	comport->writeToTerminal(START_COMMUNICATION);	// send first mesage
	comport->readFromTerminal(4500, data);			// read acknowledge
	comport->readFromTerminal(4500, data);			// read response
	if (data.at(0) ==
		ACKNOWLEDGE) {	// read again if last response was acknowledge
		comport->readFromTerminal(4500, data);
	}
	comport->writeToTerminal(
		std::vector<uint8_t>{ACKNOWLEDGE});	 // send acknowledge
	comport->writeToTerminal(requestData);	 // send response
	comport->readFromTerminal(4500, data);	 // read acknowledge
	comport->readFromTerminal(
		APP_CONFIG->getMaxWaitTime(),
		data);	// read response after payment with card (waits 100 secods)

	SPosResponse response;
	if (data.size() > 0) response = decodeResponse(data);
	printResponse(response);

	return response;
}

uint8_t CPosTerminal::checksum(const std::vector<uint8_t>& data) {
	uint8_t result = 0;
	for (uint8_t tmp : data) {
		result = result ^ tmp;
	}
	return result;
}

std::vector<uint8_t> CPosTerminal::buildData(const SPosRequest& request) {
	std::vector<uint8_t> data;
	data.push_back(STX);			  // start
	data.push_back(request.msgCode);  // message type

	for (const char& c : request.ecrNum) {
		data.push_back(c);
	}

	if (std::count(funcNumber.begin(), funcNumber.end(), request.msgCode)) {
		data.push_back(request.functionNum);
	}
	if (std::count(sendAmount.begin(), sendAmount.end(), request.msgCode)) {
		addAmount(data, request.amount);
	}
	if (std::count(cashback.begin(), cashback.end(), request.msgCode)) {
		addAmount(data, request.cashback);
	}
	if (std::count(loyaltyPremium.begin(), loyaltyPremium.end(),
				   request.msgCode)) {
		addAmount(data, request.loyaltyPrm);
	}
	if (std::count(loyaltyScheme.begin(), loyaltyScheme.end(),
				   request.msgCode)) {
		for (const char& c : request.loyaltySch) {
			data.push_back(c);
		}
	}
	if (std::count(installments.begin(), installments.end(), request.msgCode)) {
		for (const char& c : request.installments) {
			data.push_back(c);
		}
	}
	if (std::count(currencyCode.begin(), currencyCode.end(), request.msgCode)) {
		for (const char& c : request.currencyCode) {
			data.push_back(c);
		}
	}
	if (std::count(operatorNumber.begin(), operatorNumber.end(),
				   request.msgCode)) {
		for (const char& c : request.operatorNum) {
			data.push_back(c);
		}
	}

	// end byte and checksum calculation
	data.push_back(ETX);
	data.push_back(
		checksum(std::vector<uint8_t>(data.begin() + 1, data.end())));
	return data;
}

SPosResponse CPosTerminal::decodeResponse(const std::vector<uint8_t>& data) {
	int index = 4;
	SPosResponse response;

	uint8_t msgCode = data.at(1);
	response.msgCode = msgCode;
	response.ecrNum.append(data.begin() + 2, data.begin() + 4);

	if (std::count(funcNumber.begin(), funcNumber.end(), msgCode)) {
		response.functionNum =
			std::string(data.begin() + index, data.begin() + index + 1);
		index += 1;
	}
	if (std::count(terminalId.begin(), terminalId.end(), msgCode)) {
		response.terminalId =
			std::string(data.begin() + index, data.begin() + index + 8);
		index += 8;

		response.bookkeepingPrd =
			std::string(data.begin() + index, data.begin() + index + 6);
		index += 6;

		response.authCode =
			std::string(data.begin() + index, data.begin() + index + 6);
		index += 6;

		response.retReferenceNum =
			std::string(data.begin() + index, data.begin() + index + 15);
		index += 15;
	}
	if (std::count(sendAmount.begin(), sendAmount.end(), msgCode)) {
		response.amount =
			std::string(data.begin() + index, data.begin() + index + 12);
		index += 12;
	}
	if (std::count(cashback.begin(), cashback.end(), msgCode)) {
		response.cashback =
			std::string(data.begin() + index, data.begin() + index + 12);
		index += 12;
	}
	if (std::count(loyaltyPremium.begin(), loyaltyPremium.end(), msgCode)) {
		response.loyaltyPrm =
			std::string(data.begin() + index, data.begin() + index + 12);
		index += 12;
	}
	if (std::count(cardholderId.begin(), cardholderId.end(), msgCode)) {
		response.cardHolderId =
			std::string(data.begin() + index, data.end() - 2);
		index += 80;
	}
	if (std::count(reason.begin(), reason.end(), msgCode)) {
		response.reason =
			std::string(data.begin() + index, data.begin() + index + 2);
		index += 2;
	}

	return response;
}

void CPosTerminal::addAmount(std::vector<uint8_t>& data, std::string amount) {
	for (int i = 0; i < 12; i++) {
		data.push_back(0x30);
	}
	std::copy(amount.begin(), amount.end(), data.end() - amount.size());
}

bool containsOnlyDigits(const std::string& s) {
	return std::all_of(s.begin(), s.end(), ::isdigit);
}

// TODO implement a mechanism to delete old request(after 30min or set a maximum
// numnber of requests)

void CPosTerminal::payment4(char funcNumber, const std::string& amount,
							time_t timestamp) {
	try {
		if (funcNumber != '1' && funcNumber != '2' && funcNumber != '4' &&
			funcNumber != '5')
			throw std::runtime_error(
				"Invalid function number for message code 4");

		if (!containsOnlyDigits(amount))
			throw std::runtime_error("Amount does not contain only numbers");

		this->amount = amount;
		requestTimestamp = timestamp;
		functionNumber = funcNumber;

		transitionLoop(payment4Transitions);

	} catch (const std::runtime_error& e) {
		SPosResponse response;
		response.message = e.what();
		std::unique_lock<std::mutex> lock(requestsMutex);
		lastRequests.insert(
			std::make_pair(std::to_string(requestTimestamp), response));
	}
}

void CPosTerminal::closePeriodI(const time_t timestamp) {
	requestTimestamp = timestamp;

	try {
		transitionLoop(closePeriodITransitions);
	} catch (const std::runtime_error& e) {
		SPosResponse response;
		response.message = e.what();
		std::unique_lock<std::mutex> lock(requestsMutex);
		lastRequests.insert(
			std::make_pair(std::to_string(requestTimestamp), response));
	}
}

EPosState CPosTerminal::getCurrentState() {
	std::unique_lock<std::mutex> stateLock(currentStateMutex);
	return currentState;
}

void CPosTerminal::setCurrentState(EPosState state) {
	std::unique_lock<std::mutex> lock(currentStateMutex);
	currentState = state;
}

void CPosTerminal::sendStartRequest() {
	comport->writeToTerminal(START_COMMUNICATION);
}

void CPosTerminal::sendAKN() {
	comport->writeToTerminal(std::vector<uint8_t>{ACKNOWLEDGE});
}

void CPosTerminal::sendNAK() {
	comport->writeToTerminal(std::vector<uint8_t>{NAK});
}

void CPosTerminal::sendAKNAmount() {
	SPosRequest request = {
		'4',							 // msgCode
		APP_CONFIG->getEcr(),			 // ecr
		functionNumber,					 // function number
		amount,							 // cash amount
		"",								 // cashback
		"",								 // loyalty premium
		"",								 // loyalty scheme
		"",								 // installments
		APP_CONFIG->getCurrencyCode(),	 // currency code
		APP_CONFIG->getOperatorNumber()	 // operator number
	};
	std::vector<uint8_t> data = buildData(request);
	comport->writeToTerminal(std::vector<uint8_t>{ACKNOWLEDGE});
	comport->writeToTerminal(data);
}

void CPosTerminal::sendAKNSave() {
	comport->writeToTerminal(std::vector<uint8_t>{ACKNOWLEDGE});
	std::unique_lock<std::mutex> lock(requestsMutex);
	lastRequests.insert(
		std::make_pair(std::to_string(requestTimestamp), latestResponse));
}

void CPosTerminal::timeout() {
	SPosResponse response;
	response.message = "Connection to pos terminal timed out";
	std::unique_lock<std::mutex> lock(requestsMutex);
	lastRequests.insert(
		std::make_pair(std::to_string(requestTimestamp), response));
}

void CPosTerminal::sendAKNClosePeriod() {
	SPosRequest request = {
		'I',							 // msgCode
		APP_CONFIG->getEcr(),			 // ecr
		'C',							 // function number
		"",								 // cash amount
		"",								 // cashback
		"",								 // loyalty premium
		"",								 // loyalty scheme
		"",								 // installments
		"",								 // currency code
		APP_CONFIG->getOperatorNumber()	 // operator number
	};
	std::vector<uint8_t> data = buildData(request);
	comport->writeToTerminal(std::vector<uint8_t>{ACKNOWLEDGE});
	comport->writeToTerminal(data);
}

void CPosTerminal::transitionLoop(const std::vector<STransition>& transitions) {
	std::vector<uint8_t> data;
	int counter = 0;
	do {
		LOG_DEBUG << "while counter: " << counter << "\n";
		if (getCurrentState() != IDLE) {
			comport->cleanInputBuffer();
			comport->readFromTerminal(APP_CONFIG->getMaxWaitTime(), data);
			currentEvent = getResponseEvent(data);
			if (currentEvent == RESPONSE || currentEvent == ABORT)
				latestResponse = decodeResponse(data);
		}
		transitionState(transitions);
		counter++;
	} while (getCurrentState() != IDLE);
}

void CPosTerminal::transitionState(
	const std::vector<STransition>& transitions) {
	LOG_DEBUG << "Event before transition state: " << currentEvent
			  << " State before transition state: " << getCurrentState()
			  << "\n";

	for (STransition t : transitions) {
		if (t.currentState == getCurrentState() && t.event == currentEvent) {
			if (t.transitionFunc != nullptr)
				std::invoke(t.transitionFunc, *this);

			setCurrentState(t.endState);
			break;
		}
	}
	LOG_DEBUG << "finished transition state; endState: " << getCurrentState()
			  << "\n";
}

EPosEvent CPosTerminal::getResponseEvent(const std::vector<uint8_t> data) {
	LOG_DEBUG << "response data: ";
	int counter = 0;
	for (uint8_t t : data) {
		LOG_DEBUG << t;
		counter++;
	}
	LOG_DEBUG << "\n";
	LOG_DEBUG << "counter: " << counter << "\n";
	if (data.size() == 0) {
		return TIMEOUT;
	}
	switch (data.at(0)) {
		case ACKNOWLEDGE:
			LOG_DEBUG << "in case ACKNOWLEDGE \n";
			return AKN;
			break;
		case NAK:
			LOG_DEBUG << "in case NAK \n";
			return NOT_AKN;
			break;
		case STX: {
			LOG_DEBUG << "in case STX \n";
			std::vector<uint8_t> dataToCheckSum(data.begin() + 1,
												data.end() - 1);
			uint8_t check = checksum(dataToCheckSum);
			if (data.back() == check) {
				LOG_DEBUG << "checksum is correct \n";
				if (data.size() > 1) {
					if (data.at(1) == ABRT) {
						LOG_DEBUG << "returning abort \n";
						return ABORT;
					} else {
						LOG_DEBUG << "returning response \n";
						return RESPONSE;
					}
				}
			} else {
				LOG_DEBUG << "checksum is incorrect \n";
				return WRONG_RESPONSE;
			}
			break;
		}
		default:
			LOG_DEBUG << "in default case \n";
			return UNEXPECTED_RESPONSE;
			break;
	}

	return UNEXPECTED_RESPONSE;
}

time_t CPosTerminal::startPaymentThread(char functionNumber,
										const std::string& amount) {
	std::unique_lock<std::mutex> lock(threadMutex);

	LOG_DEBUG << "in startPaymentThread \n";

	checkPosAvailability();
	preparePosForNewThread();

	time_t timestamp = time(nullptr);

	CPosTerminal::getInstance()->currentProcessThread =
		std::shared_ptr<std::thread>(new std::thread(
			&CPosTerminal::payment4, this, functionNumber, amount, timestamp));

	return timestamp;
}

time_t CPosTerminal::startClosePeriodThread() {
	std::unique_lock<std::mutex> lock(threadMutex);

	LOG_DEBUG << "in startClosePeriodThread \n";

	checkPosAvailability();
	preparePosForNewThread();

	time_t timestamp = time(nullptr);

	CPosTerminal::getInstance()->currentProcessThread =
		std::shared_ptr<std::thread>(
			new std::thread(&CPosTerminal::closePeriodI, this, timestamp));

	return timestamp;
}

void CPosTerminal::checkPosAvailability() {
	if (CPosTerminal::getInstance()->getCurrentState() != IDLE)
		throw EPosTerminalBusy("POS terminal is busy with another process");
}

void CPosTerminal::preparePosForNewThread() {
	if (CPosTerminal::getInstance()->currentProcessThread != nullptr) {
		CPosTerminal::getInstance()->currentProcessThread->join();
	}
	CPosTerminal::getInstance()->currentEvent = START_REQUEST;
}

SPosResponse CPosTerminal::getResponse(std::string key) {
	std::unique_lock<std::mutex> lock(requestsMutex);
	if (lastRequests.size() > 0) {
		auto result = lastRequests.find(key);
		if (result == lastRequests.end())
			throw EResponseNotFound("response not found");
		return result->second;
	} else {
		throw EResponseNotFound("no responses found");
	}
}

void CPosTerminal::startCleaningThread() {
	lastCleanup = time(nullptr);
	std::thread t(&CPosTerminal::removeOldRequests, this);
	t.detach();
}

void CPosTerminal::removeOldRequests() {
	while (true) {
		std::unique_lock<std::mutex> lock(requestsMutex);
		std::vector<std::string> keysToRemove;
		for (auto const& entry : lastRequests) {
			time_t requestTime = (time_t)atoll(entry.first.c_str());
			if (requestTime < lastCleanup) {
				keysToRemove.push_back(entry.first);
			}
		}

		for (const string& key : keysToRemove) {
			lastRequests.erase(key);
		}

		lock.unlock();

		lastCleanup = time(nullptr);
		this_thread::sleep_for(
			std::chrono::minutes(APP_CONFIG->getClearRequestAfterMinutes()));
	}
}

// correct order of call for communication with the pos
/*
1. send request approval
2. receive acknowledgement
3. receive asc amount
4. send acknowledgement
5. send amount
6. receive answer for payment (you have to wait longer until the payment is
completed) 7.done

 */