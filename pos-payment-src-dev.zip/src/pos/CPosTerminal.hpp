#ifndef CPOS_TERMINAL_HPP
#define CPOS_TERMINAL_HPP

#include <ctime>
#include <map>
#include <memory>
#include <unordered_map>

#include "comport/CComPort.hpp"
#include "utils/CLogger.h"

typedef struct {
	uint8_t msgCode;
	std::string ecrNum;
	uint8_t functionNum;
	std::string amount;
	std::string cashback;
	std::string loyaltyPrm;
	std::string loyaltySch;
	std::string installments;
	std::string currencyCode;  // default 975 bgn change before release
	std::string operatorNum;   // default 9999 change before release
} SPosRequest;

typedef struct {
	std::string message;
	std::string msgCode;
	std::string ecrNum;
	std::string functionNum;
	std::string terminalId;
	std::string bookkeepingPrd;
	std::string authCode;
	std::string retReferenceNum;
	std::string amount;
	std::string cashback;
	std::string loyaltyPrm;
	std::string cardHolderId;
	std::string reason;

} SPosResponse;

enum EPosState {
	IDLE,
	S1,
	S2,
	S3,
	S4,
	S5,
};

enum EPosEvent {
	START_REQUEST,
	AKN,
	RESPONSE,
	ABORT,
	NOT_AKN,
	TIMEOUT,
	WRONG_RESPONSE,
	UNEXPECTED_RESPONSE
};

class CPosTerminal {
	typedef void (CPosTerminal::*CPosTerminalTransition)();

   public:
	typedef struct {
		EPosState currentState;
		CPosTerminalTransition transitionFunc;
		EPosEvent event;
		EPosState endState;

	} STransition;

   private:
	std::shared_ptr<CComPort> comport;
	CLogger logger;
	EPosState currentState;
	EPosEvent currentEvent;
	std::mutex currentStateMutex;
	std::mutex threadMutex;
	std::mutex requestsMutex;
	time_t requestTimestamp;
	uint8_t functionNumber;
	std::string amount;
	SPosResponse latestResponse;
	std::unordered_map<std::string, SPosResponse> lastRequests;
	std::shared_ptr<std::thread> currentProcessThread;
	time_t lastCleanup;

   private:
	CPosTerminal();
	void addAmount(std::vector<uint8_t>& data, std::string amount);
	SPosResponse decodeResponse(const std::vector<uint8_t>& data);
	std::vector<uint8_t> buildData(const SPosRequest& request);
	uint8_t checksum(const std::vector<uint8_t>& data);
	void checkPosAvailability();
	void preparePosForNewThread();
	void transitionLoop(const std::vector<STransition>& transitions);
	void transitionState(const std::vector<STransition>& transitions);
	void sendStartRequest();
	void sendAKN();
	void sendNAK();
	void sendAKNAmount();
	void sendAKNSave();
	void sendAKNClosePeriod();
	void timeout();
	STransition findTransition(EPosState currentState, EPosEvent event);
	EPosEvent getResponseEvent(const std::vector<uint8_t> data);
	void payment4(char funcNumber, const std::string& amount, time_t timestamp);
	void closePeriodI(const time_t timestamp);
	void startCleaningThread();
	void removeOldRequests();

   public:
	static std::shared_ptr<CPosTerminal> getInstance() {
		static std::shared_ptr<CPosTerminal> instance;
		if (instance == 0) instance.reset(new CPosTerminal());
		return instance;
	}
	CPosTerminal(CPosTerminal const&) = delete;
	void operator=(CPosTerminal const&) = delete;
	CPosTerminal(std::shared_ptr<CComPort> comPort);
	~CPosTerminal(){};
	SPosResponse sendRequest(const SPosRequest& request);
	time_t startPaymentThread(char functionNumber, const std::string& amount);
	time_t startClosePeriodThread();
	EPosState getCurrentState();
	void setCurrentState(EPosState state);
	SPosResponse getResponse(std::string key);
	std::vector<STransition> payment4Transitions = {
		{IDLE, &CPosTerminal::sendStartRequest, START_REQUEST, S1},
		{IDLE, &CPosTerminal::sendStartRequest, UNEXPECTED_RESPONSE, S1},
		{IDLE, &CPosTerminal::sendStartRequest, RESPONSE, S1},
		{IDLE, &CPosTerminal::sendStartRequest, ABORT, S1},
		{S1, &CPosTerminal::timeout, TIMEOUT, IDLE},
		{S1, &CPosTerminal::sendAKNSave, ABORT, IDLE},
		{S1, nullptr, NOT_AKN, IDLE},
		{S1, nullptr, UNEXPECTED_RESPONSE, S1},
		{S1, nullptr, RESPONSE, S1},
		{S1, nullptr, AKN, S2},
		{S2, nullptr, AKN, S2},
		{S2, nullptr, UNEXPECTED_RESPONSE, S2},
		{S2, &CPosTerminal::sendAKNSave, ABORT, IDLE},
		{S2, &CPosTerminal::timeout, TIMEOUT, IDLE},
		{S2, nullptr, NOT_AKN, IDLE},
		{S2, &CPosTerminal::sendNAK, WRONG_RESPONSE, S2},
		{S2, &CPosTerminal::sendAKNAmount, RESPONSE, S4},
		{S4, nullptr, UNEXPECTED_RESPONSE, S4},
		{S4, &CPosTerminal::sendAKNAmount, NOT_AKN, S4},
		{S4, &CPosTerminal::sendAKNSave, ABORT, IDLE},
		{S4, &CPosTerminal::timeout, TIMEOUT, IDLE},
		{S4, nullptr, AKN, S5},
		{S5, nullptr, UNEXPECTED_RESPONSE, S5},
		{S5, &CPosTerminal::sendNAK, WRONG_RESPONSE, S5},
		{S5, &CPosTerminal::sendAKNSave, ABORT, IDLE},
		{S5, &CPosTerminal::timeout, TIMEOUT, IDLE},
		{S5, &CPosTerminal::sendAKNSave, RESPONSE, IDLE}};

		std::vector<STransition> closePeriodITransitions = {
		{IDLE, &CPosTerminal::sendStartRequest, START_REQUEST, S1},
		{IDLE, &CPosTerminal::sendStartRequest, UNEXPECTED_RESPONSE, S1},
		{IDLE, &CPosTerminal::sendStartRequest, RESPONSE, S1},
		{IDLE, &CPosTerminal::sendStartRequest, ABORT, S1},
		{S1, &CPosTerminal::timeout, TIMEOUT, IDLE},
		{S1, &CPosTerminal::sendAKNSave, ABORT, IDLE},
		{S1, nullptr, NOT_AKN, IDLE},
		{S1, nullptr, UNEXPECTED_RESPONSE, S1},
		{S1, nullptr, RESPONSE, S1},
		{S1, nullptr, AKN, S2},
		{S2, nullptr, AKN, S2},
		{S2, nullptr, UNEXPECTED_RESPONSE, S2},
		{S2, &CPosTerminal::sendAKNSave, ABORT, IDLE},
		{S2, &CPosTerminal::timeout, TIMEOUT, IDLE},
		{S2, nullptr, NOT_AKN, IDLE},
		{S2, &CPosTerminal::sendNAK, WRONG_RESPONSE, S2},
		{S2, &CPosTerminal::sendAKNClosePeriod, RESPONSE, S4},
		{S4, nullptr, UNEXPECTED_RESPONSE, S4},
		{S4, &CPosTerminal::sendAKNClosePeriod, NOT_AKN, S4},
		{S4, &CPosTerminal::sendAKNSave, ABORT, IDLE},
		{S4, &CPosTerminal::timeout, TIMEOUT, IDLE},
		{S4, nullptr, AKN, S5},
		{S5, nullptr, UNEXPECTED_RESPONSE, S5},
		{S5, &CPosTerminal::sendNAK, WRONG_RESPONSE, S5},
		{S5, &CPosTerminal::sendAKNSave, ABORT, IDLE},
		{S5, &CPosTerminal::timeout, TIMEOUT, IDLE},
		{S5, &CPosTerminal::sendAKNSave, RESPONSE, IDLE}};
};

#endif