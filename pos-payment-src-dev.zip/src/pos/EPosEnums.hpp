#ifndef EPOS_ENUMS
#define EPOS_ENUMS

#include <map>
#include <vector>

#define REQ_APPROVAL_1 0x31
#define ABRT_MESSAGE_2 0x32
#define ASC_AMOUNT_3 0x33
#define SEND_AMOUNT_4 0x34
#define AUTHORISATION_5 0x35
#define SEND_AMOUNT_6 0x36
#define AUTHORISATION_7 0x37
#define SEND_AMOUNT_8 0x38
#define AUTHORISATION_9 0x39
#define SEND_AMOUNT_A 0x41
#define AUTHORISATION_B 0x42
#define SEND_AMOUNT_C 0x43
#define AUTHORISATION_D 0x44
#define SEND_AMOUNT_E 0x45
#define AUTHORISATION_F 0x46
#define SEND_AMOUNT_G 0x47
#define AUTHORISATION_H 0x48
#define CLOSE_PERIOD_I 0x49
#define CLOSE_PERIOD_RESP_J 0x4A
#define SEND_AMOUNT_K 0x4B
#define AUTHORISATION_L 0x4c

#define STOP_CUSTOMER 0x17
#define TIME_OUT_CUSTOMER 0x18
#define REJECT_BORICA 0x08
#define UNRECOVERABLE_PRBLM 0x10
#define TECH_PROBLEM 0x07
#define DIFF_CURRENCY 0x0D
#define TECH_PROB_HOST 0x0F
#define PROTOCOL_PRB 0x80
#define NO_CREDIT_CARD 0x30

#define PURCHASE1 0x31
#define CASH1 0x32
#define PURCHASE_CASH1 0x33
#define PURCHASE2 0x34
#define CASH2 0x35
#define PURCHASE_CASH2 0x36
#define PURCHASE_POINTS_ACC 0x37
#define PURCHASE_CASH_POINTS_ACC 0x38
#define POINTS_ACC 0x39
#define POINTS_PAYMENT1 0x41
#define POINTS_PAYMENT2 0x42
#define END_OF_PERIOD 0x43
#define DEFFERED_PAYMENT 0x44

static const std::vector<uint8_t> funcNumber = {
	SEND_AMOUNT_4, AUTHORISATION_5, SEND_AMOUNT_6,	AUTHORISATION_7,
	SEND_AMOUNT_8, AUTHORISATION_9, SEND_AMOUNT_A,	AUTHORISATION_B,
	SEND_AMOUNT_C, AUTHORISATION_D, SEND_AMOUNT_E,	AUTHORISATION_F,
	SEND_AMOUNT_G, AUTHORISATION_H, CLOSE_PERIOD_I, CLOSE_PERIOD_RESP_J,
	SEND_AMOUNT_K, AUTHORISATION_L};

static const std::vector<uint8_t> terminalId = {
	AUTHORISATION_5, AUTHORISATION_7,	  AUTHORISATION_9,
	AUTHORISATION_B, AUTHORISATION_D,	  AUTHORISATION_F,
	AUTHORISATION_H, CLOSE_PERIOD_RESP_J, AUTHORISATION_L};

// same as terminalId
static const std::vector<uint8_t> bookkeepingPeriod = {};

// same as terminalId
static const std::vector<uint8_t> authorisationCode = {};

// same as terminalId
static const std::vector<uint8_t> retrievalReferenceNumber = {};

static const std::vector<uint8_t> sendAmount = {
	SEND_AMOUNT_4, AUTHORISATION_5, SEND_AMOUNT_6, AUTHORISATION_7,
	SEND_AMOUNT_8, AUTHORISATION_9, SEND_AMOUNT_A, AUTHORISATION_B,
	SEND_AMOUNT_G, AUTHORISATION_H, SEND_AMOUNT_K, AUTHORISATION_L};

static const std::vector<uint8_t> cashback = {SEND_AMOUNT_6, AUTHORISATION_7,
											  SEND_AMOUNT_A, AUTHORISATION_B};

static const std::vector<uint8_t> loyaltyPremium = {
	SEND_AMOUNT_8, AUTHORISATION_9, SEND_AMOUNT_A, AUTHORISATION_B,
	SEND_AMOUNT_C, AUTHORISATION_D, SEND_AMOUNT_E, AUTHORISATION_F};

static const std::vector<uint8_t> loyaltyScheme = {
	SEND_AMOUNT_8, SEND_AMOUNT_A, SEND_AMOUNT_C, SEND_AMOUNT_E, SEND_AMOUNT_G};

static const std::vector<uint8_t> installments = {SEND_AMOUNT_K};

static const std::vector<uint8_t> cardholderId = {
	AUTHORISATION_5, AUTHORISATION_7, AUTHORISATION_9, AUTHORISATION_B,
	AUTHORISATION_D, AUTHORISATION_F, AUTHORISATION_H, AUTHORISATION_L};

static const std::vector<uint8_t> currencyCode = {
	SEND_AMOUNT_4, SEND_AMOUNT_6, SEND_AMOUNT_8, SEND_AMOUNT_A,
	SEND_AMOUNT_E, SEND_AMOUNT_G, SEND_AMOUNT_K};

static const std::vector<uint8_t> operatorNumber = {
	SEND_AMOUNT_4, SEND_AMOUNT_6, SEND_AMOUNT_8,  SEND_AMOUNT_A, SEND_AMOUNT_C,
	SEND_AMOUNT_E, SEND_AMOUNT_G, CLOSE_PERIOD_I, SEND_AMOUNT_K};

static const std::vector<uint8_t> reason = {ABRT_MESSAGE_2};

static const std::map<char, std::string> functionCodes = {
	{0x31, "Purchase"},
	{0x32, "Cash"},
	{0x33, "Purchase + Cash"},
	{0x34, "Purchase"},
	{0x35, "Cash"},
	{0x36, "Purchase + Cash"},
	{0x37, "Purchase + Points accumulation"},
	{0x38, "Purchase + Cash + Points accumulation"},
	{0x39, "Points accumulation"},
	{0x41, "Payment with points"},
	{0x42, "Payment with points"},
	{0x43, "End of period"},
	{0x44, "Deferred payment"}};

static const std::map<char, std::string> abortCodes = {
	{0x17, "Stop customer"},
	{0x18, "Time-out customer"},
	{0x08, "Rejection by BORICA"},
	{0x10, "Unrecoverable problem"},
	{0x07, "Technical problem"},
	{0x0D, "Different currency"},
	{0x0F, "Technical problem Host"},
	{0x80, "Protocol problem from ECR detected"},
	{0x30, "No credit card"}};

static const std::map<char, std::string> messageCodes = {
	{0x31, "Request approval"},
	{0x32, "Abort message"},
	{0x33, "Asc amount"},
	{0x34, "Send amount"},
	{0x35, "Authorisation"},
	{0x36, "Send amount"},
	{0x37, "Authorisation"},
	{0x38, "Send amount"},
	{0x39, "Authorisation"},
	{0x41, "Send amount"},
	{0x42, "Authorisation"},
	{0x43, "Send amount"},
	{0x44, "Authorisation"},
	{0x45, "Send amount"},
	{0x46, "Authorisation"},
	{0x47, "Send amount"},
	{0x48, "Authorisation"},
	{0x49, "Close period"},
	{0x4A, "Close period response"},
	{0x4B, "Send amount"},
	{0x4C, "Authorisation"}};

static const std::vector<uint8_t> START_COMMUNICATION = {0x02, 0x31, 0x30,
														 0x33, 0x03, 0x31};
static const uint8_t ACKNOWLEDGE = 0x06;
static const uint8_t STX = 0x02;
static const uint8_t ETX = 0x03;
static const uint8_t NAK = 0x15;
static const uint8_t ABRT = 0x32;
static const uint8_t TMT = 0x04;

#endif