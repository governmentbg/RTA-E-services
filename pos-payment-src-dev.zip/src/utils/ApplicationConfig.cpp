#include "utils/ApplicationConfig.hpp"

#include <iostream>

std::string ApplicationConfig::configPath;

ApplicationConfig::ApplicationConfig(Json::Value value) {
	jsonValue = value;
}

const std::shared_ptr<ApplicationConfig> ApplicationConfig::getInstance() {
	static std::shared_ptr<ApplicationConfig> instance;
	if(instance == 0) {
		if(configPath.size() == 0) {
			throw std::runtime_error("No config file provided.");
		}
		std::ifstream ifs(configPath);
		Json::Reader reader;
		Json::Value value;
		reader.parse(ifs, value);

		instance.reset(new ApplicationConfig(value));
	}

	return instance;
}

