#ifndef APPLICATION_CONFIG
#define APPLICATION_CONFIG

#include "jsoncpp/json/json.h"

#include <fstream>
#include <memory>
#include <stdexcept>

using namespace std;

#define CONCAT_NAMES(a, b) a##b
#define ADD_SETTING(type, jsonGetter, getterName)                              \
private:                                                                       \
	bool CONCAT_NAMES(getterName, _init) = false;                              \
	type CONCAT_NAMES(getterName, _value);                                     \
                                                                               \
public:                                                                        \
	type getterName() {                                                        \
		if (!CONCAT_NAMES(getterName, _init)) {                                \
			CONCAT_NAMES(getterName, _init) = true;                            \
			string key = #getterName;                                          \
			key = key.substr(3);                                               \
			key[0] = tolower(key[0]);                                          \
                                                                               \
			if (jsonValue[key].empty()) {                                      \
				throw invalid_argument("Missing setting");                     \
			}                                                                  \
			CONCAT_NAMES(getterName, _value) = jsonValue[key].jsonGetter();    \
		}                                                                      \
                                                                               \
		return CONCAT_NAMES(getterName, _value);                               \
	}

#define APP_CONFIG ApplicationConfig::getInstance()

class ApplicationConfig {
public:
	const static std::shared_ptr<ApplicationConfig> getInstance();
	static void setConfigPath(const string& configPath) {
		ApplicationConfig::configPath = configPath;
	}

private:
	ApplicationConfig();
	ApplicationConfig(Json::Value value);

private:
	Json::Value jsonValue;
	static string configPath;

	ADD_SETTING(string, asString, getLogLevel);
	ADD_SETTING(string, asString, getPort);
	ADD_SETTING(string, asString, getDocumentRoot);
	ADD_SETTING(string, asString, getRequestAmountUri);
	ADD_SETTING(string, asString, getClosePeriodUri);
	ADD_SETTING(string, asString, getCurrencyCode);
	ADD_SETTING(string, asString, getOperatorNumber);
	ADD_SETTING(string, asString, getEcr);
	ADD_SETTING(string, asString, getQueryParamRequestId);
	ADD_SETTING(string, asString, getQueryParamFuncNumber);
	ADD_SETTING(string, asString, getQueryParamAmount);
	ADD_SETTING(int, asInt, getMaxWaitTime);
	ADD_SETTING(string, asString, getDeviceName);
	ADD_SETTING(int, asInt, getBaudRate);
	ADD_SETTING(int, asInt, getClearRequestAfterMinutes);
};

#endif