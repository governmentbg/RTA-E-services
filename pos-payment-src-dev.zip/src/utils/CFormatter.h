#ifndef CFORMATTER_H
#define CFORMATTER_H

#include <sstream>
#include <string>

class CFormatter
{
public:
    CFormatter() {}
    ~CFormatter() {}

    template <typename Type>
    CFormatter & operator << (const Type & value)
    {
        stream_ << value;
        return *this;
    }

    operator std::string () const   { return stream_.str(); }

private:
    std::stringstream stream_;

    CFormatter(const CFormatter &);
    CFormatter & operator = (CFormatter &);
};

#endif
