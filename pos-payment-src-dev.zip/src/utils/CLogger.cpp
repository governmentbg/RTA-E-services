#include "utils/CLogger.h"

mutex CLogger::loggerMutex;
map<thread::id, shared_ptr<stringstream>> CLogger::streams;
ELogLevel CLogger::maxLevel = ELogLevel::INFO;

// ------------------------------------------------------------------------
CLogger::CLogger()
    : loggerStream(new CLoggerStream(*this)) {
    linePrefix = "";
}

// ------------------------------------------------------------------------
CLogger::CLogger(const string& prefix)
    : loggerStream(new CLoggerStream(*this)) {
    linePrefix = prefix;
}

// ------------------------------------------------------------------------
CLogger::~CLogger() {}

// ------------------------------------------------------------------------