#ifndef CLogger_H
#define CLogger_H

#include <mutex>
#include <sstream>
#include <string>
#include <iostream>
#include <memory>
#include <map>
#include <thread>
#if defined(ERROR)
#	undef ERROR
#endif
using namespace std;

#define LOG_DEBUG logger(ELogLevel::DEBUG)
#define LOG_ERROR logger(ELogLevel::ERROR)
#define LOG_INFO logger(ELogLevel::INFO)
#define LOG_WARN logger(ELogLevel::WARN)
#define LOG_TRACE logger(ELogLevel::TRACE)

typedef enum { SILENT = 0, ERROR, INFO, WARN, DEBUG, TRACE } ELogLevel;

class CLoggerStream;

class CLogger {
private:
	static mutex loggerMutex;
	static map<thread::id, std::shared_ptr<stringstream>> streams;

	string linePrefix = "";
	ELogLevel currentLevel = ELogLevel::WARN;
	static ELogLevel maxLevel;
	std::shared_ptr<CLoggerStream> loggerStream;

public:
	CLogger();
	CLogger(const string& prefix);
	virtual ~CLogger();

	static void setMaxLogLevel(ELogLevel level) {
		unique_lock<mutex> lock(loggerMutex);
		maxLevel = level;
	}

	// ------------------------------------------------------------------------
	CLoggerStream& operator()(ELogLevel level) {
		unique_lock<mutex> lock(loggerMutex);
		if(level == ELogLevel::SILENT) throw runtime_error("invalid log level");

		currentLevel = level;
		return *loggerStream;
	}

	// ------------------------------------------------------------------------
	template <typename Type>
	CLogger& print(const Type& value) {
		std::shared_ptr<stringstream> stream;
		{
			unique_lock<mutex> lock(loggerMutex);
			if(currentLevel > maxLevel) return *this;

			if(streams.find(this_thread::get_id()) == streams.end()) {
				streams[this_thread::get_id()] =
					std::shared_ptr<stringstream>(new stringstream(""));
			}
			stream = streams[this_thread::get_id()];
		}

		(*stream) << value;

		do {
			size_t newLinePos = (*stream).str().find('\n');

			if(newLinePos != string::npos) {
				string toPrint = (*stream).str().substr(0, newLinePos);

				if((*stream).str().size() > newLinePos) {
					string remaining = (*stream).str().substr(
						newLinePos + 1,
						(*stream).str().size() - (newLinePos + 1));
					(*stream).str(remaining);
				}

				{
					unique_lock<mutex> lock(loggerMutex);
					cerr << linePrefix << toPrint << endl;
				}
			} else {
				break;
			}
		} while(true);

		return *this;
	}

private:
	CLogger(const CLogger&);
	CLogger& operator=(CLogger&);
};

// ------------------------------------------------------------------------
class CLoggerStream {
public:
	CLoggerStream(CLogger& logger)
		: logger(logger) {};
	virtual ~CLoggerStream() {};

	// ------------------------------------------------------------------------
	template <typename Type>
	CLoggerStream& operator<<(const Type& value) {
		logger.print(value);
		return *this;
	}

private:
	CLogger& logger;

	CLoggerStream(const CLogger&);
	CLoggerStream& operator=(CLogger&);
};

// ------------------------------------------------------------------------

#endif
