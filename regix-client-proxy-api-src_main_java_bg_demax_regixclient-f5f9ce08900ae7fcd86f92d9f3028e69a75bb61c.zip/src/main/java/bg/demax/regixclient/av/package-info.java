/**
 * @author zivanova
 * 
 * Package for DTOs related to services in Registry Agency "Агенция по вписванията"
 * 
 * TR: Търговски регистър
 * IR: Имотен регистър
 * 
 * More info at: http://regixaisweb.egov.bg/RegiXInfo/#0
 *
 */
package bg.demax.regixclient.av;