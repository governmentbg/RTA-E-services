package bg.demax.regixclient.av.tr.actualstatev3;

import bg.demax.regixclient.mvr.bds.BaseRequestDto;

public class ActualStateRequestDto extends BaseRequestDto {
	
    protected String uic;
    protected String fieldList;

    public String getUIC() {
        return uic;
    }

    public void setUIC(String value) {
        this.uic = value;
    }

    public String getFieldList() {
        return fieldList;
    }

    public void setFieldList(String value) {
        this.fieldList = value;
    }
}
