package bg.demax.regixclient.av.tr.actualstatev3;

import java.time.LocalDate;

public class ActualStateResponseDto {

    protected DeedTypeDto deed;
    protected LocalDate dataValidForDate;
    protected Boolean dataFound;

    public DeedTypeDto getDeed() {
        return deed;
    }

    public void setDeed(DeedTypeDto value) {
        this.deed = value;
    }

    public LocalDate getDataValidForDate() {
        return dataValidForDate;
    }

    public void setDataValidForDate(LocalDate value) {
        this.dataValidForDate = value;
    }

    public Boolean isDataFound() {
        return dataFound;
    }

    public void setDataFound(Boolean value) {
        this.dataFound = value;
    }
}
