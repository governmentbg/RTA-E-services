package bg.demax.regixclient.av.tr.actualstatev3;

public enum DeedStatusTypeDto {


    /**
     * 	Нова
     */
    N,

    /**
     * 	Пререгистрирана фирма по Булстат
     */
    E,

    /**
     * 	Нова партида затворена
     */
    C,

    /**
     * 	Пререгистрирана фирма по Булстат затворена
     */
    L;

    public String value() {
        return name();
    }

    public static DeedStatusTypeDto fromValue(String v) {
        return valueOf(v);
    }
}