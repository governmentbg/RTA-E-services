package bg.demax.regixclient.av.tr.actualstatev3;

import java.util.List;

public class DeedTypeDto {

    protected DeedStatusTypeDto deedStatus;
    protected String companyName;
    protected String guid;
    protected String uic;
    protected LegalFormTypeDto legalForm;
    protected String caseNo;
    protected String caseYear;
    protected String courtNo;
    protected LiquidationOrInsolvencyDto liquidationOrInsolvency;
    protected List<SubdeedDto> subdeeds;

    public DeedStatusTypeDto getDeedStatus() {
		return deedStatus;
	}

	public void setDeedStatus(DeedStatusTypeDto deedStatus) {
		this.deedStatus = deedStatus;
	}

	public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String value) {
        this.companyName = value;
    }

    public String getGUID() {
        return guid;
    }

    public void setGUID(String value) {
        this.guid = value;
    }

    public String getUIC() {
        return uic;
    }

    public void setUIC(String value) {
        this.uic = value;
    }

    public LegalFormTypeDto getLegalForm() {
        return legalForm;
    }

    public void setLegalForm(LegalFormTypeDto value) {
        this.legalForm = value;
    }

    public String getCaseNo() {
        return caseNo;
    }

    public void setCaseNo(String value) {
        this.caseNo = value;
    }
     
    public String getCaseYear() {
        return caseYear;
    }

    public void setCaseYear(String value) {
        this.caseYear = value;
    }

    public String getCourtNo() {
        return courtNo;
    }

    public void setCourtNo(String value) {
        this.courtNo = value;
    }

    public LiquidationOrInsolvencyDto getLiquidationOrInsolvency() {
        return liquidationOrInsolvency;
    }

    public void setLiquidationOrInsolvency(LiquidationOrInsolvencyDto value) {
        this.liquidationOrInsolvency = value;
    }

    public List<SubdeedDto> getSubdeeds() {
        return subdeeds;
    }

    public void setSubdeeds(List<SubdeedDto> value) {
        this.subdeeds = value;
    }
}
