package bg.demax.regixclient.av.tr.actualstatev3;

public class FieldDto {

    protected Integer groupId;
    protected String groupName;
    protected Integer sectionId;
    protected String sectionName;
    protected String mainFieldIdent;
    protected String mainFieldCode;
    protected String mainFieldName;

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer value) {
        this.groupId = value;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String value) {
        this.groupName = value;
    }

    public Integer getSectionId() {
        return sectionId;
    }

    public void setSectionId(Integer value) {
        this.sectionId = value;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String value) {
        this.sectionName = value;
    }

    public String getMainFieldIdent() {
        return mainFieldIdent;
    }

    public void setMainFieldIdent(String value) {
        this.mainFieldIdent = value;
    }

    public String getMainFieldCode() {
        return mainFieldCode;
    }

    public void setMainFieldCode(String value) {
        this.mainFieldCode = value;
    }

    public String getMainFieldName() {
        return mainFieldName;
    }

    public void setMainFieldName(String value) {
        this.mainFieldName = value;
    }
}
