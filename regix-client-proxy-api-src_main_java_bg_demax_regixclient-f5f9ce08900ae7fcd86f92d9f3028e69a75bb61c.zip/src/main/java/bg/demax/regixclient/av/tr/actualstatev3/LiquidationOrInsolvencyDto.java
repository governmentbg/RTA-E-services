package bg.demax.regixclient.av.tr.actualstatev3;

public enum LiquidationOrInsolvencyDto {


    /**
     * 	Ликвидация
     */
    LIQUIDATION("Liquidation"),

    /**
     * 	Несъстоятелност
     */
    INSOLVENCY("Insolvency"),

    /**
     * 	В несъстоятелност (на II инстанция)
     */
    INSOLVENCY_SEC_INS("InsolvencySecIns"),

    /**
     * 	В несъстоятелност (на III инстанция)
     */
    INSOLVENCY_THIRD_INS("InsolvencyThirdIns");
    private final String value;

    LiquidationOrInsolvencyDto(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static LiquidationOrInsolvencyDto fromValue(String v) {
        for (LiquidationOrInsolvencyDto c: LiquidationOrInsolvencyDto.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
}
