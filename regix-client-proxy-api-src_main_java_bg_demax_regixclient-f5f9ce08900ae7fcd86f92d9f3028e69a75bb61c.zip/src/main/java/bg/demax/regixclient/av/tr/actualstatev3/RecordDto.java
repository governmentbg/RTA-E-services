package bg.demax.regixclient.av.tr.actualstatev3;

import java.time.LocalDate;

public class RecordDto {

    protected String recordData;
    protected int recordId;
    protected int incomingId;
    protected String fieldIdent;
    protected FieldDto mainField;
    protected String fieldEntryNumber;
    protected LocalDate fieldActionDate;

    public String getRecordData() {
        return recordData;
    }

    public void setRecordData(String value) {
        this.recordData = value;
    }

    public int getRecordId() {
        return recordId;
    }

    public void setRecordId(int value) {
        this.recordId = value;
    }

    public int getIncomingId() {
        return incomingId;
    }

    public void setIncomingId(int value) {
        this.incomingId = value;
    }

    public String getFieldIdent() {
        return fieldIdent;
    }

    public void setFieldIdent(String value) {
        this.fieldIdent = value;
    }

    public FieldDto getMainField() {
        return mainField;
    }

    public void setMainField(FieldDto value) {
        this.mainField = value;
    }

    public String getFieldEntryNumber() {
        return fieldEntryNumber;
    }

    public void setFieldEntryNumber(String value) {
        this.fieldEntryNumber = value;
    }

    public LocalDate getFieldActionDate() {
        return fieldActionDate;
    }

    public void setFieldActionDate(LocalDate value) {
        this.fieldActionDate = value;
    }
}
