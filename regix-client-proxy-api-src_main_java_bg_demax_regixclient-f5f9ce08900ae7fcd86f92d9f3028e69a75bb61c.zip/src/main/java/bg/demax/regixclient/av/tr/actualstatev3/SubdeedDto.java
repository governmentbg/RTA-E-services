package bg.demax.regixclient.av.tr.actualstatev3;

import java.util.List;

public class SubdeedDto {

    protected List<RecordDto> records;
    protected String subUIC;
    protected String subUICType;
    protected SubdeedStatusTypeDto subdeedStatus;
    protected String subUICName;

    public List<RecordDto> getRecords() {
        return records;
    }

    public void setRecords(List<RecordDto> value) {
        this.records = value;
    }

    public String getSubUIC() {
        return subUIC;
    }

    public void setSubUIC(String value) {
        this.subUIC = value;
    }

    public String getSubUICType() {
        return subUICType;
    }

    public void setSubUICType(String value) {
        this.subUICType = value;
    }

    public SubdeedStatusTypeDto getSubdeedStatus() {
        return subdeedStatus;
    }

    public void setSubdeedStatus(SubdeedStatusTypeDto value) {
        this.subdeedStatus = value;
    }

    public String getSubUICName() {
        return subUICName;
    }

    public void setSubUICName(String value) {
        this.subUICName = value;
    }
}
