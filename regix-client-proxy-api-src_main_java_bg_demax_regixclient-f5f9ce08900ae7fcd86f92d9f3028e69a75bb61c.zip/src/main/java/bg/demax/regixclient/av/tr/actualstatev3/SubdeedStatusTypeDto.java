package bg.demax.regixclient.av.tr.actualstatev3;

public enum SubdeedStatusTypeDto {

    /**
     * 	Active
     */
    A,

    /**
     * 	Closed
     */
    C;

    public String value() {
        return name();
    }

    public static SubdeedStatusTypeDto fromValue(String v) {
        return valueOf(v);
    }
}
