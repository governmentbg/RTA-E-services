package bg.demax.regixclient.av.tr.uicvalidation;

public class LegalFormTypeDto {

    private String legalFormAbbr;

    private String legalFormName;

	public String getLegalFormAbbr() {
		return legalFormAbbr;
	}

	public void setLegalFormAbbr(String legalFormAbbr) {
		this.legalFormAbbr = legalFormAbbr;
	}

	public String getLegalFormName() {
		return legalFormName;
	}

	public void setLegalFormName(String legalFormName) {
		this.legalFormName = legalFormName;
	}    
    
}
