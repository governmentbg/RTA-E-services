package bg.demax.regixclient.av.tr.uicvalidation;

public enum StatusTypeDto {

	НОВА_ПАРТИДА("\u041d\u043e\u0432\u0430 \u043f\u0430\u0440\u0442\u0438\u0434\u0430"),
	ПРЕРЕГИСТРИРАНА_ПАРТИДА(
			"\u041f\u0440\u0435\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0430\u043d\u0430 \u043f\u0430\u0440\u0442\u0438\u0434\u0430"),
	НОВА_ЗАКРИТА_ПАРТИДА(
			"\u041d\u043e\u0432\u0430 \u0437\u0430\u043a\u0440\u0438\u0442\u0430 \u043f\u0430\u0440\u0442\u0438\u0434\u0430"),
	ПРЕРЕГИСТРИРАНА_ЗАКРИТА_ПАРТИДА(
			"\u041f\u0440\u0435\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0430\u043d\u0430 \u0437\u0430\u043a\u0440\u0438\u0442\u0430 \u043f\u0430\u0440\u0442\u0438\u0434\u0430");
	private final String value;

	StatusTypeDto(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static StatusTypeDto fromValue(String v) {
		for (StatusTypeDto c : StatusTypeDto.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v);
	}
}
