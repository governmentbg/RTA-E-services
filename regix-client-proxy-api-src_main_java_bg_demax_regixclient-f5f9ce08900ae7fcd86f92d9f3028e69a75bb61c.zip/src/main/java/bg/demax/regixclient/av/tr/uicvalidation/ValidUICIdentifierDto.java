package bg.demax.regixclient.av.tr.uicvalidation;

import javax.validation.constraints.NotBlank;

import bg.demax.regixclient.mvr.bds.BaseRequestDto;

public class ValidUICIdentifierDto extends BaseRequestDto {

	@NotBlank
	private String uic;

	public String getUic() {
		return uic;
	}

	public void setUic(String uic) {
		this.uic = uic;
	}	
	
}
