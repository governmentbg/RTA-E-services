package bg.demax.regixclient.av.tr.uicvalidation;

import java.time.LocalDate;

public class ValidUICInfoDto {

	private StatusTypeDto status;

	private String uic;

	private String company;

	private LegalFormTypeDto legalForm;

	private LocalDate dataValidForDate;

	public StatusTypeDto getStatus() {
		return status;
	}

	public void setStatus(StatusTypeDto status) {
		this.status = status;
	}

	public String getUic() {
		return uic;
	}

	public void setUic(String uic) {
		this.uic = uic;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public LegalFormTypeDto getLegalForm() {
		return legalForm;
	}

	public void setLegalForm(LegalFormTypeDto legalForm) {
		this.legalForm = legalForm;
	}

	public LocalDate getDataValidForDate() {
		return dataValidForDate;
	}

	public void setDataValidForDate(LocalDate dataValidForDate) {
		this.dataValidForDate = dataValidForDate;
	}	
	
}
