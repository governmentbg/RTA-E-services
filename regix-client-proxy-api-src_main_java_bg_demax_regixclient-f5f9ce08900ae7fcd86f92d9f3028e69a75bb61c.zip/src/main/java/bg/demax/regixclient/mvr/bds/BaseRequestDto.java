package bg.demax.regixclient.mvr.bds;

import javax.validation.constraints.NotNull;

public class BaseRequestDto {
    @NotNull
    private CallContextDto callContext;

    public CallContextDto getCallContext() {
        return callContext;
    }

    public void setCallContext(CallContextDto callContext) {
        this.callContext = callContext;
    }

}
