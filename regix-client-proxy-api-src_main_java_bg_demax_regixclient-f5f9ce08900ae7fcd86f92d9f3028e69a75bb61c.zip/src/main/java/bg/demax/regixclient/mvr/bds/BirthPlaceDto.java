package bg.demax.regixclient.mvr.bds;

public class BirthPlaceDto {


    private String countryCode;
    private String countryName;
    private String countryNameLatin;
    private String territorialUnitName;
    private String districtName;
    private String municipalityName;

    public String getCountryCode() {
        return this.countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryName() {
        return this.countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCountryNameLatin() {
        return this.countryNameLatin;
    }

    public void setCountryNameLatin(String countryNameLatin) {
        this.countryNameLatin = countryNameLatin;
    }

    public String getTerritorialUnitName() {
        return this.territorialUnitName;
    }

    public void setTerritorialUnitName(String territorialUnitName) {
        this.territorialUnitName = territorialUnitName;
    }

    public String getDistrictName() {
        return this.districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public String getMunicipalityName() {
        return this.municipalityName;
    }

    public void setMunicipalityName(String municipalityName) {
        this.municipalityName = municipalityName;
    }
    

}
