package bg.demax.regixclient.mvr.bds;

import javax.validation.constraints.NotBlank;

public class CallContextDto {

    @NotBlank
    private String serviceURI;

    @NotBlank
    private String serviceType;

    @NotBlank
    private String employeeIdentifier;

    @NotBlank
    private String employeeNames;

    @NotBlank
    private String employeeAditionalIdentifier;

    @NotBlank
    private String employeePosition;

    @NotBlank
    private String responsiblePersonIdentifier;

    @NotBlank
    private String administrationOId;

    @NotBlank
    private String administrationName;

    @NotBlank
    private String lawReason;

    private String remark;

    /**
     * @return String return the serviceURI
     */
    public String getServiceURI() {
        return serviceURI;
    }

    /**
     * @param serviceURI the serviceURI to set
     */
    public void setServiceURI(String serviceURI) {
        this.serviceURI = serviceURI;
    }

    /**
     * @return String return the serviceType
     */
    public String getServiceType() {
        return serviceType;
    }

    /**
     * @param serviceType the serviceType to set
     */
    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    /**
     * @return String return the employeeIdentifier
     */
    public String getEmployeeIdentifier() {
        return employeeIdentifier;
    }

    /**
     * @param employeeIdentifier the employeeIdentifier to set
     */
    public void setEmployeeIdentifier(String employeeIdentifier) {
        this.employeeIdentifier = employeeIdentifier;
    }

    /**
     * @return String return the employeeNames
     */
    public String getEmployeeNames() {
        return employeeNames;
    }

    /**
     * @param employeeNames the employeeNames to set
     */
    public void setEmployeeNames(String employeeNames) {
        this.employeeNames = employeeNames;
    }

    /**
     * @return String return the employeeAditionalIdentifier
     */
    public String getEmployeeAditionalIdentifier() {
        return employeeAditionalIdentifier;
    }

    /**
     * @param employeeAditionalIdentifier the employeeAditionalIdentifier to set
     */
    public void setEmployeeAditionalIdentifier(String employeeAditionalIdentifier) {
        this.employeeAditionalIdentifier = employeeAditionalIdentifier;
    }

    /**
     * @return String return the employeePosition
     */
    public String getEmployeePosition() {
        return employeePosition;
    }

    /**
     * @param employeePosition the employeePosition to set
     */
    public void setEmployeePosition(String employeePosition) {
        this.employeePosition = employeePosition;
    }

    /**
     * @return String return the responsiblePersonIdentifier
     */
    public String getResponsiblePersonIdentifier() {
        return responsiblePersonIdentifier;
    }

    /**
     * @param responsiblePersonIdentifier the responsiblePersonIdentifier to set
     */
    public void setResponsiblePersonIdentifier(String responsiblePersonIdentifier) {
        this.responsiblePersonIdentifier = responsiblePersonIdentifier;
    }

    /**
     * @return String return the administrationOId
     */
    public String getAdministrationOId() {
        return administrationOId;
    }

    /**
     * @param administrationOId the administrationOId to set
     */
    public void setAdministrationOId(String administrationOId) {
        this.administrationOId = administrationOId;
    }

    /**
     * @return String return the administrationName
     */
    public String getAdministrationName() {
        return administrationName;
    }

    /**
     * @param administrationName the administrationName to set
     */
    public void setAdministrationName(String administrationName) {
        this.administrationName = administrationName;
    }

    /**
     * @return String return the lawReason
     */
    public String getLawReason() {
        return lawReason;
    }

    /**
     * @param lawReason the lawReason to set
     */
    public void setLawReason(String lawReason) {
        this.lawReason = lawReason;
    }

    /**
     * @return String return the remark
     */
    public String getRemark() {
        return remark;
    }

    /**
     * @param remark the remark to set
     */
    public void setRemark(String remark) {
        this.remark = remark;
    }

}
