package bg.demax.regixclient.mvr.bds;

import java.time.LocalDate;
import java.util.List;

public class DLCategoryDto {

	protected String category;
	protected LocalDate dateCategory;
	protected LocalDate endDateCategory;
	protected List<String> restrictions;

	public String getCategory() {
		return category;
	}

	public void setCategory(String value) {
		this.category = value;
	}

	public LocalDate getDateCategory() {
		return dateCategory;
	}

	public void setDateCategory(LocalDate value) {
		this.dateCategory = value;
	}

	public LocalDate getEndDateCategory() {
		return endDateCategory;
	}

	public void setEndDateCategory(LocalDate value) {
		this.endDateCategory = value;
	}

	public List<String> getRestrictions() {
		return restrictions;
	}

	public void setRestrictions(List<String> restrictions) {
		this.restrictions = restrictions;
	}
}
