package bg.demax.regixclient.mvr.bds;

import java.time.LocalDate;

public class ForeignCitizenTypeDto {

    
    private String pin;
    
    private String pn;
   
    private PersonNamesDto names;
    
    private NationalityListDto nationalityList;
    
    private GenderTypeDto gender;
    
    private LocalDate birthDate;
    

    public String getPin() {
        return this.pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getPn() {
        return this.pn;
    }

    public void setPn(String pn) {
        this.pn = pn;
    }

    public PersonNamesDto getNames() {
        return this.names;
    }

    public void setNames(PersonNamesDto names) {
        this.names = names;
    }

    public NationalityListDto getNationalityList() {
        return this.nationalityList;
    }

    public void setNationalityList(NationalityListDto nationalityList) {
        this.nationalityList = nationalityList;
    }

    public GenderTypeDto getGender() {
        return this.gender;
    }

    public void setGender(GenderTypeDto gender) {
        this.gender = gender;
    }

    public LocalDate getBirthDate() {
        return this.birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }


}
