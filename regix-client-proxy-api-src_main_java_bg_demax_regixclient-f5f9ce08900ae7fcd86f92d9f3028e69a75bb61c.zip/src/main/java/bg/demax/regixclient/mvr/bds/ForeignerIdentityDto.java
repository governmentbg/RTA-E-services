package bg.demax.regixclient.mvr.bds;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class ForeignerIdentityDto extends BaseRequestDto {

    @NotBlank
    private String identifier;

    @NotNull
    private IdentifierTypeDto identifierType;

    /**
     * @return String return the identifier
     */
    public String getIdentifier() {
        return identifier;
    }

    /**
     * @param identifier the identifier to set
     */
    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    /**
     * @return IdentifierType return the identifierType
     */
    public IdentifierTypeDto getIdentifierType() {
        return identifierType;
    }

    /**
     * @param identifierType the identifierType to set
     */
    public void setIdentifierType(IdentifierTypeDto identifierType) {
        this.identifierType = identifierType;
    }

}
