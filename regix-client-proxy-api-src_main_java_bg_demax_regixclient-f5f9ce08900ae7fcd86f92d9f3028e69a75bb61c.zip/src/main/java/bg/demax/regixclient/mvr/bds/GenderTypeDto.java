package bg.demax.regixclient.mvr.bds;

public class GenderTypeDto {
    

    private String genderCode;
    private String cyrillic;
    private String latin;


    public String getGenderCode() {
        return this.genderCode;
    }

    public void setGenderCode(String genderCode) {
        this.genderCode = genderCode;
    }

    public String getCyrillic() {
        return this.cyrillic;
    }

    public void setCyrillic(String cyrillic) {
        this.cyrillic = cyrillic;
    }

    public String getLatin() {
        return this.latin;
    }

    public void setLatin(String latin) {
        this.latin = latin;
    }


}
