package bg.demax.regixclient.mvr.bds;

public enum IdentifierTypeDto {

    LN_CH("LNCh"), EGN("EGN");
    private final String value;

    IdentifierTypeDto(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static IdentifierTypeDto fromValue(String v) {
        for (IdentifierTypeDto c : IdentifierTypeDto.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}