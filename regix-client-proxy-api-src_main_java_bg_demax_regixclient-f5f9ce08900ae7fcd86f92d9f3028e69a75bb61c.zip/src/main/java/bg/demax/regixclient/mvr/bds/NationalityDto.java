package bg.demax.regixclient.mvr.bds;

public class NationalityDto {
    

    private String nationalityCode;
    private String nationalityName;
    private String nationalityNameLatin;


    public String getNationalityCode() {
        return this.nationalityCode;
    }

    public void setNationalityCode(String nationalityCode) {
        this.nationalityCode = nationalityCode;
    }

    public String getNationalityName() {
        return this.nationalityName;
    }

    public void setNationalityName(String nationalityName) {
        this.nationalityName = nationalityName;
    }

    public String getNationalityNameLatin() {
        return this.nationalityNameLatin;
    }

    public void setNationalityNameLatin(String nationalityNameLatin) {
        this.nationalityNameLatin = nationalityNameLatin;
    }
    
}
