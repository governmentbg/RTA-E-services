package bg.demax.regixclient.mvr.bds;

import java.util.List;

public class NationalityListDto {
    

    protected List<NationalityDto> nationality;
    

    public List<NationalityDto> getNationality() {
        return this.nationality;
    }

    public void setNationality(List<NationalityDto> nationality) {
        this.nationality = nationality;
    }


}
