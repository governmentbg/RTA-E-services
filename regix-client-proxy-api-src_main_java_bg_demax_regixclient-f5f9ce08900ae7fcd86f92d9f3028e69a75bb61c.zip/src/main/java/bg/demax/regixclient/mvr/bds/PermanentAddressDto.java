package bg.demax.regixclient.mvr.bds;

public class PermanentAddressDto {

    
    private String districtName;
    private String districtNameLatin;
    private String municipalityName;
    private String municipalityNameLatin;
    private String settlementCode;
    private String settlementName;  
    private String settlementNameLatin; 
    private String locationCode;   
    private String locationName;   
    private String locationNameLatin;  
    private String buildingNumber;  
    private String entrance;   
    private String floor;
    private String apartment;

    public String getDistrictName() {
        return this.districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public String getDistrictNameLatin() {
        return this.districtNameLatin;
    }

    public void setDistrictNameLatin(String districtNameLatin) {
        this.districtNameLatin = districtNameLatin;
    }

    public String getMunicipalityName() {
        return this.municipalityName;
    }

    public void setMunicipalityName(String municipalityName) {
        this.municipalityName = municipalityName;
    }

    public String getMunicipalityNameLatin() {
        return this.municipalityNameLatin;
    }

    public void setMunicipalityNameLatin(String municipalityNameLatin) {
        this.municipalityNameLatin = municipalityNameLatin;
    }

    public String getSettlementCode() {
        return this.settlementCode;
    }

    public void setSettlementCode(String settlementCode) {
        this.settlementCode = settlementCode;
    }

    public String getSettlementName() {
        return this.settlementName;
    }

    public void setSettlementName(String settlementName) {
        this.settlementName = settlementName;
    }

    public String getSettlementNameLatin() {
        return this.settlementNameLatin;
    }

    public void setSettlementNameLatin(String settlementNameLatin) {
        this.settlementNameLatin = settlementNameLatin;
    }

    public String getLocationCode() {
        return this.locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public String getLocationName() {
        return this.locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public String getLocationNameLatin() {
        return this.locationNameLatin;
    }

    public void setLocationNameLatin(String locationNameLatin) {
        this.locationNameLatin = locationNameLatin;
    }

    public String getBuildingNumber() {
        return this.buildingNumber;
    }

    public void setBuildingNumber(String buildingNumber) {
        this.buildingNumber = buildingNumber;
    }

    public String getEntrance() {
        return this.entrance;
    }

    public void setEntrance(String entrance) {
        this.entrance = entrance;
    }

    public String getFloor() {
        return this.floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getApartment() {
        return this.apartment;
    }

    public void setApartment(String apartment) {
        this.apartment = apartment;
    }


}
