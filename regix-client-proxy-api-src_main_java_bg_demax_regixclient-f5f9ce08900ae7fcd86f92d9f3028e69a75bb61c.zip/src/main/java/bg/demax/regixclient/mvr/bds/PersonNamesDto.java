package bg.demax.regixclient.mvr.bds;

public class PersonNamesDto {

	private String firstName;
	private String surname;
	private String familyName;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public String getFullName() {
		StringBuilder fullNameBuilder = new StringBuilder();
		if (this.firstName != null && !this.firstName.trim().isEmpty()) {
			fullNameBuilder.append(this.firstName.trim()).append(" ");
		} else {
			return null;
		}

		if (this.surname != null && !this.surname.isEmpty()) {
			fullNameBuilder.append(this.surname.trim()).append(" ");
		}

		if (this.familyName != null && !this.familyName.trim().isEmpty()) {
			fullNameBuilder.append(this.familyName.trim());
		} else {
			return null;
		}

		return fullNameBuilder.toString().trim();
	}
}
