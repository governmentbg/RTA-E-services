package bg.demax.regixclient.mvr.bds;

import javax.validation.constraints.NotBlank;

public class PersonalIdentityDto extends BaseRequestDto {

    @NotBlank
    private String egn;

    @NotBlank
    private String identityDocumentNumber;

    /**
     * @return String return the egn
     */
    public String getEgn() {
        return egn;
    }

    /**
     * @param egn the egn to set
     */
    public void setEgn(String egn) {
        this.egn = egn;
    }

    /**
     * @return String return the identityDocumentNumber
     */
    public String getIdentityDocumentNumber() {
        return identityDocumentNumber;
    }

    /**
     * @param identityDocumentNumber the identityDocumentNumber to set
     */
    public void setIdentityDocumentNumber(String identityDocumentNumber) {
        this.identityDocumentNumber = identityDocumentNumber;
    }

}
