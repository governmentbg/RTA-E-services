package bg.demax.regixclient.mvr.bds;

import java.time.LocalDate;

public class PersonalResponseDto {

    private PersonNamesDto personNames;
    private byte[] picture;
    private boolean isValid;
    private LocalDate validUntil;
    private ReturnInformation returnInformation;

    public PersonalResponseDto() {
        this.isValid = true;
    }

    public PersonNamesDto getPersonNames() {
        return personNames;
    }

    public void setPersonNames(PersonNamesDto personNames) {
        this.personNames = personNames;
    }

    /**
     * @return byte[] return the picture
     */
    public byte[] getPicture() {
        return picture;
    }

    /**
     * @param picture the picture to set
     */
    public void setPicture(byte[] picture) {
        this.picture = picture;
    }

    /**
     * @return boolean return the isValid
     */
    public boolean isIsValid() {
        return isValid;
    }

    /**
     * @param isValid the isValid to set
     */
    public void setIsValid(boolean isValid) {
        this.isValid = isValid;
    }

    /**
     * @return LocalDate return the validUntil
     */
    public LocalDate getValidUntil() {
        return validUntil;
    }

    /**
     * @param validUntil the validUntil to set
     */
    public void setValidUntil(LocalDate validUntil) {
        this.validUntil = validUntil;
    }

    /**
     * @return ReturnInformation return the returnInformation
     */
    public ReturnInformation getReturnInformation() {
        return returnInformation;
    }

    /**
     * @param returnInformation the returnInformation to set
     */
    public void setReturnInformation(ReturnInformation returnInformation) {
        this.returnInformation = returnInformation;
    }

}
