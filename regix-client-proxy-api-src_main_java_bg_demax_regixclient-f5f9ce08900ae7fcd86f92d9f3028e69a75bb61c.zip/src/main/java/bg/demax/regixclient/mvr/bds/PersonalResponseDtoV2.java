package bg.demax.regixclient.mvr.bds;

import java.util.List;

public class PersonalResponseDtoV2 {

	private List<DLCategoryDto> dlCategоries;
	private String dlCommonRestrictions;
	private ReturnInformation returnInformation;

	public List<DLCategoryDto> getDlCategоries() {
		return dlCategоries;
	}

	public void setDlCategоries(List<DLCategoryDto> dlCategоries) {
		this.dlCategоries = dlCategоries;
	}

	public String getDlCommonRestrictions() {
		return dlCommonRestrictions;
	}

	public void setDlCommonRestrictions(String dlCommonRestrictions) {
		this.dlCommonRestrictions = dlCommonRestrictions;
	}

	public ReturnInformation getReturnInformation() {
		return returnInformation;
	}

	public void setReturnInformation(ReturnInformation returnInformation) {
		this.returnInformation = returnInformation;
	}
}
