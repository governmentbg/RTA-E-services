package bg.demax.regixclient.mvr.bds;

import java.time.LocalDate;
import java.util.List;

public class PersonalResponseDtoV3 {

	private LocalDate validUntil;
	private ReturnInformation returnInformation;

	private String egn;
	private PersonNamesDto personNames;
	private List<DLCategoryDto> dlCategоries;
	private String dlCommonRestrictions;
	private ForeignCitizenTypeDto dataForeignCitizen;
	private RPRemarkTypeDto rpRemarks;
	private String rpTypeofPermit;
	private String documentType;
	private String documentTypeLatin;
	private String documentActualStatus;
	private LocalDate actualStatusDate;
	private String documentStatusReason;
	private String identityDocumentNumber;
	private LocalDate issueDate;
	private String issuerPlace;
	private String issuerPlaceLatin;
	private String issuerName;
	private String issuerNameLatin;
	private LocalDate validDate;
	private LocalDate birthDate;
	private BirthPlaceDto birthPlace;
	private String genderName;
	private String genderNameLatin;
	private NationalityListDto nationalityList;
	private PermanentAddressDto permanentAddress;
	private Double height;
	private String eyesColor;
	private byte[] picture;
	private byte[] identitySignature;

	public LocalDate getValidUntil() {
		return this.validUntil;
	}

	public void setValidUntil(LocalDate validUntil) {
		this.validUntil = validUntil;
	}

	public ReturnInformation getReturnInformation() {
		return this.returnInformation;
	}

	public void setReturnInformation(ReturnInformation returnInformation) {
		this.returnInformation = returnInformation;
	}

	public String getEgn() {
		return this.egn;
	}

	public void setEgn(String egn) {
		this.egn = egn;
	}

	public PersonNamesDto getPersonNames() {
		return this.personNames;
	}

	public void setPersonNames(PersonNamesDto personNames) {
		this.personNames = personNames;
	}

	public List<DLCategoryDto> getDlCategоries() {
		return this.dlCategоries;
	}

	public void setDlCategоries(List<DLCategoryDto> dlCategоries) {
		this.dlCategоries = dlCategоries;
	}

	public String getDlCommonRestrictions() {
		return this.dlCommonRestrictions;
	}

	public void setDlCommonRestrictions(String dlCommonRestrictions) {
		this.dlCommonRestrictions = dlCommonRestrictions;
	}

	public ForeignCitizenTypeDto getDataForeignCitizen() {
		return this.dataForeignCitizen;
	}

	public void setDataForeignCitizen(ForeignCitizenTypeDto dataForeignCitizen) {
		this.dataForeignCitizen = dataForeignCitizen;
	}

	public RPRemarkTypeDto getRpRemarks() {
		return this.rpRemarks;
	}

	public void setRpRemarks(RPRemarkTypeDto rpRemarks) {
		this.rpRemarks = rpRemarks;
	}

	public String getRpTypeofPermit() {
		return this.rpTypeofPermit;
	}

	public void setRpTypeofPermit(String rpTypeofPermit) {
		this.rpTypeofPermit = rpTypeofPermit;
	}

	public String getDocumentType() {
		return this.documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDocumentTypeLatin() {
		return this.documentTypeLatin;
	}

	public void setDocumentTypeLatin(String documentTypeLatin) {
		this.documentTypeLatin = documentTypeLatin;
	}

	public String getDocumentActualStatus() {
		return this.documentActualStatus;
	}

	public void setDocumentActualStatus(String documentActualStatus) {
		this.documentActualStatus = documentActualStatus;
	}

	public LocalDate getActualStatusDate() {
		return this.actualStatusDate;
	}

	public void setActualStatusDate(LocalDate actualStatusDate) {
		this.actualStatusDate = actualStatusDate;
	}

	public String getDocumentStatusReason() {
		return this.documentStatusReason;
	}

	public void setDocumentStatusReason(String documentStatusReason) {
		this.documentStatusReason = documentStatusReason;
	}

	public String getIdentityDocumentNumber() {
		return this.identityDocumentNumber;
	}

	public void setIdentityDocumentNumber(String identityDocumentNumber) {
		this.identityDocumentNumber = identityDocumentNumber;
	}

	public LocalDate getIssueDate() {
		return this.issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public String getIssuerPlace() {
		return this.issuerPlace;
	}

	public void setIssuerPlace(String issuerPlace) {
		this.issuerPlace = issuerPlace;
	}

	public String getIssuerPlaceLatin() {
		return this.issuerPlaceLatin;
	}

	public void setIssuerPlaceLatin(String issuerPlaceLatin) {
		this.issuerPlaceLatin = issuerPlaceLatin;
	}

	public String getIssuerName() {
		return this.issuerName;
	}

	public void setIssuerName(String issuerName) {
		this.issuerName = issuerName;
	}

	public String getIssuerNameLatin() {
		return this.issuerNameLatin;
	}

	public void setIssuerNameLatin(String issuerNameLatin) {
		this.issuerNameLatin = issuerNameLatin;
	}

	public LocalDate getValidDate() {
		return this.validDate;
	}

	public void setValidDate(LocalDate validDate) {
		this.validDate = validDate;
	}

	public LocalDate getBirthDate() {
		return this.birthDate;
	}

	public void setBirthDate(LocalDate birthDate) {
		this.birthDate = birthDate;
	}

	public BirthPlaceDto getBirthPlace() {
		return this.birthPlace;
	}

	public void setBirthPlace(BirthPlaceDto birthPlace) {
		this.birthPlace = birthPlace;
	}

	public String getGenderName() {
		return this.genderName;
	}

	public void setGenderName(String genderName) {
		this.genderName = genderName;
	}

	public String getGenderNameLatin() {
		return this.genderNameLatin;
	}

	public void setGenderNameLatin(String genderNameLatin) {
		this.genderNameLatin = genderNameLatin;
	}

	public NationalityListDto getNationalityList() {
		return this.nationalityList;
	}

	public void setNationalityList(NationalityListDto nationalityList) {
		this.nationalityList = nationalityList;
	}

	public PermanentAddressDto getPermanentAddress() {
		return this.permanentAddress;
	}

	public void setPermanentAddress(PermanentAddressDto permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public Double getHeight() {
		return this.height;
	}

	public void setHeight(Double height) {
		this.height = height;
	}

	public String getEyesColor() {
		return this.eyesColor;
	}

	public void setEyesColor(String eyesColor) {
		this.eyesColor = eyesColor;
	}

	public byte[] getPicture() {
		return this.picture;
	}

	public void setPicture(byte[] picture) {
		this.picture = picture;
	}

	public byte[] getIdentitySignature() {
		return this.identitySignature;
	}

	public void setIdentitySignature(byte[] identitySignature) {
		this.identitySignature = identitySignature;
	}

}
