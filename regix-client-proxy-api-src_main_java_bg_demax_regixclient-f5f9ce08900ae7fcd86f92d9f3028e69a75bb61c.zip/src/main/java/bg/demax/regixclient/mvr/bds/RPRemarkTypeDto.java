package bg.demax.regixclient.mvr.bds;

import java.util.List;

public class RPRemarkTypeDto {

    protected List<String> rpRemark;

    public List<String> getRpRemark() {
        return this.rpRemark;
    }

    public void setRpRemark(List<String> rpRemark) {
        this.rpRemark = rpRemark;
    }

}
