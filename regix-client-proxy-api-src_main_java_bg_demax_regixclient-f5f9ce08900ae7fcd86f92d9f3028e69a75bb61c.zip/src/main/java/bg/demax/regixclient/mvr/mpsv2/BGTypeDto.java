package bg.demax.regixclient.mvr.mpsv2;

public class BGTypeDto {

    private String pin;

    private BGTypeNamesDto names;

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public BGTypeNamesDto getNames() {
		return names;
	}

	public void setNames(BGTypeNamesDto names) {
		this.names = names;
	}
    
}
