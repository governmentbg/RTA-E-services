package bg.demax.regixclient.mvr.mpsv2;

public class BGTypeNamesDto {

    private String first;

    private String surname;

    private String family;

	public String getFirst() {
		return first;
	}

	public void setFirst(String first) {
		this.first = first;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}
    
}
