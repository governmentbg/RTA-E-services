package bg.demax.regixclient.mvr.mpsv2;

public class FCTypeDto {

    private String pin;

    private String pn;

    private String namesCyrillic;

    private String namesLatin;

    private String nationality;

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getPn() {
		return pn;
	}

	public void setPn(String pn) {
		this.pn = pn;
	}

	public String getNamesCyrillic() {
		return namesCyrillic;
	}

	public void setNamesCyrillic(String namesCyrillic) {
		this.namesCyrillic = namesCyrillic;
	}

	public String getNamesLatin() {
		return namesLatin;
	}

	public void setNamesLatin(String namesLatin) {
		this.namesLatin = namesLatin;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
    
}
