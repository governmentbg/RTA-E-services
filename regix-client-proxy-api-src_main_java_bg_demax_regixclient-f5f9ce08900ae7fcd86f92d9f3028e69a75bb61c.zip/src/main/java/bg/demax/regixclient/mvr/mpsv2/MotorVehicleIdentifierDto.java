package bg.demax.regixclient.mvr.mpsv2;

import javax.validation.constraints.NotBlank;

import bg.demax.regixclient.mvr.bds.BaseRequestDto;

public class MotorVehicleIdentifierDto extends BaseRequestDto {

	@NotBlank
	private String registrationNumber;

	/**
     * @return String return vehicle's registration number
     */
	public String getRegistrationNumber() {
		return registrationNumber;
	}

	/**
     * @param String vehicle's registrationNumber (without separators) 
     */
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

}
