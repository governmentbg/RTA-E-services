package bg.demax.regixclient.mvr.mpsv2;

import bg.demax.regixclient.mvr.bds.ReturnInformation;

public class MotorVehicleRegistrationInfoDto {

    private ResultsDto results;

    private ReturnInformation returnInformation;
    
	public ResultsDto getResults() {
		return results;
	}

	public void setResults(ResultsDto results) {
		this.results = results;
	}

	public ReturnInformation getReturnInformation() {
		return returnInformation;
	}

	public void setReturnInformation(ReturnInformation returnInformation) {
		this.returnInformation = returnInformation;
	}
    
}
