package bg.demax.regixclient.mvr.mpsv2;

public class OwnerTypeDto {
    
    private BGTypeDto bulgarianCitizen;

    private FCTypeDto foreignCitizen;
  
    private CompanyTypeDto company;

	public BGTypeDto getBulgarianCitizen() {
		return bulgarianCitizen;
	}

	public void setBulgarianCitizen(BGTypeDto bulgarianCitizen) {
		this.bulgarianCitizen = bulgarianCitizen;
	}

	public FCTypeDto getForeignCitizen() {
		return foreignCitizen;
	}

	public void setForeignCitizen(FCTypeDto foreignCitizen) {
		this.foreignCitizen = foreignCitizen;
	}

	public CompanyTypeDto getCompany() {
		return company;
	}

	public void setCompany(CompanyTypeDto company) {
		this.company = company;
	}
    
}
