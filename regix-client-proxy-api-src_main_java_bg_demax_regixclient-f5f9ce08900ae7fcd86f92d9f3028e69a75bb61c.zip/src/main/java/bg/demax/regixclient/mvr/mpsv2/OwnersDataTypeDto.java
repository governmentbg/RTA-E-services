package bg.demax.regixclient.mvr.mpsv2;

import java.util.List;

public class OwnersDataTypeDto {

    private List<OwnerTypeDto> owner;

	public List<OwnerTypeDto> getOwner() {
		return owner;
	}

	public void setOwner(List<OwnerTypeDto> owner) {
		this.owner = owner;
	}
    
}
