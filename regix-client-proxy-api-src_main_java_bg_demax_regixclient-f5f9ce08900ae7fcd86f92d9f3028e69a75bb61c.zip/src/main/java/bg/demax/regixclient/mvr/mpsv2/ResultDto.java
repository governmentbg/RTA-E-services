package bg.demax.regixclient.mvr.mpsv2;

import java.util.List;

public class ResultDto {

    private VehicleDataTypeDto vehicleData;

    private OwnersDataTypeDto ownersData;

    private List<UsersDataTypeDto> usersData;

	public VehicleDataTypeDto getVehicleData() {
		return vehicleData;
	}

	public void setVehicleData(VehicleDataTypeDto vehicleData) {
		this.vehicleData = vehicleData;
	}

	public OwnersDataTypeDto getOwnersData() {
		return ownersData;
	}

	public void setOwnersData(OwnersDataTypeDto ownersData) {
		this.ownersData = ownersData;
	}

	public List<UsersDataTypeDto> getUsersData() {
		return usersData;
	}

	public void setUsersData(List<UsersDataTypeDto> usersData) {
		this.usersData = usersData;
	}
    
}
