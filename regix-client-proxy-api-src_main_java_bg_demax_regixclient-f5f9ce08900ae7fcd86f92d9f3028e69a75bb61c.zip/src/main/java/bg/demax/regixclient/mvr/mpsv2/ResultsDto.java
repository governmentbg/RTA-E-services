package bg.demax.regixclient.mvr.mpsv2;

import java.util.List;

public class ResultsDto {
	
	private List<ResultDto> result;

	public List<ResultDto> getResult() {
		return result;
	}

	public void setResult(List<ResultDto> result) {
		this.result = result;
	}

}
