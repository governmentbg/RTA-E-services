package bg.demax.regixclient.mvr.mpsv2;

public class UsersDataTypeDto {

	private OwnerTypeDto user;

	public OwnerTypeDto getUser() {
		return user;
	}

	public void setUser(OwnerTypeDto user) {
		this.user = user;
	}

}
