package bg.demax.regixclient.mvr.mpsv2;

import java.math.BigInteger;
import java.time.LocalDate;

public class VehicleDataTypeDto {

    private String registrationNumber;

    private LocalDate firstRegistrationDate;

    private String vin;

    private String vehicleType;

    private String category;

    private BigInteger massG;

    private BigInteger massF1;

    private String environmentalCategory;

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public LocalDate getFirstRegistrationDate() {
		return firstRegistrationDate;
	}

	public void setFirstRegistrationDate(LocalDate firstRegistrationDate) {
		this.firstRegistrationDate = firstRegistrationDate;
	}

	public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public BigInteger getMassG() {
		return massG;
	}

	public void setMassG(BigInteger massG) {
		this.massG = massG;
	}

	public BigInteger getMassF1() {
		return massF1;
	}

	public void setMassF1(BigInteger massF1) {
		this.massF1 = massF1;
	}

	public String getEnvironmentalCategory() {
		return environmentalCategory;
	}

	public void setEnvironmentalCategory(String environmentalCategory) {
		this.environmentalCategory = environmentalCategory;
	}

}
