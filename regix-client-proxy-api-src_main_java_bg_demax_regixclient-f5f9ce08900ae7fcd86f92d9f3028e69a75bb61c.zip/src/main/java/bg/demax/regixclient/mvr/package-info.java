/**
 * @author zivanova
 * 
 * Package for DTOs related to services in Ministry of Interior "Министерство на вътршните работи"
 * 
 * BDS: Регистър Български документи за самоличност
 * ERCH: Единен регистър на чужденците
 * MPSV3: Регистър на моторните превозни средства V3
 * 
 * More info at: http://regixaisweb.egov.bg/RegiXInfo/#12
 *
 */
package bg.demax.regixclient.mvr;