package bg.demax.regixclient.nra.employmentcontracts;

public enum ContractsFilterTypeDto {

    ALL("All"),
    ACTIVE("Active");
    private final String value;

    ContractsFilterTypeDto(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ContractsFilterTypeDto fromValue(String v) {
        for (ContractsFilterTypeDto c: ContractsFilterTypeDto.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
}
