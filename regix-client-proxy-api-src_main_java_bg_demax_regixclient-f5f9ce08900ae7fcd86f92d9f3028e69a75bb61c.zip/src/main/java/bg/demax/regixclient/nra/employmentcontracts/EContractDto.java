package bg.demax.regixclient.nra.employmentcontracts;

import java.math.BigDecimal;
import java.time.LocalDate;

public class EContractDto {

    private String contractorBulstat;

    private String contractorName;

    private String individualEIK;

    private String individualNames;

    private LocalDate startDate;

    private LocalDate lastAmendDate;

    private LocalDate endDate;

    private String reason;

    private LocalDate timeLimit;

    private String ecoCode;

    private String professionCode;

    private BigDecimal remuneration;

    private String professionName;

    private String ekatteCode;

	public String getContractorBulstat() {
		return contractorBulstat;
	}

	public void setContractorBulstat(String contractorBulstat) {
		this.contractorBulstat = contractorBulstat;
	}

	public String getContractorName() {
		return contractorName;
	}

	public void setContractorName(String contractorName) {
		this.contractorName = contractorName;
	}

	public String getIndividualEIK() {
		return individualEIK;
	}

	public void setIndividualEIK(String individualEIK) {
		this.individualEIK = individualEIK;
	}

	public String getIndividualNames() {
		return individualNames;
	}

	public void setIndividualNames(String individualNames) {
		this.individualNames = individualNames;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getLastAmendDate() {
		return lastAmendDate;
	}

	public void setLastAmendDate(LocalDate lastAmendDate) {
		this.lastAmendDate = lastAmendDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public LocalDate getTimeLimit() {
		return timeLimit;
	}

	public void setTimeLimit(LocalDate timeLimit) {
		this.timeLimit = timeLimit;
	}

	public String getEcoCode() {
		return ecoCode;
	}

	public void setEcoCode(String ecoCode) {
		this.ecoCode = ecoCode;
	}

	public String getProfessionCode() {
		return professionCode;
	}

	public void setProfessionCode(String professionCode) {
		this.professionCode = professionCode;
	}

	public BigDecimal getRemuneration() {
		return remuneration;
	}

	public void setRemuneration(BigDecimal remuneration) {
		this.remuneration = remuneration;
	}

	public String getProfessionName() {
		return professionName;
	}

	public void setProfessionName(String professionName) {
		this.professionName = professionName;
	}

	public String getEkatteCode() {
		return ekatteCode;
	}

	public void setEkatteCode(String ekatteCode) {
		this.ekatteCode = ekatteCode;
	}    
    
}
