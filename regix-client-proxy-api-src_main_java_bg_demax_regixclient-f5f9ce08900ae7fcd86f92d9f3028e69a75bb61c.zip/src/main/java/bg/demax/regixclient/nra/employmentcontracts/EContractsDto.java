package bg.demax.regixclient.nra.employmentcontracts;

import java.util.List;

public class EContractsDto {

    private List<EContractDto> eContract;

	public List<EContractDto> geteContract() {
		return eContract;
	}

	public void seteContract(List<EContractDto> eContract) {
		this.eContract = eContract;
	}    
    
}
