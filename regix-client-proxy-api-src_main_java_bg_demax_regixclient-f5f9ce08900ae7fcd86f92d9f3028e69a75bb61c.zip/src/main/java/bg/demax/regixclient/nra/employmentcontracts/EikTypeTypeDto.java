package bg.demax.regixclient.nra.employmentcontracts;

public enum EikTypeTypeDto {

    BULSTAT("Bulstat"),
    EGN("EGN"),
    LNC("LNC"),
    SYSTEM_NO("SystemNo"),
    BULSTAT_CL("BulstatCL");
    private final String value;

    EikTypeTypeDto(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static EikTypeTypeDto fromValue(String v) {
        for (EikTypeTypeDto c: EikTypeTypeDto.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
}
