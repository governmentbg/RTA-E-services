package bg.demax.regixclient.nra.employmentcontracts;

import javax.validation.constraints.NotNull;

import bg.demax.regixclient.mvr.bds.BaseRequestDto;

public class EmploymentContractsIdentifierDto extends BaseRequestDto {

	@NotNull
    private IdentityTypeRequestDto identity;

    private ContractsFilterTypeDto contractsFilter;

	public IdentityTypeRequestDto getIdentity() {
		return identity;
	}

	public void setIdentity(IdentityTypeRequestDto identity) {
		this.identity = identity;
	}

	public ContractsFilterTypeDto getContractsFilter() {
		return contractsFilter;
	}

	public void setContractsFilter(ContractsFilterTypeDto contractsFilter) {
		this.contractsFilter = contractsFilter;
	}    
    
}
