package bg.demax.regixclient.nra.employmentcontracts;

import java.time.LocalDate;

public class EmploymentContractsInfoDto {

	    private ResponseIdentityTypeDto identity;

	    private EContractsDto eContracts;

	    private StatusTypeDto status;

	    private ContractsFilterTypeDto contractsFilter;

	    private LocalDate reportDate;

		public ResponseIdentityTypeDto getIdentity() {
			return identity;
		}

		public void setIdentity(ResponseIdentityTypeDto identity) {
			this.identity = identity;
		}

		public EContractsDto geteContracts() {
			return eContracts;
		}

		public void seteContracts(EContractsDto eContracts) {
			this.eContracts = eContracts;
		}

		public StatusTypeDto getStatus() {
			return status;
		}

		public void setStatus(StatusTypeDto status) {
			this.status = status;
		}

		public ContractsFilterTypeDto getContractsFilter() {
			return contractsFilter;
		}

		public void setContractsFilter(ContractsFilterTypeDto contractsFilter) {
			this.contractsFilter = contractsFilter;
		}

		public LocalDate getReportDate() {
			return reportDate;
		}

		public void setReportDate(LocalDate reportDate) {
			this.reportDate = reportDate;
		}	    
	    
}
