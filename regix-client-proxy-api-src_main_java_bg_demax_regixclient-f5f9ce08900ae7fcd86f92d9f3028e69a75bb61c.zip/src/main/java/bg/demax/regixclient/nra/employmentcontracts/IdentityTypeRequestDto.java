package bg.demax.regixclient.nra.employmentcontracts;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class IdentityTypeRequestDto {

	@NotBlank
    private String id;

	@NotNull
    private EikTypeTypeDto type;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public EikTypeTypeDto getType() {
		return type;
	}

	public void setType(EikTypeTypeDto type) {
		this.type = type;
	}
    
}
