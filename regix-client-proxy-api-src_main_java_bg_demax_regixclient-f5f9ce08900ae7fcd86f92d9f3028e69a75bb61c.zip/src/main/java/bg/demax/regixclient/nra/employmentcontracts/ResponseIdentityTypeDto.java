package bg.demax.regixclient.nra.employmentcontracts;

public class ResponseIdentityTypeDto {

    private String id;

    private EikTypeTypeDto type;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public EikTypeTypeDto getType() {
		return type;
	}

	public void setType(EikTypeTypeDto type) {
		this.type = type;
	}    
    
}
