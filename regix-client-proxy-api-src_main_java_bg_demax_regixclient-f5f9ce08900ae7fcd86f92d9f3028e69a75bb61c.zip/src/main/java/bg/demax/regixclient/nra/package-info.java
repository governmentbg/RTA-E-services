/**
 * @author zivanova
 * 
 * Package for DTOs related to services in National Revenue Agency "НАП - Национална агенция за приходите"
 * 
 * More info at: http://regixaisweb.egov.bg/RegiXInfo/#19
 *
 */
package bg.demax.regixclient.nra;