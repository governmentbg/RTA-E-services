package bg.government.regixclient.app.cache;

public interface CacheDbTablenames {
	String LOGS_MOTOR_VEHICLE_REGISTRATION = "logs_motor_vehicle_registration_v2";
	String LOGS_PERSONAL_IDENTITY = "logs_personal_identity";
	String LOGS_PERSONAL_IDENTITY_V2 = "logs_personal_identity_v2";
	String LOGS_PERSONAL_IDENTITY_V3 = "logs_personal_identity_v3";
	String LOGS_FOREIGN_IDENTITY = "logs_foreign_identity";
	String LOGS_EMPLOYMENT_CONTRACTS = "logs_employment_contracts";
	String LOGS_UIC_VALIDATION = "logs_uic_validation";
	String LOGS_AV_TR_ACTUAL_STATE_V3 = "logs_av_tr_actual_state_v3";
	String LOG_SCHEMA = "regix_proxy";
}
