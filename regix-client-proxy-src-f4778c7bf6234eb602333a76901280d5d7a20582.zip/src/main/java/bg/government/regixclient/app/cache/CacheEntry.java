package bg.government.regixclient.app.cache;

import java.time.LocalDateTime;

import bg.government.regixclient.requests.CallContext;

public class CacheEntry<REQ, RES> {

	private REQ request;
	private RES response;
	private String clientName;
	private LocalDateTime requestTime;
	private LocalDateTime responseTime;
    private String error;
    private CallContext callContext;

	public REQ getRequest() {
		return request;
	}

	public void setRequest(REQ request) {
		this.request = request;
	}

	public RES getResponse() {
		return response;
	}

	public void setResponse(RES response) {
		this.response = response;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public LocalDateTime getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(LocalDateTime requestTime) {
		this.requestTime = requestTime;
	}

	public LocalDateTime getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(LocalDateTime responseTime) {
		this.responseTime = responseTime;
	}	

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public CallContext getCallContext() {
		return callContext;
	}

	public void setCallContext(CallContext callContext) {
		this.callContext = callContext;
	}
}

