package bg.government.regixclient.app.cache;

public class CacheProperties {

	private String tableName;
	private Integer firstPeriodInHours;
	private Integer secondPeriodInHours;

	public CacheProperties() {
	}

	public CacheProperties(String tableName, Integer firstPeriodInHours, Integer secondPeriodInHours) {
		this.tableName = tableName;
		this.firstPeriodInHours = firstPeriodInHours;
		this.secondPeriodInHours = secondPeriodInHours;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public Integer getFirstPeriodInHours() {
		return firstPeriodInHours;
	}

	public void setFirstPeriodInHours(Integer firstPeriodInHours) {
		this.firstPeriodInHours = firstPeriodInHours;
	}

	public Integer getSecondPeriodInHours() {
		return secondPeriodInHours;
	}

	public void setSecondPeriodInHours(Integer secondPeriodInHours) {
		this.secondPeriodInHours = secondPeriodInHours;
	}

}
