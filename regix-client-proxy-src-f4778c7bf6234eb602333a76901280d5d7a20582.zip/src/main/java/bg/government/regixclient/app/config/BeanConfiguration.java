package bg.government.regixclient.app.config;

import java.net.URISyntaxException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.GregorianCalendar;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.soap.addressing.client.ActionCallback;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;

import bg.government.regixclient.app.jackson.JaxbElementJacksonDeserializer;
import bg.government.regixclient.app.jackson.JaxbElementMixIn;
import bg.government.regixclient.app.jackson.XMLGregorianCalendarDeserializer;
import bg.government.regixclient.app.jackson.XMLGregorianCalendarSerializer;
import bg.government.regixclient.app.regixclient.CustomFaultMessageResolver;
import bg.government.regixclient.requests.ObjectFactory;

@Configuration
public class BeanConfiguration {
	
	@Bean
	@Primary
	public ObjectMapper defaultMapper() {
		ObjectMapper newOm = new ObjectMapper();
		newOm.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS); // StdDateFormat is ISO8601 since jackson 2.9
		newOm.registerModule(new JavaTimeModule()); 
		
		return newOm;
	}

	@Bean
	@Qualifier(BeanQualifiers.TYPE_ENABLED_JSON_OBJECT_MAPPER)
	public ObjectMapper jsonMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.enableDefaultTyping();
		mapper.addMixIn(JAXBElement.class, JaxbElementMixIn.class);

		SimpleModule module = new SimpleModule();
		module.addSerializer(new XMLGregorianCalendarSerializer());
		module.addDeserializer(XMLGregorianCalendar.class, new XMLGregorianCalendarDeserializer(XMLGregorianCalendar.class));
		module.addDeserializer(JAXBElement.class, new JaxbElementJacksonDeserializer(mapper));
		mapper.registerModule(module);

		mapper.registerSubtypes(GregorianCalendar.class);

		JavaTimeModule javaTimeModule = new JavaTimeModule();
		javaTimeModule.addSerializer(new LocalDateTimeSerializer(DateTimeFormatter.ISO_DATE_TIME));
		javaTimeModule.addDeserializer(LocalDateTime.class, new LocalDateTimeDeserializer(DateTimeFormatter.ISO_DATE_TIME));
		javaTimeModule.addSerializer(new LocalDateSerializer(DateTimeFormatter.ISO_DATE));
		javaTimeModule.addDeserializer(LocalDate.class, new LocalDateDeserializer(DateTimeFormatter.ISO_DATE));
		mapper.registerModule(javaTimeModule);

		return mapper;
	}

	@Bean
	public Jaxb2Marshaller marshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setPackagesToScan("bg.government.regixclient.requests");
		return marshaller;
	}

	@Bean
	public CustomFaultMessageResolver customFaultMessageResolver() {
		return new CustomFaultMessageResolver();
	}

	@Bean
	public ObjectFactory wsdlObjectFactory() {
		return new ObjectFactory();
	}

	@Bean
	public bg.government.regixclient.requests.mvr.bds.ObjectFactory bdsObjectFactory() {
		return new bg.government.regixclient.requests.mvr.bds.ObjectFactory();
	}

	@Bean
	public bg.government.regixclient.requests.mvr.erch.ObjectFactory erchObjectFactory() {
		return new bg.government.regixclient.requests.mvr.erch.ObjectFactory();
	}
	
	@Bean
	public bg.government.regixclient.requests.mvr.mpsv2.ObjectFactory mpsObjectFactory() {
		return new bg.government.regixclient.requests.mvr.mpsv2.ObjectFactory();
	}
	
	@Bean
	public bg.government.regixclient.requests.nra.employmentcontracts.ObjectFactory ecObjectFactory() {
		return new bg.government.regixclient.requests.nra.employmentcontracts.ObjectFactory();
	}
	
	@Bean
	public bg.government.regixclient.requests.av.tr.uicvalidation.ObjectFactory uicObjectFactory() {
		return new bg.government.regixclient.requests.av.tr.uicvalidation.ObjectFactory();
	}
	
	@Bean
	public bg.government.regixclient.requests.av.tr.actualstatev3.ObjectFactory actualStateObjectFactory() {
		return new bg.government.regixclient.requests.av.tr.actualstatev3.ObjectFactory();
	}

	@Bean
	public ActionCallback tempuriActionCallback() throws URISyntaxException {
		return new ActionCallback("http://tempuri.org/IRegiXEntryPoint/ExecuteSynchronous");
	}
}