package bg.government.regixclient.app.config;

public interface BeanQualifiers {
	String DEFAULT_SPRING_BOOT_CONVERSION_SERVICE = "mvcConversionService";
	String TYPE_ENABLED_JSON_OBJECT_MAPPER = "TYPE_ENABLED_JSON_OBJECT_MAPPER";
}
