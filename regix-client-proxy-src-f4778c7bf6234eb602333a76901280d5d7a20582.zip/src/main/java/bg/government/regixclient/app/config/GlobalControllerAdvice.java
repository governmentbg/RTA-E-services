package bg.government.regixclient.app.config;

import java.lang.reflect.Field;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.fasterxml.jackson.annotation.JsonProperty;

import bg.government.regixclient.app.exceptions.ApplicationException;
import bg.government.regixclient.app.exceptions.RegixResponseErrorException;
import bg.government.regixclient.app.exceptions.RegixResponseProcessingFailureException;
import bg.government.regixclient.app.exceptions.RegixWebServiceIOException;
import bg.government.regixclient.app.exceptions.dto.ApplicationExceptionDto;
import bg.government.regixclient.app.exceptions.dto.ValidationErrorDto;

@RestControllerAdvice
public class GlobalControllerAdvice extends ResponseEntityExceptionHandler {

	private static final Logger logger = LogManager.getLogger(GlobalControllerAdvice.class);
	private static final String NO_MESSAGE = "_NO_MESSAGE_";

	@Override
	protected ResponseEntity<Object> handleBindException(BindException ex, HttpHeaders headers, HttpStatus status,
			WebRequest request) {
		BindingResult bindingResult = ex.getBindingResult();
		ValidationErrorDto dto = createValidationErrorDto(bindingResult, request.getLocale());
		headers.setContentType(MediaType.APPLICATION_JSON);
		return handleExceptionInternal(ex, dto, headers, status, request);
	}

	@Override
	protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		logger.debug("", ex);

		if (ex instanceof MethodArgumentNotValidException) {
			MethodArgumentNotValidException mex = (MethodArgumentNotValidException) ex;
			body = createValidationErrorDto(mex.getBindingResult(), request.getLocale());
			headers.setContentType(MediaType.APPLICATION_JSON);
		}
		return super.handleExceptionInternal(ex, body, headers, status, request);
	}

	@ExceptionHandler(ApplicationException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public ApplicationExceptionDto ApplicationExceptionHandlers(final ApplicationException ex, final HttpServletRequest request) {
		return convertException(ex, request);
	}
	
	@ExceptionHandler(RegixResponseProcessingFailureException.class)
	@ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
	public ApplicationExceptionDto RegixResponseProcessingFailureExceptionHandlers(final RegixResponseProcessingFailureException ex,
			final HttpServletRequest request) {
		return convertException(ex, request);
	}

	@ExceptionHandler({RegixResponseErrorException.class, RegixWebServiceIOException.class})
	@ResponseStatus(HttpStatus.FAILED_DEPENDENCY)
	public ApplicationExceptionDto RegixConnectionFailureExceptionHandlers(final Exception ex,
			final HttpServletRequest request) {
		return convertException(ex, request);
	}

	@ExceptionHandler(Exception.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ApplicationExceptionDto defaultHandler(final Exception ex, final HttpServletRequest request) {
		return convertException(ex, request);
	}
	
	private ValidationErrorDto createValidationErrorDto(BindingResult bindingResult, Locale locale) {
		List<FieldError> fieldErrors = bindingResult.getFieldErrors();
		List<ObjectError> globalErrors = bindingResult.getGlobalErrors();
		ValidationErrorDto dto = new ValidationErrorDto();
		for (FieldError fieldError : fieldErrors) {
			String field = resolveFieldName(fieldError.getField(), bindingResult.getTarget().getClass());
			String message = fieldError.getDefaultMessage();
			if (fieldError.isBindingFailure()) {
				message = NO_MESSAGE;
			}
			dto.addError(field, message);
		}
		for (ObjectError globalError : globalErrors) {
			dto.addError(globalError.getObjectName(), globalError.getDefaultMessage());
		}
		return dto;
	}

	private String resolveFieldName(String fieldName, Class<?> clazz) {
		try {
			Field field = clazz.getDeclaredField(fieldName);
			String resolvedFieldName = field.getName();
			if (field.isAnnotationPresent(JsonProperty.class)) {
				JsonProperty annotation = field.getAnnotation(JsonProperty.class);
				String value = annotation.value();
				if (value != null && !value.isEmpty()) {
					resolvedFieldName = annotation.value();
				}
			}
			return resolvedFieldName;
		} catch (NoSuchFieldException e) {
			logger.trace("NoSuchField '" + fieldName + "' for class '" + clazz + "'");
			return fieldName;
		}
	}

	private ApplicationExceptionDto convertException(Exception ex, HttpServletRequest request) {
		setResponseTypeToJson(request);
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError(ex.getClass().getSimpleName());
		String message = ex.getMessage();
		dto.setMessage(message);
		return dto;
	}

	private void setResponseTypeToJson(HttpServletRequest request) {
		request.setAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE,
				Collections.singleton(MediaType.APPLICATION_JSON));
	}
	
}