package bg.government.regixclient.app.config;

import java.beans.PropertyVetoException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration
@Profile("!" + RegixClientProxyConstants.SPRING_PROFILE_UNIT_TEST)
@EnableTransactionManagement(order = 3)
public class PostgresConfig {

    @Value("${regix.datasource.jdbc.url}")
    private String jdbcUrl;

    @Value("${regix.datasource.user}")
    private String databaseUser;

    @Value("${regix.datasource.password}")
    private String databasePassword;

    @Value("${regix.datasource.driver}")
    private String databaseDriver;

    @Value("${regix.database.jdbc.pool.size}")
    private int poolSize;

    // ----------------------------------------------------------------------------
    @Bean
    public DataSource dataSource() {
        try {
            ComboPooledDataSource dataSource = new ComboPooledDataSource();
            dataSource.setDataSourceName("jsonDataSource");
            dataSource.setJdbcUrl(jdbcUrl);
            dataSource.setInitialPoolSize(poolSize);
            dataSource.setUser(databaseUser);
            dataSource.setPassword(databasePassword);
            dataSource.setDriverClass(databaseDriver);
            dataSource.setMaxPoolSize(4);
            dataSource.setMaxIdleTime(10000);
            dataSource.setIdleConnectionTestPeriod(3000);
            dataSource.setTestConnectionOnCheckin(true);
            dataSource.setTestConnectionOnCheckout(true);

            return dataSource;
        } catch (PropertyVetoException e) {
            e.printStackTrace();
        }

        return null;
    }
}