package bg.government.regixclient.app.config;

public interface RegixClientProxyConstants {

	String SPRING_PROFILE_UNIT_TEST = "utest";				// profile for unit tests
	String SPRING_PROFILE_DEBUG = "debug";					// profile for deployment to the test environment at 192.168.168.25
	String SPRING_PROFILE_PRODUCTION = "production";		// profile for deployment to the production environment at 192.168.168.28
	String SPRING_PROFILE_INTEGRATION_TEST = "itest";		// profile for integration testing to RegiX entry point
	
}
