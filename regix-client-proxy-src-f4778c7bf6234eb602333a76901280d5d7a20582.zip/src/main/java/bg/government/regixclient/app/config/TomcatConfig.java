package bg.government.regixclient.app.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TomcatConfig {

    private static final String PROTOCOL = "AJP/1.3";

    @Value("${tomcat.ajp.enabled}")
    private boolean tomcatAjpEnabled;

    @Value("${tomcat.ajp.port}")
    private int ajpPort;

    @Value("${tomcat.ajp.secure}")
    private boolean secure;

    @Value("${tomcat.ajp.scheme}")
    private String scheme;

    @Bean
    public ConfigurableServletWebServerFactory webServerFactory() {
        TomcatServletWebServerFactory factory = new TomcatServletWebServerFactory();
        if (tomcatAjpEnabled) {
            factory.setProtocol(PROTOCOL);

            factory.addConnectorCustomizers(connector -> {
                connector.setScheme(scheme);
                connector.setPort(ajpPort);
                connector.setSecure(secure);
            });
        }

        return factory;
    }
}