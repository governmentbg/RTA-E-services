package bg.government.regixclient.app.config.swagger;

import static com.google.common.base.Predicates.and;
import static springfox.documentation.builders.PathSelectors.regex;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fasterxml.classmate.TypeResolver;
import com.google.common.base.Predicate;

import bg.government.regixclient.app.RegixClientApplication;
import bg.government.regixclient.app.exceptions.dto.ApplicationExceptionDto;
import springfox.bean.validators.configuration.BeanValidatorPluginsConfiguration;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.service.VendorExtension;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
@Configuration
@Import(BeanValidatorPluginsConfiguration.class)
public class Swagger2Config {

	@Autowired
	private TypeResolver typeResolver;

	@Bean
	public Docket getSwaggerDocket() {
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.paths(getPaths())
				.build()
				.globalResponseMessage(RequestMethod.GET, getResponseMessagesForGet())
				.additionalModels(typeResolver.resolve(ApplicationExceptionDto.class))
				.apiInfo(getApiInfo());
	}

	private ApiInfo getApiInfo() {
		Package mainClassPackage = RegixClientApplication.class.getPackage();
		String title = mainClassPackage.getImplementationTitle();
		String description = "Exposes REST API endpoints for Soap RegiX Services.";
		String version = mainClassPackage.getImplementationVersion();
		String termsOfServiceUrl = null;
		Contact contact = null;
		String license = null;
		String licenseUrl = null;
		@SuppressWarnings("rawtypes")
		Collection<VendorExtension> vendorExtensions = Collections.emptyList();
		ApiInfo apiInfo = new ApiInfo(title, description, version, termsOfServiceUrl, contact, license, licenseUrl, vendorExtensions);

		return apiInfo;
	}

	@SuppressWarnings("unchecked")
	private Predicate<String> getPaths() {
		return and(
				regex("^((?!error).)*$"),
				regex("^((?!test).)*$"),
				regex("^((?!dummy).)*$")
				);
	}

	private List<ResponseMessage> getResponseMessagesForGet() {
		List<ResponseMessage> responseMessage = new ArrayList<ResponseMessage>();
		responseMessage.add(new ResponseMessageBuilder()
				.code(200)
				.message("200 success")
				.build()
		);

		responseMessage.add(new ResponseMessageBuilder()
				.code(400)
				.message("400 invalid parameters")
				.responseModel(new ModelRef(ApplicationExceptionDto.class.getSimpleName()))
				.build()
		);

		responseMessage.add(new ResponseMessageBuilder()
				.code(403)
				.message("403 forbidden")
				.responseModel(new ModelRef(ApplicationExceptionDto.class.getSimpleName()))
				.build()
		);

		responseMessage.add(new ResponseMessageBuilder()
				.code(409)
				.message("409 conflict occured")
				.responseModel(new ModelRef(ApplicationExceptionDto.class.getSimpleName()))
				.build()
		);

		responseMessage.add(new ResponseMessageBuilder()
				.code(422)
				.message("422 there was a problem while processing response from RegiX")
				.responseModel(new ModelRef(ApplicationExceptionDto.class.getSimpleName()))
				.build()
		);

		responseMessage.add(new ResponseMessageBuilder()
				.code(424)
				.message("424 error in communication with RegiX Service")
				.responseModel(new ModelRef(ApplicationExceptionDto.class.getSimpleName()))
				.build()
		);

		responseMessage.add(new ResponseMessageBuilder()
				.code(500)
				.message("500 internal server error")
				.responseModel(new ModelRef(ApplicationExceptionDto.class.getSimpleName()))
				.build()
		);

		return responseMessage;
	}
}

