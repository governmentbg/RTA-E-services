package bg.government.regixclient.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.regixclient.av.tr.actualstatev3.ActualStateRequestDto;
import bg.demax.regixclient.av.tr.actualstatev3.ActualStateResponseDto;
import bg.demax.regixclient.av.tr.uicvalidation.ValidUICIdentifierDto;
import bg.demax.regixclient.av.tr.uicvalidation.ValidUICInfoDto;
import bg.government.regixclient.app.service.RegixAvService;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/av")
public class RegixAvController {
	
	@Autowired
	private RegixAvService regixAvService;
	
	@PostMapping(value = "/tr/uic-info")
	@ApiOperation(value = "${tswag.RegixAvController.getValidUICInfo}")
	public ValidUICInfoDto getValidUICInfo(@Valid @RequestBody ValidUICIdentifierDto identifierDto, @RequestHeader HttpHeaders headers) 
			throws Exception {
		
		ValidUICInfoDto validUICInfoDto = regixAvService.getValidUICInfo(identifierDto, headers);
		
		return validUICInfoDto;
	}

	@PostMapping(value = "/tr/actual-state/v3")
	@ApiOperation(value = "${tswag.RegixAvController.getActualStateResponse}")
	public ActualStateResponseDto getActualStateResponse(@Valid @RequestBody ActualStateRequestDto actualStateRequestDto, @RequestHeader HttpHeaders headers) 
			throws Exception {

		ActualStateResponseDto actualStateResponse = regixAvService.getActualStateV3(actualStateRequestDto, headers);
		
		return actualStateResponse;
	}

}
