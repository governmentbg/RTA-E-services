package bg.government.regixclient.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.regixclient.mvr.bds.ForeignerIdentityDto;
import bg.demax.regixclient.mvr.bds.PersonalIdentityDto;
import bg.demax.regixclient.mvr.bds.PersonalResponseDto;
import bg.demax.regixclient.mvr.bds.PersonalResponseDtoV2;
import bg.demax.regixclient.mvr.bds.PersonalResponseDtoV3;
import bg.demax.regixclient.mvr.mpsv2.MotorVehicleIdentifierDto;
import bg.demax.regixclient.mvr.mpsv2.MotorVehicleRegistrationInfoDto;
import bg.government.regixclient.app.service.RegixMvrService;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/mvr")
public class RegixMvrController {
	
	@Autowired
    private RegixMvrService regixMvrService;

    @PostMapping(value = "/personal")
    @ApiOperation(value = "${tswag.RegixMvrController.getPersonalIdentityInfo}")
    public PersonalResponseDto getPersonalIdentityInfo(@Valid @RequestBody PersonalIdentityDto personalIdentity, @RequestHeader HttpHeaders headers) throws Exception {

        PersonalResponseDto personalIdentityResponseDto = regixMvrService.getPersonalIdentityInfo(personalIdentity, headers);

        return personalIdentityResponseDto;
    }

    @PostMapping(value = "/personal/v2")
    public PersonalResponseDtoV2 getPersonalIdentityInfoV2(@Valid @RequestBody PersonalIdentityDto personalIdentity, @RequestHeader HttpHeaders headers) throws Exception {

    	PersonalResponseDtoV2 personalIdentityResponseDto = regixMvrService.getPersonalIdentityInfoV2(personalIdentity, headers);

        return personalIdentityResponseDto;
    }

    @PostMapping(value = "/personal/v3")
    public PersonalResponseDtoV3 getPersonalIdentityInfoV3(@Valid @RequestBody PersonalIdentityDto personalIdentity, @RequestHeader HttpHeaders headers) throws Exception {

    	PersonalResponseDtoV3 personalIdentityResponseDto = regixMvrService.getPersonalIdentityInfoV3(personalIdentity, headers);

        return personalIdentityResponseDto;
    }

    @PostMapping(value = "/foreigner")
    @ApiOperation(value = "${tswag.RegixMvrController.getForeignerPersonalIdentityInfo}")
    public PersonalResponseDto getForeignerPersonalIdentityInfo(@Valid @RequestBody ForeignerIdentityDto foreignerIdentity, @RequestHeader HttpHeaders headers) throws Exception {

        PersonalResponseDto foreignerIdentityResponseDto = regixMvrService.getForeignerIdentityInfo(foreignerIdentity, headers);

        return foreignerIdentityResponseDto;
    }

    @PostMapping(value = "/motor-vehicle/v2")
    @ApiOperation(value = "${tswag.RegixMvrController.getMotorVehicleRegistrationInfo}")
    public MotorVehicleRegistrationInfoDto getMotorVehicleRegistrationInfo(
    		@Valid @RequestBody MotorVehicleIdentifierDto motorVehicleIdentifier, @RequestHeader HttpHeaders headers) throws Exception {
    	
    	MotorVehicleRegistrationInfoDto motorVehicleRegistrationInfoDto = regixMvrService
    			.getMotorVehicleRegistrationInfo(motorVehicleIdentifier, headers);
    	
    	return motorVehicleRegistrationInfoDto;
    }
    
}
