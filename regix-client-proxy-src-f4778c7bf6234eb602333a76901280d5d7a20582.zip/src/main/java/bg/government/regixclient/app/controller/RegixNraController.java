package bg.government.regixclient.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.regixclient.nra.employmentcontracts.EmploymentContractsIdentifierDto;
import bg.demax.regixclient.nra.employmentcontracts.EmploymentContractsInfoDto;
import bg.government.regixclient.app.service.RegixNraService;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/nra")
public class RegixNraController {
	
	@Autowired
	private RegixNraService regixNraService;

    @PostMapping(value = "/employment-contracts")
    @ApiOperation(value = "${tswag.RegixNraController.getEmploymentContractsInfo}")
    public EmploymentContractsInfoDto getEmploymentContractsInfo(
    		@Valid @RequestBody EmploymentContractsIdentifierDto employmentContractsIdentifier, @RequestHeader HttpHeaders headers) throws Exception {
    	
    	EmploymentContractsInfoDto employmentContractsInfoDto = regixNraService
    			.getEmploymentContractsInfo(employmentContractsIdentifier, headers);
    	
    	return employmentContractsInfoDto;
    }
}
