package bg.government.regixclient.app.converter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.regixclient.av.tr.actualstatev3.ActualStateResponseDto;
import bg.demax.regixclient.av.tr.actualstatev3.DeedStatusTypeDto;
import bg.demax.regixclient.av.tr.actualstatev3.DeedTypeDto;
import bg.demax.regixclient.av.tr.actualstatev3.FieldDto;
import bg.demax.regixclient.av.tr.actualstatev3.LegalFormTypeDto;
import bg.demax.regixclient.av.tr.actualstatev3.LiquidationOrInsolvencyDto;
import bg.demax.regixclient.av.tr.actualstatev3.RecordDto;
import bg.demax.regixclient.av.tr.actualstatev3.SubdeedDto;
import bg.demax.regixclient.av.tr.actualstatev3.SubdeedStatusTypeDto;
import bg.government.regixclient.app.utils.ConverterUtil;
import bg.government.regixclient.requests.av.tr.actualstatev3.ActualStateResponseV3;
import bg.government.regixclient.requests.av.tr.actualstatev3.DeedType;
import bg.government.regixclient.requests.av.tr.actualstatev3.Field;
import bg.government.regixclient.requests.av.tr.actualstatev3.Record;
import bg.government.regixclient.requests.av.tr.actualstatev3.Subdeed;

@Component
public class ActualStateResponseV3ToActualStateResponseDto implements Converter<ActualStateResponseV3, ActualStateResponseDto> {

	@Override
	public ActualStateResponseDto convert(ActualStateResponseV3 source) {
		ActualStateResponseDto dto = new ActualStateResponseDto();
		
		dto.setDataFound(source.isDataFound());
		if (source.getDataValidForDate() != null) {
			dto.setDataValidForDate(ConverterUtil.toLocalDate(source.getDataValidForDate()));
		}

		DeedType deedType = source.getDeed();
		if (deedType != null) {
			DeedTypeDto deedTypeDto = new DeedTypeDto();
			deedTypeDto.setCaseNo(deedType.getCaseNo());
			deedTypeDto.setCaseYear(deedType.getCaseYear());
			deedTypeDto.setCompanyName(deedType.getCompanyName());
			deedTypeDto.setCourtNo(deedType.getCourtNo());
			deedTypeDto.setGUID(deedType.getGUID());
			deedTypeDto.setUIC(deedType.getUIC());
			if (deedType.getDeedStatus() != null) {
				deedTypeDto.setDeedStatus(DeedStatusTypeDto.fromValue(deedType.getDeedStatus().value()));
			}
			if (deedType.getLegalForm() != null) {
				deedTypeDto.setLegalForm(LegalFormTypeDto.fromValue(deedType.getLegalForm().value()));
			}
			if (deedType.getLiquidationOrInsolvency() != null) {
				deedTypeDto.setLiquidationOrInsolvency(LiquidationOrInsolvencyDto.fromValue(deedType.getLiquidationOrInsolvency().value()));
			}
			
			if (deedType.getSubdeeds() != null && deedType.getSubdeeds().getSubdeed() != null) {
				List<SubdeedDto> subdeedDtoList = new ArrayList<SubdeedDto>();
				for (Subdeed subdeed : deedType.getSubdeeds().getSubdeed()) {
					SubdeedDto subdeedDto = new SubdeedDto();
					if (subdeed.getSubdeedStatus() != null) {
						subdeedDto.setSubdeedStatus(SubdeedStatusTypeDto.fromValue(subdeed.getSubdeedStatus().value()));
					}
					subdeedDto.setSubUIC(subdeed.getSubUIC());
					subdeedDto.setSubUICName(subdeed.getSubUICName());
					subdeedDto.setSubUICType(subdeed.getSubUICType());
					
					if (subdeed.getRecords() != null && subdeed.getRecords().getRecord() != null) {
						List<RecordDto> recordDtoList = new ArrayList<RecordDto>();
						for (Record record : subdeed.getRecords().getRecord()) {
							RecordDto recordDto = new RecordDto();
							if (record.getFieldActionDate() != null) {
								recordDto.setFieldActionDate(ConverterUtil.toLocalDate(record.getFieldActionDate()));
							}
							recordDto.setFieldEntryNumber(record.getFieldEntryNumber());
							recordDto.setFieldIdent(record.getFieldIdent());
							recordDto.setIncomingId(record.getIncomingId());
							recordDto.setRecordData(record.getRecordData());
							recordDto.setRecordId(record.getRecordId());
							if (record.getMainField() != null) {
								Field field = record.getMainField();
								FieldDto fieldDto = new FieldDto();
								fieldDto.setGroupId(field.getGroupId());
								fieldDto.setGroupName(field.getGroupName());
								fieldDto.setMainFieldCode(field.getMainFieldCode());
								fieldDto.setMainFieldIdent(field.getMainFieldIdent());
								fieldDto.setMainFieldName(field.getMainFieldName());
								fieldDto.setSectionId(field.getSectionId());
								fieldDto.setSectionName(field.getSectionName());
								
								recordDto.setMainField(fieldDto);
							}
							recordDtoList.add(recordDto);
						}
						subdeedDto.setRecords(recordDtoList);
					}
					subdeedDtoList.add(subdeedDto);
				}
				deedTypeDto.setSubdeeds(subdeedDtoList);
			}
			
			dto.setDeed(deedTypeDto);
		}
		
		return dto;
	}
}
