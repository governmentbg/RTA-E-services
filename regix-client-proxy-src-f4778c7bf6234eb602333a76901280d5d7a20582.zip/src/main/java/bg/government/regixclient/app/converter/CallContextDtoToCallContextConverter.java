package bg.government.regixclient.app.converter;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.regixclient.mvr.bds.CallContextDto;
import bg.government.regixclient.requests.CallContext;

@Component
public class CallContextDtoToCallContextConverter implements Converter<CallContextDto, CallContext>{
	
	@Override
	public CallContext convert(CallContextDto ccDto) {
		CallContext callContext = new CallContext();

        callContext.setAdministrationName(new JAXBElement<>(new QName("http://tempuri.org/", "AdministrationName"),
                        String.class, ccDto.getAdministrationName()));
        callContext.setAdministrationOId(new JAXBElement<>(new QName("http://tempuri.org/", "administrationOId"),
                        String.class, ccDto.getAdministrationOId()));
        callContext.setEmployeeIdentifier(new JAXBElement<>(new QName("http://tempuri.org/", "EmployeeIdentifier"),
                        String.class, ccDto.getEmployeeIdentifier()));
        callContext.setEmployeeNames(new JAXBElement<>(new QName("http://tempuri.org/", "EmployeeNames"),
                        String.class, ccDto.getEmployeeNames()));
        callContext.setEmployeePosition(new JAXBElement<>(new QName("http://tempuri.org/", "EmployeePosition"),
                        String.class, ccDto.getEmployeePosition()));
        callContext.setLawReason(ccDto.getLawReason());
        callContext.setServiceType(ccDto.getServiceType());
        callContext.setServiceURI(ccDto.getServiceURI());
        return callContext;
	}

}
