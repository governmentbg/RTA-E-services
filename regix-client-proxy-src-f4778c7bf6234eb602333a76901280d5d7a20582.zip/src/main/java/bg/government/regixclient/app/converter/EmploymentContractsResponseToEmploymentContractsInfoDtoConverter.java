package bg.government.regixclient.app.converter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.regixclient.nra.employmentcontracts.ContractsFilterTypeDto;
import bg.demax.regixclient.nra.employmentcontracts.EContractDto;
import bg.demax.regixclient.nra.employmentcontracts.EContractsDto;
import bg.demax.regixclient.nra.employmentcontracts.EikTypeTypeDto;
import bg.demax.regixclient.nra.employmentcontracts.EmploymentContractsInfoDto;
import bg.demax.regixclient.nra.employmentcontracts.ResponseIdentityTypeDto;
import bg.demax.regixclient.nra.employmentcontracts.StatusTypeDto;
import bg.government.regixclient.app.utils.ConverterUtil;
import bg.government.regixclient.requests.nra.employmentcontracts.EContract;
import bg.government.regixclient.requests.nra.employmentcontracts.EmploymentContractsResponse;
import bg.government.regixclient.requests.nra.employmentcontracts.ResponseIdentityType;
import bg.government.regixclient.requests.nra.employmentcontracts.StatusType;

@Component
public class EmploymentContractsResponseToEmploymentContractsInfoDtoConverter
		implements Converter<EmploymentContractsResponse, EmploymentContractsInfoDto> {

	@Override
	public EmploymentContractsInfoDto convert(EmploymentContractsResponse source) {
		EmploymentContractsInfoDto employmentContractsInfoDto = new EmploymentContractsInfoDto();

		if (source.getContractsFilter() != null) {
			employmentContractsInfoDto
					.setContractsFilter(ContractsFilterTypeDto.fromValue(source.getContractsFilter().value()));
		}

		employmentContractsInfoDto.setReportDate(ConverterUtil.toLocalDate(source.getReportDate()));

		List<EContract> eContracts = source.getEContracts().getEContract();

		if (eContracts != null) {

			List<EContractDto> eContractDtos = new ArrayList<EContractDto>();

			for (EContract eContract : eContracts) {
				EContractDto eContractDto = new EContractDto();

				eContractDto.setContractorBulstat(eContract.getContractorBulstat());
				eContractDto.setContractorName(eContract.getContractorName());
				eContractDto.setEcoCode(eContract.getEcoCode());
				eContractDto.setEkatteCode(eContract.getEKATTECode());
				eContractDto.setEndDate(ConverterUtil.toLocalDate(eContract.getEndDate()));
				eContractDto.setIndividualEIK(eContract.getIndividualEIK());
				eContractDto.setIndividualNames(eContract.getIndividualNames());
				eContractDto.setLastAmendDate(ConverterUtil.toLocalDate(eContract.getLastAmendDate()));
				eContractDto.setProfessionCode(eContract.getProfessionCode());
				eContractDto.setProfessionName(eContract.getProfessionName());
				eContractDto.setReason(eContract.getReason());
				eContractDto.setRemuneration(eContract.getRemuneration());
				eContractDto.setStartDate(ConverterUtil.toLocalDate(eContract.getStartDate()));
				eContractDto.setTimeLimit(ConverterUtil.toLocalDate(eContract.getTimeLimit()));

				eContractDtos.add(eContractDto);
			}

			EContractsDto eContractsDto = new EContractsDto();
			eContractsDto.seteContract(eContractDtos);
			employmentContractsInfoDto.seteContracts(eContractsDto);
		}

		ResponseIdentityType identityType = source.getIdentity();
		if (identityType != null) {
			ResponseIdentityTypeDto identity = new ResponseIdentityTypeDto();
			identity.setId(identityType.getID());
			identity.setType(EikTypeTypeDto.fromValue(identityType.getTYPE().value()));
			employmentContractsInfoDto.setIdentity(identity);

		}

		StatusType statusType = source.getStatus();
		if (statusType != null) {
			StatusTypeDto status = new StatusTypeDto();
			status.setCode(statusType.getCode());
			status.setMessage(statusType.getMessage());
			employmentContractsInfoDto.setStatus(status);

		}

		return employmentContractsInfoDto;
	}

}
