package bg.government.regixclient.app.converter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.regixclient.mvr.bds.ReturnInformation;
import bg.demax.regixclient.mvr.mpsv2.MotorVehicleRegistrationInfoDto;
import bg.demax.regixclient.mvr.mpsv2.OwnerTypeDto;
import bg.demax.regixclient.mvr.mpsv2.OwnersDataTypeDto;
import bg.demax.regixclient.mvr.mpsv2.ResultDto;
import bg.demax.regixclient.mvr.mpsv2.ResultsDto;
import bg.demax.regixclient.mvr.mpsv2.UsersDataTypeDto;
import bg.demax.regixclient.mvr.mpsv2.VehicleDataTypeDto;
import bg.government.regixclient.app.utils.ConverterUtil;
import bg.government.regixclient.requests.mvr.mpsv2.GetMotorVehicleRegistrationInfoV2ResponseType;
import bg.government.regixclient.requests.mvr.mpsv2.GetMotorVehicleRegistrationInfoV2ResponseType.Response;
import bg.government.regixclient.requests.mvr.mpsv2.GetMotorVehicleRegistrationInfoV2ResponseType.Response.Results;
import bg.government.regixclient.requests.mvr.mpsv2.GetMotorVehicleRegistrationInfoV2ResponseType.Response.Results.Result;
import bg.government.regixclient.requests.mvr.mpsv2.OwnerType;
import bg.government.regixclient.requests.mvr.mpsv2.OwnersDataType;
import bg.government.regixclient.requests.mvr.mpsv2.ReturnInformationType;
import bg.government.regixclient.requests.mvr.mpsv2.UsersDataType;
import bg.government.regixclient.requests.mvr.mpsv2.VehicleDataType;

@Component
public class GetMotorVehicleRegistrationInfoV2ResponseTypeToMotorVehicleRegistrationInfoDtoConverter 
	implements Converter<GetMotorVehicleRegistrationInfoV2ResponseType, MotorVehicleRegistrationInfoDto> {
	
	@Autowired
	@Lazy
	private AppConversionService conversionService;

	@Override
	public MotorVehicleRegistrationInfoDto convert(GetMotorVehicleRegistrationInfoV2ResponseType info) {
		MotorVehicleRegistrationInfoDto dto = new MotorVehicleRegistrationInfoDto();
    	
    	Response response = info.getResponse();
    	ReturnInformationType returnInfo = response.getReturnInformation();
    	
		if (returnInfo != null) {
			ReturnInformation returnInformation = new ReturnInformation();	
			returnInformation.setInfo(returnInfo.getInfo());
			returnInformation.setReturnCode(returnInfo.getReturnCode());
			dto.setReturnInformation(returnInformation);
		}
		 
		Results results = response.getResults();
		
		if (results != null) {
			List<ResultDto> resultDtos = new ArrayList<ResultDto>();

			for (Result result : results.getResult()) {
				ResultDto resultDto = new ResultDto();
				
				OwnersDataType ownersDataType = result.getOwnersData();				
				
				if (ownersDataType != null) {
					OwnersDataTypeDto ownersDataTypeDto = new OwnersDataTypeDto();
					List<OwnerTypeDto> ownerTypeDtos = new ArrayList<OwnerTypeDto>();
					
					for (OwnerType ownerType: ownersDataType.getOwner()) {
						OwnerTypeDto ownerTypeDto = conversionService.convert(ownerType, OwnerTypeDto.class);
						ownerTypeDtos.add(ownerTypeDto);
					}
					
					ownersDataTypeDto.setOwner(ownerTypeDtos);
					resultDto.setOwnersData(ownersDataTypeDto);
				}				
				
				List<UsersDataType> usersDataTypes = result.getUsersData();
				if (usersDataTypes != null) {
					List<UsersDataTypeDto> usersDataTypeDtos = new ArrayList<UsersDataTypeDto>();
					for (UsersDataType usersDataType : usersDataTypes) {
						UsersDataTypeDto usersDataTypeDto = new UsersDataTypeDto();
						OwnerTypeDto ownerTypeDto = conversionService.convert(usersDataType.getUser(), OwnerTypeDto.class);
						usersDataTypeDto.setUser(ownerTypeDto);
						usersDataTypeDtos.add(usersDataTypeDto);
					}
					resultDto.setUsersData(usersDataTypeDtos);
				}		
				
				VehicleDataType vehicleDataType = result.getVehicleData();
				if (vehicleDataType != null) {
					VehicleDataTypeDto vehicleDataTypeDto = new VehicleDataTypeDto();

					vehicleDataTypeDto.setCategory(vehicleDataType.getCategory());
					vehicleDataTypeDto.setEnvironmentalCategory(vehicleDataType.getEnvironmentalCategory());
					vehicleDataTypeDto.setFirstRegistrationDate(ConverterUtil.toLocalDate(vehicleDataType.getFirstRegistrationDate()));
					vehicleDataTypeDto.setMassF1(vehicleDataType.getMassF1());
					vehicleDataTypeDto.setMassG(vehicleDataType.getMassG());
					vehicleDataTypeDto.setRegistrationNumber(vehicleDataType.getRegistrationNumber());
					vehicleDataTypeDto.setVehicleType(vehicleDataType.getVehicleType());
					vehicleDataTypeDto.setVin(vehicleDataType.getVIN());
					
					resultDto.setVehicleData(vehicleDataTypeDto);
				}		
				
				resultDtos.add(resultDto);
			}
			
			ResultsDto resultsDto = new ResultsDto();
			resultsDto.setResult(resultDtos);
			dto.setResults(resultsDto);
		}			
		 
		return dto;
	}

}
