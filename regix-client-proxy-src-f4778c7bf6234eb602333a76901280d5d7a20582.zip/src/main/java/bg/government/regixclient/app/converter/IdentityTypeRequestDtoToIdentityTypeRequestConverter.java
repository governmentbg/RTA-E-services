package bg.government.regixclient.app.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.regixclient.nra.employmentcontracts.IdentityTypeRequestDto;
import bg.government.regixclient.requests.nra.employmentcontracts.EikTypeType;
import bg.government.regixclient.requests.nra.employmentcontracts.IdentityTypeRequest;
import bg.government.regixclient.requests.nra.employmentcontracts.ObjectFactory;

@Component
public class IdentityTypeRequestDtoToIdentityTypeRequestConverter implements Converter<IdentityTypeRequestDto, IdentityTypeRequest>{

	@Autowired
	private ObjectFactory ecObjectFactory;
	
	@Override
	public IdentityTypeRequest convert(IdentityTypeRequestDto source) {
		IdentityTypeRequest identityTypeRequest = ecObjectFactory.createIdentityTypeRequest();
		
		identityTypeRequest.setID(source.getId());
		
		if (source.getType() != null) {
			identityTypeRequest.setTYPE(EikTypeType.fromValue(source.getType().value()));
		}
		
		return identityTypeRequest;
	}

}
