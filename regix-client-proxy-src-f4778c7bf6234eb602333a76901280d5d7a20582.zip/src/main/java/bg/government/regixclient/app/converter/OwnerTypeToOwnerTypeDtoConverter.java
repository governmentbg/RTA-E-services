package bg.government.regixclient.app.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.regixclient.mvr.mpsv2.BGTypeDto;
import bg.demax.regixclient.mvr.mpsv2.BGTypeNamesDto;
import bg.demax.regixclient.mvr.mpsv2.CompanyTypeDto;
import bg.demax.regixclient.mvr.mpsv2.FCTypeDto;
import bg.demax.regixclient.mvr.mpsv2.OwnerTypeDto;
import bg.government.regixclient.requests.mvr.mpsv2.BGType;
import bg.government.regixclient.requests.mvr.mpsv2.CompanyType;
import bg.government.regixclient.requests.mvr.mpsv2.FCType;
import bg.government.regixclient.requests.mvr.mpsv2.OwnerType;

@Component
public class OwnerTypeToOwnerTypeDtoConverter implements Converter<OwnerType, OwnerTypeDto>{

	@Override
	public OwnerTypeDto convert(OwnerType ownerType) {
    	OwnerTypeDto ownerTypeDto = new OwnerTypeDto();			
		
		BGType bgType = ownerType.getBulgarianCitizen();
		BGTypeDto bgTypeDto = new BGTypeDto();
		
		if (bgType != null) {
			bgTypeDto.setPin(bgType.getPIN());
			
			BGTypeNamesDto bgTypeNamesDto = new BGTypeNamesDto();
			bgTypeNamesDto.setFirst(bgType.getNames().getFirst());
			bgTypeNamesDto.setSurname(bgType.getNames().getSurname());
			bgTypeNamesDto.setFamily(bgType.getNames().getFamily());
			
			bgTypeDto.setNames(bgTypeNamesDto);
		}		
		
		ownerTypeDto.setBulgarianCitizen(bgTypeDto);

		CompanyType companyType = ownerType.getCompany();
		CompanyTypeDto companyTypeDto = new CompanyTypeDto();
		
		if (companyType != null) {
			companyTypeDto.setId(companyType.getID());
			companyTypeDto.setName(companyType.getName());
			companyTypeDto.setNameLatin(companyType.getNameLatin());
		}		
		
		ownerTypeDto.setCompany(companyTypeDto);

		FCType fcType = ownerType.getForeignCitizen();
		FCTypeDto fcTypeDto = new FCTypeDto();
		
		if (fcType != null) {
			fcTypeDto.setPin(fcType.getPIN());
			fcTypeDto.setPn(fcType.getPN());
			fcTypeDto.setNationality(fcType.getNationality());
			fcTypeDto.setNamesCyrillic(fcType.getNamesCyrillic());
			fcTypeDto.setNamesLatin(fcType.getNamesLatin());
		}
		
		ownerTypeDto.setForeignCitizen(fcTypeDto);			
		
		return ownerTypeDto;
	}

}
