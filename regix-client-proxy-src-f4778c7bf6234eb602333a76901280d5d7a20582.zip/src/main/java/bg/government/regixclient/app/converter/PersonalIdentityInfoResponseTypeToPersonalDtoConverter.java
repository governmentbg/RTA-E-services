package bg.government.regixclient.app.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.regixclient.mvr.bds.PersonNamesDto;
import bg.demax.regixclient.mvr.bds.PersonalResponseDto;
import bg.demax.regixclient.mvr.bds.ReturnInformation;
import bg.government.regixclient.app.utils.ConverterUtil;
import bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoResponseType;

@Component
public class PersonalIdentityInfoResponseTypeToPersonalDtoConverter
		implements Converter<PersonalIdentityInfoResponseType, PersonalResponseDto> {

	@Override
	public PersonalResponseDto convert(PersonalIdentityInfoResponseType info) {
		PersonalResponseDto dto = new PersonalResponseDto();
		dto.setPicture(info.getPicture());
		dto.setIsValid(true);
		dto.setValidUntil(ConverterUtil.toLocalDate(info.getValidDate()));

		ReturnInformation returnInformation = new ReturnInformation();

		if (info.getReturnInformations() != null) {
			returnInformation.setInfo(info.getReturnInformations().getInfo());
			returnInformation.setReturnCode(info.getReturnInformations().getReturnCode());
		}

		dto.setReturnInformation(returnInformation);

		if (info.getPersonNames() != null) {
			PersonNamesDto personNamesDto = new PersonNamesDto();
			personNamesDto.setFirstName(info.getPersonNames().getFirstName());
			personNamesDto.setSurname(info.getPersonNames().getSurname());
			personNamesDto.setFamilyName(info.getPersonNames().getFamilyName());
			dto.setPersonNames(personNamesDto);
		}

		return dto;
	}

}
