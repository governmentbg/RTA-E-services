package bg.government.regixclient.app.converter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.regixclient.mvr.bds.DLCategoryDto;
import bg.demax.regixclient.mvr.bds.PersonalResponseDtoV2;
import bg.demax.regixclient.mvr.bds.ReturnInformation;
import bg.government.regixclient.app.utils.ConverterUtil;
import bg.government.regixclient.requests.mvr.bds.DLCategory;
import bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoResponseType;

@Component
public class PersonalIdentityInfoResponseTypeToPersonalResponseDtoV2Converter
		implements Converter<PersonalIdentityInfoResponseType, PersonalResponseDtoV2> {

	@Override
	public PersonalResponseDtoV2 convert(PersonalIdentityInfoResponseType from) {
		PersonalResponseDtoV2 dto = new PersonalResponseDtoV2();

		dto.setDlCommonRestrictions(from.getDLCommonRestrictions());

		if (from.getDLCategоries() != null && from.getDLCategоries().getDLCategory() != null) {
			List<DLCategoryDto> dlCategories = new ArrayList<DLCategoryDto>();
			for (DLCategory fromCategory : from.getDLCategоries().getDLCategory()) {
				DLCategoryDto dlCategoryDto = new DLCategoryDto();
				dlCategoryDto.setCategory(fromCategory.getCategory());
				dlCategoryDto.setDateCategory(ConverterUtil.toLocalDate(fromCategory.getDateCategory()));
				dlCategoryDto.setEndDateCategory(ConverterUtil.toLocalDate(fromCategory.getEndDateCategory()));
				dlCategoryDto.setRestrictions(fromCategory.getRestrictions());

				dlCategories.add(dlCategoryDto);
			}
			dto.setDlCategоries(dlCategories);
		}

		ReturnInformation returnInformation = new ReturnInformation();

		if (from.getReturnInformations() != null) {
			returnInformation.setInfo(from.getReturnInformations().getInfo());
			returnInformation.setReturnCode(from.getReturnInformations().getReturnCode());
		}

		dto.setReturnInformation(returnInformation);

		return dto;
	}
}
