package bg.government.regixclient.app.converter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.regixclient.mvr.bds.BirthPlaceDto;
import bg.demax.regixclient.mvr.bds.DLCategoryDto;
import bg.demax.regixclient.mvr.bds.ForeignCitizenTypeDto;
import bg.demax.regixclient.mvr.bds.GenderTypeDto;
import bg.demax.regixclient.mvr.bds.NationalityDto;
import bg.demax.regixclient.mvr.bds.NationalityListDto;
import bg.demax.regixclient.mvr.bds.PermanentAddressDto;
import bg.demax.regixclient.mvr.bds.PersonNamesDto;
import bg.demax.regixclient.mvr.bds.PersonalResponseDtoV3;
import bg.demax.regixclient.mvr.bds.RPRemarkTypeDto;
import bg.demax.regixclient.mvr.bds.ReturnInformation;
import bg.government.regixclient.app.utils.ConverterUtil;
import bg.government.regixclient.requests.mvr.bds.DLCategory;
import bg.government.regixclient.requests.mvr.bds.Nationality;
import bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoResponseType;

@Component
public class PersonalIdentityInfoResponseTypeToPersonalResponseDtoV3Converter
		implements Converter<PersonalIdentityInfoResponseType, PersonalResponseDtoV3> {

	@Override
	public PersonalResponseDtoV3 convert(PersonalIdentityInfoResponseType from) {
		PersonalResponseDtoV3 dto = new PersonalResponseDtoV3();

		dto.setDlCommonRestrictions(from.getDLCommonRestrictions());

		if (from.getDLCategоries() != null && from.getDLCategоries().getDLCategory() != null) {
			List<DLCategoryDto> dlCategories = new ArrayList<DLCategoryDto>();
			for (DLCategory fromCategory : from.getDLCategоries().getDLCategory()) {
				DLCategoryDto dlCategoryDto = new DLCategoryDto();
				dlCategoryDto.setCategory(fromCategory.getCategory());
				dlCategoryDto.setDateCategory(ConverterUtil.toLocalDate(fromCategory.getDateCategory()));
				dlCategoryDto.setEndDateCategory(ConverterUtil.toLocalDate(fromCategory.getEndDateCategory()));
				dlCategoryDto.setRestrictions(fromCategory.getRestrictions());

				dlCategories.add(dlCategoryDto);
			}
			dto.setDlCategоries(dlCategories);
		}

		ReturnInformation returnInformation = new ReturnInformation();

		if (from.getReturnInformations() != null) {
			returnInformation.setInfo(from.getReturnInformations().getInfo());
			returnInformation.setReturnCode(from.getReturnInformations().getReturnCode());
		}

		dto.setReturnInformation(returnInformation);

		if (from.getPersonNames() != null) {
			PersonNamesDto personNamesDto = new PersonNamesDto();
			personNamesDto.setFirstName(from.getPersonNames().getFirstName());
			personNamesDto.setSurname(from.getPersonNames().getSurname());
			personNamesDto.setFamilyName(from.getPersonNames().getFamilyName());
			dto.setPersonNames(personNamesDto);
		}

		if (from.getRPRemarks() != null && from.getRPRemarks().getRPRemark() != null) {
			RPRemarkTypeDto rpRemarkTypeDto = new RPRemarkTypeDto();
			List<String> rpRemarkDto = new ArrayList<String>();
			for (String rpRemakr : from.getRPRemarks().getRPRemark()) {
				rpRemarkDto.add(rpRemakr);
			}
			dto.setRpRemarks(rpRemarkTypeDto);
		}

		if (from.getNationalityList() != null && from.getNationalityList().getNationality() != null) {
			NationalityListDto nationalityListDto = new NationalityListDto();
			List<NationalityDto> nationalities = new ArrayList<NationalityDto>();
			for (Nationality fromNationality : from.getNationalityList().getNationality()) {
				NationalityDto nationalityDto = new NationalityDto();
				nationalityDto.setNationalityCode(fromNationality.getNationalityCode());
				nationalityDto.setNationalityName(fromNationality.getNationalityName());
				nationalityDto.setNationalityNameLatin(fromNationality.getNationalityNameLatin());
				nationalities.add(nationalityDto);
			}
			nationalityListDto.setNationality(nationalities);
			dto.setNationalityList(nationalityListDto);
		}

		if (from.getPermanentAddress() != null) {
			PermanentAddressDto permanentAddressDto = new PermanentAddressDto();
			permanentAddressDto.setDistrictName(from.getPermanentAddress().getDistrictName());
			permanentAddressDto.setDistrictNameLatin(from.getPermanentAddress().getDistrictNameLatin());
			permanentAddressDto.setMunicipalityName(from.getPermanentAddress().getMunicipalityName());
			permanentAddressDto.setMunicipalityNameLatin(from.getPermanentAddress().getMunicipalityNameLatin());
			permanentAddressDto.setSettlementCode(from.getPermanentAddress().getSettlementCode());
			permanentAddressDto.setSettlementName(from.getPermanentAddress().getSettlementName());
			permanentAddressDto.setSettlementNameLatin(from.getPermanentAddress().getSettlementNameLatin());
			permanentAddressDto.setLocationCode(from.getPermanentAddress().getLocationCode());
			permanentAddressDto.setLocationName(from.getPermanentAddress().getLocationName());
			permanentAddressDto.setLocationNameLatin(from.getPermanentAddress().getLocationNameLatin());
			permanentAddressDto.setBuildingNumber(from.getPermanentAddress().getBuildingNumber());
			permanentAddressDto.setEntrance(from.getPermanentAddress().getEntrance());
			permanentAddressDto.setFloor(from.getPermanentAddress().getFloor());
			permanentAddressDto.setApartment(from.getPermanentAddress().getApartment());
			dto.setPermanentAddress(permanentAddressDto);
		}

		if (from.getBirthPlace() != null) {
			BirthPlaceDto birthPlaceDto = new BirthPlaceDto();
			birthPlaceDto.setCountryCode(from.getBirthPlace().getCountryCode());
			birthPlaceDto.setCountryName(from.getBirthPlace().getCountryName());
			birthPlaceDto.setCountryNameLatin(from.getBirthPlace().getCountryNameLatin());
			birthPlaceDto.setDistrictName(from.getBirthPlace().getDistrictName());
			birthPlaceDto.setMunicipalityName(from.getBirthPlace().getMunicipalityName());
			birthPlaceDto.setTerritorialUnitName(from.getBirthPlace().getTerritorialUnitName());
			dto.setBirthPlace(birthPlaceDto);
		}

		if (from.getDataForeignCitizen() != null) {
			ForeignCitizenTypeDto foreignCitizenTypeDto = new ForeignCitizenTypeDto();
			foreignCitizenTypeDto.setPin(from.getDataForeignCitizen().getPIN());
			foreignCitizenTypeDto.setPn(from.getDataForeignCitizen().getPN());
			foreignCitizenTypeDto.setBirthDate(ConverterUtil.toLocalDate(from.getDataForeignCitizen().getBirthDate()));
			if (from.getDataForeignCitizen().getNames() != null) {
				PersonNamesDto personNamesDto = new PersonNamesDto();
				personNamesDto.setFirstName(from.getDataForeignCitizen().getNames().getFirstName());
				personNamesDto.setSurname(from.getDataForeignCitizen().getNames().getSurname());
				personNamesDto.setFamilyName(from.getDataForeignCitizen().getNames().getFamilyName());
				foreignCitizenTypeDto.setNames(personNamesDto);
			}
			if (from.getDataForeignCitizen().getGender() != null) {
				GenderTypeDto genderTypeDto = new GenderTypeDto();
				genderTypeDto.setCyrillic(from.getDataForeignCitizen().getGender().getCyrillic());
				genderTypeDto.setGenderCode(from.getDataForeignCitizen().getGender().getGenderCode());
				genderTypeDto.setLatin(from.getDataForeignCitizen().getGender().getLatin());
				foreignCitizenTypeDto.setGender(genderTypeDto);
			}
			if (from.getDataForeignCitizen().getNationalityList() != null
					&& from.getDataForeignCitizen().getNationalityList().getNationality() != null) {
				NationalityListDto nationalityListDto = new NationalityListDto();
				List<NationalityDto> nationalities = new ArrayList<NationalityDto>();
				for (Nationality fromNationality : from.getDataForeignCitizen().getNationalityList().getNationality()) {
					NationalityDto nationalityDto = new NationalityDto();
					nationalityDto.setNationalityCode(fromNationality.getNationalityCode());
					nationalityDto.setNationalityName(fromNationality.getNationalityName());
					nationalityDto.setNationalityNameLatin(fromNationality.getNationalityNameLatin());
					nationalities.add(nationalityDto);
				}
				nationalityListDto.setNationality(nationalities);
				foreignCitizenTypeDto.setNationalityList(nationalityListDto);
				;
			}
			dto.setDataForeignCitizen(foreignCitizenTypeDto);
		}

		dto.setEgn(from.getEGN());
		dto.setRpTypeofPermit(from.getRPTypeofPermit());
		dto.setDocumentType(from.getDocumentType());
		dto.setDocumentTypeLatin(from.getDocumentTypeLatin());
		dto.setDocumentActualStatus(from.getDocumentActualStatus());
		dto.setActualStatusDate(ConverterUtil.toLocalDate(from.getActualStatusDate()));
		dto.setDocumentStatusReason(from.getDocumentStatusReason());
		dto.setIdentityDocumentNumber(from.getIdentityDocumentNumber());
		dto.setIssueDate(ConverterUtil.toLocalDate(from.getIssueDate()));
		dto.setIssuerPlace(from.getIssuerPlace());
		dto.setIssuerPlaceLatin(from.getIssuerPlaceLatin());
		dto.setIssuerName(from.getIssuerName());
		dto.setIssuerNameLatin(from.getIssuerNameLatin());
		dto.setValidDate(ConverterUtil.toLocalDate(from.getValidDate()));
		dto.setBirthDate(ConverterUtil.toLocalDate(from.getBirthDate()));
		dto.setGenderName(from.getGenderName());
		dto.setGenderNameLatin(from.getGenderNameLatin());
		dto.setHeight(from.getHeight());
		dto.setEyesColor(from.getEyesColor());
		dto.setIdentitySignature(from.getIdentitySignature());
		dto.setPicture(from.getPicture());

		dto.setValidUntil(ConverterUtil.toLocalDate(from.getValidDate()));

		return dto;
	}
}
