package bg.government.regixclient.app.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.regixclient.av.tr.uicvalidation.LegalFormTypeDto;
import bg.demax.regixclient.av.tr.uicvalidation.StatusTypeDto;
import bg.demax.regixclient.av.tr.uicvalidation.ValidUICInfoDto;
import bg.government.regixclient.app.utils.ConverterUtil;
import bg.government.regixclient.requests.av.tr.uicvalidation.ValidUICResponseType;

@Component
public class ValidUICResponseTypeToValidUICInfoDtoConverter implements Converter<ValidUICResponseType, ValidUICInfoDto> {

	@Override
	public ValidUICInfoDto convert(ValidUICResponseType source) {
		ValidUICInfoDto dto = new ValidUICInfoDto();
		
		dto.setUic(source.getUIC());
		dto.setCompany(source.getCompany());		
		dto.setDataValidForDate(ConverterUtil.toLocalDate(source.getDataValidForDate()));	
		
		if (source.getStatus() != null) {
			dto.setStatus(StatusTypeDto.fromValue(source.getStatus().value()));
		}		
		
		if (source.getLegalForm() != null) {
			LegalFormTypeDto legalFormTypeDto = new LegalFormTypeDto();
			legalFormTypeDto.setLegalFormAbbr(source.getLegalForm().getLegalFormAbbr());
			legalFormTypeDto.setLegalFormName(source.getLegalForm().getLegalFormName());
			dto.setLegalForm(legalFormTypeDto);
		}
		
		return dto;
	}

}
