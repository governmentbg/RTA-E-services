package bg.government.regixclient.app.dto;

public class CurrentUserDto {
	public String clientName;
	public String outgoingClientCertificateFileName;

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getOutgoingClientCertificateFileName() {
		return outgoingClientCertificateFileName;
	}

	public void setOutgoingClientCertificateFileName(String outgoingClientCertificateFileName) {
		this.outgoingClientCertificateFileName = outgoingClientCertificateFileName;
	}

}
