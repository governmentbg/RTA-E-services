package bg.government.regixclient.app.exceptions;

public class ApplicationException extends RuntimeException {

	private static final long serialVersionUID = -9142354574390571892L;
	
	public ApplicationException() {
		super();
	}
	
	public ApplicationException(String message) {
		super(message);
	}
	
	public ApplicationException(String message, Object... args) {
		super(String.format(message, args));
	}

	public ApplicationException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public ApplicationException(Throwable cause) {
		super(cause);
	}
	
}
