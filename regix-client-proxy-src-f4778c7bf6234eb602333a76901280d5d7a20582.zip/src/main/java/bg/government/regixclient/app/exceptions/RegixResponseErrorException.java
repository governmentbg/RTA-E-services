package bg.government.regixclient.app.exceptions;

public class RegixResponseErrorException extends ApplicationException {

    private static final long serialVersionUID = -2091068576666233134L;

    public RegixResponseErrorException() {
        super();
    }   

    public RegixResponseErrorException(final String message) {
        super(message);
    }

    public RegixResponseErrorException(final Throwable cause) {
        super(cause);
    }
    
    public RegixResponseErrorException(final String message, final Throwable cause) {
        super(message, cause);
    }
    
}
