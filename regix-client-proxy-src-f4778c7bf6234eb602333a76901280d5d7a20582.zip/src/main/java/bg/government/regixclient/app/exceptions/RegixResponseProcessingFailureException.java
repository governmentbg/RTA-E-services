package bg.government.regixclient.app.exceptions;

public class RegixResponseProcessingFailureException extends ApplicationException {

	private static final long serialVersionUID = 1277676991479106938L;

	public RegixResponseProcessingFailureException(String msg) {
		super(msg);
	}
	
	public RegixResponseProcessingFailureException(Throwable cause) {
		super(cause);
	}
	
}
