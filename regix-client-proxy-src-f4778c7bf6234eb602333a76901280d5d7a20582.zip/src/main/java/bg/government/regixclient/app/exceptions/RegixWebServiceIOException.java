package bg.government.regixclient.app.exceptions;

public class RegixWebServiceIOException extends ApplicationException {

	private static final long serialVersionUID = -436144366871430318L;

	public RegixWebServiceIOException() {
		super();
	}

	public RegixWebServiceIOException(final String message) {
		super(message);
	}

	public RegixWebServiceIOException(final Throwable cause) {
		super(cause);
	}

	public RegixWebServiceIOException(final String message, final Throwable cause) {
		super(message, cause);
	}
}
