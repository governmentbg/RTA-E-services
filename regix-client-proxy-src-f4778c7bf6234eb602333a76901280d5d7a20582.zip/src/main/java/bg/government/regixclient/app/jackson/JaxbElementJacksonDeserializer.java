package bg.government.regixclient.app.jackson;

import java.io.IOException;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

public class JaxbElementJacksonDeserializer extends StdDeserializer<JAXBElement<?>> {

	private static final long serialVersionUID = 8489099893384574866L;

	private ObjectMapper objectMapper;

	// ----------------------------------------------------------------------------
	public JaxbElementJacksonDeserializer(ObjectMapper objectMapper) {
		super(JAXBElement.class);
		this.objectMapper = objectMapper;
	}

	// ----------------------------------------------------------------------------
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public JAXBElement<?> deserialize(JsonParser jp, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {
		JsonNode node = jp.getCodec().readTree(jp);
		QName name = objectMapper.treeToValue(node.get("name"), QName.class);
		Class<?> declaredType = objectMapper.treeToValue(node.get("declaredType"), Class.class);
		Class<?> scope = objectMapper.treeToValue(node.get("scope"), Class.class);
		Object value = objectMapper.treeToValue(node.get("value"), declaredType);
		return new JAXBElement(name, declaredType, scope, value);
	}
}