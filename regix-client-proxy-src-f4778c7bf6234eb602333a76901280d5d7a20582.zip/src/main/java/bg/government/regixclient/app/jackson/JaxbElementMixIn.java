package bg.government.regixclient.app.jackson;

import javax.xml.namespace.QName;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@JsonIgnoreProperties(value = { "globalScope", "typeSubstituted", "nil", "matrix" })
public abstract class JaxbElementMixIn<T> {
    private static final Logger logger = LogManager.getLogger(JaxbElementMixIn.class);

	// ----------------------------------------------------------------------------
	@JsonCreator
	public JaxbElementMixIn(@JsonProperty("name") QName name, @JsonProperty("declaredType") Class<T> declaredType,
			@JsonProperty("scope") Class<?> scope, @JsonProperty("value") T value) {
		logger.debug("JaxbElementMixIn: " + value.getClass().getCanonicalName());
	}
}