package bg.government.regixclient.app.jackson;

import java.io.IOException;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import bg.government.regixclient.app.exceptions.ApplicationException;

public class XMLGregorianCalendarDeserializer extends StdDeserializer<XMLGregorianCalendar>{

	private static final long serialVersionUID = 5186023922637416293L;

	public XMLGregorianCalendarDeserializer(Class<?> vc) {
		super(vc);
	}

	@Override
	public XMLGregorianCalendar deserialize(JsonParser jsonParser, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {
		
		String timeInMillisStr = jsonParser.getText();
		Long timeInMillis = Long.valueOf(timeInMillisStr);
		
		final GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTimeInMillis(timeInMillis);
          
        try {
        	XMLGregorianCalendar xmlCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar);
    		return xmlCal;
		} catch (DatatypeConfigurationException e) {
			throw new ApplicationException("There was a problem with XMLGregorianCalendar date deserialization: " + e.getMessage());
		}
        
	}

}
