package bg.government.regixclient.app.jackson;

import java.io.IOException;

import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

public class XMLGregorianCalendarSerializer extends StdSerializer<XMLGregorianCalendar> {

	private static final long serialVersionUID = -4638124298198769033L;

	public XMLGregorianCalendarSerializer() {
		super(XMLGregorianCalendar.class);
	}

	@Override
	public void serialize(XMLGregorianCalendar value, JsonGenerator gen, SerializerProvider provider)
			throws IOException {
		gen.writeNumber(value.toGregorianCalendar().getTimeInMillis());
	}

	@Override
	public void serializeWithType(XMLGregorianCalendar value, JsonGenerator gen, SerializerProvider provider,
			TypeSerializer typeSerializer) throws IOException {
		gen.writeStartArray();
		gen.writeString("javax.xml.datatype.XMLGregorianCalendar");
		serialize(value, gen, provider); // call your customized serialize method
		gen.writeEndArray();
	}
}
