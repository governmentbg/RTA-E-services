package bg.government.regixclient.app.regixclient;

import java.io.IOException;

import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;

import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.FaultMessageResolver;
import org.springframework.ws.soap.SoapHeaderException;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import bg.government.regixclient.app.exceptions.RegixResponseErrorException;

public class CustomFaultMessageResolver implements FaultMessageResolver {

    public CustomFaultMessageResolver() {
    }

    @Override
    public void resolveFault(WebServiceMessage message) throws IOException {
        SaajSoapMessage msg = (SaajSoapMessage) message;

        SOAPFault fault;
        try {
            fault = msg.getSaajMessage().getSOAPBody().getFault();
        } catch (SoapHeaderException | SOAPException e) {
            throw new RegixResponseErrorException("An error occured while handling soap fault", e);
        }
        throw new RegixResponseErrorException(fault.getFaultString());

    }
}