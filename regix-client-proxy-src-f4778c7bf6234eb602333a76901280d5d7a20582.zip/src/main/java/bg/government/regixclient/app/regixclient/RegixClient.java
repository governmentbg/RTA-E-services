package bg.government.regixclient.app.regixclient;

import javax.naming.ServiceUnavailableException;
import javax.xml.bind.JAXBElement;

import org.springframework.ws.client.WebServiceIOException;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.addressing.client.ActionCallback;

import bg.government.regixclient.app.exceptions.RegixResponseErrorException;
import bg.government.regixclient.app.exceptions.RegixWebServiceIOException;
import bg.government.regixclient.app.exceptions.RegixResponseProcessingFailureException;
import bg.government.regixclient.requests.CallContext;
import bg.government.regixclient.requests.ExecuteSynchronous;
import bg.government.regixclient.requests.ExecuteSynchronousResponse;
import bg.government.regixclient.requests.ObjectFactory;
import bg.government.regixclient.requests.ServiceRequestData;
import bg.government.regixclient.requests.ServiceRequestData.Argument;

public class RegixClient extends WebServiceGatewaySupport {

	private String regixEntryPointUri;
	private ObjectFactory wsdlFactory;
	private ActionCallback tempuriActionCallback;

	public RegixClient(String regixEntryPointUri, ObjectFactory wsdlFactory, ActionCallback tempuriActionCallback) {
		this.regixEntryPointUri = regixEntryPointUri;
		this.wsdlFactory = wsdlFactory;
		this.tempuriActionCallback = tempuriActionCallback;
	}
	
	public <REQ, RES> RES getResponseType(JAXBElement<REQ> requestBodyElement, Operation operation, CallContext context) throws ServiceUnavailableException {
		
		ExecuteSynchronousResponse response = null;
		RES responseType = null;
		
		try {
			response = execute(requestBodyElement, operation.getKey(), context);
			
			if (response == null) {
				throw new RegixResponseErrorException("Response from RegiX is null");
			}
			
			if (response.getExecuteSynchronousResult().isHasError()) {
				throw new RegixResponseErrorException("Response has error flag - Error message: " +
						response.getExecuteSynchronousResult().getError().getValue());
			} 
			
			responseType = getResponseTypeFromResponse(response);
			
		} catch (WebServiceIOException exception) {
			RegixWebServiceIOException e = new RegixWebServiceIOException(exception);
			throw e;
		} catch (RegixResponseErrorException exception) {
			throw exception;
		} catch (Exception exception) {			
			throw new RegixResponseProcessingFailureException(exception);
		} 
		
		return responseType;	
	}
	
	private ExecuteSynchronousResponse execute(JAXBElement<?> requestBodyElement, String operation, CallContext context) {

		ServiceRequestData serviceRequest = wsdlFactory.createServiceRequestData();
		serviceRequest.setOperation(operation);

		serviceRequest.setCallContext(context);
		Argument arg = new Argument();
		arg.setAny(requestBodyElement);
		serviceRequest.setArgument(arg);
		ExecuteSynchronous executeRequest = wsdlFactory.createExecuteSynchronous();
		executeRequest.setRequest(serviceRequest);

		ExecuteSynchronousResponse response = null;

		response = (ExecuteSynchronousResponse) getWebServiceTemplate().marshalSendAndReceive(regixEntryPointUri,
				executeRequest, tempuriActionCallback);		
		
		return response;
	}
	
	@SuppressWarnings("unchecked")
	private <RES> RES getResponseTypeFromResponse(ExecuteSynchronousResponse response) {
		Object value = response.getExecuteSynchronousResult().getData().getValue().getResponse().getAny();
		
		if (value instanceof JAXBElement<?>) {
			return ((JAXBElement<RES>) value).getValue();
		}
		
		return (RES) value;
	}

}