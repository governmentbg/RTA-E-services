
package bg.government.regixclient.app.regixclient;

import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.KeyManagerFactory;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.soap.addressing.client.ActionCallback;
import org.springframework.ws.soap.saaj.SaajSoapMessageFactory;
import org.springframework.ws.transport.http.HttpsUrlConnectionMessageSender;

import bg.government.regixclient.app.exceptions.ApplicationException;

@Configuration
public class RegixClientConfiguration {

	private static final Logger logger = LogManager.getLogger(RegixClientConfiguration.class);

	@Value("${regix.ws.trust-store:#{null}}")
	private ClassPathResource trustStore;

	@Value("${regix.ws.trust-store-password:#{null}}")
	private String trustStorePassword;

	@Value("${regix.ws.url}")
	private String url;

	@Value("${regix.clients.names}")
	private String[] clients;

	@Value("${regix.clients.keystores}")
	private ClassPathResource[] clientsKeystores;

	@Value("${regix.clients.passwords}")
	private String[] clientsPasswords;

	@Autowired
	private bg.government.regixclient.requests.ObjectFactory wsdlFactory;

	@Autowired
	private ActionCallback tempuriActionCallback;

	@Autowired
	private CustomFaultMessageResolver customFaultMessageResolver;

	@Bean
	public Map<String, RegixClient> regixClients(Jaxb2Marshaller marshaller) throws UnrecoverableKeyException,
			KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException, SOAPException {

		if (clients.length == 0 && clientsKeystores.length == 0 && clientsPasswords.length == 0) {
			throw new ApplicationException("No clients specified!");
		}

		Map<String, RegixClient> clientMap = new HashMap<>();
		int iCnterLimit = clients.length;
		for (int iCnter = 0; iCnter < iCnterLimit; iCnter++) {
			clientMap.put(clients[iCnter],
					createRegixClient(marshaller, clientsKeystores[iCnter], clientsPasswords[iCnter]));
		}
		return clientMap;
	}

	private RegixClient createRegixClient(Jaxb2Marshaller marshaller, ClassPathResource keyStorePath,
			String keyStorePassword) throws UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException,
			CertificateException, IOException, SOAPException {

		RegixClient client = new RegixClient(url, wsdlFactory, tempuriActionCallback);
		client.setDefaultUri(this.url);
		client.setMarshaller(marshaller);
		client.setUnmarshaller(marshaller);

		KeyManagerFactory keyManagerFactory = loadKeyStore(keyStorePath, keyStorePassword);
		HttpsUrlConnectionMessageSender messageSender = createMessageSender(keyManagerFactory);

		client.setMessageSender(messageSender);

		client.getWebServiceTemplate().setFaultMessageResolver(customFaultMessageResolver);

		MessageFactory msgFactory = MessageFactory.newInstance(SOAPConstants.SOAP_1_2_PROTOCOL);
		SaajSoapMessageFactory newSoapMessageFactory = new SaajSoapMessageFactory(msgFactory);
		client.setMessageFactory(newSoapMessageFactory);

		return client;
	}

	private KeyManagerFactory loadKeyStore(ClassPathResource keyStorePath, String keyStorePassword)
			throws NoSuchAlgorithmException, UnrecoverableKeyException, KeyStoreException, CertificateException,
			IOException {

		logger.info("Loading keystore: " + keyStorePath.getURI().toString());
		logger.info("Loading password: " + keyStorePassword);

		KeyStore keyStore = KeyStore.getInstance("PKCS12");
		keyStore.load(keyStorePath.getInputStream(), keyStorePassword.toCharArray());

		logger.info("Loaded keystore: " + keyStorePath.getURI().toString());
		try {
			keyStorePath.getInputStream().close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		keyManagerFactory.init(keyStore, keyStorePassword.toCharArray());
		return keyManagerFactory;
	}

	private HttpsUrlConnectionMessageSender createMessageSender(KeyManagerFactory keyManagerFactory) {
		HttpsUrlConnectionMessageSender messageSender = new HttpsUrlConnectionMessageSender();
		messageSender.setKeyManagers(keyManagerFactory.getKeyManagers());
		// otherwise: java.security.cert.CertificateException: No name matching
		// localhost found
		messageSender.setHostnameVerifier((hostname, sslSession) -> {
			if (hostname.equals("localhost")) {
				return true;
			}
			return false;
		});
		return messageSender;
	}
}
