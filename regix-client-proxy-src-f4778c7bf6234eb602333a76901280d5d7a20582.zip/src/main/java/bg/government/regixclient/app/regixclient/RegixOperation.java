package bg.government.regixclient.app.regixclient;

import bg.government.regixclient.app.cache.CacheDbTablenames;

public enum RegixOperation implements Operation {
    PERSONAL_IDENTITY_INFO_SEARCH("TechnoLogica.RegiX.MVRBDSAdapter.APIService.IMVRBDSAPI.GetPersonalIdentity", CacheDbTablenames.LOGS_PERSONAL_IDENTITY),
    PERSONAL_IDENTITY_INFO_SEARCH_V2("TechnoLogica.RegiX.MVRBDSAdapter.APIService.IMVRBDSAPI.GetPersonalIdentityV2", CacheDbTablenames.LOGS_PERSONAL_IDENTITY_V2),
    PERSONAL_IDENTITY_INFO_SEARCH_V3("TechnoLogica.RegiX.MVRBDSAdapter.APIService.IMVRBDSAPI.GetPersonalIdentityV3", CacheDbTablenames.LOGS_PERSONAL_IDENTITY_V3),
    FOREIGNER_IDENTITY_INFO_SEARCH("TechnoLogica.RegiX.MVRERChAdapter.APIService.IMVRERChAPI.GetForeignIdentity", CacheDbTablenames.LOGS_FOREIGN_IDENTITY),
	MOTOR_VEHICLE_REGISTRATION_INFO_SEARCH("TechnoLogica.RegiX.MVRMPSAdapter.APIService.IMVRMPSAPI.GetMotorVehicleRegistrationInfoV2", CacheDbTablenames.LOGS_MOTOR_VEHICLE_REGISTRATION),
	EMPLOYMENT_CONTRACTS_INFO_SEARCH("TechnoLogica.RegiX.NRAEmploymentContractsAdapter.APIService.INRAEmploymentContractsAPI.GetEmploymentContracts", CacheDbTablenames.LOGS_EMPLOYMENT_CONTRACTS),
	VALID_UIC_INFO_SEARCH("TechnoLogica.RegiX.AVTRAdapter.APIService.ITRAPI.GetValidUICInfo", CacheDbTablenames.LOGS_UIC_VALIDATION),
	ACTUAL_STATE_V3("TechnoLogica.RegiX.AVTRAdapter.APIService.ITRAPI.GetActualStateV3", CacheDbTablenames.LOGS_AV_TR_ACTUAL_STATE_V3);
	
    private final String key;
    private final String cacheTableName;

    private RegixOperation(String key, String cacheTableName) {
        this.key = key;
        this.cacheTableName = cacheTableName;
    }

    public String getKey() {
        return key;
    }

	public String getCacheTableName() {
		return cacheTableName;
	}
}
