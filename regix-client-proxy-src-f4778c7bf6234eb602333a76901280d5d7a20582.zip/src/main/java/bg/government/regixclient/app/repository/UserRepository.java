package bg.government.regixclient.app.repository;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class UserRepository {

	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;

	public String getUsername(String certificate) {
		Map<String, Object> arguments = new HashMap<>();
		arguments.put("certificate", certificate + "%");
		String query =  "SELECT name FROM regix_proxy.clients WHERE certificate LIKE :certificate";

		String result = jdbcTemplate.query(query, arguments, (res) -> {
			if (res.next()) {
				return res.getString(1);
			}
			return null;
		});

		return result;
	}
}
