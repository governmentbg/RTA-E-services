package bg.government.regixclient.app.security;

public enum SecurityGroups {

	FULL_ACCESS(new String[] { SecurityRole.GENERIC_USER });

	private String[] rolesInGroup;

	private SecurityGroups(String[] rolesInGroup) {
		this.rolesInGroup = rolesInGroup;
	}

	public String[] getRolesInGroup() {
		return this.rolesInGroup;
	}
}
