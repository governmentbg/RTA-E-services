package bg.government.regixclient.app.security;

public interface SecurityRole {

	String GENERIC_USER = "GENERIC_USER";

}
