package bg.government.regixclient.app.service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

import javax.xml.bind.JAXBElement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;

import bg.demax.regixclient.mvr.bds.BaseRequestDto;
import bg.government.regixclient.app.cache.CacheProperties;
import bg.government.regixclient.app.converter.AppConversionService;
import bg.government.regixclient.app.exceptions.ApplicationException;
import bg.government.regixclient.app.regixclient.RegixClient;
import bg.government.regixclient.app.regixclient.RegixOperation;
import bg.government.regixclient.app.security.SecurityUtilService;
import bg.government.regixclient.requests.CallContext;

public abstract class BaseRegixService {
	
	private static final Logger log = LogManager.getLogger(BaseRegixService.class);

	public static final String CACHE_FIRST_PERIOD_FROM_HEADER_NAME = "x-cache-first-period";
	public static final String CACHE_SECOND_PERIOD_FROM_HEADER_NAME = "x-cache-second-period";
	
	public static final String IAAA_PROXIES_ADMIN_CLIENT_NAME = "IaaaProxiesAdmin";
	public static final String OUTGOING_CLIENT_NAME_HEADER_NAME = "x-outgoing-client-name";

	@Autowired
	protected Map<String, RegixClient> regixClients;

	@Autowired
	protected AppConversionService conversionService;

	@Autowired
	protected CacheService cacheService;
	
	@Autowired
	protected SecurityUtilService securityUtilService;
	
	protected <RES, REQ> RES getResponse(JAXBElement<REQ> requestBodyElement, RegixOperation operation,
			BaseRequestDto baseRequestDto, HttpHeaders requestHeaders) throws Exception {
		CallContext callContext = conversionService.convert(baseRequestDto.getCallContext(), CallContext.class);
		CacheProperties cacheProps = buildCacheProperties(requestHeaders, operation.getCacheTableName());
				
		REQ request = requestBodyElement.getValue();
		
		String username = this.securityUtilService.getCurrentUserDetails().getUsername();
		RegixClient regixClient = null;
		if (IAAA_PROXIES_ADMIN_CLIENT_NAME.equals(username)) {
			try {
				String outgoingClientName = requestHeaders.get(OUTGOING_CLIENT_NAME_HEADER_NAME).get(0);
				username = username + "." + outgoingClientName;
				
				if (!regixClients.containsKey(outgoingClientName)) {
					throw new ApplicationException();
				}
				
				regixClient = regixClients.get(outgoingClientName);
			} catch (Exception ex) {
				throw new ApplicationException("Invalid admin operation");
			}
		} else {
			regixClient = this.regixClients.get(username);
		}
		
		final RegixClient finalRegixClient = regixClient;
		Callable<RES> callable = new Callable<RES>() {
			@Override
			public RES call() throws Exception {
				return finalRegixClient.getResponseType(requestBodyElement, operation, callContext);
			}
		};
		
		return cacheService.smartCache(callable, request, callContext, cacheProps, username);
	}

	private CacheProperties buildCacheProperties(HttpHeaders httpHeaders, String cacheTablename) {
		CacheProperties cacheProperties = new CacheProperties();
		cacheProperties.setTableName(cacheTablename);

		setCachePeriod(httpHeaders, CACHE_FIRST_PERIOD_FROM_HEADER_NAME, cacheProperties::setFirstPeriodInHours);
		setCachePeriod(httpHeaders, CACHE_SECOND_PERIOD_FROM_HEADER_NAME, cacheProperties::setSecondPeriodInHours);
		return cacheProperties;
	}

	private void setCachePeriod(HttpHeaders httpHeaders, String headerName, Consumer<Integer> cachePropSetter) {
		List<String> headerValues = httpHeaders.get(headerName);

		if (headerValues != null && !headerValues.isEmpty()) {
			String cachePeriodStr = headerValues.get(0);
			try {
				Integer cachePeriod = Integer.parseInt(cachePeriodStr);
				cachePropSetter.accept(cachePeriod);
			} catch (NumberFormatException ex) {
				log.warn("Unparsable cache period value detected.");
			}
		}
	}
}
