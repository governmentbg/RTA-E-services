package bg.government.regixclient.app.service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bg.government.regixclient.app.cache.CacheDbTablenames;
import bg.government.regixclient.app.cache.CacheEntry;
import bg.government.regixclient.app.cache.CacheProperties;
import bg.government.regixclient.app.config.BeanQualifiers;
import bg.government.regixclient.app.exceptions.ApplicationException;
import bg.government.regixclient.app.exceptions.RegixResponseErrorException;
import bg.government.regixclient.app.exceptions.RegixResponseProcessingFailureException;
import bg.government.regixclient.app.exceptions.RegixWebServiceIOException;
import bg.government.regixclient.requests.CallContext;

@Service
public class CacheService {

	private static final Logger log = LogManager.getLogger(CacheService.class);
    public static final Integer CACHE_MAX_PERIOD_HOURS = 744; //1 month

	@Autowired
	@Qualifier(BeanQualifiers.TYPE_ENABLED_JSON_OBJECT_MAPPER)
	private ObjectMapper postgreJsonMapper;

	@Autowired
	private NamedParameterJdbcTemplate jdbcTemplate;

    public <REQ, RES> CacheEntry<REQ, RES> getCacheFromDb(Object request, String username, String tableName, Integer hoursBack) {
    	
    	if (hoursBack > CACHE_MAX_PERIOD_HOURS) {
			throw new ApplicationException(String.format("Max cache period is %s", CACHE_MAX_PERIOD_HOURS));
    	}
    	
    	LocalDateTime requestTimeAfter = LocalDateTime.now().minusHours(hoursBack);

		String query = String.format(
				"SELECT workflow FROM %s.%s " + 
				"WHERE (workflow #>'{request, 1}') = (:json)::jsonb " +
				"AND workflow->>'clientName' = :username " +
				"AND workflow ->> 'response' IS NOT NULL " +
				"AND request_time >= :requestTimeAfter " +
				"ORDER BY request_time DESC " + 
				"LIMIT 1",
						CacheDbTablenames.LOG_SCHEMA, tableName);
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("requestTimeAfter", requestTimeAfter);
		parameters.put("username", username);

		serialize(request, parameters);

		String result = jdbcTemplate.query(query, parameters, (res) -> {
			if (res.next()) {
				return res.getString(1);
			}
			return null;
		});

		return deserialize(result);
	}
	
	public <REQ, RES> void logCacheToDb(CacheEntry<REQ, RES> cache, String tableName) {

		String query = String.format(
				"INSERT INTO %s.%s (workflow, request_time)  VALUES (cast(:json AS JSON), :requestTime) RETURNING workflow AS workflow",
				CacheDbTablenames.LOG_SCHEMA, tableName);
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("requestTime", cache.getRequestTime());
		
		serialize(cache, parameters);

		String result = jdbcTemplate.query(query, parameters, (res) -> {
			res.next();
			return res.getString(1);
		});

		deserialize(result);
	}

	private void serialize(Object workflow, Map<String, Object> parameters) {
		try {
			String json = postgreJsonMapper.writeValueAsString(workflow);
			parameters.put("json", json);
		} catch (JsonProcessingException e) {
			log.error(e.getMessage());
		}
	}
	
	@SuppressWarnings("unchecked")
	private <REQ, RES> CacheEntry<REQ, RES> deserialize(String result) {
		CacheEntry<REQ, RES> entry = null;
		if (result == null) {
			return entry;
		}
		try {
			entry = postgreJsonMapper.readValue(result, CacheEntry.class);
		} catch (IOException e) {
			log.error(e.getMessage());
		}
		return entry;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public <REQ, RES> RES smartCache(Callable<RES> callable, REQ request, CallContext callContext, CacheProperties props, String username) throws Exception {
		CacheEntry<REQ, RES> cacheEntry = null;
		if (props.getFirstPeriodInHours() != null) {
			
			cacheEntry = getCacheFromDb(request, username, props.getTableName(), props.getFirstPeriodInHours());
			if (cacheEntry != null && cacheEntry.getResponse() != null) {
				return cacheEntry.getResponse();
			}
		}		
		
		try {					
			cacheEntry = new CacheEntry();
			
			LocalDateTime reqTime = LocalDateTime.now();
			cacheEntry.setRequestTime(reqTime);
			cacheEntry.setRequest(request);
			
			boolean shouldLogToDb = true;
			
			try {
				RES response = callable.call();
				cacheEntry.setResponse(response);
				return response;
			} catch (RegixWebServiceIOException e) {
				shouldLogToDb = false;
				throw e;
			} catch (RegixResponseErrorException | RegixResponseProcessingFailureException e) {
				cacheEntry.setError(e.getMessage());
				throw e;
			} finally {
				if (shouldLogToDb) {
					LocalDateTime respTime = LocalDateTime.now();
					cacheEntry.setResponseTime(respTime);
					cacheEntry.setClientName(username);
					cacheEntry.setCallContext(callContext);
					logCacheToDb(cacheEntry, props.getTableName());
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			if (props.getSecondPeriodInHours() == null) {
				throw e;
			}
			cacheEntry = getCacheFromDb(request, username, props.getTableName(), props.getSecondPeriodInHours());
			if (cacheEntry != null && cacheEntry.getResponse() != null) {
				return cacheEntry.getResponse();
			} else {
				throw e;
			}
		}
	}
}
