package bg.government.regixclient.app.service;

import javax.xml.bind.JAXBElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import bg.demax.regixclient.av.tr.actualstatev3.ActualStateRequestDto;
import bg.demax.regixclient.av.tr.actualstatev3.ActualStateResponseDto;
import bg.demax.regixclient.av.tr.uicvalidation.ValidUICIdentifierDto;
import bg.demax.regixclient.av.tr.uicvalidation.ValidUICInfoDto;
import bg.government.regixclient.app.regixclient.RegixOperation;
import bg.government.regixclient.requests.av.tr.actualstatev3.ActualStateRequestV3;
import bg.government.regixclient.requests.av.tr.actualstatev3.ActualStateResponseV3;
import bg.government.regixclient.requests.av.tr.uicvalidation.ValidUICRequestType;
import bg.government.regixclient.requests.av.tr.uicvalidation.ValidUICResponseType;

@Service
public class RegixAvService extends BaseRegixService {

	@Autowired
	private bg.government.regixclient.requests.av.tr.uicvalidation.ObjectFactory uicObjectFactory;
	
	@Autowired
	private bg.government.regixclient.requests.av.tr.actualstatev3.ObjectFactory actualStateObjectFactory;

	public ValidUICInfoDto getValidUICInfo(ValidUICIdentifierDto identifierDto, HttpHeaders headers) throws Exception {
		ValidUICRequestType request = uicObjectFactory.createValidUICRequestType();
		request.setUIC(identifierDto.getUic());
		
		JAXBElement<ValidUICRequestType> requestElement = uicObjectFactory.createValidUICRequest(request);
		
		ValidUICResponseType response = getResponse(requestElement, RegixOperation.VALID_UIC_INFO_SEARCH, identifierDto, headers);
		
		return conversionService.convert(response, ValidUICInfoDto.class);
	}
	
	public ActualStateResponseDto getActualStateV3(ActualStateRequestDto requestDto, HttpHeaders headers) throws Exception {
		ActualStateRequestV3 request = actualStateObjectFactory.createActualStateRequestV3();
		request.setUIC(requestDto.getUIC());
		request.setFieldList(requestDto.getFieldList());
		
		JAXBElement<ActualStateRequestV3> requestElement = actualStateObjectFactory.createActualStateRequestV3(request);
		
		/*
		 * TODO
		 * Field ActualStateResponseV3 -> DeedType -> Subdeeds -> Subdeed -> Records -> Record -> *RecordData*
		 * is temporarily set as String. XSD type of RecordData is set to be anyType which matches Object.
		 * Since we don't know the possible implementations of RecordData, it is set as String and not filled for now. 
		 * 
		 * For now is set as String as we don't know the certain object type we are going to receive.
		 * Must update when this info is present
		 */
		ActualStateResponseV3 response = getResponse(requestElement, RegixOperation.ACTUAL_STATE_V3, requestDto, headers);
		
		return conversionService.convert(response, ActualStateResponseDto.class);
	}
}
