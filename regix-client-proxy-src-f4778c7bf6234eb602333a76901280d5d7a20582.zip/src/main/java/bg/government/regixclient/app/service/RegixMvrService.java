package bg.government.regixclient.app.service;

import javax.xml.bind.JAXBElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import bg.demax.regixclient.mvr.bds.ForeignerIdentityDto;
import bg.demax.regixclient.mvr.bds.PersonalResponseDto;
import bg.demax.regixclient.mvr.bds.PersonalResponseDtoV2;
import bg.demax.regixclient.mvr.bds.PersonalResponseDtoV3;
import bg.demax.regixclient.mvr.bds.PersonalIdentityDto;
import bg.demax.regixclient.mvr.mpsv2.MotorVehicleIdentifierDto;
import bg.demax.regixclient.mvr.mpsv2.MotorVehicleRegistrationInfoDto;
import bg.government.regixclient.app.regixclient.RegixOperation;
import bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoRequestType;
import bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoResponseType;
import bg.government.regixclient.requests.mvr.erch.ForeignIdentityInfoRequestType;
import bg.government.regixclient.requests.mvr.erch.ForeignIdentityInfoResponseType;
import bg.government.regixclient.requests.mvr.erch.IdentifierType;
import bg.government.regixclient.requests.mvr.mpsv2.GetMotorVehicleRegistrationInfoV2ResponseType;
import bg.government.regixclient.requests.mvr.mpsv2.MotorVehicleRegistrationRequestTypeV2;

@Service
public class RegixMvrService extends BaseRegixService {

	@Autowired
	private bg.government.regixclient.requests.mvr.mpsv2.ObjectFactory mpsObjectFactory;

	@Autowired
	private bg.government.regixclient.requests.mvr.bds.ObjectFactory bdsObjectFactory;

	@Autowired
	private bg.government.regixclient.requests.mvr.erch.ObjectFactory erchObjectFactory;

	public PersonalResponseDto getPersonalIdentityInfo(PersonalIdentityDto personalIdentity, HttpHeaders headers) throws Exception {
		return getPersonalIdentityInfo(personalIdentity, headers, RegixOperation.PERSONAL_IDENTITY_INFO_SEARCH, PersonalResponseDto.class);
	}

	public PersonalResponseDtoV2 getPersonalIdentityInfoV2(PersonalIdentityDto personalIdentity, HttpHeaders headers) throws Exception {
		return getPersonalIdentityInfo(personalIdentity, headers, RegixOperation.PERSONAL_IDENTITY_INFO_SEARCH_V2, PersonalResponseDtoV2.class);
    }
    
    public PersonalResponseDtoV3 getPersonalIdentityInfoV3(PersonalIdentityDto personalIdentity, HttpHeaders headers) throws Exception {
		return getPersonalIdentityInfo(personalIdentity, headers, RegixOperation.PERSONAL_IDENTITY_INFO_SEARCH_V3, PersonalResponseDtoV3.class);
	}

	private <RES> RES getPersonalIdentityInfo(PersonalIdentityDto personalIdentity, HttpHeaders headers, RegixOperation operation, Class<RES> responseDtoClass) throws Exception {

		PersonalIdentityInfoRequestType request = bdsObjectFactory.createPersonalIdentityInfoRequestType();
		request.setEGN( personalIdentity.getEgn());
		request.setIdentityDocumentNumber(personalIdentity.getIdentityDocumentNumber());

		JAXBElement<PersonalIdentityInfoRequestType> requestBodyElement = bdsObjectFactory
				.createPersonalIdentityInfoRequest(request);

		PersonalIdentityInfoResponseType response = getResponse(requestBodyElement, operation, personalIdentity, headers);

		return conversionService.convert(response, responseDtoClass);
	}

	public PersonalResponseDto getForeignerIdentityInfo(ForeignerIdentityDto foreignerIdentity, HttpHeaders headers) throws Exception {

		ForeignIdentityInfoRequestType request = erchObjectFactory.createForeignIdentityInfoRequestType();
		request.setIdentifier(foreignerIdentity.getIdentifier());
		request.setIdentifierType(IdentifierType.fromValue(foreignerIdentity.getIdentifierType().value()));

		JAXBElement<ForeignIdentityInfoRequestType> requestBodyElement = erchObjectFactory
				.createForeignIdentityInfoRequest(request);

		ForeignIdentityInfoResponseType response = getResponse(requestBodyElement,
				RegixOperation.FOREIGNER_IDENTITY_INFO_SEARCH, foreignerIdentity, headers);

		return conversionService.convert(response, PersonalResponseDto.class);
	}

	public MotorVehicleRegistrationInfoDto getMotorVehicleRegistrationInfo(MotorVehicleIdentifierDto motorVehDto, HttpHeaders headers)
			throws Exception {

		MotorVehicleRegistrationRequestTypeV2 request = mpsObjectFactory.createMotorVehicleRegistrationRequestTypeV2();
		request.setIdentifier(motorVehDto.getRegistrationNumber());

		JAXBElement<MotorVehicleRegistrationRequestTypeV2> requestBodyElement = mpsObjectFactory
				.createGetMotorVehicleRegistrationInfoV2Request(request);

		GetMotorVehicleRegistrationInfoV2ResponseType response = getResponse(requestBodyElement,
				RegixOperation.MOTOR_VEHICLE_REGISTRATION_INFO_SEARCH, motorVehDto, headers);

		return conversionService.convert(response, MotorVehicleRegistrationInfoDto.class);
	}

}