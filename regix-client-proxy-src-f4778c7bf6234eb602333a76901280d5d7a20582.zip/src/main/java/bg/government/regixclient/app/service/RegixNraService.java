package bg.government.regixclient.app.service;

import javax.xml.bind.JAXBElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import bg.demax.regixclient.nra.employmentcontracts.EmploymentContractsIdentifierDto;
import bg.demax.regixclient.nra.employmentcontracts.EmploymentContractsInfoDto;
import bg.government.regixclient.app.regixclient.RegixOperation;
import bg.government.regixclient.requests.nra.employmentcontracts.ContractsFilterType;
import bg.government.regixclient.requests.nra.employmentcontracts.EmploymentContractsRequest;
import bg.government.regixclient.requests.nra.employmentcontracts.EmploymentContractsResponse;
import bg.government.regixclient.requests.nra.employmentcontracts.IdentityTypeRequest;

@Service
public class RegixNraService extends BaseRegixService {
	
	@Autowired
	private bg.government.regixclient.requests.nra.employmentcontracts.ObjectFactory ecObjectFactory;
	
	public EmploymentContractsInfoDto getEmploymentContractsInfo(EmploymentContractsIdentifierDto employmentContractsIdentifier, HttpHeaders headers) 
			throws Exception {
		EmploymentContractsRequest request = ecObjectFactory.createEmploymentContractsRequest();
		request.setContractsFilter(ContractsFilterType.fromValue(employmentContractsIdentifier.getContractsFilter().value()));
		request.setIdentity(conversionService.convert(employmentContractsIdentifier.getIdentity(), IdentityTypeRequest.class));
		
		JAXBElement<EmploymentContractsRequest> requestBodyElement = ecObjectFactory.createEmploymentContractsRequest(request);
		
		EmploymentContractsResponse response = getResponse(requestBodyElement, RegixOperation.EMPLOYMENT_CONTRACTS_INFO_SEARCH, 
				employmentContractsIdentifier, headers);
		
		return conversionService.convert(response, EmploymentContractsInfoDto.class);
	}
}
