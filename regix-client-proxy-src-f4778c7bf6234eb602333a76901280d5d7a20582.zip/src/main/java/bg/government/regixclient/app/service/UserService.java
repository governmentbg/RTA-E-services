package bg.government.regixclient.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import bg.government.regixclient.app.dto.CurrentUserDto;
import bg.government.regixclient.app.exceptions.ApplicationException;
import bg.government.regixclient.app.security.SecurityUtilService;

@Service
public class UserService {
	@Autowired
	private SecurityUtilService securityUtilService;

	@Value("${regix.clients.names}")
	private String[] clients;

	@Value("${regix.clients.keystores}")
	private ClassPathResource[] clientsKeystores;

	public CurrentUserDto getCurrentUser() {
		String clientName = this.securityUtilService.getCurrentUserDetails().getUsername();
		Integer clientIndex = null;
		
		for (int i = 0; i < clients.length; i++) {
			String client = clients[i];
			
			if (client.equals(clientName)) {
				clientIndex = i;
				break;
			}
		}
		
		if (clientIndex == null) {
			throw new ApplicationException("Unexpected client name:" + clientName);
		}
		
		CurrentUserDto dto = new CurrentUserDto();
		dto.setClientName(clientName);
		dto.setOutgoingClientCertificateFileName(clientsKeystores[clientIndex].getFilename());
		
		
		return dto;
	}
}
