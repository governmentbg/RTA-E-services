package bg.government.regixclient.app.utils;

import java.time.LocalDate;

import javax.xml.datatype.XMLGregorianCalendar;

public class ConverterUtil {

	public static LocalDate toLocalDate(XMLGregorianCalendar xmlDate) {
		if (xmlDate == null) {
			return null;
		}
		
		return LocalDate.of(xmlDate.getYear(), xmlDate.getMonth(), xmlDate.getDay());
	}
}
