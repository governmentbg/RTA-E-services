package bg.government.regixclient.app.utils;

import java.io.IOException;
import java.lang.reflect.Modifier;
import java.util.List;

import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ReflectionUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

public class ObjectMapperUtils {
	private static ObjectMapper om = getNewConfiguredObjectMapper();

	public static <T> T fromJson(String json, Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {
		return om.readValue(json, clazz);
	}

	public static <T> List<T> fromJsonArray(String json, Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {
		return om.readValue(json, TypeFactory.defaultInstance().constructCollectionType(List.class, clazz));
	}

	public static String toJson(Object from) throws JsonProcessingException {
		return om.writeValueAsString(from);
	}

	public static String toJson(Object... objects) throws JsonProcessingException {
		StringBuilder resultBuilder = new StringBuilder();
		resultBuilder.append("{");

		for (int i = 0; i < objects.length; i++) {
			Object object = objects[i];
			String objJson = toJson(object);
			objJson = objJson.substring(1, objJson.length() - 1);
			resultBuilder.append(objJson);
			if (i != objects.length - 1) {
				resultBuilder.append(",");
			}
		}

		resultBuilder.append("}");

		return resultBuilder.toString();
	}

	public static MultiValueMap<String, String> toParams(Object... objects)
			throws IllegalArgumentException, IllegalAccessException {
		MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<>();

		for (Object object : objects) {
			ReflectionUtils.doWithFields(object.getClass(), field -> {
				if (!Modifier.isStatic(field.getModifiers())) {
					field.setAccessible(true);
					Object value = field.get(object);
					if (value != null) {
						paramMap.set(field.getName(), String.valueOf(value));
					}
				}
			});
		}
		return paramMap;
	}

	public static ObjectMapper getNewConfiguredObjectMapper() {
		ObjectMapper newOm = new ObjectMapper();
		newOm.disable(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS);
		newOm.disable(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS);
		newOm.registerModule(new JavaTimeModule());
		return newOm;
	}
}
