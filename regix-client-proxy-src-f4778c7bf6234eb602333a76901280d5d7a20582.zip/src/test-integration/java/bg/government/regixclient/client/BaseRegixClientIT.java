package bg.government.regixclient.client;

import java.io.File;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.JAXBElement;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.convert.ConversionService;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import bg.government.regixclient.app.config.BeanConfiguration;
import bg.government.regixclient.app.config.RegixClientProxyConstants;
import bg.government.regixclient.app.regixclient.RegixClient;
import bg.government.regixclient.app.regixclient.RegixClientConfiguration;
import bg.government.regixclient.app.regixclient.RegixOperation;
import bg.government.regixclient.requests.CallContext;

@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles(RegixClientProxyConstants.SPRING_PROFILE_INTEGRATION_TEST)
@ContextConfiguration(classes = { RegixClientConfiguration.class, BeanConfiguration.class, RegixClientConfig.class })
public class BaseRegixClientIT {

	private static final String DEFAULT_DIR = "/tmp";
	protected static final String ADR_CLIENT = "Client1";

	private static final Map<String, String> CLIENT_TO_NAME_MAP = new HashMap<String, String>() {
		private static final long serialVersionUID = 3830299567210514318L;
		{
			put("Client1", "adr");
			put("Client2", "dqc");
			put("Client3", "motor_exams");
			put("Client4", "tachonet");
			put("TechinspClient", "techinsp");
		}
	};

	@Autowired
	protected Map<String, RegixClient> regixClients;

	@Autowired
	protected ObjectMapper objectMapper;

	@Autowired
	protected ConversionService conversionService;

	protected void writeResponseToFile(String client, String serviceName, Object response) throws Exception {

		String fileName = CLIENT_TO_NAME_MAP.get(client) + "_" + serviceName + ".json";
		String pathName = DEFAULT_DIR + "/" + fileName;

		File file = new File(pathName);
		FileWriter fileWriter = new FileWriter(file);
		ObjectWriter writer = objectMapper.writerWithDefaultPrettyPrinter();

		fileWriter.write(writer.writeValueAsString(response));
		fileWriter.close();
	}

	protected <T extends Object> void testAllCerts(T response, JAXBElement<?> requestElement, CallContext callContext, RegixOperation operation) throws Exception {
		for (Entry<String, RegixClient> regixClientKvp : regixClients.entrySet()) {

			RegixClient regixClient = regixClientKvp.getValue();

			try {
				response = regixClient.getResponseType(requestElement, operation, callContext);
				writeResponseToFile(regixClientKvp.getKey(), response.getClass().getSimpleName(), response);	

				System.err.println(regixClientKvp.getKey() + " : " + objectMapper.writeValueAsString(response));
			} catch (Exception e) {
				writeResponseToFile(regixClientKvp.getKey(), response.getClass().getSimpleName(), e.getMessage());	

				System.err.println(regixClientKvp.getKey() + " : " + e.getMessage());
			}
		}
	}
}
