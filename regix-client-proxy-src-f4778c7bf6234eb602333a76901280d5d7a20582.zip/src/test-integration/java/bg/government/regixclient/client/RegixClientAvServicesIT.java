package bg.government.regixclient.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.xml.bind.JAXBElement;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import bg.government.regixclient.app.regixclient.RegixClient;
import bg.government.regixclient.app.regixclient.RegixOperation;
import bg.government.regixclient.app.utils.CallContextDtos;
import bg.government.regixclient.requests.CallContext;
import bg.government.regixclient.requests.av.tr.actualstatev3.ActualStateRequestV3;
import bg.government.regixclient.requests.av.tr.actualstatev3.ActualStateResponseV3;
import bg.government.regixclient.requests.av.tr.actualstatev3.LiquidationOrInsolvency;
import bg.government.regixclient.requests.av.tr.uicvalidation.ValidUICRequestType;
import bg.government.regixclient.requests.av.tr.uicvalidation.ValidUICResponseType;

public class RegixClientAvServicesIT extends BaseRegixClientIT {
	
	@Autowired
	private bg.government.regixclient.requests.av.tr.uicvalidation.ObjectFactory uicObjectFactory;

	@Autowired
	private bg.government.regixclient.requests.av.tr.actualstatev3.ObjectFactory actualStateObjectFactory;
	
	/*
	 * VALID UIC INFO TESTS
	 */
	@Test
	public void test_getValidUICInfo_with_specific_client() throws Exception {
		RegixClient regixClient = regixClients.get(ADR_CLIENT);

		ValidUICRequestType request = uicObjectFactory.createValidUICRequestType();
		request.setUIC("test");

		JAXBElement<ValidUICRequestType> requestElement = uicObjectFactory.createValidUICRequest(request);

		CallContext callContext = conversionService.convert(CallContextDtos.VALID_UIC_INFO_SEARCH.getDto(), CallContext.class);

		ValidUICResponseType response = regixClient.getResponseType(requestElement, RegixOperation.VALID_UIC_INFO_SEARCH, callContext);
		System.err.println(objectMapper.writeValueAsString(response));

		writeResponseToFile(ADR_CLIENT, "uic_validation_check", response);

		assertNotNull(response);
		assertEquals("201593301", response.getUIC());
	}

	@Test
	public void test_getValidUICInfo_with_all_clients() throws Exception {
		ValidUICRequestType request = uicObjectFactory.createValidUICRequestType();
		request.setUIC("test");

		JAXBElement<ValidUICRequestType> requestElement = uicObjectFactory.createValidUICRequest(request);

		CallContext callContext = conversionService.convert(CallContextDtos.VALID_UIC_INFO_SEARCH.getDto(), CallContext.class);

		testAllCerts(new ValidUICResponseType(), requestElement, callContext, RegixOperation.VALID_UIC_INFO_SEARCH);
	}

	/*
	 *  ACTUAL STATE V3 TESTS
	 */
	
	@Test
	public void test_getActualState_with_specific_client() throws Exception {
		RegixClient regixClient = regixClients.get(ADR_CLIENT);

		ActualStateRequestV3 request = actualStateObjectFactory.createActualStateRequestV3();
		request.setUIC("test");
		request.setFieldList("test");

		JAXBElement<ActualStateRequestV3> requestElement = actualStateObjectFactory.createActualStateRequestV3(request);

		CallContext callContext = conversionService.convert(CallContextDtos.VALID_UIC_INFO_SEARCH.getDto(), CallContext.class);

		ActualStateResponseV3 response = regixClient.getResponseType(requestElement, RegixOperation.ACTUAL_STATE_V3, callContext);
		System.err.println(objectMapper.writeValueAsString(response));

		writeResponseToFile(ADR_CLIENT, "get_actual_state_v3", response);

		assertNotNull(response);
		assertEquals(LiquidationOrInsolvency.INSOLVENCY_SEC_INS, response.getDeed().getLiquidationOrInsolvency());
	}

	@Test
	public void test_getActualStateV3_with_all_clients() throws Exception {
		ActualStateRequestV3 request = actualStateObjectFactory.createActualStateRequestV3();
		request.setUIC("202727534");
		request.setFieldList("00");

		JAXBElement<ActualStateRequestV3> requestElement = actualStateObjectFactory.createActualStateRequestV3(request);

		CallContext callContext = conversionService.convert(CallContextDtos.ACTUAL_STATE_V3.getDto(), CallContext.class);

		testAllCerts(new ActualStateResponseV3(), requestElement, callContext, RegixOperation.ACTUAL_STATE_V3);
	}
}
