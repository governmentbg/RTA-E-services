package bg.government.regixclient.client;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.core.convert.support.GenericConversionService;

import bg.government.regixclient.app.config.BeanQualifiers;

@Configuration
@ComponentScan({"bg.government.regixclient.app.converter"})
@SuppressWarnings("rawtypes")
public class RegixClientConfig {
	
	@Autowired
	private List<Converter> converters;

	@Bean
	@Qualifier(BeanQualifiers.DEFAULT_SPRING_BOOT_CONVERSION_SERVICE)
	public GenericConversionService genericConversionService() {
		GenericConversionService genericConversionService = new GenericConversionService();
		
		for (Converter converter : converters) {
			genericConversionService.addConverter(converter);
		}
	
		return genericConversionService;
	}
}
