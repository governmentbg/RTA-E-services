package bg.government.regixclient.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.xml.bind.JAXBElement;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import bg.demax.regixclient.mvr.bds.IdentifierTypeDto;
import bg.government.regixclient.app.regixclient.RegixClient;
import bg.government.regixclient.app.regixclient.RegixOperation;
import bg.government.regixclient.app.utils.CallContextDtos;
import bg.government.regixclient.requests.CallContext;
import bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoRequestType;
import bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoResponseType;
import bg.government.regixclient.requests.mvr.erch.ForeignIdentityInfoRequestType;
import bg.government.regixclient.requests.mvr.erch.ForeignIdentityInfoResponseType;
import bg.government.regixclient.requests.mvr.erch.IdentifierType;
import bg.government.regixclient.requests.mvr.mpsv2.GetMotorVehicleRegistrationInfoV2ResponseType;
import bg.government.regixclient.requests.mvr.mpsv2.MotorVehicleRegistrationRequestTypeV2;

public class RegixClientMvrServicesIT extends BaseRegixClientIT {
	
    @Autowired
	private bg.government.regixclient.requests.mvr.bds.ObjectFactory bdsObjectFactory;
    
	@Autowired
	private bg.government.regixclient.requests.mvr.mpsv2.ObjectFactory mpsObjectFactory;
	
	@Autowired
    private bg.government.regixclient.requests.mvr.erch.ObjectFactory erchObjectFactory;
	
	@Test
	public void test_getPersonalIdentityInfo_with_specific_client() throws Exception {
		RegixClient regixClient = regixClients.get(ADR_CLIENT);

		PersonalIdentityInfoRequestType request = bdsObjectFactory.createPersonalIdentityInfoRequestType();
    	request.setEGN("test");
    	request.setIdentityDocumentNumber("test");

    	JAXBElement<PersonalIdentityInfoRequestType> requestBodyElement = bdsObjectFactory.createPersonalIdentityInfoRequest(request);

    	CallContext callContext = conversionService.convert(CallContextDtos.IDENTITY_INFO_SEARCH.getDto(), CallContext.class);

    	PersonalIdentityInfoResponseType response = regixClient.getResponseType(requestBodyElement, RegixOperation.PERSONAL_IDENTITY_INFO_SEARCH, callContext);

    	System.err.println(objectMapper.writeValueAsString(response));

    	writeResponseToFile(ADR_CLIENT, "personal_identity", response);

    	assertNotNull(response);
		assertEquals("1212124563", response.getEGN());
	}

	@Test
	public void test_getPersonalIdentityInfo_with_all_clients() throws Exception {
		PersonalIdentityInfoRequestType request = bdsObjectFactory.createPersonalIdentityInfoRequestType();
    	request.setEGN("test");
    	request.setIdentityDocumentNumber("test");

    	JAXBElement<PersonalIdentityInfoRequestType> requestBodyElement = bdsObjectFactory.createPersonalIdentityInfoRequest(request);

    	CallContext callContext = conversionService.convert(CallContextDtos.IDENTITY_INFO_SEARCH.getDto(), CallContext.class);

    	PersonalIdentityInfoResponseType response = new PersonalIdentityInfoResponseType();

    	testAllCerts(response, requestBodyElement, callContext, RegixOperation.PERSONAL_IDENTITY_INFO_SEARCH);	
	}

	@Test
	public void test_getPersonalResponseDtoV2_with_specific_client() throws Exception {
		RegixClient regixClient = regixClients.get(ADR_CLIENT);

		PersonalIdentityInfoRequestType request = bdsObjectFactory.createPersonalIdentityInfoRequestType();
    	request.setEGN("test");
    	request.setIdentityDocumentNumber("test");

    	JAXBElement<PersonalIdentityInfoRequestType> requestBodyElement = bdsObjectFactory.createPersonalIdentityInfoRequest(request);

    	CallContext callContext = conversionService.convert(CallContextDtos.IDENTITY_INFO_SEARCH_V2.getDto(), CallContext.class);

    	PersonalIdentityInfoResponseType response = regixClient.getResponseType(requestBodyElement, RegixOperation.PERSONAL_IDENTITY_INFO_SEARCH_V2, callContext);

    	System.err.println(objectMapper.writeValueAsString(response));

    	writeResponseToFile(ADR_CLIENT, "personal_identity_v2", response);

    	assertNotNull(response);
		assertEquals("Успешна операция", response.getReturnInformations().getInfo());
	}

	@Test
	public void test_getPersonalResponseDtoV2_with_all_clients() throws Exception {
		PersonalIdentityInfoRequestType request = bdsObjectFactory.createPersonalIdentityInfoRequestType();
    	request.setEGN("test");
    	request.setIdentityDocumentNumber("test");

    	JAXBElement<PersonalIdentityInfoRequestType> requestBodyElement = bdsObjectFactory.createPersonalIdentityInfoRequest(request);

    	CallContext callContext = conversionService.convert(CallContextDtos.IDENTITY_INFO_SEARCH_V2.getDto(), CallContext.class);

    	testAllCerts(new PersonalIdentityInfoResponseType(), requestBodyElement, callContext, RegixOperation.PERSONAL_IDENTITY_INFO_SEARCH_V2);
	}

	@Test
	public void test_getForeignerPersonalIdentityInfo_with_specific_client() throws Exception {
		RegixClient regixClient = regixClients.get(ADR_CLIENT);

		ForeignIdentityInfoRequestType request = erchObjectFactory.createForeignIdentityInfoRequestType();
    	request.setIdentifier("test");
    	request.setIdentifierType(IdentifierType.fromValue(IdentifierTypeDto.LN_CH.value()));

		JAXBElement<ForeignIdentityInfoRequestType> requestBodyElement = erchObjectFactory.createForeignIdentityInfoRequest(request);

    	CallContext callContext = conversionService.convert(CallContextDtos.IDENTITY_INFO_SEARCH.getDto(), CallContext.class);

		ForeignIdentityInfoResponseType response = regixClient.getResponseType(requestBodyElement,RegixOperation.FOREIGNER_IDENTITY_INFO_SEARCH, callContext);
		System.err.println(objectMapper.writeValueAsString(response));

    	writeResponseToFile(ADR_CLIENT, "personal_identity", response);

    	assertNotNull(response);
		assertEquals("Успешна операция", response.getReturnInformations().getInfo());
	}

	@Test
	public void test_getForeignerPersonalIdentityInfo_with_all_clients() throws Exception {
		ForeignIdentityInfoRequestType request = erchObjectFactory.createForeignIdentityInfoRequestType();
    	request.setIdentifier("test");
    	request.setIdentifierType(IdentifierType.fromValue(IdentifierTypeDto.LN_CH.value()));

		JAXBElement<ForeignIdentityInfoRequestType> requestBodyElement = erchObjectFactory.createForeignIdentityInfoRequest(request);

    	CallContext callContext = conversionService.convert(CallContextDtos.IDENTITY_INFO_SEARCH.getDto(), CallContext.class);
    	ForeignIdentityInfoResponseType response = new ForeignIdentityInfoResponseType();

    	testAllCerts(response, requestBodyElement, callContext, RegixOperation.FOREIGNER_IDENTITY_INFO_SEARCH);
	}

	@Test
	public void test_getMotorVehicleRegistration_with_specific_client() throws Exception {
		RegixClient regixClient = regixClients.get(ADR_CLIENT);
		MotorVehicleRegistrationRequestTypeV2 request = mpsObjectFactory.createMotorVehicleRegistrationRequestTypeV2();
    	request.setIdentifier("test");

    	JAXBElement<MotorVehicleRegistrationRequestTypeV2> requestBodyElement = mpsObjectFactory.createGetMotorVehicleRegistrationInfoV2Request(request);

    	CallContext callContext = conversionService.convert(CallContextDtos.MOTOR_VEHICLE_REGISTRATION_INFO_SEARCH.getDto(), CallContext.class);

		GetMotorVehicleRegistrationInfoV2ResponseType response = regixClient.getResponseType(requestBodyElement, RegixOperation.MOTOR_VEHICLE_REGISTRATION_INFO_SEARCH, callContext);
		System.err.println(objectMapper.writeValueAsString(response));

    	writeResponseToFile(ADR_CLIENT, "motor_veh_registration", response);

    	assertNotNull(response);
		assertEquals("OK", response.getResponse().getReturnInformation().getInfo());
	}

	@Test
	public void test_getMotorVehicleRegistration_with_all_clients() throws Exception {
		MotorVehicleRegistrationRequestTypeV2 request = mpsObjectFactory.createMotorVehicleRegistrationRequestTypeV2();
    	request.setIdentifier("test");

    	JAXBElement<MotorVehicleRegistrationRequestTypeV2> requestBodyElement = mpsObjectFactory.createGetMotorVehicleRegistrationInfoV2Request(request);

    	CallContext callContext = conversionService.convert(CallContextDtos.MOTOR_VEHICLE_REGISTRATION_INFO_SEARCH.getDto(), CallContext.class);

    	GetMotorVehicleRegistrationInfoV2ResponseType response = new GetMotorVehicleRegistrationInfoV2ResponseType();
    	testAllCerts(response, requestBodyElement, callContext, RegixOperation.MOTOR_VEHICLE_REGISTRATION_INFO_SEARCH);
	}
}
