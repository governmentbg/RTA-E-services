package bg.government.regixclient.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.xml.bind.JAXBElement;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import bg.government.regixclient.app.regixclient.RegixClient;
import bg.government.regixclient.app.regixclient.RegixOperation;
import bg.government.regixclient.app.utils.CallContextDtos;
import bg.government.regixclient.requests.CallContext;
import bg.government.regixclient.requests.nra.employmentcontracts.ContractsFilterType;
import bg.government.regixclient.requests.nra.employmentcontracts.EikTypeType;
import bg.government.regixclient.requests.nra.employmentcontracts.EmploymentContractsRequest;
import bg.government.regixclient.requests.nra.employmentcontracts.EmploymentContractsResponse;
import bg.government.regixclient.requests.nra.employmentcontracts.IdentityTypeRequest;

public class RegixClientNraServicesIT extends BaseRegixClientIT {

	@Autowired
	private bg.government.regixclient.requests.nra.employmentcontracts.ObjectFactory ecObjectFactory;

	@Test
	public void test_getEmploymentContractsInfo_with_specific_client() throws Exception {
		RegixClient regixClient = regixClients.get(ADR_CLIENT);

		EmploymentContractsRequest request = ecObjectFactory.createEmploymentContractsRequest();
		request.setContractsFilter(ContractsFilterType.ALL);
		IdentityTypeRequest identityTypeRequest = ecObjectFactory.createIdentityTypeRequest();
		identityTypeRequest.setID("test");
		identityTypeRequest.setTYPE(EikTypeType.EGN);
		request.setIdentity(identityTypeRequest);

		JAXBElement<EmploymentContractsRequest> requestElement = ecObjectFactory.createEmploymentContractsRequest(request);

		CallContext callContext = conversionService.convert(CallContextDtos.EMPLOYMENT_CONTRACTS_INFO_SEARCH.getDto(), CallContext.class);

		EmploymentContractsResponse response = regixClient.getResponseType(requestElement, RegixOperation.EMPLOYMENT_CONTRACTS_INFO_SEARCH, callContext);
		writeResponseToFile(ADR_CLIENT, "employment_contracts_check", response);

		System.err.println(objectMapper.writeValueAsString(response));

		assertNotNull(response);
		assertEquals("1234123411", response.getIdentity().getID());
	}

	@Test
	public void test_getEmploymentContractsInfo_with_all_clients() throws Exception {
		EmploymentContractsRequest request = ecObjectFactory.createEmploymentContractsRequest();
		request.setContractsFilter(ContractsFilterType.ALL);
		IdentityTypeRequest identityTypeRequest = ecObjectFactory.createIdentityTypeRequest();
		identityTypeRequest.setID("test");
		identityTypeRequest.setTYPE(EikTypeType.EGN);
		request.setIdentity(identityTypeRequest);

		JAXBElement<EmploymentContractsRequest> requestElement = ecObjectFactory.createEmploymentContractsRequest(request);

		CallContext callContext = conversionService.convert(CallContextDtos.EMPLOYMENT_CONTRACTS_INFO_SEARCH.getDto(), CallContext.class);

		testAllCerts(new EmploymentContractsResponse(), requestElement, callContext, RegixOperation.EMPLOYMENT_CONTRACTS_INFO_SEARCH);
	}
}
