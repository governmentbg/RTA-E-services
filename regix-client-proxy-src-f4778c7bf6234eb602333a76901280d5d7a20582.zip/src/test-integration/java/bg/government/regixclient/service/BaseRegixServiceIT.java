package bg.government.regixclient.service;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import bg.government.regixclient.app.config.BeanConfiguration;
import bg.government.regixclient.app.config.PostgresConfig;
import bg.government.regixclient.app.config.RegixClientProxyConstants;
import bg.government.regixclient.app.regixclient.RegixClientConfiguration;
import bg.government.regixclient.app.security.SecurityRole;
import bg.government.regixclient.app.security.SecurityUtilService;
import bg.government.regixclient.app.security.UserDetailsServiceImpl;

@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles(RegixClientProxyConstants.SPRING_PROFILE_INTEGRATION_TEST)
@ContextConfiguration(classes = { RegixClientConfiguration.class, BeanConfiguration.class, PostgresConfig.class,
		RegixServiceConfig.class })
public abstract class BaseRegixServiceIT {

	@MockBean
	private SecurityUtilService securityUtilService;

	@Before
	public void setup() {
		Mockito.when(securityUtilService.getCurrentUserDetails()).thenReturn(new User("Client3", 
				"", AuthorityUtils.commaSeparatedStringToAuthorityList(UserDetailsServiceImpl.ROLE_PREFIX + SecurityRole.GENERIC_USER)));
	}

}
