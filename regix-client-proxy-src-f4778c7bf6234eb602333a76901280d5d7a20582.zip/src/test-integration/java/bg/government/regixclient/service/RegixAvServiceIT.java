package bg.government.regixclient.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;

import bg.demax.regixclient.av.tr.actualstatev3.ActualStateRequestDto;
import bg.demax.regixclient.av.tr.actualstatev3.ActualStateResponseDto;
import bg.demax.regixclient.av.tr.uicvalidation.ValidUICIdentifierDto;
import bg.demax.regixclient.av.tr.uicvalidation.ValidUICInfoDto;
import bg.government.regixclient.app.service.RegixAvService;
import bg.government.regixclient.app.utils.CallContextDtos;

public class RegixAvServiceIT extends BaseRegixServiceIT {

	/*
	 * iaaa25 to localhost - when having to go through a jumphost when using vpn to
	 * forward execute: ssh -J backend@drive.demax.bg backend@192.168.168.25 -L5010:localhost:5432
	 */
	
	@Autowired
	private RegixAvService regixAvService;
	
	@Test
	public void getValidUICInfo_test() throws Exception {
		ValidUICIdentifierDto identifierDto = validUICIdentifierDto();
		HttpHeaders headers = new HttpHeaders();
		ValidUICInfoDto infoDto = regixAvService.getValidUICInfo(identifierDto, headers);
		
		assertNotNull(infoDto);
		assertEquals("201593301", infoDto.getUic());
	}
	
	@Test
	public void getActualState_test() throws Exception {
		ActualStateRequestDto requestDto = actualStateRequestDto();
		ActualStateResponseDto responseDto = regixAvService.getActualStateV3(requestDto, new HttpHeaders());
		
		assertNotNull(responseDto);
		assertEquals("test", responseDto.getDeed().getUIC());
	}
	
	private ValidUICIdentifierDto validUICIdentifierDto() {
		ValidUICIdentifierDto identifierDto = new ValidUICIdentifierDto();
		identifierDto.setCallContext(CallContextDtos.VALID_UIC_INFO_SEARCH.getDto());
		identifierDto.setUic("test");
		return identifierDto;
	}
	
	private ActualStateRequestDto actualStateRequestDto() {
		ActualStateRequestDto requestDto = new ActualStateRequestDto();
		requestDto.setCallContext(CallContextDtos.ACTUAL_STATE_V3.getDto());
		requestDto.setUIC("test");
		requestDto.setFieldList("001, 00020");

		return requestDto;
	}
}
