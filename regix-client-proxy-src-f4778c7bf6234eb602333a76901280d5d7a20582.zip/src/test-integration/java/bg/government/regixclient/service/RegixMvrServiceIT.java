package bg.government.regixclient.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;

import bg.demax.regixclient.mvr.bds.ForeignerIdentityDto;
import bg.demax.regixclient.mvr.bds.IdentifierTypeDto;
import bg.demax.regixclient.mvr.bds.PersonalResponseDto;
import bg.demax.regixclient.mvr.bds.PersonalResponseDtoV2;
import bg.demax.regixclient.mvr.bds.PersonalIdentityDto;
import bg.demax.regixclient.mvr.mpsv2.MotorVehicleIdentifierDto;
import bg.demax.regixclient.mvr.mpsv2.MotorVehicleRegistrationInfoDto;
import bg.government.regixclient.app.service.RegixMvrService;
import bg.government.regixclient.app.utils.CallContextDtos;

public class RegixMvrServiceIT extends BaseRegixServiceIT {

	/*
	 * iaaa25 to localhost - when having to go through a jumphost when using vpn to
	 * forward execute: ssh -J backend@drive.demax.bg backend@192.168.168.25 -L5010:localhost:5432
	 */

	@Autowired
	private RegixMvrService regixMvrService;	

	@Test
	public void getPersonalIdentityInfo_test() throws Exception {
		PersonalIdentityDto personalIdentity = personalIdentityDto();
		PersonalResponseDto personalDto = regixMvrService.getPersonalIdentityInfo(personalIdentity, new HttpHeaders());

		assertNotNull(personalDto);
		assertEquals("ЛЮБОМИР", personalDto.getPersonNames().getFirstName());
	}

	@Test
	public void getPersonalResponseDtoV2_test() throws Exception {
		PersonalIdentityDto personalIdentity = personalIdentityDto();
		PersonalResponseDtoV2 personalDto = regixMvrService.getPersonalIdentityInfoV2(personalIdentity, new HttpHeaders());

		assertNotNull(personalDto);
		assertEquals("Успешна операция", personalDto.getReturnInformation().getInfo());
	}

	@Test
	public void getForeignerIdentityInfo_test() throws Exception {
		ForeignerIdentityDto foreignerIdentity = foreignerIdentityDto();
		PersonalResponseDto personalDto = regixMvrService.getForeignerIdentityInfo(foreignerIdentity, new HttpHeaders());

		assertNotNull(personalDto);
		assertEquals("ПАПАНИКОЛАУ ДАДАДАДАДАДАДАДАДАД", personalDto.getPersonNames().getFirstName());
	}

	@Test
	public void getMotorVehicleRegistrationInfo_test() throws Exception {
		MotorVehicleIdentifierDto motorVehicleIdentifier = motorVehicleIdentifierDto();
		MotorVehicleRegistrationInfoDto motorVehicleRegistrationInfoDto = regixMvrService
				.getMotorVehicleRegistrationInfo(motorVehicleIdentifier, new HttpHeaders());

		assertNotNull(motorVehicleRegistrationInfoDto);
		assertEquals("N2",
				motorVehicleRegistrationInfoDto.getResults().getResult().get(0).getVehicleData().getCategory());
	}

	private PersonalIdentityDto personalIdentityDto() {
		PersonalIdentityDto personalIdentityDto = new PersonalIdentityDto();
		personalIdentityDto.setEgn("test");
		personalIdentityDto.setIdentityDocumentNumber("test");
		personalIdentityDto.setCallContext(CallContextDtos.IDENTITY_INFO_SEARCH.getDto());
		return personalIdentityDto;
	}

	private ForeignerIdentityDto foreignerIdentityDto() {
		ForeignerIdentityDto foreignerIdentityDto = new ForeignerIdentityDto();
		foreignerIdentityDto.setIdentifier("test");
		foreignerIdentityDto.setIdentifierType(IdentifierTypeDto.LN_CH);
		foreignerIdentityDto.setCallContext(CallContextDtos.IDENTITY_INFO_SEARCH.getDto());
		return foreignerIdentityDto;
	}

	private MotorVehicleIdentifierDto motorVehicleIdentifierDto() {
		MotorVehicleIdentifierDto motorVehicleIdentifierDto = new MotorVehicleIdentifierDto();
		motorVehicleIdentifierDto.setRegistrationNumber("test");
		motorVehicleIdentifierDto.setCallContext(CallContextDtos.MOTOR_VEHICLE_REGISTRATION_INFO_SEARCH.getDto());
		return motorVehicleIdentifierDto;
	}

}
