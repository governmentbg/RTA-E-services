package bg.government.regixclient.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;

import bg.demax.regixclient.nra.employmentcontracts.ContractsFilterTypeDto;
import bg.demax.regixclient.nra.employmentcontracts.EikTypeTypeDto;
import bg.demax.regixclient.nra.employmentcontracts.EmploymentContractsIdentifierDto;
import bg.demax.regixclient.nra.employmentcontracts.EmploymentContractsInfoDto;
import bg.demax.regixclient.nra.employmentcontracts.IdentityTypeRequestDto;
import bg.government.regixclient.app.config.RegixClientProxyTestConstants;
import bg.government.regixclient.app.service.RegixNraService;
import bg.government.regixclient.app.utils.CallContextDtos;

public class RegixNraServiceIT extends BaseRegixServiceIT {
	
	/*
	 * iaaa25 to localhost - when having to go through a jumphost when using vpn to
	 * forward execute: ssh -J backend@drive.demax.bg backend@192.168.168.25 -L5010:localhost:5432
	 */
	
	@Autowired
	private RegixNraService regixNraService;
	
	@Test
	public void getEmploymentContractsInfo_test() throws Exception {
		EmploymentContractsIdentifierDto identifierDto = employmentContractsIdentifierDto();
		EmploymentContractsInfoDto infoDto = regixNraService.getEmploymentContractsInfo(identifierDto, new HttpHeaders());
		
		assertNotNull(infoDto);
		assertEquals(RegixClientProxyTestConstants.REGIX_NRA_ECONTRACTS_SUCCESS_STATUS_CODE, infoDto.getStatus().getCode());
	}

	private EmploymentContractsIdentifierDto employmentContractsIdentifierDto() {
		EmploymentContractsIdentifierDto identifierDto = new EmploymentContractsIdentifierDto();
		identifierDto.setCallContext(CallContextDtos.EMPLOYMENT_CONTRACTS_INFO_SEARCH.getDto());
		identifierDto.setContractsFilter(ContractsFilterTypeDto.ALL);
		IdentityTypeRequestDto identity = new IdentityTypeRequestDto();
		identity.setId("test");
		identity.setType(EikTypeTypeDto.EGN);
		identifierDto.setIdentity(identity);
		return identifierDto;
	}
}
