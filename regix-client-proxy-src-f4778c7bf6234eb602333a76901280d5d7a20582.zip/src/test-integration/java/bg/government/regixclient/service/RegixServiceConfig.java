package bg.government.regixclient.service;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.convert.converter.Converter;
import org.springframework.core.convert.support.GenericConversionService;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import bg.government.regixclient.app.config.BeanQualifiers;
import bg.government.regixclient.app.config.RegixClientProxyConstants;
import bg.government.regixclient.app.service.CacheService;

@Configuration
@ComponentScan({"bg.government.regixclient.app.converter",
	"bg.government.regixclient.app.service"})
@Profile(RegixClientProxyConstants.SPRING_PROFILE_INTEGRATION_TEST)
@SuppressWarnings("rawtypes")
public class RegixServiceConfig {
	
	@Autowired
	private List<Converter> converters;

	@Bean
	@Qualifier(BeanQualifiers.DEFAULT_SPRING_BOOT_CONVERSION_SERVICE)
	public GenericConversionService genericConversionService() {
		GenericConversionService genericConversionService = new GenericConversionService();
		
		for (Converter converter : converters) {
			genericConversionService.addConverter(converter);
		}
	
		return genericConversionService;
	}

	@Bean
	public CacheService logService() {
		return new CacheService();
	}
	
	@Bean
	public NamedParameterJdbcTemplate namedParameterJdbcTemplate(DataSource dataSource) {
		return new NamedParameterJdbcTemplate(dataSource);
	}

	@Bean public PlatformTransactionManager txManager(DataSource dataSource) { 
		return new DataSourceTransactionManager(dataSource); 
	}

}
