package bg.government.regixclient.app;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.DefaultMockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import bg.government.regixclient.app.security.SecurityGroups;
import bg.government.regixclient.app.security.UserDetailsServiceImpl;
import bg.government.regixclient.app.utils.SecurityTestUtil;

@WebAppConfiguration
public abstract class AbstractMvcTest extends AbstractRepositoryTest {

	@Autowired
	private WebApplicationContext webApplicationContext;

	protected MockMvc mockMvc;
	protected MvcObjectMapper mvcOm;

	@Before
	public void setup() {
		this.mockMvc = setupMockMvcBuilder(MockMvcBuilders.webAppContextSetup(webApplicationContext), true).build();
		this.mvcOm = new MvcObjectMapper(mockMvc);
	}

	protected DefaultMockMvcBuilder setupMockMvcBuilder(DefaultMockMvcBuilder builder, boolean withCsrf) {
		MockHttpServletRequestBuilder mockServletRequestBuilder = MockMvcRequestBuilders.get("/");
		if (withCsrf) {
			mockServletRequestBuilder.with(csrf());
		}

		return builder
				.defaultRequest(mockServletRequestBuilder.contentType(MediaType.APPLICATION_JSON)
						.header("X-Requested-With", "XMLHttpRequest"))
				.apply(SecurityMockMvcConfigurers.springSecurity());
	}

	protected ResultActions performRequestWithRole(MockHttpServletRequestBuilder request, String role)
			throws Exception {
		if (!role.startsWith(UserDetailsServiceImpl.ROLE_PREFIX)) {
			role = UserDetailsServiceImpl.ROLE_PREFIX + role;
		}
	
		request.with(user(new User("TechinspClient", "", 
				AuthorityUtils.commaSeparatedStringToAuthorityList(role))));
		return mockMvc.perform(request);
	}
	
	protected ResultActions performRequestWithRole(MockHttpServletRequestBuilder request, String role, String username)
			throws Exception {
		if (!role.startsWith(UserDetailsServiceImpl.ROLE_PREFIX)) {
			role = UserDetailsServiceImpl.ROLE_PREFIX + role;
		}
	
		request.with(user(new User(username, "", AuthorityUtils.commaSeparatedStringToAuthorityList(role))));
		return mockMvc.perform(request);
	}
	
	protected void testRequestPermissions(MockHttpServletRequestBuilder request, SecurityGroups securityGroup,
			ResultMatcher whenHasPermissions, ResultMatcher whenNoPermissions) throws Exception {
		testRequestPermissions(request, Arrays.asList(securityGroup.getRolesInGroup()), whenHasPermissions, whenNoPermissions);
	}

	protected void testRequestPermissions(MockHttpServletRequestBuilder request, List<String> rolesWithPermissions,
			ResultMatcher whenHasPermissions, ResultMatcher whenNoPermissions) throws Exception {
		mockMvc.perform(request).andExpect(status().isForbidden());		
		
		SecurityTestUtil.getAllRoles().forEach(role -> {
			boolean hasPermission = rolesWithPermissions.contains(role);
			ResultMatcher expectedResult = hasPermission ? whenHasPermissions : whenNoPermissions;

			try {
				performRequestWithRole(request, role).andExpect(expectedResult);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

}