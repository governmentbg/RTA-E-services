package bg.government.regixclient.app;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import bg.government.regixclient.app.RegixClientApplication;
import bg.government.regixclient.app.config.RegixClientProxyConstants;
import bg.government.regixclient.app.utils.PostgreDbCleaner;
import bg.government.regixclient.app.utils.SqlScriptExecutor;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = RegixClientApplication.class)
@ActiveProfiles(RegixClientProxyConstants.SPRING_PROFILE_UNIT_TEST)

//without this data source pools will NOT be closed after context reload and as a result will use up database connections
@DirtiesContext(classMode = ClassMode.AFTER_CLASS)
public abstract class AbstractRepositoryTest {

	@Autowired
	protected SqlScriptExecutor sqlScriptExecutor;

	@Autowired
	protected DataSource regixDataSource;

	@Before
	public void reintDatabase() throws SQLException {
		PostgreDbCleaner.trunkateAllAndResetSequences(regixDataSource.getConnection());
	}
}
