package bg.government.regixclient.app;

import java.io.IOException;
import java.util.List;

import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bg.government.regixclient.app.utils.ObjectMapperUtils;

public class MvcObjectMapper {
	private MockMvc mockMvc;
	protected ObjectMapper om;

	public MvcObjectMapper(MockMvc mockMvc) {
		this.mockMvc = mockMvc;
		this.om = ObjectMapperUtils.getNewConfiguredObjectMapper();
		this.om.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
	}

	public <T> T getResponseObjectFromRequest(MockHttpServletRequestBuilder request, Class<T> clazz)
			throws Exception {
		return getResponseObjectFromResultActions(mockMvc.perform(request), clazz);
	}

	public <T> T getResponseObjectFromResultActions(ResultActions resultActions, Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {
		String responseJson = resultActions.andReturn().getResponse().getContentAsString();
		
		return this.om.readValue(responseJson, clazz);
	}

	public <T> List<T> getListFromResultActions(ResultActions resultActions, Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {
		String responseJson = resultActions.andReturn().getResponse()
				.getContentAsString();

		JavaType type = this.om.getTypeFactory()
				.constructParametricType(List.class, clazz);
		List<T> response = this.om.readValue(responseJson, type);

		return response;
	}
}
