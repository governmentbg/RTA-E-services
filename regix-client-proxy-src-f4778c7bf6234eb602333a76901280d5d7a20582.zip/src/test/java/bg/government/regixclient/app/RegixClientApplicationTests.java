package bg.government.regixclient.app;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import bg.government.regixclient.app.config.BeanQualifiers;
import bg.government.regixclient.app.service.RegixMvrService;

@SpringBootTest
@RunWith(SpringRunner.class)
public class RegixClientApplicationTests {

	@Autowired
	private RegixMvrService regixService;

	@Autowired
	@Qualifier(BeanQualifiers.TYPE_ENABLED_JSON_OBJECT_MAPPER)
	public ObjectMapper jsonMapper;
	
	@Test
	public void contextLoads() {
		assertNotNull(regixService);
		assertNotNull(jsonMapper);
	}

}
