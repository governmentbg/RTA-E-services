package bg.government.regixclient.app.config;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.testcontainers.containers.PostgreSQLContainer;

import com.zaxxer.hikari.HikariDataSource;

import bg.government.regixclient.app.config.RegixClientProxyConstants;
import bg.government.regixclient.app.utils.DockerContainerSingletons;

@Configuration
@Profile(RegixClientProxyConstants.SPRING_PROFILE_UNIT_TEST)
public class RegixDbTestConfiguration {

	@Bean
	public DataSource regixDbDataSource() throws SQLException {
		PostgreSQLContainer<?> pgContainer = DockerContainerSingletons.getRegixPgContainer();

		HikariDataSource dataSource = new HikariDataSource();
		dataSource.setJdbcUrl(pgContainer.getJdbcUrl());
		dataSource.setPassword(pgContainer.getPassword());
		dataSource.setUsername(pgContainer.getUsername());

		return dataSource;
	}

}
