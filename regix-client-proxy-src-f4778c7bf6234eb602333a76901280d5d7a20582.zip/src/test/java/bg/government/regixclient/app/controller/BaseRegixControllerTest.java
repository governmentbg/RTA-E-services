package bg.government.regixclient.app.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.util.Map;

import org.junit.Before;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import bg.demax.regixclient.mvr.bds.BaseRequestDto;
import bg.government.regixclient.app.AbstractMvcTest;
import bg.government.regixclient.app.regixclient.RegixClient;
import bg.government.regixclient.app.utils.ObjectMapperUtils;

public abstract class BaseRegixControllerTest extends AbstractMvcTest {

	@MockBean
	protected Map<String, RegixClient> regixClients;
	
	@Mock
	protected RegixClient regixClient;
	
	@Before
	public void init() {
		Mockito.when(regixClients.get(Mockito.any())).thenReturn(regixClient);
	}
	
	protected MockHttpServletRequestBuilder getPostRequest(String endpoint, BaseRequestDto requestDto) throws Exception {
		MockHttpServletRequestBuilder request = post(endpoint);
		request.contentType(MediaType.APPLICATION_JSON_UTF8);
		request.content(ObjectMapperUtils.toJson(requestDto));
		return request;
	}

}
