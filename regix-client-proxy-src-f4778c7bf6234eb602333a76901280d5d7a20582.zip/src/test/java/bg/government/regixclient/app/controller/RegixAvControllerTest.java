package bg.government.regixclient.app.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.Arrays;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeFactory;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import bg.demax.regixclient.av.tr.actualstatev3.ActualStateRequestDto;
import bg.demax.regixclient.av.tr.actualstatev3.ActualStateResponseDto;
import bg.demax.regixclient.av.tr.uicvalidation.ValidUICIdentifierDto;
import bg.demax.regixclient.av.tr.uicvalidation.ValidUICInfoDto;
import bg.demax.regixclient.mvr.bds.CallContextDto;
import bg.government.regixclient.app.security.SecurityGroups;
import bg.government.regixclient.app.security.SecurityRole;
import bg.government.regixclient.app.service.BaseRegixService;
import bg.government.regixclient.app.utils.CallContextDtos;
import bg.government.regixclient.app.utils.RegexingSqlScriptBuilder;
import bg.government.regixclient.app.utils.SqlScriptExecutor;
import bg.government.regixclient.app.utils.TestScripts;
import bg.government.regixclient.requests.av.tr.actualstatev3.ActualStateResponseV3;
import bg.government.regixclient.requests.av.tr.actualstatev3.DeedType;
import bg.government.regixclient.requests.av.tr.uicvalidation.LegalFormType;
import bg.government.regixclient.requests.av.tr.uicvalidation.StatusType;
import bg.government.regixclient.requests.av.tr.uicvalidation.ValidUICResponseType;

public class RegixAvControllerTest extends BaseRegixControllerTest {

	private static final String AV_ENDPOINT = "/av";
	private static final String UIC_VALIDATION_INFO_ENDPOINT = AV_ENDPOINT + "/tr/uic-info";
	private static final String ACTUAL_STATE_V3_ENDPOINT = AV_ENDPOINT + "/tr/actual-state/v3";

	@Autowired
	private SqlScriptExecutor sqlScriptExecutor;
	
	private HttpHeaders headers;

	@Before
	public void setupControllerTest() {
		Arrays.asList(TestScripts.LOGS_AV_TR_ACTUAL_STATE_V3, TestScripts.LOGS_UIC_VALIDATION)
			.forEach(scriptPath -> {
				new RegexingSqlScriptBuilder()
				.addJsonStringReplacement("requestTime", LocalDateTime.now(), Arrays.asList(0))
				.replaceFor(scriptPath)
				.passAsResource(sqlScriptExecutor::execute);
		});

		
		headers = new HttpHeaders();
		headers.add(BaseRegixService.CACHE_FIRST_PERIOD_FROM_HEADER_NAME, "24");
		headers.add(BaseRegixService.CACHE_SECOND_PERIOD_FROM_HEADER_NAME, "48");
	}

	/*
	 * UIC VALIDATION TESTS
	 */

	@Test
	public void getValidUICInfo_check_permissions() throws Exception {
		ValidUICIdentifierDto identifierDto = validUICIdentifierDto("test", null);

		MockHttpServletRequestBuilder request = getPostRequest(UIC_VALIDATION_INFO_ENDPOINT, identifierDto);

		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isBadRequest(), status().isForbidden());
	}

	@Test
	public void getValidUICInfo_invalid_params() throws Exception {
		ValidUICIdentifierDto identifierDto = validUICIdentifierDto("test", null);

		MockHttpServletRequestBuilder request = getPostRequest(UIC_VALIDATION_INFO_ENDPOINT, identifierDto);

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isBadRequest());
	}

	@Test
	public void getValidUICInfo_from_cache() throws Exception {
		ValidUICIdentifierDto identifierDto = validUICIdentifierDto("test1",
				CallContextDtos.VALID_UIC_INFO_SEARCH.getDto());

		MockHttpServletRequestBuilder request = getPostRequest(UIC_VALIDATION_INFO_ENDPOINT, identifierDto).headers(headers);
		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER)
				.andExpect(status().is2xxSuccessful());
		ValidUICInfoDto infoDto = mvcOm.getResponseObjectFromResultActions(resultActions, ValidUICInfoDto.class);
		assertNotNull(infoDto);
		assertEquals("201593301 от cache", infoDto.getUic());
	}

	@Test
	public void getValidUICInfo_ignore_cache_and_get_from_regix() throws Exception {
		ValidUICIdentifierDto identifierDto = validUICIdentifierDto("test2",
				CallContextDtos.VALID_UIC_INFO_SEARCH.getDto());

		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(validUICResponseType());

		MockHttpServletRequestBuilder request = getPostRequest(UIC_VALIDATION_INFO_ENDPOINT, identifierDto);
		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER)
				.andExpect(status().is2xxSuccessful());
		ValidUICInfoDto infoDto = mvcOm.getResponseObjectFromResultActions(resultActions, ValidUICInfoDto.class);
		assertNotNull(infoDto);
		assertEquals("201593301 от RegiX", infoDto.getUic());
	}

	@Test
	public void getValidUICInfo_from_regix_and_from_cache() throws Exception {
		ValidUICIdentifierDto identifierDto = validUICIdentifierDto("test3",
				CallContextDtos.VALID_UIC_INFO_SEARCH.getDto());

		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(validUICResponseType())
				.thenThrow(new RuntimeException("Regix client should not be called more than once"));

		MockHttpServletRequestBuilder request = getPostRequest(UIC_VALIDATION_INFO_ENDPOINT, identifierDto).headers(headers);

		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER)
				.andExpect(status().is2xxSuccessful());
		ValidUICInfoDto infoDto = mvcOm.getResponseObjectFromResultActions(resultActions, ValidUICInfoDto.class);
		assertNotNull(infoDto);
		assertEquals("201593301 от RegiX", infoDto.getUic());
		LocalDate validForDate = infoDto.getDataValidForDate();
		assertEquals(2020, validForDate.getYear());
		assertEquals(Month.JANUARY, validForDate.getMonth());
		assertEquals(1, validForDate.getDayOfMonth());

		/* executes the request again to verify the response is taken from the cache this time: */
		resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER)
				.andExpect(status().is2xxSuccessful());
		infoDto = mvcOm.getResponseObjectFromResultActions(resultActions, ValidUICInfoDto.class);
		assertNotNull(infoDto);
		assertEquals("201593301 от RegiX", infoDto.getUic());
		validForDate = infoDto.getDataValidForDate();
		assertEquals(2020, validForDate.getYear());
		assertEquals(Month.JANUARY, validForDate.getMonth());
		assertEquals(1, validForDate.getDayOfMonth());
	}
	
	@Test
	public void getValidUICInfo_from_regix_and_from_cache_as_admin_as_TechinspClient() throws Exception {
		ValidUICIdentifierDto identifierDto = validUICIdentifierDto("test3",
				CallContextDtos.VALID_UIC_INFO_SEARCH.getDto());

		String outgoingClientName = "TechinspClient";
		Mockito.when(regixClients.containsKey(outgoingClientName)).thenReturn(true);
		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(validUICResponseType())
				.thenThrow(new RuntimeException("Regix client should not be called more than once"));

		
		HttpHeaders headersWithAdminUser = new HttpHeaders();
		headersWithAdminUser.add(BaseRegixService.CACHE_FIRST_PERIOD_FROM_HEADER_NAME, "24");
		headersWithAdminUser.add(BaseRegixService.OUTGOING_CLIENT_NAME_HEADER_NAME, outgoingClientName);
		
		MockHttpServletRequestBuilder request = getPostRequest(UIC_VALIDATION_INFO_ENDPOINT, identifierDto).headers(headersWithAdminUser);

		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER, BaseRegixService.IAAA_PROXIES_ADMIN_CLIENT_NAME)
				.andExpect(status().is2xxSuccessful());
		ValidUICInfoDto infoDto = mvcOm.getResponseObjectFromResultActions(resultActions, ValidUICInfoDto.class);
		assertNotNull(infoDto);
		assertEquals("201593301 от RegiX", infoDto.getUic());
		LocalDate validForDate = infoDto.getDataValidForDate();
		assertEquals(2020, validForDate.getYear());
		assertEquals(Month.JANUARY, validForDate.getMonth());
		assertEquals(1, validForDate.getDayOfMonth());

		/* executes the request again to verify the response is taken from the cache this time: */
		resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER, BaseRegixService.IAAA_PROXIES_ADMIN_CLIENT_NAME)
				.andExpect(status().is2xxSuccessful());
		infoDto = mvcOm.getResponseObjectFromResultActions(resultActions, ValidUICInfoDto.class);
		assertNotNull(infoDto);
		assertEquals("201593301 от RegiX", infoDto.getUic());
		validForDate = infoDto.getDataValidForDate();
		assertEquals(2020, validForDate.getYear());
		assertEquals(Month.JANUARY, validForDate.getMonth());
		assertEquals(1, validForDate.getDayOfMonth());
	}

	/*
	 *  ACTUAL STATE TESTS
	 */
	
	@Test
	public void getActualState_check_permissions() throws Exception {
		ActualStateRequestDto requestDto = actualStateRequestDto("test", "001, 00020", null);

		MockHttpServletRequestBuilder request = getPostRequest(ACTUAL_STATE_V3_ENDPOINT, requestDto);

		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isBadRequest(), status().isForbidden());
	}
	
	@Test
	public void getActualState_invalid_params() throws Exception {
		ActualStateRequestDto requestDto = actualStateRequestDto("test", "001, 00020", null);

		MockHttpServletRequestBuilder request = getPostRequest(ACTUAL_STATE_V3_ENDPOINT, requestDto);

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isBadRequest());
	}

	@Test
	public void getActualState_from_cache() throws Exception {
		ActualStateRequestDto requestDto = actualStateRequestDto("test", "001, 00020", CallContextDtos.ACTUAL_STATE_V3.getDto());

		MockHttpServletRequestBuilder request = getPostRequest(ACTUAL_STATE_V3_ENDPOINT, requestDto).headers(headers);
		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().is2xxSuccessful());
		ActualStateResponseDto infoDto = mvcOm.getResponseObjectFromResultActions(resultActions, ActualStateResponseDto.class);

		assertNotNull(infoDto);
		assertEquals("uic from cache", infoDto.getDeed().getUIC());
	}
	
	@Test
	public void getActualState_ignore_cache_and_get_from_regix() throws Exception {
		ActualStateRequestDto requestDto = actualStateRequestDto("test", "001, 00020", CallContextDtos.VALID_UIC_INFO_SEARCH.getDto());

		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(actualStateResponseV3());

		MockHttpServletRequestBuilder request = getPostRequest(ACTUAL_STATE_V3_ENDPOINT, requestDto);
		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().is2xxSuccessful());
		ActualStateResponseDto responseDto = mvcOm.getResponseObjectFromResultActions(resultActions, ActualStateResponseDto.class);

		assertNotNull(responseDto);
		assertEquals("uic from RegiX", responseDto.getDeed().getUIC());
	}

	@Test
	public void getActualState_from_regix_and_from_cache() throws Exception {
		ActualStateRequestDto requestDto = actualStateRequestDto("test_new", "001, 00020", CallContextDtos.VALID_UIC_INFO_SEARCH.getDto());

		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(actualStateResponseV3())
				.thenThrow(new RuntimeException("Regix client should not be called more than once"));

		MockHttpServletRequestBuilder request = getPostRequest(ACTUAL_STATE_V3_ENDPOINT, requestDto).headers(headers);
		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().is2xxSuccessful());
		ActualStateResponseDto responseDto = mvcOm.getResponseObjectFromResultActions(resultActions, ActualStateResponseDto.class);

		assertNotNull(responseDto);
		assertEquals("uic from RegiX", responseDto.getDeed().getUIC());

		/*
		 * executes the request again to verify the response is taken from the cache
		 * this time:
		 */
		resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().is2xxSuccessful());
		responseDto = mvcOm.getResponseObjectFromResultActions(resultActions, ActualStateResponseDto.class);

		assertNotNull(responseDto);
		assertEquals("uic from RegiX", responseDto.getDeed().getUIC());
	}
	
	private ValidUICIdentifierDto validUICIdentifierDto(String uic, CallContextDto callContextDto) {
		ValidUICIdentifierDto identifierDto = new ValidUICIdentifierDto();
		identifierDto.setCallContext(callContextDto);
		identifierDto.setUic(uic);
		return identifierDto;
	}
	
	private ValidUICResponseType validUICResponseType() throws Exception {
		ValidUICResponseType validUICResponseType = new ValidUICResponseType();
		validUICResponseType.setDataValidForDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(new GregorianCalendar(2020,0,1)));
		validUICResponseType.setUIC("201593301 от RegiX");
		LegalFormType legalFormType = new LegalFormType();
		validUICResponseType.setLegalForm(legalFormType);
		validUICResponseType.setStatus(StatusType.НОВА_ПАРТИДА);
		return validUICResponseType;
	}
	
	private ActualStateRequestDto actualStateRequestDto(String uic, String fieldList, CallContextDto callContextDto) {
		ActualStateRequestDto requestDto = new ActualStateRequestDto();
		requestDto.setCallContext(callContextDto);
		requestDto.setUIC(uic);
		requestDto.setFieldList(fieldList);
		return requestDto;
	}
	
	private ActualStateResponseV3 actualStateResponseV3() throws Exception {
		ActualStateResponseV3 response = new ActualStateResponseV3();
		response.setDataFound(true);
		response.setDataValidForDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(new GregorianCalendar()));
		DeedType deed = new DeedType();
		deed.setCaseNo("case number");
		deed.setCaseYear("2008");
		deed.setUIC("uic from RegiX");
		response.setDeed(deed);

		return response;
	}
}
