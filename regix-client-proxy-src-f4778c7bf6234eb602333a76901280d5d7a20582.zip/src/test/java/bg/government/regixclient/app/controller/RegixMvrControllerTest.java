package bg.government.regixclient.app.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeFactory;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import bg.demax.regixclient.mvr.bds.BaseRequestDto;
import bg.demax.regixclient.mvr.bds.CallContextDto;
import bg.demax.regixclient.mvr.bds.ForeignerIdentityDto;
import bg.demax.regixclient.mvr.bds.IdentifierTypeDto;
import bg.demax.regixclient.mvr.bds.PersonalResponseDto;
import bg.demax.regixclient.mvr.bds.PersonalResponseDtoV2;
import bg.demax.regixclient.mvr.bds.PersonalResponseDtoV3;
import bg.demax.regixclient.mvr.bds.PersonalIdentityDto;
import bg.demax.regixclient.mvr.mpsv2.MotorVehicleIdentifierDto;
import bg.demax.regixclient.mvr.mpsv2.MotorVehicleRegistrationInfoDto;
import bg.government.regixclient.app.config.RegixClientProxyTestConstants;
import bg.government.regixclient.app.exceptions.RegixResponseErrorException;
import bg.government.regixclient.app.security.SecurityGroups;
import bg.government.regixclient.app.security.SecurityRole;
import bg.government.regixclient.app.service.BaseRegixService;
import bg.government.regixclient.app.utils.CallContextDtos;
import bg.government.regixclient.app.utils.RegexingSqlScriptBuilder;
import bg.government.regixclient.app.utils.SqlScriptExecutor;
import bg.government.regixclient.app.utils.TestScripts;
import bg.government.regixclient.requests.mvr.bds.DLCategory;
import bg.government.regixclient.requests.mvr.bds.PersonNames;
import bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoResponseType;
import bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoResponseType.DLCategоries;
import bg.government.regixclient.requests.mvr.bds.ReturnInformation;
import bg.government.regixclient.requests.mvr.erch.ForeignIdentityInfoResponseType;
import bg.government.regixclient.requests.mvr.erch.IdentityDocument;
import bg.government.regixclient.requests.mvr.mpsv2.GetMotorVehicleRegistrationInfoV2ResponseType;
import bg.government.regixclient.requests.mvr.mpsv2.GetMotorVehicleRegistrationInfoV2ResponseType.Response;
import bg.government.regixclient.requests.mvr.mpsv2.GetMotorVehicleRegistrationInfoV2ResponseType.Response.Results;
import bg.government.regixclient.requests.mvr.mpsv2.GetMotorVehicleRegistrationInfoV2ResponseType.Response.Results.Result;
import bg.government.regixclient.requests.mvr.mpsv2.OwnersDataType;
import bg.government.regixclient.requests.mvr.mpsv2.ReturnInformationType;
import bg.government.regixclient.requests.mvr.mpsv2.VehicleDataType;

public class RegixMvrControllerTest extends BaseRegixControllerTest {

	private static final String MVR_ENDPOINT = "/mvr";
	private static final String PERSONAL_IDENTITY_INFO_ENDPOINT = MVR_ENDPOINT + "/personal";
	private static final String PERSONAL_IDENTITY_INFO_V2_ENDPOINT = MVR_ENDPOINT + "/personal/v2";
	private static final String PERSONAL_IDENTITY_INFO_V3_ENDPOINT = MVR_ENDPOINT + "/personal/v3";
	private static final String FOREIGNER_IDENTITY_INFO_ENDPOINT = MVR_ENDPOINT + "/foreigner";
	private static final String MOTOR_VEHICLE_REGISTRATION_INFO_ENDPOINT = MVR_ENDPOINT + "/motor-vehicle/v2";

	@Autowired
	private SqlScriptExecutor sqlScriptExecutor;

	private HttpHeaders headers;

	@Before
	public void setupControllerTest() {

		TestScripts.MVR_LOGS.forEach(scriptPath -> {
			new RegexingSqlScriptBuilder().addJsonStringReplacement("requestTime", LocalDateTime.now())
					.replaceFor(scriptPath).passAsResource(sqlScriptExecutor::execute);
		});

		headers = new HttpHeaders();
		headers.add(BaseRegixService.CACHE_FIRST_PERIOD_FROM_HEADER_NAME, "24");
	}

	// ----------------------------------------------------------------------------

	@Test
	public void getPersonalIdentityInfo_check_permissions() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test", "test", null);

		MockHttpServletRequestBuilder request = getPostRequest(PERSONAL_IDENTITY_INFO_ENDPOINT, personalIdentityDto)
				.headers(headers);

		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isBadRequest(), status().isForbidden());
	}

	@Test
	public void getPersonalIdentityInfoV2_check_permissions() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test", "test", null);

		MockHttpServletRequestBuilder request = getPostRequest(PERSONAL_IDENTITY_INFO_V2_ENDPOINT, personalIdentityDto)
				.headers(headers);

		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isBadRequest(), status().isForbidden());
	}

	@Test
	public void getPersonalIdentityInfoV3_check_permissions() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test", "test", null);

		MockHttpServletRequestBuilder request = getPostRequest(PERSONAL_IDENTITY_INFO_V3_ENDPOINT, personalIdentityDto)
				.headers(headers);

		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isBadRequest(), status().isForbidden());
	}

	@Test
	public void getForeignerPersonalIdentityInfo_check_permissions() throws Exception {
		ForeignerIdentityDto foreignerIdentityDto = foreignerIdentityDto("test", null);

		MockHttpServletRequestBuilder request = getPostRequest(FOREIGNER_IDENTITY_INFO_ENDPOINT, foreignerIdentityDto);

		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isBadRequest(), status().isForbidden());
	}

	@Test
	public void getMotorVehicleRegistrationInfo_check_permissions() throws Exception {
		MotorVehicleIdentifierDto motorVehicleIdentifierDto = motorVehicleIdentifierDto("test", null);

		MockHttpServletRequestBuilder request = getPostRequest(MOTOR_VEHICLE_REGISTRATION_INFO_ENDPOINT,
				motorVehicleIdentifierDto);

		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isBadRequest(), status().isForbidden());
	}

	// ----------------------------------------------------------------------------

	@Test
	public void getPersonalIdentityInfo_invalid_params() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test", "test", null);

		MockHttpServletRequestBuilder request = getPostRequest(PERSONAL_IDENTITY_INFO_ENDPOINT, personalIdentityDto);

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isBadRequest());
	}

	@Test
	public void getPersonalIdentityInfo_from_cache_regix_success_operation_return_code() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test1", "test1",
				CallContextDtos.IDENTITY_INFO_SEARCH.getDto());

		execute_and_verify_PersonalDto(PERSONAL_IDENTITY_INFO_ENDPOINT, personalIdentityDto, "ЛЮБОМИР от cache",
				headers);
	}

	@Test
	public void getPersonalIdentityInfo_from_cache_regix_no_data_found_operation_return_code() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test2", "test2",
				CallContextDtos.IDENTITY_INFO_SEARCH.getDto());

		execute_and_verify_PersonalDto(PERSONAL_IDENTITY_INFO_ENDPOINT, personalIdentityDto, null, headers);
	}

	@Test
	public void getPersonalIdentityInfo_ignore_cache_and_get_from_regix() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test3", "test3",
				CallContextDtos.IDENTITY_INFO_SEARCH.getDto());

		execute_with_mock_response_from_regix_and_verify_PersonalDto(PERSONAL_IDENTITY_INFO_ENDPOINT,
				personalIdentityDto, "ЛЮБОМИР от RegiX", personalIdentityInfoResponseType());
	}

	@Test
	public void getPersonalIdentityInfo_from_regix_and_check_if_cached() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test4", "test4",
				CallContextDtos.IDENTITY_INFO_SEARCH.getDto());

		execute_with_mock_response_from_regix_and_verify_PersonalDto(PERSONAL_IDENTITY_INFO_ENDPOINT,
				personalIdentityDto, "ЛЮБОМИР от RegiX", personalIdentityInfoResponseType());
		/*
		 * executes the request again to verify the response is taken from the cache
		 * this time:
		 */
		execute_and_verify_PersonalDto(PERSONAL_IDENTITY_INFO_ENDPOINT, personalIdentityDto, "ЛЮБОМИР от RegiX",
				headers);
	}

	@Test
	public void getPersonalIdentityInfo_throws_RegixConnectionFailureException() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test", "test",
				CallContextDtos.IDENTITY_INFO_SEARCH.getDto());

		MockHttpServletRequestBuilder request = getPostRequest(PERSONAL_IDENTITY_INFO_ENDPOINT, personalIdentityDto);

		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(new RegixResponseErrorException());

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isFailedDependency());
	}

	// ----------------------------------------------------------------------------

	@Test
	public void getPersonalIdentityInfoV2_invalid_params() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test", "test", null);

		MockHttpServletRequestBuilder request = getPostRequest(PERSONAL_IDENTITY_INFO_V2_ENDPOINT, personalIdentityDto);

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isBadRequest());
	}

	@Test
	public void getPersonalIdentityInfoV2_from_cache_regix_success() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test1", "test1",
				CallContextDtos.IDENTITY_INFO_SEARCH_V2.getDto());

		execute_and_verify_PersonalResponseDtoV2(PERSONAL_IDENTITY_INFO_V2_ENDPOINT, personalIdentityDto,
				"Category from cache", headers);
	}

	@Test
	public void getPersonalIdentityInfoV2_ignore_cache_and_get_from_regix() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test3", "test3",
				CallContextDtos.IDENTITY_INFO_SEARCH_V2.getDto());

		execute_with_mock_response_from_regix_and_verify_PersonalDtoV2(PERSONAL_IDENTITY_INFO_V2_ENDPOINT,
				personalIdentityDto, "Category from RegiX", personalIdentityInfoResponseType());
	}

	@Test
	public void getPersonalIdentityInfoV2_from_regix_and_check_if_cached() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test4", "test4",
				CallContextDtos.IDENTITY_INFO_SEARCH_V2.getDto());

		execute_with_mock_response_from_regix_and_verify_PersonalDtoV2(PERSONAL_IDENTITY_INFO_V2_ENDPOINT,
				personalIdentityDto, "Category from RegiX", personalIdentityInfoResponseType());
		/*
		 * executes the request again to verify the response is taken from the cache
		 * this time:
		 */
		execute_and_verify_PersonalResponseDtoV2(PERSONAL_IDENTITY_INFO_V2_ENDPOINT, personalIdentityDto,
				"Category from RegiX", headers);
	}

	@Test
	public void getPersonalIdentityInfoV2_throws_RegixConnectionFailureException() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test", "test",
				CallContextDtos.IDENTITY_INFO_SEARCH_V2.getDto());

		MockHttpServletRequestBuilder request = getPostRequest(PERSONAL_IDENTITY_INFO_V2_ENDPOINT, personalIdentityDto);

		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(new RegixResponseErrorException());

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isFailedDependency());
	}

	// ----------------------------------------------------------------------------

	@Test
	public void getPersonalIdentityInfoV3_invalid_params() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test", "test", null);

		MockHttpServletRequestBuilder request = getPostRequest(PERSONAL_IDENTITY_INFO_V3_ENDPOINT, personalIdentityDto);

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isBadRequest());
	}

	@Test
	public void getPersonalIdentityInfoV3_from_cache_regix_success() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test1", "test1",
				CallContextDtos.IDENTITY_INFO_SEARCH_V3.getDto());

		execute_and_verify_PersonalResponseDtoV3(PERSONAL_IDENTITY_INFO_V3_ENDPOINT, personalIdentityDto,
				"Category from cache", headers);
	}

	@Test
	public void getPersonalIdentityInfoV3_ignore_cache_and_get_from_regix() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test3", "test3",
				CallContextDtos.IDENTITY_INFO_SEARCH_V3.getDto());

		execute_with_mock_response_from_regix_and_verify_PersonalDtoV3(PERSONAL_IDENTITY_INFO_V3_ENDPOINT,
				personalIdentityDto, "Category from RegiX", personalIdentityInfoResponseType());
	}

	@Test
	public void getPersonalIdentityInfoV3_from_regix_and_check_if_cached() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test4", "test4",
				CallContextDtos.IDENTITY_INFO_SEARCH_V3.getDto());

		execute_with_mock_response_from_regix_and_verify_PersonalDtoV3(PERSONAL_IDENTITY_INFO_V3_ENDPOINT,
				personalIdentityDto, "Category from RegiX", personalIdentityInfoResponseType());
		/*
		 * executes the request again to verify the response is taken from the cache
		 * this time:
		 */
		execute_and_verify_PersonalResponseDtoV3(PERSONAL_IDENTITY_INFO_V3_ENDPOINT, personalIdentityDto,
				"Category from RegiX", headers);
	}

	@Test
	public void getPersonalIdentityInfoV3_throws_RegixConnectionFailureException() throws Exception {
		PersonalIdentityDto personalIdentityDto = personalIdentityDto("test", "test",
				CallContextDtos.IDENTITY_INFO_SEARCH_V3.getDto());

		MockHttpServletRequestBuilder request = getPostRequest(PERSONAL_IDENTITY_INFO_V3_ENDPOINT, personalIdentityDto);

		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenThrow(new RegixResponseErrorException());

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isFailedDependency());
	}

	// ----------------------------------------------------------------------------

	@Test
	public void getForeignerPersonalIdentityInfo_invalid_params() throws Exception {
		ForeignerIdentityDto foreignerIdentityDto = foreignerIdentityDto("test", null);

		MockHttpServletRequestBuilder request = getPostRequest(FOREIGNER_IDENTITY_INFO_ENDPOINT, foreignerIdentityDto);

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isBadRequest());
	}

	@Test
	public void getForeignerPersonalIdentityInfo_from_cache_regix_success_operation_return_code() throws Exception {
		ForeignerIdentityDto foreignerIdentityDto = foreignerIdentityDto("test1",
				CallContextDtos.IDENTITY_INFO_SEARCH.getDto());

		execute_and_verify_PersonalDto(FOREIGNER_IDENTITY_INFO_ENDPOINT, foreignerIdentityDto, "ПАПАНИКОЛАУ от cache",
				headers);
	}

	@Test
	public void getForeignerPersonalIdentityInfo_ignore_cache_and_get_from_regix() throws Exception {
		ForeignerIdentityDto foreignerIdentityDto = foreignerIdentityDto("test2",
				CallContextDtos.IDENTITY_INFO_SEARCH.getDto());

		execute_with_mock_response_from_regix_and_verify_PersonalDto(FOREIGNER_IDENTITY_INFO_ENDPOINT,
				foreignerIdentityDto, "ПАПАНИКОЛАУ от RegiX", foreignIdentityInfoResponseType());
	}

	@Test
	public void getForeignerPersonalIdentityInfo_from_regix_and_check_if_cached() throws Exception {
		ForeignerIdentityDto foreignerIdentityDto = foreignerIdentityDto("test3",
				CallContextDtos.IDENTITY_INFO_SEARCH.getDto());

		execute_with_mock_response_from_regix_and_verify_PersonalDto(FOREIGNER_IDENTITY_INFO_ENDPOINT,
				foreignerIdentityDto, "ПАПАНИКОЛАУ от RegiX", foreignIdentityInfoResponseType());
		/*
		 * executes the request again to verify the response is taken from the cache
		 * this time:
		 */
		execute_and_verify_PersonalDto(FOREIGNER_IDENTITY_INFO_ENDPOINT, foreignerIdentityDto, "ПАПАНИКОЛАУ от RegiX",
				headers);
	}

	// ----------------------------------------------------------------------------

	@Test
	public void getMotorVehicleRegistrationInfo_invalid_params() throws Exception {
		MotorVehicleIdentifierDto motorVehicleIdentifierDto = motorVehicleIdentifierDto("test", null);

		MockHttpServletRequestBuilder request = getPostRequest(MOTOR_VEHICLE_REGISTRATION_INFO_ENDPOINT,
				motorVehicleIdentifierDto);

		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isBadRequest());
	}

	@Test
	public void getMotorVehicleRegistrationInfo_from_cache_regix_success_operation_return_code() throws Exception {
		MotorVehicleIdentifierDto motorVehicleIdentifierDto = motorVehicleIdentifierDto("test1",
				CallContextDtos.MOTOR_VEHICLE_REGISTRATION_INFO_SEARCH.getDto());

		execute_and_verify_MotorVehicleRegistrationInfoDto(motorVehicleIdentifierDto, "N2 от cache", headers);
	}

	@Test
	public void getMotorVehicleRegistrationInfo_ignore_cache_and_get_from_regix() throws Exception {
		MotorVehicleIdentifierDto motorVehicleIdentifierDto = motorVehicleIdentifierDto("test2",
				CallContextDtos.MOTOR_VEHICLE_REGISTRATION_INFO_SEARCH.getDto());

		execute_with_mock_response_from_regix_and_verify_MotorVehicleRegistrationInfoDto(motorVehicleIdentifierDto,
				"N2 от RegiX");
	}

	@Test
	public void getMotorVehicleRegistrationInfo_from_regix_and_check_if_cached() throws Exception {
		MotorVehicleIdentifierDto motorVehicleIdentifierDto = motorVehicleIdentifierDto("test3",
				CallContextDtos.MOTOR_VEHICLE_REGISTRATION_INFO_SEARCH.getDto());

		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(motorVehicleRegistrationInfoV2ResponseType())
				.thenThrow(new RuntimeException("Regix client should not be called more than once"));

		MockHttpServletRequestBuilder request = getPostRequest(MOTOR_VEHICLE_REGISTRATION_INFO_ENDPOINT,
				motorVehicleIdentifierDto).headers(headers);

		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER)
				.andExpect(status().is2xxSuccessful());
		MotorVehicleRegistrationInfoDto motorVehDto = mvcOm.getResponseObjectFromResultActions(resultActions,
				MotorVehicleRegistrationInfoDto.class);
		assertNotNull(motorVehDto);
		assertEquals("N2 от RegiX", motorVehDto.getResults().getResult().get(0).getVehicleData().getCategory());
		LocalDate firstRegDate = motorVehDto.getResults().getResult().get(0).getVehicleData()
				.getFirstRegistrationDate();
		assertEquals(2000, firstRegDate.getYear());
		assertEquals(Month.FEBRUARY, firstRegDate.getMonth());
		assertEquals(29, firstRegDate.getDayOfMonth());

		/*
		 * executes the request again to verify the response is taken from the cache
		 * this time:
		 */
		resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER)
				.andExpect(status().is2xxSuccessful());
		motorVehDto = mvcOm.getResponseObjectFromResultActions(resultActions, MotorVehicleRegistrationInfoDto.class);
		assertNotNull(motorVehDto);
		assertEquals("N2 от RegiX", motorVehDto.getResults().getResult().get(0).getVehicleData().getCategory());
		firstRegDate = motorVehDto.getResults().getResult().get(0).getVehicleData().getFirstRegistrationDate();
		assertEquals(2000, firstRegDate.getYear());
		assertEquals(Month.FEBRUARY, firstRegDate.getMonth());
		assertEquals(29, firstRegDate.getDayOfMonth());
	}

	// ----------------------------------------------------------------------------

	private <RES> void execute_with_mock_response_from_regix_and_verify_PersonalDto(String endpoint,
			BaseRequestDto requestDto, String expectedFirstName, RES response) throws Exception {

		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response)
				.thenThrow(new RuntimeException("Regix client should not be called more than once"));

		execute_and_verify_PersonalDto(endpoint, requestDto, expectedFirstName);
	}

	private <RES> void execute_and_verify_PersonalDto(String endpoint, BaseRequestDto requestDto,
			String expectedFirstName) throws Exception {
		execute_and_verify_PersonalDto(endpoint, requestDto, expectedFirstName, new HttpHeaders());
	}

	private <RES> void execute_and_verify_PersonalDto(String endpoint, BaseRequestDto requestDto,
			String expectedFirstName, HttpHeaders headers) throws Exception {
		MockHttpServletRequestBuilder request = getPostRequest(endpoint, requestDto).headers(headers);

		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER)
				.andExpect(status().is2xxSuccessful());
		PersonalResponseDto personalDto = mvcOm.getResponseObjectFromResultActions(resultActions,
				PersonalResponseDto.class);
		assertNotNull(personalDto);
		assertEquals(expectedFirstName, personalDto.getPersonNames().getFirstName());
	}

	private <RES> void execute_with_mock_response_from_regix_and_verify_PersonalDtoV2(String endpoint,
			BaseRequestDto requestDto, String expectedFirstName, RES response) throws Exception {

		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response)
				.thenThrow(new RuntimeException("Regix client should not be called more than once"));

		execute_and_verify_PersonalResponseDtoV2(endpoint, requestDto, expectedFirstName, new HttpHeaders());
	}

	private <RES> void execute_with_mock_response_from_regix_and_verify_PersonalDtoV3(String endpoint,
			BaseRequestDto requestDto, String expectedFirstName, RES response) throws Exception {

		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response)
				.thenThrow(new RuntimeException("Regix client should not be called more than once"));

		execute_and_verify_PersonalResponseDtoV3(endpoint, requestDto, expectedFirstName, new HttpHeaders());
	}

	private <RES> void execute_and_verify_PersonalResponseDtoV2(String endpoint, BaseRequestDto requestDto,
			String expectedCategory, HttpHeaders headers) throws Exception {
		MockHttpServletRequestBuilder request = getPostRequest(endpoint, requestDto).headers(headers);

		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER)
				.andExpect(status().is2xxSuccessful());
		PersonalResponseDtoV2 personalDto = mvcOm.getResponseObjectFromResultActions(resultActions,
				PersonalResponseDtoV2.class);
		assertNotNull(personalDto);
		assertEquals(expectedCategory, personalDto.getDlCategоries().get(0).getCategory());
	}

	private <RES> void execute_and_verify_PersonalResponseDtoV3(String endpoint, BaseRequestDto requestDto,
			String expectedCategory, HttpHeaders headers) throws Exception {
		MockHttpServletRequestBuilder request = getPostRequest(endpoint, requestDto).headers(headers);

		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER)
				.andExpect(status().is2xxSuccessful());
		PersonalResponseDtoV3 personalDto = mvcOm.getResponseObjectFromResultActions(resultActions,
				PersonalResponseDtoV3.class);
		assertNotNull(personalDto);
		assertEquals(expectedCategory, personalDto.getDlCategоries().get(0).getCategory());
	}

	private void execute_with_mock_response_from_regix_and_verify_MotorVehicleRegistrationInfoDto(
			BaseRequestDto requestDto, String expectedCategory) throws Exception {

		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(motorVehicleRegistrationInfoV2ResponseType())
				.thenThrow(new RuntimeException("Regix client should not be called more than once"));

		execute_and_verify_MotorVehicleRegistrationInfoDto(requestDto, expectedCategory);
	}

	private void execute_and_verify_MotorVehicleRegistrationInfoDto(BaseRequestDto requestDto, String expectedCategory)
			throws Exception {
		execute_and_verify_MotorVehicleRegistrationInfoDto(requestDto, expectedCategory, new HttpHeaders());
	}

	private void execute_and_verify_MotorVehicleRegistrationInfoDto(BaseRequestDto requestDto, String expectedCategory,
			HttpHeaders headers) throws Exception {
		MockHttpServletRequestBuilder request = getPostRequest(MOTOR_VEHICLE_REGISTRATION_INFO_ENDPOINT, requestDto)
				.headers(headers);

		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER)
				.andExpect(status().is2xxSuccessful());
		MotorVehicleRegistrationInfoDto motorVehDto = mvcOm.getResponseObjectFromResultActions(resultActions,
				MotorVehicleRegistrationInfoDto.class);
		assertNotNull(motorVehDto);
		assertEquals(expectedCategory, motorVehDto.getResults().getResult().get(0).getVehicleData().getCategory());
	}

	// ----------------------------------------------------------------------------

	private PersonalIdentityDto personalIdentityDto(String egn, String idn, CallContextDto callContextDto) {
		PersonalIdentityDto personalIdentityDto = new PersonalIdentityDto();
		personalIdentityDto.setEgn(egn);
		personalIdentityDto.setIdentityDocumentNumber(idn);
		personalIdentityDto.setCallContext(callContextDto);
		return personalIdentityDto;
	}

	private ForeignerIdentityDto foreignerIdentityDto(String identifier, CallContextDto callContextDto) {
		ForeignerIdentityDto foreignerIdentityDto = new ForeignerIdentityDto();
		foreignerIdentityDto.setIdentifier(identifier);
		foreignerIdentityDto.setIdentifierType(IdentifierTypeDto.LN_CH);
		foreignerIdentityDto.setCallContext(callContextDto);
		return foreignerIdentityDto;
	}

	private MotorVehicleIdentifierDto motorVehicleIdentifierDto(String regNumber, CallContextDto callContextDto) {
		MotorVehicleIdentifierDto motorVehicleIdentifierDto = new MotorVehicleIdentifierDto();
		motorVehicleIdentifierDto.setRegistrationNumber(regNumber);
		motorVehicleIdentifierDto.setCallContext(callContextDto);
		return motorVehicleIdentifierDto;
	}

	private PersonalIdentityInfoResponseType personalIdentityInfoResponseType() {
		PersonalIdentityInfoResponseType personalIdentityInfoResponseType = new PersonalIdentityInfoResponseType();
		ReturnInformation returnInformation = new ReturnInformation();
		returnInformation.setReturnCode(RegixClientProxyTestConstants.REGIX_MVR_SUCCESS_OPERATION_RETURN_CODE);
		personalIdentityInfoResponseType.setReturnInformations(returnInformation);
		PersonNames personNames = new PersonNames();
		personNames.setFirstName("ЛЮБОМИР от RegiX");
		personalIdentityInfoResponseType.setPersonNames(personNames);
		personalIdentityInfoResponseType.setDLCommonRestrictions("Common restrictions");
		DLCategоries dCategоries = new DLCategоries();
		dCategоries.setDLCategory(new ArrayList<DLCategory>());
		DLCategory category = new DLCategory();
		category.setCategory("Category from RegiX");
		dCategоries.getDLCategory().add(category);
		personalIdentityInfoResponseType.setDLCategоries(dCategоries);
		return personalIdentityInfoResponseType;
	}

	private ForeignIdentityInfoResponseType foreignIdentityInfoResponseType() {
		ForeignIdentityInfoResponseType foreignIdentityInfoResponseType = new ForeignIdentityInfoResponseType();
		bg.government.regixclient.requests.mvr.erch.ReturnInformation returnInformation = new bg.government.regixclient.requests.mvr.erch.ReturnInformation();
		returnInformation.setReturnCode(RegixClientProxyTestConstants.REGIX_MVR_SUCCESS_OPERATION_RETURN_CODE);
		foreignIdentityInfoResponseType.setReturnInformations(returnInformation);
		bg.government.regixclient.requests.mvr.erch.PersonNames personNames = new bg.government.regixclient.requests.mvr.erch.PersonNames();
		personNames.setFirstName("ПАПАНИКОЛАУ от RegiX");
		foreignIdentityInfoResponseType.setPersonNames(personNames);
		IdentityDocument identityDocument = new IdentityDocument();
		foreignIdentityInfoResponseType.setIdentityDocument(identityDocument);
		return foreignIdentityInfoResponseType;
	}

	private GetMotorVehicleRegistrationInfoV2ResponseType motorVehicleRegistrationInfoV2ResponseType()
			throws Exception {
		GetMotorVehicleRegistrationInfoV2ResponseType responseType = new GetMotorVehicleRegistrationInfoV2ResponseType();
		Response response = new Response();
		ReturnInformationType returnInformation = new ReturnInformationType();
		returnInformation.setReturnCode(RegixClientProxyTestConstants.REGIX_MVR_SUCCESS_OPERATION_RETURN_CODE);
		response.setReturnInformation(returnInformation);
		Results results = new Results();
		Result result = new Result();
		VehicleDataType vehicleDataType = new VehicleDataType();
		vehicleDataType.setCategory("N2 от RegiX");
		vehicleDataType.setFirstRegistrationDate(
				DatatypeFactory.newInstance().newXMLGregorianCalendar(new GregorianCalendar(2000, 1, 29)));
		result.setVehicleData(vehicleDataType);
		OwnersDataType ownersDataType = new OwnersDataType();
		result.setOwnersData(ownersDataType);
		results.getResult().add(result);
		response.setResults(results);
		responseType.setResponse(response);
		return responseType;
	}
}
