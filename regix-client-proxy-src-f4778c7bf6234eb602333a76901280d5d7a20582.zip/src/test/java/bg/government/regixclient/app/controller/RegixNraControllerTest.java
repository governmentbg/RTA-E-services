package bg.government.regixclient.app.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.Arrays;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeFactory;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import bg.demax.regixclient.mvr.bds.CallContextDto;
import bg.demax.regixclient.nra.employmentcontracts.ContractsFilterTypeDto;
import bg.demax.regixclient.nra.employmentcontracts.EikTypeTypeDto;
import bg.demax.regixclient.nra.employmentcontracts.EmploymentContractsIdentifierDto;
import bg.demax.regixclient.nra.employmentcontracts.EmploymentContractsInfoDto;
import bg.demax.regixclient.nra.employmentcontracts.IdentityTypeRequestDto;
import bg.government.regixclient.app.config.RegixClientProxyTestConstants;
import bg.government.regixclient.app.security.SecurityGroups;
import bg.government.regixclient.app.security.SecurityRole;
import bg.government.regixclient.app.service.BaseRegixService;
import bg.government.regixclient.app.utils.CallContextDtos;
import bg.government.regixclient.app.utils.RegexingSqlScriptBuilder;
import bg.government.regixclient.app.utils.SqlScriptExecutor;
import bg.government.regixclient.app.utils.TestScripts;
import bg.government.regixclient.requests.nra.employmentcontracts.ContractsFilterType;
import bg.government.regixclient.requests.nra.employmentcontracts.EContracts;
import bg.government.regixclient.requests.nra.employmentcontracts.EikTypeType;
import bg.government.regixclient.requests.nra.employmentcontracts.EmploymentContractsResponse;
import bg.government.regixclient.requests.nra.employmentcontracts.ResponseIdentityType;
import bg.government.regixclient.requests.nra.employmentcontracts.StatusType;

public class RegixNraControllerTest extends BaseRegixControllerTest {

	private static final String NRA_ENDPOINT = "/nra";
	private static final String EMPLOYMENT_CONTRACTS_INFO_ENDPOINT = NRA_ENDPOINT + "/employment-contracts";
	
	@Autowired
	private SqlScriptExecutor sqlScriptExecutor;
	
	private HttpHeaders headers;
	
	@Before
	public void setupControllerTest() {
		new RegexingSqlScriptBuilder()
			.addJsonStringReplacement("requestTime", LocalDateTime.now(), Arrays.asList(0))
			.replaceFor(TestScripts.LOGS_EMPLOYMENT_CONTRACTS)
			.passAsResource(sqlScriptExecutor::execute);

		headers = new HttpHeaders();
		headers.add(BaseRegixService.CACHE_FIRST_PERIOD_FROM_HEADER_NAME, "24");
	}
	
	// ----------------------------------------------------------------------------
	
	@Test
	public void getEmploymentContractsInfo_check_permissions() throws Exception {
		EmploymentContractsIdentifierDto identifierDto = employmentContractsIdentifierDto("test", null);
		
		MockHttpServletRequestBuilder request = getPostRequest(EMPLOYMENT_CONTRACTS_INFO_ENDPOINT, identifierDto);

		testRequestPermissions(request, SecurityGroups.FULL_ACCESS, status().isBadRequest(), status().isForbidden());
	}
	
	// ----------------------------------------------------------------------------
	
	@Test 
	public void getEmploymentContractsInfo_invalid_params() throws Exception {
		EmploymentContractsIdentifierDto identifierDto = employmentContractsIdentifierDto("test", null);
		
		MockHttpServletRequestBuilder request = getPostRequest(EMPLOYMENT_CONTRACTS_INFO_ENDPOINT, identifierDto);
		
		performRequestWithRole(request, SecurityRole.GENERIC_USER).andExpect(status().isBadRequest());
	}
	
	@Test
	public void getEmploymentContractsInfo_from_cache_regix_success_operation_return_code() throws Exception {
		EmploymentContractsIdentifierDto identifierDto = employmentContractsIdentifierDto("test1", 
				CallContextDtos.EMPLOYMENT_CONTRACTS_INFO_SEARCH.getDto());
		
		MockHttpServletRequestBuilder request = getPostRequest(EMPLOYMENT_CONTRACTS_INFO_ENDPOINT, identifierDto).headers(headers);
		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER)
				.andExpect(status().is2xxSuccessful());
		EmploymentContractsInfoDto infoDto = mvcOm.getResponseObjectFromResultActions(resultActions, EmploymentContractsInfoDto.class);
		assertNotNull(infoDto);
		assertEquals("1234123411 от cache", infoDto.getIdentity().getId());
	}
	
	@Test
	public void getEmploymentContractsInfo_ignore_cache_and_get_from_regix() throws Exception {
		EmploymentContractsIdentifierDto identifierDto = employmentContractsIdentifierDto("test2",
				CallContextDtos.EMPLOYMENT_CONTRACTS_INFO_SEARCH.getDto());
		
		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(employmentContractsResponse());
		
		MockHttpServletRequestBuilder request = getPostRequest(EMPLOYMENT_CONTRACTS_INFO_ENDPOINT, identifierDto);
		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER)
				.andExpect(status().is2xxSuccessful());
		EmploymentContractsInfoDto infoDto = mvcOm.getResponseObjectFromResultActions(resultActions, EmploymentContractsInfoDto.class);
		assertNotNull(infoDto);
		assertEquals("1234123411 от RegiX", infoDto.getIdentity().getId());
	}
	
	@Test
	public void getEmploymentContractsInfo_from_regix_and_from_cache() throws Exception {
		EmploymentContractsIdentifierDto identifierDto = employmentContractsIdentifierDto("test3", 
				CallContextDtos.EMPLOYMENT_CONTRACTS_INFO_SEARCH.getDto());
		
		Mockito.when(regixClient.getResponseType(Mockito.any(), Mockito.any(), Mockito.any()))
			.thenReturn(employmentContractsResponse())
			.thenThrow(new RuntimeException("Regix client should not be called more than once"));
		
		MockHttpServletRequestBuilder request = getPostRequest(EMPLOYMENT_CONTRACTS_INFO_ENDPOINT, identifierDto).headers(headers);
		ResultActions resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER)
				.andExpect(status().is2xxSuccessful());
		EmploymentContractsInfoDto infoDto = mvcOm.getResponseObjectFromResultActions(resultActions, EmploymentContractsInfoDto.class);
		assertNotNull(infoDto);
		assertEquals("1234123411 от RegiX", infoDto.getIdentity().getId());
		LocalDate reportDate = infoDto.getReportDate();
		assertEquals(1986, reportDate.getYear());
		assertEquals(Month.JULY, reportDate.getMonth());
		assertEquals(14, reportDate.getDayOfMonth());		
		
		/* executes the request again to verify the response is taken from the cache this time: */
		resultActions = performRequestWithRole(request, SecurityRole.GENERIC_USER)
				.andExpect(status().is2xxSuccessful());
		infoDto = mvcOm.getResponseObjectFromResultActions(resultActions, EmploymentContractsInfoDto.class);
		assertNotNull(infoDto);
		assertEquals("1234123411 от RegiX", infoDto.getIdentity().getId());
		reportDate = infoDto.getReportDate();
		assertEquals(1986, reportDate.getYear());
		assertEquals(Month.JULY, reportDate.getMonth());
		assertEquals(14, reportDate.getDayOfMonth());	
	}
	
	// ----------------------------------------------------------------------------
	
	private EmploymentContractsIdentifierDto employmentContractsIdentifierDto(String identityId, CallContextDto callContextDto) {
		EmploymentContractsIdentifierDto identifierDto = new EmploymentContractsIdentifierDto();
		identifierDto.setCallContext(callContextDto);
		identifierDto.setContractsFilter(ContractsFilterTypeDto.ALL);
		IdentityTypeRequestDto identity = new IdentityTypeRequestDto();
		identity.setId(identityId);
		identity.setType(EikTypeTypeDto.EGN);
		identifierDto.setIdentity(identity);
		return identifierDto;
	}
	
	private EmploymentContractsResponse employmentContractsResponse() throws Exception {
		EmploymentContractsResponse response = new EmploymentContractsResponse();
		ResponseIdentityType identityType = new ResponseIdentityType();
		identityType.setID("1234123411 от RegiX");
		identityType.setTYPE(EikTypeType.EGN);
		response.setIdentity(identityType);
		StatusType statusType = new StatusType();
		statusType.setCode(RegixClientProxyTestConstants.REGIX_NRA_ECONTRACTS_SUCCESS_STATUS_CODE);
		response.setStatus(statusType);
		response.setContractsFilter(ContractsFilterType.ALL);
		response.setReportDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(new GregorianCalendar(1986,6,14)));
		EContracts eContracts = new EContracts();
		response.setEContracts(eContracts);
		return response;
	}

}
