package bg.government.regixclient.app.controller;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import bg.government.regixclient.app.AbstractMvcTest;

public class UserControllerTest extends AbstractMvcTest {
	public static final String CURRENT_USER_PATH = "/users/current";
	
	@Test
	public void testGetCurrentUser() {
		//TODO figure out meaningful test
		assertTrue(true);
	}
}
