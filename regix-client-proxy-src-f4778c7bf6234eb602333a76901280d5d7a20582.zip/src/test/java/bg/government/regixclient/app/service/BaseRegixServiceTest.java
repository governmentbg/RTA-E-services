package bg.government.regixclient.app.service;

import java.util.Map;

import javax.xml.bind.JAXBElement;

import org.hamcrest.core.StringContains;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.userdetails.UserDetails;

import bg.demax.regixclient.mvr.bds.BaseRequestDto;
import bg.government.regixclient.app.converter.AppConversionService;
import bg.government.regixclient.app.exceptions.ApplicationException;
import bg.government.regixclient.app.regixclient.RegixClient;
import bg.government.regixclient.app.regixclient.RegixOperation;
import bg.government.regixclient.app.security.SecurityUtilService;

@RunWith(MockitoJUnitRunner.class)
public class BaseRegixServiceTest {
	
	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();
	
	@Mock
	protected Map<String, RegixClient> regixClients;

	@Mock
	protected AppConversionService conversionService;

	@Mock
	protected CacheService cacheService;
	
	@Mock
	protected SecurityUtilService securityUtilService;
	
	@InjectMocks
	private BaseRegixService baseRegixService = new BaseRegixService() {};
	
	@Test
	public void testGetResponse_when_user_is_admin_base_case() throws Exception {
		HttpHeaders headers = new HttpHeaders();
		String outgoingClientName = "CoolOutgoingClient";
		headers.add(BaseRegixService.OUTGOING_CLIENT_NAME_HEADER_NAME, outgoingClientName);
		Mockito.when(regixClients.containsKey(outgoingClientName)).thenReturn(true);
		executeGetResponse(BaseRegixService.IAAA_PROXIES_ADMIN_CLIENT_NAME, headers);
		
		String expectedUserName = BaseRegixService.IAAA_PROXIES_ADMIN_CLIENT_NAME + "." + outgoingClientName;
		Mockito.verify(regixClients, Mockito.times(1)).get(outgoingClientName);
		Mockito.verify(cacheService, Mockito.times(1))
		.smartCache(Mockito.any(), Mockito.any() , Mockito.any(), Mockito.any(), Mockito.eq(expectedUserName));
	}
	
	@Test
	public void testGetResponse_when_user_is_admin_but_no_header__should_throw() throws Exception {
		exceptionRule.expect(ApplicationException.class);
		exceptionRule.expectMessage(StringContains.containsString("admin"));
		HttpHeaders headers = new HttpHeaders();
		executeGetResponse(BaseRegixService.IAAA_PROXIES_ADMIN_CLIENT_NAME, headers);
	}
	
	@Test
	public void testGetResponse_when_user_is_not_admin_base_case() throws Exception {
		String username = "coolUser";
		executeGetResponse(username, new HttpHeaders());
		
		Mockito.verify(regixClients, Mockito.times(1)).get(username);
		Mockito.verify(cacheService, Mockito.times(1))
		.smartCache(Mockito.any(), Mockito.any() , Mockito.any(), Mockito.any(), Mockito.eq(username));
	}
	
	
	private void executeGetResponse(String username, HttpHeaders headers) throws Exception {
		UserDetails ud = Mockito.mock(UserDetails.class);
		Mockito.when(ud.getUsername()).thenReturn(username);
		Mockito.when(securityUtilService.getCurrentUserDetails()).thenReturn(ud);
		
		@SuppressWarnings("unchecked")
		JAXBElement<Object> requestBodyElement = Mockito.mock(JAXBElement.class);
		RegixOperation operation = RegixOperation.ACTUAL_STATE_V3;
		BaseRequestDto baseReqDto = Mockito.mock(BaseRequestDto.class);
		
		baseRegixService.getResponse(requestBodyElement, operation, baseReqDto, headers);	
	}
}
