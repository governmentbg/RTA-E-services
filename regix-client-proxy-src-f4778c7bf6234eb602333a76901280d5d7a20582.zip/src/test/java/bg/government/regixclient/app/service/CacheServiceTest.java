package bg.government.regixclient.app.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.IOException;
import java.time.LocalDateTime;

import org.apache.commons.io.IOUtils;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.databind.ObjectMapper;

import bg.government.regixclient.app.AbstractRepositoryTest;
import bg.government.regixclient.app.cache.CacheDbTablenames;
import bg.government.regixclient.app.cache.CacheEntry;
import bg.government.regixclient.app.config.BeanQualifiers;
import bg.government.regixclient.app.exceptions.ApplicationException;
import bg.government.regixclient.app.security.SecurityRole;
import bg.government.regixclient.app.security.SecurityUtilService;
import bg.government.regixclient.requests.mvr.mpsv2.GetMotorVehicleRegistrationInfoV2ResponseType;
import bg.government.regixclient.requests.mvr.mpsv2.MotorVehicleRegistrationRequestTypeV2;

public class CacheServiceTest extends AbstractRepositoryTest {
	
	private static final String CACHE_ENTRY_JSON_PATH = "/static/cache-entries-json/logs_motor_vehicle_registration_v2.txt";
	private static final Integer DAYS_BACK_ID_1 = 1;

	@Autowired
	private CacheService cacheService;

	@MockBean
	private SecurityUtilService securityUtilService;

	@Autowired
	@Qualifier(BeanQualifiers.TYPE_ENABLED_JSON_OBJECT_MAPPER)
	private ObjectMapper postgreJsonMapper;
	
	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();

	@SuppressWarnings("unchecked")
	@Test
	public void testLogCacheToDb() throws Exception {
		UserDetails ud = new User("Client3", "", AuthorityUtils.commaSeparatedStringToAuthorityList("ROLE_" + SecurityRole.GENERIC_USER));
		Mockito.when(securityUtilService.getCurrentUserDetails()).thenReturn(ud);

		CacheEntry<MotorVehicleRegistrationRequestTypeV2, GetMotorVehicleRegistrationInfoV2ResponseType> cacheEntry = null;
		CacheEntry<MotorVehicleRegistrationRequestTypeV2, GetMotorVehicleRegistrationInfoV2ResponseType> deserializedCacheEntry = null;

		cacheEntry = postgreJsonMapper.readValue(readFile(CACHE_ENTRY_JSON_PATH), CacheEntry.class);
		cacheEntry.setRequestTime(LocalDateTime.now().minusMinutes(1L));
		cacheEntry.setResponseTime(LocalDateTime.now());

		cacheService.logCacheToDb(cacheEntry, CacheDbTablenames.LOGS_MOTOR_VEHICLE_REGISTRATION);
		deserializedCacheEntry = cacheService.getCacheFromDb(cacheEntry.getRequest(), cacheEntry.getClientName(), CacheDbTablenames.LOGS_MOTOR_VEHICLE_REGISTRATION, DAYS_BACK_ID_1);

		assertNotNull(deserializedCacheEntry);
		assertEquals(cacheEntry.getRequest().getIdentifier(), deserializedCacheEntry.getRequest().getIdentifier());

	}

	@Test
	@SuppressWarnings("unchecked")
	public void testLogCacheToDb_No_Result_When_Reponse_In_CacheEntry_Is_Null() throws Exception {
		UserDetails ud = new User("Client3", "", AuthorityUtils.commaSeparatedStringToAuthorityList("ROLE_" + SecurityRole.GENERIC_USER));
		Mockito.when(securityUtilService.getCurrentUserDetails()).thenReturn(ud);

		CacheEntry<MotorVehicleRegistrationRequestTypeV2, GetMotorVehicleRegistrationInfoV2ResponseType> cacheEntry = null;
		CacheEntry<MotorVehicleRegistrationRequestTypeV2, GetMotorVehicleRegistrationInfoV2ResponseType> deserializedCacheEntry = null;

		cacheEntry = postgreJsonMapper.readValue(readFile(CACHE_ENTRY_JSON_PATH), CacheEntry.class);
		cacheEntry.setRequestTime(LocalDateTime.now().minusMinutes(1L));
		cacheEntry.setResponseTime(LocalDateTime.now());
		cacheEntry.setResponse(null);

		cacheService.logCacheToDb(cacheEntry, CacheDbTablenames.LOGS_MOTOR_VEHICLE_REGISTRATION);
		deserializedCacheEntry = cacheService.getCacheFromDb(cacheEntry.getRequest(), cacheEntry.getClientName(), CacheDbTablenames.LOGS_MOTOR_VEHICLE_REGISTRATION, DAYS_BACK_ID_1);
		
		assertNull(deserializedCacheEntry);
		
		String countAll = String.format("SELECT COUNT(*) FROM %s.%s", CacheDbTablenames.LOG_SCHEMA, CacheDbTablenames.LOGS_MOTOR_VEHICLE_REGISTRATION);
		String entriesCount = sqlScriptExecutor.executeSQLQuery(countAll);

		assertEquals("1", entriesCount);
	}
	
	@Test
	public void testMaxCachePeriod() {
		exceptionRule.expect(ApplicationException.class);
		exceptionRule.expectMessage(String.format("Max cache period is %s", CacheService.CACHE_MAX_PERIOD_HOURS));
		cacheService.getCacheFromDb(null, "", "", CacheService.CACHE_MAX_PERIOD_HOURS + 1);
	}

	private String readFile(String path) throws IOException {
		return IOUtils.toString(this.getClass().getResourceAsStream(path), "UTF-8");
	}
}
