package bg.government.regixclient.app.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.function.Consumer;

import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.testcontainers.containers.PostgreSQLContainer;

import com.github.dockerjava.api.command.CreateContainerCmd;

@SuppressWarnings( {"rawtypes", "unchecked"} )
public class DockerContainerSingletons {
	private static PostgreSQLContainer regixPgContainer = null;

	public static synchronized PostgreSQLContainer getRegixPgContainer() throws SQLException {
		if (regixPgContainer == null) {
			String cacheDbVersion = "postgres:10.7";
			regixPgContainer = new PostgreSQLContainer<>(cacheDbVersion);
			regixPgContainer.withCreateContainerCmdModifier(new Consumer<CreateContainerCmd>() {
				@Override
				public void accept(CreateContainerCmd createContainerCmd) {
					createContainerCmd.withHostName("regixPgContainer");
					createContainerCmd.withName("regixPgContainer");
				}
			});
			/*
			 * User name set here exists in PostgreSQL as well.
			 */
			regixPgContainer.withUsername("docker");
			regixPgContainer.start();

			Connection connection = DriverManager.getConnection(regixPgContainer.getJdbcUrl(),
					regixPgContainer.getUsername(), regixPgContainer.getPassword());
			ScriptUtils.executeSqlScript(connection, new ClassPathResource(TestScripts.INIT_REGIX_SCRIPT));
			connection.close();
		}

		return regixPgContainer;
	}
}
