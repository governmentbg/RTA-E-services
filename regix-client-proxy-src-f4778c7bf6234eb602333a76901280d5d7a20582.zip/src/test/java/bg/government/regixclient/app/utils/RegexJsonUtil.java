package bg.government.regixclient.app.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RegexJsonUtil {
	
	public static String replace(Path filePath, String regex, String replacement) {
		return replaceForIndexes(readFile(filePath), regex, replacement, Collections.emptyList());
	}
	
	public static String replace(String str, String regex, String replacement) {
		return replaceForIndexes(str, regex, replacement, Collections.emptyList());
	}
	
	public static String replaceForIndexes(Path filePath, String regex, String replacement, List<Integer> indexes) {
		return replaceForIndexes(readFile(filePath), regex, replacement, indexes);
	}

	public static String replaceForIndexes(String str, String regex, String replacement, List<Integer> indexes) {
		List<MatchResult> matchResults = matchResults(str, regex);
		
		if (indexes == null || indexes.isEmpty()) {
			indexes = getIntListForSize(matchResults.size());
		}

		String strResult = str;
		
		for (Integer currentMatchIndex: indexes) {
			MatchResult matchResult = matchResults.get(currentMatchIndex);
			strResult = replaceAtIndex(strResult, replacement, matchResult);
			matchResults = matchResults(strResult, regex);
		}

		return strResult;
	}
	
	private static List<MatchResult> matchResults(String sqlContent, String regex) {
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(sqlContent);

		List<MatchResult> matchResults = new ArrayList<MatchResult>();

		while (matcher.find()) {
			matchResults.add(matcher.toMatchResult());
		}
		
		return matchResults;
	}

	private static String replaceAtIndex(String input, String replacer, MatchResult matchResult) {
		int groupToBeReplacedIndex = 1;
		String groupToBeReplaced = matchResult.group(groupToBeReplacedIndex);

		int startIndex = matchResult.start(groupToBeReplacedIndex);
		int endIndex = startIndex + groupToBeReplaced.length();

		if (groupToBeReplaced.endsWith(",")) {
			endIndex--;
		}
		
		StringBuilder builder = new StringBuilder(input);
		builder.replace(startIndex, endIndex, replacer);
		return builder.toString();
	}
	
	private static String readFile(Path filePath) {
		Stream<String> lines = null;
		try {
			lines = Files.lines(filePath);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage());
		}
		String contents = lines.collect(Collectors.joining(System.lineSeparator()));
		lines.close();
		
		return contents;
	}
	
	private static List<Integer> getIntListForSize(int listSize) {
		List<Integer> intList = new ArrayList<>();
		
		for (int i = 0; i < listSize; i++) {
			intList.add(i);
		}
		
		return intList;
	}
}