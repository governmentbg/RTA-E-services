package bg.government.regixclient.app.utils;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.IOUtils;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;

public class RegexingSqlScriptBuilder {
	
	private String regexedString;
	
	private List<RegexingParam> regexingParams;
		
	public RegexingSqlScriptBuilder() {
		this.regexingParams = new ArrayList<RegexingSqlScriptBuilder.RegexingParam>();
	}
	
	public RegexingSqlScriptBuilder addJsonReplacement(String jsonPropName, Object replacement) {
		String pattern = getRegexForJsonProp(jsonPropName);
		this.regexingParams.add(new RegexingParam(pattern, String.valueOf(replacement)));
		return this;
	}
	
	public RegexingSqlScriptBuilder addJsonReplacement(String jsonPropName, Object replacement, 
			List<Integer> indexes) {		
		String pattern = getRegexForJsonProp(jsonPropName);
		this.regexingParams.add(new RegexingParam(pattern, String.valueOf(replacement), indexes));
		return this;
	}
	
	public RegexingSqlScriptBuilder addJsonStringReplacement(String jsonPropName, Object replacement) {
		String pattern = getRegexForJsonProp(jsonPropName);
		String strReplacement = "\"" + String.valueOf(replacement) + "\"";
		this.regexingParams.add(new RegexingParam(pattern, strReplacement));
		return this;
	}
	
	public RegexingSqlScriptBuilder addJsonStringReplacement(String jsonPropName, Object replacement,
			List<Integer> indexes) {
		String pattern = getRegexForJsonProp(jsonPropName);
		String strReplacement = "\"" + String.valueOf(replacement) + "\"";
		this.regexingParams.add(new RegexingParam(pattern, strReplacement, indexes));
		return this;
	}

	public RegexingSqlScriptBuilder replaceFor(String scriptPath) {
		String script = readFile(scriptPath);
		
		this.regexedString = script;
		for (RegexingParam regexingParam: this.regexingParams) {
			String pattern = regexingParam.getPattern();
			String replacement = regexingParam.getReplacement();
			List<Integer> indexes = regexingParam.getIndexes();
			
			this.regexedString = RegexJsonUtil.replaceForIndexes(this.regexedString, pattern, replacement, indexes);
		}
		
		return this;
	}
	
	public RegexingSqlScriptBuilder passAsResource(Consumer<Resource> consumer) {
		InputStreamResource inputStreamResource = new InputStreamResource(
				IOUtils.toInputStream(this.regexedString, Charset.defaultCharset()));
		consumer.accept(inputStreamResource);
		return this;
	}
	
	public RegexingSqlScriptBuilder pass(Consumer<String> consumer) {
		consumer.accept(this.regexedString);
		return this;
	}

	private String readFile(String filePath) {
		Path path = Paths.get(this.getClass().getClassLoader().getResource(filePath).getFile());

		Stream<String> lines = null;
		try {
			lines = Files.lines(path);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage());
		}
		String contents = lines.collect(Collectors.joining(System.lineSeparator()));
		lines.close();
		
		return contents;
	}
	
	private String getRegexForJsonProp(String jsonPropName) {
		StringBuilder builder = new StringBuilder();
		builder.append("\"").append(jsonPropName).append("\":").append("\\s*(.*)(\\n)");
		return builder.toString();
	}
	
	private class RegexingParam {
		private String pattern;
		private String replacement;
		private List<Integer> indexes;
		
		public RegexingParam(String pattern, String replacement) {
			this.pattern = pattern;
			this.replacement = replacement;
			this.indexes = Collections.emptyList();
		}
		
		public RegexingParam(String pattern, String replacement, List<Integer> indexes) {
			this.pattern = pattern;
			this.replacement = replacement;
			this.indexes = indexes;
		}

		public String getPattern() {
			return pattern;
		}

		public String getReplacement() {
			return replacement;
		}

		public List<Integer> getIndexes() {
			return indexes;
		}		
		
	}
}
