package bg.government.regixclient.app.utils;

import java.util.Arrays;
import java.util.List;

public interface TestScripts {

	String INIT_REGIX_SCRIPT = "sql/init_regix_db.sql";
	
	String LOGS_FOREIGN_IDENTITY = "sql/logs_foreign_identity.sql";
	String LOGS_MOTOR_VEHICLE_REGISTRATION_V2 = "sql/logs_motor_vehicle_registration_v2.sql";
	String LOGS_PERSONAL_IDENTITY = "sql/logs_personal_identity.sql";
	String LOGS_PERSONAL_IDENTITY_V2 = "sql/logs_personal_identity_v2.sql";
	String LOGS_PERSONAL_IDENTITY_V3 = "sql/logs_personal_identity_v3.sql";
	String LOGS_EMPLOYMENT_CONTRACTS = "sql/logs_employment_contracts.sql";
	String LOGS_UIC_VALIDATION = "sql/logs_uic_validation.sql";
	String LOGS_AV_TR_ACTUAL_STATE_V3 = "sql/logs_av_tr_actual_state_v3.sql";
	
	List<String> MVR_LOGS = Arrays.asList( LOGS_FOREIGN_IDENTITY, LOGS_MOTOR_VEHICLE_REGISTRATION_V2, LOGS_PERSONAL_IDENTITY, LOGS_PERSONAL_IDENTITY_V2, LOGS_PERSONAL_IDENTITY_V3 );	

}
