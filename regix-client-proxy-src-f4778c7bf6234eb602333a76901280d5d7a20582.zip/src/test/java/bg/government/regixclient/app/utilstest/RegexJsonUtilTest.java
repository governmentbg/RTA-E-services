package bg.government.regixclient.app.utilstest;

import static org.junit.Assert.assertEquals;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

import org.junit.Test;

import bg.government.regixclient.app.utils.RegexJsonUtil;

public class RegexJsonUtilTest {

	private static String MINI_JSON_PATH = "static/utils/mini.json";	
	private static Path MINI_JSON_FILE_PATH =  Paths.get(RegexJsonUtilTest.class.getClassLoader().getResource(MINI_JSON_PATH).getFile());
	
	@Test	
	public void test_replaceForIndexes_index_0_read_from_file(){
		String replacement = "\"1999-04-10T10:52:28.944\"";
		String replaced = RegexJsonUtil.replaceForIndexes(MINI_JSON_FILE_PATH, getRegexForJsonProp("requestTime"), 
				replacement, Arrays.asList(0));
		
		String expectedStr =
				"{\n" + 
				"	\"requestTime\": \"1999-04-10T10:52:28.944\",\n" + 
				"	\"requestTime\": \"2020-04-02T10:52:27.987\",\n" + 
				"	\"employeeIdentifier\": null,\n" + 
				"	\"employeeIdentifier\": 1234\n" + 
				"}";		

		assertEquals(expectedStr, replaced);		
	}
	
	@Test	
	public void test_replaceForIndexes_index_1_read_from_file(){
		String replacement = "\"1999-04-10T10:52:28.944\"";
		String replaced = RegexJsonUtil.replaceForIndexes(MINI_JSON_FILE_PATH, getRegexForJsonProp("requestTime"), 
				replacement, Arrays.asList(1));
		
		String expectedStr =
				"{\n" + 
				"	\"requestTime\": \"2020-04-01T10:52:27.987\",\n" + 
				"	\"requestTime\": \"1999-04-10T10:52:28.944\",\n" + 
				"	\"employeeIdentifier\": null,\n" + 
				"	\"employeeIdentifier\": 1234\n" + 
				"}";	

		assertEquals(expectedStr, replaced);
	}
	
	@Test	
	public void test_replace_read_from_file(){
		String replacement = "\"1999-04-10T10:52:28.944\"";
		String replaced = RegexJsonUtil.replace(MINI_JSON_FILE_PATH, getRegexForJsonProp("requestTime"), replacement);
		
		String expectedStr =
				"{\n" + 
				"	\"requestTime\": \"1999-04-10T10:52:28.944\",\n" + 
				"	\"requestTime\": \"1999-04-10T10:52:28.944\",\n"  +
				"	\"employeeIdentifier\": null,\n" + 
				"	\"employeeIdentifier\": 1234\n" + 
				"}";

		assertEquals(expectedStr, replaced);
	}
	
	@Test	
	public void test_replaceForIndexes_index_0(){
		String inputStr = "\"requestTime\": null,\n" + 
				 		  "\"requestTime\": \"2020-04-02T10:52:27.987\"\n";
		String replacement = "\"1999-04-10T10:52:28.944\"";
		String replaced = RegexJsonUtil.replaceForIndexes(inputStr, getRegexForJsonProp("requestTime"), 
				replacement, Arrays.asList(0));
		
		String expectedStr = "\"requestTime\": \"1999-04-10T10:52:28.944\",\n" + 
				             "\"requestTime\": \"2020-04-02T10:52:27.987\"\n";

		assertEquals(expectedStr, replaced);
	}
	
	@Test	
	public void test_replaceForIndexes_index_1(){
		String inputStr = "\"requestTime\": null,\n" + 
				 		  "\"requestTime\": \"2020-04-02T10:52:27.987\"\n";
		String replacement = "\"1999-04-10T10:52:28.944\"";
		String replaced = RegexJsonUtil.replaceForIndexes(inputStr, getRegexForJsonProp("requestTime"), 
				replacement, Arrays.asList(1));
		
		String expectedStr = "\"requestTime\": null,\n" + 
							 "\"requestTime\": \"1999-04-10T10:52:28.944\"\n";

		assertEquals(expectedStr, replaced);
	}
	
	@Test	
	public void test_replaceForIndexes(){
		String inputStr = "\"requestTime\": \"2020-04-02T10:52:27.987\",\n" + 
				 		  "\"requestTime\": null\n";
		String replacement = "\"1999-04-10T10:52:28.944\"";
		String replaced = RegexJsonUtil.replace(inputStr, getRegexForJsonProp("requestTime"), replacement);

		String expectedStr = "\"requestTime\": \"1999-04-10T10:52:28.944\",\n" + 
							 "\"requestTime\": \"1999-04-10T10:52:28.944\"\n";
		assertEquals(expectedStr, replaced);
	}
	
	private static String getRegexForJsonProp(String jsonPropName) {
		StringBuilder builder = new StringBuilder();
		builder.append("\"").append(jsonPropName).append("\":").append("\\s*(.*)(\\n)");
		return builder.toString();
	}
	
	
}
