package bg.government.regixclient.app.utilstest;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.function.Consumer;

import org.junit.Test;

import bg.government.regixclient.app.utils.RegexingSqlScriptBuilder;

public class RegexingSqlScriptBuilderTest {

	private static String MINI_JSON_PATH = "static/utils/mini.json";	
	
	@Test
	public void add_multiple_replacements() {
		
		String expectedStr =
				"{\n" + 
				"	\"requestTime\": \"test-date\",\n" + 
				"	\"requestTime\": \"2020-04-02T10:52:27.987\",\n" + 
				"	\"employeeIdentifier\": 123456789,\n" + 
				"	\"employeeIdentifier\": 123456789\n" + 
				"}";	
		
		new RegexingSqlScriptBuilder()
			.addJsonStringReplacement("requestTime", "test-date", Arrays.asList(0))
			.addJsonReplacement("employeeIdentifier", 123456789)
			.replaceFor(MINI_JSON_PATH)
			.pass(new Consumer<String>() {
				
				@Override
				public void accept(String t) {
					assertEquals(expectedStr, t);
					
				}
			});
	}
}
