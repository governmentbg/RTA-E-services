--
-- PostgreSQL database dump
--

-- Dumped from database version 10.7 (Debian 10.7-1.pgdg90+1)
-- Dumped by pg_dump version 10.12 (Ubuntu 10.12-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;



CREATE ROLE admin;
ALTER ROLE admin WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'md531b76814ede2415c9850d685bac8cdf8';
CREATE ROLE ict_proxy;
ALTER ROLE ict_proxy WITH NOSUPERUSER NOINHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS CONNECTION LIMIT 8 PASSWORD 'md570be30ceb8e7a2554dd8613df6d0e815';
CREATE ROLE ict_proxy_admin;
ALTER ROLE ict_proxy_admin WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS CONNECTION LIMIT 5 PASSWORD 'md558215e1fa0ee2bc2a66aeff9f159598f';
CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;
CREATE ROLE "regix-proxy";
ALTER ROLE "regix-proxy" WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'md5cd75a4ffabce86551d6ded33d7186857';
CREATE ROLE techinsp_info;
ALTER ROLE techinsp_info WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS CONNECTION LIMIT 5 PASSWORD 'md5a6c9100f829abacecd56ebaf802eb3c0';

--
-- Name: ict_proxy; Type: SCHEMA; Schema: -; Owner: admin
--

CREATE SCHEMA ict_proxy;


ALTER SCHEMA ict_proxy OWNER TO admin;

--
-- Name: regix_proxy; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA regix_proxy;


ALTER SCHEMA regix_proxy OWNER TO postgres;

--
-- Name: SCHEMA regix_proxy; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA regix_proxy IS 'standard public schema';


--
-- Name: techinsp_info;f Type: SCHEMA; Schema: -; Owner: admin
--

CREATE SCHEMA techinsp_info;


ALTER SCHEMA techinsp_info OWNER TO admin;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: availability_log; Type: TABLE; Schema: ict_proxy; Owner: admin
--

CREATE TABLE ict_proxy.availability_log (
    "time" timestamp without time zone NOT NULL,
    available boolean
);


ALTER TABLE ict_proxy.availability_log OWNER TO admin;

--
-- Name: clients; Type: TABLE; Schema: regix_proxy; Owner: regix-proxy
--

CREATE TABLE regix_proxy.clients (
    name character varying(32) NOT NULL,
    certificate text NOT NULL,
    id integer NOT NULL
);


ALTER TABLE regix_proxy.clients OWNER TO "regix-proxy";

--
-- Name: clients_if_seq; Type: SEQUENCE; Schema: regix_proxy; Owner: regix-proxy
--

CREATE SEQUENCE regix_proxy.clients_if_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE regix_proxy.clients_if_seq OWNER TO "regix-proxy";

--
-- Name: clients_if_seq; Type: SEQUENCE OWNED BY; Schema: regix_proxy; Owner: regix-proxy
--

ALTER SEQUENCE regix_proxy.clients_if_seq OWNED BY regix_proxy.clients.id;


--
-- Name: clients; Type: TABLE; Schema: ict_proxy; Owner: regix-proxy
--

CREATE TABLE ict_proxy.clients (
    name character varying(32) NOT NULL,
    certificate text NOT NULL,
    id integer DEFAULT nextval('regix_proxy.clients_if_seq'::regclass) NOT NULL
);


ALTER TABLE ict_proxy.clients OWNER TO "regix-proxy";

--
-- Name: logs_vehicle_info; Type: TABLE; Schema: ict_proxy; Owner: admin
--

CREATE TABLE ict_proxy.logs_vehicle_info (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);


ALTER TABLE ict_proxy.logs_vehicle_info OWNER TO admin;


--
-- Name: logs_foreign_identity; Type: TABLE; Schema: regix_proxy; Owner: regix-proxy
--

CREATE TABLE regix_proxy.logs_foreign_identity (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);


ALTER TABLE regix_proxy.logs_foreign_identity OWNER TO "regix-proxy";

--
-- Name: logs_motor_vehicle_registration_v2; Type: TABLE; Schema: regix_proxy; Owner: regix-proxy
--

CREATE TABLE regix_proxy.logs_motor_vehicle_registration_v2 (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);


ALTER TABLE regix_proxy.logs_motor_vehicle_registration_v2 OWNER TO "regix-proxy";

--
-- Name: logs_personal_identity; Type: TABLE; Schema: regix_proxy; Owner: regix-proxy
--

CREATE TABLE regix_proxy.logs_personal_identity (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);


ALTER TABLE regix_proxy.logs_personal_identity OWNER TO "regix-proxy";

-- logs_employment_contracts

CREATE TABLE regix_proxy.logs_employment_contracts (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);

ALTER TABLE regix_proxy.logs_employment_contracts OWNER TO "regix-proxy";

-- logs_uic_validation

CREATE TABLE regix_proxy.logs_uic_validation (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);

ALTER TABLE regix_proxy.logs_uic_validation OWNER TO "regix-proxy";

--
-- Name: logs_av_tr_actual_state_v3; Type: TABLE; Schema: regix-proxy; Owner: regix-proxy
--

CREATE TABLE regix_proxy.logs_av_tr_actual_state_v3 (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);

ALTER TABLE regix_proxy.logs_av_tr_actual_state_v3 OWNER TO "regix-proxy";

--
-- Name: logs_personal_identity_v2; Type: TABLE; Schema: regix-proxy; Owner: regix-proxy
--
CREATE TABLE regix_proxy.logs_personal_identity_v2(
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);

ALTER TABLE regix_proxy.logs_personal_identity_v2 OWNER to "regix-proxy";

--
-- Name: logs_personal_identity_v3; Type: TABLE; Schema: regix-proxy; Owner: regix-proxy
--
CREATE TABLE regix_proxy.logs_personal_identity_v3(
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);

ALTER TABLE regix_proxy.logs_personal_identity_v3 OWNER to "regix-proxy";

--
-- Name: l_inspections_history; Type: TABLE; Schema: techinsp_info; Owner: admin
--

CREATE TABLE techinsp_info.l_inspections_history (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);


ALTER TABLE techinsp_info.l_inspections_history OWNER TO admin;

--
-- Name: TABLE l_inspections_history; Type: COMMENT; Schema: techinsp_info; Owner: admin
--

COMMENT ON TABLE techinsp_info.l_inspections_history IS 'Запазва входните и изходни данни, с които е направена заявката към услугата "Информация относно проведени технически прегледи на ППС"';


--
-- Name: l_inspections_last; Type: TABLE; Schema: techinsp_info; Owner: admin
--

CREATE TABLE techinsp_info.l_inspections_last (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);


ALTER TABLE techinsp_info.l_inspections_last OWNER TO admin;

--
-- Name: TABLE l_inspections_last; Type: COMMENT; Schema: techinsp_info; Owner: admin
--

COMMENT ON TABLE techinsp_info.l_inspections_last IS 'Запазва входните и изходни данни, с които е направена заявката към услугата "Информация относно последния проведен технически преглед ма ППС"';


--
-- Name: l_inspections_last_valid; Type: TABLE; Schema: techinsp_info; Owner: admin
--

CREATE TABLE techinsp_info.l_inspections_last_valid (
    workflow jsonb NOT NULL,
    id SERIAL PRIMARY KEY,
    request_time timestamp without time zone
);


ALTER TABLE techinsp_info.l_inspections_last_valid OWNER TO admin;

--
-- Name: TABLE l_inspections_last_valid; Type: COMMENT; Schema: techinsp_info; Owner: admin
--

COMMENT ON TABLE techinsp_info.l_inspections_last_valid IS 'Запазва входните и изходни данни, с които е направена заявката към услугата "Информация относно наличие на валиден технически преглед на ППС"';


--
-- Name: clients id; Type: DEFAULT; Schema: regix_proxy; Owner: regix-proxy
--

ALTER TABLE ONLY regix_proxy.clients ALTER COLUMN id SET DEFAULT nextval('regix_proxy.clients_if_seq'::regclass);


--
-- Name: availability_log availability_log_pkey; Type: CONSTRAINT; Schema: ict_proxy; Owner: admin
--

ALTER TABLE ONLY ict_proxy.availability_log
    ADD CONSTRAINT availability_log_pkey PRIMARY KEY ("time");


--
-- Name: clients clients_if_key; Type: CONSTRAINT; Schema: ict_proxy; Owner: regix-proxy
--

ALTER TABLE ONLY ict_proxy.clients
    ADD CONSTRAINT clients_if_key UNIQUE (id);


--
-- Name: clients clients_string_pkey; Type: CONSTRAINT; Schema: ict_proxy; Owner: regix-proxy
--

ALTER TABLE ONLY ict_proxy.clients
    ADD CONSTRAINT clients_string_pkey PRIMARY KEY (certificate);


--
-- Name: clients clients_if_key; Type: CONSTRAINT; Schema: regix_proxy; Owner: regix-proxy
--

ALTER TABLE ONLY regix_proxy.clients
    ADD CONSTRAINT clients_if_key UNIQUE (id);


--
-- Name: clients clients_string_pkey; Type: CONSTRAINT; Schema: regix_proxy; Owner: regix-proxy
--

ALTER TABLE ONLY regix_proxy.clients
    ADD CONSTRAINT clients_string_pkey PRIMARY KEY (certificate);


--
-- Name: idx_btree_regnum_ownerid_time; Type: INDEX; Schema: ict_proxy; Owner: admin
--

CREATE INDEX idx_btree_regnum_ownerid_time ON ict_proxy.logs_vehicle_info USING btree ((((((workflow -> 'request'::text) -> 'request'::text) -> 'vehicleRequestData'::text) ->> 'vehRegistrationNumber'::text)));


--
-- Name: idx_btree_regnum_ownerid_time_test2; Type: INDEX; Schema: ict_proxy; Owner: admin
--

CREATE INDEX idx_btree_regnum_ownerid_time_test2 ON ict_proxy.logs_vehicle_info USING btree ((((((workflow -> 'request'::text) -> 'request'::text) -> 'vehicleRequestData'::text) ->> 'vehRegistrationNumber'::text)), (((((workflow -> 'request'::text) -> 'request'::text) -> 'vehicleOwnerData'::text) ->> 'vehOwnerId'::text)), ((workflow -> 'requestTime'::text)));


--
-- Name: idx_btree_regnum_ownerid_time_test3; Type: INDEX; Schema: ict_proxy; Owner: admin
--

CREATE INDEX idx_btree_regnum_ownerid_time_test3 ON ict_proxy.logs_vehicle_info USING btree ((((((workflow -> 'request'::text) -> 'request'::text) -> 'vehicleRequestData'::text) ->> 'vehRegistrationNumber'::text)), (((((workflow -> 'request'::text) -> 'request'::text) -> 'vehicleOwnerData'::text) ->> 'vehOwnerId'::text)));


--
-- Name: logs_foreign_identity_expr_expr1_idx; Type: INDEX; Schema: regix_proxy; Owner: regix-proxy
--

CREATE INDEX logs_foreign_identity_expr_expr1_idx ON regix_proxy.logs_foreign_identity USING btree ((((workflow -> 'request'::text) ->> 'identifier'::text)), (((workflow -> 'request'::text) ->> 'identifierType'::text)));


--
-- Name: logs_personal_identity_expr_expr1_idx; Type: INDEX; Schema: regix_proxy; Owner: regix-proxy
--

CREATE INDEX logs_personal_identity_expr_expr1_idx ON regix_proxy.logs_personal_identity USING btree ((((workflow -> 'request'::text) ->> 'egn'::text)), (((workflow -> 'request'::text) ->> 'identityDocumentNumber'::text)));


--
-- Name: SCHEMA ict_proxy; Type: ACL; Schema: -; Owner: admin
--

GRANT USAGE ON SCHEMA ict_proxy TO ict_proxy;
GRANT USAGE ON SCHEMA ict_proxy TO ict_proxy_admin;


--
-- Name: SCHEMA regix_proxy; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA regix_proxy TO "regix-proxy";


--
-- Name: SCHEMA techinsp_info; Type: ACL; Schema: -; Owner: admin
--

GRANT ALL ON SCHEMA techinsp_info TO techinsp_info;


--
-- Name: TABLE availability_log; Type: ACL; Schema: ict_proxy; Owner: admin
--

GRANT SELECT,INSERT ON TABLE ict_proxy.availability_log TO ict_proxy;
GRANT SELECT ON TABLE ict_proxy.availability_log TO ict_proxy_admin;


--
-- Name: TABLE clients; Type: ACL; Schema: ict_proxy; Owner: regix-proxy
--

GRANT SELECT ON TABLE ict_proxy.clients TO ict_proxy;
GRANT SELECT ON TABLE ict_proxy.clients TO ict_proxy_admin;


--
-- Name: TABLE logs_vehicle_info; Type: ACL; Schema: ict_proxy; Owner: admin
--

GRANT SELECT,INSERT,UPDATE ON TABLE ict_proxy.logs_vehicle_info TO ict_proxy;
GRANT SELECT ON TABLE ict_proxy.logs_vehicle_info TO ict_proxy_admin;


--
-- Name: TABLE l_inspections_history; Type: ACL; Schema: techinsp_info; Owner: admin
--

GRANT SELECT,INSERT,UPDATE ON TABLE techinsp_info.l_inspections_history TO techinsp_info;


--
-- Name: TABLE l_inspections_last; Type: ACL; Schema: techinsp_info; Owner: admin
--

GRANT SELECT,INSERT,UPDATE ON TABLE techinsp_info.l_inspections_last TO techinsp_info;


--
-- Name: TABLE l_inspections_last_valid; Type: ACL; Schema: techinsp_info; Owner: admin
--

GRANT SELECT,INSERT,UPDATE ON TABLE techinsp_info.l_inspections_last_valid TO techinsp_info;


--
-- PostgreSQL database dump complete
--

