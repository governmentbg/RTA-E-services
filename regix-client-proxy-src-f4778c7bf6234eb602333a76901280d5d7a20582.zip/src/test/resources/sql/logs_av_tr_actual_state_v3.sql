INSERT INTO regix_proxy.logs_av_tr_actual_state_v3(
	workflow)
	VALUES ('
{
    "error": null,
    "request": [
        "bg.government.regixclient.requests.av.tr.actualstatev3.ActualStateRequestV3",
        {
            "uic": "test",
            "fieldList": "001, 00020"
        }
    ],
    "response": [
        "bg.government.regixclient.requests.av.tr.actualstatev3.ActualStateResponseV3",
        {
            "deed": {
                "uic": "uic from cache",
                "guid": "94CE5DE4A60D44B995380BC7AA273925",
                "caseNo": "4821",
                "courtNo": "110",
                "caseYear": "2005",
                "subdeeds": {
                    "subdeed": [
                        "java.util.ArrayList",
                        [
                            {
                                "subUIC": "0011",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        [
                                            {
                                                "recordId": 10187415,
                                                "mainField": {
                                                    "groupId": 45,
                                                    "groupName": "Идентификация",
                                                    "sectionId": 414,
                                                    "sectionName": "Обща информация",
                                                    "mainFieldCode": "1",
                                                    "mainFieldName": "ЕИК/ПИК",
                                                    "mainFieldIdent": "00010"
                                                },
                                                "fieldIdent": "00010",
                                                "incomingId": 3182331,
                                                "recordData": "",
                                                "fieldActionDate": [
                                                    "javax.xml.datatype.XMLGregorianCalendar",
                                                    1253106877000
                                                ],
                                                "fieldEntryNumber": "20090916161437"
                                            },
                                            {
                                                "recordId": 18495284,
                                                "mainField": {
                                                    "groupId": 415,
                                                    "groupName": "Основни обстоятелства",
                                                    "sectionId": 1,
                                                    "sectionName": "Общ статус",
                                                    "mainFieldCode": "10",
                                                    "mainFieldName": "Представители",
                                                    "mainFieldIdent": "00100"
                                                },
                                                "fieldIdent": "001000",
                                                "incomingId": 5524238,
                                                "recordData": "",
                                                "fieldActionDate": [
                                                    "javax.xml.datatype.XMLGregorianCalendar",
                                                    1291116648000
                                                ],
                                                "fieldEntryNumber": "20101130133048"
                                            },
                                            {
                                                "recordId": 10187431,
                                                "mainField": {
                                                    "groupId": 415,
                                                    "groupName": "Основни обстоятелства",
                                                    "sectionId": 1,
                                                    "sectionName": "Общ статус",
                                                    "mainFieldCode": "13",
                                                    "mainFieldName": "Управителен съвет",
                                                    "mainFieldIdent": "00132"
                                                },
                                                "fieldIdent": "001320",
                                                "incomingId": 21982166,
                                                "recordData": "",
                                                "fieldActionDate": [
                                                    "javax.xml.datatype.XMLGregorianCalendar",
                                                    1478617996000
                                                ],
                                                "fieldEntryNumber": "20161108171316"
                                            },
                                            {
                                                "recordId": 11242290,
                                                "mainField": {
                                                    "groupId": 415,
                                                    "groupName": "Основни обстоятелства",
                                                    "sectionId": 1,
                                                    "sectionName": "Общ статус",
                                                    "mainFieldCode": "13",
                                                    "mainFieldName": "Управителен съвет",
                                                    "mainFieldIdent": "00132"
                                                },
                                                "fieldIdent": "001321",
                                                "incomingId": 3518760,
                                                "recordData": "",
                                                "fieldActionDate": [
                                                    "javax.xml.datatype.XMLGregorianCalendar",
                                                    1478617996000
                                                ],
                                                "fieldEntryNumber": "20161108171316"
                                            },
                                            {
                                                "recordId": 18495338,
                                                "mainField": {
                                                    "groupId": 415,
                                                    "groupName": "Основни обстоятелства",
                                                    "sectionId": 1,
                                                    "sectionName": "Общ статус",
                                                    "mainFieldCode": "13",
                                                    "mainFieldName": "Управителен съвет",
                                                    "mainFieldIdent": "00132"
                                                },
                                                "fieldIdent": "001321",
                                                "incomingId": 5524238,
                                                "recordData": "",
                                                "fieldActionDate": [
                                                    "javax.xml.datatype.XMLGregorianCalendar",
                                                    1478617996000
                                                ],
                                                "fieldEntryNumber": "20161108171316"
                                            },
                                            {
                                                "recordId": 21914720,
                                                "mainField": {
                                                    "groupId": 415,
                                                    "groupName": "Основни обстоятелства",
                                                    "sectionId": 1,
                                                    "sectionName": "Общ статус",
                                                    "mainFieldCode": "13",
                                                    "mainFieldName": "Управителен съвет",
                                                    "mainFieldIdent": "00132"
                                                },
                                                "fieldIdent": "001321",
                                                "incomingId": 6674302,
                                                "recordData": "",
                                                "fieldActionDate": [
                                                    "javax.xml.datatype.XMLGregorianCalendar",
                                                    1478617996000
                                                ],
                                                "fieldEntryNumber": "20161108171316"
                                            },
                                            {
                                                "recordId": 10187435,
                                                "mainField": {
                                                    "groupId": 415,
                                                    "groupName": "Основни обстоятелства",
                                                    "sectionId": 1,
                                                    "sectionName": "Общ статус",
                                                    "mainFieldCode": "14",
                                                    "mainFieldName": "Надзорен съвет",
                                                    "mainFieldIdent": "00140"
                                                },
                                                "fieldIdent": "001400",
                                                "incomingId": 20415943,
                                                "recordData": "",
                                                "fieldActionDate": [
                                                    "javax.xml.datatype.XMLGregorianCalendar",
                                                    1461070819000
                                                ],
                                                "fieldEntryNumber": "20160419160019"
                                            },
                                            {
                                                "recordId": 10238410,
                                                "mainField": {
                                                    "groupId": 415,
                                                    "groupName": "Основни обстоятелства",
                                                    "sectionId": 1,
                                                    "sectionName": "Общ статус",
                                                    "mainFieldCode": "14",
                                                    "mainFieldName": "Надзорен съвет",
                                                    "mainFieldIdent": "00140"
                                                },
                                                "fieldIdent": "001401",
                                                "incomingId": 3198092,
                                                "recordData": "",
                                                "fieldActionDate": [
                                                    "javax.xml.datatype.XMLGregorianCalendar",
                                                    1461070819000
                                                ],
                                                "fieldEntryNumber": "20160419160019"
                                            },
                                            {
                                                "recordId": 20112503,
                                                "mainField": {
                                                    "groupId": 415,
                                                    "groupName": "Основни обстоятелства",
                                                    "sectionId": 1,
                                                    "sectionName": "Общ статус",
                                                    "mainFieldCode": "14",
                                                    "mainFieldName": "Надзорен съвет",
                                                    "mainFieldIdent": "00140"
                                                },
                                                "fieldIdent": "001401",
                                                "incomingId": 5935947,
                                                "recordData": "",
                                                "fieldActionDate": [
                                                    "javax.xml.datatype.XMLGregorianCalendar",
                                                    1461070819000
                                                ],
                                                "fieldEntryNumber": "20160419160019"
                                            },
                                            {
                                                "recordId": 48854373,
                                                "mainField": {
                                                    "groupId": 415,
                                                    "groupName": "Основни обстоятелства",
                                                    "sectionId": 1,
                                                    "sectionName": "Общ статус",
                                                    "mainFieldCode": "14",
                                                    "mainFieldName": "Надзорен съвет",
                                                    "mainFieldIdent": "00140"
                                                },
                                                "fieldIdent": "001401",
                                                "incomingId": 19509282,
                                                "recordData": "",
                                                "fieldActionDate": [
                                                    "javax.xml.datatype.XMLGregorianCalendar",
                                                    1461070819000
                                                ],
                                                "fieldEntryNumber": "20160419160019"
                                            },
                                            {
                                                "recordId": 10187416,
                                                "mainField": {
                                                    "groupId": 415,
                                                    "groupName": "Основни обстоятелства",
                                                    "sectionId": 1,
                                                    "sectionName": "Общ статус",
                                                    "mainFieldCode": "2",
                                                    "mainFieldName": "Фирма",
                                                    "mainFieldIdent": "00020"
                                                },
                                                "fieldIdent": "00020",
                                                "incomingId": 3182331,
                                                "recordData": "",
                                                "fieldActionDate": [
                                                    "javax.xml.datatype.XMLGregorianCalendar",
                                                    1253106877000
                                                ],
                                                "fieldEntryNumber": "20090916161437"
                                            }
                                        ]
                                    ]
                                },
                                "subUICName": null,
                                "subUICType": "1",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0064",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН БЛАГОЕВГРАД",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0045",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН СТАРА ЗАГОРА",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0030",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН ПЛЕВЕН",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0011",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН БУРГАС",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0026",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН ВАРНА",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0055",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН ПЛОВДИВ",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0079",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "Велико Търново",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0083",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН ДОБРИЧ",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0098",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН РАЗГРАД",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0108",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН ХАСКОВО",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0114",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН ГАБРОВО",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0129",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "Кърджали",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0133",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "Силистра",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0148",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "Шумен",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0152",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН ЯМБОЛ",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0167",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД-КЛОН ТЪРГОВИЩЕ",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0171",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "Русе",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0186",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "Монтана",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0190",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН ВИДИН",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0202",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН ВРАЦА",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0217",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН КЮСТЕНДИЛ",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0221",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН ЛОВЕЧ",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0236",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН ПАЗАРДЖИК",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0240",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН ПЕРНИК",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0255",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН СЛИВЕН",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            },
                            {
                                "subUIC": "0260",
                                "records": {
                                    "record": [
                                        "java.util.ArrayList",
                                        []
                                    ]
                                },
                                "subUICName": "ДСК ЛИЗИНГ АД - КЛОН СМОЛЯН",
                                "subUICType": "3",
                                "subdeedStatus": "A"
                            }
                        ]
                    ]
                },
                "legalForm": "АД",
                "deedStatus": "N",
                "companyName": "ДСК ЛИЗИНГ АД",
                "liquidationOrInsolvency": "INSOLVENCY_SEC_INS"
            },
            "dataFound": true,
            "dataValidForDate": [
                "javax.xml.datatype.XMLGregorianCalendar",
                1588148513685
            ]
        }
    ],
    "clientName": "TechinspClient",
    "callContext": {
        "remark": null,
        "lawReason": "чл. 29, ал. 3 от Наредба № 38 от 16.04.2004 г.",
        "serviceURI": "1916",
        "serviceType": "Провеждане на изпити за придобиване на правоспособност за управление на МПС",
        "employeeNames": {
            "name": "{http://tempuri.org/}EmployeeNames",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Информационна система, обслужваща дейността по обучението и изпитите за придобиване на правоспособност за управление на моторно превозно средство и проверочните изпити, по чл. 27, ал. 7 от Наредба № 37 от 2.08.2002 г. за условията и реда за обучение на кандидатите за придобиване на правоспособност за управление на моторно превозно средство и условията и реда за издаване на разрешение за тяхното обучение",
            "declaredType": "java.lang.String"
        },
        "employeePosition": {
            "name": "{http://tempuri.org/}EmployeePosition",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Position",
            "declaredType": "java.lang.String"
        },
        "administrationOId": {
            "name": "{http://tempuri.org/}administrationOId",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "2.16.100.1.1.9",
            "declaredType": "java.lang.String"
        },
        "administrationName": {
            "name": "{http://tempuri.org/}AdministrationName",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Изпълнителна агенция “Автомобилна администрация”",
            "declaredType": "java.lang.String"
        },
        "employeeIdentifier": {
            "name": "{http://tempuri.org/}EmployeeIdentifier",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "SYSTEM",
            "declaredType": "java.lang.String"
        },
        "employeeAditionalIdentifier": null,
        "responsiblePersonIdentifier": null
    },
    "requestTime": "2020-04-29T11:21:53.136",
    "responseTime": "2020-04-29T11:21:58.036"
}
');

UPDATE regix_proxy.logs_av_tr_actual_state_v3 
SET request_time = (workflow ->>'requestTime')::timestamp;