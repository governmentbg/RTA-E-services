INSERT INTO regix_proxy.logs_employment_contracts(
	workflow)
	VALUES ('
{
    "error": null,
    "request": [
        "bg.government.regixclient.requests.nra.employmentcontracts.EmploymentContractsRequest",
        {
            "identity": {
                "id": "test1",
                "type": "EGN"
            },
            "contractsFilter": "ALL"
        }
    ],
    "response": [
        "bg.government.regixclient.requests.nra.employmentcontracts.EmploymentContractsResponse",
        {
            "status": {
                "code": 0,
                "message": "Message"
            },
            "identity": {
                "id": "1234123411 от cache",
                "type": "BULSTAT"
            },
            "econtracts": {
                "econtract": [
                    "java.util.ArrayList",
                    [
                        {
                            "reason": "01",
                            "ecoCode": "String",
                            "endDate": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75434400000
                            ],
                            "startDate": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75607200000
                            ],
                            "timeLimit": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75348000000
                            ],
                            "ekattecode": "token",
                            "remuneration": 800,
                            "individualEIK": "020202",
                            "lastAmendDate": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75520800000
                            ],
                            "contractorName": "Example Contractor Name",
                            "professionCode": "01",
                            "professionName": "IT Support",
                            "individualNames": "Example Individual Name",
                            "contractorBulstat": "123123123"
                        },
                        {
                            "reason": "01",
                            "ecoCode": "EcoCode",
                            "endDate": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75088800000
                            ],
                            "startDate": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75261600000
                            ],
                            "timeLimit": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75002400000
                            ],
                            "ekattecode": "09093",
                            "remuneration": 1050,
                            "individualEIK": "010101",
                            "lastAmendDate": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75175200000
                            ],
                            "contractorName": "Example Contractor Name",
                            "professionCode": "ProfessionCod",
                            "professionName": "Position",
                            "individualNames": "Example Individual Name 2",
                            "contractorBulstat": "123123888"
                        }
                    ]
                ]
            },
            "reportDate": [
                "javax.xml.datatype.XMLGregorianCalendar",
                -76384800000
            ],
            "contractsFilter": "ALL"
        }
    ],
    "clientName": "TechinspClient",
    "callContext": {
        "remark": null,
        "lawReason": "Съгласно чл. 36, ал. 1, т. 3 от Наредба № 38 от 16.04.2004 г. се проверява самоличността на кандидатите, включени в протокола за изпит.",
        "serviceURI": null,
        "serviceType": "За проверовъчна дейност",
        "employeeNames": {
            "name": "{http://tempuri.org/}EmployeeNames",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeePosition": {
            "name": "{http://tempuri.org/}EmployeePosition",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "administrationOId": {
            "name": "{http://tempuri.org/}administrationOId",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "2.16.100.1.1.9",
            "declaredType": "java.lang.String"
        },
        "administrationName": {
            "name": "{http://tempuri.org/}AdministrationName",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Изпълнителна агенция “Автомобилна администрация”",
            "declaredType": "java.lang.String"
        },
        "employeeIdentifier": {
            "name": "{http://tempuri.org/}EmployeeIdentifier",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeeAditionalIdentifier": null,
        "responsiblePersonIdentifier": null
    },
    "requestTime": "2020-04-01T10:52:27.987",
    "responseTime": "2020-04-10T10:52:28.944"
}');

INSERT INTO regix_proxy.logs_employment_contracts(
	workflow)
	VALUES ('
{
    "error": null,
    "request": [
        "bg.government.regixclient.requests.nra.employmentcontracts.EmploymentContractsRequest",
        {
            "identity": {
                "id": "test2",
                "type": "EGN"
            },
            "contractsFilter": "ALL"
        }
    ],
    "response": [
        "bg.government.regixclient.requests.nra.employmentcontracts.EmploymentContractsResponse",
        {
            "status": {
                "code": 0,
                "message": "Message"
            },
            "identity": {
                "id": "1234123411",
                "type": "BULSTAT"
            },
            "econtracts": {
                "econtract": [
                    "java.util.ArrayList",
                    [
                        {
                            "reason": "01",
                            "ecoCode": "String",
                            "endDate": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75434400000
                            ],
                            "startDate": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75607200000
                            ],
                            "timeLimit": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75348000000
                            ],
                            "ekattecode": "token",
                            "remuneration": 800,
                            "individualEIK": "020202",
                            "lastAmendDate": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75520800000
                            ],
                            "contractorName": "Example Contractor Name",
                            "professionCode": "01",
                            "professionName": "IT Support",
                            "individualNames": "Example Individual Name",
                            "contractorBulstat": "123123123"
                        },
                        {
                            "reason": "01",
                            "ecoCode": "EcoCode",
                            "endDate": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75088800000
                            ],
                            "startDate": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75261600000
                            ],
                            "timeLimit": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75002400000
                            ],
                            "ekattecode": "09093",
                            "remuneration": 1050,
                            "individualEIK": "010101",
                            "lastAmendDate": [
                                "javax.xml.datatype.XMLGregorianCalendar",
                                -75175200000
                            ],
                            "contractorName": "Example Contractor Name",
                            "professionCode": "ProfessionCod",
                            "professionName": "Position",
                            "individualNames": "Example Individual Name 2",
                            "contractorBulstat": "123123888"
                        }
                    ]
                ]
            },
            "reportDate": [
                "javax.xml.datatype.XMLGregorianCalendar",
                -76384800000
            ],
            "contractsFilter": "ALL"
        }
    ],
    "clientName": "TechinspClient",
    "callContext": {
        "remark": null,
        "lawReason": "Съгласно чл. 36, ал. 1, т. 3 от Наредба № 38 от 16.04.2004 г. се проверява самоличността на кандидатите, включени в протокола за изпит.",
        "serviceURI": null,
        "serviceType": "За проверовъчна дейност",
        "employeeNames": {
            "name": "{http://tempuri.org/}EmployeeNames",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeePosition": {
            "name": "{http://tempuri.org/}EmployeePosition",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "administrationOId": {
            "name": "{http://tempuri.org/}administrationOId",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "2.16.100.1.1.9",
            "declaredType": "java.lang.String"
        },
        "administrationName": {
            "name": "{http://tempuri.org/}AdministrationName",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Изпълнителна агенция “Автомобилна администрация”",
            "declaredType": "java.lang.String"
        },
        "employeeIdentifier": {
            "name": "{http://tempuri.org/}EmployeeIdentifier",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeeAditionalIdentifier": null,
        "responsiblePersonIdentifier": null
    },
    "requestTime": "2020-04-01T10:52:27.987",
    "responseTime": "2020-04-10T10:52:28.944"
}');

UPDATE regix_proxy.logs_employment_contracts 
SET request_time = (workflow ->>'requestTime')::timestamp;