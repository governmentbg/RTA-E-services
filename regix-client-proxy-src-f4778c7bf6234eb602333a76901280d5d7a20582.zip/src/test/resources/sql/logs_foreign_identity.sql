INSERT INTO regix_proxy.logs_foreign_identity(
	workflow)
	VALUES ('
{
    "error": null,
    "request": [
        "bg.government.regixclient.requests.mvr.erch.ForeignIdentityInfoRequestType",
        {
            "identifier": "test1",
            "identifierType": "LN_CH"
        }
    ],
    "response": [
        "bg.government.regixclient.requests.mvr.erch.ForeignIdentityInfoResponseType",
        {
            "egn": "3911184417",
            "lnch": "1000006058",
            "height": 160,
            "picture": "iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABc",
            "statuses": {
                "status": [
                    "java.util.ArrayList",
                    [
                        {
                            "dateTo": null,
                            "dateFrom": null,
                            "statusName": null,
                            "statusNameLatin": null
                        }
                    ]
                ]
            },
            "birthDate": "1939-11-18",
            "eyesColor": null,
            "birthPlace": {
                "countryCode": "GRC",
                "countryName": null,
                "districtName": null,
                "countryNameLatin": null,
                "municipalityName": null,
                "territorialUnitName": ""
            },
            "genderName": null,
            "personNames": {
                "surname": null,
                "firstName": "ПАПАНИКОЛАУ от cache",
                "familyName": "АЛЕКСАНДРА ХАРАЛАМПИЕВА",
                "surnameLatin": null,
                "lastNameLatin": "ALEKSANDRA HARALAMPIEVA",
                "firstNameLatin": "PAPANIKOLAU DADADADADADADADAD"
            },
            "eyesColorLatin": null,
            "travelDocument": {
                "issueDate": [
                    "javax.xml.datatype.XMLGregorianCalendar",
                    977954400000
                ],
                "validDate": [
                    "javax.xml.datatype.XMLGregorianCalendar",
                    1104530400000
                ],
                "issuePlace": null,
                "issuerName": null,
                "documentType": null,
                "issuePlaceLatin": null,
                "issuerNameLatin": null,
                "documentTypeLatin": null,
                "travelDocumentNumber": "500204070",
                "travelDocumentSeries": ""
            },
            "genderNameLatin": null,
            "nationalityList": {
                "nationality": [
                    "java.util.ArrayList",
                    [
                        {
                            "nationalityCode": "RUS",
                            "nationalityName": null,
                            "nationalityNameLatin": null
                        },
                        {
                            "nationalityCode": "TUR",
                            "nationalityName": null,
                            "nationalityNameLatin": null
                        }
                    ]
                ]
            },
            "identityDocument": {
                "issueDate": [
                    "javax.xml.datatype.XMLGregorianCalendar",
                    978991200000
                ],
                "validDate": [
                    "javax.xml.datatype.XMLGregorianCalendar",
                    1104530400000
                ],
                "issuePlace": null,
                "issuerName": null,
                "documentType": null,
                "issuePlaceLatin": null,
                "issuerNameLatin": null,
                "documentTypeLatin": null,
                "identityDocumentNumber": null
            },
            "permanentAddress": {
                "floor": "",
                "entrance": "4",
                "apartment": "98",
                "districtName": null,
                "locationCode": "2292",
                "locationName": null,
                "buildingNumber": "129",
                "settlementCode": "10135",
                "settlementName": null,
                "municipalityName": null,
                "districtNameLatin": null,
                "locationNameLatin": null,
                "settlementNameLatin": null,
                "municipalityNameLatin": null
            },
            "temporaryAddress": {
                "floor": null,
                "entrance": "3",
                "apartment": null,
                "districtName": null,
                "locationCode": "86074",
                "locationName": null,
                "buildingNumber": "214",
                "settlementCode": "68134",
                "settlementName": null,
                "municipalityName": null,
                "districtNameLatin": null,
                "locationNameLatin": null,
                "settlementNameLatin": null,
                "municipalityNameLatin": null
            },
            "identitySignature": "iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABc",
            "returnInformations": {
                "info": "Успешна операция",
                "returnCode": "0000"
            },
            "permanentAddressAbroad": {
                "street": "АДАМС СТ. 4",
                "settlementName": "ПЪРТ",
                "nationalityCode": "AUS",
                "nationalityName": null,
                "nationalityNameLatin": null
            }
        }
    ],
    "clientName": "TechinspClient",
    "callContext": {
        "remark": null,
        "lawReason": "Съгласно чл. 36, ал. 1, т. 3 от Наредба № 38 от 16.04.2004 г. се проверява самоличността на кандидатите, включени в протокола за изпит.",
        "serviceURI": null,
        "serviceType": "За проверовъчна дейност",
        "employeeNames": {
            "name": "{http://tempuri.org/}EmployeeNames",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeePosition": {
            "name": "{http://tempuri.org/}EmployeePosition",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "administrationOId": {
            "name": "{http://tempuri.org/}administrationOId",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "2.16.100.1.1.9",
            "declaredType": "java.lang.String"
        },
        "administrationName": {
            "name": "{http://tempuri.org/}AdministrationName",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Изпълнителна агенция “Автомобилна администрация”",
            "declaredType": "java.lang.String"
        },
        "employeeIdentifier": {
            "name": "{http://tempuri.org/}EmployeeIdentifier",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeeAditionalIdentifier": null,
        "responsiblePersonIdentifier": null
    },
    "requestTime": "2020-04-06T16:01:54.855",
    "responseTime": "2020-04-06T16:01:55.878"
}');

INSERT INTO regix_proxy.logs_foreign_identity(
	workflow)
	VALUES ('
{
    "error": "RuntimeException occured - Exception mesage:Invalid XML content in Request.Argument against an XSD Schema. Check for correct XSD schema here: http://regixaisweb.egov.bg/regixinfo/\r\nParameter name: Argument",
    "request": [
        "bg.government.regixclient.requests.mvr.erch.ForeignIdentityInfoRequestType",
        {
            "identifier": "test2",
            "identifierType": "LN_CH"
        }
    ],
    "response": null,
    "clientName": "TechinspClient",
    "callContext": {
        "remark": null,
        "lawReason": "Съгласно чл. 36, ал. 1, т. 3 от Наредба № 38 от 16.04.2004 г. се проверява самоличността на кандидатите, включени в протокола за изпит.",
        "serviceURI": null,
        "serviceType": "За проверовъчна дейност",
        "employeeNames": {
            "name": "{http://tempuri.org/}EmployeeNames",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeePosition": {
            "name": "{http://tempuri.org/}EmployeePosition",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "administrationOId": {
            "name": "{http://tempuri.org/}administrationOId",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "2.16.100.1.1.9",
            "declaredType": "java.lang.String"
        },
        "administrationName": {
            "name": "{http://tempuri.org/}AdministrationName",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Изпълнителна агенция “Автомобилна администрация”",
            "declaredType": "java.lang.String"
        },
        "employeeIdentifier": {
            "name": "{http://tempuri.org/}EmployeeIdentifier",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeeAditionalIdentifier": null,
        "responsiblePersonIdentifier": null
    },
    "requestTime": "2020-04-06T16:05:48.148",
    "responseTime": "2020-04-06T16:05:49.212"
}');

UPDATE regix_proxy.logs_foreign_identity 
SET request_time = (workflow ->>'requestTime')::timestamp;