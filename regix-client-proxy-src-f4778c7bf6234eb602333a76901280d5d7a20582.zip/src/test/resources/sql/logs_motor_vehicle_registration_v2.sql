INSERT INTO regix_proxy.logs_motor_vehicle_registration_v2(workflow)
	VALUES ('
{
    "error": null,
    "request": [
        "bg.government.regixclient.requests.mvr.mpsv2.MotorVehicleRegistrationRequestTypeV2",
        {
            "identifier": "test1"
        }
    ],
    "response": [
        "bg.government.regixclient.requests.mvr.mpsv2.GetMotorVehicleRegistrationInfoV2ResponseType",
        {
            "header": {
                "dateTime": [
                    "javax.xml.datatype.XMLGregorianCalendar",
                    -62135604000000
                ],
                "userName": null,
                "messageID": null,
                "operation": null,
                "callContext": null,
                "messageRefID": null,
                "callerIPAddress": null,
                "organizationUnit": null
            },
            "response": {
                "results": {
                    "result": [
                        "java.util.ArrayList",
                        [
                            {
                                "usersData": [
                                    "java.util.ArrayList",
                                    []
                                ],
                                "ownersData": {
                                    "owner": [
                                        "java.util.ArrayList",
                                        [
                                            {
                                                "company": {
                                                    "id": null,
                                                    "name": null,
                                                    "nameLatin": null
                                                },
                                                "foreignCitizen": {
                                                    "pn": null,
                                                    "pin": null,
                                                    "namesLatin": null,
                                                    "nationality": null,
                                                    "namesCyrillic": null
                                                },
                                                "bulgarianCitizen": {
                                                    "pin": "5804037095",
                                                    "names": {
                                                        "first": "ТОНКА",
                                                        "family": "АТАНАСОВА",
                                                        "surname": "ДИМИТРОВА"
                                                    }
                                                }
                                            }
                                        ]
                                    ]
                                },
                                "vehicleData": {
                                    "vin": "WDB61141710924991",
                                    "fuel": null,
                                    "color": null,
                                    "massG": 2180,
                                    "model": null,
                                    "massF1": 4600,
                                    "capacity": null,
                                    "category": "N2 от cache",
                                    "maxPower": null,
                                    "vehicleType": "ТОВАРЕН АВТОМОБИЛ",
                                    "approvalType": null,
                                    "engineNumber": null,
                                    "offRoadSymbols": null,
                                    "vehicleDocument": {
                                        "vehDocumentDate": null,
                                        "vehDocumentNumber": null
                                    },
                                    "tradeDescription": null,
                                    "registrationNumber": "В1437РМ",
                                    "typeApprovalNumber": null,
                                    "environmentalCategory": null,
                                    "firstRegistrationDate": [
                                        "javax.xml.datatype.XMLGregorianCalendar",
                                        573343200000
                                    ]
                                }
                            }
                        ]
                    ]
                },
                "returnInformation": {
                    "info": "OK",
                    "returnCode": "0"
                }
            }
        }
    ],
    "clientName": "TechinspClient",
    "callContext": {
        "remark": null,
        "lawReason": "Съгласно чл. 36, ал. 1, т. 3 от Наредба № 38 от 16.04.2004 г. се проверява самоличността на кандидатите, включени в протокола за изпит.",
        "serviceURI": null,
        "serviceType": "За проверовъчна дейност",
        "employeeNames": {
            "name": "{http://tempuri.org/}EmployeeNames",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeePosition": {
            "name": "{http://tempuri.org/}EmployeePosition",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "administrationOId": {
            "name": "{http://tempuri.org/}administrationOId",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "2.16.100.1.1.9",
            "declaredType": "java.lang.String"
        },
        "administrationName": {
            "name": "{http://tempuri.org/}AdministrationName",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Изпълнителна агенция “Автомобилна администрация”",
            "declaredType": "java.lang.String"
        },
        "employeeIdentifier": {
            "name": "{http://tempuri.org/}EmployeeIdentifier",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeeAditionalIdentifier": null,
        "responsiblePersonIdentifier": null
    },
    "requestTime": "2020-04-06T16:10:30.692",
    "responseTime": "2020-04-06T16:10:31.715"
}');

INSERT INTO regix_proxy.logs_motor_vehicle_registration_v2(workflow)
	VALUES ('
{
    "error": "RuntimeException occured - Exception mesage:Invalid XML content in Request.Argument against an XSD Schema. Check for correct XSD schema here: http://regixaisweb.egov.bg/regixinfo/\r\nParameter name: Argument",
    "request": [
        "bg.government.regixclient.requests.mvr.mpsv2.MotorVehicleRegistrationRequestTypeV2",
        {
            "identifier": "test2"
        }
    ],
    "response": null,
    "clientName": "TechinspClient",
    "callContext": {
        "remark": null,
        "lawReason": "Съгласно чл. 36, ал. 1, т. 3 от Наредба № 38 от 16.04.2004 г. се проверява самоличността на кандидатите, включени в протокола за изпит.",
        "serviceURI": null,
        "serviceType": "За проверовъчна дейност",
        "employeeNames": {
            "name": "{http://tempuri.org/}EmployeeNames",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeePosition": {
            "name": "{http://tempuri.org/}EmployeePosition",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "administrationOId": {
            "name": "{http://tempuri.org/}administrationOId",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "2.16.100.1.1.9",
            "declaredType": "java.lang.String"
        },
        "administrationName": {
            "name": "{http://tempuri.org/}AdministrationName",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Изпълнителна агенция “Автомобилна администрация”",
            "declaredType": "java.lang.String"
        },
        "employeeIdentifier": {
            "name": "{http://tempuri.org/}EmployeeIdentifier",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeeAditionalIdentifier": null,
        "responsiblePersonIdentifier": null
    },
    "requestTime": "2020-04-06T16:13:39.126",
    "responseTime": "2020-04-06T16:13:48.939"
}');

UPDATE regix_proxy.logs_motor_vehicle_registration_v2 
SET request_time = (workflow ->>'requestTime')::timestamp;