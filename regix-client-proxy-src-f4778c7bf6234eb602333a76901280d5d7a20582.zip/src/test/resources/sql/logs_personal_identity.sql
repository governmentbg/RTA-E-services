INSERT INTO regix_proxy.logs_personal_identity(
	workflow)
	VALUES ('
{
    "error": null,
    "request": [
        "bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoRequestType",
        {
            "egn": "test1",
            "identityDocumentNumber": "test1"
        }
    ],
    "response": [
        "bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoResponseType",
        {
            "egn": "1212124563",
            "height": 170,
            "picture": "iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABc",
            "birthDate": [
                "javax.xml.datatype.XMLGregorianCalendar",
                382744800000
            ],
            "eyesColor": "СВЕТЛИ",
            "issueDate": [
                "javax.xml.datatype.XMLGregorianCalendar",
                940539600000
            ],
            "validDate": null,
            "birthPlace": {
                "countryCode": "BGR",
                "countryName": "България",
                "districtName": "СОФИЙСКА",
                "countryNameLatin": null,
                "municipalityName": "САМОКОВ",
                "territorialUnitName": "ГР.САМОКОВ Общ.САМОКОВ Обл.СОФИЙСКА"
            },
            "genderName": "Мъж",
            "issuerName": "ДИРЕКЦИЯ БДС - ГДОП",
            "issuerPlace": null,
            "personNames": {
                "surname": "ИВАНОВ",
                "firstName": "ЛЮБОМИР от cache",
                "familyName": "МИТЕВ",
                "surnameLatin": "IVANOV",
                "lastNameLatin": "MITEV",
                "firstNameLatin": "LYUBOMIR"
            },
            "documentType": "ЛИЧНА КАРТА",
            "genderNameLatin": null,
            "issuerNameLatin": null,
            "nationalityList": {
                "nationality": [
                    "java.util.ArrayList",
                    [
                        {
                            "nationalityCode": "BGR",
                            "nationalityName": "България",
                            "nationalityNameLatin": null
                        },
                        {
                            "nationalityCode": "USA",
                            "nationalityName": "САЩ",
                            "nationalityNameLatin": null
                        }
                    ]
                ]
            },
            "issuerPlaceLatin": null,
            "permanentAddress": {
                "floor": "",
                "entrance": "",
                "apartment": "",
                "districtName": "СОФИЙСКА",
                "locationCode": "518",
                "locationName": "УЛ.НЕОФИТ РИЛСКИ (Д.КРЪСТЕВ)",
                "buildingNumber": "10",
                "settlementCode": "65231",
                "settlementName": "ГР.САМОКОВ Общ.САМОКОВ Обл.СОФИЙСКА",
                "municipalityName": "САМОКОВ",
                "districtNameLatin": null,
                "locationNameLatin": null,
                "settlementNameLatin": null,
                "municipalityNameLatin": null
            },
            "documentTypeLatin": null,
            "identitySignature": "iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABc",
            "returnInformations": {
                "info": "Успешна операция",
                "returnCode": "0000"
            },
            "identityDocumentNumber": null
        }
    ],
    "clientName": "TechinspClient",
    "callContext": {
        "remark": null,
        "lawReason": "Съгласно чл. 36, ал. 1, т. 3 от Наредба № 38 от 16.04.2004 г. се проверява самоличността на кандидатите, включени в протокола за изпит.",
        "serviceURI": null,
        "serviceType": "За проверовъчна дейност",
        "employeeNames": {
            "name": "{http://tempuri.org/}EmployeeNames",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeePosition": {
            "name": "{http://tempuri.org/}EmployeePosition",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "administrationOId": {
            "name": "{http://tempuri.org/}administrationOId",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "2.16.100.1.1.9",
            "declaredType": "java.lang.String"
        },
        "administrationName": {
            "name": "{http://tempuri.org/}AdministrationName",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Изпълнителна агенция “Автомобилна администрация”",
            "declaredType": "java.lang.String"
        },
        "employeeIdentifier": {
            "name": "{http://tempuri.org/}EmployeeIdentifier",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeeAditionalIdentifier": null,
        "responsiblePersonIdentifier": null
    },
    "requestTime": "2020-04-06T15:19:05.298",
    "responseTime": "2020-04-06T15:19:12.595"
}');

INSERT INTO regix_proxy.logs_personal_identity(
	workflow)
	VALUES ('
{
    "error": null,
    "request": [
        "bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoRequestType",
        {
            "egn": "test2",
            "identityDocumentNumber": "test2"
        }
    ],
    "response": [
        "bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoResponseType",
         {
	        "egn": null,
	        "height": null,
	        "picture": null,
	        "birthDate": null,
	        "eyesColor": null,
	        "issueDate": null,
	        "validDate": null,
	        "birthPlace": {
	            "countryCode": null,
	            "countryName": null,
	            "districtName": null,
	            "countryNameLatin": null,
	            "municipalityName": null,
	            "territorialUnitName": null
	        },
	        "genderName": null,
	        "issuerName": null,
	        "issuerPlace": null,
	        "personNames": {
	            "surname": null,
	            "firstName": null,
	            "familyName": null,
	            "surnameLatin": null,
	            "lastNameLatin": null,
	            "firstNameLatin": null
	        },
	        "documentType": null,
	        "genderNameLatin": null,
	        "issuerNameLatin": null,
	        "nationalityList": {
	            "nationality": [
	                "java.util.ArrayList",
	                []
	            ]
	        },
	        "issuerPlaceLatin": null,
	        "permanentAddress": {
	            "floor": null,
	            "entrance": null,
	            "apartment": null,
	            "districtName": null,
	            "locationCode": null,
	            "locationName": null,
	            "buildingNumber": null,
	            "settlementCode": null,
	            "settlementName": null,
	            "municipalityName": null,
	            "districtNameLatin": null,
	            "locationNameLatin": null,
	            "settlementNameLatin": null,
	            "municipalityNameLatin": null
	        },
	        "documentTypeLatin": null,
	        "identitySignature": null,
	        "returnInformations": {
	            "info": "Няма данни отговарящи на условията",
	            "returnCode": "0100"
	        },
	        "identityDocumentNumber": null
        }
    ],
    "clientName": "TechinspClient",
    "callContext": {
        "remark": null,
        "lawReason": "Съгласно чл. 36, ал. 1, т. 3 от Наредба № 38 от 16.04.2004 г. се проверява самоличността на кандидатите, включени в протокола за изпит.",
        "serviceURI": null,
        "serviceType": "За проверовъчна дейност",
        "employeeNames": {
            "name": "{http://tempuri.org/}EmployeeNames",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeePosition": {
            "name": "{http://tempuri.org/}EmployeePosition",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "administrationOId": {
            "name": "{http://tempuri.org/}administrationOId",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "2.16.100.1.1.9",
            "declaredType": "java.lang.String"
        },
        "administrationName": {
            "name": "{http://tempuri.org/}AdministrationName",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Изпълнителна агенция “Автомобилна администрация”",
            "declaredType": "java.lang.String"
        },
        "employeeIdentifier": {
            "name": "{http://tempuri.org/}EmployeeIdentifier",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeeAditionalIdentifier": null,
        "responsiblePersonIdentifier": null
    },
    "requestTime": "2020-04-06T15:18:12.595",
    "responseTime": "2020-04-06T15:19:12.595"
}');


INSERT INTO regix_proxy.logs_personal_identity(
	workflow)
	VALUES ('
{
    "error": "Response has error flag - Error message: Access denied!",
    "request": [
        "bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoRequestType",
        {
            "egn": "test3",
            "identityDocumentNumber": "test3"
        }
    ],
    "response": null,
    "clientName": "TechinspClient",
    "callContext": {
        "remark": null,
        "lawReason": "Съгласно чл. 36, ал. 1, т. 3 от Наредба № 38 от 16.04.2004 г. се проверява самоличността на кандидатите, включени в протокола за изпит.",
        "serviceURI": null,
        "serviceType": "За проверовъчна дейност",
        "employeeNames": {
            "name": "{http://tempuri.org/}EmployeeNames",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeePosition": {
            "name": "{http://tempuri.org/}EmployeePosition",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "administrationOId": {
            "name": "{http://tempuri.org/}administrationOId",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "2.16.100.1.1.9",
            "declaredType": "java.lang.String"
        },
        "administrationName": {
            "name": "{http://tempuri.org/}AdministrationName",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Изпълнителна агенция “Автомобилна администрация”",
            "declaredType": "java.lang.String"
        },
        "employeeIdentifier": {
            "name": "{http://tempuri.org/}EmployeeIdentifier",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "employeeAditionalIdentifier": null,
        "responsiblePersonIdentifier": null
    },
    "requestTime": "2020-04-06T15:22:17.502",
    "responseTime": "2020-04-06T15:22:18.485"
}');

UPDATE regix_proxy.logs_personal_identity 
SET request_time = (workflow ->>'requestTime')::timestamp;