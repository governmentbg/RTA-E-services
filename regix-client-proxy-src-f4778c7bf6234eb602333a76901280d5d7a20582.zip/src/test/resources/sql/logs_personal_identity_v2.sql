INSERT INTO regix_proxy.logs_personal_identity_v2(
	workflow)
	VALUES ('
{
    "error": null,
    "request": [
        "bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoRequestType",
        {
            "egn": "test1",
            "identityDocumentNumber": "test1"
        }
    ],
    "response": [
        "bg.government.regixclient.requests.mvr.bds.PersonalIdentityInfoResponseType",
        {
            "egn": null,
            "height": 170,
            "picture": null,
            "birthDate": [
                "javax.xml.datatype.XMLGregorianCalendar",
                94860000000
            ],
            "eyesColor": "ПЪСТРИ",
            "issueDate": [
                "javax.xml.datatype.XMLGregorianCalendar",
                1272834000000
            ],
            "rpremarks": {
                "rpremark": [
                    "java.util.ArrayList",
                    []
                ]
            },
            "validDate": [
                "javax.xml.datatype.XMLGregorianCalendar",
                1588453200000
            ],
            "birthPlace": {
                "countryCode": "BGR",
                "countryName": "България",
                "districtName": "ГАБРОВО",
                "countryNameLatin": null,
                "municipalityName": "СЕВЛИЕВО",
                "territorialUnitName": "ГР.СЕВЛИЕВО Общ.СЕВЛИЕВО Обл.ГАБРОВО"
            },
            "genderName": null,
            "issuerName": "МВР Габрово",
            "issuerPlace": null,
            "personNames": {
                "surname": null,
                "firstName": null,
                "familyName": null,
                "surnameLatin": null,
                "lastNameLatin": null,
                "firstNameLatin": null
            },
            "documentType": "ЛИЧНА КАРТА",
            "dlcategоries": {
                "dlcategory": [
                    "java.util.ArrayList",
                    [
                    	{
                    		"category": "Category from cache",
    						"dateCategory": null,
    						"endDateCategory": null,
    						"restrictions": null
                    	}
                    ]
                ]
            },
            "rptypeofPermit": null,
            "genderNameLatin": null,
            "issuerNameLatin": "MoI BGR",
            "nationalityList": {
                "nationality": [
                    "java.util.ArrayList",
                    [
                        {
                            "nationalityCode": "BGR",
                            "nationalityName": "България",
                            "nationalityNameLatin": null
                        }
                    ]
                ]
            },
            "actualStatusDate": [
                "javax.xml.datatype.XMLGregorianCalendar",
                1396386000000
            ],
            "issuerPlaceLatin": null,
            "permanentAddress": {
                "floor": "3",
                "entrance": "Б",
                "apartment": "7",
                "districtName": "ГАБРОВО",
                "locationCode": "60616",
                "locationName": "ЖК Д-РАТАНАС МОСКОВ",
                "buildingNumber": "24",
                "settlementCode": "65927",
                "settlementName": "ГР.СЕВЛИЕВО Общ.СЕВЛИЕВО Обл.ГАБРОВО",
                "municipalityName": "СЕВЛИЕВО",
                "districtNameLatin": null,
                "locationNameLatin": null,
                "settlementNameLatin": null,
                "municipalityNameLatin": null
            },
            "documentTypeLatin": null,
            "identitySignature": null,
            "dataForeignCitizen": {
                "pn": null,
                "pin": null,
                "names": {
                    "surname": null,
                    "firstName": null,
                    "familyName": null,
                    "surnameLatin": null,
                    "lastNameLatin": null,
                    "firstNameLatin": null
                },
                "gender": {
                    "latin": null,
                    "cyrillic": null,
                    "genderCode": null
                },
                "birthDate": null,
                "nationalityList": {
                    "nationality": [
                        "java.util.ArrayList",
                        []
                    ]
                }
            },
            "returnInformations": {
                "info": "Успешна операция",
                "returnCode": "0000"
            },
            "dlcommonRestrictions": "restrictions here",
            "documentActualStatus": "НЕВАЛИДЕН",
            "documentStatusReason": "ИЗГУБЕН (ОТКРАДНАТ)",
            "identityDocumentNumber": "640112305"
        }
    ],
    "clientName": "TechinspClient",
    "callContext": {
        "remark": null,
        "lawReason": "Съгласно чл. 36, ал. 1, т. 3 от Наредба № 38 от 16.04.2004 г. се проверява самоличността на кандидатите, включени в протокола за изпит.",
        "serviceURI": "65232:2019-12-23 14:24:30.916",
        "serviceType": "За проверовъчна дейност",
        "employeeNames": {
            "name": "{http://tempuri.org/}EmployeeNames",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "С Иванов",
            "declaredType": "java.lang.String"
        },
        "employeePosition": {
            "name": "{http://tempuri.org/}EmployeePosition",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "administrationOId": {
            "name": "{http://tempuri.org/}administrationOId",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "2.16.100.1.1.9",
            "declaredType": "java.lang.String"
        },
        "administrationName": {
            "name": "{http://tempuri.org/}AdministrationName",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Изпълнителна агенция “Автомобилна администрация”",
            "declaredType": "java.lang.String"
        },
        "employeeIdentifier": {
            "name": "{http://tempuri.org/}EmployeeIdentifier",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "_sivanov@rta.government.bg_",
            "declaredType": "java.lang.String"
        },
        "employeeAditionalIdentifier": null,
        "responsiblePersonIdentifier": null
    },
    "requestTime": "2020-06-02T09:47:56.099",
    "responseTime": "2020-06-02T09:47:56.725"
}

	
');

UPDATE regix_proxy.logs_personal_identity_v2 
SET request_time = (workflow ->>'requestTime')::timestamp;