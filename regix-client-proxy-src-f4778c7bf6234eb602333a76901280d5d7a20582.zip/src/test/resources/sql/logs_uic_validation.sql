INSERT INTO regix_proxy.logs_uic_validation(
	workflow)
	VALUES ('
{
    "error": null,
    "request": [
        "bg.government.regixclient.requests.av.tr.uicvalidation.ValidUICRequestType",
        {
            "uic": "test1"
        }
    ],
    "response": [
        "bg.government.regixclient.requests.av.tr.uicvalidation.ValidUICResponseType",
        {
            "uic": "201593301 от cache",
            "status": "НОВА_ПАРТИДА",
            "company": "ТехноЛогика",
            "legalForm": {
                "legalFormAbbr": "ЕАД",
                "legalFormName": "Еднолично акционерно дружество"
            },
            "dataValidForDate": null
        }
    ],
    "clientName": "TechinspClient",
    "callContext": {
        "remark": null,
        "lawReason": "Съгласно чл. 36, ал. 1, т. 3 от Наредба № 38 от 16.04.2004 г. се проверява самоличността на кандидатите, включени в протокола за изпит.",
        "serviceURI": "65232:2019-12-23 14:24:30.916",
        "serviceType": "За проверовъчна дейност",
        "employeeNames": {
            "name": "{http://tempuri.org/}EmployeeNames",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "С Иванов",
            "declaredType": "java.lang.String"
        },
        "employeePosition": {
            "name": "{http://tempuri.org/}EmployeePosition",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "administrationOId": {
            "name": "{http://tempuri.org/}administrationOId",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "2.16.100.1.1.9",
            "declaredType": "java.lang.String"
        },
        "administrationName": {
            "name": "{http://tempuri.org/}AdministrationName",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Изпълнителна агенция “Автомобилна администрация”",
            "declaredType": "java.lang.String"
        },
        "employeeIdentifier": {
            "name": "{http://tempuri.org/}EmployeeIdentifier",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "_sivanov@rta.government.bg_",
            "declaredType": "java.lang.String"
        },
        "employeeAditionalIdentifier": null,
        "responsiblePersonIdentifier": null
    },
    "requestTime": "2020-04-24T10:53:59.004",
    "responseTime": "2020-04-24T10:54:00.19"
}');

INSERT INTO regix_proxy.logs_uic_validation(
	workflow)
	VALUES ('
{
    "error": null,
    "request": [
        "bg.government.regixclient.requests.av.tr.uicvalidation.ValidUICRequestType",
        {
            "uic": "test2"
        }
    ],
    "response": [
        "bg.government.regixclient.requests.av.tr.uicvalidation.ValidUICResponseType",
        {
            "uic": "201593301",
            "status": "НОВА_ПАРТИДА",
            "company": "ТехноЛогика",
            "legalForm": {
                "legalFormAbbr": "ЕАД",
                "legalFormName": "Еднолично акционерно дружество"
            },
            "dataValidForDate": null
        }
    ],
    "clientName": "TechinspClient",
    "callContext": {
        "remark": null,
        "lawReason": "Съгласно чл. 36, ал. 1, т. 3 от Наредба № 38 от 16.04.2004 г. се проверява самоличността на кандидатите, включени в протокола за изпит.",
        "serviceURI": "65232:2019-12-23 14:24:30.916",
        "serviceType": "За проверовъчна дейност",
        "employeeNames": {
            "name": "{http://tempuri.org/}EmployeeNames",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "С Иванов",
            "declaredType": "java.lang.String"
        },
        "employeePosition": {
            "name": "{http://tempuri.org/}EmployeePosition",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": null,
            "declaredType": "java.lang.String"
        },
        "administrationOId": {
            "name": "{http://tempuri.org/}administrationOId",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "2.16.100.1.1.9",
            "declaredType": "java.lang.String"
        },
        "administrationName": {
            "name": "{http://tempuri.org/}AdministrationName",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "Изпълнителна агенция “Автомобилна администрация”",
            "declaredType": "java.lang.String"
        },
        "employeeIdentifier": {
            "name": "{http://tempuri.org/}EmployeeIdentifier",
            "scope": "javax.xml.bind.JAXBElement$GlobalScope",
            "value": "_sivanov@rta.government.bg_",
            "declaredType": "java.lang.String"
        },
        "employeeAditionalIdentifier": null,
        "responsiblePersonIdentifier": null
    },
    "requestTime": "2020-01-04T10:53:59.004",
    "responseTime": "2020-04-24T10:54:00.19"
}');

UPDATE regix_proxy.logs_uic_validation 
SET request_time = (workflow ->>'requestTime')::timestamp;