package bg.demax.eservices.backend.bulsi.egov.saml;

import javax.xml.namespace.QName;

import org.opensaml.xml.schema.XSString;


public interface ResourceOID extends XSString {

  /**
   * Local name of the XSI type.
   */
  String TYPE_LOCAL_NAME = "ResourceOID";

  /**
   * QName of the XSI type.
   */
  QName TYPE_NAME = new QName(SAMLeAuthConstants.SAML2_EAUTH_EXT_NS,
      TYPE_LOCAL_NAME,
      SAMLeAuthConstants.SAML2_EAUTH_EXT_PREFIX
  );

}
