package bg.demax.eservices.backend.bulsi.egov.saml;

public class SAMLeAuthConstants {

  public static final String SAML2_EAUTH_EXT_NS = "urn:bg:egov:eauth:2.0:saml:ext";

  public static final String SAML2_EAUTH_EXT_PREFIX = "egovbga";
}
