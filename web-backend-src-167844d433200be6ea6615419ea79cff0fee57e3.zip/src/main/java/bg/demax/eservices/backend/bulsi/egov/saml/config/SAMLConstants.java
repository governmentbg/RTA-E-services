package bg.demax.eservices.backend.bulsi.egov.saml.config;



import static org.opensaml.saml.common.xml.SAMLConstants.SCHEMA_DIR;

public class SAMLConstants {

  public static final String SAML20_BG_EGOV_SCHEMA_LOCATION =
      SCHEMA_DIR + "bg-egov-eauthentication-2.0.xsd";
}
