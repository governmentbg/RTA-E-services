package bg.demax.eservices.backend.bulsi.egov.saml.impl;

import org.opensaml.common.impl.AbstractSAMLObjectBuilder;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;

import bg.demax.eservices.backend.bulsi.egov.saml.LevelOfAssurance;
import bg.demax.eservices.backend.bulsi.egov.saml.SAMLeAuthConstants;


public class LevelOfAssuranceBuilder extends AbstractSAMLObjectBuilder<LevelOfAssurance> {

  @NonNull
  @Override
  public LevelOfAssurance buildObject() {
    return this.buildObject(SAMLeAuthConstants.SAML2_EAUTH_EXT_NS, LevelOfAssurance.TYPE_LOCAL_NAME,
        SAMLeAuthConstants.SAML2_EAUTH_EXT_PREFIX);
  }

  @NonNull
  @Override
  public LevelOfAssurance buildObject(@Nullable String namespaceURI, @NonNull String localName,
      @Nullable String namespacePrefix) {
    return new LevelOfAssuranceImpl(namespaceURI, localName, namespacePrefix);
  }
}
