package bg.demax.eservices.backend.bulsi.egov.saml.impl;

import java.util.List;

import bg.demax.eservices.backend.bulsi.egov.saml.LevelOfAssuranceType;
import org.opensaml.xml.schema.impl.XSStringImpl;

public class LevelOfAssuranceTypeImpl
  extends XSStringImpl
  implements LevelOfAssuranceType {

  /**
   * Constructor.
   *
   * @param namespaceURI     the namespace the element is in
   * @param elementLocalName the local name of the XML element this Object represents
   * @param namespacePrefix  the prefix for the given namespace
   */
  protected LevelOfAssuranceTypeImpl(
    String namespaceURI,
    String elementLocalName,
    String namespacePrefix
  ) {
    super(namespaceURI, elementLocalName, namespacePrefix);
  }
}
