package bg.demax.eservices.backend.bulsi.egov.saml.impl;

import bg.demax.eservices.backend.bulsi.egov.saml.Provider;
import bg.demax.eservices.backend.bulsi.egov.saml.SAMLeAuthConstants;

import org.opensaml.common.impl.AbstractSAMLObjectBuilder;

import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;

public class ProviderBuilder extends AbstractSAMLObjectBuilder<Provider> {

  @NonNull
  @Override
  public Provider buildObject() {
    return this.buildObject(SAMLeAuthConstants.SAML2_EAUTH_EXT_NS, Provider.TYPE_LOCAL_NAME,
        SAMLeAuthConstants.SAML2_EAUTH_EXT_PREFIX);
  }

  @NonNull
  @Override
  public Provider buildObject(@Nullable String namespaceURI, @NonNull String localName,
      @Nullable String namespacePrefix) {
    return new ProviderImpl(namespaceURI, localName, namespacePrefix);
  }
}
