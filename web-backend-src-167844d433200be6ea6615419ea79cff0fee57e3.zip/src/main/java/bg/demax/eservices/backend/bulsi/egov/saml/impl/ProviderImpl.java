package bg.demax.eservices.backend.bulsi.egov.saml.impl;

import java.util.List;

import bg.demax.eservices.backend.bulsi.egov.saml.Provider;

public class ProviderImpl extends ResourceOIDImpl implements Provider {

  /**
   * Constructor.
   *
   * @param namespaceURI     the namespace the element is in
   * @param elementLocalName the local name of the XML element this Object represents
   * @param namespacePrefix  the prefix for the given namespace
   */
  protected ProviderImpl(
    String namespaceURI,
    String elementLocalName,
    String namespacePrefix
  ) {
    super(namespaceURI, elementLocalName, namespacePrefix);
  }
}
