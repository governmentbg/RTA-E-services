package bg.demax.eservices.backend.bulsi.egov.saml.impl;


import org.opensaml.common.impl.AbstractSAMLObjectMarshaller;

public class RequestedServiceMarshaller extends AbstractSAMLObjectMarshaller {

}
