package bg.demax.eservices.backend.bulsi.egov.saml.impl;


import bg.demax.eservices.backend.bulsi.egov.saml.LevelOfAssurance;
import bg.demax.eservices.backend.bulsi.egov.saml.Provider;
import bg.demax.eservices.backend.bulsi.egov.saml.RequestedService;
import bg.demax.eservices.backend.bulsi.egov.saml.Service;

import org.opensaml.common.impl.AbstractSAMLObjectUnmarshaller;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.io.UnmarshallingException;

public class RequestedServiceUnmarshaller extends AbstractSAMLObjectUnmarshaller {


  protected void processChildElement(final XMLObject parentSAMLObject,
      final XMLObject childSAMLObject)
      throws UnmarshallingException {
    RequestedService requestedService = (RequestedService) parentSAMLObject;

    if (childSAMLObject instanceof Provider) {
      requestedService.setProvider((Provider) childSAMLObject);
    } else if (childSAMLObject instanceof Service) {
      requestedService.setService((Service) childSAMLObject);
    } else if (childSAMLObject instanceof LevelOfAssurance) {
        requestedService.setLevelOfAssurance((LevelOfAssurance) childSAMLObject);
    } else {
      super.processChildElement(parentSAMLObject, childSAMLObject);
    }

  }
}
