package bg.demax.eservices.backend.bulsi.egov.saml.impl;

import bg.demax.eservices.backend.bulsi.egov.saml.SAMLeAuthConstants;
import bg.demax.eservices.backend.bulsi.egov.saml.Service;

import org.opensaml.common.impl.AbstractSAMLObjectBuilder;

import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;

public class ServiceBuilder extends AbstractSAMLObjectBuilder<Service> {

  @NonNull
  @Override
  public Service buildObject() {
    return this.buildObject(SAMLeAuthConstants.SAML2_EAUTH_EXT_NS, Service.TYPE_LOCAL_NAME,
        SAMLeAuthConstants.SAML2_EAUTH_EXT_PREFIX);
  }

  @NonNull
  @Override
  public Service buildObject(@Nullable String namespaceURI, @NonNull String localName,
      @Nullable String namespacePrefix) {
    return new ServiceImpl(namespaceURI, localName, namespacePrefix);
  }
}
