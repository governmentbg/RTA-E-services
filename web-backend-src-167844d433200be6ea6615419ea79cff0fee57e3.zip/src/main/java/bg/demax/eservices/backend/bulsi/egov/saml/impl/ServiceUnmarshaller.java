package bg.demax.eservices.backend.bulsi.egov.saml.impl;

import org.opensaml.xml.schema.impl.XSStringUnmarshaller;

public class ServiceUnmarshaller extends XSStringUnmarshaller {

}
