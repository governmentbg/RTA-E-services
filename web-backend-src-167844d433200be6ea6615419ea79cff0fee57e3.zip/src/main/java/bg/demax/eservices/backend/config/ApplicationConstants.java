package bg.demax.eservices.backend.config;

public interface ApplicationConstants {
	String APPLICATION_ENTITIES_PACKAGE_TO_SCAN = "bg.demax.eservices.backend.entity";

	String SPRING_PROFILE_TEST = "test";
	String SPRING_PROFILE_PRODUCTION = "production";
	String SPRING_PROFILE_DEVELOPMENT = "dev";
	String SPRING_PROFILE_DRIVE = "drive";
}
