package bg.demax.eservices.backend.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import bg.demax.eservices.backend.service.config.BeanConfigurationService;
import bg.demax.eservices.backend.util.Utils;

@EnableAsync
@EnableScheduling
@Configuration
public class BeanConfiguration {
	
	@Autowired
	private BeanConfigurationService beanConfigurationService;
			
	@Autowired
	private Utils utils;

	@Bean
	public JavaMailSender getJavaMailSender() {
		if (utils.checkActiveProfile(ApplicationConstants.SPRING_PROFILE_PRODUCTION)) {
			return beanConfigurationService.configureMailSenderProd();
		}
		return beanConfigurationService.configureMailSenderDev();
	}
}
