package bg.demax.eservices.backend.config;

public interface BeanQualifierConstants {
	String PROXY_REST_TEMPLATE = "proxyRestTemplate";
	String REST_TEMPLATE = "restTemplate";
	String IAAA_GATEWAY_REST_TEMPLATE = "iaaaGatewayRestTemplate";
	String IAAA_GATEWAY_REST_TEMPLATE_TACHO_NET = "iaaaGatewayRestTemplateTachoNet";
	String DEMAX_PAYMENT_SERVICE_HTTP_CLIENT = "demaxPaymentServiceHttpClient";
	String IAAA_PAYMENT_SERVICE_HTTP_CLIENT = "iaaaPaymentServiceHttpClient";
}