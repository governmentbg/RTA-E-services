package bg.demax.eservices.backend.config;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.opensaml.common.SAMLException;
import org.opensaml.common.SAMLRuntimeException;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.saml.SAMLAuthenticationProvider;
import org.springframework.security.saml.SAMLAuthenticationToken;
import org.springframework.security.saml.SAMLConstants;
import org.springframework.security.saml.SAMLCredential;
import org.springframework.security.saml.context.SAMLMessageContext;

import bg.demax.eservices.backend.entity.security.User;

public class CustomSAMLAuthenticationProvider extends SAMLAuthenticationProvider {

    @Override
    public Collection<? extends GrantedAuthority> getEntitlements(SAMLCredential credential, Object userDetail) {

        if(userDetail instanceof User) {
            List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
			User user = (User) userDetail;
            authorities.addAll(user.getAuthorities());
            return authorities;

        } else {
            return Collections.emptyList();
        }
    }

    @Override
    protected Object getPrincipal(SAMLCredential credential, Object userDetail) {
        if (userDetail != null) {
            return (userDetail);
        }else if (isForcePrincipalAsString()) {
            return credential.getNameID().getValue();
        } else {
            return credential.getNameID();
        }
    }

    // @Override
    // public Authentication authenticate(Authentication authentication) throws AuthenticationException {

    //     if (!supports(authentication.getClass())) {
    //         throw new IllegalArgumentException("Only SAMLAuthenticationToken is supported, " + authentication.getClass() + " was attempted");
    //     }

    //     SAMLAuthenticationToken token = (SAMLAuthenticationToken) authentication;
    //     SAMLMessageContext context = token.getCredentials();

    //     if (context == null) {
    //         throw new AuthenticationServiceException("SAML message context is not available in the authentication token");
    //     }

    //     SAMLCredential credential;

    //     try {
    //         if (SAMLConstants.SAML2_WEBSSO_PROFILE_URI.equals(context.getCommunicationProfileId())) {
    //             credential = consumer.processAuthenticationResponse(context);
    //         } else if (SAMLConstants.SAML2_HOK_WEBSSO_PROFILE_URI.equals(context.getCommunicationProfileId())) {
    //             credential = hokConsumer.processAuthenticationResponse(context);
    //         } else {
    //             throw new SAMLException("Unsupported profile encountered in the context " + context.getCommunicationProfileId());
    //         }
    //     } catch (SAMLRuntimeException e) {
    //         samlLogger.log(SAMLConstants.AUTH_N_RESPONSE, SAMLConstants.FAILURE, context, e);
    //         throw new AuthenticationServiceException("Error validating SAML message", e);
    //     } catch (SAMLException e) {
    //         samlLogger.log(SAMLConstants.AUTH_N_RESPONSE, SAMLConstants.FAILURE, context, e);
    //         throw new AuthenticationServiceException("Error validating SAML message", e);
    //     } catch (ValidationException e) {
    //         samlLogger.log(SAMLConstants.AUTH_N_RESPONSE, SAMLConstants.FAILURE, context, e);
    //         throw new AuthenticationServiceException("Error validating SAML message signature", e);
    //     } catch (org.opensaml.xml.security.SecurityException e) {
    //         samlLogger.log(SAMLConstants.AUTH_N_RESPONSE, SAMLConstants.FAILURE, context, e);
    //         throw new AuthenticationServiceException("Error validating SAML message signature", e);
    //     } catch (DecryptionException e) {
    //         samlLogger.log(SAMLConstants.AUTH_N_RESPONSE, SAMLConstants.FAILURE, context, e);
    //         throw new AuthenticationServiceException("Error decrypting SAML message", e);
    //     }

    //     Object userDetails = getUserDetails(credential);
    //     Object principal = getPrincipal(credential, userDetails);
    //     Collection<? extends GrantedAuthority> entitlements = getEntitlements(credential, userDetails);

    //     Date expiration = getExpirationDate(credential);

    //     SAMLCredential authenticationCredential = excludeCredential ? null : credential;
    //     ExpiringUsernameAuthenticationToken result = new ExpiringUsernameAuthenticationToken(expiration, principal, authenticationCredential, entitlements);
    //     result.setDetails(userDetails);
        
    //     samlLogger.log(SAMLConstants.AUTH_N_RESPONSE, SAMLConstants.SUCCESS, context, result, null);

    //     return result;

    // }

}
