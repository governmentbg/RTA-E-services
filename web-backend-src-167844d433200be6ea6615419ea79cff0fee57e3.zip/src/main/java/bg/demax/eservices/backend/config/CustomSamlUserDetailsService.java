package bg.demax.eservices.backend.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.saml.SAMLCredential;
import org.springframework.security.saml.userdetails.SAMLUserDetailsService;
import org.springframework.stereotype.Service;

import bg.demax.eservices.backend.security.CustomSamlPrincipalExtractor;

@Service
public class CustomSamlUserDetailsService implements SAMLUserDetailsService {


	@Value("${user.pid}")
	private String pid;

	@Autowired
	CustomSamlPrincipalExtractor samlPrincipalExtractor;

	@Override
	public Object loadUserBySAML(SAMLCredential credential) throws UsernameNotFoundException {
		
		return samlPrincipalExtractor.getUserFromSamlCredential(credential);
	}
	
}
