package bg.demax.eservices.backend.config;

import java.io.IOException;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import bg.demax.payment.service.api.http.PaymentServiceHttpClient;

@Configuration
public class DemaxPaymentServiceHttpClientConfiguration {
	
	@Value("${payment.service.demax.keystore.classpath.file}")
	private Resource keystoreCAResource;
	
	@Value("${payment.service.demax.client.keystore.classpath.file}")
	private Resource paymentServiceKeystoreResource;
	
	@Value("${payment.service.demax.keystore.password}")
	private String paymentServiceClientKeystorePassword;
	
	@Value("${payment.service.demax.base-url}")
	private String baseUrl;
	
	private RestTemplate restTemplate() {
		return new RestTemplate(sslRequestFactory());
	}

	@Bean(name = "demaxPaymentServiceHttpClient")
	public PaymentServiceHttpClient paymentServiceHttpClient() {
		PaymentServiceHttpClient client = new PaymentServiceHttpClient();
		client.setBaseUrl(baseUrl);
		client.setRestTemplate(restTemplate());
		return client;
	}

	private ClientHttpRequestFactory sslRequestFactory() {
		try {
			SSLContext sslContext = new SSLContextBuilder()
					.loadKeyMaterial(paymentServiceClientKeyStore(), paymentServiceClientKeystorePassword.toCharArray())
					.loadTrustMaterial(keystoreCAResource.getURL(), paymentServiceClientKeystorePassword.toCharArray())
					.build();

			SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext, 
					NoopHostnameVerifier.INSTANCE);
			CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).build();
			HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
			return requestFactory;
		} catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException | UnrecoverableKeyException
				| CertificateException | IOException e) {
			throw new RuntimeException("Could not setup ClientHttpRequestFactory.", e);
		}
	}

	private KeyStore paymentServiceClientKeyStore() {
		try {
			KeyStore keyStore = KeyStore.getInstance("JKS");
			InputStream keyStoreInputStream = paymentServiceKeystoreResource.getInputStream();
			keyStore.load(keyStoreInputStream, paymentServiceClientKeystorePassword.toCharArray());
			keyStoreInputStream.close();
			return keyStore;
		} catch (NoSuchAlgorithmException | CertificateException | IOException | KeyStoreException e) {
			throw new RuntimeException("Could not load payment service keystore.", e);
		}
	}
}
