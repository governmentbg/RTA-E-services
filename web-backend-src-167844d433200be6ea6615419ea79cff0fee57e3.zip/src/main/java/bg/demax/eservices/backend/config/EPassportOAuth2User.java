package bg.demax.eservices.backend.config;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.oauth2.core.user.OAuth2User;

import bg.demax.eservices.backend.entity.security.Role.Roles;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EPassportOAuth2User implements OAuth2User {

	private Map<String, Object> attributes;

	private String name;
	private String nameCyrillic;
	private String egn;

	@Override
	public Map<String, Object> getAttributes() {
		if (this.attributes == null) {
			this.attributes = new HashMap<>();
			this.attributes.put("name", this.getName());
			this.attributes.put("egn", this.getEgn());
			this.attributes.put("nameCyrillic", this.getNameCyrillic());
		}
		return attributes;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return AuthorityUtils.createAuthorityList(Roles.ROLE_APPLICANT_E_FACE.getName());
	}
}
