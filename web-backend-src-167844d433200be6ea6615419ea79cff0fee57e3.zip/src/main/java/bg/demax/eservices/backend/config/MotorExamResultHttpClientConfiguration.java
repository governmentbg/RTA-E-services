package bg.demax.eservices.backend.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import bg.demax.eservices.backend.http.MotorExamResultHttpClient;

@Configuration
public class MotorExamResultHttpClientConfiguration {
	
	@Value("${bg.demax.eservices.motor.exam.result.base-url}")
	private String baseUrl;
	
	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_GATEWAY_REST_TEMPLATE)
	private RestTemplate iaaaGatewayRestTemplate;

	@Bean
	public MotorExamResultHttpClient motorExamResultHttpClient() {
		MotorExamResultHttpClient client = new MotorExamResultHttpClient();
		client.setBaseUrl(baseUrl);
		client.setRestTemplate(iaaaGatewayRestTemplate);
		return client;
	}
}
