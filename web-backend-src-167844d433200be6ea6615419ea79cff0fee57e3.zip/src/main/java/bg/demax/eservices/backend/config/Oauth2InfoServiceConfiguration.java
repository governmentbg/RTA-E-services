package bg.demax.eservices.backend.config;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.oauth2.resource.AuthoritiesExtractor;
import org.springframework.boot.autoconfigure.security.oauth2.resource.PrincipalExtractor;
import org.springframework.boot.autoconfigure.security.oauth2.resource.ResourceServerProperties;
import org.springframework.boot.autoconfigure.security.oauth2.resource.UserInfoTokenServices;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.security.oauth2.client.OAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.filter.OAuth2ClientAuthenticationProcessingFilter;
import org.springframework.security.oauth2.client.filter.OAuth2ClientContextFilter;
import org.springframework.security.oauth2.client.token.grant.code.AuthorizationCodeResourceDetails;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.web.filter.CompositeFilter;

import bg.demax.eservices.backend.service.config.Oauth2ConfigurationService;
import bg.demax.eservices.backend.util.Utils;

@Configuration
@EnableOAuth2Client
public class Oauth2InfoServiceConfiguration {

	@Autowired
	public SimpleUrlAuthenticationSuccessHandler simpleUrlAuthenticationSuccessHandler;

	@Autowired
	private OAuth2ClientContext oauth2ClientContext;

	private Oauth2ConfigurationService oauth2ConfigurationService;
		
	@Autowired
	private Utils utils;
	
	@Autowired
	private FilterChainProxy samlFilter;
	
	@Autowired
	public Oauth2InfoServiceConfiguration(@Lazy Oauth2ConfigurationService oauth2ConfigurationService) {
		this.oauth2ConfigurationService = oauth2ConfigurationService;
	}

	@Bean
	public FilterRegistrationBean<OAuth2ClientContextFilter> oauth2ClientFilterRegistration(
			OAuth2ClientContextFilter filter) {
		FilterRegistrationBean<OAuth2ClientContextFilter> registration = new FilterRegistrationBean<OAuth2ClientContextFilter>();
		registration.setFilter(filter);
		registration.setOrder(-100);
		return registration;
	}

	@Bean
	public AuthorizationCodeResourceDetails infoService() {
		if (utils.checkActiveProfile(ApplicationConstants.SPRING_PROFILE_DEVELOPMENT)) {
			return oauth2ConfigurationService.setAuthorizationCodeResourceDetailsDev();
		} else if (utils.checkActiveProfile(ApplicationConstants.SPRING_PROFILE_DRIVE)) {
			return oauth2ConfigurationService.setAuthorizationCodeResourceDetailsDrive();
		}
		return oauth2ConfigurationService.setAuthorizationCodeResourceDetailsProd();
	}

	@Primary
	@Bean("infoServiceResource")
	public ResourceServerProperties infoServiceResource() {
		if (utils.checkActiveProfile(ApplicationConstants.SPRING_PROFILE_DEVELOPMENT)) {
			return oauth2ConfigurationService.setResourceServerPropertiesDev();
		} else if (utils.checkActiveProfile(ApplicationConstants.SPRING_PROFILE_DRIVE)) {
			return oauth2ConfigurationService.setResourceServerPropertiesDrive();
		}
		return oauth2ConfigurationService.setResourceServerPropertiesProd();
	}

	@Bean("simpleUrlAuthenticationSuccessHandler")
	public SimpleUrlAuthenticationSuccessHandler devUrlAuthenticationSuccessHandler() {
		SimpleUrlAuthenticationSuccessHandler simpleUrlAuthenticationSuccessHandler = new SimpleUrlAuthenticationSuccessHandler();
		simpleUrlAuthenticationSuccessHandler.setAlwaysUseDefaultTargetUrl(true);
		simpleUrlAuthenticationSuccessHandler.setDefaultTargetUrl(oauth2ConfigurationService.getDefaultTargetUrl());
		simpleUrlAuthenticationSuccessHandler.setUseReferer(true);
		return simpleUrlAuthenticationSuccessHandler;
	}

	@Bean("oauth2InfoServiceFilter")
	public Filter ssoFilter(AuthoritiesExtractor authoritiesExtractor, PrincipalExtractor principalExtractor)
			throws Exception {
		OAuth2ClientAuthenticationProcessingFilter infoServiceFilter = new OAuth2ClientAuthenticationProcessingFilter(
			"/login/info-service");
		OAuth2RestTemplate infoServiceTemplate = new OAuth2RestTemplate(infoService(), oauth2ClientContext);
		infoServiceFilter.setRestTemplate(infoServiceTemplate);
		UserInfoTokenServices tokenServices = new UserInfoTokenServices(infoServiceResource().getUserInfoUri(),
				infoService().getClientId());
		tokenServices.setAuthoritiesExtractor(authoritiesExtractor);
		tokenServices.setPrincipalExtractor(principalExtractor);
		tokenServices.setRestTemplate(infoServiceTemplate);
		infoServiceFilter.setTokenServices(tokenServices);
		infoServiceFilter.setAuthenticationSuccessHandler(simpleUrlAuthenticationSuccessHandler);


		CompositeFilter filter = new CompositeFilter();
		List<Filter> filters = new ArrayList<>();
	
		filters.add(samlFilter);
		// ----------------- INFO SERVICE ----------------------
		filters.add(infoServiceFilter);
		
		filter.setFilters(filters);
		return filter;
	}
}
