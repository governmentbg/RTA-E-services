package bg.demax.eservices.backend.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import bg.demax.eservices.backend.util.CustomTransactionProfilerCallback;
import bg.demax.eservices.backend.util.CustomTransactionRetryInterceptor;

@Configuration
@EnableTransactionManagement
@EnableAspectJAutoProxy
@EnableRetry
@Profile("!" + ApplicationConstants.SPRING_PROFILE_TEST)
public class PostgreConfiguration {

	@Value("${spring.jpa.properties.hibernate.hbm2ddl.auto}")
	private String hibernateHbm2dll;

	@Value("${spring.jpa.properties.hibernate.show_sql}")
	private String hibernateShowSql;

	@Value("${spring.jpa.properties.hibernate.format_sql}")
	private String hibernateFormatSql;

	@Value("${spring.jpa.properties.hibernate.use_sql_comments}")
	private String hibernateUseSqlComments;

	@Value("${spring.jpa.properties.hibernate.dialect}")
	private String hibernateDialect;

	@Value("${spring.jpa.properties.hibernate.temp.use_jdbc_metadata_defaults}")
	private String hibernateTempUseJdbcMetadataDefauls;

	@Value("${spring.datasource.url}")
	private String url;

	@Value("${spring.datasource.username}")
	private String username;

	@Value("${spring.datasource.password}")
	private String password;

	@Value("${spring.datasource.driver-class-name}")
	private String driverClassName;

	@Value("${customTransactionRetryInterceptor.maxRetry}")
	private Integer maxRetry;

	@Value("${customTransactionRetryInterceptor.order}")
	private Integer retryInterceptorOrder;

	@Value("${customTransactionRetryInterceptor.randomSleepMillis}")
	private Integer randomSleepMillis;

	@Value("${customTransactionProfilerCallback.dumpInterval}")
	private Integer dumpInterval;

	@Value("${customTransactionProfilerCallback.order}")
	private Integer callbackOrder;

	@Bean("entityManagerFactory")
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(dataSource());
		sessionFactory.setPackagesToScan(ApplicationConstants.APPLICATION_ENTITIES_PACKAGE_TO_SCAN);
		sessionFactory.setHibernateProperties(hibernateProperties());
		return sessionFactory;
	}

	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setUrl(url);
		dataSource.setUsername(username);
		dataSource.setPassword(password);
		dataSource.setDriverClassName(driverClassName);
		return dataSource;
	}

	private Properties hibernateProperties() {
		Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty("hibernate.hbm2ddl.auto", hibernateHbm2dll);
		hibernateProperties.setProperty("hibernate.show_sql", hibernateShowSql);
		hibernateProperties.setProperty("hibernate.format_sql", hibernateFormatSql);
		hibernateProperties.setProperty("hibernate.use_sql_comments", hibernateUseSqlComments);
		hibernateProperties.setProperty("hibernate.dialect", hibernateDialect);
		hibernateProperties.setProperty("hibernate.temp.use_jdbc_metadata_defaults", hibernateTempUseJdbcMetadataDefauls);
		return hibernateProperties;
	}

	@Bean
	public CustomTransactionRetryInterceptor customTransactionRetryInterceptor() {
		CustomTransactionRetryInterceptor retryInterceptor = new CustomTransactionRetryInterceptor();
		retryInterceptor.setMaxRetries(maxRetry);
		retryInterceptor.setOrder(retryInterceptorOrder);
		retryInterceptor.setRandomSleepMillis(randomSleepMillis);
		return retryInterceptor;
	}

	@Bean
	public CustomTransactionProfilerCallback custoProfilerCallbackmTransactionProfilerCallback() {
		CustomTransactionProfilerCallback profilerCallback = new CustomTransactionProfilerCallback();
		profilerCallback.setDumpInterval(dumpInterval);
		profilerCallback.setOrder(callbackOrder);
		return profilerCallback;
	}
}