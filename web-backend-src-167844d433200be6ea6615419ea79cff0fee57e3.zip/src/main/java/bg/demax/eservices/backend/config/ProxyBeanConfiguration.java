package bg.demax.eservices.backend.config;

import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.TrustStrategy;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
@Profile("!" + ApplicationConstants.SPRING_PROFILE_TEST)
public class ProxyBeanConfiguration {

	@Bean
	@Qualifier("regixContext")
	public RegixProxySslContextFactoryBean proxySslContext() throws Exception {
		return new RegixProxySslContextFactoryBean();
	}

	@Bean
	@Qualifier("iaaaGatewayContext")
	public IaaaGatewaySslContextFactoryBean iaaaGatewaySslContext() throws Exception {
		return new IaaaGatewaySslContextFactoryBean();
	}

	@Bean(name = BeanQualifierConstants.PROXY_REST_TEMPLATE)
	public RestTemplate proxyRestTemplate() throws Exception {

		SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(proxySslContext().getObject(),
			new NoopHostnameVerifier());

		HttpClientBuilder proxyHttpClientBuilder = HttpClientBuilder.create();
		proxyHttpClientBuilder.setSSLSocketFactory(sslConnectionSocketFactory);
		proxyHttpClientBuilder.setSSLContext(proxySslContext().getObject());

		HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = 
				new HttpComponentsClientHttpRequestFactory();
		httpComponentsClientHttpRequestFactory.setHttpClient(proxyHttpClientBuilder.build());

		RestTemplate regixProxyRestTemplate = new RestTemplate();
		regixProxyRestTemplate.setRequestFactory(httpComponentsClientHttpRequestFactory);
		return regixProxyRestTemplate;
	}

	@Bean(name = BeanQualifierConstants.IAAA_GATEWAY_REST_TEMPLATE)
	public RestTemplate iaaaGatewayRestTemplate() throws Exception {

		SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(iaaaGatewaySslContext().getObject(),
			new NoopHostnameVerifier());

		HttpClientBuilder iaaaGatewayHttpClientBuilder = HttpClientBuilder.create();
		iaaaGatewayHttpClientBuilder.setSSLSocketFactory(sslConnectionSocketFactory);
		iaaaGatewayHttpClientBuilder.setSSLContext(iaaaGatewaySslContext().getObject());

		HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = 
				new HttpComponentsClientHttpRequestFactory();
		httpComponentsClientHttpRequestFactory.setHttpClient(iaaaGatewayHttpClientBuilder.build());

		RestTemplate iaaaGatewayRestTemplate = new RestTemplate();
		iaaaGatewayRestTemplate.setRequestFactory(httpComponentsClientHttpRequestFactory);
		return iaaaGatewayRestTemplate;
	}

	@Bean(name = BeanQualifierConstants.IAAA_GATEWAY_REST_TEMPLATE_TACHO_NET)
	public RestTemplate iaaaGatewayRestTemplateTachoNet() throws Exception {
		SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(
				iaaaGatewaySslContext().getObject(), new NoopHostnameVerifier());

		HttpClientBuilder iaaaGatewayHttpClientBuilder = HttpClientBuilder.create();
		iaaaGatewayHttpClientBuilder.setSSLSocketFactory(sslConnectionSocketFactory);
		iaaaGatewayHttpClientBuilder.setSSLContext(iaaaGatewaySslContext().getObject());

		HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = 
			new HttpComponentsClientHttpRequestFactory();
		httpComponentsClientHttpRequestFactory.setHttpClient(iaaaGatewayHttpClientBuilder.build());

		RestTemplate iaaaGatewayRestTemplateTachoNet = new RestTemplate();
		iaaaGatewayRestTemplateTachoNet.setRequestFactory(httpComponentsClientHttpRequestFactory);
		iaaaGatewayRestTemplateTachoNet.setErrorHandler(new TachoRestTemplateResponseErrorHandler());
		return iaaaGatewayRestTemplateTachoNet;
	}

	@Bean(name = BeanQualifierConstants.REST_TEMPLATE)
	public RestTemplate restTemplate() throws Exception {
		HostnameVerifier allHostsValid = new HostnameVerifier() {
			@Override
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		};
		HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;
		SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom()
			.loadTrustMaterial(null, acceptingTrustStrategy)
			.build();
		SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);
		CloseableHttpClient httpClient = HttpClients.custom()
			.setSSLSocketFactory(csf)
			.build();
		HttpComponentsClientHttpRequestFactory requestFactory =
			new HttpComponentsClientHttpRequestFactory();
		requestFactory.setHttpClient(httpClient);
		RestTemplate restTemplate = new RestTemplate(requestFactory);
		return restTemplate;
	}
}