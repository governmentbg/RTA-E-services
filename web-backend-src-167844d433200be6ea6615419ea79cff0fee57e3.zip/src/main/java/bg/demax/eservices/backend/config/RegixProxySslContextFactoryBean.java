package bg.demax.eservices.backend.config;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.KeyStore;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.eservices.backend.entity.config.Certificate;
import bg.demax.eservices.backend.repository.GenericRepository;
import bg.demax.eservices.backend.util.Utils;

public class RegixProxySslContextFactoryBean implements FactoryBean<SSLContext> {

	@Autowired
	private GenericRepository genericRepository;
		
	@Autowired
	private Utils utils;

	@Override
	@Transactional(readOnly = true)
	@Qualifier("regixContext")
	public SSLContext getObject() throws Exception {
		Certificate keyMaterialCertificate = new Certificate();
		Certificate trustMaterialCertificate = new Certificate();
		
		if (utils.checkActiveProfile(ApplicationConstants.SPRING_PROFILE_DEVELOPMENT)
			|| utils.checkActiveProfile(ApplicationConstants.SPRING_PROFILE_DRIVE)) {
			keyMaterialCertificate = genericRepository.findByIdOrElseThrowException(
				Certificate.class, Certificate.REGIX_KEY_STORE_ADR_PERMITS_TEST_AND_DRIVE_ENVIRONMENT);
			trustMaterialCertificate = genericRepository.findByIdOrElseThrowException(
			Certificate.class, Certificate.REGIX_TRUST_STORE_TEST_AND_DRIVE_ENVIRONMENT);
		} else {
			keyMaterialCertificate = genericRepository.findByIdOrElseThrowException(
				Certificate.class, Certificate.REGIX_KEY_STORE_ADR_PERMITS_PROD_ENVIRONMENT);
			trustMaterialCertificate = genericRepository.findByIdOrElseThrowException(
				Certificate.class, Certificate.REGIX_TRUST_STORE_PROD_ENVIRONMENT);
		}
		String keyMaterialKeystorePassword = keyMaterialCertificate.getPassword();
		byte[] keyMaterialAsByteArray = keyMaterialCertificate.getKey();

		String trustMaterialKeystorePassword = trustMaterialCertificate.getPassword();
		byte[] trustyMaterialAsByteArray = trustMaterialCertificate.getKey();

		SSLContext sslContext = SSLContextBuilder.create()
				.loadKeyMaterial(getKeyStore(keyMaterialAsByteArray, keyMaterialKeystorePassword),
						keyMaterialKeystorePassword.toCharArray())
				.loadTrustMaterial(getKeyStore(trustyMaterialAsByteArray, trustMaterialKeystorePassword),
						new TrustSelfSignedStrategy())
				.build();

		return sslContext;
	}

	@Override
	public Class<?> getObjectType() {
		return SSLContext.class;
	}

	private KeyStore getKeyStore(byte[] keyAsByteArray, String password) throws Exception {
		KeyStore keyStore = KeyStore.getInstance("JKS");
		InputStream keyStream = new ByteArrayInputStream(keyAsByteArray);
		keyStore.load(keyStream, password.toCharArray());

		return keyStore;
	}
}
