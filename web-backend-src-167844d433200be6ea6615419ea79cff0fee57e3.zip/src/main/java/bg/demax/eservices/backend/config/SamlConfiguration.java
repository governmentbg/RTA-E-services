package bg.demax.eservices.backend.config;

import bg.demax.eservices.backend.bulsi.egov.saml.LevelOfAssurance;
import bg.demax.eservices.backend.bulsi.egov.saml.Provider;
import bg.demax.eservices.backend.bulsi.egov.saml.RequestedService;
import bg.demax.eservices.backend.bulsi.egov.saml.Service;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.LevelOfAssuranceBuilder;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.LevelOfAssuranceMarshaller;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.LevelOfAssuranceUnmarshaller;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.ProviderBuilder;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.ProviderMarshaller;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.ProviderUnmarshaller;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.RequestedServiceBuilder;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.RequestedServiceMarshaller;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.RequestedServiceUnmarshaller;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.ServiceBuilder;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.ServiceMarshaller;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.ServiceUnmarshaller;
import bg.demax.eservices.backend.service.config.Oauth2ConfigurationService;
import bg.demax.eservices.backend.util.FileUtils;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.opensaml.saml2.metadata.provider.FilesystemMetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.util.resource.ResourceException;
import org.opensaml.xml.parse.StaticBasicParserPool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.saml.SAMLAuthenticationProvider;
import org.springframework.security.saml.SAMLBootstrap;
import org.springframework.security.saml.SAMLDiscovery;
import org.springframework.security.saml.SAMLEntryPoint;
import org.springframework.security.saml.SAMLLogoutFilter;
import org.springframework.security.saml.SAMLLogoutProcessingFilter;
import org.springframework.security.saml.SAMLProcessingFilter;
import org.springframework.security.saml.context.SAMLContextProviderImpl;
import org.springframework.security.saml.context.SAMLContextProviderLB;
import org.springframework.security.saml.key.JKSKeyManager;
import org.springframework.security.saml.key.KeyManager;
import org.springframework.security.saml.log.SAMLDefaultLogger;
import org.springframework.security.saml.metadata.CachingMetadataManager;
import org.springframework.security.saml.metadata.ExtendedMetadata;
import org.springframework.security.saml.metadata.ExtendedMetadataDelegate;
import org.springframework.security.saml.metadata.MetadataGenerator;
import org.springframework.security.saml.metadata.MetadataGeneratorFilter;
import org.springframework.security.saml.processor.HTTPPostBinding;
import org.springframework.security.saml.processor.HTTPRedirectDeflateBinding;
import org.springframework.security.saml.processor.SAMLBinding;
import org.springframework.security.saml.processor.SAMLProcessorImpl;
import org.springframework.security.saml.util.VelocityFactory;
import org.springframework.security.saml.websso.SingleLogoutProfile;
import org.springframework.security.saml.websso.SingleLogoutProfileImpl;
import org.springframework.security.saml.websso.WebSSOProfileConsumer;
import org.springframework.security.saml.websso.WebSSOProfileConsumerHoKImpl;
import org.springframework.security.saml.websso.WebSSOProfileConsumerImpl;
import org.springframework.security.saml.websso.WebSSOProfileECPImpl;
import org.springframework.security.saml.websso.WebSSOProfileOptions;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.util.ResourceUtils;

@Configuration
public class SamlConfiguration {

  @Value("${saml.keystore.location}")
  private String samlKeystoreLocation;

  @Value("${saml.keystore.password}")
  private String samlKeystorePassword;

  @Value("${saml.keystore.alias}")
  private String samlKeystoreAlias;

  @Value("${saml.idp}")
  private String defaultIdp;

  @Value("${saml.sp}")
  private String samlAudience;

  @Autowired
  @Lazy
  private Oauth2ConfigurationService oauth2ConfigurationService;

  @Bean(initMethod = "initialize")
  public StaticBasicParserPool parserPool() {
    return new StaticBasicParserPool();
  }

  @Bean
  public SAMLAuthenticationProvider samlAuthenticationProvider() {
    return new CustomSAMLAuthenticationProvider();
  }

  // @Bean
  // public SAMLContextProviderImpl contextProvider() {
  //   return new SAMLContextProviderImpl();
  // }

  @Bean
  public static SAMLBootstrap samlBootstrap() {
    return new SAMLBootstrap();
  }

  @Bean
  public SAMLDefaultLogger samlLogger() {
    SAMLDefaultLogger logger = new SAMLDefaultLogger();
    logger.setLogAllMessages(true);
    logger.setLogErrors(true);
    logger.setLogErrors(true);
    return logger;
  }

  @Bean
  public WebSSOProfileConsumer webSSOprofileConsumer() {
    return new WebSSOProfileConsumerImpl();
  }

  @Bean
  @Qualifier("hokWebSSOprofileConsumer")
  public WebSSOProfileConsumerHoKImpl hokWebSSOProfileConsumer() {
    return new WebSSOProfileConsumerHoKImpl();
  }

  @Bean
  public WebSSOProfile webSSOprofile() {
    org.opensaml.xml.Configuration.registerObjectProvider(
      RequestedService.TYPE_NAME,
      new RequestedServiceBuilder(),
      new RequestedServiceMarshaller(),
      new RequestedServiceUnmarshaller()
    );

    org.opensaml.xml.Configuration.registerObjectProvider(
      Provider.TYPE_NAME,
      new ProviderBuilder(),
      new ProviderMarshaller(),
      new ProviderUnmarshaller()
    );

    org.opensaml.xml.Configuration.registerObjectProvider(
      Service.TYPE_NAME,
      new ServiceBuilder(),
      new ServiceMarshaller(),
      new ServiceUnmarshaller()
    );

    org.opensaml.xml.Configuration.registerObjectProvider(
      LevelOfAssurance.TYPE_NAME,
      new LevelOfAssuranceBuilder(),
      new LevelOfAssuranceMarshaller(),
      new LevelOfAssuranceUnmarshaller()
    );

    return new WebSSOProfile();
  }

  @Bean
  public WebSSOProfileConsumerHoKImpl hokWebSSOProfile() {
    return new WebSSOProfileConsumerHoKImpl();
  }

  @Bean
  public WebSSOProfileECPImpl ecpProfile() {
    return new WebSSOProfileECPImpl();
  }

  @Bean
  public SingleLogoutProfile logoutProfile() {
    return new SingleLogoutProfileImpl();
  }

  @Bean
  public WebSSOProfileOptions defaultWebSSOProfileOptions() {
    WebSSOProfileOptions webSSOProfileOptions = new WebSSOProfileOptions();
    webSSOProfileOptions.setIncludeScoping(false);
    return webSSOProfileOptions;
  }

  @Bean
  public SAMLEntryPoint samlEntryPoint() {
    SAMLEntryPoint samlEntryPoint = new SAMLEntryPoint();
    samlEntryPoint.setDefaultProfileOptions(defaultWebSSOProfileOptions());
    samlEntryPoint.setFilterProcessesUrl("/login/saml");
    return samlEntryPoint;
  }

  @Bean
  public SAMLContextProviderLB contextProvider() {
      SAMLContextProviderLB samlContextProviderLB = new SAMLContextProviderLB();
      samlContextProviderLB.setContextPath("/e-services-web");
      samlContextProviderLB.setIncludeServerPortInRequestURL(false);
      samlContextProviderLB.setServerName("drive.demax.bg");
      samlContextProviderLB.setScheme("https");
      return samlContextProviderLB;
  }


  @Bean
  public ExtendedMetadata extendedMetadata() {
    ExtendedMetadata extendedMetadata = new ExtendedMetadata();
    extendedMetadata.setIdpDiscoveryEnabled(false);
    extendedMetadata.setSignMetadata(false);
    return extendedMetadata;
  }

  @Bean
  public KeyManager keyManager() {
    DefaultResourceLoader loader = new DefaultResourceLoader();
    Resource storeFile = loader.getResource(samlKeystoreLocation);
    Map<String, String> passwords = new HashMap<>();
    passwords.put(samlKeystoreAlias, samlKeystorePassword);
    return new JKSKeyManager(
      storeFile,
      samlKeystorePassword,
      passwords,
      samlKeystoreAlias
    );
  }

  @Bean
  public ExtendedMetadataDelegate extendedMetadataProvider()
    throws MetadataProviderException {
    File metadata = null;

    String tmpDir = "/tmp/targetFile.tmp";
    FileUtils.copyJavaResourceDir2TmpDir("xml", tmpDir, FileUtils.FileType.XML);

    try {
      DefaultResourceLoader loader = new DefaultResourceLoader();
      Resource storeFile = loader.getResource(
        "classpath:/saml/metadata/sso.xml"
      );
      InputStream initialStream = storeFile.getInputStream();
      byte[] buffer = new byte[initialStream.available()];
      initialStream.read(buffer);

      File targetFile = new File(tmpDir);
      OutputStream outStream = new FileOutputStream(targetFile);
      outStream.write(buffer);
      outStream.flush();
      outStream.close();
      metadata = (new File(tmpDir));
    } catch (Exception e) {
      e.printStackTrace();
    }

    FilesystemMetadataProvider provider = new FilesystemMetadataProvider(
      metadata
    );
    provider.setParserPool(parserPool());
    return new ExtendedMetadataDelegate(provider, extendedMetadata());
  }

  @Bean
  @Qualifier("metadata")
  public CachingMetadataManager metadata()
    throws MetadataProviderException, ResourceException {
    List<MetadataProvider> providers = new ArrayList<>();
    providers.add(extendedMetadataProvider());
    CachingMetadataManager metadataManager = new CachingMetadataManager(
      providers
    );
    metadataManager.setDefaultIDP(defaultIdp);
    return metadataManager;
  }

  @Bean
  @Qualifier("saml")
  public SavedRequestAwareAuthenticationSuccessHandler authenticationSuccessHandler() {
    SavedRequestAwareAuthenticationSuccessHandler successRedirectHandler = new SavedRequestAwareAuthenticationSuccessHandler();
    successRedirectHandler.setDefaultTargetUrl(
      oauth2ConfigurationService.getDefaultTargetUrl()
    );
    return successRedirectHandler;
  }

  @Bean
  @Qualifier("saml")
  public SimpleUrlAuthenticationFailureHandler authenticationFailureHandler() {
    SimpleUrlAuthenticationFailureHandler failureHandler = new SimpleUrlAuthenticationFailureHandler();
    failureHandler.setUseForward(true);
    failureHandler.setDefaultFailureUrl("/error");
    return failureHandler;
  }

  @Bean
  public SimpleUrlLogoutSuccessHandler successLogoutHandler() {
    SimpleUrlLogoutSuccessHandler successLogoutHandler = new SimpleUrlLogoutSuccessHandler();
    successLogoutHandler.setDefaultTargetUrl("/");
    return successLogoutHandler;
  }

  @Bean
  public SecurityContextLogoutHandler logoutHandler() {
    SecurityContextLogoutHandler logoutHandler = new SecurityContextLogoutHandler();
    logoutHandler.setInvalidateHttpSession(true);
    logoutHandler.setClearAuthentication(true);
    return logoutHandler;
  }

  @Bean
  public SAMLLogoutProcessingFilter samlLogoutProcessingFilter() {
    return new SAMLLogoutProcessingFilter(
      successLogoutHandler(),
      logoutHandler()
    );
  }

  @Bean
  public SAMLLogoutFilter samlLogoutFilter() {
    return new SAMLLogoutFilter(
      successLogoutHandler(),
      new LogoutHandler[] { logoutHandler() },
      new LogoutHandler[] { logoutHandler() }
    );
  }

  @Bean
  public HTTPPostBinding httpPostBinding() {
    return new HTTPPostBinding(parserPool(), VelocityFactory.getEngine());
  }

  @Bean
  public HTTPRedirectDeflateBinding httpRedirectDeflateBinding() {
    return new HTTPRedirectDeflateBinding(parserPool());
  }

  @Bean
  public SAMLProcessorImpl processor() {
    ArrayList<SAMLBinding> bindings = new ArrayList<>();
    bindings.add(httpRedirectDeflateBinding());
    bindings.add(httpPostBinding());
    return new SAMLProcessorImpl(bindings);
  }

  @Bean
  public SAMLDiscovery samlDiscovery() {
    SAMLDiscovery idpDiscovery = new SAMLDiscovery();
    return idpDiscovery;
  }

  public MetadataGenerator metadataGenerator() {
    MetadataGenerator metadataGenerator = new MetadataGenerator();
    metadataGenerator.setEntityId(samlAudience);
    metadataGenerator.setExtendedMetadata(extendedMetadata());
    metadataGenerator.setIncludeDiscoveryExtension(false);
    metadataGenerator.setKeyManager(keyManager());
    metadataGenerator.setRequestSigned(false);
    metadataGenerator.setEntityBaseURL("https://drive.demax.bg/e-services-web");
    return metadataGenerator;
  }

  @Bean
  public SAMLProcessingFilter samlWebSSOProcessingFilter() throws Exception {
    SAMLProcessingFilter samlWebSSOProcessingFilter = new SAMLProcessingFilter();
    samlWebSSOProcessingFilter.setAuthenticationManager(
      authenticationManager()
    );
    samlWebSSOProcessingFilter.setAuthenticationSuccessHandler(
      authenticationSuccessHandler()
    );
    samlWebSSOProcessingFilter.setAuthenticationFailureHandler(
      authenticationFailureHandler()
    );
    samlWebSSOProcessingFilter.setContextProvider(contextProvider());

    return samlWebSSOProcessingFilter;
  }

  @Bean
  public FilterChainProxy samlFilter() throws Exception {
    List<SecurityFilterChain> chains = new ArrayList<>();
    chains.add(
      new DefaultSecurityFilterChain(
        new AntPathRequestMatcher("/saml/SSO/**"),
        samlWebSSOProcessingFilter()
      )
    );
    chains.add(
      new DefaultSecurityFilterChain(
        new AntPathRequestMatcher("/saml/discovery/**"),
        samlDiscovery()
      )
    );
    chains.add(
      new DefaultSecurityFilterChain(
        new AntPathRequestMatcher("/saml/login/**"),
        samlEntryPoint()
      )
    );
    chains.add(
      new DefaultSecurityFilterChain(
        new AntPathRequestMatcher("/saml/logout/**"),
        samlLogoutFilter()
      )
    );
    chains.add(
      new DefaultSecurityFilterChain(
        new AntPathRequestMatcher("/saml/SingleLogout/**"),
        samlLogoutProcessingFilter()
      )
    );
    return new FilterChainProxy(chains);
  }

  @Bean
  @Order(Ordered.HIGHEST_PRECEDENCE)
  public MetadataGeneratorFilter metadataGeneratorFilter() {
    return new MetadataGeneratorFilter(metadataGenerator());
  }

  @Bean
  public AuthenticationManager authenticationManager() {
    return new ProviderManager(
      Collections.singletonList(samlAuthenticationProvider())
    );
  }
}
