package bg.demax.eservices.backend.config;

import bg.demax.eservices.backend.bulsi.egov.saml.LevelOfAssurance;
import bg.demax.eservices.backend.bulsi.egov.saml.Provider;
import bg.demax.eservices.backend.bulsi.egov.saml.RequestedService;
import bg.demax.eservices.backend.bulsi.egov.saml.Service;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.LevelOfAssuranceBuilder;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.ProviderBuilder;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.RequestedServiceBuilder;
import bg.demax.eservices.backend.bulsi.egov.saml.impl.ServiceBuilder;
import org.opensaml.common.SAMLException;
import org.opensaml.saml2.common.Extensions;
import org.opensaml.saml2.common.impl.ExtensionsBuilder;
import org.opensaml.saml2.core.AuthnRequest;
import org.opensaml.saml2.metadata.AssertionConsumerService;
import org.opensaml.saml2.metadata.SingleSignOnService;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.springframework.security.saml.context.SAMLMessageContext;
import org.springframework.security.saml.websso.WebSSOProfileImpl;
import org.springframework.security.saml.websso.WebSSOProfileOptions;

/**
 * Class adds additional extensions element to the AuthnRequest sent to IDP.
 */
public class WebSSOProfile extends WebSSOProfileImpl {

  @Override
  protected AuthnRequest getAuthnRequest(
    SAMLMessageContext context,
    WebSSOProfileOptions options,
    AssertionConsumerService assertionConsumer,
    SingleSignOnService bindingService
  )
    throws SAMLException, MetadataProviderException {
    AuthnRequest authnRequest = super.getAuthnRequest(
      context,
      options,
      assertionConsumer,
      bindingService
    );
    authnRequest.setExtensions(buildExtensions());
    return authnRequest;
  }

  protected Extensions buildExtensions() {
    Extensions extensions = new ExtensionsBuilder()
    .buildObject(
        "urn:oasis:names:tc:SAML:2.0:protocol",
        Extensions.LOCAL_NAME,
        "saml2p"
      );

    RequestedService requestedService = new RequestedServiceBuilder()
      .buildObject();
    Service service = new ServiceBuilder().buildObject();
    Provider provider = new ProviderBuilder().buildObject();
    LevelOfAssurance loa = new LevelOfAssuranceBuilder().buildObject();
    
    service.setValue("2.16.100.1.1.1.1.13.1.1.2");
    provider.setValue("2.16.100.1.1.1.1.13");
    loa.setValue("LOW");

    requestedService.setService(service);
    requestedService.setProvider(provider);
    requestedService.setLevelOfAssurance(loa);

    extensions.getUnknownXMLObjects().add(requestedService);
    return extensions;
  }
}
