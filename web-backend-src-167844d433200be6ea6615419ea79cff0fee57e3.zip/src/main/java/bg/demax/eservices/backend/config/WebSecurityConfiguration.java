package bg.demax.eservices.backend.config;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.servlet.Filter;

import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.oauth2.client.EnableOAuth2Sso;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.oauth2.client.endpoint.DefaultAuthorizationCodeTokenResponseClient;
import org.springframework.security.oauth2.client.http.OAuth2ErrorResponseErrorHandler;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.oauth2.client.userinfo.CustomUserTypesOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.http.converter.OAuth2AccessTokenResponseHttpMessageConverter;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.saml.metadata.MetadataGeneratorFilter;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.logout.HttpStatusReturningLogoutSuccessHandler;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.web.client.RestTemplate;

import bg.demax.eservices.backend.entity.security.Role.Roles;
import bg.demax.eservices.backend.http.HttpUserAgentHeaderInterceptor;
import bg.demax.eservices.backend.service.UserService;
import bg.demax.eservices.backend.service.config.Oauth2ConfigurationService;
import bg.demax.eservices.backend.util.Utils;

@Configuration
@EnableWebSecurity
@EnableOAuth2Sso
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {

	private static final String CSRF_TOKEN_COOKIE_NAME = "_csrf";
	private static final String ACCESS_TOKEN_COOKIE_NAME = "access_token";

	// A workaround for Cloudflare blocking the oauth2 token request.
	private static final String CUSTOM_USER_AGENT_HEADER_VALUE = 
			"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36";

	@Autowired
	private UserService userDetailsService;

	@Autowired
	@Lazy
	private Filter oauth2InfoServiceFilter;

	@Autowired
	private Oauth2ConfigurationService oAuthService;
		
	@Autowired
	private Utils utils;

	@Autowired
	private MetadataGeneratorFilter metadataGeneratorFilter;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.cors().and().csrf()
				// TODO is it okay to leave /api/payments/notify without security here
				.ignoringAntMatchers("/login", "/login/oauth2/code**", "/login/info-service**", 
						"/api/payments/notify/iaaa", "/api/payments/notify/demax", "/login/saml", "/saml/**")
				.csrfTokenRepository(getCsrfTokenRepository())
			.and()
				.addFilterBefore(metadataGeneratorFilter, BasicAuthenticationFilter.class)
				.addFilterBefore(oauth2InfoServiceFilter, BasicAuthenticationFilter.class)
				.exceptionHandling()
				.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED))
			
			.and().csrf().disable();

		authRequestsAndAddMatchers(http)
				.and()
					.logout()
					.logoutUrl("/api/logout")
					.logoutSuccessUrl("/")
					.logoutSuccessHandler((new HttpStatusReturningLogoutSuccessHandler(HttpStatus.OK)))
					.invalidateHttpSession(true)
					.deleteCookies("JSESSIONID", CSRF_TOKEN_COOKIE_NAME, ACCESS_TOKEN_COOKIE_NAME)
					.clearAuthentication(true)
					.permitAll()
				.and()
					.oauth2Login()
					.tokenEndpoint()
					.accessTokenResponseClient(this.accessTokenResponseClient())
				.and()
					.userInfoEndpoint()
					.userService(this.oauth2UserService());
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		super.configure(auth);
		auth.authenticationProvider(preAuthProvider());
	}

	@Bean
	public AuthenticationProvider preAuthProvider() {
		PreAuthenticatedAuthenticationProvider provider = new PreAuthenticatedAuthenticationProvider();
		provider.setPreAuthenticatedUserDetailsService(userDetailsService);
		return provider;
	}

	@Bean
	public CsrfTokenRepository getCsrfTokenRepository() {
		CookieCsrfTokenRepository repository = new CookieCsrfTokenRepository();

		repository.setCookieHttpOnly(false);
		repository.setCookieName(CSRF_TOKEN_COOKIE_NAME);
		repository.setHeaderName("X-CSRF-TOKEN");

		return repository;
	}

	@Bean
	public ClientRegistrationRepository clientRegistrationRepository() {
		List<ClientRegistration> registrations = new ArrayList<>();
		registrations.add(faceAuthClientRegistration());
		return new InMemoryClientRegistrationRepository(registrations);
	}

	private ClientRegistration faceAuthClientRegistration() {
		String redirectUriTemplate = "https://rta.government.bg/e-services-web/login/oauth2/code/{registrationId}";
		if (utils.checkActiveProfile(ApplicationConstants.SPRING_PROFILE_DEVELOPMENT)) {
			redirectUriTemplate = "http://localhost:4200/login/oauth2/code/{registrationId}";
		} else if (utils.checkActiveProfile(ApplicationConstants.SPRING_PROFILE_DRIVE)) {
			redirectUriTemplate = "https://drive.demax.bg/e-services-web/login/oauth2/code/{registrationId}";
		}
		return oAuthService.setClientRegistrationFaceAuth(redirectUriTemplate);
	}

	private DefaultAuthorizationCodeTokenResponseClient accessTokenResponseClient() throws Exception {
		RestTemplate restTemplate = new RestTemplate(
				Arrays.asList(new FormHttpMessageConverter(), new OAuth2AccessTokenResponseHttpMessageConverter()));
		restTemplate.setErrorHandler(new OAuth2ErrorResponseErrorHandler());
		restTemplate.setInterceptors(
				Arrays.asList(new HttpUserAgentHeaderInterceptor(CUSTOM_USER_AGENT_HEADER_VALUE)));
		restTemplate.setRequestFactory(this.faceAuthSslRequestFactory());

		DefaultAuthorizationCodeTokenResponseClient accessTokenResponseClient = new DefaultAuthorizationCodeTokenResponseClient();
		accessTokenResponseClient.setRestOperations(restTemplate);
		return accessTokenResponseClient;
	}

	private OAuth2UserService<OAuth2UserRequest, OAuth2User> oauth2UserService() throws Exception {
		RestTemplate restTemplate = new RestTemplate(this.faceAuthSslRequestFactory());
		MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter = new MappingJackson2HttpMessageConverter();
		mappingJackson2HttpMessageConverter.setSupportedMediaTypes(Arrays.asList(MediaType.APPLICATION_JSON));
		restTemplate.setErrorHandler(new OAuth2ErrorResponseErrorHandler());
		restTemplate.getMessageConverters().add(mappingJackson2HttpMessageConverter);
		restTemplate.setInterceptors(Arrays.asList(new HttpUserAgentHeaderInterceptor(CUSTOM_USER_AGENT_HEADER_VALUE)));
		Map<String, Class<? extends OAuth2User>> customUserTypes = new HashMap<>();
		customUserTypes.put(oAuthService.getFaceAuthClientRegistrationId(), EPassportOAuth2User.class);
		CustomUserTypesOAuth2UserService oAuth2UserService = new CustomUserTypesOAuth2UserService(customUserTypes);
		oAuth2UserService.setRestOperations(restTemplate);
		return oAuth2UserService;
	}
	
	private ClientHttpRequestFactory faceAuthSslRequestFactory() throws Exception {
		try {
			SSLContext sslContext = new SSLContextBuilder()
					.loadTrustMaterial(oAuthService.getKeyStore(), new TrustSelfSignedStrategy())
					.build();

			SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext);
			HttpClient httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).build();
			HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
			return requestFactory;
		} catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException | CertificateException | IOException e) {
			throw new RuntimeException("Could not setup ClientHttpRequestFactory.", e);
		}
	}
	
	private ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry authRequestsAndAddMatchers(
			HttpSecurity httpSecurity) throws Exception {
		return httpSecurity.antMatcher("/**")
			.authorizeRequests()
				// TODO: make /login/info-service access anonymous instead of permitAll when logout is added
				.mvcMatchers("/index.html", "/js/**", "/lib/**", "/assets/**", "/api/csrf", "/login/info-service**",
					"/api/translations/{lang_code}", "/login/saml", "**/saml/**", "/api/translations/languages",
					"/login/oauth2/code**").permitAll()
				.mvcMatchers(HttpMethod.PUT, "/api/payments/notify/iaaa").permitAll()
				.mvcMatchers(HttpMethod.PUT, "/api/payments/notify/demax").permitAll()
				// EMAIL
				.mvcMatchers(HttpMethod.POST, "/api/emails/token")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_APPLICANT_E_SIGN.getName(), 
						Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.PUT, "/api/emails/verify")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_APPLICANT_E_SIGN.getName(), 
						Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.GET, "/api/emails/current")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(),
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())
				// SUBJECT
				.mvcMatchers(HttpMethod.POST, "/api/subjects/personal-info").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.POST, "/api/subjects/approver/mvr-personal-info")
					.hasAnyAuthority(Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.POST, "/api/subjects/approver/mvr-pictures")
					.hasAnyAuthority(Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.POST, "/api/subjects/application/{id}/approver/nap-check")
					.hasAnyAuthority( Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.POST, "/api/subjects/mvr-personal-info").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName())

				.mvcMatchers(HttpMethod.POST, "/api/subjects/applications/{id}/picture-transition")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
							Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())	

				// DOCUMENTS
				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/pdf")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/required-documents")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.PUT, "/api/documents/confirm-attached-documents")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/required-documents-attached")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.GET,
					"/api/documents/application/{id}/milestone/{milestoneId}/required-documents")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(), 
							Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.POST, "/api/documents/application/{id}/document/{typeId}")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
						Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/document/{typeId}")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_APPROVER.getName(), Roles.ROLE_VIEWER.getName())

				.mvcMatchers(HttpMethod.DELETE, "/api/documents/application/{id}/document/{typeId}")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/document/{typeId}/page/{pageId}")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_APPROVER.getName(), Roles.ROLE_VIEWER.getName())
	
				.mvcMatchers(HttpMethod.DELETE, "/api/documents/application/{id}/document/{typeId}/page/{pageId}")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/document/{typeId}/pages-info")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_APPROVER.getName(), Roles.ROLE_VIEWER.getName())

				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/document/{typeId}/check")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.PUT, "/api/documents/application/{id}/documents-declaration")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
							Roles.ROLE_APPLICANT_E_SIGN.getName())

				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/check-all")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.PUT, "/api/documents/application/{id}/document/{typeId}/page-order")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/can-submit")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())
						
				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/document/{typeId}/page-order")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/desk-subject-face").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName())

				.mvcMatchers(HttpMethod.POST, "/api/documents/application/{id}/document/{typeId}/auto-fixed")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.POST, "/api/documents/application/{id}/document/{typeId}/auto-fixed/approver")
					.hasAnyAuthority(Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/document/{typeId}/auto-fixed")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_APPROVER.getName(), Roles.ROLE_VIEWER.getName())

				.mvcMatchers(HttpMethod.POST, "/api/documents/application/{id}/document/{typeId}/edited")
					.hasAnyAuthority(
						Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
							Roles.ROLE_APPROVER.getName(), Roles.ROLE_APPLICANT_E_SIGN.getName(),
								Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/document/{typeId}/edited")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_APPROVER.getName(), Roles.ROLE_VIEWER.getName())

				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/document/{typeId}/original")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(), 
							Roles.ROLE_APPROVER.getName(), Roles.ROLE_VIEWER.getName())

				.mvcMatchers(HttpMethod.GET, "/api/documents/application/{id}/document/{typeId}/auto-fixed-check")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_VIEWER.getName(), Roles.ROLE_APPROVER.getName())
				// APPLICATION
				.mvcMatchers(HttpMethod.GET, "/api/applications/created")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(),
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.POST, "/api/applications/check").permitAll()
										
				.mvcMatchers(HttpMethod.PUT, "/api/applications/{id}/verify-email").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_APPLICANT_E_SIGN.getName(), 
						Roles.ROLE_APPLICANT_E_FACE.getName())	

				.mvcMatchers(HttpMethod.POST, "/api/applications/{id}/card-renewal").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())
			
				.mvcMatchers(HttpMethod.PUT, "/api/applications/{id}/correspondence")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.GET, "/api/applications/{id}/card-check")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.GET, "/api/applications/{id}/approver/card-check")
					.hasAnyAuthority(Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.GET, "/api/applications/{id}/contact-details")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPROVER.getName(), 
							Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.PUT, "/api/applications/{id}/delivery")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.PUT, "/api/applications/{id}/cancel")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.DELETE, "/api/applications/{id}/delete")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName())

				.mvcMatchers(HttpMethod.PUT, "/api/applications/{id}/approve")
					.hasAnyAuthority(Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.PUT, "/api/applications/{id}/reject")
					.hasAnyAuthority(Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.PUT, "/api/applications/{id}/return")
					.hasAnyAuthority(Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.PUT, "/api/applications/{id}/deliver-client")
					.hasAnyAuthority(Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.PUT, "/api/applications/{id}/submit")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.PUT, "/api/applications/{id}/can-submit")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.POST, "/api/applications/{id}/milestone/{milestoneId}")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.GET, "/api/applications/{id}/pdf")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
							Roles.ROLE_APPLICANT_E_SIGN.getName())

				.mvcMatchers(HttpMethod.GET, "/api/applications/type/{id}/in-progress")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(), 
							Roles.ROLE_APPLICANT_E_SIGN.getName())					

				.mvcMatchers(HttpMethod.GET, "/api/applications/{id}/draft").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), Roles.ROLE_VIEWER.getName(),
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.GET, "/api/applications/{id}")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(), 
							Roles.ROLE_APPROVER.getName(), Roles.ROLE_PERSO_CENTER_DEMAX.getName())

				.mvcMatchers(HttpMethod.POST, "/api/applications/{id}/picture-transition").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())	

				.mvcMatchers(HttpMethod.POST, "/api/applications/{id}/remark")
					.hasAnyAuthority(Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.POST, "/api/applications").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.GET, "/api/applications").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), Roles.ROLE_APPROVER.getName(),
						Roles.ROLE_PERSO_CENTER_DEMAX.getName(), Roles.ROLE_VIEWER.getName())
				// DQC
				.mvcMatchers(HttpMethod.POST, "/api/dqc/application/{id}/certificate").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())	

				.mvcMatchers(HttpMethod.POST, "/api/dqc/application/{id}/all-certificates").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(), 
							Roles.ROLE_APPROVER.getName())	

				.mvcMatchers(HttpMethod.POST, "/api/dqc/application/{id}/all-cards").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(), 
							Roles.ROLE_APPROVER.getName())	

				.mvcMatchers(HttpMethod.GET, "/api/dqc/application/{id}/approver/certificates")
					.hasAnyAuthority(Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.GET, "/api/dqc/application/{id}/certificates").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_VIEWER.getName())		

				.mvcMatchers(HttpMethod.DELETE, "/api/dqc/application/{id}/certificate/{typeId}").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.POST, "/api/dqc/certificates/transition").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())	
				// ADR CARD
				.mvcMatchers(HttpMethod.GET, "/api/adr-cards/application/{id}/modules").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName())

				.mvcMatchers(HttpMethod.GET, "/api/adr-cards/application/{id}/approver/modules").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.POST, "/api/adr-cards/application/{id}/module").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())	
	
				.mvcMatchers(HttpMethod.DELETE, "/api/adr-cards/application/{id}/module/{typeId}").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.POST, "/api/adr-cards/application/{id}/modules/transition").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())
				// NOMENCLATURES
				.mvcMatchers(HttpMethod.GET, "/api/nomenclatures/admin-search").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_VIEWER.getName(), Roles.ROLE_APPROVER.getName(), 
						Roles.ROLE_DESK_STAFF.getName(), Roles.ROLE_PERSO_CENTER_DEMAX.getName())
				.mvcMatchers(HttpMethod.GET, "/api/nomenclatures/autocomplete**").permitAll()
				.mvcMatchers(HttpMethod.GET, "/api/nomenclatures/remarks").hasAnyAuthority(Roles.ROLE_APPROVER.getName())
				.mvcMatchers(HttpMethod.GET, "/api/nomenclatures/roles")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName())
				.mvcMatchers(HttpMethod.GET, "/api/nomenclatures/authentication-methods")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName())
				.mvcMatchers(HttpMethod.GET, "/api/nomenclatures/**").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_APPROVER.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())
				// DRIVING LICENCE
				.mvcMatchers(HttpMethod.POST, "/api/driving-licences").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName())

				.mvcMatchers(HttpMethod.POST, "/api/driving-licences/mvr-info").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName())

				.mvcMatchers(HttpMethod.POST, "/api/driving-licences/approver/mvr-info").hasAnyAuthority(
					Roles.ROLE_APPROVER.getName())
				// PAYMENTS
				.mvcMatchers(HttpMethod.GET, "/api/payments/application/{id}/taxes").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_VIEWER.getName(), Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.POST, "/api/payments/application/{id}").hasAnyAuthority(
					Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
						Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.GET, "/api/payments/application/{id}/payment-type/{typeId}")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_APPLICANT_E_SIGN.getName(), 
						Roles.ROLE_APPLICANT_E_FACE.getName(), Roles.ROLE_DESK_STAFF.getName(), 
						Roles.ROLE_VIEWER.getName(), Roles.ROLE_APPROVER.getName())

				.mvcMatchers(HttpMethod.GET, "/api/payments/application/{id}/document/{typeId}/pages-info")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_APPLICANT_E_SIGN.getName(), 
						Roles.ROLE_APPLICANT_E_FACE.getName(), Roles.ROLE_DESK_STAFF.getName(), 
							Roles.ROLE_VIEWER.getName(), Roles.ROLE_APPROVER.getName())
				
				.mvcMatchers(HttpMethod.GET, "/api/payments/application/{id}/invoice")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName(), Roles.ROLE_APPLICANT_E_SIGN.getName(), 
						Roles.ROLE_APPLICANT_E_FACE.getName(), Roles.ROLE_DESK_STAFF.getName(), 
							Roles.ROLE_VIEWER.getName(), Roles.ROLE_APPROVER.getName(), 
								Roles.ROLE_PERSO_CENTER_DEMAX.getName())
				// TRANSLATIONS
				.mvcMatchers(HttpMethod.GET, "/api/translations").hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName())
				.mvcMatchers(HttpMethod.POST, "/api/translations").hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName())
				.mvcMatchers(HttpMethod.PUT, "/api/translations").hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName())
				.mvcMatchers(HttpMethod.DELETE, "/api/translations/{key}").hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName())
				.mvcMatchers(HttpMethod.GET, "/api/translations/filter").hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName())
				
				// ADR EXAM
				.mvcMatchers(HttpMethod.GET, "/api/exam-applications/{id}/adr-exam-people")
					.hasAnyAuthority(Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
						Roles.ROLE_DESK_STAFF.getName())

				.mvcMatchers("/api/exam-applications/{id}/consultant-exam-learning-plans-for-extension")
					.hasAnyAuthority(Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_DESK_STAFF.getName())
					
				.mvcMatchers(HttpMethod.GET, "/api/exam-applications/{id}/adr-exam-protocols")
					.hasAnyAuthority(Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_DESK_STAFF.getName())

				.mvcMatchers(HttpMethod.POST, "/api/exam-applications/{id}/adr-exam-enrolment")
					.hasAnyAuthority(Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_DESK_STAFF.getName())

				.mvcMatchers(HttpMethod.POST, "/api/exam-applications/{id}/consultant-extension-exam-enrolment")
					.hasAnyAuthority(Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_DESK_STAFF.getName())
				
				.mvcMatchers("/api/exam-applications/{id}/consultant-exam-protocols")
					.hasAnyAuthority(Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_DESK_STAFF.getName())
					
				// MOTOR EXAM
				.mvcMatchers(HttpMethod.GET, "/api/exam-applications/{id}/motor-exam-people")
					.hasAnyAuthority(Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_DESK_STAFF.getName())

				.mvcMatchers(HttpMethod.GET, "/api/exam-applications/{id}/motor-exam-protocols")
					.hasAnyAuthority(Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_DESK_STAFF.getName())

				.mvcMatchers(HttpMethod.POST, "/api/exam-applications/{id}/motor-exam-enrolment")
					.hasAnyAuthority(Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_DESK_STAFF.getName())

				// TAXI EXAM
				.mvcMatchers(HttpMethod.GET, "/api/exam-applications/{id}/taxi-exam-protocols")
					.hasAnyAuthority(Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_DESK_STAFF.getName())
				
				.mvcMatchers(HttpMethod.POST, "/api/exam-applications/{id}/taxi-exam-enrolment")
					.hasAnyAuthority(Roles.ROLE_APPLICANT_E_SIGN.getName(), Roles.ROLE_APPLICANT_E_FACE.getName(),
							Roles.ROLE_DESK_STAFF.getName())
				// USERS
				.mvcMatchers(HttpMethod.GET, "/api/users/current")
					.authenticated()
					
				.mvcMatchers(HttpMethod.GET, "/api/users")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName())
				.mvcMatchers(HttpMethod.PUT, "/api/users/{id}/roles")
					.hasAnyAuthority(Roles.ROLE_ADMIN_DEMAX.getName())
					
				.anyRequest().authenticated();
	}
}
