package bg.demax.eservices.backend.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.eservices.backend.dto.AdrModuleDto;
import bg.demax.eservices.backend.service.AdrCardService;
import bg.demax.eservices.backend.service.IaaaGatewayService;

@RestController
@RequestMapping("/api/adr-cards")
public class AdrCardController {

	@Autowired
	private IaaaGatewayService proxyService;

	@Autowired
	private AdrCardService adrCardService;

	@GetMapping("/application/{id}/modules")
	public List<AdrModuleDto> getSubjectModulesFromRegister(@PathVariable("id") int applicationId) {
		return proxyService.getSubjectModulesFromRegister(applicationId);
	}

	@GetMapping("/application/{id}/approver/modules")
	public List<AdrModuleDto> getSubjectModulesForApprover(@PathVariable("id") int applicationId) {
		return proxyService.getSubjectModulesForApprover(applicationId);
	}

	@PostMapping("/application/{id}/module")
	public void saveModule(@PathVariable("id") int applicationId, @RequestBody @Valid AdrModuleDto dto) {
		adrCardService.saveModule(applicationId, dto);
	}

	@DeleteMapping("/application/{id}/module/{typeId}")
	public void deleteModule(@PathVariable("id") int applicationId, @PathVariable("typeId") int  moduleTypeId) {
		adrCardService.deleteModule(applicationId, moduleTypeId);
	}	

	@PostMapping("/application/{id}/modules/transition")
	public List<AdrModuleDto> saveTransitionForSelectedModules(@PathVariable("id") int applicationId) {
		return adrCardService.saveTransitionForSelectedModules(applicationId);
	}
}