package bg.demax.eservices.backend.controller;

import java.io.IOException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import bg.demax.eservices.backend.dto.ApplicantContactDetailsDto;
import bg.demax.eservices.backend.dto.ApplicationSearchParamsDto;
import bg.demax.eservices.backend.dto.ApplicationTypeIdDto;
import bg.demax.eservices.backend.dto.ChosenCorrespondenceDto;
import bg.demax.eservices.backend.dto.DeliveryInfoDto;
import bg.demax.eservices.backend.dto.EmailWrapperDto;
import bg.demax.eservices.backend.dto.PaginationQueryParamsDto;
import bg.demax.eservices.backend.dto.RemarkDto;
import bg.demax.eservices.backend.dto.captcha.ApplicationCheckParams;
import bg.demax.eservices.backend.dto.captcha.CaptchaResponse;
import bg.demax.eservices.backend.dto.card.CardDto;
import bg.demax.eservices.backend.dto.view.ApplicationDraftDto;
import bg.demax.eservices.backend.dto.view.ApplicationDto;
import bg.demax.eservices.backend.dto.view.ApplicationLightDto;
import bg.demax.eservices.backend.dto.view.ApplicationRemarkViewDto;
import bg.demax.eservices.backend.dto.view.ApplicationShortDto;
import bg.demax.eservices.backend.dto.view.CardViewDto;
import bg.demax.eservices.backend.dto.view.ContactViewDto;
import bg.demax.eservices.backend.dto.view.OldCardDto;
import bg.demax.eservices.backend.exception.ApplicationException;
import bg.demax.eservices.backend.exception.TachoNetApplicationException;
import bg.demax.eservices.backend.service.ApplicationProxyService;
import bg.demax.eservices.backend.service.ApplicationService;
import bg.demax.eservices.backend.service.ApproverService;
import bg.demax.eservices.backend.service.CaptchaService;
import bg.demax.eservices.backend.service.CardService;
import bg.demax.eservices.backend.service.CorrespondenceService;
import bg.demax.eservices.backend.service.fsm.TransitionService;
import bg.demax.hibernate.paging.PageResult;

@RestController
@RequestMapping("/api/applications")
public class ApplicationController {

	@Autowired
	private ApplicationService applicationService;

	@Autowired
	private ApplicationProxyService applicationProxyService;

	@Autowired
	private CorrespondenceService correspondenceService;

	@Autowired
	private CardService cardService;

	@Autowired
	private TransitionService transitionService;

	@Autowired
	private CaptchaService captchaService;

	@Autowired
	private ApproverService approverService;

	@PostMapping
	public Integer createNewApplication(@RequestBody @Valid ApplicationTypeIdDto applicationTypeIdWrapperDto) {
		return applicationService.startTheProcess(applicationTypeIdWrapperDto.getId());
	}

	@GetMapping
	public PageResult<ApplicationLightDto> findByPage(@Valid PaginationQueryParamsDto pageParams,
			@Valid ApplicationSearchParamsDto searchParams) {
		return applicationService.findPage(pageParams, searchParams);
	}

	@GetMapping("/{id}")
	public ApplicationDto getApplication(@PathVariable("id") int applicationId) {
		return applicationService.getApplicationDto(applicationId);
	}

	@GetMapping("/{id}/draft")
	public ApplicationDraftDto getApplicationDraft(@PathVariable("id") int applicationId) {
		return applicationService.getApplicationDraft(applicationId);
	}

	@GetMapping("/created")
	public List<ApplicationShortDto> getApplicationsByUser() {
		return applicationService.getApplicationsByUser();
	}

	// TODO : не се ползва на фронта - да се провери има ли нужда от него
	@PutMapping("/{id}/verify-email")
	public void verifyEmail(@PathVariable("id") int applicationId, @RequestBody @Valid EmailWrapperDto dto) {
		applicationService.verifyEmail(applicationId, dto);
	}

	@GetMapping("/{id}/contact-details")
	public ApplicantContactDetailsDto getApplicantContactDetails(@PathVariable("id") int applicationId) {
		return correspondenceService.getApplicantContactDetails(applicationId);
	}

	@PutMapping("/{id}/correspondence")
	public ContactViewDto setCorrespondenceContact(@PathVariable("id") int applicationId,
		@RequestBody @Valid ChosenCorrespondenceDto correspondenceDto) {
		return correspondenceService.setCorrespondenceContact(applicationId, correspondenceDto);
	}

	@GetMapping("/{id}/card-check")
	public OldCardDto getCardInfoFromService(@PathVariable("id") int applicationId)
		throws JsonParseException, JsonMappingException, IOException {
		return cardService.getCardInfoFromService(applicationId);
	}

	@GetMapping("/{id}/approver/card-check")
	public OldCardDto getCardInfoFromServiceForApprover(@PathVariable("id") int applicationId)
		throws JsonParseException, JsonMappingException, IOException, TachoNetApplicationException {
		return cardService.getCardInfoFromServiceForApprover(applicationId);
	}

	@PostMapping("/{id}/card-renewal")
	public CardViewDto saveCardRenewalInfo(@PathVariable("id") int applicationId, @RequestBody @Valid CardDto dto) {
		return cardService.saveCardRenewalInfo(applicationId, dto);
	}

	@PutMapping("/{id}/delivery")
	public DeliveryInfoDto saveDeliveryInfo(@PathVariable("id") int applicationId, 
			@RequestBody @Valid DeliveryInfoDto deliveryInfoDto) {
		return applicationService.saveDeliveryInfo(applicationId, deliveryInfoDto);
	}

	@GetMapping("/type/{applicationTypeId}/in-progress")
	public boolean checkIfApplicationOfSameTypeAlreadyInProgress(@PathVariable("applicationTypeId") int applicationTypeId) {
		return applicationService.checkIfApplicationOfSameTypeAlreadyInProgress(applicationTypeId);
	}

	@PutMapping("/{id}/cancel")
	public void cancelApplication(@PathVariable("id") int applicationId) {
		applicationProxyService.cancelApplication(applicationId);
	}

	@DeleteMapping("/{id}/delete")
	public void deleteApplication(@PathVariable("id") int applicationId) {
		applicationService.deleteApplication(applicationId);
	}

	@PutMapping("/{id}/submit")
	public void submitApplication(@PathVariable("id") int applicationId) {
		applicationProxyService.submitApplication(applicationId);
	}

	@PutMapping("/{id}/approve")
	public void approveApplication(@PathVariable("id") int applicationId) {
		approverService.processApplicationApproval(applicationId);
	}

	@PutMapping("/{id}/reject")
	public void rejectApplication(@PathVariable("id") int applicationId) {
		applicationService.rejectApplication(applicationId);
	}

	@PutMapping("/{id}/return")
	public void returnApplication(@PathVariable("id") int applicationId) {
		applicationService.returnApplication(applicationId);
	}

	@PutMapping("/{id}/deliver-client")
	public void deliverPersonallyCardApplication(@PathVariable("id") int applicationId) {
		applicationService.deliverPersonallyCardApplication(applicationId);
	}

	@PostMapping("/{id}/remark")
	public List<ApplicationRemarkViewDto> addRemark(@PathVariable("id") int applicationId, @RequestBody RemarkDto remarkDto) {
		return applicationService.addRemarkFromDto(applicationId, remarkDto);
	}

	@PostMapping("/{id}/milestone/{milestoneId}")
	public void setToMilestone(@PathVariable("id") int applicationId, @PathVariable("milestoneId") int milestoneId) {
		transitionService.setApplicationProcessToMilestoneStatus(applicationId, milestoneId);
	}

	@PostMapping("/check")
	public ApplicationShortDto checkApplicationStatus(@RequestBody @Valid ApplicationCheckParams params) {
		CaptchaResponse captchaResponse = captchaService.validateRecaptcha(params.getReCaptchaResponse());
		if (captchaResponse.getSuccess().equals(Boolean.FALSE)) {
			throw new ApplicationException("Captcha validation failed.", captchaResponse.getErrorCodes());
		}
		return applicationService.getApplicationShortDtoByApplicationId(params.getApplicationId());
	}

}