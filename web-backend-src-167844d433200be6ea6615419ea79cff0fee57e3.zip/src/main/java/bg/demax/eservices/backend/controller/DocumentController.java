package bg.demax.eservices.backend.controller;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Set;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.itextpdf.text.DocumentException;

import bg.demax.eservices.backend.dto.ApplicationIdWrapperDto;
import bg.demax.eservices.backend.dto.DocumentsDeclarationDto;
import bg.demax.eservices.backend.dto.nomenclature.RequiredDocumentTypeDto;
import bg.demax.eservices.backend.dto.view.AttachedDocumentShortInfoDto;
import bg.demax.eservices.backend.service.attachment.AttachedDocumentService;
import bg.demax.eservices.backend.service.attachment.DocumentService;

@RestController
@RequestMapping("/api/documents")
public class DocumentController {
	
	@Autowired
	private DocumentService documentService;

	@Autowired
	private AttachedDocumentService attachedDocumentService;
	
	@GetMapping(path = "/application/{id}/pdf", produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Resource> getGeneratedCardPdfApplication(@PathVariable("id") int applicationId)
		throws IOException, NoSuchAlgorithmException, DocumentException {
		return documentService.getGeneratedCardPdfApplication(applicationId);
	}

	@GetMapping("/application/{id}/required-documents")
	public Set<RequiredDocumentTypeDto> getRequiredDocumentsForSection(@PathVariable("id") int applicationId) {
		return documentService.getRequiredDocumentsForSection(applicationId);
	}
	
	@GetMapping("/application/{id}/required-documents-attached")
	public boolean checkAllRequiredDocumentsAreAttached(@PathVariable("id") int applicationId) {
		return documentService.checkAllDocumentsAreAttached(applicationId);
	}

	@GetMapping("/application/{id}/milestone/{milestoneId}/required-documents")
	public List<Integer> getRequiredDocumentsForDefinedSection(
		@PathVariable("id") int applicationId, @PathVariable("milestoneId") int milestoneId) {
		return documentService.getRequiredDocumentsForDefinedSection(applicationId, milestoneId);
	}

	@PutMapping("/confirm-attached-documents")
	public void confirmAttachedDocuments(@RequestBody ApplicationIdWrapperDto applicationIdDto) {
		documentService.confirmAttachedDocuments(applicationIdDto.getId());
	}

	@PostMapping(path = "/application/{id}/document/{typeId}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public Integer saveUploadedDocumentPage(
		@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId,
		@NotNull @RequestPart("file") MultipartFile file) throws NoSuchAlgorithmException, IOException {
		return documentService.saveUploadedDocumentPage(applicationId, documentTypeId, file);
	}

	@PostMapping(path = "/application/{id}/document/{typeId}/auto-fixed",
		consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Resource> saveOriginalFaceOrSignatureAndGetAutoFixedPicture(
		@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId,
		@NotNull @RequestPart("file") MultipartFile file)
		throws NoSuchAlgorithmException, IOException, DocumentException {
		return documentService.saveOriginalFaceOrSignatureAndGetAutoFixedPicture(applicationId, documentTypeId, file);
	}

	@PostMapping(path = "/application/{id}/document/{typeId}/edited", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public Integer saveEditedPicture(
		@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId,
		@NotNull @RequestParam("autoFixed") boolean isAutoFixed,
		@NotNull @RequestPart("file") MultipartFile file)
		throws NoSuchAlgorithmException, IOException, DocumentException {
		return documentService.saveEditedPicture(applicationId, documentTypeId, file, isAutoFixed);
	}

	@GetMapping(path = "/application/{id}/document/{typeId}/edited", produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Resource> getEditedPictureOfFaceOrSignature(
		@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId)
		throws NoSuchAlgorithmException, IOException, DocumentException {
		return documentService.getEditedPictureOfFaceOrSignature(applicationId, documentTypeId);
	}

	@GetMapping(path = "/application/{id}/document/{typeId}/auto-fixed", produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Resource> getAutoFixedFaceOrSignature(
		@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId)
		throws NoSuchAlgorithmException, IOException, DocumentException {
		return documentService.getAutoFixedFaceOrSignature(applicationId, documentTypeId);
	}

	@PostMapping(path = "/application/{id}/document/{typeId}/auto-fixed/approver", 
		consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Resource> getAutoFixedPictureFromMvrCheck(
		@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId,
		@NotNull @RequestPart("file") MultipartFile file) throws IOException {
		return documentService.getAutoFixedPictureFromMvrCheck(applicationId, documentTypeId, file);
	}

	@GetMapping(path = "/application/{id}/document/{typeId}/original", produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Resource> getOriginalPictureOfFaceOrSignature(
		@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId)
		throws NoSuchAlgorithmException, IOException, DocumentException {
		return documentService.getOriginalPictureOfFaceOrSignature(applicationId, documentTypeId);
	}

	@GetMapping(path = "/application/{id}/document/{typeId}", produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Resource> getDocument(@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId)
		throws IOException, NoSuchAlgorithmException, DocumentException {
		return documentService.getDocument(applicationId, documentTypeId);
	}

	@DeleteMapping(path = "/application/{id}/document/{typeId}")
	public void deleteUploadedDocument(@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId) {
		documentService.deleteUploadedDocument(applicationId, documentTypeId);
	}

	@GetMapping(path = "/application/{id}/document/{typeId}/page/{pageId}", produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Resource> getDocumentPage(
		@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId, @PathVariable("pageId") int pageId)
			throws IOException, NoSuchAlgorithmException, DocumentException {
		return documentService.getDocumentPage(applicationId, documentTypeId, pageId);
	}

	@DeleteMapping(path = "/application/{id}/document/{typeId}/page/{pageId}")
	public void deleteUploadedDocumentPage(
		@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId, @PathVariable("pageId") int pageId) {
		documentService.deleteUploadedDocumentPage(applicationId, documentTypeId, pageId);
	}

	@GetMapping(path = "/application/{id}/document/{typeId}/pages-info")	
	public AttachedDocumentShortInfoDto getDocumentPagesInfo(
		@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId)
			throws IOException, NoSuchAlgorithmException, DocumentException {
		return documentService.getDocumentPagesInfo(applicationId, documentTypeId);
	}
 
	@GetMapping(path = "/application/{id}/document/{typeId}/check")
	public boolean checkIfDocumentIsAlreadyUploaded(
		@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId) throws IOException {
		return documentService.checkIfDocumentIsAlreadyUploaded(applicationId, documentTypeId);
	}

	@PutMapping(path = "/application/{id}/documents-declaration")
	public void declareDocument(@PathVariable("id") int applicationId, @Valid @RequestBody DocumentsDeclarationDto dto) {
		documentService.declareDocuments(applicationId, dto);
	}

	@GetMapping(path = "/application/{id}/check-all")
	public boolean checkIfAllRequiredDocumentsAreAttached(@PathVariable("id") int applicationId) throws IOException {
		return attachedDocumentService.checkIfAllRequiredDocumentsAreAttached(applicationId);
	}

	@GetMapping("/application/{id}/can-submit")
	public boolean checkIfCanContinueToSubmitApplication(@PathVariable("id") int applicationId) {
		return documentService.checkIfCanContinueToSubmitApplication(applicationId);
	}

	@PutMapping("/application/{id}/document/{typeId}/page-order")
	public void setDocumentPagesOrder(@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId,
		@NotEmpty @RequestBody List<Integer> pageIdsOrderedByPageNumber) {
		documentService.setDocumentPagesOrder(applicationId, documentTypeId, pageIdsOrderedByPageNumber);
	}

	@GetMapping(path = "/application/{id}/desk-subject-face", produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Resource> getPictureOfUserOnDesk(@PathVariable("id") int applicationId)
		throws IOException, NoSuchAlgorithmException, DocumentException {
		return documentService.getPictureOfUserOnDesk(applicationId);
	}

	@GetMapping("/application/{id}/document/{typeId}/auto-fixed-check")
	public boolean checkIsPictureAutoFixed(@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId)
		throws IOException, NoSuchAlgorithmException, DocumentException {
		return documentService.checkIsPictureAutoFixed(applicationId, documentTypeId);
	}
}