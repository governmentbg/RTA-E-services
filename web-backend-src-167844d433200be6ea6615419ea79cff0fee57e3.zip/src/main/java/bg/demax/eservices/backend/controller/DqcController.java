package bg.demax.eservices.backend.controller;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.eservices.backend.dto.ApplicationIdWrapperDto;
import bg.demax.eservices.backend.dto.CertificateDto;
import bg.demax.eservices.backend.dto.proxy.dqc.OldDqcCardDto;
import bg.demax.eservices.backend.dto.proxy.dqc.SimpleDqcCertDto;
import bg.demax.eservices.backend.service.CardService;
import bg.demax.eservices.backend.service.DqcService;
import bg.demax.eservices.backend.service.IaaaGatewayService;

@RestController
@RequestMapping("/api/dqc")
public class DqcController {

	@Autowired
	private IaaaGatewayService iaaaGatewayService;

	@Autowired
	private DqcService dqcService;

	@Autowired
	private CardService cardService;

	@GetMapping("/application/{id}/certificates")
	public Set<CertificateDto> getCertificates(@PathVariable("id") int applicationId)
			throws JsonParseException, JsonMappingException, IOException {
		return iaaaGatewayService.getSubjectDqcCertificates(applicationId);
	}

	@GetMapping("/application/{id}/approver/certificates")
	public List<CertificateDto> getCertificatesForApprover(@PathVariable("id") int applicationId) {
		return iaaaGatewayService.getCertificatesForApprover(applicationId);
	}

	@GetMapping("/application/{id}/all-certificates")
	public Set<SimpleDqcCertDto> getAllCertificates(@PathVariable("id") int applicationId)
			throws JsonParseException, JsonMappingException, IOException {
		return iaaaGatewayService.getAllCertificatesForPreview(applicationId);
	}

	@GetMapping("/application/{id}/all-cards")
	public List<OldDqcCardDto> getAllDqcCards(@PathVariable("id") int applicationId)
			throws JsonParseException, JsonMappingException, IOException {
		return cardService.getAllOldDqcCardsFromService(applicationId);
	}

	@PostMapping("/application/{id}/certificate")
	public void saveCertificate(@PathVariable("id") int applicationId, @RequestBody @Valid CertificateDto certificateDto) {
		dqcService.saveCertificate(applicationId, certificateDto);
	}

	@DeleteMapping("/application/{id}/certificate/{typeId}")
	public void deleteCertificateAndAttachedDocuments(@PathVariable("id") int applicationId, 
		@PathVariable("typeId") int certificateTypeId) {
		dqcService.deleteCertificateAndCertificateAttachedDocumentsIfExists(applicationId, certificateTypeId);
	}

	@PostMapping("/certificates/transition")
	public List<CertificateDto> saveTransitionForSelectedCertificates(@RequestBody ApplicationIdWrapperDto applicationIdDto) {
		return dqcService.saveTransitionForSelectedCertificates(applicationIdDto.getId());
	}
}
