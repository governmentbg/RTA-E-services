package bg.demax.eservices.backend.controller;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.eservices.backend.dto.DrivingLicenceDto;
import bg.demax.eservices.backend.dto.proxy.regix.mvr.RequestMvrDto;
import bg.demax.eservices.backend.dto.view.DrivingLicenceViewDto;
import bg.demax.eservices.backend.service.DrivingLicenceService;
import bg.demax.eservices.backend.service.ProxyService;

@RestController
@RequestMapping("/api/driving-licences")
public class DrivingLicenceController {

	@Autowired
	private ProxyService proxyService;

	@Autowired
	private DrivingLicenceService drivingLicenceService;

	@PostMapping("/mvr-info")
	public DrivingLicenceViewDto getMvrDLInfo(@RequestBody @Valid RequestMvrDto requestInfo) 
		throws NoSuchAlgorithmException, IOException, Exception {
		return proxyService.getSubjectMvrDLInfo(requestInfo);
	}

	@PostMapping("/approver/mvr-info")
	public DrivingLicenceViewDto getMvrDLInfoForApprover(@RequestBody @Valid RequestMvrDto requestInfo) 
		throws NoSuchAlgorithmException, IOException, Exception {
		return proxyService.getSubjectMvrDLInfoForApprover(requestInfo);
	}

	@PostMapping
	public DrivingLicenceViewDto saveDrivingLicenceInfo(@RequestBody @Valid DrivingLicenceDto drivingLicenceDto) {
		return drivingLicenceService.saveDrivingLicenceInfoManually(drivingLicenceDto);
	}
}
