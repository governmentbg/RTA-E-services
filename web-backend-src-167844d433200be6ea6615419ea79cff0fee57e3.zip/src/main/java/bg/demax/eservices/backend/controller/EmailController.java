package bg.demax.eservices.backend.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.eservices.backend.dto.EmailWrapperDto;
import bg.demax.eservices.backend.dto.VerificationTokenWrapperDto;
import bg.demax.eservices.backend.service.EmailService;

@RestController
@RequestMapping("/api/emails")
public class EmailController {
	@Autowired
	private EmailService emailService;
	
	@PostMapping("/token")
	public void sendVerificationCodeToEmail(@RequestBody @Valid EmailWrapperDto dto) {
		emailService.sendVerificationCode(dto.getEmail());
	}
	
	@PutMapping("/verify")
	public void updateUserVerificationStatus(@RequestBody @Valid VerificationTokenWrapperDto dto) {
		emailService.verifyEmail(dto.getVerificationToken());
	}
	
	@GetMapping("/current")
	public String getCurrentUserEmail() {
		return emailService.getCurrentUserEmail();
	}
}
