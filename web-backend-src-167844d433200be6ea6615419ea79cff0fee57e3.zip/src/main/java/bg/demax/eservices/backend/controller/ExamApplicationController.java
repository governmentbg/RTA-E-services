package bg.demax.eservices.backend.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.eservices.backend.controller.param.AdrExamProtocolSelectionQueryParams;
import bg.demax.eservices.backend.controller.param.MotorExamPeopleQueryParams;
import bg.demax.eservices.backend.controller.param.MotorExamProtocolSelectionQueryParams;
import bg.demax.eservices.backend.controller.param.TaxiExamProtocolSelectionQueryParams;
import bg.demax.eservices.backend.dto.exam.AdrConsultantExtensionExamEnrolmentRequestDto;
import bg.demax.eservices.backend.dto.exam.AdrExamPersonSelectionDto;
import bg.demax.eservices.backend.dto.exam.AdrExamProtocolsResponseDto;
import bg.demax.eservices.backend.dto.exam.MotorExamEnrolmentRequestDto;
import bg.demax.eservices.backend.dto.exam.MotorExamPersonSelectionDto;
import bg.demax.eservices.backend.dto.exam.MotorExamProtocolsResponseDto;
import bg.demax.eservices.backend.dto.exam.TaxiExamEnrolmentRequestDto;
import bg.demax.eservices.backend.http.dto.adr.AdrExamEnrolmentRequestDto;
import bg.demax.eservices.backend.http.dto.adr.ConsultantExamLearningPlanSelectionDto;
import bg.demax.eservices.backend.service.ExamApplicationProxyService;

@RestController
@RequestMapping("/api/exam-applications")
public class ExamApplicationController {

	@Autowired
	private ExamApplicationProxyService examApplicationProxyService;

	@GetMapping("/{id}/adr-exam-people")
	public List<AdrExamPersonSelectionDto> getAdrExamPeopleForSelection(@PathVariable("id") int adrExamApplicationId) {
		return examApplicationProxyService.getAdrExamPeopleForSelection(adrExamApplicationId);
	}

	@GetMapping("/{id}/consultant-exam-learning-plans-for-extension")
	public List<ConsultantExamLearningPlanSelectionDto> getConsultantExamLearningPlansForExtension(
			@PathVariable("id") int consultantExamApplicationId) {
		return examApplicationProxyService.getConsultantExamLearningPlansForExtension(consultantExamApplicationId);
	}
	
	@GetMapping("/{id}/adr-exam-protocols")
	public AdrExamProtocolsResponseDto getAdrExamProtocolsForSelection(@PathVariable("id") int adrExamApplicationId, 
			@Valid AdrExamProtocolSelectionQueryParams queryParams) {
		return examApplicationProxyService.getAdrExamProtocolsForSelection(adrExamApplicationId, queryParams);
	}

	@GetMapping("/{id}/consultant-exam-protocols")
	public AdrExamProtocolsResponseDto getConsultantExamProtocolsForSelection(
			@PathVariable("id") int consultantExamApplicationId) {
		return examApplicationProxyService.getConsultantExamProtocolsForSelection(consultantExamApplicationId);
	}

	@PostMapping("/{id}/adr-exam-enrolment")
	public void enrolForAdrExam(@PathVariable("id") int adrExamApplicationId, 
			@Valid @RequestBody AdrExamEnrolmentRequestDto requestDto) {
		examApplicationProxyService.enrolForAdrExam(adrExamApplicationId, requestDto);
	}
	
	@PostMapping("/{id}/consultant-extension-exam-enrolment")
	public void enrolForAdrConsultantExtensionExam(@PathVariable("id") int consultantExamApplicationId, 
			@Valid @RequestBody AdrConsultantExtensionExamEnrolmentRequestDto requestDto) {
		examApplicationProxyService.enrolForAdrConsultantExtensionExam(consultantExamApplicationId, requestDto);
	}

	@GetMapping("/{id}/motor-exam-people")
	public List<MotorExamPersonSelectionDto> getMotorExamPeopleForSelection(
			@PathVariable("id") int motorExamApplicationId,
			@Valid MotorExamPeopleQueryParams params) {
		return examApplicationProxyService.getMotorExamPeopleForSelection(motorExamApplicationId, params);
	}

	@GetMapping("/{id}/motor-exam-protocols")
	public MotorExamProtocolsResponseDto getMotorExamProtocolsForSelection(@PathVariable("id") int motorExamApplicationId, 
			@Valid MotorExamProtocolSelectionQueryParams queryParams) {
		return examApplicationProxyService.getMotorExamProtocolsForSelection(motorExamApplicationId, queryParams);
	}

	@PostMapping("/{id}/motor-exam-enrolment")
	public void enrolForMotorExam(@PathVariable("id") int motorExamApplicationId,
			@Valid @RequestBody MotorExamEnrolmentRequestDto requestDto) {
		examApplicationProxyService.enrolForMotorExam(motorExamApplicationId, requestDto);
	}

	@GetMapping("/{id}/taxi-exam-protocols")
	public MotorExamProtocolsResponseDto getTaxiExamProtocols(@PathVariable("id") int taxiExamApplicationId,
			@Valid TaxiExamProtocolSelectionQueryParams queryParams) {
		return examApplicationProxyService.getTaxiExamProtocols(taxiExamApplicationId, queryParams);
	}

	@PostMapping("/{id}/taxi-exam-enrolment")
	public void getTaxiExamEnrolment(@PathVariable("id") int taxiExamApplicationId,
			@Valid @RequestBody TaxiExamEnrolmentRequestDto requestDto) {
		examApplicationProxyService.enrolForTaxiExam(taxiExamApplicationId, requestDto);
	}
}
