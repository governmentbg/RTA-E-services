package bg.demax.eservices.backend.controller;

import java.util.Collections;

import javax.servlet.http.HttpServletRequest;

import org.apache.tomcat.util.http.fileupload.FileUploadBase.FileSizeLimitExceededException;
import org.apache.tomcat.util.http.fileupload.FileUploadBase.SizeLimitExceededException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import bg.demax.eservices.backend.dto.exception.ApplicationExceptionDto;
import bg.demax.eservices.backend.dto.exception.FileSizeLimitExceededExceptionDto;
import bg.demax.eservices.backend.dto.exception.SizeLimitExceededExceptionDto;
import bg.demax.eservices.backend.dto.proxy.regix.mvr.InvalidDocumentFromMvrDto;
import bg.demax.eservices.backend.exception.ApplicationException;
import bg.demax.eservices.backend.exception.NoSuchEntityException;
import bg.demax.eservices.backend.exception.UserAccessDeniedException;
import bg.demax.eservices.backend.exception.proxy.InvalidDocumentFromMvrException;

@RestControllerAdvice
public class GlobalControllerAdvice extends ResponseEntityExceptionHandler {
	private static final Logger logger = LogManager.getLogger();

	@ExceptionHandler(ApplicationException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public ApplicationExceptionDto handleApplicationException(ApplicationException ex, HttpServletRequest request) {
		return convertException(ex, request);
	}

	@ExceptionHandler(ConstraintViolationException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ApplicationExceptionDto handleConstraintViolationException(ConstraintViolationException ex,
			HttpServletRequest request) {
		return convertException(ex, request);
	}

	@ExceptionHandler(MaxUploadSizeExceededException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ApplicationExceptionDto handleMaxUploadSizeExceededException(MaxUploadSizeExceededException ex, HttpServletRequest request) {
		setResponseTypeToJson(request);
		ApplicationExceptionDto dto;
		if (ex.getRootCause() instanceof SizeLimitExceededException) {
			SizeLimitExceededException rootCause = (SizeLimitExceededException) ex.getRootCause();
			dto = new SizeLimitExceededExceptionDto(rootCause.getPermittedSize());
		} else if (ex.getRootCause() instanceof FileSizeLimitExceededException) {
			FileSizeLimitExceededException rootCause = (FileSizeLimitExceededException) ex.getRootCause();
			dto = new FileSizeLimitExceededExceptionDto(rootCause.getPermittedSize());
		} else {
			return convertException(ex, request);
		}
		return dto;
	}

	@ExceptionHandler(NoSuchEntityException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ApplicationExceptionDto handleNoSuchEntityException(NoSuchEntityException ex, HttpServletRequest request) {
		return convertException(ex, request);
	}
	
	@ExceptionHandler(UserAccessDeniedException.class)
	@ResponseStatus(HttpStatus.FORBIDDEN)
	public ApplicationExceptionDto handleUserAccessDeniedException(UserAccessDeniedException ex, HttpServletRequest request) {
		return convertException(ex, request);
	}

	@ExceptionHandler
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ApplicationExceptionDto handleUnhandledExceptions(Exception ex, HttpServletRequest request) {
		if (!ex.getClass().getCanonicalName().equals("org.apache.catalina.connector.ClientAbortException")) {
			logger.error("Caught unhandled exception: ", ex);
		}
		setResponseTypeToJson(request);
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError("Exception");
		return dto;
	}

	@ExceptionHandler(InvalidDocumentFromMvrException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public InvalidDocumentFromMvrDto handleInvalidDocumentFromMvrException(InvalidDocumentFromMvrException ex, HttpServletRequest request) {
		setResponseTypeToJson(request);
		InvalidDocumentFromMvrDto dto = new InvalidDocumentFromMvrDto(ex.getError(), ex.getStatus(), ex.getDate(), ex.getStatusReason());
		return dto;
	}

	private ApplicationExceptionDto convertException(RuntimeException ex, HttpServletRequest request) {
		setResponseTypeToJson(request);
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError(ex.getClass().getSimpleName());
		String message = ex.getMessage();
		dto.setMessage(message);
		return dto;
	}

	private void setResponseTypeToJson(HttpServletRequest request) {
		request.setAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE,
				Collections.singleton(MediaType.APPLICATION_JSON));
	}
}
