package bg.demax.eservices.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.eservices.backend.dto.RoleDto;
import bg.demax.eservices.backend.dto.nomenclature.AdminSearchNomenclaturesDto;
import bg.demax.eservices.backend.dto.nomenclature.CityDto;
import bg.demax.eservices.backend.dto.nomenclature.CountryCodeDto;
import bg.demax.eservices.backend.dto.nomenclature.CountryDto;
import bg.demax.eservices.backend.dto.nomenclature.DqcCertificateNomenclaturesDto;
import bg.demax.eservices.backend.dto.nomenclature.MunicipalityDto;
import bg.demax.eservices.backend.dto.nomenclature.OrgUnitDto;
import bg.demax.eservices.backend.dto.nomenclature.RegionDto;
import bg.demax.eservices.backend.dto.nomenclature.RequiredDocumentTypeDto;
import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.dto.view.CategoryDto;
import bg.demax.eservices.backend.service.NomenclatureService;

@RestController
@RequestMapping("/api/nomenclatures")
public class NomenclatureController {
	@Autowired
	private NomenclatureService nomenclatureService;
	
	@GetMapping("/regions")
	public List<RegionDto> getAllRegions() {
		return nomenclatureService.getAllRegions();
	}
		
	@GetMapping("/{regCode}/municipalities")
	public List<MunicipalityDto> getMunicipalitiesByRegion(@PathVariable("regCode") String regionCode) {
		return nomenclatureService.getMunicipalitiesByRegion(regionCode);
	}

	@GetMapping("/{regCode}/cities")
	public List<CityDto> getCitiesByRegion(@PathVariable("regCode") String regionCode) {
		return nomenclatureService.getCitiesByRegion(regionCode);
	}

	@GetMapping("/countries")
	public List<CountryDto> getAllCountries() {
		return nomenclatureService.getAllCountries();
	}
	
	@GetMapping("/country-codes")
	public List<CountryCodeDto> getAllCountryCodes() {
		return nomenclatureService.getAllCountryCodes();
	}

	@GetMapping("/countries/{name}")
	public TranslationDto getCountryByName(@PathVariable("name") String countryName) {
		return nomenclatureService.getCountryByName(countryName);
	}

	@GetMapping(value = "/application-types/{id}", produces = "text/plain")
	public String getApplicationTypeDescriptionKeyById(@PathVariable("id") int typeId) {
		return nomenclatureService.getApplicationTypeDescriptionKeyById(typeId);
	}

	@GetMapping("/org-units")
	public List<OrgUnitDto> getAllOrgUnits() {
		return nomenclatureService.getAllOrgUnits();
	}

	@GetMapping("/required-document-types")
	public List<RequiredDocumentTypeDto> getAllRequiredDocumentTypes() {
		return nomenclatureService.getAllRequiredDocumentTypes();
	}
	
	@GetMapping("/identity-document-types")
	public List<TranslationDto> getAllIdentityDocumentTypes() {
		return nomenclatureService.getAllIdentityDocumentTypes();
	}

	@GetMapping("/identity-document-issuers")
	public List<TranslationDto> getAllIdentityDocumentIssuers() {
		return nomenclatureService.getAllIdentityDocumentIssuers();
	}

	@GetMapping("/dqc-certificate-nomenclatures")
	public DqcCertificateNomenclaturesDto getDqcCertificateNomenclatures() {
		return nomenclatureService.getDqcCertificateNomenclatures();
	}

	@GetMapping("/adr-module-types")
	public List<TranslationDto> getAdrModuleTypes() {
		return nomenclatureService.getAdrModuleTypes();
	}

	@GetMapping("/categories")
	public List<CategoryDto> getAllCategories() {
		return nomenclatureService.getAllCategories();
	}
	
	@GetMapping("/card-issuing-reasons")
	public List<TranslationDto> getAllCardIssuingReasons() {
		return nomenclatureService.getAllCardIssuingReasons();
	}

	@GetMapping("/admin-search")
	public AdminSearchNomenclaturesDto getAllAdminSearchNomenclatures() {
		return nomenclatureService.getAllAdminSearchNomenclatures();
	}

	@GetMapping("/remarks")
	public List<TranslationDto> getAllRemarksForApplicationType(@RequestParam("applicationId") int applicationId) {
		return nomenclatureService.getAllRemarksForApplicationType(applicationId);
	}

	@GetMapping("/autocomplete/countries")
	public List<TranslationDto> getCountriesByAutocompletePhrase(@RequestParam("phrase") String phrase, 
			@RequestParam("lang") String lang) {
		return nomenclatureService.getCountriesByAutocompletePhrase(phrase, lang);
	}

	@GetMapping("/autocomplete/issuers")
	public List<TranslationDto> getIssuersByAutocompletePhrase(@RequestParam("phrase") String phrase,
		@RequestParam("lang") String lang) {
		return nomenclatureService.getIssuersByAutocompletePhrase(phrase, lang);
	}

	@GetMapping("/autocomplete/regions")
	public List<RegionDto> getRegionsByAutocompletePhrase(@RequestParam("phrase") String phrase, @RequestParam("lang") String lang) {
		return nomenclatureService.getRegionsByAutocompletePhrase(phrase, lang);
	}

	@GetMapping("/autocomplete/{regionCode}/municipality")
	public List<MunicipalityDto> getMunByAutocompletePhrase(
		@PathVariable("regionCode") String regionCode, @RequestParam("phrase") String phrase, @RequestParam("lang") String lang) {
		return nomenclatureService.getMunByAutocompletePhrase(phrase, lang, regionCode);
	}

	@GetMapping("/autocomplete/{regionCode}/cities")
	public List<CityDto> getCitiesByAutocompletePhrase(
		@PathVariable("regionCode") String regionCode, @RequestParam("phrase") String phrase, @RequestParam("lang") String lang) {
		return nomenclatureService.getCitiesByAutocompletePhrase(phrase, lang, regionCode);
	}

	@GetMapping("/autocomplete/document-types")
	public List<TranslationDto> getDocumentTypesAutocompletePhrase(@RequestParam("phrase") String phrase, 
		@RequestParam("lang") String lang) {
		return nomenclatureService.getDocumentTypesAutocompletePhrase(phrase, lang);
	}

	@GetMapping("/genders")
	public List<TranslationDto> getAllGenders() {
		return nomenclatureService.getAllGenders();
	}

	@GetMapping("/roles")
	public List<RoleDto> getAllRoles() {
		return nomenclatureService.getAllRoles();
	}

	@GetMapping("/authentication-methods")
	public List<TranslationDto> getAllAuthenticationMethods() {
		return nomenclatureService.getAllAuthenticationMethods();
	}
}
