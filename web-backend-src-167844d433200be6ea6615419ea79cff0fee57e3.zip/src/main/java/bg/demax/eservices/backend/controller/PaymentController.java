package bg.demax.eservices.backend.controller;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import bg.demax.eservices.backend.dto.PaymentDto;
import bg.demax.eservices.backend.dto.view.DocumentPageInfoDto;
import bg.demax.eservices.backend.dto.view.PaymentTaxesViewDto;
import bg.demax.eservices.backend.service.payment.PaymentProxyService;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

	@Autowired
	private PaymentProxyService paymentProxyService;

	@GetMapping("/application/{id}/taxes")
	public PaymentTaxesViewDto getApplicationTaxes(@PathVariable("id") int applicationId) {
		return paymentProxyService.getApplicationTaxes(applicationId);
	}

	@PostMapping("/application/{id}")
	public void createPaymentForApplication(@PathVariable("id") int applicationId, @RequestBody @Valid PaymentDto dto) 
		throws IOException {
		paymentProxyService.createPaymentForApplication(applicationId, dto);
	}

	@GetMapping(path = "/application/{id}/payment-type/{typeId}", produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Resource> getGeneratedPaymentOrderForApplicationByPaymentType(@PathVariable("id") int applicationId,
			@PathVariable("typeId") int paymentTypeId) throws IOException {
		return paymentProxyService.getGeneratedPaymentOrderForApplicationByPaymentType(applicationId, paymentTypeId);
	}

	@GetMapping(path = "/application/{id}/document/{typeId}/pages-info")	
	public List<DocumentPageInfoDto> getPaymentDocumentPagesInfo(
		@PathVariable("id") int applicationId, @PathVariable("typeId") int documentTypeId) {
		return paymentProxyService.getPaymentDocumentPagesInfo(applicationId, documentTypeId);
	}

	@GetMapping(path = "/application/{id}/invoice", produces = MediaType.MULTIPART_FORM_DATA_VALUE)	
	public  ResponseEntity<Resource> getGeneratedInvoice(
		@PathVariable("id") int applicationId) throws IOException {
		return paymentProxyService.getGeneratedInvoice(applicationId);
	}

}
