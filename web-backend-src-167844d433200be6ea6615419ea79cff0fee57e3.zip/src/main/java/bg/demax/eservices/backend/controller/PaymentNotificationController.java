package bg.demax.eservices.backend.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.eservices.backend.entity.applications.PaymentType;
import bg.demax.eservices.backend.service.PaymentNotificationService;
import bg.demax.payment.service.api.dto.PaymentNotificationDto;
import bg.demax.payment.service.api.dto.PaymentNotificationResponseDto;

@RestController
@RequestMapping("/api/payments/notify")
public class PaymentNotificationController {

	@Autowired
	private PaymentNotificationService paymentNotificationService;

	@PutMapping("/iaaa")
	public List<PaymentNotificationResponseDto> notifyAndUpdateIaaaPayments(
			@Valid @RequestBody List<PaymentNotificationDto> paymentDtos) {
		return paymentNotificationService.notifyAndUpdatePayments(paymentDtos, PaymentType.PROCESSING_FEE_ID);
	}

	@PutMapping("/demax")
	public List<PaymentNotificationResponseDto> notifyAndUpdateDemaxPayments(
			@Valid @RequestBody List<PaymentNotificationDto> paymentDtos) {
		//TODO: handle the PaymentType.DELIVERY_FEE_ID depending on the logic for DELIVERY_FEE payment creation, 
		// when it is implemented.
		return paymentNotificationService.notifyAndUpdatePayments(paymentDtos, PaymentType.PERSONALIZATION_FEE_ID);
	}
}