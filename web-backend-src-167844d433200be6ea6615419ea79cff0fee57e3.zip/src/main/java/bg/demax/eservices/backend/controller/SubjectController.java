package bg.demax.eservices.backend.controller;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.eservices.backend.dto.PersonalInfoDto;
import bg.demax.eservices.backend.dto.proxy.regix.mvr.RequestMvrDto;
import bg.demax.eservices.backend.dto.proxy.regix.nap.ContractDto;
import bg.demax.eservices.backend.dto.view.PhotoAndSignatureDto;
import bg.demax.eservices.backend.service.ApplicationService;
import bg.demax.eservices.backend.service.SubjectService;

@RestController
@RequestMapping("/api/subjects")
public class SubjectController {

	@Autowired
	private SubjectService subjectService;

	@Autowired
	private ApplicationService applicationService;

	@PostMapping("/mvr-personal-info")
	public PersonalInfoDto getPersonalInfoFromMvrAndGrao(@RequestBody @Valid RequestMvrDto requestInfo)
		throws IOException, NoSuchAlgorithmException, Exception {
		return subjectService.getPersonalInfoFromMvrAndGrao(requestInfo);
	}

	@PostMapping("/approver/mvr-personal-info")
	public PersonalInfoDto getPersonalInfoFromMvrAndGraoForApprover(@RequestBody @Valid RequestMvrDto requestInfo)
		throws Exception {
		return subjectService.getPersonalInfoFromMvrAndGraoForApprover(requestInfo);
	}

	@PostMapping("/approver/mvr-pictures")
	public PhotoAndSignatureDto getPicturesFromMvrForApprover(
		@RequestBody @Valid RequestMvrDto requestInfo) throws Exception {
		return subjectService.getPhotoAndSignatureFromMvrForApprover(requestInfo);
	}

	@PostMapping("/personal-info")
	public PersonalInfoDto savePersonalInfo(@RequestBody @Valid PersonalInfoDto personalInfoDto) {
		return applicationService.savePersonalInfoAndTransition(personalInfoDto);
	}
	// TODO : да се провери дали ще се ползва като се изтества на драйва за проверка в грао
	// @GetMapping("/grao/{egn}")
	// public GraoResponseDto getInfoFromGrao(@PathVariable("egn") String egn) {
	// 	return iaaaGatewayService.getSubjectInfoFromGrao(egn);
	// }

	@PostMapping("/application/{id}/picture-transition")
	public void saveTransitionForFaceAndSignatureSection(@PathVariable("id") int applicationId) {
		subjectService.saveTransitionForFaceAndSignatureSection(applicationId);
	}

	@GetMapping("/application/{id}/approver/nap-check")
	public List<ContractDto> getActiveContractsForApprover(@PathVariable("id") int applicationId) {
		return subjectService.getActiveContractsForApprover(applicationId);
	}
}
