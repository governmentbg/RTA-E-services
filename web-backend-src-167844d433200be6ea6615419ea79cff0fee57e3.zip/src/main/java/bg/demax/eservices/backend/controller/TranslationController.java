package bg.demax.eservices.backend.controller;

import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.eservices.backend.dto.LanguageDto;
import bg.demax.eservices.backend.dto.PaginationQueryParamsDto;
import bg.demax.eservices.backend.dto.TranslationRequestDto;
import bg.demax.eservices.backend.dto.TranslationSearchParamsDto;
import bg.demax.eservices.backend.dto.view.TranslationKeyValuesDto;
import bg.demax.eservices.backend.service.LanguageService;
import bg.demax.eservices.backend.service.TranslationValueService;
import bg.demax.hibernate.paging.PageResult;

@RestController
@RequestMapping("/api/translations")
public class TranslationController {
	@Autowired
	private TranslationValueService translationValueService;

	@Autowired
	private LanguageService languageService;

	@GetMapping("/languages")
	public ResponseEntity<List<LanguageDto>> getLanguages() {
		List<LanguageDto> languages = languageService.getLanguages();
		return ResponseEntity.ok().cacheControl(CacheControl.maxAge(3, TimeUnit.HOURS)).body(languages);
	}

	@GetMapping("/{lang_code}")
	public ResponseEntity<String> getTranslationForLanguage(@PathVariable("lang_code") String langCode) {
		return ResponseEntity.ok().cacheControl(CacheControl.maxAge(3, TimeUnit.HOURS))
				.body(translationValueService.getTranslationValuesForLanguage(langCode));
	}

	@GetMapping
	public PageResult<TranslationKeyValuesDto> findByPage(@Valid PaginationQueryParamsDto paginationQueryParamsDto, 
		@Valid TranslationSearchParamsDto searchParams) {
		return translationValueService.findByPage(paginationQueryParamsDto, searchParams);
	}

	@PostMapping
	public TranslationKeyValuesDto addNewTranslation(@RequestBody @Valid TranslationRequestDto newTranslation) {
		return translationValueService.addNewTranslation(newTranslation);
	}

	@PutMapping
	public TranslationKeyValuesDto editTranslation(@RequestBody @Valid TranslationRequestDto translation) {
		return translationValueService.editTranslation(translation);
	}

	@DeleteMapping("/{key}")
	public void deleteTranslation(@PathVariable("key") String key) {
		translationValueService.deleteTranslation(key);
	}

	//TODO "/filter" endpoint - to search key by value and language
}
