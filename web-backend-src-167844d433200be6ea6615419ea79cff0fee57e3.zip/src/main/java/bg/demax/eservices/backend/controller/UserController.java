package bg.demax.eservices.backend.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import bg.demax.eservices.backend.controller.param.UserManagementListQueryParams;
import bg.demax.eservices.backend.dto.UserDto;
import bg.demax.eservices.backend.dto.UserManagementListItemDto;
import bg.demax.eservices.backend.dto.UserRoleChangeRequestDto;
import bg.demax.eservices.backend.service.UserService;
import bg.demax.hibernate.paging.PageResult;

@RestController
@RequestMapping("/api/users")
public class UserController {

	@Autowired
	private UserService userService;

	@GetMapping("/current")
	public UserDto getCurrentLoggedInUser(Principal principal, HttpServletRequest request) {
		return userService.getCurrentUserDto(principal.getName(), request.getRemoteAddr());
	}

	@GetMapping
	public PageResult<UserManagementListItemDto> getUsersList(@Valid UserManagementListQueryParams params) {
		return userService.getUsersManagementList(params);
	}

	@PutMapping("/{id}/roles")
	public void changeUserRoles(@PathVariable("id") int userId, @Valid @RequestBody UserRoleChangeRequestDto requestDto) {
		userService.changeUserRole(userId, requestDto);
	}
}
