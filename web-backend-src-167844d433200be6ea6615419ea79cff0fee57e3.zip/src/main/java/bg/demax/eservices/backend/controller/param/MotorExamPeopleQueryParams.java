package bg.demax.eservices.backend.controller.param;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MotorExamPeopleQueryParams {

	@NotNull
	@Min(1)
	private Integer categoryId;
}
