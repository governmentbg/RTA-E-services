package bg.demax.eservices.backend.controller.param;

import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MotorExamProtocolSelectionQueryParams {

	@NotNull
	public String orgUnitCode;
}
