package bg.demax.eservices.backend.controller.param;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaxiExamProtocolSelectionQueryParams {

	@NotBlank
	private String regionCode;
}
