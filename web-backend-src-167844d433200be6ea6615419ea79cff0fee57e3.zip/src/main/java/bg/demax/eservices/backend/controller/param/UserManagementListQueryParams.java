package bg.demax.eservices.backend.controller.param;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import bg.demax.eservices.backend.dto.PaginationQueryParamsDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserManagementListQueryParams extends PaginationQueryParamsDto {

	private String identityNumber;
	private String name;
	
	@Pattern(regexp = "^(APPLICANT_E_SIGN|APPLICANT_E_FACE|APPROVER|VIEWER"
			+ "|DESK_STAFF|ADMIN_DEMAX|PERSO_CENTER_DEMAX)$")
	private String role;

	@Min(1)
	@Max(4)
	private Integer authenticationMethodId;
}
