package bg.demax.eservices.backend.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.AddressDto;
import bg.demax.eservices.backend.dto.nomenclature.CityDto;
import bg.demax.eservices.backend.dto.nomenclature.MunicipalityDto;
import bg.demax.eservices.backend.dto.nomenclature.RegionDto;
import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.entity.applications.Address;

@Component
public class AddressToAddressDto implements Converter<Address, AddressDto> {
	
	@Autowired
	private AppConversionService conversionService;

	@Override
	public AddressDto convert(Address source) {
		AddressDto dto = new AddressDto();
		dto.setCountryDto(source.getCountry() != null 
			? conversionService.convert(source.getCountry(), TranslationDto.class)
			: null);
		dto.setCityDto(source.getCity() != null 
			? conversionService.convert(source.getCity(), CityDto.class)
			: null);
		dto.setRegionDto(source.getCity() != null  
			? conversionService.convert(source.getCity().getRegion(), RegionDto.class)
			: null);
		dto.setMunicipalityDto(source.getCity() != null  
			? conversionService.convert(source.getMunicipality(), MunicipalityDto.class)
			: null);
		dto.setApartment(source.getApartment());
		dto.setEntrance(source.getEntrance());
		dto.setStreet(source.getStreet());
		dto.setBuilding(source.getBuilding());
		dto.setPostalCode(source.getPostalCode());
		dto.setStreetNumber(source.getStreetNumber());
		return dto;
	}
}