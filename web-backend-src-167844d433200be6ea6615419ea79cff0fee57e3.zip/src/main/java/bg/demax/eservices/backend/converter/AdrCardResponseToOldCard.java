package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.proxy.adr.vo.AdrCardResponse;
import bg.demax.eservices.backend.entity.applications.OldCard;

@Component
public class AdrCardResponseToOldCard  implements Converter<AdrCardResponse, OldCard> {

	@Override
	public OldCard convert(AdrCardResponse source) {
		OldCard dto = new OldCard();
		dto.setValidity(source.getValidTo());
		dto.setCardNumber(source.getNumber());
		return dto;
	}
}