package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.proxy.adr.vo.AdrCardResponse;
import bg.demax.eservices.backend.dto.view.OldCardDto;

@Component
public class AdrCardResponseToOldCardDto  implements Converter<AdrCardResponse, OldCardDto> {

	@Override
	public OldCardDto convert(AdrCardResponse source) {
		OldCardDto dto = new OldCardDto();
		dto.setValidity(source.getValidTo());
		dto.setCardNumber(source.getNumber());
		return dto;
	}
}