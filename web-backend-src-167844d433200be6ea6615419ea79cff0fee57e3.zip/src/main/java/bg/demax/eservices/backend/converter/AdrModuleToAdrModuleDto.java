package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.AdrModuleDto;
import bg.demax.eservices.backend.entity.applications.AdrModule;

@Component
public class AdrModuleToAdrModuleDto implements Converter<AdrModule, AdrModuleDto> {
	
	@Override
	public AdrModuleDto convert(AdrModule source) {
		AdrModuleDto dto = new AdrModuleDto();
		dto.setTypeId(source.getModuleType().getId());
		dto.setTypeKey(source.getModuleType().getTranslationKeyString());
		dto.setIssueDate(source.getIssuedDate());
		dto.setValidTo(source.getValidDate());
		dto.setAttached(source.isAttached());
		return dto;
	}
}