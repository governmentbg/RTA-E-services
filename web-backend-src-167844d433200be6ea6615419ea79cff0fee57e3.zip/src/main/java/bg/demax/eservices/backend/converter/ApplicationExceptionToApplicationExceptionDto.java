package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.exception.ApplicationExceptionDto;
import bg.demax.eservices.backend.exception.ApplicationException;

@Component
public class ApplicationExceptionToApplicationExceptionDto
		implements Converter<ApplicationException, ApplicationExceptionDto> {
	@Override
	public ApplicationExceptionDto convert(ApplicationException ex) {
		ApplicationExceptionDto dto = new ApplicationExceptionDto();
		dto.setError(ex.getError());
		String message = ex.getMessage();
		dto.setMessage(message);
		return dto;
	}
}
