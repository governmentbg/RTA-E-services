package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.view.ApplicationRemarkViewDto;
import bg.demax.eservices.backend.entity.applications.ApplicationRemark;

@Component
public class ApplicationRemarkToApplicationRemarkViewDto implements Converter<ApplicationRemark, ApplicationRemarkViewDto> {
	@Override
	public ApplicationRemarkViewDto convert(ApplicationRemark source) {
		ApplicationRemarkViewDto dto = new ApplicationRemarkViewDto();
		dto.setMessageTimestamp(source.getMessageTimestamp());
		dto.setMessage(source.getMessage());
		dto.setRemarkKey(source.getRemark() != null ? source.getRemark().getTranslationKeyString() : null);

		return dto;
	}
}
