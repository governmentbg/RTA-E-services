package bg.demax.eservices.backend.converter;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.entity.applications.Application;
import bg.demax.eservices.backend.entity.applications.Payment;
import bg.demax.eservices.backend.entity.applications.PaymentStatus.PaymentStatuses;
import bg.demax.eservices.backend.entity.applications.PaymentType;
import bg.demax.eservices.backend.vo.ApplicationCancellationVo;

@Component
public class ApplicationToApplicationCancellationVoConverter implements Converter<Application, ApplicationCancellationVo> {

	@Override
	public ApplicationCancellationVo convert(Application application) {
		Set<Payment> payments = application.getPayments();

		List<Long> demaxPaymentServiceIds = payments.stream().filter(payment -> {
			return payment.getPaymentServiceId() != null 
					&& (payment.getPaymentType().getId().equals(PaymentType.PERSONALIZATION_FEE_ID)
					|| payment.getPaymentType().getId().equals(PaymentType.DELIVERY_FEE_ID))
					&& PaymentStatuses.WAITING.getCode().equals(payment.getPaymentStatus().getCode());
		}).map(payment -> {
			return payment.getPaymentServiceId();
		}).collect(Collectors.toList());

		List<Long> iaaaPaymentServiceIds = payments.stream().filter(payment -> {
			return payment.getPaymentServiceId() != null 
					&& payment.getPaymentType().getId().equals(PaymentType.PROCESSING_FEE_ID)
					&& PaymentStatuses.WAITING.getCode().equals(payment.getPaymentStatus().getCode());
		}).map(payment -> {
			return payment.getPaymentServiceId();
		}).collect(Collectors.toList());

		return new ApplicationCancellationVo(application.getId(), demaxPaymentServiceIds, iaaaPaymentServiceIds);
	}
}
