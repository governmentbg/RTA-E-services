package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.entity.applications.ApplicationType;

@Component
public class ApplicationTypeToTranslationDto implements Converter<ApplicationType, TranslationDto> {

	@Override
	public TranslationDto convert(ApplicationType source) {
		TranslationDto dto = new TranslationDto();
		dto.setId(source.getId());
		dto.setKey(source.getTranslationKeyString());
		
		return dto;
	}
}
