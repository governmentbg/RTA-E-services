package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.entity.applications.AttachedDocument;

@Component
public class AttachedDocumentToTranslationDto implements Converter<AttachedDocument, TranslationDto> {
	
	@Override
	public TranslationDto convert(AttachedDocument source) {
		TranslationDto dto = new TranslationDto();
		dto.setId(source.getDocumentType().getId());
		dto.setKey(source.getDocumentType().getTranslationKeyString());
		return dto;
	}
}