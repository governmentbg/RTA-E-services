package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.entity.security.AuthenticationMethod;

@Component
public class AuthenticationMethodToTranslationDto implements Converter<AuthenticationMethod, TranslationDto> {
	
	@Override
	public TranslationDto convert(AuthenticationMethod source) {
		TranslationDto dto = new TranslationDto();
		dto.setId(source.getId());
		dto.setKey(source.getTranslationKeyString());
		return dto;
	}
}