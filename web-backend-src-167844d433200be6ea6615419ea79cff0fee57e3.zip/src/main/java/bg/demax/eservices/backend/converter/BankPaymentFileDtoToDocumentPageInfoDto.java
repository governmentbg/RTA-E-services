package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.view.DocumentPageInfoDto;
import bg.demax.payment.service.api.dto.BankPaymentFileDto;

@Component
public class BankPaymentFileDtoToDocumentPageInfoDto implements Converter<BankPaymentFileDto, DocumentPageInfoDto> {

	@Override
	public DocumentPageInfoDto convert(BankPaymentFileDto source) {
		DocumentPageInfoDto dto = new DocumentPageInfoDto();
		dto.setId(source.getId());
		dto.setName(source.getFileName());
		dto.setSize(source.getSizeInBytes());
		return dto;
	}
}
