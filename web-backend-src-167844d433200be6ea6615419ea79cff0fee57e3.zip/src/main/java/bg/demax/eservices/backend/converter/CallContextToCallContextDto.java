package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import bg.demax.eservices.backend.entity.config.CallContext;
import bg.demax.regixclient.mvr.bds.CallContextDto;

@Component
public class CallContextToCallContextDto implements Converter<CallContext, CallContextDto> {
	
	@Override
	public CallContextDto convert(CallContext source) {
		CallContextDto dto = new CallContextDto();
		dto.setServiceType(source.getServiceType());
		dto.setEmployeeNames(source.getEmployeeNames());
		dto.setAdministrationName(source.getAdministrationName());
		dto.setAdministrationOId(source.getAdministrationOid());
		return dto;
	}
}