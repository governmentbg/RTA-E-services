package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.view.CategoryDto;
import bg.demax.eservices.backend.entity.applications.Category;

@Component
public class CategoryToCategoryDto implements Converter<Category, CategoryDto> {
	@Override
	public CategoryDto convert(Category source) {
		CategoryDto dto = new CategoryDto();
		dto.setCategoryId(source.getId());
		dto.setCategory(source.getCategory());
		dto.setImageClass(source.getImageClass());
		return dto;
	}
}
