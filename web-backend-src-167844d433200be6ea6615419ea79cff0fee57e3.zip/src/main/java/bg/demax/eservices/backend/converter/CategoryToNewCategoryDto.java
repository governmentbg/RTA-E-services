package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.NewCategoryDto;
import bg.demax.eservices.backend.entity.applications.Category;

@Component
public class CategoryToNewCategoryDto implements Converter<Category, NewCategoryDto> {
	@Override
	public NewCategoryDto convert(Category source) {
		NewCategoryDto dto = new NewCategoryDto();
		dto.setCategoryId(source.getId());
		return dto;
	}
}
