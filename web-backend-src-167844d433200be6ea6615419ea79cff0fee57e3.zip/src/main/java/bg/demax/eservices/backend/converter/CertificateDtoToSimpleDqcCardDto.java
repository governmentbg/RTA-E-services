package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.CertificateDto;
import bg.demax.eservices.backend.dto.proxy.dqc.SimpleDqcCertDto;

@Component
public class CertificateDtoToSimpleDqcCardDto implements Converter<CertificateDto, SimpleDqcCertDto> {

	@Override
	public SimpleDqcCertDto convert(CertificateDto source) {
		SimpleDqcCertDto cert = new SimpleDqcCertDto();
		cert.setTypeKey(source.getTypeKey());
		cert.setEndDate(source.getTrainingEnd());
		cert.setStartDate(source.getTrainingStart());
		cert.setIssueDate(source.getIssuedOn());
		//TODO set issuer and issuer number
		return cert;
	}
	
}
