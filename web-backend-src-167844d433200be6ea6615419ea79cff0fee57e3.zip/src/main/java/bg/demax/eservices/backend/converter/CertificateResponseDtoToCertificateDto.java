package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.CertificateDto;
import bg.demax.eservices.backend.dto.proxy.dqc.CertificateResponseDto;
import bg.demax.eservices.backend.util.Utils;

@Component
public class CertificateResponseDtoToCertificateDto implements Converter<CertificateResponseDto, CertificateDto> {
	@Override
	public CertificateDto convert(CertificateResponseDto source) {
		CertificateDto dto = new CertificateDto();
		dto.setPermitNumber(String.valueOf(source.getPermitNumber()).replaceAll(Utils.LEADING_ZEROS_REGEX, ""));
		dto.setCertificateNumber(source.getCertificateNumber().replaceAll(Utils.LEADING_ZEROS_REGEX, ""));
		dto.setIssuedOn(source.getCertificateDate().toLocalDate());
		dto.setTrainingStart(source.getTrainingStartDate().toLocalDate());
		dto.setTrainingEnd(source.getTrainingEndDate().toLocalDate());
		dto.setAttached(false);
	
		return dto;
	}
}
