package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.CityDto;
import bg.demax.eservices.backend.entity.applications.City;

@Component
public class CityToCityDto implements Converter<City, CityDto> {
	
	@Override
	public CityDto convert(City source) {
		CityDto dto = new CityDto();
		dto.setCityCode(source.getCode());
		dto.setKey(source.getTranslationKeyString());
		return dto;
	}
}