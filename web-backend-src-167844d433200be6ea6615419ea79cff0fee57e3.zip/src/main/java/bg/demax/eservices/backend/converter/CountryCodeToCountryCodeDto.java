package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.CountryCodeDto;
import bg.demax.eservices.backend.entity.applications.CountryCode;

@Component
public class CountryCodeToCountryCodeDto implements Converter<CountryCode, CountryCodeDto> {

	@Override
	public CountryCodeDto convert(CountryCode source) {
		CountryCodeDto dto = new CountryCodeDto();
		dto.setCode(source.getCode());
		dto.setId(source.getId());
		dto.setCountryTranslationKey(source.getCountry().getTranslationKeyString());
		dto.setCountryCode2(source.getCountry().getCode2());
		return dto;
	}
}
