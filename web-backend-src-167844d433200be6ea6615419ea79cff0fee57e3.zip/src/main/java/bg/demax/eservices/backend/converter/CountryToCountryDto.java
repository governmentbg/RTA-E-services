package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.CountryDto;
import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.entity.applications.Country;

@Component
public class CountryToCountryDto implements Converter<Country, CountryDto> {
	
	@Override
	public CountryDto convert(Country source) {
		CountryDto country = new CountryDto();
		TranslationDto dto = new TranslationDto();
		dto.setId(source.getId());
		dto.setKey(source.getTranslationKeyString());
		country.setCountry(dto);
		country.setEu(source.isEuMember());
		return country;
	}
}