package bg.demax.eservices.backend.converter;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.hibernate.Hibernate;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.proxy.dqc.DqcCardCreationCargoCertificate;
import bg.demax.eservices.backend.dto.proxy.dqc.DqcCardCreationPassengerCertificate;
import bg.demax.eservices.backend.dto.proxy.dqc.DqcCardCreationPersonDto;
import bg.demax.eservices.backend.dto.proxy.dqc.DqcCardCreationRequestDto;
import bg.demax.eservices.backend.entity.applications.ApplicationAddress;
import bg.demax.eservices.backend.entity.applications.ApplicationEmail;
import bg.demax.eservices.backend.entity.applications.Category;
import bg.demax.eservices.backend.entity.applications.City;
import bg.demax.eservices.backend.entity.applications.ContactType;
import bg.demax.eservices.backend.entity.applications.CorrespondenceType;
import bg.demax.eservices.backend.entity.applications.DqcApplication;
import bg.demax.eservices.backend.entity.applications.DqcCertificate;
import bg.demax.eservices.backend.entity.applications.DrivingLicence;
import bg.demax.eservices.backend.entity.applications.DrivingLicenceCategory;
import bg.demax.eservices.backend.entity.applications.IdentityDocument;
import bg.demax.eservices.backend.entity.applications.Payment;
import bg.demax.eservices.backend.entity.applications.PaymentType;
import bg.demax.eservices.backend.entity.applications.Region;
import bg.demax.eservices.backend.entity.applications.TrainingType;
import bg.demax.eservices.backend.entity.config.Language;
import bg.demax.eservices.backend.entity.config.TranslationValue;
import bg.demax.eservices.backend.entity.subjects.LegalSubject;
import bg.demax.eservices.backend.entity.subjects.PhysicalSubject;
import bg.demax.eservices.backend.entity.subjects.PhysicalSubjectVersion;
import bg.demax.eservices.backend.entity.subjects.Subject;
import bg.demax.eservices.backend.exception.ApplicationException;
import bg.demax.eservices.backend.exception.CardCreationRequestException;

@Component
public class DqcApplicationToDqcCardCreationRequestDtoConverter
		implements Converter<DqcApplication, DqcCardCreationRequestDto> {

	@Override
	public DqcCardCreationRequestDto convert(DqcApplication dqcApplication) {
		Subject subject = dqcApplication.getSubject();
		if (subject == null) {
			throw new ApplicationException("DqcApplication with id=" + dqcApplication.getId() 
				+ " does not have a Subject.");
		}
		subject = (Subject) Hibernate.unproxy(subject);
		
		if (subject instanceof LegalSubject) {
			throw new ApplicationException("Legal subject is not allowed for this operation.");
		} 
		PhysicalSubject physicalSubject = (PhysicalSubject) subject;
		
		PhysicalSubjectVersion physicalSubjectVersion = dqcApplication.getPhysicalSubjectVersion();
		
		IdentityDocument identityDocument = dqcApplication.getIdentityDocument();
		if (identityDocument == null) {
			throw new ApplicationException("DqcApplication with id=" + dqcApplication.getId() 
				+ " does not have IdentityDocument.");
		}
		
		Optional<TranslationValue> identityDocumentIssuerBgTranslationValueOptional = identityDocument.getDocumentIssuer()
			.getTranslationKey().getValues().stream().filter(translationValues -> {
				return translationValues.getLanguage().getCode().equals(Language.BULGARIAN_CODE);
			}).findFirst();
		
		DrivingLicence drivingLicence = dqcApplication.getDrivingLicence();
		if (drivingLicence == null) {
			throw new ApplicationException("DqcApplication with id=" + dqcApplication.getId() 
				+ " does not have DrivingLicence.");
		}
		
		Optional<TranslationValue> drivingLicenceIssuerBgTranslationValueOptional;
		if (drivingLicence.getDocumentIssuer() != null) {
			drivingLicenceIssuerBgTranslationValueOptional = drivingLicence.getDocumentIssuer()
				.getTranslationKey().getValues().stream().filter(translationValues -> {
					return translationValues.getLanguage().getCode().equals(Language.BULGARIAN_CODE);
				}).findFirst();
		} else if (drivingLicence.getIssuingCountry() != null) {
			drivingLicenceIssuerBgTranslationValueOptional = drivingLicence.getIssuingCountry()
				.getTranslationKey().getValues().stream().filter(translationValues -> {
					return translationValues.getLanguage().getCode().equals(Language.BULGARIAN_CODE);
				}).findFirst();
		} else {
			drivingLicenceIssuerBgTranslationValueOptional = Optional.empty();
		}
		
		List<DrivingLicenceCategory> cDrivingLicenceCategories = drivingLicence.getDrivingLicenceCategories().stream()
			.filter(drivingLicenceCategory -> {
				return drivingLicenceCategory.getCategory().getId().equals(Category.C_ID)
						|| drivingLicenceCategory.getCategory().getId().equals(Category.CE_ID);
			}).collect(Collectors.toList());
		
		List<DrivingLicenceCategory> c1DrivingLicenceCategories = drivingLicence.getDrivingLicenceCategories().stream()
			.filter(drivingLicenceCategory -> {
				return drivingLicenceCategory.getCategory().getId().equals(Category.C1_ID)
						|| drivingLicenceCategory.getCategory().getId().equals(Category.C1E_ID);
			}).collect(Collectors.toList());
		
		List<DrivingLicenceCategory> dDrivingLicenceCategories = drivingLicence.getDrivingLicenceCategories().stream()
			.filter(drivingLicenceCategory -> {
				return drivingLicenceCategory.getCategory().getId().equals(Category.D_ID)
						|| drivingLicenceCategory.getCategory().getId().equals(Category.DE_ID);
			}).collect(Collectors.toList());
		
		List<DrivingLicenceCategory> d1DrivingLicenceCategories = drivingLicence.getDrivingLicenceCategories().stream()
			.filter(drivingLicenceCategory -> {
				return drivingLicenceCategory.getCategory().getId().equals(Category.D1_ID)
						|| drivingLicenceCategory.getCategory().getId().equals(Category.D1E_ID);
			}).collect(Collectors.toList());
		
		List<DqcCertificate> dqcCertificates = dqcApplication.getCertificates();
		
		Optional<DqcCertificate> cargoDqcCertificateOptional = dqcCertificates.stream()
			.filter(certificate -> {
				return certificate.getCertificateType().getId().equals(TrainingType.GOODS);
			}).sorted((certificate1, certificate2) -> {
				return certificate2.getIssuedDate().compareTo(certificate1.getIssuedDate());
			}).findFirst();
		
		Optional<DqcCertificate> passengerDqcCertificateOptional = dqcCertificates.stream()
			.filter(certificate -> {
				return certificate.getCertificateType().getId().equals(TrainingType.PASSANGERS);
			}).sorted((certificate1, certificate2) -> {
				return certificate2.getIssuedDate().compareTo(certificate1.getIssuedDate());
			}).findFirst();
		
		DqcCardCreationRequestDto dto = new DqcCardCreationRequestDto();
		dto.setFirstName(physicalSubjectVersion.getFirstNameLat().getName());
		dto.setFirstNameCyr(physicalSubjectVersion.getFirstNameCyr().getName());
		if (physicalSubjectVersion.getFathersNameLat() != null && physicalSubjectVersion.getFathersNameCyr() != null) {
			dto.setFathersName(physicalSubjectVersion.getFathersNameLat().getName());
			dto.setFathersNameCyr(physicalSubjectVersion.getFathersNameCyr().getName());
		}
		dto.setSurName(physicalSubjectVersion.getFamilyNameLat().getName());
		dto.setSurNameCyr(physicalSubjectVersion.getFamilyNameCyr().getName());
		
		DqcCardCreationPersonDto personDto = new DqcCardCreationPersonDto();
		personDto.setPersonalNumber(physicalSubject.getIdentityNumber());
		personDto.setBirthDate(physicalSubject.getBirthDate());
		personDto.setBirthPlace(physicalSubject.getBirthPlaceLatin());
		personDto.setBirthPlaceCyr(physicalSubject.getBirthPlace());
		personDto.setPersonalNumberType(physicalSubject.getIdentityNumberType().getId().toString());
		dto.setPerson(personDto);
		
		Optional<ApplicationAddress> permanentAddressOptional = dqcApplication.getApplicationAddresses()
			.stream().filter(applicationAddress -> {
				return applicationAddress.getContactType().getId().equals(ContactType.PERMANENT_ADDRESS);
			}).findFirst();

		Optional<ApplicationAddress> postalAddressOptional = dqcApplication.getApplicationAddresses()
			.stream().filter(applicationAddress -> {
				return applicationAddress.getCorrespondenceType().getId().equals(CorrespondenceType.POSTAL_ADDRESS);
			}).findFirst();

		if (!postalAddressOptional.isPresent()) {
			Optional<ApplicationAddress> correspondenceAddressOptional = dqcApplication.getApplicationAddresses()
			.stream().filter(applicationAddress -> {
				return applicationAddress.getCorrespondenceType().getId().equals(
					CorrespondenceType.PREFERRED_CORRESPONDENCE_CONTACT);
			}).findFirst();
			if (!correspondenceAddressOptional.isPresent()) {
				throw new CardCreationRequestException(String.format(
					"Липсва пощенски адрес или адрес тип предочитан канал за комункация за заявление : %d", 
						dqcApplication.getId()));
			}
			postalAddressOptional = correspondenceAddressOptional;
		}
		
		if (permanentAddressOptional.isPresent()) {
			ApplicationAddress permanentAddress = permanentAddressOptional.get();
			City city = permanentAddress.getAddress().getCity();
			Optional<TranslationValue> cityBgTranslationValueOptional = city.getTranslationKey().getValues()
				.stream().filter(translationValue -> {
					return translationValue.getLanguage().getCode().equals(Language.BULGARIAN_CODE);
				}).findFirst();
			
			Region region = permanentAddress.getAddress().getCity().getRegion();
			Optional<TranslationValue> regionBgTranslationValueOptional = region.getTranslationKey().getValues()
				.stream().filter(translationValue -> {
					return translationValue.getLanguage().getCode().equals(Language.BULGARIAN_CODE);
				}).findFirst();
			
			if (regionBgTranslationValueOptional.isPresent()) {
				String residenceDistrictValue = regionBgTranslationValueOptional.get().getValue();
				residenceDistrictValue = removeBracketsSubstring(residenceDistrictValue);
				dto.setResidenceDistrict(residenceDistrictValue);
			}
			
			if (cityBgTranslationValueOptional.isPresent()) {
				dto.setResidenceCity(cityBgTranslationValueOptional.get().getValue());
			}
			
			dto.setResidenceAddress(permanentAddress.getAddress().getCyrillicAddressString()); // = postalAddress
		}
		
		if (postalAddressOptional.isPresent()) {
			ApplicationAddress postalAddress = postalAddressOptional.get();
			City city = postalAddress.getAddress().getCity();
			Optional<TranslationValue> cityBgTranslationValueOptional = city.getTranslationKey().getValues()
				.stream().filter(translationValue -> {
					return translationValue.getLanguage().getCode().equals(Language.BULGARIAN_CODE);
				}).findFirst();
			
			Region region = postalAddress.getAddress().getCity().getRegion();
			Optional<TranslationValue> regionBgTranslationValueOptional = region.getTranslationKey().getValues()
				.stream().filter(translationValue -> {
					return translationValue.getLanguage().getCode().equals(Language.BULGARIAN_CODE);
				}).findFirst();
			
			if (regionBgTranslationValueOptional.isPresent()) {
				String postalDistrictValue = regionBgTranslationValueOptional.get().getValue();
				postalDistrictValue = removeBracketsSubstring(postalDistrictValue);
				dto.setPostalDistrict(postalDistrictValue);
			}
			
			if (cityBgTranslationValueOptional.isPresent()) {
				dto.setPostalCity(cityBgTranslationValueOptional.get().getValue());
			}
			
			dto.setPostalAddress(postalAddress.getAddress().getCyrillicAddressString());
		}
		
		Optional<ApplicationEmail> preferredCorespondenceEmailOptional = dqcApplication.getApplicationEmails()
			.stream().filter(applicationEmail -> {
				return applicationEmail.getCorrespondenceType().getId()
					.equals(CorrespondenceType.PREFERRED_CORRESPONDENCE_CONTACT);
			}).findFirst();
		
		Optional<Payment> processingFeePaymentOptional = dqcApplication.getPayments().stream().filter(payment -> {
			return payment.getPaymentType().getId().equals(PaymentType.PROCESSING_FEE_ID);
		}).findFirst();
		
		if (!processingFeePaymentOptional.isPresent()) {
			throw new ApplicationException("Processing fee payment not found for DQC application with id=" 
				+ dqcApplication.getId());
		}
		Payment processingFeePayment = processingFeePaymentOptional.get();
		dto.setPhone(processingFeePayment.getArchimedDocumentUriNumber());
		
		if (preferredCorespondenceEmailOptional.isPresent()) {
			dto.setEmail(preferredCorespondenceEmailOptional.get().getEmail().getEmail()); 
		}
		
		dto.setLicenseNumber(drivingLicence.getNumber());
		if (drivingLicenceIssuerBgTranslationValueOptional.isPresent()) {
			dto.setLicenseIssuer(drivingLicenceIssuerBgTranslationValueOptional.get().getValue());
		}
		dto.setLicenseIssueDate(drivingLicence.getIssuingDate());
		
		if ((cDrivingLicenceCategories != null && !cDrivingLicenceCategories.isEmpty())
				|| (c1DrivingLicenceCategories != null && !c1DrivingLicenceCategories.isEmpty())) {
			List<String> categoryStrings;
			if (cDrivingLicenceCategories != null && !cDrivingLicenceCategories.isEmpty()) {
				categoryStrings = cDrivingLicenceCategories.stream()
					.sorted((drivingLicenceCategory1, drivingLicenceCategory2) -> {
						return drivingLicenceCategory1.getCategory().getId()
								.compareTo(drivingLicenceCategory2.getCategory().getId());
					}).map(drivingLicenceCategory -> {
						return drivingLicenceCategory.getCategory().getCategory();
					}).collect(Collectors.toList());
			} else {
				categoryStrings = c1DrivingLicenceCategories.stream()
					.sorted((drivingLicenceCategory1, drivingLicenceCategory2) -> {
						return drivingLicenceCategory1.getCategory().getId()
								.compareTo(drivingLicenceCategory2.getCategory().getId());
					}).map(drivingLicenceCategory -> {
						return drivingLicenceCategory.getCategory().getCategory();
					}).collect(Collectors.toList());
			}
			
			dto.setCategoriesC(String.join(" ", categoryStrings));
			
			LocalDate issueDate = Stream.concat(cDrivingLicenceCategories.stream(), c1DrivingLicenceCategories.stream())
				.filter(drivingLicenceCategory -> {
					return drivingLicenceCategory.getCategory().getId().equals(Category.C_ID)
							|| drivingLicenceCategory.getCategory().getId().equals(Category.C1_ID);
				}).map(drivingLicenceCategory -> {
					return drivingLicenceCategory.getIssuedDate();
				}).findFirst().get();
			
			dto.setCatsCDate(issueDate);
		} else {
			dto.setCategoriesC("");
			dto.setCatsCDate(null); 
		}

		if ((dDrivingLicenceCategories != null && !dDrivingLicenceCategories.isEmpty())
				|| (d1DrivingLicenceCategories != null && !d1DrivingLicenceCategories.isEmpty())) {
			List<String> categoryStrings;
			if (dDrivingLicenceCategories != null && !dDrivingLicenceCategories.isEmpty()) {
				categoryStrings = dDrivingLicenceCategories.stream()
					.sorted((drivingLicenceCategory1, drivingLicenceCategory2) -> {
						return drivingLicenceCategory1.getCategory().getId()
								.compareTo(drivingLicenceCategory2.getCategory().getId());
					}).map(drivingLicenceCategory -> {
						return drivingLicenceCategory.getCategory().getCategory();
					}).collect(Collectors.toList());
			} else {
				categoryStrings = d1DrivingLicenceCategories.stream()
					.sorted((drivingLicenceCategory1, drivingLicenceCategory2) -> {
						return drivingLicenceCategory1.getCategory().getId()
								.compareTo(drivingLicenceCategory2.getCategory().getId());
					}).map(drivingLicenceCategory -> {
						return drivingLicenceCategory.getCategory().getCategory();
					}).collect(Collectors.toList());
			}
			
			dto.setCategoriesD(String.join(" ", categoryStrings));
			
			LocalDate issueDate = Stream.concat(dDrivingLicenceCategories.stream(), d1DrivingLicenceCategories.stream())
				.filter(drivingLicenceCategory -> {
					return drivingLicenceCategory.getCategory().getId().equals(Category.D_ID)
							|| drivingLicenceCategory.getCategory().getId().equals(Category.D1_ID);
				}).map(drivingLicenceCategory -> {
					return drivingLicenceCategory.getIssuedDate();
				}).findFirst().get();

			dto.setCatsDDate(issueDate);
		} else {
			dto.setCategoriesD("");
			dto.setCatsDDate(null);
		}

		dto.setPassNumber(identityDocument.getDocumentNumber());
		dto.setPassIssueDate(identityDocument.getIssuingDate());
		if (identityDocumentIssuerBgTranslationValueOptional.isPresent()) {
			TranslationValue identityDocumentIssuerBgTranslationKey = identityDocumentIssuerBgTranslationValueOptional.get();
			dto.setPassIssuer(identityDocumentIssuerBgTranslationKey.getValue());
		}
		
		// попълва се от сървиса, заради това че Application нама директна връзка към ApplicationType
		//dto.setDescription(dqcApplication.getCardIssuingReason().getReasonCyrillic());
		
		//dto.setIssueDate(dqcApplication.getApprovalTimestamp().toLocalDate());
		dto.setIssueDate(LocalDate.now());
		
		// попълват се в сървиса, заради рекуестите към DocumentStorage
		// dto.setFace(face);
		// dto.setSignature(signature);
		
		if (cargoDqcCertificateOptional.isPresent()) {
			DqcCertificate cargoDqcCertificate = cargoDqcCertificateOptional.get();
			
			DqcCardCreationCargoCertificate cargoCertificateDto = new DqcCardCreationCargoCertificate();
			cargoCertificateDto.setCertType(cargoDqcCertificate.getLegalBasisType().getDqcCertificateType());
			cargoCertificateDto.setStartDate(cargoDqcCertificate.getTrainingStartDate());
			cargoCertificateDto.setEndDate(cargoDqcCertificate.getTrainingEndDate());
			cargoCertificateDto.setIssueDate(cargoDqcCertificate.getIssuedDate());
			cargoCertificateDto.setIssuer(cargoDqcCertificate.getPermitNumber());
			cargoCertificateDto.setIssuerNumber(cargoDqcCertificate.getNumber()); 
			cargoCertificateDto.setValidTo(null);
			dto.setCargoCertificate(cargoCertificateDto);
		}
		
		if (passengerDqcCertificateOptional.isPresent()) {
			DqcCertificate passengerDqcCertificate = passengerDqcCertificateOptional.get();
			
			DqcCardCreationPassengerCertificate passengerCertificateDto = new DqcCardCreationPassengerCertificate();
			passengerCertificateDto.setCertType(passengerDqcCertificate.getLegalBasisType().getDqcCertificateType());
			passengerCertificateDto.setStartDate(passengerDqcCertificate.getTrainingStartDate());
			passengerCertificateDto.setEndDate(passengerDqcCertificate.getTrainingEndDate());
			passengerCertificateDto.setIssueDate(passengerDqcCertificate.getIssuedDate());
			passengerCertificateDto.setIssuer(passengerDqcCertificate.getPermitNumber());
			passengerCertificateDto.setIssuerNumber(passengerDqcCertificate.getNumber());
			passengerCertificateDto.setValidTo(null);
			dto.setPassengerCertificate(passengerCertificateDto);
		}
		
		return dto;
	}

	private String removeBracketsSubstring(String residenceDistrictValue) {
		// old code : "\\(.*?\\)"  - хвърляше грешка при :  София (столица)
		return residenceDistrictValue.replaceAll("[(){}]", "").trim();
	}
}
