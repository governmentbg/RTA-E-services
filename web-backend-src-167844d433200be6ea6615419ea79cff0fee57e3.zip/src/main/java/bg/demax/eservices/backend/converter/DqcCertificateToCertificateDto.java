package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.CertificateDto;
import bg.demax.eservices.backend.entity.applications.DqcCertificate;
import bg.demax.eservices.backend.util.Utils;

@Component
public class DqcCertificateToCertificateDto implements Converter<DqcCertificate, CertificateDto> {
	@Override
	public CertificateDto convert(DqcCertificate source) {
		CertificateDto dto = new CertificateDto();
		dto.setPermitNumber(source.getPermitNumber().replaceAll(Utils.LEADING_ZEROS_REGEX, ""));
		dto.setCertificateNumber(source.getNumber().replaceAll(Utils.LEADING_ZEROS_REGEX, ""));
		dto.setTypeId(source.getCertificateType().getId());
		dto.setTypeKey(source.getCertificateType().getTranslationKeyString());
		dto.setIssuedOn(source.getIssuedDate());
		dto.setTrainingStart(source.getTrainingStartDate());
		dto.setTrainingEnd(source.getTrainingEndDate());
		dto.setLegalBasisId(source.getLegalBasisType().getId());
		dto.setLegalBasisKey(source.getLegalBasisType().getTranslationKeyString());
		dto.setLegalBasisType(source.getLegalBasisType().getDqcCertificateType());
		dto.setAttached(source.isAttached());

		return dto;
	}
}
