package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.view.CategoryDto;
import bg.demax.eservices.backend.entity.applications.DrivingLicenceCategory;

@Component
public class DrivingLicenceCategoryToCategoryDto implements Converter<DrivingLicenceCategory, CategoryDto> {
	@Override
	public CategoryDto convert(DrivingLicenceCategory source) {
		CategoryDto dto = new CategoryDto();
		dto.setCategoryId(source.getCategory().getId());
		dto.setCategory(source.getCategory().getCategory());
		dto.setAcquisitionDate(source.getIssuedDate());
		return dto;
	}
}
