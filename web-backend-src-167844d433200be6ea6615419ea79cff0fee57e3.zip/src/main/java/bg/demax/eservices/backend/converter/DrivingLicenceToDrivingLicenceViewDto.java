package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.dto.view.DrivingLicenceViewDto;
import bg.demax.eservices.backend.entity.applications.DrivingLicence;

@Component
public class DrivingLicenceToDrivingLicenceViewDto implements Converter<DrivingLicence, DrivingLicenceViewDto> {

	@Override
	public DrivingLicenceViewDto convert(DrivingLicence source) {
		DrivingLicenceViewDto dto = new DrivingLicenceViewDto();
		dto.setDocumentNumber(source.getNumber());
		if (source.getDocumentIssuer() != null) {
			dto.setBulgarian(true);
			TranslationDto docIssuer = new TranslationDto();
			docIssuer.setId(source.getDocumentIssuer().getId());
			docIssuer.setKey(source.getDocumentIssuer().getTranslationKeyString());
			dto.setIssuedBy(docIssuer);
		} else {
			dto.setBulgarian(false);
			TranslationDto countryIssuer = new TranslationDto();
			countryIssuer.setId(source.getIssuingCountry().getId());
			countryIssuer.setKey(source.getIssuingCountry().getTranslationKeyString());
			dto.setIssuedBy(countryIssuer);
		}
		dto.setExpirationDate(source.getValidityDate());
		dto.setIssuedOn(source.getIssuingDate());
		return dto;
	}
}