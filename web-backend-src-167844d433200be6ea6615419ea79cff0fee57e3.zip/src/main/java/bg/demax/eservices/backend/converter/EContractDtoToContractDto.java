package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.proxy.regix.nap.ContractDto;
import bg.demax.regixclient.nra.employmentcontracts.EContractDto;

@Component
public class EContractDtoToContractDto implements Converter<EContractDto, ContractDto> {

	@Override
	public ContractDto convert(EContractDto source) {
		ContractDto dto = new ContractDto();
		dto.setStartDate(source.getStartDate());
		dto.setEndDate(source.getEndDate());
		dto.setTimeLimit(source.getTimeLimit());
		dto.setProfessionCode(source.getProfessionCode());
		dto.setProfessionName(source.getProfessionName());
		return dto;
	}
}
