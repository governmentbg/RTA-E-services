package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.entity.fsm.GeneralizedStatus;

@Component
public class GeneralizedStatusToTranslationDto implements Converter<GeneralizedStatus, TranslationDto> {

	@Override
	public TranslationDto convert(GeneralizedStatus source) {
		TranslationDto dto = new TranslationDto();
		dto.setId(source.getId());
		dto.setKey(source.getTranslationKeyString());
		return dto;
	}
}