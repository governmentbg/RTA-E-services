package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.eservices.backend.dto.AddressDto;
import bg.demax.eservices.backend.dto.proxy.regix.grao.GraoAddressDto;

@Component
public class GraoAddressDtoToAddressDto implements Converter<GraoAddressDto, AddressDto> {

	@Override
	@Transactional
	public AddressDto convert(GraoAddressDto source) {
		AddressDto dto = new AddressDto();
		if (source.getApartment() != null) {
			dto.setApartment(source.getApartment());
		}
		if (source.getEntrance() != null) {
			dto.setEntrance(source.getEntrance());
		}
		if (source.getStreet() != null) {
			dto.setStreet(source.getStreet().getText());
		}
		if (source.getNumber() !=  null) {
			dto.setStreetNumber(source.getNumber());
		} 
		return dto;
	}
}