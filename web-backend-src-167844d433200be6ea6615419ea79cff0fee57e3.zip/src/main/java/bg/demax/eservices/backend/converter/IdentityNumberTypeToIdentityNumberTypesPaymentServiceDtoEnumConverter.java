package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.entity.subjects.IdentityNumberType;
import bg.demax.payment.service.api.dto.PaymentPayerDetailsDto.IdentityNumberTypes;

@Component
public class IdentityNumberTypeToIdentityNumberTypesPaymentServiceDtoEnumConverter
		implements Converter<IdentityNumberType, IdentityNumberTypes> {

	@Override
	public IdentityNumberTypes convert(IdentityNumberType type) {
		switch (type.getId()) {
			case IdentityNumberType.EGN:
				return IdentityNumberTypes.EGN;
			case IdentityNumberType.LNCH:
				return IdentityNumberTypes.LNC;
			case IdentityNumberType.EIK:
				return IdentityNumberTypes.BULSTAT;
			case IdentityNumberType.SYSTEM_No:
				return IdentityNumberTypes.SYSTEM_NUMBER;
			default:
				throw new RuntimeException("Unknown IdentityNumberType.");
		}
	}
}
