package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.LanguageDto;
import bg.demax.eservices.backend.entity.config.Language;

@Component
public class LanguageToLanguageDto implements Converter<Language, LanguageDto> {
	@Override
	public LanguageDto convert(Language from) {
		LanguageDto dto = new LanguageDto();
		dto.setCode(from.getCode());
		dto.setName(from.getName());

		return dto;
	}
}
