package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.AdrModuleDto;
import bg.demax.eservices.backend.entity.applications.ModuleType;

@Component
public class ModuleTypeToAdrModuleDto implements Converter<ModuleType, AdrModuleDto> {
	@Override
	public AdrModuleDto convert(ModuleType source) {
		AdrModuleDto dto = new AdrModuleDto();
		dto.setTypeId(source.getId());
		dto.setTypeKey(source.getTranslationKeyString());
		return dto;
	}
}