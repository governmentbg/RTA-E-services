package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.MunicipalityDto;
import bg.demax.eservices.backend.entity.applications.Municipality;

@Component
public class MunicipalityToMunicipalityDto implements Converter<Municipality, MunicipalityDto> {
	
	@Override
	public MunicipalityDto convert(Municipality source) {
		MunicipalityDto dto = new MunicipalityDto();
		dto.setCode(source.getMunicipalityId().getCode());
		dto.setRegionCode(source.getMunicipalityId().getRegion().getCode());
		dto.setKey(source.getTranslationKeyString());
		return dto;
	}
}