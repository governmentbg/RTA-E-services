package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.view.OldCardDto;
import bg.demax.eservices.backend.entity.applications.OldCard;

@Component
public class OldCardDtoToOldCard implements Converter<OldCardDto, OldCard> {
	@Override
	public OldCard convert(OldCardDto source) {
		OldCard dto = new OldCard();
		dto.setCardNumber(source.getCardNumber());
		dto.setDateLost(source.getDate());
		dto.setPlaceLost(source.getPlace());
		dto.setValidity(source.getValidity());
		dto.setCardIssuer(source.getIssuedBy());
		// country to be set by db request

		return dto;
	}
}