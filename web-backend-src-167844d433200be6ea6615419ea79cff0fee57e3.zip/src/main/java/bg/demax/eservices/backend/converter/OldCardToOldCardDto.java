package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.dto.view.OldCardDto;
import bg.demax.eservices.backend.entity.applications.OldCard;

@Component
public class OldCardToOldCardDto implements Converter<OldCard, OldCardDto> {
	@Override
	public OldCardDto convert(OldCard source) {
		OldCardDto dto = new OldCardDto();
		dto.setCardNumber(source.getCardNumber());
		dto.setDate(source.getDateLost());
		dto.setPlace(source.getPlaceLost());
		dto.setValidity(source.getValidity());
		dto.setIssuedBy(source.getCardIssuer());
		TranslationDto issuerCountry = new TranslationDto();
		issuerCountry.setId(source.getCountry().getId());
		issuerCountry.setKey(source.getCountry().getTranslationKeyString());
		dto.setIssuingCountry(issuerCountry);

		return dto;
	}
}