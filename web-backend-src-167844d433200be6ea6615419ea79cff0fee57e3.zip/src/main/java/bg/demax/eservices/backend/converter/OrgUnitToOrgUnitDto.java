package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.OrgUnitDto;
import bg.demax.eservices.backend.entity.applications.OrgUnit;

@Component
public class OrgUnitToOrgUnitDto implements Converter<OrgUnit, OrgUnitDto> {
	
	@Override
	public OrgUnitDto convert(OrgUnit source) {
		OrgUnitDto dto = new OrgUnitDto();
		dto.setAddress(source.getAddress());
		dto.setCityTranslationKey(source.getCity().getTranslationKeyString());
		dto.setCode(source.getCode());
		dto.setName(source.getTranslationKeyString());
		dto.setPhoneNumber(source.getPhoneNumber().getPhoneNumber());
		return dto;
	}
}