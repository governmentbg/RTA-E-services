package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.PaginationQueryParamsDto;

@Component
public class PaginationQueryParamsToPageableConverter implements Converter<PaginationQueryParamsDto, Pageable> {

	@Override
	public Pageable convert(PaginationQueryParamsDto pageParams) {
		Direction orderDirection = pageParams.getDirection().equals(PaginationQueryParamsDto.DIRECTION_DESCENDING) ? Direction.DESC
				: Direction.ASC;

		String orderBy;
		if (pageParams.getOrderBy() != null && !pageParams.getOrderBy().trim().isEmpty()) {
			orderBy = pageParams.getOrderBy().trim();
		} else {
			orderBy = "id";
		}

		return PageRequest.of(pageParams.getPage() - 1, pageParams.getPageSize(), orderDirection, orderBy);
	}

}
