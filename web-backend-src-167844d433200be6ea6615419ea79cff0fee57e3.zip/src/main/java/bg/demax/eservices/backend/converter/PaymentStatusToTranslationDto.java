package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.entity.applications.ApplicationPaymentStatus;

@Component
public class PaymentStatusToTranslationDto implements Converter<ApplicationPaymentStatus, TranslationDto> {

	@Override
	public TranslationDto convert(ApplicationPaymentStatus source) {
		TranslationDto dto = new TranslationDto();
		dto.setId(source.getId());
		dto.setKey(source.getTranslationKeyString());
		return dto;
	}
}