package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.view.PaymentShortDto;
import bg.demax.eservices.backend.entity.applications.Payment;

@Component
public class PaymentToPaymentShortDto implements Converter<Payment, PaymentShortDto> {

	@Override
	public PaymentShortDto convert(Payment source) {
		PaymentShortDto dto = new PaymentShortDto();
		dto.setId(source.getId());
		dto.setPaymentStatusCode(source.getPaymentStatus().getCode());
		dto.setPaymentTypeKey(source.getPaymentType().getTranslationKeyString());
		
		return dto;
	}
}
