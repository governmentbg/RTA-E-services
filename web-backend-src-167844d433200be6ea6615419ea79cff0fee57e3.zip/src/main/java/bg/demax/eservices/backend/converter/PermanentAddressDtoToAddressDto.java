package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import bg.demax.eservices.backend.dto.AddressDto;
import bg.demax.regixclient.mvr.bds.PermanentAddressDto;

@Component
public class PermanentAddressDtoToAddressDto implements Converter<PermanentAddressDto, AddressDto> {

	@Override
	@Transactional
	public AddressDto convert(PermanentAddressDto source) {
		AddressDto dto = new AddressDto();
		dto.setApartment(source.getApartment());
		dto.setEntrance(source.getEntrance());
		dto.setStreet(source.getLocationName());
		dto.setStreetNumber(source.getBuildingNumber());
		return dto;
	}
}