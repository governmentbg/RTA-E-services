package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.view.NamesDto;
import bg.demax.regixclient.mvr.bds.PersonNamesDto;

@Component
public class PersonNamesDtoToNamesDto implements Converter<PersonNamesDto, NamesDto> {

	@Override
	public NamesDto convert(PersonNamesDto source) {
		NamesDto dto = new NamesDto();
		dto.setFirstNameCyr(source.getFirstName());
		dto.setFatherNameCyr(source.getSurname());
		dto.setFamilyNameCyr(source.getFamilyName());
		dto.setFirstNameLat(source.getFirstNameLatin());
		dto.setFatherNameLat(source.getSurnameLatin());
		dto.setFamilyNameLat(source.getLastNameLatin());
		return dto;
	}
}