package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.DrivingLicenceDto;
import bg.demax.regixclient.mvr.bds.PersonalResponseDtoV3;

@Component
public class PersonalResponseDtoV3ToDrivingLicenceDto implements Converter<PersonalResponseDtoV3, DrivingLicenceDto> {

	@Override
	public DrivingLicenceDto convert(PersonalResponseDtoV3 source) {
		DrivingLicenceDto dto = new DrivingLicenceDto();
		dto.setDateOfExpiry(source.getValidUntil());
		dto.setDateOfIssue(source.getIssueDate());
		dto.setDocumentNumber(source.getIdentityDocumentNumber());
		return dto;
	}
}
