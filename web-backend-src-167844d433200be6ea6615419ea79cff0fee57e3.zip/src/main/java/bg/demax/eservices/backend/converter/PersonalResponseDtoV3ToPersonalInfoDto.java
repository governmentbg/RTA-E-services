package bg.demax.eservices.backend.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.PersonalInfoDto;
import bg.demax.eservices.backend.dto.view.NamesDto;
import bg.demax.regixclient.mvr.bds.PersonalResponseDtoV3;

@Component
public class PersonalResponseDtoV3ToPersonalInfoDto implements Converter<PersonalResponseDtoV3, PersonalInfoDto> {

	@Autowired
	private AppConversionService conversionService;

	@Override
	public PersonalInfoDto convert(PersonalResponseDtoV3 source) {
		PersonalInfoDto dto = new PersonalInfoDto();
		dto.setDateOfBirth(source.getBirthDate());
		dto.setDateOfExpiry(source.getValidUntil());
		dto.setDateOfIssue(source.getIssueDate());
		dto.setDocumentNumber(source.getIdentityDocumentNumber());
		dto.setIdentityNumber(source.getEgn());
		dto.setNamesDto(conversionService.convert(source.getPersonNames(), NamesDto.class));
		dto.setPlaceOfBirth(source.getBirthPlace().getCountryName());
		if (source.getBirthPlace().getCountryNameLatin() != null) {
			dto.setPlaceOfBirthLatin(source.getBirthPlace().getCountryNameLatin());
		}
		return dto;
	}
}