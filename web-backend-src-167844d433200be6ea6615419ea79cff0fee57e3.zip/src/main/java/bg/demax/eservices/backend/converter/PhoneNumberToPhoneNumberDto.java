package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.PhoneNumberDto;
import bg.demax.eservices.backend.entity.applications.PhoneNumber;

@Component
public class PhoneNumberToPhoneNumberDto implements Converter<PhoneNumber, PhoneNumberDto> {
	
	@Override
	public PhoneNumberDto convert(PhoneNumber source) {
		PhoneNumberDto dto = new PhoneNumberDto();
		dto.setCountryCodeId(source.getCountryCode().getId());
		dto.setPhoneNumber(source.getPhoneNumber());
		return dto;
	}
}