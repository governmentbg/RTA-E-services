package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.RegionDto;
import bg.demax.eservices.backend.entity.applications.Region;

@Component
public class RegionToRegionDto implements Converter<Region, RegionDto> {
	
	@Override
	public RegionDto convert(Region source) {
		RegionDto dto = new RegionDto();
		dto.setRegionCode(source.getCode());
		dto.setKey(source.getTranslationKeyString());
		return dto;
	}
}