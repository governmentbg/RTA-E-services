package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.RequiredDocumentTypeDto;
import bg.demax.eservices.backend.entity.applications.RequiredDocumentType;

@Component
public class RequiredDocumentTypeToRequiredDocumentTypeDto implements Converter<RequiredDocumentType, RequiredDocumentTypeDto> {

	@Override
	public RequiredDocumentTypeDto convert(RequiredDocumentType source) {
		RequiredDocumentTypeDto dto = new RequiredDocumentTypeDto();
		dto.setId(source.getId());
		dto.setType(source.getTranslationKeyString());
		dto.setValidityMonths(source.getValidityMonths());
		return dto;
	}
}
