package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.RoleDto;
import bg.demax.eservices.backend.entity.security.Role;

@Component
public class RoleToRoleDtoConverter implements Converter<Role, RoleDto> {

	@Override
	public RoleDto convert(Role role) {
		RoleDto dto = new RoleDto();
		dto.setId(role.getId());
		dto.setKey(role.getTranslationKeyString());
		dto.setRole(role.getRole());
		return dto;
	}
}
