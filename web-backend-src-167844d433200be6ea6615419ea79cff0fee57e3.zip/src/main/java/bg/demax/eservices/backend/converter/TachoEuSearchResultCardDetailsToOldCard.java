package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.proxy.tachograph.TachoEuSearchResult.CardDetails;
import bg.demax.eservices.backend.entity.applications.OldCard;

@Component
public class TachoEuSearchResultCardDetailsToOldCard implements Converter<CardDetails, OldCard> {

	@Override
	public OldCard convert(CardDetails source) {
		OldCard oldCard = new OldCard();

		oldCard.setCardIssuer(source.getCardIssuingAuthority());
		oldCard.setCardNumber(source.getCardNumber());
		oldCard.setValidity(source.getCardExpiryDate());
		//country set outside of converter

		return oldCard;
	}
	
}
