package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.proxy.tachograph.TachoLocalSearchResult;
import bg.demax.eservices.backend.entity.applications.OldCard;

@Component
public class TachoLocalSearchResultToOldCard  implements Converter<TachoLocalSearchResult, OldCard> {

	@Override
	public OldCard convert(TachoLocalSearchResult source) {
		OldCard dto = new OldCard();
		dto.setValidity(source.getExpiryDate().toLocalDate());
		dto.setCardNumber(source.getCardNumber());
		return dto;
	}
}
