package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.entity.applications.TrainingType;

@Component
public class TrainingTypeToTranslationDto implements Converter<TrainingType, TranslationDto> {
	@Override
	public TranslationDto convert(TrainingType source) {
		TranslationDto dto = new TranslationDto();
		dto.setId(source.getId());
		dto.setKey(source.getTranslationKeyString());
		return dto;
	}
}
