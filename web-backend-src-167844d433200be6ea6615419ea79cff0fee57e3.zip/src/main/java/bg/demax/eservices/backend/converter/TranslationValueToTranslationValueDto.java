package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.view.TranslationKeyValuesDto;
import bg.demax.eservices.backend.entity.config.Language;
import bg.demax.eservices.backend.entity.config.TranslationValue;

@Component
public class TranslationValueToTranslationValueDto implements Converter<TranslationValue, TranslationKeyValuesDto> {
	
	@Override
	public TranslationKeyValuesDto convert(TranslationValue source) {
		TranslationKeyValuesDto dto = new TranslationKeyValuesDto();
		dto.setTranslationKey(source.getTranslationKey().getKey());
		for (TranslationValue value : source.getTranslationKey().getValues()) {
			if (value.getLanguage().getCode().equals(Language.BULGARIAN_CODE)) {
				dto.setBgTranslation(value.getValue());
			} else {
				dto.setEnTranslation(value.getValue());
			}
		}
		return dto;
	}
}