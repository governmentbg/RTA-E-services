package bg.demax.eservices.backend.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.UserHistoryLogDto;
import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.entity.security.UserHistoryLog;

@Component
public class UserHistoryLogToUserHistoryLogDtoConverter implements Converter<UserHistoryLog, UserHistoryLogDto> {

	@Autowired
	private AppConversionService conversionService;

	@Override
	public UserHistoryLogDto convert(UserHistoryLog historyLog) {
		UserHistoryLogDto dto = new UserHistoryLogDto();
		dto.setId(historyLog.getId());
		dto.setTime(historyLog.getTime());
		dto.setAuthenticationMethod(conversionService.convert(historyLog.getAuthenticationMethod(), TranslationDto.class));
		return dto;
	}
}
