package bg.demax.eservices.backend.converter;

import java.util.HashSet;
import java.util.Set;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.UserDto;
import bg.demax.eservices.backend.entity.security.Role;
import bg.demax.eservices.backend.entity.security.User;

@Component
public class UserToUserDto implements Converter<User, UserDto> {

	@Override
	public UserDto convert(User source) {
		UserDto dto = new UserDto();
		dto.setId(source.getId());
		dto.setUsername(source.getUsername());
		if (source.getEmail() != null) {
			dto.setEmail(source.getEmail().getEmail());
		}
		dto.setIdentityNumber(source.getSubject().getIdentityNumber());
		dto.setIdentityNumberType(source.getSubject().getIdentityNumberType().getType());
		Set<String> roles = new HashSet<>();
		for (Role role : source.getRoles()) {
			roles.add(role.getRole());
		}
		dto.setRoles(roles);
		dto.setVerified(source.isVerified());
		return dto;
	}
}