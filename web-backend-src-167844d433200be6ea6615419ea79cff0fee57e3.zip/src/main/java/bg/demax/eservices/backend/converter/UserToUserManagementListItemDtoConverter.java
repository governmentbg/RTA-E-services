package bg.demax.eservices.backend.converter;

import java.util.List;
import java.util.stream.Collectors;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.RoleDto;
import bg.demax.eservices.backend.dto.UserHistoryLogDto;
import bg.demax.eservices.backend.dto.UserManagementListItemDto;
import bg.demax.eservices.backend.entity.security.User;
import bg.demax.eservices.backend.entity.security.UserHistoryLog;
import bg.demax.eservices.backend.entity.subjects.LegalSubject;
import bg.demax.eservices.backend.entity.subjects.LegalSubjectVersion;
import bg.demax.eservices.backend.entity.subjects.PhysicalSubject;
import bg.demax.eservices.backend.entity.subjects.PhysicalSubjectVersion;
import bg.demax.eservices.backend.entity.subjects.Subject;

@Component
public class UserToUserManagementListItemDtoConverter implements Converter<User, UserManagementListItemDto> {

	@Autowired
	private AppConversionService conversionService;
	
	@Override
	public UserManagementListItemDto convert(User user) {
		Subject subject = user.getSubject();
		subject = (Subject) Hibernate.unproxy(subject);
		
		String fullName = null;
		if (subject instanceof PhysicalSubject) {
			PhysicalSubject physicalSubject = (PhysicalSubject) subject;
			PhysicalSubjectVersion validVersion = physicalSubject.getValidVersion();
			
			if (validVersion != null) {
				fullName = validVersion.getFullName();
			}
		} else if (subject instanceof LegalSubject) {
			LegalSubject legalSubject = (LegalSubject) subject;
			LegalSubjectVersion validVersion = legalSubject.getValidVersion();
			
			if (validVersion != null) {
				fullName = validVersion.getCompanyName();
			}
		} else {
			throw new RuntimeException("Unknown subject type.");
		}
		
		UserManagementListItemDto dto = new UserManagementListItemDto();
		dto.setId(user.getId());
		dto.setIdentityNumber(subject.getIdentityNumber());
		dto.setFullName(fullName);
		if (user.getEmail() != null) {
			dto.setEmail(user.getEmail().getEmail());
		}
		
		if (user.getRoles() != null) {
			List<RoleDto> roles = user.getRoles().stream().map(role -> {
				return conversionService.convert(role, RoleDto.class);
			}).sorted((role1, role2) -> {
				return role1.getId().compareTo(role2.getId());
			}).collect(Collectors.toList());
			dto.setRoles(roles);
		}
		if (user.getUserHistoryLogs() != null && !user.getUserHistoryLogs().isEmpty()) {
			UserHistoryLog lastLoginHistoryLog = user.getUserHistoryLogs().get(0);
			dto.setLastLogin(conversionService.convert(lastLoginHistoryLog, UserHistoryLogDto.class));
		}
		return dto;
	}
}
