package bg.demax.eservices.backend.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.view.WarningDto;
import bg.demax.eservices.backend.entity.applications.Warning;

@Component
public class WarningToWarningDto implements Converter<Warning, WarningDto> {
	@Override
	public WarningDto convert(Warning source) {
		WarningDto dto = new WarningDto();
		dto.setWarningMessageTranslationKey(source.getWarningMessage().getTranslationKeyString());
		dto.setWarningVariableInfo(source.getWarningVariableInfo());
		return dto;
	}		
}
