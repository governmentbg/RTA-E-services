package bg.demax.eservices.backend.converter.exam;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.exam.AdrExamModuleResultDto;
import bg.demax.eservices.backend.dto.exam.AdrExamPersonSelectionDto;
import bg.demax.eservices.backend.http.dto.adr.AdrExamPersonDto;
import bg.demax.eservices.backend.http.dto.adr.AdrExamPersonExamResultDto;

@Component
public class AdrExamPersonDtoToAdrExamPersonSelectionDtoConverter
		implements Converter<AdrExamPersonDto, AdrExamPersonSelectionDto> {

	@Override
	public AdrExamPersonSelectionDto convert(AdrExamPersonDto source) {
		AdrExamPersonSelectionDto dto = new AdrExamPersonSelectionDto();
		dto.setId(source.getId());
		dto.setLearningPlanName(source.getLearningPlanName());
		dto.setLearningPlanSubCategoryIdsCsv(source.getLearningPlanSubCategoryIdsCsv());
		dto.setLearningValidTo(source.getLearningValidTo());
		
		if (source.getExamResults() != null) {
			List<AdrExamModuleResultDto> examModuleResults = convertExamResultsToCompactModuleResults(source.getExamResults());
			dto.setExamModuleResults(examModuleResults);
		} else {
			dto.setExamModuleResults(new LinkedList<>());
		}
		return dto;
	}

	private List<AdrExamModuleResultDto> convertExamResultsToCompactModuleResults(List<AdrExamPersonExamResultDto> examResults) {
		Map<Integer, bg.demax.eservices.backend.http.dto.adr.AdrExamModuleResultDto> moduleSubCategoryIdToResultValueMap 
			= new LinkedHashMap<>();
		for (AdrExamPersonExamResultDto examResult : examResults) {
			for (bg.demax.eservices.backend.http.dto.adr.AdrExamModuleResultDto moduleResult : examResult.getModuleResults()) {
				int moduleSubCategoryId = moduleResult.getModuleSubCategoryId();
				
				Boolean isPassed = moduleResult.getIsPassed();
				
				if (moduleSubCategoryIdToResultValueMap.containsKey(moduleSubCategoryId)) {
					bg.demax.eservices.backend.http.dto.adr.AdrExamModuleResultDto currentModuleResult = 
							moduleSubCategoryIdToResultValueMap.get(moduleSubCategoryId);
					Boolean currentIsPassed = currentModuleResult.getIsPassed();
					
					int isPassedScore = getIsPassedValueScore(isPassed);
					int currentIsPassedScore = getIsPassedValueScore(currentIsPassed);
					if (isPassedScore > currentIsPassedScore) {
						moduleSubCategoryIdToResultValueMap.put(moduleSubCategoryId, currentModuleResult);
					}
				} else {
					moduleSubCategoryIdToResultValueMap.put(moduleSubCategoryId, moduleResult);
				}
			}
		}
		
		List<AdrExamModuleResultDto> moduleResults = new LinkedList<>();
		for (Entry<Integer, bg.demax.eservices.backend.http.dto.adr.AdrExamModuleResultDto> entry 
				: moduleSubCategoryIdToResultValueMap.entrySet()) {
			bg.demax.eservices.backend.http.dto.adr.AdrExamModuleResultDto moduleResult = entry.getValue();
			Boolean isPassed = moduleResult.getIsPassed();
			
			AdrExamModuleResultDto moduleResultDto = new AdrExamModuleResultDto();
			moduleResultDto.setModule(moduleResult.getModule());
			moduleResultDto.setModuleSubCategoryId(moduleResult.getModuleSubCategoryId());
			moduleResultDto.setIsPassed(isPassed);
			moduleResults.add(moduleResultDto);
		}
		return moduleResults;
	}

	private int getIsPassedValueScore(Boolean isPassed) {
		if (isPassed == null) {
			return 0;
		}
		if (isPassed.booleanValue() == false) {
			return 1;
		}
		if (isPassed.booleanValue() == true) {
			return 2;
		}
		throw new IllegalArgumentException();
	}
}
