package bg.demax.eservices.backend.converter.exam;

import java.util.LinkedList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.exam.AdrExamModuleResultDto;
import bg.demax.eservices.backend.dto.exam.AdrExamPersonSelectionDto;
import bg.demax.eservices.backend.entity.applications.AdrExamPerson;
import bg.demax.eservices.backend.entity.applications.AdrExamPersonModuleResult;

@Component
public class AdrExamPersonToAdrExamPersonSelectionDtoConverter implements Converter<AdrExamPerson, AdrExamPersonSelectionDto> {

	@Override
	public AdrExamPersonSelectionDto convert(AdrExamPerson examPerson) {
		AdrExamPersonSelectionDto dto = new AdrExamPersonSelectionDto();
		dto.setId(examPerson.getId());
		dto.setLearningPlanName(examPerson.getLearningPlanName());
		dto.setLearningPlanSubCategoryIdsCsv(examPerson.getLearningPlanSubCategoryIdsCsv());
		dto.setLearningValidTo(null);
		dto.setExamModuleResults(convertExamModuleResults(examPerson.getExamModuleResults()));
		return dto;
	}

	private List<AdrExamModuleResultDto> convertExamModuleResults(List<AdrExamPersonModuleResult> examModuleResults) {
		List<AdrExamModuleResultDto> dtos = new LinkedList<>();
		for (AdrExamPersonModuleResult examModuleResult : examModuleResults) {
			AdrExamModuleResultDto dto = new AdrExamModuleResultDto();
			dto.setModule(examModuleResult.getModule());
			dto.setModuleSubCategoryId(examModuleResult.getModuleSubCategoryId());
			dto.setIsPassed(examModuleResult.getIsPassed());
			dtos.add(dto);
		}
		return dtos;
	}
}
