package bg.demax.eservices.backend.converter.exam;

import org.springframework.beans.BeanUtils;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.exam.AdrExamProtocolSelectionDto;
import bg.demax.eservices.backend.http.dto.adr.AdrExamProtocolDto;

@Component
public class AdrExamProtocolDtoToAdrExamProtocolSelectionDtoConverter
		implements Converter<AdrExamProtocolDto, AdrExamProtocolSelectionDto> {

	@Override
	public AdrExamProtocolSelectionDto convert(AdrExamProtocolDto source) {
		AdrExamProtocolSelectionDto dto = new AdrExamProtocolSelectionDto();
		BeanUtils.copyProperties(source, dto);
		return dto;
	}
}
