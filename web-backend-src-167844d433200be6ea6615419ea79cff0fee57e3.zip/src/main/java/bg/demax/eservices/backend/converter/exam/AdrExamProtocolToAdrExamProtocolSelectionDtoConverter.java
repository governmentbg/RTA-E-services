package bg.demax.eservices.backend.converter.exam;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.exam.AdrExamProtocolSelectionDto;
import bg.demax.eservices.backend.entity.applications.AdrExamProtocol;

@Component
public class AdrExamProtocolToAdrExamProtocolSelectionDtoConverter
		implements Converter<AdrExamProtocol, AdrExamProtocolSelectionDto> {

	@Override
	public AdrExamProtocolSelectionDto convert(AdrExamProtocol source) {
		AdrExamProtocolSelectionDto dto = new AdrExamProtocolSelectionDto();
		dto.setId(source.getAdrProtocolId());
		dto.setExamDateTime(source.getExamDateTime());
		dto.setNumber(source.getNumber());
		dto.setRoomName(source.getRoomName());
		dto.setRemainingSeats(null);
		return dto;
	}
}
