package bg.demax.eservices.backend.converter.exam;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.entity.applications.AdrExamApplication;
import bg.demax.eservices.backend.entity.applications.ConsultantExamApplication;
import bg.demax.eservices.backend.entity.applications.ExamApplication;
import bg.demax.eservices.backend.entity.applications.MotorExamApplication;
import bg.demax.eservices.backend.entity.applications.TaxiDriverExamApplication;
import bg.demax.eservices.backend.vo.exam.AbstractExamApplicationUnenrolmentVo;
import bg.demax.eservices.backend.vo.exam.adr.AdrApplicationUnenrolmentVo;
import bg.demax.eservices.backend.vo.exam.motor.MotorApplicationUnenrolmentVo;

@Component
public class ExamApplicationToAbstractExamApplicationUnenrolmentVoConverter
		implements Converter<ExamApplication, AbstractExamApplicationUnenrolmentVo> {

	private final Log logger = LogFactory.getLog(getClass());
	
	@Override
	public AbstractExamApplicationUnenrolmentVo convert(ExamApplication examApplication) {
		AbstractExamApplicationUnenrolmentVo unenrolmentVo;
		if (examApplication instanceof AdrExamApplication) {
			AdrExamApplication adrExamApplication = (AdrExamApplication) examApplication;
			AdrApplicationUnenrolmentVo adrExamUnenrolmentVo = new AdrApplicationUnenrolmentVo();
			adrExamUnenrolmentVo.setApplicationId(adrExamApplication.getId());
			adrExamUnenrolmentVo.setExamResultId(adrExamApplication.getExamResultId());
			unenrolmentVo = adrExamUnenrolmentVo;
		} else if (examApplication instanceof ConsultantExamApplication) {
			ConsultantExamApplication consultantExamApplication = (ConsultantExamApplication) examApplication;
			AdrApplicationUnenrolmentVo adrExamUnenrolmentVo = new AdrApplicationUnenrolmentVo();
			adrExamUnenrolmentVo.setApplicationId(consultantExamApplication.getId());
			adrExamUnenrolmentVo.setExamResultId(consultantExamApplication.getExamResultId());
			unenrolmentVo = adrExamUnenrolmentVo;
		} else if (examApplication instanceof MotorExamApplication) {
			MotorExamApplication motorExamApplication = (MotorExamApplication) examApplication;
			MotorApplicationUnenrolmentVo adrExamUnenrolmentVo = new MotorApplicationUnenrolmentVo();
			adrExamUnenrolmentVo.setApplicationId(motorExamApplication.getId());
			adrExamUnenrolmentVo.setExamResultId(motorExamApplication.getExamResultId());
			unenrolmentVo = adrExamUnenrolmentVo;
		} else if (examApplication instanceof TaxiDriverExamApplication) {
			TaxiDriverExamApplication taxiDriverExamApplication = (TaxiDriverExamApplication) examApplication;
			MotorApplicationUnenrolmentVo adrExamUnenrolmentVo = new MotorApplicationUnenrolmentVo();
			adrExamUnenrolmentVo.setApplicationId(taxiDriverExamApplication.getId());
			adrExamUnenrolmentVo.setExamResultId(taxiDriverExamApplication.getExamResultId());
			unenrolmentVo = adrExamUnenrolmentVo;
		} else {
			logger.error("Unknown ExamApplication type.");
			throw new RuntimeException("Unknown ExamApplication type.");
		}
		return unenrolmentVo;
	}
}
