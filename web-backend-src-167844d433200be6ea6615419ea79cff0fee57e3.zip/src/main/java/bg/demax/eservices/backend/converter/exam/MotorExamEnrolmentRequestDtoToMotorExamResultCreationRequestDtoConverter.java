package bg.demax.eservices.backend.converter.exam;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.dto.exam.MotorExamEnrolmentRequestDto;
import bg.demax.eservices.backend.http.dto.motor.MotorExamResultCreationRequestDto;

@Component
public class MotorExamEnrolmentRequestDtoToMotorExamResultCreationRequestDtoConverter
		implements Converter<MotorExamEnrolmentRequestDto, MotorExamResultCreationRequestDto> {

	@Override
	public MotorExamResultCreationRequestDto convert(MotorExamEnrolmentRequestDto source) {
		MotorExamResultCreationRequestDto dto = new MotorExamResultCreationRequestDto();
		dto.setExamPersonId(source.getExamPersonId());
		dto.setProtocolId(source.getProtocolId());
		return dto;
	}
}
