package bg.demax.eservices.backend.converter.exam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.converter.AppConversionService;
import bg.demax.eservices.backend.dto.exam.MotorExamPersonSelectionDto;
import bg.demax.eservices.backend.dto.nomenclature.OrgUnitDto;
import bg.demax.eservices.backend.entity.applications.MotorExamPerson;

@Component
public class MotorExamPersonToMotorExamPersonSelectionDtoConverter
		implements Converter<MotorExamPerson, MotorExamPersonSelectionDto> {

	@Autowired
	private AppConversionService conversionService;
	
	@Override
	public MotorExamPersonSelectionDto convert(MotorExamPerson examPerson) {
		MotorExamPersonSelectionDto dto = new MotorExamPersonSelectionDto();
		dto.setExamPersonId(examPerson.getExamPersonId());
		dto.setLearningPlanName(examPerson.getLearningPlanName());
		dto.setOrgUnit(conversionService.convert(examPerson.getOrgUnit(), OrgUnitDto.class));
		dto.setTheoreticalExamResult(examPerson.getTheoreticalExamResult());
		return dto;
	}
}
