package bg.demax.eservices.backend.converter.exam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import bg.demax.eservices.backend.converter.AppConversionService;
import bg.demax.eservices.backend.dto.exam.MotorExamProtocolSelectionDto;
import bg.demax.eservices.backend.dto.nomenclature.OrgUnitDto;
import bg.demax.eservices.backend.entity.applications.MotorExamProtocol;

@Component
public class MotorExamProtocolToMotorExamProtocolSelectionDtoConverter
		implements Converter<MotorExamProtocol, MotorExamProtocolSelectionDto> {

	@Autowired
	private AppConversionService conversionService;
	
	@Override
	public MotorExamProtocolSelectionDto convert(MotorExamProtocol source) {
		MotorExamProtocolSelectionDto dto = new MotorExamProtocolSelectionDto();
		dto.setId(source.getId());
		dto.setExamDateTime(source.getExamDateTime());
		dto.setNumber(source.getNumber());
		dto.setOrgUnit(conversionService.convert(source.getOrgUnit(), OrgUnitDto.class));
		dto.setRoomName(source.getRoomName());
		dto.setRemainingSeats(null);
		return dto;
	}
}
