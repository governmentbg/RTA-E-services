package bg.demax.eservices.backend.dto;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import bg.demax.eservices.backend.dto.nomenclature.CityDto;
import bg.demax.eservices.backend.dto.nomenclature.MunicipalityDto;
import bg.demax.eservices.backend.dto.nomenclature.RegionDto;
import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.validation.ValidAddressDto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ValidAddressDto
public class AddressDto {

	@Valid
	private TranslationDto countryDto;

	@Valid
	private CityDto cityDto;

	@Valid
	private RegionDto regionDto;

	@Valid
	private MunicipalityDto municipalityDto;

	@Min(1)
	@Max(3)
	@NotNull
	private Integer addressTypeId;

	@Size(min = 4, max = 4)
	private String postalCode;

	private String street;
	private String streetNumber;
	private String entrance;
	private String building;
	private String apartment;
}