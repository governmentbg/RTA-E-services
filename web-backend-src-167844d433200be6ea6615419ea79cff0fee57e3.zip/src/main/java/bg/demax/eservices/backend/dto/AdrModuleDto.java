package bg.demax.eservices.backend.dto;

import java.time.LocalDate;

import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdrModuleDto {
	@NotNull
	private Integer typeId;
	
	private String typeKey;

	@Past
	private LocalDate issueDate;

	@Future
	private LocalDate validTo;

	@NotNull
	private Boolean attached;
}