package bg.demax.eservices.backend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicantContactDetailsDto {
	private AddressDto permanentAddress;
	private AddressDto currentAddress;
	private AddressDto otherAddress;
}