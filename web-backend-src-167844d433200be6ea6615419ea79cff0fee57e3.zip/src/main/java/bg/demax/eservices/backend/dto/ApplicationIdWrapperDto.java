package bg.demax.eservices.backend.dto;

import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationIdWrapperDto {

	@NotNull
	private Integer id;
}
