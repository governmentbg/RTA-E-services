package bg.demax.eservices.backend.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationSearchParamsDto {

	@Min(1)
	private Integer applicationId;

	@Min(1)
	@Max(4)
	private Integer authMethodId;

	@Min(1)
	@Max(7)
	private Integer applicationTypeId;

	@PastOrPresent
	@DateTimeFormat(iso = ISO.DATE) // yyyy-MM-dd
	private LocalDate dateFrom;

	@PastOrPresent
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate dateTo;

	@Min(1)
	@Max(3)
	private Integer flagTypeId;

	@Min(1)
	@Max(5)
	private Integer paymentStatusId;

	@Size(min = 2, max = 32)
	private String firstName;

	@Size(min = 2, max = 32)
	private String secondName;

	@Size(min = 2, max = 32)
	private String familyName;

	@Min(1)
	@Max(10)
	private Integer statusId;

	@Size(min = 1, max = 10)
	private String identityNumber;

	@Size(min = 10, max = 30)
	private String deliveryUnitCode;

	public LocalDateTime getDateFrom() {
		if (this.dateFrom != null) {
			return this.dateFrom.atStartOfDay();
		}
		return null;
	}
 
	public LocalDateTime getDateTo() {
		if (this.dateTo != null) {
			return this.dateTo.plusDays(1).atStartOfDay();
		}
		return null;
	}
}
