package bg.demax.eservices.backend.dto;

import java.util.List;

import bg.demax.eservices.backend.entity.fsm.ApplicationProcessStatus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationStatusesWithMilestones {
	private Integer startMilestoneStatusId;
	private Integer endMilestoneStatusId;
	private	List<ApplicationProcessStatus>	allPassedStatuses;
}
