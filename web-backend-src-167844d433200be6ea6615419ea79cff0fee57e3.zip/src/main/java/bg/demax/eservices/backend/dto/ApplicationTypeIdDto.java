package bg.demax.eservices.backend.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationTypeIdDto {
	@Min(1)
	@Max(7)
	@NotNull
	private Integer id;
}
