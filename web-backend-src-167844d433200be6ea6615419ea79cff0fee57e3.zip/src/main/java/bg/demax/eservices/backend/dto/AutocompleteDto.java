package bg.demax.eservices.backend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AutocompleteDto {
	private String phrase;
	private String langCode;
}