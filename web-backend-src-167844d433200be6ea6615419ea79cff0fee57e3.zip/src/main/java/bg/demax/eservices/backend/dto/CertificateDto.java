package bg.demax.eservices.backend.dto;

import java.time.LocalDate;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.PastOrPresent;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
public class CertificateDto {
	@NotNull
	@Min(1)
	@Max(2)
	private Integer typeId;

	private String typeKey;
	
	@NotBlank
	private String permitNumber;
	
	@NotBlank
	private String certificateNumber;
	
	@NotNull
	@Min(1)
	@Max(5)
	private Integer legalBasisId;

	private String legalBasisKey;

	private String legalBasisType;
	
	@NotNull
	@PastOrPresent
	private LocalDate issuedOn;
	
	@NotNull
	@Past
	private LocalDate trainingStart;
	
	@NotNull
	@PastOrPresent
	private LocalDate trainingEnd;

	@NotNull
	private Boolean attached;
}