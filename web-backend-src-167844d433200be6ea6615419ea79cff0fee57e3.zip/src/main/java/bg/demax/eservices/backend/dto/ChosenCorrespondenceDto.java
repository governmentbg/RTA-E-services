package bg.demax.eservices.backend.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChosenCorrespondenceDto {
	private static final String EMAIL_REGEX = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+[.][A-Za-z]+$";

	@Pattern(regexp = EMAIL_REGEX)
	private String email;

	@Valid
	private PhoneNumberDto phoneNumberDto;

	@Valid
	@NotNull
	private AddressDto addressDto;
}