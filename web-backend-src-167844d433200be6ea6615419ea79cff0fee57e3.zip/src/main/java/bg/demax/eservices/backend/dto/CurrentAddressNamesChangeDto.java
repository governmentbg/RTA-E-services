package bg.demax.eservices.backend.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CurrentAddressNamesChangeDto {

	@NotNull
	private Integer applicationId;
	private boolean changedNames;
	private boolean currentAddressSameAsPermanent;
	
	@Valid
	@NotNull
	private AddressDto currentAddress;

	@NotNull
	private Boolean isAuthorizedPerson;
}