package bg.demax.eservices.backend.dto;

import javax.validation.Valid;

import bg.demax.eservices.backend.dto.nomenclature.OrgUnitDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeliveryInfoDto {
	private Integer deliveryTypeId;
	@Valid
	private AddressDto address;
	@Valid
	private OrgUnitDto orgUnitDto;
}
