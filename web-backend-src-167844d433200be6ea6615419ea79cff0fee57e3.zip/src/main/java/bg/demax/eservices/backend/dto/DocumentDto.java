package bg.demax.eservices.backend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentDto {

	private byte[] document;
	private int validityMonths;
}