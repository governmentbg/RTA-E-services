package bg.demax.eservices.backend.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentsDeclarationDto {

	@NotNull
	private boolean declared;
	
	@NotEmpty
	private Integer[] documentTypeIds;
}
