package bg.demax.eservices.backend.dto;

import java.time.LocalDate;
import java.util.Set;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DrivingLicenceDto {

	@NotNull
	private Integer applicationId;

	@NotBlank
	@Size(min = 3, max = 16)
	private String documentNumber;

	private Integer documentIssuerId;

	@NotNull
	private LocalDate dateOfExpiry;

	@NotNull
	@PastOrPresent
	private LocalDate dateOfIssue;

	@NotNull
	private Integer countryId;

	@Valid
	private Set<NewCategoryDto> categories;

	@NotNull
	private Boolean isEditing;

	@JsonProperty("dateOfExpiry")
	public void setDateOfExpiryFromJson(String dateOfExpiry) {
		this.dateOfExpiry =  LocalDate.parse(dateOfExpiry);
	}
	
	@JsonProperty("dateOfIssue")
	public void setDateOfIssueJson(String dateOfIssue) {
		this.dateOfIssue =  LocalDate.parse(dateOfIssue);
	}
}
