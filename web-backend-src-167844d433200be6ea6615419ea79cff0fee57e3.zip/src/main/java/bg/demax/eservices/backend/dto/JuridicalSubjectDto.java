package bg.demax.eservices.backend.dto;

import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JuridicalSubjectDto {

	@NotNull
	private String name;

	@NotNull
	private String address;

	@NotNull
	private String eik;

	@NotNull
	private String vatNumber;
	
}
