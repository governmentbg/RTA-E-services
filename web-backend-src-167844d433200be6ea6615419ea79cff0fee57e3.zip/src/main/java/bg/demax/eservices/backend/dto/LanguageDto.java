package bg.demax.eservices.backend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LanguageDto {
	private String code;
	private String name;
}
