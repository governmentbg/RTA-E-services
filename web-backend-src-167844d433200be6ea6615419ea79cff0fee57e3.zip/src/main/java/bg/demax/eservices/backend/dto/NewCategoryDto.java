package bg.demax.eservices.backend.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NewCategoryDto {
	@NotNull
	private Integer categoryId;
	
	@NotNull
	@PastOrPresent
	private LocalDate startDate;

	@JsonProperty("startDate")
	public void setStartDateFromJson(String startDate) {
		this.startDate =  LocalDate.parse(startDate);
	}
}
