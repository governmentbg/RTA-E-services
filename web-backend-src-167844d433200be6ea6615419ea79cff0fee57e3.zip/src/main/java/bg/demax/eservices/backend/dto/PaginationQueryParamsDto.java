package bg.demax.eservices.backend.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaginationQueryParamsDto {

	public static final String DIRECTION_ASCENDING = "asc";
	public static final String DIRECTION_DESCENDING = "desc";

	@Min(1)
	@NotNull
	private Integer page;

	@Min(10)
	@Max(20)
	private Integer pageSize;

	private String orderBy;

	@NotNull
	@Pattern(regexp = "^(" + DIRECTION_ASCENDING + "|" + DIRECTION_DESCENDING + ")$")
	private String direction = DIRECTION_DESCENDING;
}