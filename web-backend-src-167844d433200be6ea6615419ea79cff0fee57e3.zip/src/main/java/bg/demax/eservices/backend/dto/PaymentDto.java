package bg.demax.eservices.backend.dto;

import java.math.BigDecimal;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentDto {
	@Min(1)
	@Max(2)
	@NotNull
	private Integer paymentTypeId;

	@Min(1)
	@Max(5)
	@NotNull
	private Integer paymentMethodId;

	@Positive
	@NotNull
	private BigDecimal amount;

	private JuridicalSubjectDto juridicalSubject;

}
