package bg.demax.eservices.backend.dto;


import java.time.LocalDate;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.dto.view.NamesDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PersonalInfoDto {
	@NotNull
	private Integer applicationId;

	@NotBlank
	@Size(min = 10, max = 10)
	private String identityNumber;

	@NotBlank
	private String placeOfBirth;

	@NotBlank
	private String placeOfBirthLatin;
	
	@NotBlank
	@Size(min = 9, max = 30)
	private String documentNumber;

	@NotNull
	private TranslationDto identityDocumentType;

	@NotNull
	private TranslationDto documentIssuer;
	
	@NotNull
	private LocalDate dateOfExpiry;
	
	@NotNull
	@PastOrPresent
	private LocalDate dateOfIssue;
	
	@NotNull
	@Past
	private LocalDate dateOfBirth;
	
	@NotNull
	private TranslationDto nationality;

	@Valid
	@NotNull
	private NamesDto namesDto;

	private boolean currentAddressSameAsPermanent;
	
	@Valid
	@NotNull
	private AddressDto permanentAddressDto;
	
	@Valid
	@NotNull
	private AddressDto currentAddressDto;

	private boolean changedNames;

	@NotNull
	private Boolean isAuthorizedPerson;

	@NotNull
	private Boolean isEditing;

	private Boolean hasGraoCheck;
	
	private TranslationDto gender;

	@JsonProperty("dateOfExpiry")
	public void setDateOfExpiryFromJson(String dateOfExpiry) {
		this.dateOfExpiry =  LocalDate.parse(dateOfExpiry);
	}

	@JsonProperty("dateOfIssue")
	public void setDateOfIssueFromJson(String dateOfIssue) {
		this.dateOfIssue =  LocalDate.parse(dateOfIssue);
	}

	@JsonProperty("dateOfBirth")
	public void setBirthDateFromJson(String dateOfBirth) {
		this.dateOfBirth =  LocalDate.parse(dateOfBirth);
	}
}