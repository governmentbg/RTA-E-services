package bg.demax.eservices.backend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PictureDto {
	private String name;
	private byte[] bytes;
}
