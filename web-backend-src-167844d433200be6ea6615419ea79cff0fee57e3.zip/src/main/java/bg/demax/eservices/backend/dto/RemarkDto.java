package bg.demax.eservices.backend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RemarkDto {
	private Integer remarkTypeId;
	private String message;
}