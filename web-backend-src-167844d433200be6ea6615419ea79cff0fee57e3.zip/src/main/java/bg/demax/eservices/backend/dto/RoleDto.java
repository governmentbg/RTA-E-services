package bg.demax.eservices.backend.dto;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoleDto extends TranslationDto {

	private String role;
}
