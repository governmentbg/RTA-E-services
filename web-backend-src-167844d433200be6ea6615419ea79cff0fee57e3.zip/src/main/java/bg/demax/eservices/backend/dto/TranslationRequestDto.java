package bg.demax.eservices.backend.dto;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TranslationRequestDto {

	@NotBlank
	private String translationKey;

	@NotBlank
	private String bgTranslationValue;

	@NotBlank
	private String enTranslationValue;
}
