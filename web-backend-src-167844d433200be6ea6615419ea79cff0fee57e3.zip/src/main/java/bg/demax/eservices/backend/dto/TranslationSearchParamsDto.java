package bg.demax.eservices.backend.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TranslationSearchParamsDto {

	private String key;
	private String bg;
	private String en;
}
