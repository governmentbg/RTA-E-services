package bg.demax.eservices.backend.dto;

import java.util.Set;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDto {
	private int id;
	private String identityNumber;
	private String identityNumberType;
	private String fullNameCyr;
	private String fullNameLat;
	private String username;
	private String email;
	private Set<String> roles;
	private boolean isVerified;
	private String authMethodKey;
}