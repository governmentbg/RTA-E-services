package bg.demax.eservices.backend.dto;

import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserHistoryLogDto {

	private Integer id;

	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDateTime time;

	private TranslationDto authenticationMethod;
}
