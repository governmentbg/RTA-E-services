package bg.demax.eservices.backend.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserManagementListItemDto {

	private Integer id;
	private String identityNumber;
	private String fullName;
	private String email;
	private List<RoleDto> roles;
	private UserHistoryLogDto lastLogin;
}
