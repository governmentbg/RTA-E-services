package bg.demax.eservices.backend.dto.captcha;

import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationCheckParams {

	@NotNull
	private Integer applicationId;
	@NotNull
	private String reCaptchaResponse;
}
