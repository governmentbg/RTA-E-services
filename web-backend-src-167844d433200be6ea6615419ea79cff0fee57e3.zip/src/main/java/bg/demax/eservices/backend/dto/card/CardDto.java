package bg.demax.eservices.backend.dto.card;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.dto.view.NamesDto;
import bg.demax.eservices.backend.dto.view.OldCardDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CardDto {
	@Valid
	private OldCardDto oldCardDto;

	@Valid
	private NamesDto personNamesDto;

	@NotNull
	private TranslationDto issuingReason;
}