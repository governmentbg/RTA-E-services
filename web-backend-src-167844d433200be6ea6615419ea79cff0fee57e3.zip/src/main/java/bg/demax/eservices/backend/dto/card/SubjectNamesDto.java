package bg.demax.eservices.backend.dto.card;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubjectNamesDto {
	@NotBlank
	private String firstNameCyr;
	private String fathersNameCyr;
	private String familyNameCyr;
	
	@NotBlank
	private String firstNameLat;
	private String fathersNameLat;
	private String familyNameLat;
}
