package bg.demax.eservices.backend.dto.exam;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdrExamPersonSelectionDto {

	private Long id;

	private String learningPlanName;
	private String learningPlanSubCategoryIdsCsv;
	
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDateTime learningValidTo;

	private List<AdrExamModuleResultDto> examModuleResults;
}
