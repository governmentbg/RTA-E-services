package bg.demax.eservices.backend.dto.exam;

import java.time.LocalDate;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class AdrExamProtocolsResponseDto {

	private LocalDate fromDate;
	private LocalDate toDate;
	private Integer minExamDayFromTodayForLongPayment;
	private List<AdrExamProtocolSelectionDto> protocols;
}
