package bg.demax.eservices.backend.dto.exam;

import bg.demax.eservices.backend.dto.nomenclature.OrgUnitDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MotorExamPersonSelectionDto {

	private Long examPersonId;
	private OrgUnitDto orgUnit;
	private String learningPlanName;
	private String theoreticalExamResult;
}
