package bg.demax.eservices.backend.dto.exam;

import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import bg.demax.eservices.backend.dto.nomenclature.OrgUnitDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MotorExamProtocolSelectionDto {

	private Long id;
	private String number;
	
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDateTime examDateTime;
	
	private OrgUnitDto orgUnit;
	private String roomName;
	private Integer remainingSeats;
}
