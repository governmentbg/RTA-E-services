package bg.demax.eservices.backend.dto.exam;

import java.time.LocalDate;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MotorExamProtocolsResponseDto {

	private LocalDate fromDate;
	private LocalDate toDate;
	private Integer minExamDayFromTodayForLongPayment;
	private List<MotorExamProtocolSelectionDto> protocols;
}
