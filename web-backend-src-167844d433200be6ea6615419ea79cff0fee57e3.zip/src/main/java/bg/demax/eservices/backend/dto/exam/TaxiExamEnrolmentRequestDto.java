package bg.demax.eservices.backend.dto.exam;

import java.time.LocalDate;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaxiExamEnrolmentRequestDto {

	@NotBlank
	private String orgUnitCode;

	@NotBlank
	private String municipalityCode;

	@NotNull
	@Min(1)
	private Long protocolId;

	@NotBlank
	private String criminalRecordCertificateNumber;

	@NotNull
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate criminalRecordCertificateIssueDate;

	@NotBlank
	private String certificateOfPsychologicalFitnessNumber;

	@NotNull
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate certificateOfPsychologicalFitnessIssueDate;
}
