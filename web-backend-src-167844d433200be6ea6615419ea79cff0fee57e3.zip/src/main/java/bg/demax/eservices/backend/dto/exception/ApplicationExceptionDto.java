package bg.demax.eservices.backend.dto.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationExceptionDto {
	private String error;
	private String message;
}
