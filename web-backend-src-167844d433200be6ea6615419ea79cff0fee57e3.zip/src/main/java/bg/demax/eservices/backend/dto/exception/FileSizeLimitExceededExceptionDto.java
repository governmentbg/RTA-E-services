package bg.demax.eservices.backend.dto.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FileSizeLimitExceededExceptionDto extends SizeLimitExceededExceptionDto {

	public FileSizeLimitExceededExceptionDto(long maxUploadSize) {
		super(maxUploadSize);
		this.setError("FileSizeLimitExceededException");
		this.setMessage("The size of one file can not exceed " + this.getMaxSize());
	}
}