package bg.demax.eservices.backend.dto.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SizeLimitExceededExceptionDto extends ApplicationExceptionDto {

	private static final long ONE_MB = 1048576;

	private String maxSize;

	public SizeLimitExceededExceptionDto(long maxSizeInBytes) {
		this.maxSize = (maxSizeInBytes / ONE_MB) + "MB";
		this.setError("SizeLimitExceededException");
		this.setMessage("The size of all files can not exceed " + this.getMaxSize());
	}
}