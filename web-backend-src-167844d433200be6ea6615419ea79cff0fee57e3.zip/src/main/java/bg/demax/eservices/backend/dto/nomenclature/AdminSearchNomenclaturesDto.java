package bg.demax.eservices.backend.dto.nomenclature;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminSearchNomenclaturesDto {
	private List<TranslationDto> authMethods;
	private List<TranslationDto> applicationTypes;
	private List<TranslationDto> paymentStatuses;	
	private List<TranslationDto> generalStatuses;	
	private List<String> deliveryKeys;
}