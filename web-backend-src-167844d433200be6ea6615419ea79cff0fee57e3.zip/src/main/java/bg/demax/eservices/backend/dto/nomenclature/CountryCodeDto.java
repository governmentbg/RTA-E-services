package bg.demax.eservices.backend.dto.nomenclature;

import lombok.Setter;

import lombok.Getter;

@Getter
@Setter
public class CountryCodeDto {
	private Integer id;
	private String code;
	private String countryTranslationKey;
	private String countryCode2;
}
