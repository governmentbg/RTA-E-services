package bg.demax.eservices.backend.dto.nomenclature;

import lombok.Setter;
import lombok.Getter;

@Getter
@Setter
public class CountryDto {
	private TranslationDto country;
	private boolean isEu;
}