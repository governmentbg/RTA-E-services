package bg.demax.eservices.backend.dto.nomenclature;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DqcCertificateNomenclaturesDto {
	List<TranslationDto> legalBasisTypes;
	List<TranslationDto> certificateTypes;
}