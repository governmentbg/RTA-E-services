package bg.demax.eservices.backend.dto.nomenclature;

import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MunicipalityDto {

	@Size(min = 1, max = 5)
	private String code;
	
	@Size(min = 1, max = 5)
	private String regionCode;
	
	private String key;
}