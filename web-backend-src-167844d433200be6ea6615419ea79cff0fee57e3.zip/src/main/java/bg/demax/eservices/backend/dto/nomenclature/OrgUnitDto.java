package bg.demax.eservices.backend.dto.nomenclature;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrgUnitDto {

	private String code;
	
	//TODO: remove when frontend is ready and uses the translation key
	@NotBlank
	private String name;
	
	@NotBlank
	private String cityTranslationKey;

	@NotBlank
	private String address;

	@NotBlank
	private String phoneNumber;
}
