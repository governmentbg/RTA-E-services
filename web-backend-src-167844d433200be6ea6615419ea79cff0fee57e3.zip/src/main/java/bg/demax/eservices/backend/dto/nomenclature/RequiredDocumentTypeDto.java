package bg.demax.eservices.backend.dto.nomenclature;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RequiredDocumentTypeDto {

	private Integer id;
	private String type;
	private Integer validityMonths;
}