package bg.demax.eservices.backend.dto.nomenclature;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubCategoryDto {
	private int id;
	private String subCategory;
	private String category;
}
