package bg.demax.eservices.backend.dto.pdfsignature;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PdfDigitalSignatureVerificationResponseDto {

	public static final int VALID_CODE = 0;
	public static final int INVALID_PUBLISHER_CODE = 1;
	public static final int APPLICATION_NOT_TRUSTED_CERTIFICATE_CODE = 2;
	public static final int INVALID_SIGNATURE_CODE = 3;
	public static final int CERTIFICATE_CHAIN_VERIFICATION_ERROR_CODE = 4;
	
	private PdfDigitalSignatureCertificateDto certificate = null;
	private Boolean valid = null;
	private Integer code = null;
}