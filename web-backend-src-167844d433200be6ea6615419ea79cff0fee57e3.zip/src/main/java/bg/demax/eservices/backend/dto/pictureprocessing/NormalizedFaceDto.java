package bg.demax.eservices.backend.dto.pictureprocessing;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NormalizedFaceDto {
	private String image;
	private Double margin;
}