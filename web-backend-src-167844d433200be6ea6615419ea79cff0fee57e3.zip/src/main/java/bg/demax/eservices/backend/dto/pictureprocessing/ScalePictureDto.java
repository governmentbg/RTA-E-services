package bg.demax.eservices.backend.dto.pictureprocessing;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ScalePictureDto {
	private String image;
	private Integer topX;
	private Integer topY;
	private Integer srcWidth;
	private Integer srcHeight;
	private Integer dstWidth;
	private Integer dstHeight;
}