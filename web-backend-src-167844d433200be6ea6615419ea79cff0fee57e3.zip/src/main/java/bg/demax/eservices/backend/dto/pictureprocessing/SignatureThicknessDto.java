package bg.demax.eservices.backend.dto.pictureprocessing;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SignatureThicknessDto {
	private String image;
	private String mode;
}