package bg.demax.eservices.backend.dto.proxy.adr;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class AdrCardCreationRequestDto {

	private String incomingNumber;
	private String identityNumber;
	private String orgUnitCode;
	private String face;
	private String signature;
	private List<Integer> certificateRemarkTypeIds; // -optional skip if there are none
}
