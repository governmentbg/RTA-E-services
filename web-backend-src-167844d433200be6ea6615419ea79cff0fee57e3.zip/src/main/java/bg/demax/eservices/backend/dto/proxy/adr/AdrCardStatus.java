package bg.demax.eservices.backend.dto.proxy.adr;

import java.util.Arrays;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum AdrCardStatus {
	BLOCKED("blocked"), 
	EXPIRED("expired"), 
	INPERSO("inperso"), 
	INPRINT("inprint"), 
	INQA("inqa"),
	PERSONALISED("personalized"),
	STOLEN("stolen"), 
	SUBMITTED("submitted"), 
	WORKING("working");

	public static final List<AdrCardStatus> VALID_STATUSES = Arrays.asList(
		PERSONALISED, STOLEN, BLOCKED);

	public static final List<AdrCardStatus> VALID_STATUSES_APPROVER = Arrays.asList(
		PERSONALISED, STOLEN, BLOCKED, EXPIRED);

	public static final List<AdrCardStatus> STATUSES_IN_PROGRESS = Arrays.asList(
		INPERSO, INPRINT, INQA, SUBMITTED, WORKING);

	private String text;

	public static AdrCardStatus fromString(String text) {
		for (AdrCardStatus adrCardStatus : AdrCardStatus.values()) {
			if (adrCardStatus.text.equalsIgnoreCase(text)) {
				return adrCardStatus;
			}
		}
		return null;
	}

}
