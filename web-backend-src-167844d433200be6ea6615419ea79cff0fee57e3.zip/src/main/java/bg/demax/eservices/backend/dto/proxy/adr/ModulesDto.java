package bg.demax.eservices.backend.dto.proxy.adr;

import java.time.LocalDate;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ModulesDto {
	private LocalDate validTo;
	private List<String> moduleValidities;
}
