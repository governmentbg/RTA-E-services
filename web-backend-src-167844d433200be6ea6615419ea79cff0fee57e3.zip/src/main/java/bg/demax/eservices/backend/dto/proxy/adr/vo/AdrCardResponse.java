package bg.demax.eservices.backend.dto.proxy.adr.vo;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdrCardResponse {
	private String number;
	private List<String> categories;
	private String state;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate issueDate;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate validTo;
	
}