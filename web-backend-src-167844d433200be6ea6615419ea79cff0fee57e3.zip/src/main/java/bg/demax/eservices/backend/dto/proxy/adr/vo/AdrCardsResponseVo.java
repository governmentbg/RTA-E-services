package bg.demax.eservices.backend.dto.proxy.adr.vo;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdrCardsResponseVo {
	private List<AdrCardResponse> cards;
}