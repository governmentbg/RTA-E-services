package bg.demax.eservices.backend.dto.proxy.dqc;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CargoCertDto extends DqcCardCertificateDto {

}
