package bg.demax.eservices.backend.dto.proxy.dqc;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CertificateResponseDto {
	private String fullName;
	private String certificateNumber;
	private String certificationType;
	private String legalBasis;
	private String companyFullName;
	private Integer permitNumber;
		
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	private LocalDateTime certificateDate;
	
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	private LocalDateTime trainingStartDate;
	
	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	private LocalDateTime trainingEndDate;

	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	private LocalDateTime permitIssueDate;

	@JsonProperty("trainingTypeDuration")
	public void setLegalBasis(String trainingTypeDuration) {
		this.legalBasis = trainingTypeDuration;
	}
}
