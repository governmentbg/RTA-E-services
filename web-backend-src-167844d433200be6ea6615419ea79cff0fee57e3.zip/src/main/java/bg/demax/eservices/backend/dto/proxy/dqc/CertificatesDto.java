package bg.demax.eservices.backend.dto.proxy.dqc;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CertificatesDto {
	private List<CertificateResponseDto> certificates;
}
