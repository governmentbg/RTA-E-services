package bg.demax.eservices.backend.dto.proxy.dqc;

import java.time.LocalDate;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DqcCardCertificateDto {
	
	private String issuerNumber;
	private String certType;
	private String issuer;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate startDate;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate endDate;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize
	private LocalDate issueDate;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate validTo;
	
}
