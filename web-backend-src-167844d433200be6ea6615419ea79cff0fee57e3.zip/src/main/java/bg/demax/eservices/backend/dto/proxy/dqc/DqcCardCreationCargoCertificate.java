package bg.demax.eservices.backend.dto.proxy.dqc;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DqcCardCreationCargoCertificate {

	private String issuerNumber;
	private String issuer;
	private String certType;
	private LocalDate startDate;
	private LocalDate endDate;
	private LocalDate issueDate;
	private LocalDate validTo;
}
