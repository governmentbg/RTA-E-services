package bg.demax.eservices.backend.dto.proxy.dqc;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DqcCardCreationPersonDto {

	private String personalNumber;
	private String personalNumberType;
	private String birthPlace;
	private String birthPlaceCyr;
	private LocalDate birthDate;
}
