package bg.demax.eservices.backend.dto.proxy.dqc;

import java.time.LocalDate;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DqcCardCreationRequestDto {

	private String firstName;
	private String firstNameCyr;
	private String surName;
	private String surNameCyr;
	private String fathersName;
	private String fathersNameCyr;
	private String categoriesC;
	private String categoriesD;
	private String residenceAddress;
	private String postalDistrict;
	private String postalCity;
	private String postalAddress;
	private String phone;
	private String email;
	private String licenseNumber;
	private String licenseIssuer;
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate licenseIssueDate;
	
	private String passNumber;
	private String passIssuer;
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate passIssueDate;
	
	private String description;
	private String residenceDistrict;
	private String residenceCity;
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate issueDate;
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate catsCDate;
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate catsDDate;
	private DqcCardCreationPersonDto person;
	private byte[] face;
	private byte[] signature;
	private DqcCardCreationCargoCertificate cargoCertificate;
	private DqcCardCreationPassengerCertificate passengerCertificate;
}
