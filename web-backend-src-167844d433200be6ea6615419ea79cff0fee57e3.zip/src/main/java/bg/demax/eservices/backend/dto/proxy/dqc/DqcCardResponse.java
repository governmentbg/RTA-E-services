package bg.demax.eservices.backend.dto.proxy.dqc;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DqcCardResponse {
	private String firstNameCyr;
	private String fathersNameCyr;
	private String surNameCyr;
	private String birthPlaceCyr;
	private String seqNumber;
	private CargoCertDto cargoCertDto;
	private PassengerCertDto passengerCertDto;
	private String state;
	
	@JsonProperty("cCats")
	private String cCategories;

	@JsonProperty("dCats")
	private String dCategories;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate validTo;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate birthDate;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate issueDate;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate cCatsDate;
	
	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate dCatsDate;
	
}
