package bg.demax.eservices.backend.dto.proxy.dqc;

import java.time.LocalDate;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OldDqcCardDto {

	private String number;
	private LocalDate issuedOn;
	private LocalDate validTo;
	private String status;
	private List<SimpleDqcCertDto> certificates;
}
