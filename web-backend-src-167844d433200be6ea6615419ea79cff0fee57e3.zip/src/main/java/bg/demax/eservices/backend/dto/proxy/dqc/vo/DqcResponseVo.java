package bg.demax.eservices.backend.dto.proxy.dqc.vo;

import java.util.List;

import bg.demax.eservices.backend.dto.proxy.dqc.DqcCardResponse;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DqcResponseVo {
	private List<DqcCardResponse> cards;
}