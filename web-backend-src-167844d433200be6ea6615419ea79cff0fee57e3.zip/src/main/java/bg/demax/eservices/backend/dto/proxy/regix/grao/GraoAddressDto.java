package bg.demax.eservices.backend.dto.proxy.regix.grao;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GraoAddressDto {
	private GraoPlaceDto oblast;
	private GraoPlaceDto obstina;
	private GraoPlaceDto place;
	private GraoPlaceDto street;
	private String number;
	private String entrance;
	private String floor;
	private String apartment;
	private String regDate;

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (this == null || object == null) {
			return false;
		}
		if (this.getClass() != object.getClass()) {
			return false;
		}

		GraoAddressDto otherAddress = (GraoAddressDto) object;
		if ((this.oblast == null ? otherAddress.oblast == null : this.oblast.equals(otherAddress.oblast))
			&& (this.obstina == null ? otherAddress.obstina == null : this.obstina.equals(otherAddress.obstina)) 
			&& (this.place == null ? otherAddress.place == null : this.place.equals(otherAddress.place))
			&& (this.street == null ? otherAddress.street == null : this.street.equals(otherAddress.street))
			&& this.number == otherAddress.number
			&& this.entrance == otherAddress.entrance
			&& this.floor == otherAddress.floor
			&& this.apartment == otherAddress.apartment ) {
			return true;
		}
		return false;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((oblast == null) ? 0 : oblast.hashCode());
		result = prime * result + ((obstina == null) ? 0 : obstina.hashCode());
		result = prime * result + ((place == null) ? 0 : place.hashCode());
		result = prime * result + ((number == null) ? 0 : number.hashCode());
		result = prime * result + ((entrance == null) ? 0 : entrance.hashCode());
		result = prime * result + ((floor == null) ? 0 : floor.hashCode());
		result = prime * result + ((apartment == null) ? 0 : apartment.hashCode());
		return result;
	}



}
