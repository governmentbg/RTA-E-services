package bg.demax.eservices.backend.dto.proxy.regix.grao;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GraoBirthData {
	private GraoPlaceDto country;
	private GraoPlaceDto place;
	private LocalDateTime date;
}
