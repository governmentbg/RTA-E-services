package bg.demax.eservices.backend.dto.proxy.regix.grao;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GraoNamesDto {
	private String first;
	private String middle;
	private String last;
}
