package bg.demax.eservices.backend.dto.proxy.regix.grao;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GraoPersonResponseDto {
	private String egn;
	private GraoNamesDto names;
	private GraoBirthData birthData;
	private GraoPlaceDto nationality;
	private GraoAddressDto residenceAddress;
	private GraoAddressDto currentAddress;
}
