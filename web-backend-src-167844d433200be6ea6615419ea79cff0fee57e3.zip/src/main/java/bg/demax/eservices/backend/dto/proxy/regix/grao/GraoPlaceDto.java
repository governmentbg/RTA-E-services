package bg.demax.eservices.backend.dto.proxy.regix.grao;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GraoPlaceDto {
	private String code;
	private String text;

	@Override
	public boolean equals(Object object) {
		if (this == object) { 
			return true;
		}
		if (this == null || object == null) {
			return false;
		}
		if (this.getClass() != object.getClass()) {
			return false;
		}
		GraoPlaceDto otherPlace = (GraoPlaceDto) object;
		if (this.code == null) {
			if (otherPlace.code != null) {
				return false;
			}
		} else if (otherPlace.code == null) {
			if (this.code != null) {
				return false;
			}
		}
		if (this.code.equals(otherPlace.code)) {
			return true;
		}
		return false;
	}
	
	@Override
	public int hashCode() {
		int result = 17;
		result = 31 * result + ((code == null) ? 0 : code.hashCode());
		return result;
	}
}
