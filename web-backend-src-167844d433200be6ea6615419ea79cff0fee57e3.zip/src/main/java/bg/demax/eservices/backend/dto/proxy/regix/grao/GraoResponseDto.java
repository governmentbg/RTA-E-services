package bg.demax.eservices.backend.dto.proxy.regix.grao;

import bg.demax.eservices.backend.exception.proxy.RemoteServiceExceptionDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GraoResponseDto  {
	private String status;
	private GraoPersonResponseDto person;
	private RemoteServiceExceptionDto remoteExceptionDto;
}
