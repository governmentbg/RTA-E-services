package bg.demax.eservices.backend.dto.proxy.regix.mvr;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class InvalidDocumentFromMvrDto {

	private String error;
	private String status;
	private LocalDate date;
	private String statusReason; 
	
}
