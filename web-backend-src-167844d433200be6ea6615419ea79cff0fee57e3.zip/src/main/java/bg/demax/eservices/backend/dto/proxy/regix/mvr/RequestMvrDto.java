package bg.demax.eservices.backend.dto.proxy.regix.mvr;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonGetter;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RequestMvrDto {

	@Size(min = 10, max = 10)
	@NotBlank
	private String identityNumber;

	@Size(min = 9, max = 9)
	@NotBlank
	private String documentNumber;

	@NotNull
	private TranslationDto identityDocumentType;

	@Min(1)
	@NotNull
	private Integer applicationId;

	private TranslationDto nationality;

	@NotNull
	private Boolean isAuthorizedPerson;

	private boolean isWithLnch;

	private boolean isForeignerWithEgn;

	public boolean isBulgarianWithEgnAndDocumentNumber() {
		return !isForeignerWithEgn && !isWithLnch;
	}

	@JsonGetter("isAuthorizedPerson")
	public Boolean getIsAuthorizedPerson() {
		return isAuthorizedPerson;
	}
	
	@JsonGetter("isWithLnch")
	public Boolean getIsWithLnch() {
		return isWithLnch;
	}
}
