package bg.demax.eservices.backend.dto.proxy.regix.nap;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContractDto {
	LocalDate startDate;
	LocalDate endDate;
	LocalDate timeLimit;
	String professionCode;
	String professionName;
}
