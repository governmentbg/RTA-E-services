package bg.demax.eservices.backend.dto.proxy.regix.nap;

import java.util.List;

import bg.demax.regixclient.nra.employmentcontracts.StatusTypeDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NapResponseDto  {
	private StatusTypeDto statusTypeDto;
	private List<ContractDto> activeContractDtos;
}