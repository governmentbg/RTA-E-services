package bg.demax.eservices.backend.dto.proxy.regix.nap;

import bg.demax.regixclient.mvr.bds.CallContextDto;
import bg.demax.regixclient.nra.employmentcontracts.IdentityTypeRequestDto;
import bg.demax.regixclient.nra.employmentcontracts.ContractsFilterTypeDto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PersonalNapIdentityDto {
	private IdentityTypeRequestDto identity;
	private CallContextDto callContext;
	private ContractsFilterTypeDto contractsFilter;
}
