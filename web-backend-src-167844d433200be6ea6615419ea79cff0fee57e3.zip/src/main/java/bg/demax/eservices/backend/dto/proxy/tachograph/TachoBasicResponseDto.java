package bg.demax.eservices.backend.dto.proxy.tachograph;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TachoBasicResponseDto {
	private String status;
	private String message;
}
