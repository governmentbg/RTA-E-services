package bg.demax.eservices.backend.dto.proxy.tachograph;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TachoCardRequest {
	private String reqType;
	private String reasonForReplacement;
	private Boolean isTemporary;
	private String cardNumber;
	private String cardLanguage;
	private String startOfValidityDate;
	private String expiryDate;
	private TachoRequestAddressDto deliveryAddres;
	private TachoPersonDetailsDto person;
}
