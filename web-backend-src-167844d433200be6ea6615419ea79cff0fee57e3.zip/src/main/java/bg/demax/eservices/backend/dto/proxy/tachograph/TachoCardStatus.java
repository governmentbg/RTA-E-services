package bg.demax.eservices.backend.dto.proxy.tachograph;

import java.util.Arrays;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum TachoCardStatus {
	APPLICATION("Application"),
	APPROVED("Approved"),
	CONFISCATED("Confiscated"), 
	DISPATCHED("Dispatched"),
	EXCHANGED("Exchanged"), 
	EXPIRED("Expired"), 
	HANDED_OVER("HandedOver"), 
	IN_EXCHANGE("InExchange"), 
	LOST("Lost"),
	MALFUNCTIONING("Malfunctioning"), 
	PERSONALISED("Personalised"), 
	REPLACED("Replaced"), 
	RENEWED("Renewed"),
	STOLEN("Stolen"), 
	SURRENDERED("Surrendered"), 
	SUSPENDED("Suspended"), 
	WITHDRAWN("Withdrawn"), 
	REJECTED("Rejected");

	public static final List<TachoCardStatus> VALID_STATUSES = Arrays.asList(
		HANDED_OVER, IN_EXCHANGE, LOST, STOLEN, MALFUNCTIONING, SUSPENDED, CONFISCATED);

	public static final List<TachoCardStatus> VALID_STATUSES_APPROVER = Arrays.asList(
		HANDED_OVER, IN_EXCHANGE, LOST, STOLEN, MALFUNCTIONING, SUSPENDED, CONFISCATED, EXPIRED);

	public static final List<TachoCardStatus> STATUSES_IN_PROGRESS = Arrays.asList(
		APPLICATION, APPROVED, PERSONALISED, DISPATCHED);

	public static final List<TachoCardStatus> LOST_OR_STOLEN = Arrays.asList(LOST, STOLEN);
	public static final List<TachoCardStatus> SUSPENDED_CONFISCATED_OR_MALFUNCTIONING = Arrays.asList(
		SUSPENDED, CONFISCATED, MALFUNCTIONING);

	public static final List<TachoCardStatus> VALID_STATUSES_RENEWAL = Arrays.asList(HANDED_OVER, MALFUNCTIONING);
	public static final List<TachoCardStatus> VALID_STATUSES_REPLACEMENT = Arrays.asList(LOST, STOLEN, MALFUNCTIONING);

	private String text;

	//ТODO this does not work; has to be fixed if it's going to be used
	public static TachoCardStatus fromString(String text) {
		for (TachoCardStatus tachoCardStatus : TachoCardStatus.values()) {
			if (tachoCardStatus.text.equalsIgnoreCase(text)) {
				return tachoCardStatus;
			}
		}
		return null;
	}

}
