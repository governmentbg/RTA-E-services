package bg.demax.eservices.backend.dto.proxy.tachograph;

import lombok.AllArgsConstructor;
import lombok.Getter;


@AllArgsConstructor
@Getter
public enum TachoEuResponseStatus {
	FOUND("Found"),
	NOT_FOUND("NotFound"),
	TIMEOUT("Timeout"),
	NOT_AVAILABLE("NotAvailable");



	private String text;

	public static TachoEuResponseStatus fromString(String text) {
		for (TachoEuResponseStatus tachoResponseStatus : TachoEuResponseStatus.values()) {
			if (tachoResponseStatus.text.equalsIgnoreCase(text)) {
				return tachoResponseStatus;
			}
		}
		return null;
	}
	
}
