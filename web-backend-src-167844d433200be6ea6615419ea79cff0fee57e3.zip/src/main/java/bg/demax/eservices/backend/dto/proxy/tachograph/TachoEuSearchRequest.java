package bg.demax.eservices.backend.dto.proxy.tachograph;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TachoEuSearchRequest {
	private String to;
	private String businessCaseId;
	private String requestPurpose;
	private String requestSource;
	private List<CardHolderDto> searchCriteria;
}
