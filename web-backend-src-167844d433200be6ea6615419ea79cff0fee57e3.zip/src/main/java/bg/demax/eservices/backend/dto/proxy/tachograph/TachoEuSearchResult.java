package bg.demax.eservices.backend.dto.proxy.tachograph;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import bg.demax.eservices.backend.entity.applications.Country;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TachoEuSearchResult {

	private String businessCaseId;
	private List<EuSearchCriteria> searchCriteria;

	@Getter
	@Setter
	public static class DrivingLicenceDetails {
		public String dlNumber;
		public String dlIssuingCountry;
		@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
		public LocalDate dlIssuingDate;
		public String dlStatus;
		@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
		public LocalDate dlExpiryDate;
	}

	@Getter
	@Setter
	public static class CardDetails {
		public String cardNumber;
		public String cardStatus;
		public String cardIssuingAuthority;
		@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
		public LocalDate cardStartOfValidityDate;
		@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
		public LocalDate cardExpiryDate;
		public Date cardStatusModifiedDate;
		public boolean validForDriving;
		public boolean temporaryCard;
		public Country country;
	}

	@Getter
	@Setter
	public static class SearchResult {
		public String searchMethod;
		public DrivingLicenceDetails drivingLicenceDetails;
		public CardHolderDto cardHolderDetails;
		public CardDetails cardDetails;
	}

	@Getter
	@Setter
	public static class MemberStateResponse {
		public String statusCode;
		public List<String> msCode;
		public List<SearchResult> searchResults;
		public List<String> statusMessage;
	}

	@Getter
	@Setter
	public static class EuSearchCriteria extends CardHolderDto {
		public List<MemberStateResponse> memberState;
	}

}
