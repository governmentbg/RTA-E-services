package bg.demax.eservices.backend.dto.proxy.tachograph;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TachoLocalResponseDto {
	private List<TachoLocalSearchResult> foundCards;
	private TachoBasicResponseDto error;
}
