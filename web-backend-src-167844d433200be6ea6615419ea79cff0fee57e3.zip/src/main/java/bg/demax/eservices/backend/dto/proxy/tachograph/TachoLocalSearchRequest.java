package bg.demax.eservices.backend.dto.proxy.tachograph;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TachoLocalSearchRequest extends TachoRequestNamesDto {
	private String identifier;
	private String identifierType;
}