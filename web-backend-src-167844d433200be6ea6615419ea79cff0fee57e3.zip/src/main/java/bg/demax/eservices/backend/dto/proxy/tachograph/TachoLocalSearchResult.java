package bg.demax.eservices.backend.dto.proxy.tachograph;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TachoLocalSearchResult extends TachoRequestNamesDto {

	private String status;
	private String type;
	private String fatherName;
	private String firstNameTrans;
	private String familyNameTrans;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private LocalDate birthDate;
	private String birthPlace;
	private String identifier;
	private String identifierType;
	private String orgName;
	private String fiscalCode;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd H:mm:ss")
	private LocalDateTime startOfValidityDate;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd H:mm:ss")
	private LocalDateTime expiryDate;
	private String cardNumber;
	private String dlNumber;
	private String dlIssuingAuth;
	private String dlIssuingCountry;
	private TachoRequestAddressDto address; 
	private String photoFace;
	private String photoSign;
	private Boolean isTemporary;
	
}
