package bg.demax.eservices.backend.dto.proxy.tachograph;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TachoNewCardDriverLicenceDto {
	private String dlNumber;
	private String categories;
	private String issueDate;
	private String expiryDate;
	private String issuingAuthority;
	private String issuingCountry; 
	
}
