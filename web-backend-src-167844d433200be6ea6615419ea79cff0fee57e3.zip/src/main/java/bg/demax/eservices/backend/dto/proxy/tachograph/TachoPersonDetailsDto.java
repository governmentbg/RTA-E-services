package bg.demax.eservices.backend.dto.proxy.tachograph;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TachoPersonDetailsDto {

	private String identifier;
	private String identifierType;
	private String title;
	@JsonInclude(value = Include.NON_NULL)
	private String fatherName;
	private String firstName;
	private String firstNameTrans;
	private String familyName;
	private String familyNameTrans;
	private String birthDate;
	private String birthPlace;
	private String phone;
	private String email;
	private String idCardSeries;
	private String idCardNumber;
	private String idCardIssueDate;
	private String idCardIssuingAuth;
	private String gender;
	private String photoFace;
	private String photoSign;
	private TachoRequestAddressDto address;
	private TachoNewCardDriverLicenceDto drivingLicence;
	
}
