package bg.demax.eservices.backend.dto.proxy.tachograph;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TachoRequestAddressDto extends TachoResponseAddressDto {
	private String building;
	private String entrance;
	private String aptNo;
	
}
