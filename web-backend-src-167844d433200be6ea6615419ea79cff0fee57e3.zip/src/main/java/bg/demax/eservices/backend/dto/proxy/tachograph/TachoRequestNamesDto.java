package bg.demax.eservices.backend.dto.proxy.tachograph;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TachoRequestNamesDto {
	private String firstName;
	private String familyName;
	
}
