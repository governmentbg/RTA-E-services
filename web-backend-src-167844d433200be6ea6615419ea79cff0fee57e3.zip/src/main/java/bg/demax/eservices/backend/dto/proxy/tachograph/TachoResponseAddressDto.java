package bg.demax.eservices.backend.dto.proxy.tachograph;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TachoResponseAddressDto {
	private String street;
	private String streetNo;
	private String building;
	private String entrance;
	private String aptNo;
	private String zipCode;
	private String locality;
	private String county;
	private String country;
}
