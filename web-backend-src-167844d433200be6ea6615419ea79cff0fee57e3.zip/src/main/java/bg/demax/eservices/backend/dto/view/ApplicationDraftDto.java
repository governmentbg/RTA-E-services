package bg.demax.eservices.backend.dto.view;

import java.util.List;

import bg.demax.eservices.backend.dto.AdrModuleDto;
import bg.demax.eservices.backend.dto.CertificateDto;
import bg.demax.eservices.backend.dto.DeliveryInfoDto;
import bg.demax.eservices.backend.dto.PersonalInfoDto;
import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationDraftDto {
	private int applicationId;
	private TranslationDto applicationType;
	private String identityNumber;
	private NamesDto names;
	private boolean hasGraoCheck;
	private boolean hasMvrCheck;
	private boolean hasDlMvrCheck;
	private boolean hasAutoFixedPicturesFromMvr;
	private List<TranslationDto> attachedDocuments;
	private PersonalInfoDto personalInfoDto;
	private ContactViewDto contactInfoDto;
	private DrivingLicenceViewDto drivingLicenceDto;
	private CardViewDto cardViewDto;
	private DeliveryInfoDto deliveryDto;
	private boolean isAuthorizedPerson;
	private List<CertificateDto> dqcCertificateDtos;
	private List<AdrModuleDto> adrModuleDtos;
}