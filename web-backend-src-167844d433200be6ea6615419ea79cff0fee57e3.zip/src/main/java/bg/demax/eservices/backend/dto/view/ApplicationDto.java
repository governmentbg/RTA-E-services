package bg.demax.eservices.backend.dto.view;

import java.util.List;

import bg.demax.eservices.backend.dto.AdrModuleDto;
import bg.demax.eservices.backend.dto.CertificateDto;
import bg.demax.eservices.backend.dto.DeliveryInfoDto;
import bg.demax.eservices.backend.dto.PersonalInfoDto;
import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import bg.demax.eservices.backend.dto.view.exam.AdrExamInfoDto;
import bg.demax.eservices.backend.dto.view.exam.MotorExamInfoDto;
import bg.demax.eservices.backend.dto.view.exam.TaxiExamInfoDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationDto {
	private TranslationDto applicationTypeViewDto;
	private NamesDto names;
	private String identityNumber;
	private SummaryDto summaryDto;
	private boolean hasGraoCheck;
	private boolean hasMvrCheck;
	private boolean hasDlMvrCheck;
	private boolean isEuCitizen;
	private boolean hasAutoFixedPicturesFromMvr;
	private PersonalInfoDto personalInfoDto;
	private ContactViewDto contactViewDto;
	private DrivingLicenceViewDto drivingLicenceDto;
	private CardViewDto cardViewDto;
	private DeliveryInfoDto deliveryViewDto;
	private List<CertificateDto> dqcCertificateDtos;
	private List<AdrModuleDto> adrModuleDtos;
	private PaymentViewDto paymentDto;
	
	private AdrExamInfoDto adrExamInfo;
	private MotorExamInfoDto motorExamInfo;
	private TaxiExamInfoDto taxiExamInfo;
}
