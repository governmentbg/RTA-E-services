package bg.demax.eservices.backend.dto.view;

import java.time.LocalDate;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationLightDto {
	private int applicationId;
	private GeneralStatusDescriptionDto applicationStatus;
	private TranslationDto authMethod;
	private int applicationTypeId;
	private LocalDate date;
	private NamesBilingualDto names;
	private String identityNumber;
	private int correspondenceTypeId;
	private int flags;
	private int paymentStatusId;
	private LocalDate lastStatusChange;
	private String deliveryKey;
}