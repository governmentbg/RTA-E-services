package bg.demax.eservices.backend.dto.view;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationRemarkViewDto {
	private String message;
	private String remarkKey;
	private LocalDateTime messageTimestamp;
}
