package bg.demax.eservices.backend.dto.view;

import java.util.List;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationShortDto {
	private int applicationId;
	private TranslationDto applicationType;
	private GeneralStatusDescriptionDto applicationStatus;
	private List<WarningDto> warningDtos;
	private List<ApplicationRemarkViewDto> remarkDtos;
	private boolean hasInvoice;
	private List<PaymentShortDto> payments;
}
