package bg.demax.eservices.backend.dto.view;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AttachedDocumentShortInfoDto {
	private boolean isDeclared;
	private List<DocumentPageInfoDto> pagesInfoShort;
}