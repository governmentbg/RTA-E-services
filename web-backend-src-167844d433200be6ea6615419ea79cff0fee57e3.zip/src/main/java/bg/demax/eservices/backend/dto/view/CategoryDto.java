package bg.demax.eservices.backend.dto.view;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryDto {
	@NotNull
	private Integer categoryId;

	@NotBlank
	private String category;
	
	@NotNull
	@PastOrPresent
	private LocalDate acquisitionDate;

	private String imageClass;
}
