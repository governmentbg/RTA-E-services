package bg.demax.eservices.backend.dto.view;

import bg.demax.eservices.backend.dto.AddressDto;
import bg.demax.eservices.backend.dto.PhoneNumberDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactViewDto {
	private AddressDto address;
	private String email;
	private PhoneNumberDto phoneNumberDto;
	private Integer contactTypeId;
}