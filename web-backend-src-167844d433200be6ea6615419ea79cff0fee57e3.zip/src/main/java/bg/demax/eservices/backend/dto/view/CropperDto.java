package bg.demax.eservices.backend.dto.view;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CropperDto {
	private Integer cropperX1;
	private Integer cropperX2;
	private Integer cropperY1;
	private Integer cropperY2;
	private Integer rotate;
	private Double scale;
}