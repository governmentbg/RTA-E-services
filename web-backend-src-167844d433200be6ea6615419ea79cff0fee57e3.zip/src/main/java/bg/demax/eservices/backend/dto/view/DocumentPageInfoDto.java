package bg.demax.eservices.backend.dto.view;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentPageInfoDto {
	private Integer id;
	private String name;
	private Integer size;
}