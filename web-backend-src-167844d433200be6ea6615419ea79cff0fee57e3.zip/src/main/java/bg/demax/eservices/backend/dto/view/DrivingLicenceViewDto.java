package bg.demax.eservices.backend.dto.view;

import java.time.LocalDate;
import java.util.List;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DrivingLicenceViewDto {
	private String documentNumber;
	private LocalDate issuedOn;
	private LocalDate expirationDate;
	private TranslationDto issuedBy;
	private boolean bulgarian;
	private List<CategoryDto> categories;
	private boolean hasAutoFixedPictures;
}
