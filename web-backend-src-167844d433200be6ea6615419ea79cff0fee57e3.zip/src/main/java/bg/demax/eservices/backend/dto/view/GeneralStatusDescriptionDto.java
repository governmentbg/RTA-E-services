package bg.demax.eservices.backend.dto.view;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GeneralStatusDescriptionDto {
	private TranslationDto generalStatus;
	private String statusDescriptionKey;
}