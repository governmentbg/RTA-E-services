package bg.demax.eservices.backend.dto.view;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class  NamesBilingualDto {
	private String namesInCyr;
	private String namesInLat;
}