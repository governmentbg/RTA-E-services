package bg.demax.eservices.backend.dto.view;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class  NamesDto {
	@NotBlank
	private String firstNameCyr;
	private String fatherNameCyr;
	private String familyNameCyr;
	
	@NotBlank
	private String firstNameLat;
	private String fatherNameLat;
	private String familyNameLat;
}