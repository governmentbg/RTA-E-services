package bg.demax.eservices.backend.dto.view;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OldCardDto {
	@NotBlank
	private String cardNumber;

	@NotNull
	private LocalDate validity;

	@NotNull
	private TranslationDto issuingCountry;

	@NotBlank
	private String issuedBy;

	private String place;

	@PastOrPresent
	private LocalDate date;
}
