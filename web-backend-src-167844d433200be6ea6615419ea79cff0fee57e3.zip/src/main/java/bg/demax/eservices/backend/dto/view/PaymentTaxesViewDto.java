package bg.demax.eservices.backend.dto.view;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class PaymentTaxesViewDto {
	private BigDecimal processingFee;
	private BigDecimal deliveryFee;
	private BigDecimal personalizationFee;
}
