package bg.demax.eservices.backend.dto.view;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentViewDto {
	private String processingFeeStatus;
	private Integer processingFeeMethodId;
	private String personalizationFeeStatus;
	private Integer personalizationFeeMethodId;
}