package bg.demax.eservices.backend.dto.view;

import java.time.LocalDate;
import java.util.List;

import bg.demax.eservices.backend.dto.nomenclature.TranslationDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SummaryDto {
	private TranslationDto authMethod;
	private TranslationDto paymentStatus;
	private LocalDate submissionDate;
	private List<TranslationDto> attachedDocuments;
	private ApplicationShortDto shortApplication;
}
