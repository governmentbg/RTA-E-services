package bg.demax.eservices.backend.dto.view;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WarningDto {
	private String warningMessageTranslationKey;
	private String warningVariableInfo;
}
