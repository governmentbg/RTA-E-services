package bg.demax.eservices.backend.dto.view.exam;

import bg.demax.eservices.backend.dto.exam.AdrExamPersonSelectionDto;
import bg.demax.eservices.backend.dto.exam.AdrExamProtocolSelectionDto;
import bg.demax.eservices.backend.dto.nomenclature.OrgUnitDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdrExamInfoDto {

	private AdrExamPersonSelectionDto selectedAdrExamPerson;
	private OrgUnitDto selectedOrgUnit;
	private AdrExamProtocolSelectionDto selectedAdrProtocol;
	private Boolean isConsultantExtension;
}
