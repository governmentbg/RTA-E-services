package bg.demax.eservices.backend.dto.view.exam;

import bg.demax.eservices.backend.dto.exam.MotorExamPersonSelectionDto;
import bg.demax.eservices.backend.dto.exam.MotorExamProtocolSelectionDto;
import bg.demax.eservices.backend.dto.view.CategoryDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MotorExamInfoDto {

	private MotorExamPersonSelectionDto selectedMotorExamPerson;
	private MotorExamProtocolSelectionDto selectedMotorProtocol;
	private CategoryDto selectedCategory;
}
