package bg.demax.eservices.backend.dto.view.exam;

import bg.demax.eservices.backend.dto.exam.MotorExamProtocolSelectionDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaxiExamInfoDto {

	private MotorExamProtocolSelectionDto selectedMotorProtocol;
	
}
