package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_additional_city_neighborhoods", schema = DbSchema.APPLICATIONS)
public class AdditionalCityNeighborhood {
	@Id
	@Column(name = "code")
	private String code;

	@Column(name = "city_neighborhood_name", nullable = false)
	private String cityNeighborhoodName;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "city_code", nullable = false)
	private City city;
}
