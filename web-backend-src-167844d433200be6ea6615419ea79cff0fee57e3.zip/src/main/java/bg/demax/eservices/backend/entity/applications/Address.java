package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.Language;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "addresses", schema = DbSchema.APPLICATIONS)
public class Address {

	public static final String REGION = "област";
	public static final String CITY = "гр./с.";
	public static final String STREET = "ул./бул.";
	public static final String STREET_NUMBER = "N";
	public static final String ENTRANCE = "вх.";
	public static final String BUILDING = "сграда";
	public static final String APARTMENT = "ап.";
	public static final String POSTAL_CODE = "п.к.";
	public static final String NEIGHBORHOOD = "к.в.";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "country_id")
	private Country country;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "city_code")
	private City city;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name = "municipality_code", referencedColumnName = "code", nullable = false),
		@JoinColumn(name = "region_code", referencedColumnName = "region_code", nullable = false)
	})
	private Municipality municipality;
	
	@Column(name = "street")
	private String street;
	
	@Column(name = "street_number")
	private String streetNumber;
	
	@Column(name = "entrance")
	private String entrance;
	
	@Column(name = "building")
	private String building;
	
	@Column(name = "apartment")
	private String apartment;

	@Column(name = "postal_code")
	private String postalCode;
	
	public String getAddressString() {
		StringBuilder additionalAddress = new StringBuilder();
		if (this.getStreet() != null && !this.getStreet().isEmpty()) {
			// additionalAddress.append(Address.STREET);
			additionalAddress.append(this.getStreet());
		}
		if (this.getStreetNumber() != null  && !this.getStreetNumber().isEmpty()) {
			additionalAddress.append(", ");
			additionalAddress.append(Address.STREET_NUMBER);
			additionalAddress.append(this.getStreetNumber());
		}
		if (this.getBuilding() != null && !this.getBuilding().isEmpty()) {
			additionalAddress.append(", ");
			additionalAddress.append(Address.BUILDING);
			additionalAddress.append(this.getBuilding());
		}
		if (this.getEntrance() != null && !this.getEntrance().isEmpty()) {
			additionalAddress.append(", ");
			additionalAddress.append(Address.ENTRANCE);
			additionalAddress.append(this.getEntrance());
		}
		if (this.getApartment() != null && !this.getApartment().isEmpty()) {
			additionalAddress.append(", ");
			additionalAddress.append(Address.APARTMENT);
			additionalAddress.append(this.getApartment());
		}
		if (this.getPostalCode() != null && !this.getPostalCode().isEmpty()) {
			additionalAddress.append(", ");
			additionalAddress.append(Address.POSTAL_CODE);
			additionalAddress.append(this.getPostalCode());
		}
		return additionalAddress.toString();
	}
	
	public String getCyrillicAddressString() {
		StringBuilder additionalAddress = new StringBuilder();
		if (this.getStreet() != null && !this.getStreet().isEmpty()) {
			// additionalAddress.append(Address.STREET);
			additionalAddress.append(this.getStreet());
		}
		if (this.getStreetNumber() != null  && !this.getStreetNumber().isEmpty()) {
			additionalAddress.append(", ");
			//additionalAddress.append(Address.STREET_NUMBER);
			additionalAddress.append(this.getStreetNumber());
		}
		if (this.getBuilding() != null && !this.getBuilding().isEmpty()) {
			additionalAddress.append(", ");
			additionalAddress.append(Address.BUILDING);
			additionalAddress.append(this.getBuilding());
		}
		if (this.getEntrance() != null && !this.getEntrance().isEmpty()) {
			additionalAddress.append(", ");
			additionalAddress.append(Address.ENTRANCE);
			additionalAddress.append(this.getEntrance());
		}
		if (this.getApartment() != null && !this.getApartment().isEmpty()) {
			additionalAddress.append(", ");
			additionalAddress.append(Address.APARTMENT);
			additionalAddress.append(this.getApartment());
		}
		if (this.getPostalCode() != null && !this.getPostalCode().isEmpty()) {
			additionalAddress.append(", ");
			additionalAddress.append(Address.POSTAL_CODE);
			additionalAddress.append(this.getPostalCode());
		}
		return additionalAddress.toString();
	}
	
	public String getFullCyrillicAddressString() {
		StringBuilder additionalAddress = new StringBuilder();
		if (this.getCountry() != null) {
			String countryName = this.getCountry().getTranslationValue(Language.BULGARIAN_CODE);
			if (countryName != null) {
				additionalAddress.append(countryName);
			}
		}
		if (this.getMunicipality() != null) {
			Region region = this.getMunicipality().getMunicipalityId().getRegion();
			String regionName = region.getTranslationValue(Language.BULGARIAN_CODE);
			if (regionName != null) {
				if (additionalAddress.length() > 0) {
					additionalAddress.append(", ");
				}
				additionalAddress.append(REGION).append(" ").append(regionName);
			}
		}
		if (this.getCity() != null) {
			String cityName = this.getCity().getTranslationValue(Language.BULGARIAN_CODE);
			if (cityName != null) {
				if (additionalAddress.length() > 0) {
					additionalAddress.append(", ");
				}
				additionalAddress.append(CITY).append(" ").append(cityName);
			}
		}
		
		if (this.getStreet() != null && !this.getStreet().isEmpty()) {
			// additionalAddress.append(Address.STREET);
			additionalAddress.append(this.getStreet());
		}
		if (this.getStreetNumber() != null  && !this.getStreetNumber().isEmpty()) {
			additionalAddress.append(", ");
			//additionalAddress.append(Address.STREET_NUMBER);
			additionalAddress.append(this.getStreetNumber());
		}
		if (this.getBuilding() != null && !this.getBuilding().isEmpty()) {
			additionalAddress.append(", ");
			additionalAddress.append(Address.BUILDING);
			additionalAddress.append(this.getBuilding());
		}
		if (this.getEntrance() != null && !this.getEntrance().isEmpty()) {
			additionalAddress.append(", ");
			additionalAddress.append(Address.ENTRANCE);
			additionalAddress.append(this.getEntrance());
		}
		if (this.getApartment() != null && !this.getApartment().isEmpty()) {
			additionalAddress.append(", ");
			additionalAddress.append(Address.APARTMENT);
			additionalAddress.append(this.getApartment());
		}
		if (this.getPostalCode() != null && !this.getPostalCode().isEmpty()) {
			additionalAddress.append(", ");
			additionalAddress.append(Address.POSTAL_CODE);
			additionalAddress.append(this.getPostalCode());
		}
		return additionalAddress.toString();
	}
}
