package bg.demax.eservices.backend.entity.applications;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "adr_card_applications", schema = DbSchema.APPLICATIONS)
public class AdrCardApplication extends CardApplication {

	@ManyToMany(mappedBy = "adrCardApplications", fetch = FetchType.LAZY)
	private List<AdrModule> adrModules;

	public void removeModule(AdrModule module) {
		this.adrModules.remove(module);
		module.getAdrCardApplications().remove(this);
	}
}
