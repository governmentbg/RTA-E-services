package bg.demax.eservices.backend.entity.applications;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(schema = DbSchema.APPLICATIONS, name = "adr_exam_people")
@Getter
@Setter
public class AdrExamPerson {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

	@Column(name = "exam_person_id", nullable = false)
	private Long examPersonId;

	@Column(name = "learning_plan_name", nullable = false)
	private String learningPlanName;
	
	@Column(name = "learning_plan_sub_category_ids_csv", nullable = false)
	private String learningPlanSubCategoryIdsCsv;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "adrExamPerson")
	@OrderBy("id ASC")
	private List<AdrExamPersonModuleResult> examModuleResults = new LinkedList<>();

	public List<Integer> getLearningPlanSubCategoryIds() {
		if (learningPlanSubCategoryIdsCsv == null || learningPlanSubCategoryIdsCsv.trim().isEmpty()) {
			return Collections.emptyList();
		}
		return Stream.of(learningPlanSubCategoryIdsCsv.split(","))
			.map(learningPlanSubCategoryIdString -> {
				return Integer.parseInt(learningPlanSubCategoryIdString.trim());
			}).collect(Collectors.toList());
	}
}
