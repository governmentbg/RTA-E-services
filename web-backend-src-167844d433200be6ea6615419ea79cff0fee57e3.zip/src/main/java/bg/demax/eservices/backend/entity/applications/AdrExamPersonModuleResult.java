package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(schema = DbSchema.APPLICATIONS, name = "adr_exam_person_module_results")
@Getter
@Setter
public class AdrExamPersonModuleResult {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "adr_exam_person_id", nullable = false)
	private AdrExamPerson adrExamPerson;

	@Column(name = "module", nullable = false)
	private String module;

	@Column(name = "module_sub_category_id", nullable = false)
	private Integer moduleSubCategoryId;
	
	@Column(name = "is_passed", nullable = true)
	private Boolean isPassed;

	public boolean isExamPassed() {
		if (this.isPassed == null) {
			return false;
		}
		return this.isPassed.booleanValue();
	}
}
