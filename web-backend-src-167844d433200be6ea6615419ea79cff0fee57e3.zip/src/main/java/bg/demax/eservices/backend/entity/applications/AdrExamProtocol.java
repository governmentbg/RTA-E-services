package bg.demax.eservices.backend.entity.applications;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(schema = DbSchema.APPLICATIONS, name = "adr_exam_protocols")
@Getter
@Setter
public class AdrExamProtocol {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

	@Column(name = "adr_protocol_id", nullable = false)
	private Long adrProtocolId;

	@Column(name = "number", nullable = false)
	private String number;

	@Column(name = "exam_date_time", nullable = false)
	private LocalDateTime examDateTime;

	@Column(name = "room_name", nullable = false)
	private String roomName;
}
