package bg.demax.eservices.backend.entity.applications;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.subjects.Subject;
import bg.demax.eservices.backend.enumeration.DbSchema;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "adr_modules", schema = DbSchema.APPLICATIONS)
public class AdrModule {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "module_type_id", nullable = false)
	private ModuleType moduleType;

	@Column(name = "issued_date")
	private LocalDate issuedDate;

	@Column(name = "validity")
	private LocalDate validDate;

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "adr_card_applications_modules", schema = DbSchema.APPLICATIONS,
				joinColumns = @JoinColumn(name = "adr_module_id"),
				inverseJoinColumns = @JoinColumn(name = "id"))
	private List<AdrCardApplication> adrCardApplications;

	@Column(name = "is_attached", nullable = false)
	private boolean isAttached;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "subject_id", nullable = false)
	private Subject subject;
}