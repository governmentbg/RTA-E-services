package bg.demax.eservices.backend.entity.applications;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.fsm.ApplicationProcess;
import bg.demax.eservices.backend.entity.fsm.GeneralizedStatus;
import bg.demax.eservices.backend.entity.security.AuthenticationMethod;
import bg.demax.eservices.backend.entity.security.User;
import bg.demax.eservices.backend.entity.subjects.Authorization;
import bg.demax.eservices.backend.entity.subjects.PhysicalSubjectVersion;
import bg.demax.eservices.backend.entity.subjects.Subject;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "applications", schema = DbSchema.APPLICATIONS)
@Inheritance(strategy = InheritanceType.JOINED)
public class Application {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "subject_id")
	private Subject subject;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "identity_document_id")
	private IdentityDocument identityDocument;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "driving_licence_id")
	private DrivingLicence drivingLicence;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false)
	private User user;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "authentication_method_id", nullable = false)
	private AuthenticationMethod authenticationMethod;

	@Column(name = "creation_timestamp", nullable = false)
	private LocalDateTime creationTimestamp;
	
	@Column(name = "submission_timestamp")
	private LocalDateTime submissionTimestamp;
	
	@Column(name = "approval_timestamp", nullable = true)
	private LocalDateTime approvalTimestamp;
	
	@OneToMany(mappedBy = "application", fetch = FetchType.LAZY)
	private Set<Payment> payments;
	
	@OneToMany(mappedBy = "application", fetch = FetchType.LAZY)
	private Set<AttachedDocument> attachedDocuments;
	
	@OneToMany(mappedBy = "application", fetch = FetchType.LAZY)
	private Set<Warning> warnings;

	@OneToMany(mappedBy = "application", fetch = FetchType.LAZY)
	private List<ApplicationRemark> remarks;

	@OneToOne(mappedBy = "application", fetch = FetchType.LAZY)
	private ApplicationProcess applicationProcess;
	
	@OneToOne(mappedBy = "application", fetch = FetchType.LAZY)
	private Authorization authorization;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "generalized_status_id")
	private GeneralizedStatus currentGeneralizedStatus;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "application")
	private Set<ApplicationAddress> applicationAddresses = new HashSet<>();
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "application")
	private Set<ApplicationEmail> applicationEmails = new HashSet<>();
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "application")
	private Set<ApplicationPhoneNumber> applicationPhoneNumbers = new HashSet<>();

	@ManyToOne(fetch = FetchType.LAZY) 
	@JoinColumn(name = "physical_subject_version_id")
	private PhysicalSubjectVersion physicalSubjectVersion;
}
