package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.TranslatableEntity;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_application_payment_statuses", schema = DbSchema.APPLICATIONS)
public class ApplicationPaymentStatus extends TranslatableEntity {
	public static final int NOT_PAID_ID = 1;
	public static final int FOR_PROCESSING_ID = 2;
	public static final int PARTIALLY_PAID_ID = 3;
	public static final int PAID_ID = 4;
	public static final int NOT_ALL_PAYMENTS_GENERATED_ID = 5;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
}
