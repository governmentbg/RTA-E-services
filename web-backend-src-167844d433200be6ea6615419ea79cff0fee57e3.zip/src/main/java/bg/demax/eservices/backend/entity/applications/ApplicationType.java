package bg.demax.eservices.backend.entity.applications;

import java.util.Arrays;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.TranslatableEntity;
import bg.demax.eservices.backend.entity.config.TranslationKey;
import bg.demax.eservices.backend.entity.fsm.ApplicationProcessStatus;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_application_types", schema = DbSchema.APPLICATIONS)
public class ApplicationType extends TranslatableEntity {

	public static final int TACHOGRAPH_CARD_ID = 1;
	public static final int DQC_CARD_ID = 2;
	public static final int ADR_CARD_ID = 3;
	public static final int CONSULTANT_EXAM_ID = 4;
	public static final int MOTOR_EXAM_ID = 5;
	public static final int TAXI_EXAM_ID = 6;
	public static final int ADR_EXAM_ID = 7;

	public static final List<Integer> CARD_APPLICATION_TYPES = Arrays.asList(
		ApplicationType.ADR_CARD_ID, ApplicationType.DQC_CARD_ID, ApplicationType.TACHOGRAPH_CARD_ID);

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "description_translation_key", nullable = false)
	private TranslationKey descriptionTranslationKey;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status_id", nullable = false)
	private ApplicationProcessStatus status;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "application_type_template_id", nullable = false)
	private ApplicationTypeTemplate applicationTypeTemplate;

	@Column(name = "processing_fee_payment_reason")
	private String processingFeePaymentReason;

	@Column(name = "pеrso_fee_payment_reason")
	private String persoFeePaymentReason;
}
