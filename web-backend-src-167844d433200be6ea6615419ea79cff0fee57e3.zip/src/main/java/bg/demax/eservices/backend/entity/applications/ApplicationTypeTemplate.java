package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_application_type_templates", schema = DbSchema.APPLICATIONS)
public class ApplicationTypeTemplate {
	private static final int TWO_TO_THE_POWER_OF_NINETEEN = 524288;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "card_name_cyrillic", nullable = false)
	private String cardNameCyrillic;

	@Column(name = "card_name_latin", nullable = false)
	private String cardNameLatin;

	@Column(name = "template", nullable = false, length = TWO_TO_THE_POWER_OF_NINETEEN)
	private byte[] template;

	@Column(name = "name", nullable = false)
	private String name;
 
	@OneToOne(mappedBy = "applicationTypeTemplate")
	private ApplicationType applicationType;
}
