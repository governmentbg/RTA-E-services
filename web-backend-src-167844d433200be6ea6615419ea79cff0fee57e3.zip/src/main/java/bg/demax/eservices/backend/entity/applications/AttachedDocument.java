package bg.demax.eservices.backend.entity.applications;

import java.time.LocalDateTime;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "attached_documents", schema = DbSchema.APPLICATIONS)
public class AttachedDocument {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "application_id", nullable = false)
	private Application application;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "document_type_id", nullable = false)
	private RequiredDocumentType documentType;

	@Column(name = "attached_timestamp", nullable = false)
	private LocalDateTime attachedTimestamp;

	@Column(name = "is_valid", nullable = false)
	private boolean isValid;

	@Column(name = "is_active", nullable = false)
	private boolean isActive;

	@Column(name = "is_declared", nullable = false)
	private boolean isDeclared;

	@OneToMany(mappedBy = "attachedDocument")
	private Set<AttachedDocumentPage> pages;
}
