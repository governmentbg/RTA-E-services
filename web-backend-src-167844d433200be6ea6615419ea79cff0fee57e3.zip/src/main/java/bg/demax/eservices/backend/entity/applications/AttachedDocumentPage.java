package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "attached_document_pages", schema = DbSchema.APPLICATIONS)
public class AttachedDocumentPage {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "attached_document_id", nullable = false)
	private AttachedDocument attachedDocument;

	@Column(name = "page_checksum", nullable = false)
	private String pageChecksum;

	@Column(name = "page_number", nullable = false)
	private int pageNumber;

	@Column(name = "name", nullable = false)
	private String name;

	@Column(name = "size", nullable = false)
	private Integer size;
}
