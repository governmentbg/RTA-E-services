package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "card_applications", schema = DbSchema.APPLICATIONS)
public class CardApplication extends Application {

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "delivery_method_id")
	private DeliveryMethod deliveryMethod;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "chosen_org_unit_code")
	private OrgUnit chosenOrgUnit;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "card_issuing_reason_id")
	private CardIssuingReason cardIssuingReason;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "old_card_id")
	private OldCard oldCard;
}
