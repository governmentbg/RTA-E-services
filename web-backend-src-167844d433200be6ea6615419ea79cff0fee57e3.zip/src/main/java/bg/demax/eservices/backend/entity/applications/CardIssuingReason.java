package bg.demax.eservices.backend.entity.applications;

import java.util.Arrays;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.TranslatableEntity;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_card_issuing_reasons", schema = DbSchema.APPLICATIONS)
public class CardIssuingReason extends TranslatableEntity {

	public static final int FIRST_CARD = 1;
	public static final int CARD_LOST = 2;
	public static final int CARD_STOLEN = 3;
	public static final int CARD_BROKEN = 4;
	public static final int CARD_NAME_CHANGE = 5;
	public static final int CARD_PHOTO_CHANGE = 6;
	public static final int CARD_DRIVING_LICENCE_CHANGE = 7;
	public static final int CARD_PERSONAL_DOCUMENT_CHANGE = 8;
	public static final int CARD_WANT_BULGARIAN = 9;
	public static final int CARD_EXPIRE = 10;
	public static final int CARD_TAKEN_AWAY = 12;
	public static final int NEW_CERTIFICATE = 13; //only for dqc cards

	public static final List<Integer> GROUP_1 = Arrays.asList(CARD_LOST, CARD_BROKEN, CARD_STOLEN, CARD_PERSONAL_DOCUMENT_CHANGE);
	public static final List<Integer> GROUP_2 = Arrays.asList(CARD_NAME_CHANGE, CARD_DRIVING_LICENCE_CHANGE, CARD_TAKEN_AWAY);

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "reason_cyrillic", nullable = false)
	private String reasonCyrillic;

	@Column(name = "reason_latin", nullable = false)
	private String reasonLatin;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "adr_card_product_code", nullable = true)
	private ProductCode productCode;
}
