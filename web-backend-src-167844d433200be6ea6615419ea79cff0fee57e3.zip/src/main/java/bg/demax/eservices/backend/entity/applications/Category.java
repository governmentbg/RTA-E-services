package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_categories", schema = DbSchema.APPLICATIONS)
public class Category {

	public static final int C1_ID = 7;
	public static final int C_ID = 8;
	public static final int C1E_ID = 12;
	public static final int CE_ID = 13;

	public static final int D1_ID = 9;
	public static final int D_ID = 10;
	public static final int D1E_ID = 14;
	public static final int DE_ID = 15;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "category", nullable = false)
	private String category;

	@Column(name = "image_class", nullable = false)
	private String imageClass;

	@Column(name = "motor_exam_sub_category_id", nullable = false)
	private Integer motorExamSubCategoryId;
}
