package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "consultant_exam_applications", schema = DbSchema.APPLICATIONS)
@Getter
@Setter
public class ConsultantExamApplication extends ExamApplication {

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "selected_adr_exam_person_id", nullable = true, unique = true)
	private AdrExamPerson selectedAdrExamPerson;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "selected_adr_protocol_id", nullable = true, unique = true)
	private AdrExamProtocol selectedAdrProtocol;

	@Column(name = "exam_result_id", nullable = true)
	private Long examResultId;
	
	@Column(name = "is_extension", nullable = true)
	private Boolean isExtension = null;
}
