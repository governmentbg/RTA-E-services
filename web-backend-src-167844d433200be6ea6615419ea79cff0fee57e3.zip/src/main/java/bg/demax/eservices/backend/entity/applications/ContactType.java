package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.TranslatableEntity;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_contact_types", schema = DbSchema.APPLICATIONS)
public class ContactType extends TranslatableEntity {
	
	public static final int CURRENT_ADDRESS = 1;
	public static final int PERMANENT_ADDRESS = 2;
	public static final int ADDITIONAL_ADDRESS = 3;
	public static final int EMAIL = 4;
	public static final int PHONE_NUMBER = 5;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
}
