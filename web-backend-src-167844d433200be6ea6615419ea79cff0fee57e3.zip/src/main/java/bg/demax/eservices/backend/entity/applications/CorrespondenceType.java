package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_correspondence_types", schema = DbSchema.APPLICATIONS)
public class CorrespondenceType {
	
	public static final int DELIVERY_CONTACT = 1;
	public static final int PREFERRED_CORRESPONDENCE_CONTACT  = 2;
	public static final int NOT_SPECIFIED = 3;
	public static final int AUTHORIZED_PERSON_CONTACT = 5;
	public static final int POSTAL_ADDRESS = 6;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "type", nullable = false)
	private String type;
}
