package bg.demax.eservices.backend.entity.applications;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_delivery_methods", schema = DbSchema.APPLICATIONS)
public class DeliveryMethod {

	public static final int RECEIVE_IN_PERSON = 1;
	public static final int RECEIVE_BY_COURIER = 2;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "method", nullable = false)
	private String method;
	
	@Column(name = "cost", nullable = false)
	private BigDecimal cost;
}