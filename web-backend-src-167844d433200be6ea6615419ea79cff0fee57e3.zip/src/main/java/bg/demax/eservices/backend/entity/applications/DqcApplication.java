package bg.demax.eservices.backend.entity.applications;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "dqc_applications", schema = DbSchema.APPLICATIONS)
public class DqcApplication extends CardApplication {
	
	@ManyToMany(mappedBy = "dqcApplications", fetch = FetchType.LAZY)
	private List<DqcCertificate> certificates;

	public void removeCertificate(DqcCertificate certificate) {
		this.certificates.remove(certificate);
		certificate.getDqcApplications().remove(this);
	}
}
