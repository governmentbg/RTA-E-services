package bg.demax.eservices.backend.entity.applications;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.subjects.Subject;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "dqc_certificates", schema = DbSchema.APPLICATIONS)
public class DqcCertificate {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
		
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "certificate_type_id", nullable = false)
	private TrainingType certificateType;
	
	@Column(name = "permit_number", nullable = false)
	private String permitNumber;
	
	@Column(name = "number", nullable = false)
	private String number;
	
	@Column(name = "issued_date", nullable = false)
	private LocalDate issuedDate;
	
	@Column(name = "training_start_date", nullable = false)
	private LocalDate trainingStartDate;
	
	@Column(name = "training_end_date", nullable = false)
	private LocalDate trainingEndDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "legal_basis_type_id", nullable = false)
	private CertificateLegalBasisType legalBasisType;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "subject_id", nullable = false)
	private Subject subject;

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "dqc_applications_certificates", schema = DbSchema.APPLICATIONS,
				joinColumns = @JoinColumn(name = "dqc_certificate_id"),
				inverseJoinColumns = @JoinColumn(name = "id"))
	private List<DqcApplication> dqcApplications;

	@Column(name = "is_attached", nullable = false)
	private boolean isAttached;
}