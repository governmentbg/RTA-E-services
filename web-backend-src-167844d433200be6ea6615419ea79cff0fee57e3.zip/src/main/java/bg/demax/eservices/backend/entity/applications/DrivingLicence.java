package bg.demax.eservices.backend.entity.applications;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "driving_licences", schema = DbSchema.APPLICATIONS)
public class DrivingLicence {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "number", nullable = false)
	private String number;
	
	@Column(name = "issuing_date", nullable = false)
	private LocalDate issuingDate;
	
	@Column(name = "validity_date", nullable = false)
	private LocalDate validityDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "document_issuer_id")
	private DocumentIssuer documentIssuer;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "issuing_country_id")
	private Country issuingCountry;
	
	@OneToMany(mappedBy = "drivingLicence", fetch = FetchType.LAZY)
	@OrderBy("issuedDate")
	private List<DrivingLicenceCategory> drivingLicenceCategories;
}
