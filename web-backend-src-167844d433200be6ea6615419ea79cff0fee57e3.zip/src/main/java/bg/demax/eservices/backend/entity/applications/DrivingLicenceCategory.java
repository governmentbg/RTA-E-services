package bg.demax.eservices.backend.entity.applications;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "driving_licences_categories", schema = DbSchema.APPLICATIONS)
public class DrivingLicenceCategory {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "category_id", nullable = false)
	private Category category;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "driving_licence_id", nullable = false)
	private DrivingLicence drivingLicence;
	
	@Column(name = "issued_date", nullable = false)
	private LocalDate issuedDate;
	
	@Column(name = "validity_date")
	private LocalDate validityDate;
}
