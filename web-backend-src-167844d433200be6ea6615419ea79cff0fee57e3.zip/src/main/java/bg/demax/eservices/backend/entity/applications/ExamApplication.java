package bg.demax.eservices.backend.entity.applications;

import java.sql.Timestamp;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "exam_applications", schema = DbSchema.APPLICATIONS)
@Getter
@Setter
public class ExamApplication extends Application {
	
	@Column(name = "exam_date_time", nullable = true)
	private Timestamp examDateTime;

	@Column(name = "enrolment_expiration_date", nullable = true)
	private LocalDate enrolmentExpirationDate;
}
