package bg.demax.eservices.backend.entity.applications;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "identity_documents", schema = DbSchema.APPLICATIONS)
public class IdentityDocument {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "type_id", nullable = false)
	private IdentityDocumentType type;
	
	@Column(name = "number", nullable = false)
	private String documentNumber;
	
	@Column(name = "validity_date", nullable = false)
	private LocalDate validityDate;
	
	@Column(name = "issuing_date", nullable = false)
	private LocalDate issuingDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "document_issuer_id", nullable = false)
	private DocumentIssuer documentIssuer;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "nationality_id", nullable = false)
	private Country nationality;
}
