package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.TranslatableEntity;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_identity_document_types", schema = DbSchema.APPLICATIONS)
public class IdentityDocumentType extends TranslatableEntity {

	private static final int CERTIFICATE_FOR_PROLONGED_RESIDENCE_OF_EU_CITIZEN = 4;
	private static final int CERTIFICATE_FOR_RESIDENCE_PERMIT_OF_EU_CITIZEN = 5;
	private static final int RESIDENCE_CARD_FOR_PROLONGED_RESIDENCE_OF_A_FAMILY_MEMBER_OF_A_EU_CITIZEN = 6;
	private static final int RESIDENCE_CARD_FOR_RESIDENCE_PERMIT_OF_A_FAMILY_MEMBER_OF_A_EU_CITIZEN = 7;
	private static final int PROLONGED_RESIDENCE_PERMIT = 8;
	private static final int RESIDENCE_PERMIT = 9;
	public static final int CERTIFICATE_FOR_REGISTRATION_FROM_NAP = 18;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	public boolean isWithLnch() {
		if (this.getId().equals(CERTIFICATE_FOR_PROLONGED_RESIDENCE_OF_EU_CITIZEN)
				|| this.getId().equals(CERTIFICATE_FOR_RESIDENCE_PERMIT_OF_EU_CITIZEN)
				|| this.getId().equals(RESIDENCE_CARD_FOR_PROLONGED_RESIDENCE_OF_A_FAMILY_MEMBER_OF_A_EU_CITIZEN)
				|| this.getId().equals(RESIDENCE_CARD_FOR_RESIDENCE_PERMIT_OF_A_FAMILY_MEMBER_OF_A_EU_CITIZEN)
				|| this.getId().equals(PROLONGED_RESIDENCE_PERMIT)) {
			return true;
		}
		
		return false;
	}
	
	public boolean isForeignerWithEgn() {
		if (this.getId().equals(RESIDENCE_PERMIT)) {
			return true;
		}
		
		return false;
	}
}
