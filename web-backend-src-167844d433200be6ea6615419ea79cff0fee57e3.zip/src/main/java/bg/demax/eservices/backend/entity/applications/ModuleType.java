package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.TranslatableEntity;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_module_types", schema = DbSchema.APPLICATIONS)
public class ModuleType extends TranslatableEntity {
	
	public static final int BASIC = 1;
	public static final int TANKS = 2;
	public static final int CLASS_1 = 3;
	public static final int CLASS_7 = 4;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "register_response_type", nullable = false)
	private String registerResponseType;
}