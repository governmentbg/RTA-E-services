package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "motor_exam_applications", schema = DbSchema.APPLICATIONS)
@Getter
@Setter
public class MotorExamApplication extends ExamApplication {

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "selected_motor_exam_person_id", nullable = true, unique = true)
	private MotorExamPerson selectedExamPerson;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "selected_motor_exam_protocol_id", nullable = true, unique = true)
	private MotorExamProtocol selectedExamProtocol;

	@Column(name = "exam_result_id", nullable = true)
	private Long examResultId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "selected_category_id", nullable = true)
	private Category selectedCategory;
}
