package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(schema = DbSchema.APPLICATIONS, name = "motor_exam_people")
@Getter
@Setter
public class MotorExamPerson {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

	@Column(name = "exam_person_id", nullable = false)
	private Long examPersonId;

	@Column(name = "learning_plan_name", nullable = false)
	private String learningPlanName;

	@Column(name = "theoretical_exam_result", nullable = true)
	private String theoreticalExamResult;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "org_unit_code", nullable = false)
	private OrgUnit orgUnit;
}
