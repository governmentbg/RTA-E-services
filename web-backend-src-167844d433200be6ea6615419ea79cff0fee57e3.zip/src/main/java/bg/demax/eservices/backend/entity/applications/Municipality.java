package bg.demax.eservices.backend.entity.applications;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.TranslatableEntity;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_municipalities", schema = DbSchema.APPLICATIONS)
public class Municipality extends TranslatableEntity {
	@EmbeddedId
	private MunicipalityId municipalityId;
	
	@Embeddable
	@Data
	@NoArgsConstructor
	public static class MunicipalityId implements Serializable {
		private static final long serialVersionUID = 3432858047223885880L;

		@Column(name = "code", nullable = false)
		private String code;
		
		@ManyToOne(fetch = FetchType.LAZY)
		@JoinColumn(name = "region_code", nullable = false)
		private Region region; 
	}
}
