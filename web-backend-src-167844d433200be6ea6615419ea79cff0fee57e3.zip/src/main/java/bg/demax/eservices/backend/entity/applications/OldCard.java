package bg.demax.eservices.backend.entity.applications;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "old_cards", schema = DbSchema.APPLICATIONS)
public class OldCard {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "country_id", nullable = false)
	private Country country;
	
	@Column(name = "card_issuer", nullable = false)
	private String cardIssuer;

	@Column(name = "card_number", nullable = false)
	private String cardNumber;

	@Column(name = "date")
	private LocalDate dateLost;
	
	@Column(name = "place")
	private String placeLost;
	
	@Column(name = "validity", nullable = false)
	private LocalDate validity;
}
