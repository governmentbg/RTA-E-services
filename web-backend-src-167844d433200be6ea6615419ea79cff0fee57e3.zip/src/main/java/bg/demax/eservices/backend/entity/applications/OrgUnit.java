package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.TranslatableEntity;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_org_units", schema = DbSchema.APPLICATIONS)
public class OrgUnit extends TranslatableEntity {

	@Id
	@Column(name = "code")
	private String code;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "city_code", nullable = false)
	private City city;

	@Column(name = "address", nullable = false)
	private String address;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "phone_number_id", nullable = false)
	private PhoneNumber phoneNumber;
}
