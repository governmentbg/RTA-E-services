package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.TranslatableEntity;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_payment_methods", schema = DbSchema.APPLICATIONS)
public class PaymentMethod extends TranslatableEntity {

	public static final int VIRTUAL_POS_TERMINAL = 1;
	public static final int E_PAY = 2;
	public static final int EASY_PAY = 3;
	public static final int BANK = 4;
	public static final int PHYSICAL_POS_TERMINAL = 5;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
}
