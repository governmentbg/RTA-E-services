package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "n_payment_statuses", schema = DbSchema.APPLICATIONS)
@Immutable
@Getter
@Setter
public class PaymentStatus {
	
	@Id
	@Column(name = "code", nullable = false, length = 10)
	private String code = null;

	public static enum PaymentStatuses {
		CREATED, WAITING, PAID, CANCELED, DENIED, EXPIRED, ERROR;

		public String getCode() {
			return this.name();
		}
		
		public static PaymentStatuses getByCode(String code) {
			for (PaymentStatuses result : PaymentStatuses.values()) {
				if (result.getCode().equals(code)) {
					return result;
				}
			}
			throw new IllegalArgumentException();
		}
		
	}
}
