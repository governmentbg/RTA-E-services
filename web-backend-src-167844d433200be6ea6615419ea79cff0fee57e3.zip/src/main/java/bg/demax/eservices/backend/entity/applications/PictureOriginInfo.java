package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "picture_origin_infos", schema = DbSchema.APPLICATIONS)
public class PictureOriginInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "is_from_mvr", nullable = false)
	private Boolean isFromMVR;

	@Column(name = "is_auto_fixed", nullable = false)
	private Boolean isAutoFixed;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "attached_document_pages_id", nullable = false)
	private AttachedDocumentPage attachedDocumentPage;
}