package bg.demax.eservices.backend.entity.applications;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_product_codes", schema = DbSchema.APPLICATIONS)
public class ProductCode {

	public static final String CODE_PROCESSING_TACHO_CARD = "440101";
	public static final String CODE_PROCESSING_DQC = "410201";
	public static final String CODE_ADR_CARD_ISSUING = "400301";
	public static final String CODE_ADR_CARD_COPY = "400401";
	public static final String CODE_ADR_CARD_EXTENSION = "400501";

	public static final String CODE_PERSO_TACHO_CARD = "6";
	public static final String CODE_PERSO_DQC = "12";
	public static final String CODE_PERSO_ADR_CARD = "3";

	@Id
	@Column(name = "code", nullable = false)
	private String code;

	@Column(name = "code_description", nullable = false)
	private String codeDescription;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "payment_type_id")
	private PaymentType paymentType;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "application_type_id")
	private ApplicationType applicationType;

	@Column(name = "exam_sub_category_ids_csv", nullable = true)
	private String examSubCategoryIdsCsv;

	public List<Integer> getExamSubCategoryIds() {
		if (examSubCategoryIdsCsv == null) {
			return null;
		}
		return Stream.of(examSubCategoryIdsCsv.split(","))
			.map(examSubCategoryIdString -> {
				return Integer.parseInt(examSubCategoryIdString.trim());
			}).collect(Collectors.toList());
	}
}
