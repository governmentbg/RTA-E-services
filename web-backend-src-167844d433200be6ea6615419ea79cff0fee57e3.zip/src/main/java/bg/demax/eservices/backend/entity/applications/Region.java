package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.TranslatableEntity;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_regions", schema = DbSchema.APPLICATIONS)
public class Region extends TranslatableEntity {
	@Id
	@Column(name = "code")
	private String code;
}
