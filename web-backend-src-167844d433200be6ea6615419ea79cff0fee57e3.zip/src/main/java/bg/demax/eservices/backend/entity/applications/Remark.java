package bg.demax.eservices.backend.entity.applications;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.TranslatableEntity;
import bg.demax.eservices.backend.entity.fsm.ApplicationProcessStatus;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_remarks", schema = DbSchema.APPLICATIONS)
public class Remark extends TranslatableEntity {

	public static final int ALREADY_STARTED_PROCESS_FOR_SAME_CARD_TYPE = 8;
	public static final int MISSING_ACTIVE_CONTRACT_IN_NAP = 9;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@ManyToMany(mappedBy = "remarks", fetch = FetchType.LAZY)
	private Set<ApplicationProcessStatus> statuses;
}
