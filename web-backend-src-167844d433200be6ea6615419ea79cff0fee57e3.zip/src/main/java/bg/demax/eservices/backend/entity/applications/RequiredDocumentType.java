package bg.demax.eservices.backend.entity.applications;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.TranslatableEntity;
import bg.demax.eservices.backend.entity.fsm.ApplicationProcessStatus;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_required_document_types", schema = DbSchema.APPLICATIONS)
public class RequiredDocumentType extends TranslatableEntity {
	public static final int IDENTITY_DOCUMENT_ID = 1;
	public static final int DECLARATION_OF_NAME_IDENTITY_ID = 4;
	public static final int TRANSLATED_DRIVING_LICENCE = 5;
	public static final int DQC_CERTIFICATE_GOODS = 12;
	public static final int PHOTO_FACE = 17;
	public static final int PHOTO_SIGNATURE = 18;
	public static final int APPLICATION = 19;
	public static final int PAYMENT_ORDER_PROCESSING_FEE = 20;
	public static final int DQC_CERTIFICATE_PASSANGERS = 22;
	public static final int PHOTO_FACE_AUTHORIZED = 23;
	public static final int PAYMENT_ORDER_PERSONALIZATION_FEE = 24;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "type", nullable = false)
	private String type;
	
	@Column(name = "validity_months")
	private Integer validityMonths;
	
	@ManyToMany(mappedBy = "requiredDocumentTypes", fetch = FetchType.LAZY)
	private Set<ApplicationProcessStatus> statuses;
}
