package bg.demax.eservices.backend.entity.applications;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "tachograph_applications", schema = DbSchema.APPLICATIONS)
public class TachographApplication extends CardApplication {
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "applicant_gender_id")
	private Gender applicantGender;
}
