package bg.demax.eservices.backend.entity.applications;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "warnings", schema = DbSchema.APPLICATIONS)
public class Warning {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "warning_variable_info", nullable = false)
	private String warningVariableInfo;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "warning_message_id", nullable = false)
	private WarningMessage warningMessage;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "application_id", nullable = false)
	private Application application;

	@Column(name = "creation_timestamp", nullable = false)
	private LocalDateTime creationTimestamp;
}
