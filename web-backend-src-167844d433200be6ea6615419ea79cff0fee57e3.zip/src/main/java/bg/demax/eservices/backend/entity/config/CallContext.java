package bg.demax.eservices.backend.entity.config;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.applications.ApplicationType;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_call_contexts", schema = DbSchema.CONFIG)
public class CallContext {

	public static final int DEFAULT_CALL_CONTEXT = 1;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "service_type", nullable = false)
	private String serviceType;
	
	@Column(name = "employee_identifier", nullable = false)
	private String employeeIdentifier;
	
	@Column(name = "employee_names", nullable = false)
	private String employeeNames;
	
	@Column(name = "employee_additional_identifier", nullable = false)
	private String employeeAdditionalIdentifier;
	
	@Column(name = "employee_position", nullable = false)
	private String employeePosition;
	
	@Column(name = "responsible_person_identifier", nullable = false)
	private String responsiblePersonIdentifier;
	
	@Column(name = "administration_oid", nullable = false)
	private String administrationOid;
	
	@Column(name = "administration_name", nullable = false)
	private String administrationName;
		
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "application_type_id", nullable = false)
	private ApplicationType applicationType;
}
