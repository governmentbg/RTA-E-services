package bg.demax.eservices.backend.entity.config;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_certificates", schema = DbSchema.CONFIG)
public class Certificate {

	//-----REGIX TEST ENVIRONMENT CERTIFICATES-----
	public static final int REGIX_KEY_STORE_ADR_PERMITS_TEST_AND_DRIVE_ENVIRONMENT = 1;
	public static final int REGIX_TRUST_STORE_TEST_AND_DRIVE_ENVIRONMENT = 2;
	public static final int REGIX_KEY_STORE_DRIVING_LICENCE_TEST_AND_DRIVE_ENVIRONMENT = 6;

	//-----REGIX PROD ENVIRONMENT CERTIFICATES-----
	public static final int REGIX_TRUST_STORE_PROD_ENVIRONMENT = 7;
	public static final int REGIX_KEY_STORE_ADR_PERMITS_PROD_ENVIRONMENT = 8;
	public static final int REGIX_KEY_STORE_DRIVING_LICENCE_PROD_ENVIRONMENT = 9;

	//-----IAAA GATEWAY PROD ENVIRONMENT CERTIFICATES-----
	public static final int IAAA_GATEWAY_CLIENT_CERTIFICATE_PROD_ENVIRONMENT = 18;
	public static final int IAAA_GATEWAY_TRUST_STORE_PROD_ENVIRONMENT = 19;

	//-----IAAA GATEWAY TEST ENVIRONMENT CERTIFICATES-----
	public static final int IAAA_GATEWAY_CLIENT_CERTIFICATE_TEST_AND_DRIVE_ENVIRONMENT = 20;
	public static final int IAAA_GATEWAY_TRUST_STORE_TEST_AND_DRIVE_ENVIRONMENT = 24;

	//-----FACE-AUTH CERTIFICATES-----
	public static final int FACE_AUTH_KEYSTORE_ID_DEV_AND_DRIVE = 5;
	public static final int FACE_AUTH_KEYSTORE_ID_PROD = 25;

	//-----DQC TEST ENVIRONMENT CERTIFICATES-----
	public static final int DQC_KEYSTORE_TEST_ENVIRONMENT = 31;

	//-----TACHO TEST ENVIRONMENT CERTIFICATES-----
	public static final int TACHO_KEYSTORE_TEST_ENVIRONMENT = 32;

	//-----DQC AND TACHO TEST TRUSTSTORE-----
	public static final int DQC_TACHO_TRUESTSTORE_TEST_ENVIRONMENT = 33;

	//-----DQC PROD ENVIRONMENT CERTIFICATES-----
	public static final int DQC_KEYSTORE_PROD_ENVIRONMENT = 34;

	//-----TACHO PROD ENVIRONMENT CERTIFICATES-----
	public static final int TACHO_KEYSTORE_PROD_ENVIRONMENT = 35;

	//-----DQC AND TACHO PROD TRUSTSTORE-----
	public static final int DQC_TACHO_TRUESTSTORE_PROD_ENVIRONMENT = 36;

	//-----REGIX ADR TEST ENVIRONMENT CERTIFICATES-----
	public static final int REGIX_KEY_STORE_ADR_EXAM_RESULT_TEST_AND_DRIVE_ENVIRONMENT = 40;
	public static final int REGIX_KEY_STORE_MOTOR_EXAM_RESULT_TEST_AND_DRIVE_ENVIRONMENT = 41;
	public static final int REGIX_EXAM_RESULT_TRUST_STORE_TEST_AND_DRIVE_ENVIRONMENT = 42;

	//-----REGIX ADR PROD ENVIRONMENT CERTIFICATES-----
	public static final int REGIX_KEY_STORE_ADR_EXAM_RESULT_PROD_ENVIRONMENT = 43;
	public static final int REGIX_KEY_STORE_MOTOR_EXAM_RESULT_PROD_ENVIRONMENT = 44;
	public static final int REGIX_EXAM_RESULT_TRUST_STORE_PROD_ENVIRONMENT = 45;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "key", nullable = false)
	private byte[] key;

	@Column(name = "password", nullable = false)
	private String password;

	@Column(name = "type", nullable = false)
	private String type;
}
