package bg.demax.eservices.backend.entity.config;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "languages", schema = DbSchema.CONFIG)
public class Language {
	public static final String BULGARIAN_CODE = "bg";
	public static final String ENGLISH_CODE = "en";
	
	@Id
	@Column(name = "code")
	private String code;
	
	@Column(name = "name", nullable = false)
	private String name;
}
