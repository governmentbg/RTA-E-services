package bg.demax.eservices.backend.entity.config;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "s_variables", schema = DbSchema.CONFIG)
public class SystemVariable {

	public static final String BOOLEAN = "BOOLEAN";
	public static final String DOUBLE = "DOUBLE";
	public static final String INTEGER = "INTEGER";
	public static final String STRING = "STRING";

	public static final LocalDate COVID_GRACE_PERIOD_START = LocalDate.of(2020,03,11);
	public static final LocalDate COVID_GRACE_PERIOD_PERSONAL_INFO_END = LocalDate.of(2021,01,31);
	public static final LocalDate COVID_GRACE_PERIOD_DRIVING_LICENCE_END = LocalDate.of(2020,12,31);

	// Proxy address and status
	public static final int IS_MVR_CHECK_ENABLED = 1;
	public static final int IS_NAP_CHECK_ENABLED = 2;
	public static final int IS_GRAO_CHECK_ENABLED = 3;
	public static final int IS_DQC_SERVICE_ENABLED = 4;

	// Regix proxy production urls
	public static final int REGIX_PROXY_MVR_URL_PROD = 112;
	public static final int REGIX_PROXY_NAP_URL_PROD = 113;
	public static final int REGIX_PROXY_GRAO_URL_PROD = 114;
	
	public static final int REGIX_PROXY_TACHO_LOCAL_SEARCH_PROD = 132;
	public static final int REGIX_PROXY_TACHO_EU_SEARCH_PROD = 135;

	public static final int REGIX_PROXY_NEW_TACHO_CARD_PROD = 136;
	public static final int REGIX_PROXY_NEW_DQC_CARD_URL_PROD = 142;
	public static final int REGIX_PROXY_NEW_ADR_CARD_URL_PROD = 148;

	// Regix proxy dev and drive urls
	public static final int REGIX_PROXY_MVR_URL_DRIVE = 16;
	public static final int REGIX_PROXY_MVR_URL_DEV = 129;
	public static final int REGIX_PROXY_NAP_URL_DEV_AND_DRIVE = 18;
	public static final int REGIX_PROXY_NAP_URL_DEV_HOME = 12;
	public static final int REGIX_PROXY_GRAO_URL_DEV_AND_DRIVE = 19;

	public static final int REGIX_PROXY_TACHO_LOCAL_SEARCH_DEV_AND_DRIVE = 133;
	public static final int REGIX_PROXY_TACHO_EU_SEARCH_DRIVE_AND_DEV = 134;

	public static final int REGIX_PROXY_NEW_TACHO_CARD_DRIVE = 137;

	public static final int REGIX_PROXY_NEW_DQC_CARD_URL_DRIVE = 143;
	public static final int REGIX_PROXY_NEW_DQC_CARD_URL_DEV = 144;

	public static final int REGIX_PROXY_NEW_ADR_CARD_URL_DEV = 150;
	public static final int REGIX_PROXY_NEW_ADR_CARD_URL_DRIVE = 149;

	// Regix proxy request cache period
	public static final int REGIX_PROXY_REQUEST_CACHE_PERIOD = 122;

	// Iaaa Gateway production urls
	public static final int PROXY_DQC_REGISTER_CERTIFICATES_URL_PROD = 115;
	public static final int PROXY_DQC_REGISTER_CARD_URL_PROD = 116;
	public static final int PROXY_ADR_MODULES_REGISTER_URL_PROD = 139;
	public static final int PROXY_ADR_CARD_REGISTER_URL_PROD = 145;
	
	// Iaaa Gateway dev and drive urls
	public static final int PROXY_DQC_REGISTER_CERTIFICATES_URL_DEV_AND_DRIVE = 51;
	public static final int PROXY_DQC_REGISTER_CARD_URL_DRIVE_AND_DEV = 52;
	public static final int PROXY_DQC_REGISTER_CARD_URL_DEV_HOME = 125;
	public static final int PROXY_ADR_MODULES_REGISTER_URL_DEV_AND_DRIVE = 140;
	public static final int PROXY_ADR_MODULES_REGISTER_URL_DEV_HOME = 141;
	public static final int PROXY_ADR_CARD_REGISTER_URL_DRIVE = 146;
	public static final int PROXY_ADR_CARD_REGISTER_URL_DEV = 147;
	public static final int REGIX_PROXY_TACHO_LOCAL_SEARCH_DEV_HOME = 151;
	public static final int REGIX_PROXY_TACHO_EU_SEARCH_DEV_HOME = 152;
	
	public static final int DEV_PROXY_DOC_PICTURES_URL = 53;
	public static final int DRIVE_PROXY_DOC_PICTURES_URL = 75;
	public static final int PRODUCTION_PROXY_DOC_PICTURES_URL = 93;
	
	// oAuth2 variables in production
	public static final int INFO_SERVICE_PRODUCTION_CLIENT_PRE_ESTABLISHED_REDIRECT_URI = 82;
	public static final int INFO_SERVICE_PRODUCTION_ACCESS_TOKEN_URI = 83;
	public static final int INFO_SERVICE_PRODUCTION_AUTHENTICATION_SCHEME = 84;
	public static final int INFO_SERVICE_PRODUCTION_CLIENT_AUTHENTICATION_SCHEME = 85;
	public static final int INFO_SERVICE_PRODUCTION_CLIENT_ID = 86;
	public static final int INFO_SERVICE_PRODUCTION_CLIENT_SECRET = 87;
	public static final int INFO_SERVICE_PRODUCTION_CLIENT_SCOPE = 88;
	public static final int INFO_SERVICE_PRODUCTION_CLIENT_TOKEN_NAME = 89;
	public static final int INFO_SERVICE_PRODUCTION_USER_AUTHORIZATION_URI = 90;
	public static final int INFO_SERVICE_PRODUCTION_RESOURCE_USER_INFO_URI = 91;
	public static final int INFO_SERVICE_PRODUCTION_DEFAULT_TARGET_URL = 92;

	// oAuth2 variables in drive
	public static final int INFO_SERVICE_DRIVE_CLIENT_PRE_ESTABLISHED_REDIRECT_URI = 29;
	public static final int INFO_SERVICE_DRIVE_ACCESS_TOKEN_URI = 32;
	public static final int INFO_SERVICE_DRIVE_AUTHENTICATION_SCHEME = 33;
	public static final int INFO_SERVICE_DRIVE_CLIENT_AUTHENTICATION_SCHEME = 34;
	public static final int INFO_SERVICE_DRIVE_CLIENT_ID = 35;
	public static final int INFO_SERVICE_DRIVE_CLIENT_SECRET = 36;
	public static final int INFO_SERVICE_DRIVE_CLIENT_SCOPE = 37;
	public static final int INFO_SERVICE_DRIVE_CLIENT_TOKEN_NAME = 38;
	public static final int INFO_SERVICE_DRIVE_USER_AUTHORIZATION_URI = 39;
	public static final int INFO_SERVICE_DRIVE_RESOURCE_USER_INFO_URI = 40;
	public static final int INFO_SERVICE_DRIVE_DEFAULT_TARGET_URL = 41;

	// oAuth2 variables in dev
	public static final int INFO_SERVICE_DEV_CLIENT_ID = 22;
	public static final int INFO_SERVICE_DEV_CLIENT_SECRET = 23;
	public static final int INFO_SERVICE_DEV_ACCESS_TOKEN_URI = 24;
	public static final int INFO_SERVICE_DEV_USER_AUTHORIZATION_URI = 25;
	public static final int INFO_SERVICE_DEV_CLIENT_AUTHENTICATION_SCHEME = 26;
	public static final int INFO_SERVICE_DEV_RESOURCE_USER_INFO_URI = 27;
	public static final int INFO_SERVICE_DEV_CLIENT_PRE_ESTABLISHED_REDIRECT_URI = 28;
	public static final int INFO_SERVICE_DEV_CLIENT_USE_CURRENT_URI = 31;
	public static final int INFO_SERVICE_DEV_DEFAULT_TARGET_URL = 73;

	// digital-signature verification pdf in drive
	public static final int DIGITAL_SIGNATURE_VERIFICATION_PDF_CLIENT_ID = 69;
	public static final int DIGITAL_SIGNATURE_VERIFICATION_PDF_URL = 70;
	public static final int DIGITAL_SIGNATURE_VERIFICATION_PDF_SCOPE = 71;
	public static final int DIGITAL_SIGNATURE_VERIFICATION_PDF_TOKEN = 72;
	
	// Face and signature processing services in dev
	public static final int PROCESSING_PHOTO_FACE_URL_DEV = 76;
	public static final int PROCESSING_PHOTO_SIGNATURE_URL_DEV = 77;
	public static final int PROCESSING_PHOTO_SIGNATURE_THICKNESS_URL_DEV = 78;
	public static final int PROCESSING_PHOTO_SCALE_URL_DEV = 79;
	public static final int PROCESSING_PHOTO_NORMALIZE_URL_DEV = 80;

	public static final int PHOTO_SIGNATURE_DEFAULT_THICKNESS = 81;

	// Face and signature processing services in production
	public static final int PROCESSING_PHOTO_FACE_URL_PROD = 117;
	public static final int PROCESSING_PHOTO_SIGNATURE_URL_PROD = 118;
	public static final int PROCESSING_PHOTO_SIGNATURE_THICKNESS_URL_PROD = 119;
	public static final int PROCESSING_PHOTO_SCALE_URL_PROD = 120;
	public static final int PROCESSING_PHOTO_NORMALIZE_URL_PROD = 121;

	// faceAuth variables in dev and drive
	public static final int FACE_AUTH_CLIENT_REGISTRATION_ID = 57;
	public static final int FACE_AUTH_CLIENT_ID = 58;
	public static final int FACE_AUTH_CLIENT_SECRET = 59;
	public static final int FACE_AUTH_SCOPE = 60;
	public static final int FACE_AUTH_JWK_URI = 61;
	public static final int FACE_AUTH_AUTHORIZATION_URI = 62;
	public static final int FACE_AUTH_TOKEN_URI = 63;
	public static final int FACE_AUTH_RESOURCE_USER_INFO_URI = 64;
	public static final int FACE_AUTH_USER_NAME_ATTRIBUTE = 65;
	public static final int FACE_AUTH_CLIENT_NAME = 66;

	// faceAuth variables in production
	public static final int FACE_AUTH_PROD_CLIENT_REGISTRATION_ID = 94;
	public static final int FACE_AUTH_PROD_CLIENT_ID = 95;
	public static final int FACE_AUTH_PROD_CLIENT_SECRET = 96;
	public static final int FACE_AUTH_PROD_JWK_URI = 97;
	public static final int FACE_AUTH_PROD_AUTHORIZATION_URI = 98;
	public static final int FACE_AUTH_PROD_TOKEN_URI = 99;
	public static final int FACE_AUTH_PROD_RESOURCE_USER_INFO_URI = 100;
	public static final int FACE_AUTH_PROD_USER_NAME_ATTRIBUTE = 101;
	public static final int FACE_AUTH_PROD_CLIENT_NAME = 102;

	// mail settings dev
	public static final int MAIL_HOST_DEV = 42;
	public static final int MAIL_PORT_DEV = 43;
	public static final int MAIL_USERNAME_DEV = 44;
	public static final int MAIL_PASSWORD_DEV = 45;
	public static final int MAIL_SMTP_AUTH_DEV = 46;
	public static final int MAIL_SMTP_SOCKET_FACTORY_CLASS_DEV = 47;
	public static final int MAIL_START_TLS_ENABLE_DEV = 48;
	public static final int MAIL_SSL_ENABLE_DEV = 49;
	
	// mail settings production
	public static final int MAIL_HOST_PROD = 103;
	public static final int MAIL_PORT_PROD = 104;
	public static final int MAIL_USERNAME_PROD = 105;
	public static final int MAIL_PASSWORD_PROD = 106;
	public static final int MAIL_SMTP_AUTH_PROD = 107;
	public static final int MAIL_SMTP_SOCKET_FACTORY_CLASS_PROD = 108;
	public static final int MAIL_START_TLS_ENABLE_PROD = 109;
	public static final int MAIL_SSL_ENABLE_PROD = 110;
	public static final int MAIL_PROD = 111;

	public static final int PDF_FOND_NAME = 55;
	public static final int DEFAULT_DELIVERY_TAX = 10;

	public static final int MIN_EXAM_DAYS_FROM_TODAY = 123;
	public static final int MAX_EXAM_DAYS_FROM_TODAY = 124;
	
	public static final int MIN_EXAM_DAYS_FROM_TODAY_FOR_LONG_PAYMENT = 126;
	public static final int SHORT_PAYMENT_EXAM_ENROLMENT_EXPIRATION_DAYS_FROM_TODAY = 127;
	public static final int LONG_PAYMENT_EXAM_ENROLMENT_EXPIRATION_DAYS_FROM_TODAY = 128;
	
	public static final int SHORT_PAYMENT_DEADLINE_WARNING_DAYS_FROM_TODAY = 130;
	public static final int LONG_PAYMENT_DEADLINE_WARNING_DAYS_FROM_TODAY = 131;

	// Tachograph cards
	public static final int TACHOGRAPTH_CARD_VALIDITY = 138;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "name", nullable = false)
	private String name;

	@Column(name = "description", nullable = false)
	private String description;

	@Column(name = "value", nullable = false)
	private String value;

	@Column(name = "type", nullable = false)
	private String type;
}
