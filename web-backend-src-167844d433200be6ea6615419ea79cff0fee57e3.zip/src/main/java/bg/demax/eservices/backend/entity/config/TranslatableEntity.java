package bg.demax.eservices.backend.entity.config;

import java.util.Optional;

import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;

import lombok.Getter;
import lombok.Setter;

@MappedSuperclass
@Getter
@Setter
public abstract class TranslatableEntity {
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "translation_key", nullable = false)
	private TranslationKey translationKey;

	public String getTranslationKeyString() {
		return getTranslationKey().getKey();
	}
	
	public String getTranslationValue(String languageCode) {
		if (this.getTranslationKey().getValues() == null
				|| this.getTranslationKey().getValues().isEmpty()) {
			return null;
		}
		Optional<String> translationValueOptional = this.getTranslationKey().getValues().stream().filter(translationValue -> {
			return translationValue.getLanguage().getCode().equals(languageCode);
		}).map(translationValue -> {
			return translationValue.getValue();
		}).findFirst();
		
		return translationValueOptional.orElse(null);
	}
}
