package bg.demax.eservices.backend.entity.config;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "translation_keys", schema = DbSchema.CONFIG)
@Getter
@Setter
@NoArgsConstructor
public class TranslationKey {

	public static final String ROLE_DESK_STAFF_AND_ADMIN_AND_VIEWER_SUFFIX = "_desk_staff";
	public static final String ROLE_APPLICANT_SUFFIX = "_applicant";
	public static final String ROLE_APPROVER_SUFFIX = "_approver";
	public static final String ROLE_PERSO_CENTER_DEMAX_SUFFIX = "_perso_center_demax";

	public static final String APPLICATION_STATUS_ICON_SUFFIX = "_icon";
	public static final String APPLICATION_STATUS_DESCRIPTION_SUFFIX = "_description";

	@Id
	@Column(name = "key")
	private String key;
	
	@OneToMany(mappedBy = "id.translationKey", fetch = FetchType.LAZY)
	private Set<TranslationValue> values;
	
	public TranslationKey(String key) {
		this.key = key;
	}
}
