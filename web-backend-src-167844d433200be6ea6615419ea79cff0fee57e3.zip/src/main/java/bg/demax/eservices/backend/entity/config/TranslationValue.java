package bg.demax.eservices.backend.entity.config;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "translation_values", schema = DbSchema.CONFIG)
public class TranslationValue {
	@EmbeddedId
	private TranslationValueId id;

	@Column(name = "value", nullable = false)
	private String value;

	public TranslationKey getTranslationKey() {
		return id.getTranslationKey();
	}

	public Language getLanguage() {
		return id.getLanguage();
	}

	@Embeddable
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class TranslationValueId implements Serializable {
		private static final long serialVersionUID = -7354414075732645384L;

		@ManyToOne(fetch = FetchType.LAZY)
		@JoinColumn(name = "translation_key", nullable = false)
		private TranslationKey translationKey;

		@ManyToOne(fetch = FetchType.LAZY)
		@JoinColumn(name = "language_code", nullable = false)
		private Language language;
	}
}
