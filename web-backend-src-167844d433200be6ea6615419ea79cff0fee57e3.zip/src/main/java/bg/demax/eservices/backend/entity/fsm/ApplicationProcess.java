package bg.demax.eservices.backend.entity.fsm;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.applications.Application;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "application_processes", schema = DbSchema.FINITE_STATE_MACHINE)
public class ApplicationProcess {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "start_time", nullable = false)
	private Timestamp startTime;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "application_id", nullable = false)
	private Application application;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "application_process_status_id", nullable = false)
	private ApplicationProcessStatus applicationProcessStatus;
}
