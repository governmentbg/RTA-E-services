package bg.demax.eservices.backend.entity.fsm;

import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


import bg.demax.eservices.backend.entity.applications.Remark;
import bg.demax.eservices.backend.entity.applications.RequiredDocumentType;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_application_process_statuses", schema = DbSchema.FINITE_STATE_MACHINE)
public class ApplicationProcessStatus {

	public static final int START_STATUS = 1;
	public static final int SERVICES_WORK = 14;
	public static final int BG_CITIZEN = 16;
	public static final int HAS_CHANGED_NAMES = 18;
	public static final int DL_MVR_SERVICE_WORKS = 29;
	public static final int COMMUNICATION_CHANNEL_HAS_BEEN_ENTERED_ID = 27;
	public static final int DRIVING_LICENCE_INFO_ENTERED = 33;
	public static final int CHOOSES_CERTIFICATES_FROM_REGISTER = 70;
	public static final int APPLICATION_SUBMITTED = 55;
	public static final int APPLICATION_SUBMITTED_AND_PAID = 69;
	public static final int HAS_OLD_CARD_FROM_CARD_SERVICE = 73;
	public static final int APPLICATION_APPROVED = 75;
	public static final int APPLICATION_GENERATED = 76;
	public static final int APPLICATION_CANCELED_BY_APPLICANT = 80;
	public static final int SERVICES_WORK_FOR_AUTHORIZED_PERSON = 81;
	public static final int REJECTED_IS_IRREGULAR = 87;
	public static final int CANCELED_NOT_PAID_ON_TIME = 88;
	public static final int APPLICATION_IS_RETURNED = 89;
	public static final int CARD_WAS_MADE = 90;
	public static final int CARD_WAS_SENT = 91;
	public static final int DELIVERED_IAAA = 92;
	public static final int DELIVERED_CLIENT = 93;
	public static final int ATTACHING_PHOTO_AND_SIGNATURE = 99;
	public static final int PHOTO_AND_SIGNATURE_FROM_SERVICE = 100;
	public static final int GRAO_NOT_WORK = 111;
	public static final int ENROLLED_FOR_EXAM = 113;
	public static final int APPLICATION_FINISHED = 1000;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "status", nullable = false)
	private String status;
		
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "generalized_status_id")
	private GeneralizedStatus generalizedStatus;

	@OneToMany(mappedBy = "startStatus", fetch = FetchType.LAZY)
	private List<Transition> transitions;

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(
			name = "n_remarks_statuses", schema = DbSchema.FINITE_STATE_MACHINE,
			joinColumns = @JoinColumn(name = "application_process_status_id"),
			inverseJoinColumns = @JoinColumn(name = "remark_id"))	
	private Set<Remark> remarks;
	
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(
			name = "n_required_document_types_statuses", schema = DbSchema.FINITE_STATE_MACHINE,
			joinColumns = @JoinColumn(name = "application_process_status_id"),
			inverseJoinColumns = @JoinColumn(name = "required_document_type_id"))
	private Set<RequiredDocumentType> requiredDocumentTypes;
}
