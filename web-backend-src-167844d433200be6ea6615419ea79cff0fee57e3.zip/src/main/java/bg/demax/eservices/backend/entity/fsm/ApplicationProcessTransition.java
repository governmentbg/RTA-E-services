package bg.demax.eservices.backend.entity.fsm;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "application_processes_transitions", schema = DbSchema.FINITE_STATE_MACHINE)
public class ApplicationProcessTransition {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "transition_id", nullable = false)
	private Transition transition;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "application_process_id", nullable = false)
	private ApplicationProcess applicationProcess;
	
	@Column(name = "timestamp", nullable = false)
	private Timestamp timestamp;
}
