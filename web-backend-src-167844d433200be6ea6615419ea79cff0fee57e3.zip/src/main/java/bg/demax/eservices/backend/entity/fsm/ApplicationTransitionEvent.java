package bg.demax.eservices.backend.entity.fsm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_application_transition_events", schema = DbSchema.FINITE_STATE_MACHINE)
public class ApplicationTransitionEvent {

	public static final int CHOOSES_APPLICATION_FOR_DQC_CARD = 1;
	public static final int CHOOSES_APPLICATION_FOR_ADR_CARD = 2;    
	public static final int CHOOSES_APPLICATION_FOR_TACHOGRAPH_CARD = 3;  
	public static final int CHOOSES_APPLICATION_FOR_MOTOR_EXAM = 4;  
	public static final int CHOOSES_APPLICATION_FOR_ADR_EXAM = 5;  
	public static final int CHOOSES_APPLICATION_CONSULTANT_EXAM = 6; 
	public static final int CHOOSES_APPLICATION_FOR_TAXI_DRIVER_EXAM = 7;
	public static final int AUTHENTICATING_EL_SIGNATURE = 8;
	public static final int AUTHENTICATING_FACE_AUTH = 9;
	public static final int AUTHENTICATING_AT_DESK = 10;
	public static final int AUTHORIZED_ON_BEHALF_OF_SOMEONE_ELSE = 11; 
	public static final int ENTERS_PERSONAL_INFO_OF_AUTHORIZED_PERSON = 12;  
	public static final int SERVICES_WORK = 13;
	public static final int SERVICES_DONT_WORK = 14;  
	public static final int APPLICANT_IS_BULGARIAN = 15;
	public static final int APPLICANT_IS_FROM_EU = 16;
	public static final int APPLICANT_HAS_CHANGED_NAMES = 17;
	public static final int APPLICANT_HAS_NOT_CHANGED_NAMES = 18;
	public static final int PERSONAL_INFO_IS_ADDED = 19;   
	public static final int NEEDED_DOCUMENTS_ARE_ATTACHED = 20;   
	public static final int CHOOSES_EMAIL = 21; 
	public static final int CHOOSES_CORRESPONDENCE_ADDRESS = 24;   
	public static final int CHOOSES_PHONE = 25;    
	public static final int ENTERED_EMAIL = 26;
	public static final int ENTERED_CORRESPONDENCE_ADDRESS = 29;   
	public static final int ENTERED_PHONE_NUMBER = 30;  
	public static final int ENTERS_INFO_FOR_EU_DRIVING_LICENCE = 31;
	public static final int ENTERS_INFO_FOR_NON_EU_DRIVING_LICENCE = 32; 
	public static final int DOESNT_HAVE_DRIVING_LICENCE = 33;   
	public static final int MVR_WORKS = 34;    
	public static final int MVR_DOESNT_WORK = 35;  
	public static final int DRIVING_LICENCE_INFO_IS_ENTERED = 36;   
	public static final int ENTERS_INFO_FOR_BULGARIAN_DRIVING_LICENCE = 37;   
	public static final int AUTHENTICATION_COMPLETED = 38;   
	public static final int HAS_OLD_CARD = 39;
	public static final int DOESNT_HAVE_OLD_CARD = 40;
	public static final int HAS_BG_CARD = 41;
	public static final int HAS_FOREIGN_CARD = 42;
	public static final int OLD_CARD_IS_STOLEN = 43;
	public static final int CHOSE_REASON_FOR_CHANGING_CARD = 44;
	public static final int CERTIFICATE_REQUIRED = 45;
	public static final int CERTIFICATE_NOT_REQUIRED = 46;
	public static final int CERTIFICATE_REGISTER_NOT_WORK = 47;
	public static final int CERTIFICATE_REGISTER_CHECK = 48;
	public static final int CERT_REGISTER_MISSING_CERTIFICATE = 49;
	public static final int CERTIFICATE_REGISTER_WORKS = 50;
	public static final int SELECTS_CERT_FROM_REGISTER = 51;
	public static final int NON_EU_CITIZEN = 52;
	public static final int NOT_NEED_NAP_CHECK = 53;
	public static final int NAP_DOESNT_WORK = 54;
	public static final int NAP_WORKS = 55;
	public static final int NAP_CONFIRMS_APPLICANT_WORKS = 56;
	public static final int SELECTS_CARD_TO_BE_RECEIVED_BY_AUTHORIZED_PERSON = 57;
	public static final int SELECTS_CARD_TO_BE_DELIVERED = 58;
	public static final int SELECTS_CARD_TO_RECIEVE_IN_PERSON = 59;
	public static final int ENTERED_DELIVERY_ADDRESS = 61;
	public static final int SELECTED_ORG_UNIT = 62;
	public static final int ALL_REQUIRED_DOCUMENTS_ATTACHED_CHECK = 63;
	public static final int NOT_AUTHENTICATED_WITH_PASSPORT = 64;
	public static final int AUTHENTICATED_WITH_PASSPORT = 65;
	public static final int APPLICATION_ATTACHED = 66;
	public static final int PAID = 67;
	public static final int NOT_PAID = 68;
	public static final int APPLIES_FOR_CARD = 75;
	public static final int APPLIES_FOR_EXAM = 76;
	public static final int NOT_DQC_APPLICATION = 77;
	public static final int DQC_APPLICATION = 78;
	public static final int DQC_REGISTER_WORKS = 79;
	public static final int MVR_WORKS_BUT_GRAO_DOES_NOT = 80;
	public static final int END_NAP_CHECKS = 81;
	public static final int CANCEL_APPLICATION = 82;
	public static final int ALL_REQUIRED_DOCUMENTS_ATTACHED = 83;
	public static final int APPLICATION_PDF_GENERATED = 84;
	public static final int PROCESSED_BY_OPERATOR = 85;
	public static final int APPLICATION_NOT_PAYED_IN_TIME = 86;
	public static final int APPLICATION_HAS_IRREGULARITIES = 87;
	public static final int SUBMITS_APPLICATIONS_AGAIN = 88;
	public static final int APPLICATION_HAS_NO_IRREGULARITIES = 89;
	public static final int APPLICATION_REJECTED = 90;
	public static final int HAS_CHOSEN_DELIVERY_DESK = 93;
	public static final int HAS_CHOSEN_DELIVERY_ADDRESS = 94; 
	public static final int CANCELED_BY_APPLICANT_AFTER_SUBMISSION = 95;
	public static final int PHOTO_AND_SIGNATURE_ATTACHED = 96;
	public static final int APPLIES_FOR_TACHOGRAPH = 97;
	public static final int DOESNT_APPLY_FOR_TACHOGRAPH = 98;
	public static final int CARD_REGISTER_DOESNT_WORK = 99;
	public static final int CARD_REGISTER_WORKS = 100;
	public static final int DO_NOT_HAVE_CARD_IN_REGISTER = 101;
	public static final int MODULE_REGISTER_MISSING_MODULES_OR_DOESNT_WORK = 102;
	public static final int NEEDED_DATA_IS_ENTERED = 103;
	public static final int MODULE_REGISTER_CHECK = 104;
	public static final int MODULES_SELECTED = 105;
	public static final int MODULE_REGISTER_WORKS = 106;
	public static final int CERTIFICATE_REGISTER_DOESNT_WORK = 107;
	public static final int MODULE_REGISTER_DOESNT_WORK = 108;
	public static final int CHOSES_TO_ATTACH_CERT_PASSENGERS = 109;
	public static final int CHOSES_TO_ATTACH_CERT_GOODS = 110;
	public static final int CHOSES_TO_ATTACH_CERT_PASSENGERS_AND_GOODS = 111;
	public static final int FIXING_ISSUES = 112;
	public static final int SELECTED_EXAM_PERSON_AND_PROTOCOL = 113;
	public static final int TAXI_EXAM_DATA_ENTERED_AND_SELECTED_PROTOCOL = 114;
	public static final int CARD_IS_LOST = 115;
	public static final int UPLOAD_CARD = 116;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "event", nullable = false)
	private String event;
}