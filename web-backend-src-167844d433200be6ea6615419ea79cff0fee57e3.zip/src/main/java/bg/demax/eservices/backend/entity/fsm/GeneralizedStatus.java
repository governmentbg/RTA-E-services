package bg.demax.eservices.backend.entity.fsm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.TranslatableEntity;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_generalized_statuses", schema = DbSchema.FINITE_STATE_MACHINE)
public class GeneralizedStatus extends TranslatableEntity {
	public static final int DRAFT = 1;
	public static final int SUBMITTED_EXPECTS_PAYMENT = 2;
	public static final int REJECTED_NOT_PAID_ON_TIME = 3;
	public static final int SUBMITTED_AND_PAID = 4;
	public static final int SUBMITTED_REJECTED_IRREGULARITIES = 5;
	public static final int SUBMITTED_RETURNED = 6;
	public static final int CANCELED_BY_APPLICANT = 7;
	public static final int APPROVED = 8;
	public static final int DELIVERED_IAAA = 9;
	public static final int DELIVERED_CLIENT = 10;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
		
	@Column(name = "status_description")
	private String string;
}
