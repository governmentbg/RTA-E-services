package bg.demax.eservices.backend.entity.fsm;

import java.util.Arrays;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_milestone_statuses", schema = DbSchema.FINITE_STATE_MACHINE)
public class MilestoneStatus {

	public static final int START = 1;
	public static final int ENTERING_PERSONAL_DATA = 2;
	public static final int PERSONAL_DATA_ENTERED = 4;
	public static final int CORRESPONDENCE_INFO_ENTERED = 5;
	public static final int DRIVING_LICENCE_INFO_ENTERED = 7;	
	public static final int CERTIFICATES_INFO_ENTERED = 8;
	public static final int CARD_ISSUING_INFO_ENTERED = 10;
	public static final int SIGNATURE_AND_PHOTO_ATTACHED = 12;

	public static final List<Integer> MILESTONES_WITH_DOCS_FOR_CARD_APPLICATION = 
		Arrays.asList(MilestoneStatus.ENTERING_PERSONAL_DATA, MilestoneStatus.CORRESPONDENCE_INFO_ENTERED,
			MilestoneStatus.DRIVING_LICENCE_INFO_ENTERED, MilestoneStatus.CERTIFICATES_INFO_ENTERED);

	public static final List<Integer> MILESTONES_WITH_DOCS_FOR_EXAM_APPLICATION = 
		Arrays.asList(MilestoneStatus.ENTERING_PERSONAL_DATA, MilestoneStatus.CORRESPONDENCE_INFO_ENTERED);

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status_id", nullable = false)
	private ApplicationProcessStatus status;
}
