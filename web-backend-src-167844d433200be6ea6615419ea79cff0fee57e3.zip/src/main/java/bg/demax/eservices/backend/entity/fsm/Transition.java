package bg.demax.eservices.backend.entity.fsm;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_transitions", schema = DbSchema.FINITE_STATE_MACHINE)
public class Transition {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "transition_event_id", nullable = false)
	private ApplicationTransitionEvent transitionEvent;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "start_status_id", nullable = false)
	private ApplicationProcessStatus startStatus;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "end_status_id", nullable = false)
	private ApplicationProcessStatus endStatus;

	@OneToMany(mappedBy = "transition", fetch = FetchType.LAZY)
	private List<ApplicationProcessTransition> applicationProcessTransitions;
}
