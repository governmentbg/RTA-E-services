package bg.demax.eservices.backend.entity.security;

import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.config.TranslatableEntity;
import bg.demax.eservices.backend.entity.fsm.GeneralizedStatus;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_roles", schema = DbSchema.SECURITY)
public class Role extends TranslatableEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "role", nullable = false, unique = true)
	private String role;

	@Column(name = "description")
	private String description;

	@ManyToMany(mappedBy = "roles", fetch = FetchType.LAZY)
	private Set<User> users;
	
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "n_generalized_statuses_roles",
				schema = DbSchema.FINITE_STATE_MACHINE,
				joinColumns = @JoinColumn(name = "role_id"),
				inverseJoinColumns = @JoinColumn(name = "generalized_status_id"))
	private List<GeneralizedStatus> statuses;
	
	@Getter
	@AllArgsConstructor
	public static enum Roles {
		ROLE_APPLICANT_E_SIGN(1, "APPLICANT_E_SIGN"),
		ROLE_APPLICANT_E_FACE(2, "APPLICANT_E_FACE"),
		ROLE_APPROVER(3, "APPROVER"),
		// ! Add new role with id >>> 4
		ROLE_VIEWER(5, "VIEWER"),
		ROLE_DESK_STAFF(6, "DESK_STAFF"),
		// ! Add new role with id  >>> 7
		ROLE_ADMIN_DEMAX(8, "ADMIN_DEMAX"),
		ROLE_PERSO_CENTER_DEMAX(9, "PERSO_CENTER_DEMAX");
		
		private Integer id;
		private String name;
	}
}
