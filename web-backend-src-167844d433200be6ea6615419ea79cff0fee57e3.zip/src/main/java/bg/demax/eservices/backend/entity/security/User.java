package bg.demax.eservices.backend.entity.security;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import bg.demax.eservices.backend.entity.applications.Email;
import bg.demax.eservices.backend.entity.subjects.Subject;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "users", schema = DbSchema.SECURITY)
public class User implements UserDetails {

	private static final long serialVersionUID = -2472924825652499440L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "email_id")
	private Email email;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "subject_id", nullable = false)
	private Subject subject;

	@Column(name = "is_active", nullable = false)
	private boolean isActive;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "users_roles",
				schema = DbSchema.SECURITY,
				joinColumns = @JoinColumn(name = "user_id"),
				inverseJoinColumns = @JoinColumn(name = "role_id"))
	private Set<Role> roles;
	
	@Column(name = "is_verified", nullable = false)
	private boolean isVerified;

	@OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
	private Set<UserSignature> signatures;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	@OrderBy("id DESC")
	private List<UserHistoryLog> userHistoryLogs;
	
	@OneToOne(mappedBy = "user", fetch = FetchType.LAZY)
	private VerificationToken token;

	@Override
	public List<GrantedAuthority> getAuthorities() {
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		List<GrantedAuthority> securityAuthorities = getRoles().stream().map(role -> {
			return new SimpleGrantedAuthority(role.getRole());
		}).collect(Collectors.toList());
		authorities.addAll(securityAuthorities);

		return authorities;
	}

	@Override
	public String getPassword() {
		return null;
	}

	@Override
	public String getUsername() {
		return this.subject.getIdentityNumber() + this.subject.getIdentityNumberType().getType();
	}

	@Override
	public boolean isAccountNonExpired() {
		return isActive;
	}

	@Override
	public boolean isAccountNonLocked() {
		return isActive;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return isActive;
	}

	@Override
	public boolean isEnabled() {
		return isActive;
	}
}
