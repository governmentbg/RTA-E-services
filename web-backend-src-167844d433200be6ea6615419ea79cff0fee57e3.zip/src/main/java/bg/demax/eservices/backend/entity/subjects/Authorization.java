package bg.demax.eservices.backend.entity.subjects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.applications.Application;
import bg.demax.eservices.backend.entity.applications.IdentityDocument;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "authorizations", schema = DbSchema.SUBJECTS)
public class Authorization {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "authorized_subject_id", nullable = false)
	private Subject authorizedSubject;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "application_id", nullable = false)
	private Application application;
		
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "identity_document_id", nullable = false)
	private IdentityDocument identityDocument;
}
