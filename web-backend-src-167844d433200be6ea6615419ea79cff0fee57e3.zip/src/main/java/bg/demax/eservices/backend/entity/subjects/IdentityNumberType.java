package bg.demax.eservices.backend.entity.subjects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "n_identity_number_types", schema = DbSchema.SUBJECTS)
public class IdentityNumberType {

	public static final int EGN = 1;
	public static final int LNCH = 2;
	public static final int EIK = 3;
	public static final int SYSTEM_No = 4; // NAP temp number

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "type", nullable = false)
	private String type;

	public String getCyrillicCode() {
		switch (this.id) {
			case EGN:
				return "ЕГН";
			case LNCH:
				return "ЛНЧ";
			case EIK:
				return "ЕИК";
			case SYSTEM_No:
				return "ID";
			default:
				throw new RuntimeException("Unknown IdentityNumberType.");
		}
	}
}
