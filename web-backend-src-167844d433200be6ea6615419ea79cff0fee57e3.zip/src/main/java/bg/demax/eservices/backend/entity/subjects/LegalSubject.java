package bg.demax.eservices.backend.entity.subjects;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "legal_subjects", schema = DbSchema.SUBJECTS)
public class LegalSubject extends Subject {

	@OneToMany(mappedBy = "legalSubject", fetch = FetchType.LAZY)
	private List<LegalSubjectVersion> subjectVersions;

	public LegalSubjectVersion getValidVersion() {
		if (getSubjectVersions() != null) {
			return getSubjectVersions().stream().filter(version -> version.getIsValid()).findFirst().orElse(null);
		}
		return null;
	}
}
