package bg.demax.eservices.backend.entity.subjects;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "legal_subject_versions", schema = DbSchema.SUBJECTS)
public class LegalSubjectVersion {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "legal_subject_id", nullable = false)
	private LegalSubject legalSubject;
	
	@Column(name = "version_date_time", nullable = false)
	private Timestamp versionDateTime;
	
	@Column(name = "company_name")
	private String companyName;
	
	@Column(name = "is_valid", nullable = false)
	private Boolean isValid;
}
