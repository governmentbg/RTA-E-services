package bg.demax.eservices.backend.entity.subjects;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "physical_subjects", schema = DbSchema.SUBJECTS)
public class PhysicalSubject extends Subject {
	@Column(name = "birth_date")
	private LocalDate birthDate;

	@Column(name = "birth_place")
	private String birthPlace;

	@Column(name = "birth_place_lat")
	private String birthPlaceLatin;

	@OneToMany(mappedBy = "physicalSubject", fetch = FetchType.LAZY)
	private List<PhysicalSubjectVersion> subjectVersions;
	
	public PhysicalSubjectVersion getValidVersion() {
		if (getSubjectVersions() != null) {
			return getSubjectVersions().stream().filter(version -> version.getIsValid()).findFirst().orElse(null);
		}
		return null;
	}
}
