package bg.demax.eservices.backend.entity.subjects;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "physical_subject_versions", schema = DbSchema.SUBJECTS)
public class PhysicalSubjectVersion {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "physical_subject_id", nullable = false)
	private PhysicalSubject physicalSubject;
	
	@Column(name = "version_date_time", nullable = false)
	private Timestamp versionDateTime;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "first_name_cyr_id")
	private PhysicalSubjectName firstNameCyr;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "fathers_name_cyr_id")
	private PhysicalSubjectName fathersNameCyr;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "family_name_cyr_id")
	private PhysicalSubjectName familyNameCyr;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "first_name_lat_id", nullable = false)
	private PhysicalSubjectName firstNameLat;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "fathers_name_lat_id")
	private PhysicalSubjectName fathersNameLat;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "family_name_lat_id", nullable = false)
	private PhysicalSubjectName familyNameLat;

	@Column(name = "is_valid", nullable = false)
	private Boolean isValid;

	public String getFullName() {
		StringBuilder fullNameBuilder = new StringBuilder();
		if (firstNameCyr != null && familyNameCyr != null) {
			fullNameBuilder.append(firstNameCyr.getName()).append(" ");
			if (fathersNameCyr != null) {
				fullNameBuilder.append(fathersNameCyr.getName()).append(" ");
			}
			fullNameBuilder.append(familyNameCyr.getName());
			
			return fullNameBuilder.toString();
		} else if (firstNameLat != null && familyNameLat != null) {
			fullNameBuilder.append(firstNameLat.getName()).append(" ");
			if (fathersNameLat != null) {
				fullNameBuilder.append(fathersNameLat.getName()).append(" ");	
			}
			fullNameBuilder.append(familyNameLat.getName());
			
			return fullNameBuilder.toString();
		} else {
			return null;
		}
	}

	public String getFirstNameCyrString() {
		if (this.getFirstNameCyr() != null) {
			return this.getFirstNameCyr().getName();
		}
		return null;
	}

	public String getFathersNameCyrString() {
		if (this.getFathersNameCyr() != null) {
			return this.getFathersNameCyr().getName();
		}
		return null;
	}

	public String getFamilyNameCyrString() {
		if (this.getFamilyNameCyr() != null) {
			return this.getFamilyNameCyr().getName();
		}
		return null;
	}

	public String getFirstNameLatString() {
		if (this.getFirstNameLat() != null) {
			return this.getFirstNameLat().getName();
		}
		return null;
	}

	public String getFathersNameLatString() {
		if (this.getFathersNameLat() != null) {
			return this.getFathersNameLat().getName();
		}
		return null;
	}

	public String getFamilyNameLatString() {
		if (this.getFamilyNameLat() != null) {
			return this.getFamilyNameLat().getName();
		}
		return null;
	}
}
