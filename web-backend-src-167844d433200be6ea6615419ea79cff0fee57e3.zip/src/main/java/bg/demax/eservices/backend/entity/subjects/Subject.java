package bg.demax.eservices.backend.entity.subjects;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import bg.demax.eservices.backend.entity.applications.Application;
import bg.demax.eservices.backend.entity.applications.DqcCertificate;
import bg.demax.eservices.backend.entity.security.User;
import bg.demax.eservices.backend.enumeration.DbSchema;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "subjects", schema = DbSchema.SUBJECTS)
@Inheritance(strategy = InheritanceType.JOINED)
public class Subject {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "identity_number", nullable = false)
	private String identityNumber;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "identity_number_type_id", nullable = false)
	private IdentityNumberType identityNumberType;

	@OneToMany(mappedBy = "subject", fetch = FetchType.LAZY)
	private List<Application> applications;
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "subject")
	private User user;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "subject")
	private Set<DqcCertificate> dqcCertificates = new HashSet<>();
}
