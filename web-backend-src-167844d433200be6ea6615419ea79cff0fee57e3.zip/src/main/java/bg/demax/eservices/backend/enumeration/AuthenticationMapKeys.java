package bg.demax.eservices.backend.enumeration;

public interface AuthenticationMapKeys {
	String CERTNO = "certno";
	String NAME = "name";
	String MAIL = "mail";
	String PID_ISSUER = "pid_issuer";
	String PID = "pid";
	String EGN = "egn";
	String ORGANIZATION = "organization";
	String ORG_ISSUER = "org_issuer";
	String ORG = "org";
	String BULSTAT = "bulstat";
	String PUBLIC_KEY = "public_key";
	String NAME_CYR = "nameCyrillic";
}
