package bg.demax.eservices.backend.enumeration;

public interface DbSchema {
	String FINITE_STATE_MACHINE = "finite_state_machine";
	String SUBJECTS = "subjects";
	String SECURITY = "security";
	String CONFIG = "config";
	String APPLICATIONS = "applications";
}
