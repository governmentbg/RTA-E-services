package bg.demax.eservices.backend.exception;

public class AddressException extends ApplicationException {

	private static final long serialVersionUID = -4673248389800235654L;

	public AddressException(String message) {
		super(message);
	}
}
	