package bg.demax.eservices.backend.exception;

public class ApplicationProcessStatusIsNotMilestone extends ApplicationException {

	private static final long serialVersionUID = 1L;

	public ApplicationProcessStatusIsNotMilestone(int applicationId, int statusId) {
		super(String.format("Status with id %d of application with id %d is not a milestone status.", statusId, applicationId));
	}
}
