package bg.demax.eservices.backend.exception;

public class CardApplicationAlreadyStartedException extends ApplicationException {
	private static final long serialVersionUID = -3625355373176179339L;
	
	public CardApplicationAlreadyStartedException(int applicationId) {
		super(String.format(
			"User of application with id : %d has already started process for new card. Can not continue application.", 
				applicationId));
	}
}
