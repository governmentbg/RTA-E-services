package bg.demax.eservices.backend.exception;

public class CardCreationRequestException extends ApplicationException {

	private static final long serialVersionUID = -8032742549101989209L;

	public CardCreationRequestException(String message) {
		super(message);
	}
}