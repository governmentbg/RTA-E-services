package bg.demax.eservices.backend.exception;

public class DocumentExpiredException extends ApplicationException {

	private static final long serialVersionUID = -4673248389805235654L;

	public DocumentExpiredException(String documentNumber) {
		super(String.format("Document with number %s has expired.", documentNumber));
	}

	public DocumentExpiredException(int applicationId) {
		super(String.format("Document for application with id: %d is expired", applicationId));
	}
}
