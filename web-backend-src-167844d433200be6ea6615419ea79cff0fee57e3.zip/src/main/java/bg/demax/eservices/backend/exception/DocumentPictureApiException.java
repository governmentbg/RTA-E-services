package bg.demax.eservices.backend.exception;

public class DocumentPictureApiException extends ApplicationException {

	private static final long serialVersionUID = -3625346373176179339L;

	public DocumentPictureApiException(String reason) {
		super(reason);
	}
}