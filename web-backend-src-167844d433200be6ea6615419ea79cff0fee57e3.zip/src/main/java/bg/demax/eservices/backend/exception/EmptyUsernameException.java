package bg.demax.eservices.backend.exception;

public class EmptyUsernameException extends ApplicationException {
	private static final long serialVersionUID = -3997926358528726034L;

}
