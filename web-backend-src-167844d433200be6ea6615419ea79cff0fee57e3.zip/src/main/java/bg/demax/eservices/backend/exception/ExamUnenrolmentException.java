package bg.demax.eservices.backend.exception;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class ExamUnenrolmentException extends ApplicationException {

	private static final long serialVersionUID = 6848385703446763895L;

	private List<Exception> exceptions;
	
	public ExamUnenrolmentException() {
		super("Errors while unenrolling exam applications.");
		exceptions = new LinkedList<>();
	}

	public void addException(Exception e) {
		this.exceptions.add(e);
	}
	
	@Override
	public String getMessage() {
		return super.getMessage() + " \n " 
				+ "Underlying exceptions are: " + this.exceptions.stream().map(exception -> {
					return exception.getClass().getName() + ": " + exception.getMessage() + ";\n";
				}).collect(Collectors.toList());
	}
}
