package bg.demax.eservices.backend.exception;

public class FirstNameLatinNotFound extends ApplicationException {

	private static final long serialVersionUID = 5674123264476884221L;

	public FirstNameLatinNotFound(int subjectVersionId) {
		super(String.format("First name in Latin not found in subject version with id %d.", subjectVersionId));
	}
}