package bg.demax.eservices.backend.exception;

public class InvalidApplicationProcessStatusException extends ApplicationException {

	private static final long serialVersionUID = 3729749032337891261L;

	public InvalidApplicationProcessStatusException(int currentStatusId, int expectedStatusId) {
		super("Invalid current application process status. Expected status id is: " + expectedStatusId 
				+ ", but is: " + currentStatusId);
	}
}
