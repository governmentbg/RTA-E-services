package bg.demax.eservices.backend.exception;

public class InvalidCorrespondenceContactException extends ApplicationException {
	private static final long serialVersionUID = 3490414836761487203L;

	public InvalidCorrespondenceContactException(String message) {
		super(message);
	}
}
