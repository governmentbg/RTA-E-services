package bg.demax.eservices.backend.exception;

public class InvalidIdException extends ApplicationException {
	private static final long serialVersionUID = -1353722130948721734L;

	public InvalidIdException(String codes, Class<?> clazz) {
		super("Invalid %s ID detected in %s!", clazz.getSimpleName(), codes);
	}
}
