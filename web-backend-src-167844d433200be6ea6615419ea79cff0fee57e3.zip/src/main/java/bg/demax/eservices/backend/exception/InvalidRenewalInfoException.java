package bg.demax.eservices.backend.exception;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class InvalidRenewalInfoException extends ApplicationException {
	private static final long serialVersionUID = 3542869600029530115L;
	
	public InvalidRenewalInfoException(String message) {
		super(message);
	}
}
