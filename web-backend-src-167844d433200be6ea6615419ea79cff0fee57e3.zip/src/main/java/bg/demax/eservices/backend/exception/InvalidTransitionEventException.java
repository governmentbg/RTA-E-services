package bg.demax.eservices.backend.exception;

public class InvalidTransitionEventException extends ApplicationException {

	private static final long serialVersionUID = -3625346373176179339L;

	public InvalidTransitionEventException(String startStatus, String event) {
		super(String.format(
				"There is no valid transition with start status '%s' and event '%s'. Please, choose a different event",
				startStatus, event));
	}
}