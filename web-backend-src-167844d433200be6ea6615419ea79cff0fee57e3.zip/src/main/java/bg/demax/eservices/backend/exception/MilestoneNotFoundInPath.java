package bg.demax.eservices.backend.exception;

public class MilestoneNotFoundInPath extends ApplicationException {

	private static final long serialVersionUID = -1849302491699163665L;

	public MilestoneNotFoundInPath(int milestoneId, int applicationId) {
		super(String.format("Milestone status with id %d not found in path for application with id %d", 
				milestoneId, applicationId));
	}

	public MilestoneNotFoundInPath(String message) {
		super(message);
	}
}
