package bg.demax.eservices.backend.exception;

public class MismatchException extends ApplicationException {

	private static final long serialVersionUID = -3217744893370622214L;

	public MismatchException(String message) {
		super(message);
	}
}