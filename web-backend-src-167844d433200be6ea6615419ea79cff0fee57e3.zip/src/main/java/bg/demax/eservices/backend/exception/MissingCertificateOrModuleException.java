package bg.demax.eservices.backend.exception;

public class MissingCertificateOrModuleException extends ApplicationException {

	private static final long serialVersionUID = 6828109635228370283L;

	public MissingCertificateOrModuleException(int applicationId, int trainingTypeId) {
		super("File for training type with id %d is not attached. Application id: %d",
				trainingTypeId, applicationId);
	}

	public MissingCertificateOrModuleException(int applicationId) {
		super("No certificates or module found for application with id: %d", applicationId);
	}

	public MissingCertificateOrModuleException(String string) {
		super(string);
	}
}
