package bg.demax.eservices.backend.exception;

public class MissingPaymentException extends ApplicationException {
	private static final long serialVersionUID = -4466104989700320927L;

	public MissingPaymentException(String message) {
		super(message);
	}
}