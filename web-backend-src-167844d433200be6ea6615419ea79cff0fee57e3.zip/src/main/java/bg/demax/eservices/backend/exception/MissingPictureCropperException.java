package bg.demax.eservices.backend.exception;

public class MissingPictureCropperException extends ApplicationException  {
	private static final long serialVersionUID = -8326068377466575200L;
}