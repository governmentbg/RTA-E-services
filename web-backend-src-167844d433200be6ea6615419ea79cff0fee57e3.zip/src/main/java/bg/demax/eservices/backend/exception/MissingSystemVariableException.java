package bg.demax.eservices.backend.exception;

public class MissingSystemVariableException extends ApplicationException {
	private static final long serialVersionUID = -4466104989700320927L;

	public MissingSystemVariableException(String reason) {
		super(reason);
	}
}