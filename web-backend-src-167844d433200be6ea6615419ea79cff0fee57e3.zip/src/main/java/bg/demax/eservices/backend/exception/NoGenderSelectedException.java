package bg.demax.eservices.backend.exception;

public class NoGenderSelectedException extends ApplicationException {
	private static final long serialVersionUID = -8323407235615271853L;
}
