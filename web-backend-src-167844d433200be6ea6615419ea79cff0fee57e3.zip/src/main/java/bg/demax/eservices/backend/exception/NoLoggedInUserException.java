package bg.demax.eservices.backend.exception;

public class NoLoggedInUserException extends ApplicationException {
	private static final long serialVersionUID = -8326068377466575286L;
}
