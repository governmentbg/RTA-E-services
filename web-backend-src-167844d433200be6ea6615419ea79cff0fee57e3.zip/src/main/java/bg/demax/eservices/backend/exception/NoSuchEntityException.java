package bg.demax.eservices.backend.exception;

import java.io.Serializable;

public class NoSuchEntityException extends ApplicationException {
	private static final long serialVersionUID = -1374115713869604446L;

	public NoSuchEntityException(Class<?> clazz, Serializable id) {
		super(clazz.getSimpleName() + " with id " + id + " not found.");
	}

	public NoSuchEntityException(String message) {
		super(message);
	}

	public NoSuchEntityException(String message, Object... args) {
		super(message, args);
	}
}
