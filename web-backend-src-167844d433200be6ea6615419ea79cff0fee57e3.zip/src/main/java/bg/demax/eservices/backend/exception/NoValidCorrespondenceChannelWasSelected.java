package bg.demax.eservices.backend.exception;

public class NoValidCorrespondenceChannelWasSelected extends ApplicationException {

	private static final long serialVersionUID = 432763181397176064L;
}
