package bg.demax.eservices.backend.exception;

public class RepeatingTypesException extends ApplicationException {
	private static final long serialVersionUID = -585901912460092343L;

	public RepeatingTypesException(String message) {
		super(message);
	}
}
