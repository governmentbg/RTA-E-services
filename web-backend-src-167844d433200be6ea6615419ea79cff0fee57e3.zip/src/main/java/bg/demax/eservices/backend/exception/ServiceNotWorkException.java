package bg.demax.eservices.backend.exception;

public class ServiceNotWorkException extends ApplicationException {
	private static final long serialVersionUID = -585901912460092343L;

	public ServiceNotWorkException(String message) {
		super(message);
	}
}