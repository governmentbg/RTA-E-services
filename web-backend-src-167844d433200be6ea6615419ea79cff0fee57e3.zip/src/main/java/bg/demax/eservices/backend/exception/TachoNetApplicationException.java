package bg.demax.eservices.backend.exception;

public class TachoNetApplicationException extends ApplicationException {

	private static final long serialVersionUID = -6228336830177219687L;

	public TachoNetApplicationException(String message) {
		super(message);
	}
	
}
