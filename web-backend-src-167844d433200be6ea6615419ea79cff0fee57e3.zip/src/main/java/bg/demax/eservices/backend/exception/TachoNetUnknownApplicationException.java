package bg.demax.eservices.backend.exception;

public class TachoNetUnknownApplicationException extends TachoNetApplicationException {

	private static final long serialVersionUID = 4875558102034842977L;

	public TachoNetUnknownApplicationException(String message) {
		super(message);
	}
	
}
