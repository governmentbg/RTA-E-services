package bg.demax.eservices.backend.exception;

import java.util.Arrays;

import bg.demax.eservices.backend.entity.security.Role.Roles;

public class UserAccessDeniedException extends ApplicationException {
	private static final long serialVersionUID = 5495539679851121776L;

	public UserAccessDeniedException(int userId, Roles... expectedRoles) {
		super("User with id: " + userId + " must have one of the following roles: " + Arrays.toString(expectedRoles));
	}

	public UserAccessDeniedException(Roles... expectedRoles) {
		super("User must have one of the following roles: " + Arrays.toString(expectedRoles));
	}
	
	public UserAccessDeniedException(String message) {
		super(message);
	}
}
