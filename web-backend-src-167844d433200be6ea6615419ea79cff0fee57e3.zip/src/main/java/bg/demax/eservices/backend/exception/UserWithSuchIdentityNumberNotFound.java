package bg.demax.eservices.backend.exception;

public class UserWithSuchIdentityNumberNotFound extends ApplicationException {

	private static final long serialVersionUID = -3625346373176179339L;

	public UserWithSuchIdentityNumberNotFound(String identityNumber) {
		super(String.format("User with identityNumber %s not found", identityNumber));
	}
}