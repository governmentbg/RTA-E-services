package bg.demax.eservices.backend.exception.file;

import bg.demax.eservices.backend.exception.ApplicationException;

public class DigitalSignatureVerificationServiceException extends ApplicationException {
	private static final long serialVersionUID = -6666021942217112318L;

	public DigitalSignatureVerificationServiceException(String message) {
		super(message);
	}
}