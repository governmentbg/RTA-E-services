package bg.demax.eservices.backend.exception.file;

import bg.demax.eservices.backend.exception.ApplicationException;

public class GeneratedApplicationException extends ApplicationException {

	private static final long serialVersionUID = -4673248389805235655L;

	public GeneratedApplicationException(int applicationId, String fieldName) {
		super(String.format(
			"Application with number %d can not be generated. Missing %s field information.", applicationId, fieldName));
	}
}