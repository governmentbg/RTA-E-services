package bg.demax.eservices.backend.exception.file;

import bg.demax.eservices.backend.exception.ApplicationException;

public class InvalidPdfSignatureException extends ApplicationException {

	private static final long serialVersionUID = -4673248389805235654L;

	public InvalidPdfSignatureException(int applicationId) {
		super(String.format(
			"Invalid or missing digital signature on application with id : %d.", applicationId));
	}
}