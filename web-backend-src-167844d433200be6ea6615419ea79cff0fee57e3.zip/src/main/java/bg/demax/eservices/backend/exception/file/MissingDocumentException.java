package bg.demax.eservices.backend.exception.file;

import bg.demax.eservices.backend.exception.ApplicationException;

public class MissingDocumentException extends ApplicationException {
	private static final long serialVersionUID = -4673248389805235654L;

	public MissingDocumentException(int applicationId, int requiredDocTypeId) {
		super(String.format(
			"Missing required document. \nDocument type id: %d \nApplication id : %d.", requiredDocTypeId, applicationId));
	}
}