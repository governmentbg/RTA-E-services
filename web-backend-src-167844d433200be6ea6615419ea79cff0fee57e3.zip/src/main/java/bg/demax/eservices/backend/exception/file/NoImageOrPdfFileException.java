package bg.demax.eservices.backend.exception.file;

import bg.demax.eservices.backend.exception.ApplicationException;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NoImageOrPdfFileException extends ApplicationException {
	private static final long serialVersionUID = -749189548589788679L;

	public NoImageOrPdfFileException(String filename, int applicationId) {
		super("Uploaded file : " + filename + " for application with id : " + applicationId
			+ " has correct extension but wrong content.Must be picture or pdf.");
	}
}