package bg.demax.eservices.backend.exception.file;

import bg.demax.eservices.backend.exception.ApplicationException;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NotExactlyOneFaceDetectedException extends ApplicationException {
	private static final long serialVersionUID = -3213444822270622214L;

	public NotExactlyOneFaceDetectedException(String message) {
		super(message);
	}
}