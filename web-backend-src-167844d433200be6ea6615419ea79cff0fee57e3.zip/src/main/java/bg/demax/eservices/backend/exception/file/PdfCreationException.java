package bg.demax.eservices.backend.exception.file;

import bg.demax.eservices.backend.exception.ApplicationException;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PdfCreationException extends ApplicationException {
	private static final long serialVersionUID = -3217744822270622214L;

	public PdfCreationException(int attachedDocumentId, int documentTypeId) {
		super(String.format("PDF file with all pages of AttachedDocument with id: "
			+ " %d and type : %d can not be created.", attachedDocumentId, documentTypeId));
	}

	public PdfCreationException(int applicationId) {
		super(String.format("PDF file of application with id : %d and all attached documents can not be created.", applicationId));
	}

	public PdfCreationException(int applicationId, String pictureName) {
		super(String.format("PDF file of application with id : %d and all attached documents can not be created."
			+ "Can not add picture %s to pdf", applicationId, pictureName));
	}

	public PdfCreationException(String message) {
		super(message);
	}
}