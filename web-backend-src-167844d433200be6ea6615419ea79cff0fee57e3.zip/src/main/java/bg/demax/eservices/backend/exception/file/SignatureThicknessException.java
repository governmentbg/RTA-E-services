package bg.demax.eservices.backend.exception.file;

import bg.demax.eservices.backend.exception.ApplicationException;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SignatureThicknessException extends ApplicationException {
	private static final long serialVersionUID = -3217744822270648214L;

	public SignatureThicknessException(int applicationId) {
		super(String.format("Attached signature for application with id : %d  is too thin.", applicationId));
	}

}