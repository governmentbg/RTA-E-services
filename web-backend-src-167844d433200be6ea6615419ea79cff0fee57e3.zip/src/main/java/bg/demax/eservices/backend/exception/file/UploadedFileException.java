package bg.demax.eservices.backend.exception.file;

import bg.demax.eservices.backend.exception.ApplicationException;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UploadedFileException extends ApplicationException {
	private static final long serialVersionUID = -749189548589788679L;

	public UploadedFileException(String filename, int applicationId) {
		super("Uploaded file : " + filename + " for application with id : " + applicationId
			+ " has wrong extension. Must be one of : .png .jpg .pdf");
	}

	public UploadedFileException(String filename, int applicationId, int documentTypeId) {
		super("Uploaded file page : " + filename + " for document typeId : " + documentTypeId + " and application with id : " 
			+ applicationId	+ " already exists with different name");
	}

	public UploadedFileException(int pageId, int applicationId) {
		super("Can't delete page with id: %d of submitted application with id: %d", pageId, applicationId);
	}

	public UploadedFileException(String message) {
		super(message);
	}

	public UploadedFileException(int applicationId) {
		super("Can't save uploaded application with id : %d. Required documents are missing.", applicationId);
	}
}