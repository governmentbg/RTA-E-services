package bg.demax.eservices.backend.exception.proxy;

import bg.demax.eservices.backend.exception.ApplicationException;

public class ConnectionToServiceFailedException extends ApplicationException {
	private static final long serialVersionUID = 8817815853725173474L;

	public ConnectionToServiceFailedException(String message) {
		super(message);
	}
}
