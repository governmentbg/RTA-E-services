package bg.demax.eservices.backend.exception.proxy;

import bg.demax.eservices.backend.exception.ApplicationException;

public class DocumentNotFoundRegixException extends ApplicationException {

	private static final long serialVersionUID = -233075743462156449L;

	public DocumentNotFoundRegixException(String documentNumber) {
		super(String.format("Document with number %s not found in %s", documentNumber));
	}
}