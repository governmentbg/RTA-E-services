package bg.demax.eservices.backend.exception.proxy;

import bg.demax.eservices.backend.exception.ApplicationException;

public class DocumentStorageException extends ApplicationException {

	private static final long serialVersionUID = 1093200612338986847L;

	public DocumentStorageException(String message) {
		super(message);
	}
}
