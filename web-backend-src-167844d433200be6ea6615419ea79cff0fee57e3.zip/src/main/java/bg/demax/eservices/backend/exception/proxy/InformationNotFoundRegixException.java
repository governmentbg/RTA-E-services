package bg.demax.eservices.backend.exception.proxy;

import bg.demax.eservices.backend.exception.ApplicationException;

public class InformationNotFoundRegixException extends ApplicationException {

	private static final long serialVersionUID = 979907684145560504L;

	public InformationNotFoundRegixException(String message) {
		super(message);
	}
}