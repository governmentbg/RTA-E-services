package bg.demax.eservices.backend.exception.proxy;

import java.time.LocalDate;

import bg.demax.eservices.backend.exception.ApplicationException;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class InvalidDocumentFromMvrException extends ApplicationException { 

	private static final long serialVersionUID = 7186277426537891687L;
	
	private String status;
	private LocalDate date;
	private String statusReason;
}
