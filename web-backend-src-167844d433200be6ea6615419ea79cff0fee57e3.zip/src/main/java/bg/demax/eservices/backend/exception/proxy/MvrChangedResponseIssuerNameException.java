package bg.demax.eservices.backend.exception.proxy;

import bg.demax.eservices.backend.exception.ApplicationException;

public class MvrChangedResponseIssuerNameException extends ApplicationException {

	private static final long serialVersionUID = 1L;

	public MvrChangedResponseIssuerNameException(String message) {
		super(message);
	}
}
