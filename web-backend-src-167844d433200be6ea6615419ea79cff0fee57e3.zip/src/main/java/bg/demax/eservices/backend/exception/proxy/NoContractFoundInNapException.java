package bg.demax.eservices.backend.exception.proxy;


import bg.demax.eservices.backend.exception.ApplicationException;

public class NoContractFoundInNapException extends ApplicationException {
	private static final long serialVersionUID = 979907684145569504L;

	public NoContractFoundInNapException(int applicationId) {
		super(String.format(
			"Nap check for application with id: %d do not found active contracts. Can not continue.", applicationId));
	}

}