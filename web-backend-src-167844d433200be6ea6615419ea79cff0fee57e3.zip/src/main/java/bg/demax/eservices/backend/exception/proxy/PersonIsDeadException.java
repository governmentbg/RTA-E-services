package bg.demax.eservices.backend.exception.proxy;

import bg.demax.eservices.backend.exception.ApplicationException;

public class PersonIsDeadException extends ApplicationException {

	private static final long serialVersionUID = 979907684145560504L;

	public PersonIsDeadException(String identityNumber) {
		super(String.format("Person with identity number %s is found to be dead", identityNumber));
	}
}