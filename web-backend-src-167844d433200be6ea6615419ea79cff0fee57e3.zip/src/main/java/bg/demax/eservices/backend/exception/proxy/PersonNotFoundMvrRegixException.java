package bg.demax.eservices.backend.exception.proxy;

import bg.demax.eservices.backend.exception.ApplicationException;

public class PersonNotFoundMvrRegixException extends ApplicationException {

	private static final long serialVersionUID = 4204915421291730035L;

	public PersonNotFoundMvrRegixException(String identityNumber) {
		super(String.format("Person with identity number %s not found in MVR Service", identityNumber));
	}

	public PersonNotFoundMvrRegixException(int applicationId) {
		super(String.format("Can not get MVR info for application with id : %d. Wrong personal info entered.", applicationId));
	}
}