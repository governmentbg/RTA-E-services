package bg.demax.eservices.backend.exception.proxy;

import bg.demax.eservices.backend.exception.ApplicationException;

public class ProxyException extends ApplicationException {
	private static final long serialVersionUID = -6666021942217112318L;

	public ProxyException(String message) {
		super(message);
	}
}
