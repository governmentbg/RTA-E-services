package bg.demax.eservices.backend.exception.proxy;

import bg.demax.eservices.backend.exception.ApplicationException;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RemoteServiceException extends ApplicationException {

	private static final long serialVersionUID = 2212414556819625269L;

	private RemoteServiceExceptionDto remoteServiceExceptionDto;

	public RemoteServiceException(RemoteServiceExceptionDto remoteServiceExceptionDto) {
		super();
		this.remoteServiceExceptionDto = remoteServiceExceptionDto; 
	}
}
