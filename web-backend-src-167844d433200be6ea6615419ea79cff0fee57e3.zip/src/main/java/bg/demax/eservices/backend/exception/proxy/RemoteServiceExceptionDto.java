package bg.demax.eservices.backend.exception.proxy;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RemoteServiceExceptionDto {
	private String error;
	private String message;
	private int proxiedHttpStatus;
	private String proxiedResponseBody;
	private String proxiedMethod;
	private String proxiedUrl;
}