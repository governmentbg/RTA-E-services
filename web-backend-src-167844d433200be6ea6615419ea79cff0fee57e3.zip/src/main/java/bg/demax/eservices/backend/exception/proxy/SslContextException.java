package bg.demax.eservices.backend.exception.proxy;

import bg.demax.eservices.backend.exception.ApplicationException;

public class SslContextException extends ApplicationException {

	private static final long serialVersionUID = 5579400392976240791L;

	public SslContextException(String message) {
		super(message);
	}
	
}
