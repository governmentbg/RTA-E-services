package bg.demax.eservices.backend.exception.proxy;

import bg.demax.eservices.backend.exception.ApplicationException;

public class UserIsNotApprovedToCheckInProxyServerException extends ApplicationException {
	private static final long serialVersionUID = 7858163260007009697L;

}