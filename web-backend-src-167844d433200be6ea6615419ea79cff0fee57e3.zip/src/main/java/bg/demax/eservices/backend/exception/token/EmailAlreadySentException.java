package bg.demax.eservices.backend.exception.token;

import bg.demax.eservices.backend.exception.ApplicationException;

public class EmailAlreadySentException extends ApplicationException {

	private static final long serialVersionUID = -5036503580698018471L;

	public EmailAlreadySentException(String message) {
		super(message);
	}
	
}
