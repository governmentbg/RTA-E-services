package bg.demax.eservices.backend.exception.token;

import bg.demax.eservices.backend.exception.ApplicationException;

public class ExpiredTokenException extends ApplicationException {
	private static final long serialVersionUID = 8795267658641508134L;

	public ExpiredTokenException(String message) {
		super(message);
	}
}
