package bg.demax.eservices.backend.exception.token;

import bg.demax.eservices.backend.exception.ApplicationException;

public class UserEmailIsAlreadyVerifiedException extends ApplicationException {

	private static final long serialVersionUID = 3042697250017838278L;

	public UserEmailIsAlreadyVerifiedException(String message) {
		super(message);
	}
	
}
