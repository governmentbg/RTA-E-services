package bg.demax.eservices.backend.http;

import java.net.URI;
import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import bg.demax.payment.service.api.exception.HttpServerCommunicationException;

public abstract class AbstractHttpClient {

	private final Log logger = LogFactory.getLog(getClass());
	
	private RestTemplate restTemplate;

	protected void setRestTemplate(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	protected <T> T executeGetRequest(URI uri, Class<T> responseType) {
		return executeHttpRequest(uri, HttpMethod.GET, null, responseType, null);
	}
	
	protected <T> T executeGetRequest(URI uri, Class<T> responseType, HttpHeaders additionalHeaders) {
		return executeHttpRequest(uri, HttpMethod.GET, null, responseType, additionalHeaders);
	}
	
	protected <T> T executePostRequest(URI uri, Object requestBody, Class<T> responseType) {
		return executeHttpRequest(uri, HttpMethod.POST, requestBody, responseType, null);
	}

	protected <T> T executePostRequest(URI uri, Object requestBody, Class<T> responseType, HttpHeaders additionalHeaders) {
		return executeHttpRequest(uri, HttpMethod.POST, requestBody, responseType, additionalHeaders);
	}

	protected <T> T executePutRequest(URI uri, Object requestBody, Class<T> responseType) {
		return executeHttpRequest(uri, HttpMethod.PUT, requestBody, responseType, null);
	}
	
	protected <T> T executePutRequest(URI uri, Object requestBody, Class<T> responseType, HttpHeaders additionalHeaders) {
		return executeHttpRequest(uri, HttpMethod.PUT, requestBody, responseType, additionalHeaders);
	}

	protected <T> T executeDeleteRequest(URI uri, Object requestBody, Class<T> responseType) {
		return executeHttpRequest(uri, HttpMethod.DELETE, requestBody, responseType, null);
	}

	protected <T> T executeDeleteRequest(URI uri, Object requestBody, Class<T> responseType, HttpHeaders additionalHeaders) {
		return executeHttpRequest(uri, HttpMethod.DELETE, requestBody, responseType, additionalHeaders);
	}
	
	protected <T> T postMultipartRequest(URI uri, MultiValueMap<String, Object> multipartFiles, Class<T> responseType) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		return exchangeFormRequest(uri, HttpMethod.POST, multipartFiles, responseType, headers);
	}

	protected <T> T postFormDataRequest(URI uri, MultiValueMap<String, Object> formData, Class<T> responseType) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.ALL));
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		return exchangeFormRequest(uri, HttpMethod.POST, formData, responseType, headers);
	}
	
	private <T> T executeHttpRequest(URI uri, HttpMethod httpMethod, Object requestBody, Class<T> responseType, 
			HttpHeaders additionalHeaders) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		if (requestBody != null
				&& (httpMethod == HttpMethod.POST || httpMethod == HttpMethod.PUT || httpMethod == HttpMethod.PATCH)) {
			headers.setContentType(MediaType.APPLICATION_JSON);
		}
		if (additionalHeaders != null) {
			headers.addAll(additionalHeaders);
		}
		RequestEntity<?> requestEntity = new RequestEntity<>(requestBody, headers, httpMethod, uri);

		ResponseEntity<T> response;
		try {
			response = restTemplate.exchange(requestEntity, responseType);
		} catch (RestClientException e) {
			logger.error("Error in communication with HTTP server. Request uri=" + uri, e);
			throw new HttpServerCommunicationException(e);
		}
		return response.getBody();
	}

	private <T> T exchangeFormRequest(URI uri, HttpMethod httpMethod, MultiValueMap<String, Object> formData,
			Class<T> responseType, HttpHeaders headers) {
		HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<>(formData, headers);

		ResponseEntity<T> response;
		try {
			response = restTemplate.exchange(uri, httpMethod, httpEntity, responseType);
		} catch (RestClientException e) {
			logger.error("Error in communication with HTTP server.", e);
			throw new HttpServerCommunicationException(e);
		}
		return response.getBody();
	}
}
