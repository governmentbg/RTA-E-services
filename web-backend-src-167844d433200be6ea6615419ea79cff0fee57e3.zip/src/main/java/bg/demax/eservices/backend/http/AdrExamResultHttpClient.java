package bg.demax.eservices.backend.http;

import java.net.URI;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import bg.demax.eservices.backend.entity.applications.ApplicationType;
import bg.demax.eservices.backend.exception.ApplicationException;
import bg.demax.eservices.backend.exception.proxy.RemoteServiceException;
import bg.demax.eservices.backend.exception.proxy.RemoteServiceExceptionDto;
import bg.demax.eservices.backend.http.dto.adr.AdrExamEnrolmentRequestDto;
import bg.demax.eservices.backend.http.dto.adr.AdrExamPersonDto;
import bg.demax.eservices.backend.http.dto.adr.AdrExamPersonRegistrationRequestDto;
import bg.demax.eservices.backend.http.dto.adr.AdrExamProtocolDto;
import bg.demax.eservices.backend.http.dto.adr.AdrExamResultEnrolmentResponseDto;
import bg.demax.eservices.backend.http.dto.adr.ConsultantExamLearningPlanSelectionDto;
import bg.demax.eservices.backend.vo.exam.adr.AdrConsultantExtensionExamEnrolmentRequestVo;
import bg.demax.eservices.backend.vo.exam.adr.AdrExamPeopleRequestVo;
import bg.demax.eservices.backend.vo.exam.adr.AdrExamProtocolRequestVo;
import bg.demax.eservices.backend.vo.exam.adr.AdrRequestVo;
import bg.demax.eservices.backend.vo.exam.adr.ConsultantExamLearningPlanForExtensionRequestVo;

public class AdrExamResultHttpClient extends AbstractProxyHttpClient {

	private static final int UNENROL_RETRY_BACKOFF_DELAY_SECONDS = 2;
	private static final long IAAA_PERMIT_ID = 1021;

	private final Log logger = LogFactory.getLog(getClass());

	private String baseUrl;

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	@Override
	public void setRestTemplate(RestTemplate restTemplate) {
		super.setRestTemplate(restTemplate);
	}

	public List<AdrExamPersonDto> getAdrExamPeopleForSelection(AdrExamPeopleRequestVo requestVo) {
		String examTypeParameterValue;
		if (ApplicationType.ADR_EXAM_ID == requestVo.getApplicationTypeId().intValue()) {
			examTypeParameterValue = "DRIVERS";
		} else if (ApplicationType.CONSULTANT_EXAM_ID == requestVo.getApplicationTypeId().intValue()) {
			examTypeParameterValue = "CONSULTANTS_ACQUIRE";
		} else {
			throw new ApplicationException("Invalid operation for application type with id=" 
				+ requestVo.getApplicationTypeId() + ".");
		}

		return doGetExamPeopleForExamEnrolment(requestVo.getPersonIdentityNumber(), examTypeParameterValue);
	}

	public List<ConsultantExamLearningPlanSelectionDto> getLearningPlansForExtension(
			ConsultantExamLearningPlanForExtensionRequestVo requestVo) {
		String apiUrl = "/api/learning-plans/for-extension/{personalIdentityNumber}";
		
		String examTypeParameterValue;
		if (ApplicationType.ADR_EXAM_ID == requestVo.getApplicationTypeId().intValue()) {
			examTypeParameterValue = "DRIVERS";
		} else if (ApplicationType.CONSULTANT_EXAM_ID == requestVo.getApplicationTypeId().intValue()) {
			examTypeParameterValue = "CONSULTANTS_RENEW";
		} else {
			throw new ApplicationException("Invalid operation for application type with id=" 
				+ requestVo.getApplicationTypeId() + ".");
		}

		URI uri = UriComponentsBuilder.fromHttpUrl(baseUrl)
				.path(apiUrl)
				.queryParam("examType", examTypeParameterValue)
				.build(requestVo.getPersonIdentityNumber());

		logger.debug("Getting learning plans for extension from adr-exam-result...");
		ConsultantExamLearningPlanSelectionDto[] learningPlanDtos = executeGetRequest(uri, 
				ConsultantExamLearningPlanSelectionDto[].class);
		logger.debug("Got learning plans for selection from adr-exam-result.");

		return Arrays.asList(learningPlanDtos);
	}
	
	public List<AdrExamProtocolDto> getAdrExamProtocolsForSelection(AdrExamProtocolRequestVo requestVo) {
		String apiUrl = "/api/protocols";
		DateTimeFormatter paramDateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String examTypeParameterValue = getExamTypeParameterValueByRequestVo(requestVo);
		String fromDateParameterValue = requestVo.getFromDate().format(paramDateFormatter);
		String toDateParameterValue = requestVo.getToDate().format(paramDateFormatter);

		URI uri = UriComponentsBuilder.fromHttpUrl(baseUrl)
				.path(apiUrl)
				.queryParam("orgUnitCode", requestVo.getOrgUnitCode())
				.queryParam("examType", examTypeParameterValue)
				.queryParam("fromExamDate", fromDateParameterValue)
				.queryParam("toExamDate", toDateParameterValue)
				.build(requestVo.getOrgUnitCode());

		logger.debug("Getting exam protocols from adr-exam-result...");
		AdrExamProtocolDto[] adrExamPeople = executeGetRequest(uri, AdrExamProtocolDto[].class);
		logger.debug("Got exam protocols from adr-exam-result.");

		return Arrays.asList(adrExamPeople);
	}

	public AdrExamResultEnrolmentResponseDto enrolForExam(AdrExamEnrolmentRequestDto requestDto) {
		String apiUrl = "/api/exam-enrolment";
		URI uri = UriComponentsBuilder.fromHttpUrl(baseUrl)
				.path(apiUrl)
				.build()
				.toUri();

		logger.debug("Enrolling person for exam in adr-exam-result...");
		AdrExamResultEnrolmentResponseDto responseDto = executePostRequest(uri, requestDto, 
				AdrExamResultEnrolmentResponseDto.class);
		logger.debug("Enrolled person for exam in adr-exam-result.");

		return responseDto;
	}
	
	public AdrExamResultEnrolmentResponseDto enrolForAdrConsultantExtensionExam(
			AdrConsultantExtensionExamEnrolmentRequestVo requestVo) {
		String examTypeParameterValue = "CONSULTANTS_RENEW";
		List<AdrExamPersonDto> examPeople = doGetExamPeopleForExamEnrolment(requestVo.getPersonalIdentityNumber(), 
				examTypeParameterValue);
		
		if (examPeople != null && !examPeople.isEmpty()) {
			for (AdrExamPersonDto adrExamPersonDto : examPeople) {
				cancelExamPersonLearning(adrExamPersonDto.getId());
			}
		}
		long examPersonId = registerExamPerson(requestVo);
		
		AdrExamEnrolmentRequestDto examEnrolmentRequestDto = new AdrExamEnrolmentRequestDto();
		examEnrolmentRequestDto.setExamPersonId(examPersonId);
		examEnrolmentRequestDto.setProtocolId(requestVo.getProtocolId());
		AdrExamResultEnrolmentResponseDto responseDto = enrolForExam(examEnrolmentRequestDto);
		return responseDto;
	}

	private long registerExamPerson(AdrConsultantExtensionExamEnrolmentRequestVo requestVo) {
		String apiUrl = "/api/exam-people";
		URI uri = UriComponentsBuilder.fromHttpUrl(baseUrl)
				.path(apiUrl)
				.build()
				.toUri();
		
		AdrExamPersonRegistrationRequestDto requestDto = new AdrExamPersonRegistrationRequestDto();
		requestDto.setPersonalIdentityNumber(requestVo.getPersonalIdentityNumber());

		requestDto.setFirstName(requestVo.getFirstName());
		requestDto.setSurname(requestVo.getSurname());
		requestDto.setFamilyName(requestVo.getFamilyName());

		requestDto.setFirstNameLatin(requestVo.getFamilyNameLatin());
		requestDto.setSurnameLatin(requestVo.getSurnameLatin());
		requestDto.setFamilyNameLatin(requestVo.getFamilyNameLatin());

		requestDto.setCountryCode(requestVo.getCountryCode());
		requestDto.setLearningPlanId(requestVo.getLearningPlanId());
		requestDto.setPermitId(IAAA_PERMIT_ID);
		
		logger.debug("Registerring new examPerson...");
		long examPersonId = executePostRequest(uri, requestDto, Long.class);
		logger.debug("Registerred new examPerson with id=" + examPersonId);
		return examPersonId;
	}

	private void cancelExamPersonLearning(long examPersonId) {
		String apiUrl = "/api/exam-people/cancel-learning/{examPersonId}";
		URI uri = UriComponentsBuilder.fromHttpUrl(baseUrl)
				.path(apiUrl)
				.build(examPersonId);
		
		logger.debug("Canceling learning for examPerson with id=" + examPersonId);
		executePostRequest(uri, null, Void.class);
		logger.debug("Canceled learning for examPerson with id=" + examPersonId);
	}

	@Retryable(backoff = @Backoff(delay = UNENROL_RETRY_BACKOFF_DELAY_SECONDS * 1000), maxAttempts = 10)
	public void unenrolFromExam(long examResultId) {
		String apiUrl = "/api/exam-results/{id}";
		URI uri = UriComponentsBuilder.fromHttpUrl(baseUrl)
				.path(apiUrl)
				.build(examResultId);

		logger.debug("Unenrolling person from exam in adr-exam-result...");
		try {
			executeDeleteRequest(uri, null, Void.class);
		} catch (RemoteServiceException e) {
			RemoteServiceExceptionDto remoteServiceExceptionDto = e.getRemoteServiceExceptionDto();
			String proxiedResponseBody = remoteServiceExceptionDto.getProxiedResponseBody();
			if (remoteServiceExceptionDto.getProxiedHttpStatus() == HttpStatus.NOT_FOUND.value() 
					&& proxiedResponseBody != null
					&& proxiedResponseBody.contains("NoSuchEntityException")
					&& proxiedResponseBody.contains("ExamResult")) {
				logger.info("ExamResult not found. ExamPerson is already unenrolled from this exam.");
			} else {
				throw e;
			}
		}
		logger.debug("Unenrolled person from exam in adr-exam-result.");
	}

	private String getExamTypeParameterValueByRequestVo(AdrRequestVo requestVo) {
		String examTypeParameterValue;
		if (ApplicationType.ADR_EXAM_ID == requestVo.getApplicationTypeId().intValue()) {
			examTypeParameterValue = "DRIVERS";
		} else if (ApplicationType.CONSULTANT_EXAM_ID == requestVo.getApplicationTypeId().intValue()) {
			examTypeParameterValue = "CONSULTANTS";
		} else {
			throw new ApplicationException("Invalid operation for application type with id=" 
				+ requestVo.getApplicationTypeId() + ".");
		}
		return examTypeParameterValue;
	}
	
	private List<AdrExamPersonDto> doGetExamPeopleForExamEnrolment(String personalIdentityNumber,
			String examTypeParameterValue) {
		String apiUrl = "/api/exam-people/for-exam-enrolment/{personalIdentityNumber}";
		URI uri = UriComponentsBuilder.fromHttpUrl(baseUrl)
				.path(apiUrl)
				.queryParam("examType", examTypeParameterValue)
				.build(personalIdentityNumber);

		logger.debug("Getting exam people from adr-exam-result...");
		AdrExamPersonDto[] adrExamPeople = executeGetRequest(uri, AdrExamPersonDto[].class);
		logger.debug("Got exam people from adr-exam-result.");

		return Arrays.asList(adrExamPeople);
	}
}
