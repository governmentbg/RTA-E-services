package bg.demax.eservices.backend.http;

import java.io.IOException;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import bg.demax.eservices.backend.config.BeanQualifierConstants;
import bg.demax.eservices.backend.dto.DocumentDto;
import bg.demax.eservices.backend.dto.pictureprocessing.FaceProcessingDto;
import bg.demax.eservices.backend.dto.pictureprocessing.NormalizedFaceDto;
import bg.demax.eservices.backend.dto.pictureprocessing.ScalePictureDto;
import bg.demax.eservices.backend.dto.pictureprocessing.SignatureProcessingDto;
import bg.demax.eservices.backend.dto.pictureprocessing.SignatureThicknessDto;
import bg.demax.eservices.backend.exception.file.FacePictureNotCorrectException;
import bg.demax.eservices.backend.exception.file.NotExactlyOneFaceDetectedException;
import bg.demax.eservices.backend.exception.file.PictureProcessingException;
import bg.demax.eservices.backend.exception.file.SignaturePictureNotCorrectException;
import bg.demax.eservices.backend.exception.proxy.DocumentStorageException;

import org.json.JSONObject;

@Component
public class DocumentPicturesHttpClient {

	private static final String RESULT_KEY_FROM_JSON_BODY = "result";

	private static final Logger logger = LogManager.getLogger();

	@Autowired
	@Qualifier(BeanQualifierConstants.REST_TEMPLATE)
	private RestTemplate documentArchiveRestTemplate;

	public byte[] getDocumentBytes(String checksum, String url) throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		ResponseEntity<byte[]> response;

		try {
			response = documentArchiveRestTemplate.getForEntity(url + "/" + checksum, byte[].class);
		} catch (HttpClientErrorException | HttpServerErrorException e) {
			logger.debug("", e);
			throw new DocumentStorageException(String.format(
				"E-services Document Storage API returned status code: %d", e.getRawStatusCode()));
		}

		if (response.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
			throw new DocumentStorageException("Could not connect to document storage service.");
		}

		if (response.getBody() == null || response.getStatusCode() != HttpStatus.OK) {
			throw new DocumentStorageException(
					String.format("Could not find document or picture with checksum : %s. Status Code : %d.", checksum,
							response.getStatusCode().value()));
		}

		return response.getBody();
	}

	public String saveDocumentBytesWithChecksum(DocumentDto requestDto, int applicationId, String url)
			throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> requestEntity = new HttpEntity<Object>(requestDto, headers);

		ResponseEntity<String> response = null;
		try {
			response = documentArchiveRestTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);
		} catch (HttpClientErrorException | HttpServerErrorException e) {
			logger.debug("", e);
			throw new DocumentStorageException(String.format(
				"E-services Document Storage API returned status code: %d", e.getRawStatusCode()));
		}

		if (response == null || response.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
			throw new DocumentStorageException("Could not connect to document pictures service.");
		}

		if (response.getBody() == null || response.getStatusCode() != HttpStatus.OK) {
			throw new DocumentStorageException(String.format(
				"Could not save document pictures for application with id : %d. Status Code : %d.",
					applicationId, response.getStatusCode().value()));
		}
		return response.getBody();

	}

	public String autoProcessFacePicture(FaceProcessingDto requestDto, int applicationId, String url) throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> requestEntity = new HttpEntity<Object>(requestDto, headers);

		ResponseEntity<String> response;
		try {
			response = documentArchiveRestTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);
		} catch (HttpClientErrorException | HttpServerErrorException e) {
			logger.debug("", e);
			if (e.getResponseBodyAsString().contains("Not exactly one face detected")) {
				throw new NotExactlyOneFaceDetectedException("Not exactly one face detected on uploaded picture.");
			}
			throw new FacePictureNotCorrectException(String.format(
				"Picture processing photo face service could not return fixed picture, but : %s", 
				e.getResponseBodyAsString()));
		}

		if (response == null || response.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
			throw new PictureProcessingException("Could not connect to picture processing service.");
		}
		if (response.getBody() == null || response.getStatusCode() != HttpStatus.OK) {
			throw new PictureProcessingException(String.format(
				"Could not get auto fixed picture from picture processing service for application with id : %d. "
				+ "Status Code : %d.", applicationId, response.getStatusCode().value()));
		}
	
		JSONObject jsonObject = new JSONObject(response.getBody());
		return (String) jsonObject.getString(RESULT_KEY_FROM_JSON_BODY);
	}

	public Double checkSignatureThickness(SignatureThicknessDto requestDto, int applicationId, String url) throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> requestEntity = new HttpEntity<Object>(requestDto, headers);

		ResponseEntity<String> response;
		try {
			response = documentArchiveRestTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);
		} catch (HttpClientErrorException | HttpServerErrorException e) {
			logger.debug("", e);
			throw new PictureProcessingException(String.format(
				"Signature thickness check service returned status code: %d", e.getRawStatusCode()));
		}

		if (response == null || response.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
			throw new PictureProcessingException("Could not connect to signature thickness check service.");
		}
		if (response.getBody() == null || response.getStatusCode() != HttpStatus.OK) {
			throw new PictureProcessingException(String.format(
				"Could not check signature thickness with service for application with id : %d. Status Code : %d.",
					applicationId, response.getStatusCode().value()));
		}

		JSONObject jsonObject = new JSONObject(response.getBody());
		return (Double) jsonObject.getDouble(RESULT_KEY_FROM_JSON_BODY);
	}

	public String autoProcessSignaturePicture(SignatureProcessingDto requestDto, int applicationId, String url) throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> requestEntity = new HttpEntity<Object>(requestDto, headers);

		ResponseEntity<String> response;
		try {
			response = documentArchiveRestTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);
		} catch (HttpClientErrorException | HttpServerErrorException e) {
			logger.debug("", e);
			throw new SignaturePictureNotCorrectException(String.format(
				"Signature processing service returned status code: %d", e.getRawStatusCode()));
		}

		if (response == null || response.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
			throw new PictureProcessingException("Could not connect to signature processing service.");
		}
		if (response.getBody() == null || response.getStatusCode() != HttpStatus.OK) {
			throw new PictureProcessingException(String.format(
				"Could not get edited picture from signature processing service for application with id : %d. "
				+ "Status Code : %d.", applicationId, response.getStatusCode().value()));
		}

		JSONObject jsonObject = new JSONObject(response.getBody());
		return (String) jsonObject.getString(RESULT_KEY_FROM_JSON_BODY);
	}

	public String normalizeFacePicture(NormalizedFaceDto requestDto, int applicationId, String url) throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> requestEntity = new HttpEntity<Object>(requestDto, headers);

		ResponseEntity<String> response;
		try {
			response = documentArchiveRestTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);
		} catch (HttpClientErrorException | HttpServerErrorException e) {
			logger.debug("", e);
			throw new PictureProcessingException(String.format(
				"Normalize face service returned status code: %d", e.getRawStatusCode()));
		}

		if (response == null || response.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
			throw new PictureProcessingException("Could not connect to normalize face service.");
		}
		if (response.getBody() == null || response.getStatusCode() != HttpStatus.OK) {
			throw new PictureProcessingException(String.format(
				"Could not normalize face picture for application with id : %d. Status Code : %d.",
					applicationId, response.getStatusCode().value()));
		}

		JSONObject jsonObject = new JSONObject(response.getBody());
		return (String) jsonObject.getString(RESULT_KEY_FROM_JSON_BODY);
	}

	public String scalePicture(ScalePictureDto requestDto, int applicationId, String url) throws IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> requestEntity = new HttpEntity<Object>(requestDto, headers);

		ResponseEntity<String> response;
		try {
			response = documentArchiveRestTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);
		} catch (HttpClientErrorException | HttpServerErrorException e) {
			logger.debug("", e);
			throw new PictureProcessingException(String.format(
				"Scale picture service returned status code: %d", e.getRawStatusCode()));
		} 
		
		if (response == null || response.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
			throw new PictureProcessingException("Could not connect to scale picture service.");
		}
		if (response.getBody() == null || response.getStatusCode() != HttpStatus.OK) {
			throw new PictureProcessingException(String.format(
				"Could not auto scale picture for application with id : %d. Status Code : %d.",
					applicationId, response.getStatusCode().value()));
		}

		JSONObject jsonObject = new JSONObject(response.getBody());
		return (String) jsonObject.getString(RESULT_KEY_FROM_JSON_BODY);
	}
}
