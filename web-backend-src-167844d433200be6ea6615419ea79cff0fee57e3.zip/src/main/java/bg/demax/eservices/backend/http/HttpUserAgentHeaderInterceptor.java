package bg.demax.eservices.backend.http;

import java.io.IOException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.Assert;

/**
 * A workaround for Cloudflare blocking the oauth2 token request.
 * 
 * @author petio
 *
 */
public class HttpUserAgentHeaderInterceptor implements ClientHttpRequestInterceptor {

	private final String name = HttpHeaders.USER_AGENT;
	private final String value;

	public HttpUserAgentHeaderInterceptor(String value) {
		Assert.hasLength(value, "Value must not be empty");
		this.value = value;
	}

	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
			throws IOException {
		request.getHeaders().add(this.name, this.value);
		return execution.execute(request, body);
	}
}
