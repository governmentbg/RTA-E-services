package bg.demax.eservices.backend.http;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Arrays;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.eservices.backend.config.BeanQualifierConstants;
import bg.demax.eservices.backend.exception.proxy.ProxyException;
import bg.demax.eservices.backend.exception.proxy.RemoteServiceException;
import bg.demax.eservices.backend.exception.proxy.RemoteServiceExceptionDto;

@Component
public class IaaaGatewayHttpClient {

	private static final Logger logger = LogManager.getLogger();

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_GATEWAY_REST_TEMPLATE)
	private RestTemplate iaaaGatewayRestTemplate;

	@Autowired
	private ObjectMapper mapper;

	@Retryable(value = { RestClientException.class, ProxyException.class },
			maxAttempts = 2,
			backoff = @Backoff(delay = 10000))
	public <T> T performPostRequest(Object requestDto, Class<T> returnTypeObject, String proxyRequestUrl, String service)
		throws JsonParseException, JsonMappingException, IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<Object> entity = new HttpEntity<Object>(requestDto, headers);
		ResponseEntity<T> responseEntity;

		logger.debug(LocalDateTime.now().toString() + "  starting " + service + " request...");
		try {
			responseEntity = iaaaGatewayRestTemplate.exchange(proxyRequestUrl, HttpMethod.POST, entity, returnTypeObject);
			logger.info("Response from get request to: " + proxyRequestUrl + ", response: " + responseEntity);
		} catch (HttpStatusCodeException e) {
			logger.error(e.getResponseBodyAsString(), e);
			throw new RemoteServiceException(mapper.readValue(e.getResponseBodyAsString(), RemoteServiceExceptionDto.class));
		} catch (RestClientException e) {
			logger.error("Error while getting " + service + " info.", e);
			throw new ProxyException("Could not find subject " + service + " info.");
		}
		logger.debug(LocalDateTime.now().toString() + "  finished " + service + " request...");
		if (responseEntity.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
			throw new ProxyException("Could not connect to " + service + " proxy service.");
		}

		if (responseEntity.getBody() == null || responseEntity.getStatusCode() != HttpStatus.OK) {
			throw new ProxyException("Could not find subject " + service + " info.");
		}

		return responseEntity.getBody();
	}

	@Retryable(value = { RestClientException.class, ProxyException.class },
			maxAttempts = 2,
			backoff = @Backoff(delay = 10000))
	public <T> T performGetRequest(Class<T> returnTypeObject, String proxyRequestUrl, String service)
		throws JsonParseException, JsonMappingException, IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<Object> entity = new HttpEntity<Object>(headers);

		ResponseEntity<T> response;
		try {
			response = iaaaGatewayRestTemplate.exchange(proxyRequestUrl, HttpMethod.GET, entity, returnTypeObject);
			logger.info("Response from get request to: " + proxyRequestUrl + ", response: " + response);
		} catch (HttpStatusCodeException e) {
			logger.error(e.getResponseBodyAsString(), e);
			throw new RemoteServiceException(mapper.readValue(e.getResponseBodyAsString(), RemoteServiceExceptionDto.class));
		} catch (RestClientException e) {
			logger.error("", e);
			throw new ProxyException("Could not find info from " + service);
		}
		if (response == null) {
			throw new ProxyException("Response from " + service + " is NULL.");
		}

		if (response.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
			throw new ProxyException("Could not connect to " + service + " proxy service.");
		}

		if (response.getBody() == null || response.getStatusCode() != HttpStatus.OK) {
			throw new ProxyException("Could not find info from " + service);
		}

		return response.getBody();
	}
}
