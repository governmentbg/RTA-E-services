package bg.demax.eservices.backend.http;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Arrays;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import bg.demax.eservices.backend.config.BeanQualifierConstants;
import bg.demax.eservices.backend.exception.proxy.ProxyException;
import bg.demax.eservices.backend.exception.proxy.RemoteServiceException;
import bg.demax.eservices.backend.exception.proxy.RemoteServiceExceptionDto;

@Component
public class IaaaGatewayHttpClientTachoNet {

	private static final Logger logger = LogManager.getLogger();

	@Autowired
	@Qualifier(BeanQualifierConstants.IAAA_GATEWAY_REST_TEMPLATE_TACHO_NET)
	private RestTemplate iaaaGatewayRestTemplateTachoNet;

	@Autowired
	private ObjectMapper mapper;

	@Retryable(value = { RestClientException.class, ProxyException.class },
			maxAttempts = 2,
			backoff = @Backoff(delay = 10000))
	public String performPostRequest(Object requestDto, String proxyRequestUrl, String service)
		throws JsonParseException, JsonMappingException, IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity<Object> entity = new HttpEntity<Object>(requestDto, headers);
		ResponseEntity<String> responseEntity;

		logger.debug(LocalDateTime.now().toString() + "  starting " + service + " request...");
		try {
			responseEntity = iaaaGatewayRestTemplateTachoNet.exchange(proxyRequestUrl, HttpMethod.POST, entity, String.class);
			logger.info("Response from TachoNet request to: " + proxyRequestUrl + ", response: " + responseEntity.getBody());
		} catch (HttpStatusCodeException e) {
			logger.error(e.getResponseBodyAsString(), e);
			throw new RemoteServiceException(mapper.readValue(e.getResponseBodyAsString(), RemoteServiceExceptionDto.class));
		} catch (RestClientException e) {
			logger.error("Error while getting " + service + " info.", e);
			throw new ProxyException("Could not find subject " + service + " info.");
		}
		logger.debug(LocalDateTime.now().toString() + "  finished " + service + " request...");

		//status codes specific for the proxy service
		if (responseEntity.getStatusCode() == HttpStatus.PRECONDITION_FAILED) {
			return responseEntity.getBody();
		}

		if (responseEntity.getStatusCode().series() != HttpStatus.Series.SUCCESSFUL) {
			return mapper.readValue(responseEntity.getBody(), RemoteServiceExceptionDto.class).getProxiedResponseBody();
		}

		return responseEntity.getBody();
	}
}
