package bg.demax.eservices.backend.http;

import java.net.URI;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import bg.demax.eservices.backend.exception.ApplicationException;
import bg.demax.eservices.backend.exception.proxy.RemoteServiceException;
import bg.demax.eservices.backend.exception.proxy.RemoteServiceExceptionDto;
import bg.demax.eservices.backend.http.dto.motor.MotorExamPersonCreationResponseDto;
import bg.demax.eservices.backend.http.dto.motor.MotorExamPersonRegistrationRequestDto;
import bg.demax.eservices.backend.http.dto.motor.MotorExamPersonDto;
import bg.demax.eservices.backend.http.dto.motor.MotorExamProtocolDto;
import bg.demax.eservices.backend.http.dto.motor.MotorExamResultCreationRequestDto;
import bg.demax.eservices.backend.http.dto.motor.MotorExamResultEnrolmentResponseDto;
import bg.demax.eservices.backend.http.dto.motor.MotorProvidedDocumentRegistrationRequestDto;
import bg.demax.eservices.backend.vo.exam.motor.MotorExamPeopleRequestVo;
import bg.demax.eservices.backend.vo.exam.motor.MotorExamProtocolRequestVo;
import bg.demax.eservices.backend.vo.exam.motor.TaxiMotorExamEnrolmentRequestVo;

public class MotorExamResultHttpClient extends AbstractProxyHttpClient {

	private static final long TAXI_LEARNING_PLAN_ID = 136; // придобиване на удостоверение на ВТА
	private static final int UNENROL_RETRY_BACKOFF_DELAY_SECONDS = 2;

	private final Log logger = LogFactory.getLog(getClass());

	private String baseUrl;

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	@Override
	public void setRestTemplate(RestTemplate restTemplate) {
		super.setRestTemplate(restTemplate);
	}

	public List<MotorExamPersonDto> getMotorExamPeopleForSelection(MotorExamPeopleRequestVo requestVo) {
		String apiUrl = "/api/exam-people/for-theoretical-exam-enrolment/{personalIdentityNumber}";

		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(baseUrl)
				.path(apiUrl);
		
		if (requestVo.getSubCategoryId() != null) {
			uriBuilder.queryParam("categoryId", requestVo.getSubCategoryId());
		}

		URI uri = uriBuilder
				.build(requestVo.getPersonIdentityNumber());

		logger.debug("Getting exam people from motor-exam-result...");
		MotorExamPersonDto[] motorExamPeople = executeGetRequest(uri, MotorExamPersonDto[].class);
		logger.debug("Got exam people from motor-exam-result.");

		return Arrays.asList(motorExamPeople);
	}

	public List<MotorExamProtocolDto> getMotorExamProtocolsForSelection(MotorExamProtocolRequestVo requestVo) {
		String apiUrl = "/api/protocols";
		DateTimeFormatter paramDateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String fromDateParameterValue = requestVo.getFromExamDate().format(paramDateFormatter);
		String toDateParameterValue = requestVo.getToExamDate().format(paramDateFormatter);

		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(baseUrl)
				.path(apiUrl);

		if (requestVo.getOrgUnitCode() != null) {
			uriBuilder.queryParam("orgUnitCode", requestVo.getOrgUnitCode());
		}

		URI uri = uriBuilder
				.queryParam("examType", "EXTERNAL_THEORETICAL")
				.queryParam("reservationType", requestVo.getReservationType())
				.queryParam("fromExamDate", fromDateParameterValue)
				.queryParam("toExamDate", toDateParameterValue)
				.build()
				.toUri();

		logger.debug("Getting exam protocols from motor-exam-result...");
		MotorExamProtocolDto[] motorExamPeople = executeGetRequest(uri, MotorExamProtocolDto[].class);
		logger.debug("Got exam protocols from motor-exam-result.");

		return Arrays.asList(motorExamPeople);
	}

	public MotorExamResultEnrolmentResponseDto enrolForExam(MotorExamResultCreationRequestDto requestDto) {
		String apiUrl = "/api/exam-results";
		URI uri = UriComponentsBuilder.fromHttpUrl(baseUrl)
				.path(apiUrl)
				.build()
				.toUri();

		logger.debug("Enrolling person for exam in motor-exam-result...");
		MotorExamResultEnrolmentResponseDto responseDto = executePostRequest(uri, requestDto, 
				MotorExamResultEnrolmentResponseDto.class);
		logger.debug("Enrolled person for exam in motor-exam-result.");

		return responseDto;
	}

	public MotorExamResultEnrolmentResponseDto enrolForTaxiExam(TaxiMotorExamEnrolmentRequestVo requestVo) {
		MotorExamPeopleRequestVo examPeopleRequestVo = new MotorExamPeopleRequestVo();
		examPeopleRequestVo.setPersonIdentityNumber(requestVo.getPersonIdentityNumber());
		examPeopleRequestVo.setSubCategoryId(MotorExamPeopleRequestVo.TAXI_SUB_CATEGORY_ID);
		List<MotorExamPersonDto> examPersonDtos = this.getMotorExamPeopleForSelection(examPeopleRequestVo);

		long examPersonId;
		if (examPersonDtos == null || examPersonDtos.isEmpty()) {
			MotorExamPersonCreationResponseDto examPersonCreationResponseDto = createTaxiExamPerson(requestVo);
			examPersonId = examPersonCreationResponseDto.getExamPersonId();
		} else {
			if (examPersonDtos.size() > 1) {
				throw new ApplicationException("Unexpected exam people count. Expected only one exam person.");
			}
			
			MotorExamPersonDto examPersonDto = examPersonDtos.get(0);
			if (examPersonDto.getOrgUnit().getCode().equals(requestVo.getOrgUnitCode())) {
				examPersonId = examPersonDto.getExamPersonId();
			} else {
				this.cancelExamPersonLearning(examPersonDto.getExamPersonId());
				MotorExamPersonCreationResponseDto examPersonCreationResponseDto = createTaxiExamPerson(requestVo);
				examPersonId = examPersonCreationResponseDto.getExamPersonId();
			}
		}
		
		MotorExamResultCreationRequestDto requestDto = new MotorExamResultCreationRequestDto();
		requestDto.setExamPersonId(examPersonId);
		requestDto.setMunicipalityCode(requestVo.getMunicipalityCode());
		requestDto.setMunicipalityRegionCode(requestVo.getRegionCode());
		requestDto.setProtocolId(requestVo.getProtocolId());
		
		return enrolForExam(requestDto);
	}

	private void cancelExamPersonLearning(long examPersonId) {
		String apiUrl = "/api/exam-people/cancel-learning/{examPersonId}";
		URI uri = UriComponentsBuilder.fromHttpUrl(baseUrl)
				.path(apiUrl)
				.build(examPersonId);
		
		logger.debug("Canceling exam person learning in motor-exam-result...");
		executePostRequest(uri, null, Void.class);
		logger.debug("Canceled exam person learning in motor-exam-result.");
	}

	private MotorExamPersonCreationResponseDto createTaxiExamPerson(TaxiMotorExamEnrolmentRequestVo requestVo) {
		MotorExamPersonRegistrationRequestDto examPersonCreationDto = new MotorExamPersonRegistrationRequestDto();
		examPersonCreationDto.setPersonalIdentityNumber(requestVo.getPersonIdentityNumber());
		examPersonCreationDto.setFirstName(requestVo.getFirstName());
		examPersonCreationDto.setSurname(requestVo.getSurname());
		examPersonCreationDto.setFamilyName(requestVo.getFamilyName());
		
		examPersonCreationDto.setFirstNameLatin(requestVo.getFirstNameLatin());
		examPersonCreationDto.setSurnameLatin(requestVo.getSurnameLatin());
		examPersonCreationDto.setFamilyNameLatin(requestVo.getFamilyNameLatin());
		
		examPersonCreationDto.setCountryCode(requestVo.getCountryCode());
		examPersonCreationDto.setOrgUnitCode(requestVo.getOrgUnitCode());
		examPersonCreationDto.setRegionCode(requestVo.getRegionCode());
		
		examPersonCreationDto.setLearningPlanId(TAXI_LEARNING_PLAN_ID); 

		examPersonCreationDto.setProvidedDocuments(new LinkedList<>());
		MotorProvidedDocumentRegistrationRequestDto criminalRecordProvidedDocumentDto = 
				new MotorProvidedDocumentRegistrationRequestDto();
		criminalRecordProvidedDocumentDto.setDocumentRequirementId(MotorProvidedDocumentRegistrationRequestDto
				.CRIMINAL_RECORD_CERTIFICATE_DOC_REQUIREMENT_ID);
		criminalRecordProvidedDocumentDto.setNumber(requestVo.getCriminalRecordCertificateNumber());
		criminalRecordProvidedDocumentDto.setIssueDate(requestVo.getCriminalRecordCertificateIssueDate());
		criminalRecordProvidedDocumentDto.setIssuedBy(null);
		examPersonCreationDto.getProvidedDocuments().add(criminalRecordProvidedDocumentDto);
		
		MotorProvidedDocumentRegistrationRequestDto drivingLicenceProvidedDocumentDto = 
				new MotorProvidedDocumentRegistrationRequestDto();
		drivingLicenceProvidedDocumentDto.setDocumentRequirementId(MotorProvidedDocumentRegistrationRequestDto
				.DRIVING_LICENCE_DOC_REQUIREMENT_ID);
		drivingLicenceProvidedDocumentDto.setNumber(requestVo.getDrivingLicenceNumber());
		drivingLicenceProvidedDocumentDto.setIssueDate(requestVo.getDrivingLicenceIssueDate());
		drivingLicenceProvidedDocumentDto.setIssuedBy(null);
		examPersonCreationDto.getProvidedDocuments().add(drivingLicenceProvidedDocumentDto);
		
		MotorProvidedDocumentRegistrationRequestDto certificateOfPsychologicalFitnessProvidedDocumentDto = 
				new MotorProvidedDocumentRegistrationRequestDto();
		certificateOfPsychologicalFitnessProvidedDocumentDto.setDocumentRequirementId(MotorProvidedDocumentRegistrationRequestDto
					.CERTIFICATE_OF_PSYCHOLOGICAL_FITNESS_DOC_REQUIREMENT_ID);
		certificateOfPsychologicalFitnessProvidedDocumentDto.setNumber(requestVo.getCertificateOfPsychologicalFitnessNumber());
		certificateOfPsychologicalFitnessProvidedDocumentDto
			.setIssueDate(requestVo.getCertificateOfPsychologicalFitnessIssueDate());
		certificateOfPsychologicalFitnessProvidedDocumentDto.setIssuedBy(null);
		examPersonCreationDto.getProvidedDocuments().add(certificateOfPsychologicalFitnessProvidedDocumentDto);

		MotorExamPersonCreationResponseDto examPersonCreationResponseDto = this
				.doCreateTaxiExamPerson(examPersonCreationDto);
		return examPersonCreationResponseDto;
	}
	
	private MotorExamPersonCreationResponseDto doCreateTaxiExamPerson(MotorExamPersonRegistrationRequestDto requestDto) {
		String apiUrl = "/api/exam-people";
		URI uri = UriComponentsBuilder.fromHttpUrl(baseUrl)
				.path(apiUrl)
				.build()
				.toUri();
		
		logger.debug("Creating taxi exam person in motor-exam-result...");
		MotorExamPersonCreationResponseDto responseDto = executePostRequest(uri, requestDto, 
				MotorExamPersonCreationResponseDto.class);
		logger.debug("Created taxi exam person in motor-exam-result.");

		return responseDto;
	}

	@Retryable(backoff = @Backoff(delay = UNENROL_RETRY_BACKOFF_DELAY_SECONDS * 1000), maxAttempts = 10)
	public void unenrolFromExam(Long examResultId) {
		String apiUrl = "/api/exam-results/{id}";
		URI uri = UriComponentsBuilder.fromHttpUrl(baseUrl)
				.path(apiUrl)
				.build(examResultId);

		logger.debug("Unenrolling person from exam in motor-exam-result...");
		try {
			executeDeleteRequest(uri, null, Void.class);
			logger.debug("Unenrolled person from exam in motor-exam-result.");
		} catch (RemoteServiceException e) {
			RemoteServiceExceptionDto remoteServiceExceptionDto = e.getRemoteServiceExceptionDto();
			String proxiedResponseBody = remoteServiceExceptionDto.getProxiedResponseBody();
			if (remoteServiceExceptionDto.getProxiedHttpStatus() == HttpStatus.NOT_FOUND.value() 
					&& proxiedResponseBody != null
					&& proxiedResponseBody.contains("NoSuchEntityException")
					&& proxiedResponseBody.contains("ExamResult")) {
				logger.info("ExamResult not found. ExamPerson is already unenrolled from this exam.");
			} else {
				throw e;
			}
		}
	}
}
