package bg.demax.eservices.backend.http;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Arrays;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bg.demax.eservices.backend.config.ApplicationConstants;
import bg.demax.eservices.backend.entity.applications.ApplicationType;
import bg.demax.eservices.backend.entity.config.SystemVariable;
import bg.demax.eservices.backend.exception.proxy.ProxyException;
import bg.demax.eservices.backend.exception.proxy.RemoteServiceException;
import bg.demax.eservices.backend.exception.proxy.RemoteServiceExceptionDto;
import bg.demax.eservices.backend.service.ApplicationService;
import bg.demax.eservices.backend.service.SslContextService;
import bg.demax.eservices.backend.service.config.SystemVariableService;
import bg.demax.eservices.backend.util.Utils;

//TODO: refactor this class. It is an HTTP client and should not use any services.
@Component
public class RegixProxyHttpClient {

	private static final Logger logger = LogManager.getLogger();
	private static final String CACHE_HEADER = "X-CACHE-FIRST-PERIOD";
	private static final String MONTH_PERIOD_IN_HOURS = "720";

	@Autowired
	ApplicationService applicationService;

	@Autowired
	SslContextService sslContextService;

	@Autowired
	SystemVariableService systemVariableService;

	@Autowired
	private Utils utils;

	@Autowired
	private ObjectMapper mapper;

	@Retryable(value = { RestClientException.class,
			ProxyException.class }, maxAttempts = 2, backoff = @Backoff(delay = 10000))
	public <T> T performPostRequest(Object requestDto, Class<T> returnTypeObject, String proxyRequestUrl,
			String service, Integer applicationId) throws JsonParseException, JsonMappingException, IOException {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		
		String regixRequestCachePeriod = systemVariableService
			.getSystemVariableString(SystemVariable.REGIX_PROXY_REQUEST_CACHE_PERIOD);

		if (utils.checkActiveProfile(ApplicationConstants.SPRING_PROFILE_PRODUCTION)) {
			//if cache is 0 don't add header
			if (!regixRequestCachePeriod.equals("0")) {
				headers.add(CACHE_HEADER, regixRequestCachePeriod);
			}
		} else {
			// За тестови нужди се сетва 1 месец (30*24) = максималния срок,
			// докато Regix Team Demax не променят кеша на тестовата на 1 година , за да не се наливат скриптове всеки месец.
			headers.add(CACHE_HEADER, MONTH_PERIOD_IN_HOURS);
		}

		HttpEntity<Object> entity = new HttpEntity<Object>(requestDto, headers);
		ResponseEntity<T> responseEntity;

		logger.debug(LocalDateTime.now().toString() + "  starting " + service + " request...");
		try {
			RestTemplate proxyRestTemplate = getRestTemplateForApplicationType(applicationId);
			responseEntity = proxyRestTemplate.exchange(proxyRequestUrl, HttpMethod.POST, entity, returnTypeObject);
		} catch (HttpStatusCodeException e) {
			logger.error(e.getResponseBodyAsString(), e);
			throw new RemoteServiceException(mapper.readValue(e.getResponseBodyAsString(), RemoteServiceExceptionDto.class));
		} catch (RestClientException e) {
			logger.error("Error while getting " + service + " info.", e);
			throw new ProxyException("Could not find subject " + service + " info.");
		}
		logger.debug(LocalDateTime.now().toString() + "  finished " + service + " request...");

		if (responseEntity.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
			throw new ProxyException("Could not connect to " + service + " proxy service.");
		}

		if (responseEntity.getBody() == null || responseEntity.getStatusCode() != HttpStatus.OK) {
			throw new ProxyException("Could not find subject " + service + " info.");
		}

		return responseEntity.getBody();
	}

	public RestTemplate getRestTemplateForApplicationType(Integer applicationId) {
		ApplicationType applicationType = applicationService.getApplicationTypeFromFsm(applicationId);

		SSLContext sslContext = sslContextService.getSslContextForApplication(applicationType);

		SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext,
				new NoopHostnameVerifier());

		HttpClientBuilder iaaaGatewayHttpClientBuilder = HttpClientBuilder.create();
		iaaaGatewayHttpClientBuilder.setSSLSocketFactory(sslConnectionSocketFactory);
		iaaaGatewayHttpClientBuilder.setSSLContext(sslContext);

		HttpComponentsClientHttpRequestFactory httpComponentsClientHttpRequestFactory = 
				new HttpComponentsClientHttpRequestFactory();
		httpComponentsClientHttpRequestFactory.setHttpClient(iaaaGatewayHttpClientBuilder.build());

		RestTemplate iaaaGatewayRestTemplate = new RestTemplate();
		iaaaGatewayRestTemplate.setRequestFactory(httpComponentsClientHttpRequestFactory);
		return iaaaGatewayRestTemplate;
	}
}
