package bg.demax.eservices.backend.http.dto.adr;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdrExamEnrolmentRequestDto {

	@NotNull
	@Min(1)
	private Long examPersonId;
	
	@NotNull
	@Min(1)
	private Long protocolId;

	@NotBlank
	private String orgUnitCode;
}
