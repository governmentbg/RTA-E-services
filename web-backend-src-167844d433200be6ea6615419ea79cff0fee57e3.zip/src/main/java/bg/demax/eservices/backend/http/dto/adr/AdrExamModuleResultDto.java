package bg.demax.eservices.backend.http.dto.adr;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdrExamModuleResultDto {

	private String module;
	private Integer moduleSubCategoryId;
	private Boolean isPassed;
}
