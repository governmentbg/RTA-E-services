package bg.demax.eservices.backend.http.dto.adr;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdrExamPersonDto {

	private Long id;

	private String learningPlanName;
	private String learningPlanSubCategoryIdsCsv;
	
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDateTime learningValidTo;

	private List<AdrExamPersonExamResultDto> examResults;
}
