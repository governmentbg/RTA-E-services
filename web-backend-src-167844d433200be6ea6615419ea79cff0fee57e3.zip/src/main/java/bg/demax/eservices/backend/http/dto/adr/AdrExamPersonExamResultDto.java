package bg.demax.eservices.backend.http.dto.adr;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdrExamPersonExamResultDto {

	private Long id;
	private List<AdrExamModuleResultDto> moduleResults;
}
