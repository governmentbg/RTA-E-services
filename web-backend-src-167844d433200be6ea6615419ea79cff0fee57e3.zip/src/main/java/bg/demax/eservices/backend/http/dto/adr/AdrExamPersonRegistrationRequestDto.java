package bg.demax.eservices.backend.http.dto.adr;

import com.sun.istack.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdrExamPersonRegistrationRequestDto {

	@NotNull
	private String personalIdentityNumber;

	@NotNull
	private String firstName;

	@NotNull
	private String surname;

	@NotNull
	private String familyName;

	@NotNull
	private String firstNameLatin;

	@NotNull
	private String surnameLatin;

	@NotNull
	private String familyNameLatin;

	@NotNull
	private String countryCode;

	@NotNull
	private Long learningPlanId;

	@NotNull
	private Long permitId;
}
