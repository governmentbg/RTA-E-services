package bg.demax.eservices.backend.http.dto.adr;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdrExamResultEnrolmentResponseDto {

	private Long examResultId;
	private AdrExamPersonDto examPerson;
	private AdrExamProtocolDto protocol;
}
