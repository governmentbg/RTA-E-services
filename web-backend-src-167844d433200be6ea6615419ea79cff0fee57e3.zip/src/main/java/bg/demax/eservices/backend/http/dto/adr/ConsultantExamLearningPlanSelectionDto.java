package bg.demax.eservices.backend.http.dto.adr;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConsultantExamLearningPlanSelectionDto {

	private Long id;
	private String description;
}
