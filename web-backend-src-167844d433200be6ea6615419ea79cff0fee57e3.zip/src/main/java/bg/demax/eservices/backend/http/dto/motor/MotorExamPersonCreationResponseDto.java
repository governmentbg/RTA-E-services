package bg.demax.eservices.backend.http.dto.motor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MotorExamPersonCreationResponseDto {

	private Long examPersonId;
}
