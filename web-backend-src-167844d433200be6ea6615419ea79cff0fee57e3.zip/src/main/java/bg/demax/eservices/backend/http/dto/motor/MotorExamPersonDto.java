package bg.demax.eservices.backend.http.dto.motor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MotorExamPersonDto {

	private Long examPersonId;
	private OrgUnitDto orgUnit;
	private String learningPlanName;
	private String theoreticalExamResult;
}
