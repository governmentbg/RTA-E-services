package bg.demax.eservices.backend.http.dto.motor;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MotorExamPersonRegistrationRequestDto {

	private String personalIdentityNumber;

	private String firstName;
	private String surname;
	private String familyName;

	private String firstNameLatin;
	private String surnameLatin;
	private String familyNameLatin;
	
	private String countryCode;

	private String regionCode;

	private Long learningPlanId;

	private String orgUnitCode;
	
	private List<MotorProvidedDocumentRegistrationRequestDto> providedDocuments;
}
