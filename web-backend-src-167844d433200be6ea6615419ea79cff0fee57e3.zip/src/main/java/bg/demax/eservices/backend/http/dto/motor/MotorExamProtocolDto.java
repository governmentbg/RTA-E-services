package bg.demax.eservices.backend.http.dto.motor;

import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MotorExamProtocolDto {

	private Long id;
	private String number;
	
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDateTime examDateTime;
	
	private OrgUnitDto orgUnit;
	private String roomName;
	private Integer remainingSeats;
}
