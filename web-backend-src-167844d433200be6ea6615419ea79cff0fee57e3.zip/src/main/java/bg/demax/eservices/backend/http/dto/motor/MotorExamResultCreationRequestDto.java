package bg.demax.eservices.backend.http.dto.motor;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MotorExamResultCreationRequestDto {

	@NotNull
	@Min(1)
	private Long examPersonId;
	
	@NotNull
	@Min(1)
	private Long protocolId;
	
	private String municipalityCode;
	
	private String municipalityRegionCode;
}
