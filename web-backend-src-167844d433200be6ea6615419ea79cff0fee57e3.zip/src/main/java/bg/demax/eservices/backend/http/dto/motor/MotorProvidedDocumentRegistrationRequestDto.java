package bg.demax.eservices.backend.http.dto.motor;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MotorProvidedDocumentRegistrationRequestDto {

	public static final long CERTIFICATE_OF_PSYCHOLOGICAL_FITNESS_DOC_REQUIREMENT_ID = 495;
	public static final long CRIMINAL_RECORD_CERTIFICATE_DOC_REQUIREMENT_ID = 496;
	public static final long DRIVING_LICENCE_DOC_REQUIREMENT_ID = 497;
	
	@NotNull
	private Long documentRequirementId;

	@NotBlank
	private String number;

	@NotNull
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate issueDate;

	private String issuedBy;
}
