package bg.demax.eservices.backend.http.dto.motor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaxiMotorExamEnrolmentRequestDto {

	private Long examPersonId;
	private Long protocolId;
	private String municipalityCode;
}
