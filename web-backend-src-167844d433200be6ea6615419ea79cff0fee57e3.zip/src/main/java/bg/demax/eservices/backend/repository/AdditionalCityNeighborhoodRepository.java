package bg.demax.eservices.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.AdditionalCityNeighborhood;

@Repository
public interface AdditionalCityNeighborhoodRepository extends JpaRepository<AdditionalCityNeighborhood, Integer> {

	AdditionalCityNeighborhood findByCityNeighborhoodName(String cityNeighborhoodName);
}