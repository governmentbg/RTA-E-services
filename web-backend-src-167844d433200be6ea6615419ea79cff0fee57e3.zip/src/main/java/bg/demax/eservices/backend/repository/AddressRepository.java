package bg.demax.eservices.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.Address;
import bg.demax.eservices.backend.entity.applications.City;
import bg.demax.eservices.backend.entity.applications.Country;

@Repository
public interface AddressRepository extends JpaRepository<Address, Integer> {

	Address findFirstByStreetAndPostalCodeAndCityAndStreetNumberAndBuildingAndApartment(
		String street, String postalCode, City city, String streetNumber, 
			String building, String apartment);

	Address findByCountry(Country country);
}