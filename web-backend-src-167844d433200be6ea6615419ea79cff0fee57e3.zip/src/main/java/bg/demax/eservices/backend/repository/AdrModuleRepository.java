package bg.demax.eservices.backend.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.AdrModule;
import bg.demax.eservices.backend.entity.applications.ModuleType;
import bg.demax.eservices.backend.entity.subjects.Subject;

@Repository
public interface AdrModuleRepository extends JpaRepository<AdrModule, Integer> {

	@Query(" SELECT COUNT(apps.id) FROM AdrModule AS module "
		+ "JOIN module.adrCardApplications AS apps  " 
		+ "WHERE module.id = :adrModuleId")
	int countByAdrModule(int adrModuleId);

	AdrModule findByModuleTypeAndIssuedDateAndSubject(ModuleType type, LocalDate date, Subject subject);

	AdrModule findByModuleTypeAndValidDateAndSubject(ModuleType type, LocalDate date, Subject subject);

	List<AdrModule> findBySubject(Subject subject);

	@Query("SELECT module FROM AdrModule AS module "
		+ "JOIN module.adrCardApplications AS apps  " 
		+ "WHERE apps.id = :adrCardApplicationId")
	List<AdrModule> findByAdrCardApplication(int adrCardApplicationId);
}