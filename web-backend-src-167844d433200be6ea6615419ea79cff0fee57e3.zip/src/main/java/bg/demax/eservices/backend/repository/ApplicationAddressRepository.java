package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.ContactType;
import bg.demax.eservices.backend.entity.applications.CorrespondenceType;
import bg.demax.eservices.backend.entity.applications.Address;
import bg.demax.eservices.backend.entity.applications.Application;
import bg.demax.eservices.backend.entity.applications.ApplicationAddress;

@Repository
public interface ApplicationAddressRepository extends JpaRepository<ApplicationAddress, Integer> {
	List<ApplicationAddress> findByApplicationAndContactType(Application application, ContactType contactType);

	List<ApplicationAddress> findByApplicationIdAndContactTypeId(Integer applicationId, Integer contactTypeId);
	
	ApplicationAddress findByApplicationAndCorrespondenceType(Application application, CorrespondenceType correspondenceType);
	
	ApplicationAddress findByApplicationIdAndCorrespondenceTypeId(int applicationId, Integer correspondenceTypeId);

	ApplicationAddress findByApplicationAndCorrespondenceTypeAndContactType(
		Application application, CorrespondenceType correspondenceType, ContactType contactType);

	ApplicationAddress findByApplicationIdAndCorrespondenceTypeIdAndContactTypeId(
		int application, int correspondenceType, int contactType);

	List<ApplicationAddress> findByApplication(Application application);
	
	int countByAddress(Address address);
}