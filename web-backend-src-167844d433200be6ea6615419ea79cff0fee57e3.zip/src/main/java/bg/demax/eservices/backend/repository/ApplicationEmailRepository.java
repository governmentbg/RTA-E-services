package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.Application;
import bg.demax.eservices.backend.entity.applications.ApplicationEmail;
import bg.demax.eservices.backend.entity.applications.CorrespondenceType;
import bg.demax.eservices.backend.entity.applications.Email;

@Repository
public interface ApplicationEmailRepository extends JpaRepository<ApplicationEmail, Integer> {
	List<ApplicationEmail> findByApplication(Application application);

	List<ApplicationEmail> findByApplicationId(Integer applicationId);

	ApplicationEmail findByApplicationAndCorrespondenceType(Application application, CorrespondenceType correspondenceType);

	ApplicationEmail findByApplicationIdAndCorrespondenceTypeId(Integer applicationId, Integer correspondenceTypeId);
	
	ApplicationEmail findByApplicationAndEmail(Application application, Email email);

	ApplicationEmail findByApplicationAndCorrespondenceTypeAndEmail(
		Application application, CorrespondenceType correspondenceType, Email email);

	int countByEmail(Email email);	
}