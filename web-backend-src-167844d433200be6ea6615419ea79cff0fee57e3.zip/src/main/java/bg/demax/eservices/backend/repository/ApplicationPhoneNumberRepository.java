package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.Application;
import bg.demax.eservices.backend.entity.applications.ApplicationPhoneNumber;
import bg.demax.eservices.backend.entity.applications.CorrespondenceType;
import bg.demax.eservices.backend.entity.applications.PhoneNumber;

@Repository
public interface ApplicationPhoneNumberRepository extends JpaRepository<ApplicationPhoneNumber, Integer> {
	ApplicationPhoneNumber findByApplicationAndCorrespondenceType(Application application, CorrespondenceType correspondenceType);

	ApplicationPhoneNumber findByApplicationIdAndCorrespondenceTypeId(Integer applicationId, Integer correspondenceTypeId);

	List<ApplicationPhoneNumber> findByApplication(Application application);

	int countByPhoneNumber(PhoneNumber phoneNumber);
}
