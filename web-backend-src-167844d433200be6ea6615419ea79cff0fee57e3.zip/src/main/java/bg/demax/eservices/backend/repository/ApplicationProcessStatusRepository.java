package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.fsm.ApplicationProcessStatus;

@Repository
public interface ApplicationProcessStatusRepository extends JpaRepository<ApplicationProcessStatus, Integer> {
	@Query("SELECT status FROM ApplicationProcessStatus AS status "
		+ "JOIN status.transitions AS tr  " 
		+ "JOIN tr.applicationProcessTransitions AS apt  " 
		+ "WHERE apt.applicationProcess.id = :applicationProcessId ORDER BY apt.id")
	List<ApplicationProcessStatus> findByApplicationProcess(int applicationProcessId);
}
