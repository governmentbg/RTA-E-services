package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.fsm.ApplicationProcess;
import bg.demax.eservices.backend.entity.fsm.ApplicationProcessTransition;

@Repository
public interface ApplicationProcessTransitionsRepository extends JpaRepository<ApplicationProcessTransition, Integer> {

	List<ApplicationProcessTransition> findByApplicationProcessOrderById(ApplicationProcess applicationProcess);

	ApplicationProcessTransition findFirstByApplicationProcessApplicationIdOrderById(Integer applicationId);
}