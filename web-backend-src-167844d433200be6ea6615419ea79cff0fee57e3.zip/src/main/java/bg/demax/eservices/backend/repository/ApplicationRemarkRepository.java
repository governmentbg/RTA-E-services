package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.Application;
import bg.demax.eservices.backend.entity.applications.ApplicationRemark;

@Repository
public interface ApplicationRemarkRepository extends JpaRepository<ApplicationRemark, Integer> {

	List<ApplicationRemark> findAllByApplicationId(int applicationId);

	void deleteAllByApplication(Application application);
}