package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.Application;
import bg.demax.eservices.backend.entity.applications.CardApplication;
import bg.demax.eservices.backend.entity.applications.DrivingLicence;
import bg.demax.eservices.backend.entity.applications.IdentityDocument;
import bg.demax.eservices.backend.entity.security.User;
import bg.demax.eservices.backend.entity.subjects.Subject;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Integer> {

	List<Application> findAllByUserOrderByIdDesc(User user);
	
	List<Application> findAllByCurrentGeneralizedStatusId(int generalizedStatusId);
	
	Page<Application> findAll(Specification<Application> params, Pageable pageable);

	int countByIdentityDocument(IdentityDocument identityDocument);

	int countByDrivingLicence(DrivingLicence drivingLicence);

	int countBySubject(Subject subject);

	@Query(value = "FROM CardApplication AS a WHERE a.submissionTimestamp >= current_date - :nDays")
	List<CardApplication> findAllCardApplicationsSubmittedInLastNDays(@Param("nDays") int nDays);
}
