package bg.demax.eservices.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.ApplicationType;
import bg.demax.eservices.backend.entity.fsm.ApplicationProcessStatus;

@Repository
public interface ApplicationTypeRepository extends JpaRepository<ApplicationType, Integer> {

	ApplicationType findByStatus(ApplicationProcessStatus status);
}