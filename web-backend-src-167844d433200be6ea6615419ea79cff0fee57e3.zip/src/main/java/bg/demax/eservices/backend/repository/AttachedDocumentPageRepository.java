package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.AttachedDocument;
import bg.demax.eservices.backend.entity.applications.AttachedDocumentPage;
import bg.demax.eservices.backend.entity.applications.RequiredDocumentType;

@Repository
public interface AttachedDocumentPageRepository extends JpaRepository<AttachedDocumentPage, Integer> {

	int countByAttachedDocument(AttachedDocument document);

	List<AttachedDocumentPage> findAllByAttachedDocumentOrderByIdAsc(AttachedDocument document);

	List<AttachedDocumentPage> findAllByAttachedDocumentOrderByPageNumber(AttachedDocument document);
	
	@Query(value = "SELECT * FROM applications.attached_document_pages AS atp WHERE atp.attached_document_id IN (" 
		+ "	SELECT ad.id FROM ( "
		+ "	SELECT document_type_id, MAX(attached_timestamp) AS MaxDate "
		+ "	FROM applications.attached_documents AS ad "
		+ "	JOIN applications.applications AS a ON a.id = ad.application_id "
		+ " WHERE a.id =:applicationId and NOT(document_type_id="
		+ RequiredDocumentType.PHOTO_FACE + ") and NOT (document_type_id=" + RequiredDocumentType.PHOTO_SIGNATURE + ")"
		+ " and NOT (document_type_id=" + RequiredDocumentType.PHOTO_FACE_AUTHORIZED + ")"
		+ " GROUP BY document_type_id) AS md"
		+ "	INNER JOIN applications.attached_documents AS ad"
		+ "	ON ad.document_type_id = md.document_type_id AND ad.attached_timestamp = md.MaxDate)", nativeQuery = true)
	List<AttachedDocumentPage> findAllAttachedDocumentPagesExceptPhotoFaceAndSignByApplication(int applicationId);
	
	//TODO: test
	@Query("SELECT page "
			+ "FROM AttachedDocumentPage page "
			+ "WHERE page.attachedDocument.application.id = :applicationId "
			+ "AND page.attachedDocument.documentType.id = :requiredDocumentTypeId ")
	List<AttachedDocumentPage> findByApplicationIdAndRequiredDocumentTypeId(@Param("applicationId") int applicationId, 
			@Param("requiredDocumentTypeId") int requiredDocumentTypeId, 
			Pageable pageable);
}
