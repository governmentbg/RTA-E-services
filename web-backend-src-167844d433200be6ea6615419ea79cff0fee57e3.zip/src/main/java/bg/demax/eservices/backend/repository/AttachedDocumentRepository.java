package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.Application;
import bg.demax.eservices.backend.entity.applications.AttachedDocument;
import bg.demax.eservices.backend.entity.applications.RequiredDocumentType;

@Repository
public interface AttachedDocumentRepository extends JpaRepository<AttachedDocument, Integer> {
	AttachedDocument findAttachedDocumentByApplicationIdAndDocumentTypeIdAndIsActive(
		int applicationId, int documentTypeId, boolean isActive);

	@Query(value = "SELECT * FROM applications.attached_documents AS ad"
		+ " WHERE ad.id IN (" 
		+ " SELECT ad.id FROM (" 
			+ " SELECT document_type_id, MAX(attached_timestamp) AS MaxDate"
			+ " FROM applications.attached_documents AS ad" 
			+ " JOIN applications.applications AS a ON a.id = ad.application_id"
			+ " WHERE a.id = :applicationId"
			+ " GROUP BY document_type_id) AS md"
		+ " INNER JOIN applications.attached_documents AS ad"
		+ " ON ad.document_type_id = md.document_type_id AND ad.attached_timestamp = md.MaxDate)", nativeQuery = true)
	List<AttachedDocument> findAllLastAttachedDocumentsByApplication(int applicationId);

	boolean existsByApplicationAndDocumentTypeAndIsActive(Application application, RequiredDocumentType documentType, boolean isActive);

	List<AttachedDocument> findByApplication(Application application);
}
