package bg.demax.eservices.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.Application;
import bg.demax.eservices.backend.entity.subjects.Authorization;
import bg.demax.eservices.backend.entity.subjects.Subject;

@Repository
public interface AuthorizationRepository extends JpaRepository<Authorization, Integer> {

	Authorization findByApplication(Application application);

	int countByAuthorizedSubject(Subject subject);
}