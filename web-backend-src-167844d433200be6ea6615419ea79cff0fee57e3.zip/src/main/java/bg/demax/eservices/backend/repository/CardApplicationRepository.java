package bg.demax.eservices.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.CardApplication;
import bg.demax.eservices.backend.entity.applications.OldCard;

@Repository
public interface CardApplicationRepository extends JpaRepository<CardApplication, Integer> {

	int countByOldCard(OldCard oldCard);
}