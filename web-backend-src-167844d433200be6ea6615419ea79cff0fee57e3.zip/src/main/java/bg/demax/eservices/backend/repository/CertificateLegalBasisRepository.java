package bg.demax.eservices.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.CertificateLegalBasisType;

@Repository
public interface CertificateLegalBasisRepository extends JpaRepository<CertificateLegalBasisType, Integer> {
	@Query(value = "SELECT * FROM applications.n_certificate_legal_basis_types AS c "
			+ "INNER JOIN config.translation_keys AS tk ON tk.key = c.translation_key "
			+ "INNER JOIN config.translation_values AS tv ON tv.translation_key = tk.key "
			+ "WHERE tv.value = :legalBasis", nativeQuery = true)
	CertificateLegalBasisType findByLegalBasis(@Param("legalBasis") String legalBasis);

	CertificateLegalBasisType findByRegisterResponseBasis(String registerBasisString);

	CertificateLegalBasisType findByDqcCertificateType(String certificateType);
}