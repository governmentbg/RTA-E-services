package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.City;

@Repository
public interface CityRepository extends JpaRepository<City, Integer> {

	List<City> findByRegionCode(String regionCode);

	@Query(value =  "FROM City c JOIN TranslationValue tv ON tv.id.translationKey = c.translationKey "
				+ "WHERE c.region.code = :regionCode AND "
				+ "lower(tv.value) LIKE %:phrase% AND tv.id.language.code = :langCode")
	List<City> findByAutocompletePhraseAndLangCode(String phrase, String langCode, String regionCode);
}