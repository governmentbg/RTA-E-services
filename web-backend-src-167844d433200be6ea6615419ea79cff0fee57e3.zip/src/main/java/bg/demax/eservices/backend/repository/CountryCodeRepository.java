package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.CountryCode;

@Repository
public interface CountryCodeRepository extends JpaRepository<CountryCode, Integer> {
	List<CountryCode> findAllByOrderByCode();
}
