package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.Country;

@Repository
public interface CountryRepository extends JpaRepository<Country, String> {

	@Query(value =  "FROM Country c JOIN TranslationValue tv ON tv.id.translationKey = c.translationKey "
				+ "WHERE tv.value = :countryName")
	Country findByName(String countryName);

	@Query(value =  "FROM Country c JOIN TranslationValue tv ON tv.id.translationKey = c.translationKey "
				+ "WHERE lower(tv.value) LIKE :phrase% AND tv.id.language.code = :langCode ORDER BY tv.value")
	List<Country> findByAutocompletePhraseAndLangCode(String phrase, String langCode);

	Country findByCode2(String code);

	Country findByCode3(String code);
}