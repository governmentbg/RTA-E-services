package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.DocumentIssuer;

@Repository
public interface DocumentIssuerRepository extends JpaRepository<DocumentIssuer, String> {
	
	@Query(value = "FROM DocumentIssuer AS di WHERE di.translationKey.key = "
				+ "(SELECT vs.id.translationKey FROM di.translationKey.values AS vs "
				+ "WHERE vs.value = :documentIssuer AND vs.id.language.code = 'bg')")
	DocumentIssuer findByDocumentIssuer(String documentIssuer);
	
	@Query("FROM DocumentIssuer di JOIN TranslationValue tv ON tv.id.translationKey = di.translationKey "
			+ "WHERE tv.id.language.code = 'bg' ORDER BY tv.value")
	List<DocumentIssuer> findAllOderByBgTranslation();

	@Query(value =  "FROM DocumentIssuer di JOIN TranslationValue tv ON tv.id.translationKey = di.translationKey "
				+ "WHERE lower(tv.value) LIKE :phrase% AND tv.id.language.code = :langCode")
	List<DocumentIssuer> findByAutocompletePhraseAndLangCode(String phrase, String langCode);
}