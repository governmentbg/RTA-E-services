package bg.demax.eservices.backend.repository;

import java.util.List;
import java.time.LocalDate;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.DqcApplication;
import bg.demax.eservices.backend.entity.applications.DqcCertificate;
import bg.demax.eservices.backend.entity.applications.TrainingType;
import bg.demax.eservices.backend.entity.subjects.Subject;

@Repository
public interface DqcCertificateRepository extends JpaRepository<DqcCertificate, Integer> {

	DqcCertificate findByPermitNumberAndNumberAndCertificateTypeAndIssuedDateAndSubjectAndIsAttached(
		String permitNumber, String number, TrainingType certificateType, LocalDate date, Subject subject, boolean isAttached);
	
	List<DqcCertificate> findByDqcApplicationsId(int applicationId);

	List<DqcCertificate> findBySubjectAndDqcApplicationsAndIsAttachedTrue(Subject subject, DqcApplication application);

	@Query("SELECT COUNT(apps.id) FROM DqcCertificate AS certificate "
		+ "JOIN certificate.dqcApplications AS apps  " 
		+ "WHERE certificate.id = :dqcCertificateId")
	int countByDqcCertificates(int dqcCertificateId);
}