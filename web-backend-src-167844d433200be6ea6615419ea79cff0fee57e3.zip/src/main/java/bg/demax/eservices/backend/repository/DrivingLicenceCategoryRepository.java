package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.Category;
import bg.demax.eservices.backend.entity.applications.DrivingLicence;
import bg.demax.eservices.backend.entity.applications.DrivingLicenceCategory;

@Repository
public interface DrivingLicenceCategoryRepository extends JpaRepository<DrivingLicenceCategory, Integer> {

	DrivingLicenceCategory findByDrivingLicenceAndCategory(DrivingLicence drivingLicence, Category category);
	
	List<DrivingLicenceCategory> findByDrivingLicence(DrivingLicence drivingLicence);
}