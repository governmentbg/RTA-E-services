package bg.demax.eservices.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.Gender;

@Repository
public interface GenderRepository extends JpaRepository<Gender, String> {
	
	@Query(value = "FROM Gender AS g WHERE g.translationKey.key = "
				+ "(SELECT vs.id.translationKey FROM g.translationKey.values AS vs "
				+ "WHERE vs.value = :gender AND vs.id.language.code = 'en')")
	Gender findByGender(String gender);
}