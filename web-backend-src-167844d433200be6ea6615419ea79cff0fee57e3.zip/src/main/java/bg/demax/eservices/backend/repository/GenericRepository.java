package bg.demax.eservices.backend.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.exception.NoSuchEntityException;
import bg.demax.hibernate.AbstractFinder;

@Repository
public class GenericRepository extends AbstractFinder {

	public <ENTITY_TYPE, ID> ENTITY_TYPE findById(Class<ENTITY_TYPE> type, Serializable id) {
		return getSession().find(type, id);
	}

	public <ENTITY_TYPE, ID> ENTITY_TYPE findByIdOrElseThrowException(Class<ENTITY_TYPE> type, Serializable id) {
		ENTITY_TYPE entity = findById(type, id);
		if (entity == null) {
			throw new NoSuchEntityException(type, id);
		}
		return entity;
	}

	public <ENTITY_TYPE> ENTITY_TYPE getReferenceById(Class<ENTITY_TYPE> entityClass, Serializable id) {
		return getSession().byId(entityClass).getReference(id);
	}

	@SuppressWarnings("unchecked")
	public <ENTITY_TYPE> List<ENTITY_TYPE> findAll(Class<ENTITY_TYPE> entityClass) {
		return (List<ENTITY_TYPE>) createQuery("from " + entityClass.getName() + " order by id asc").list();
	}

	public void save(Object entity) {
		getSession().persist(entity);
	}

	public void delete(Object entity) {
		getSession().delete(entity);
	}

	public void flush() {
		getSession().flush();
	}
}
