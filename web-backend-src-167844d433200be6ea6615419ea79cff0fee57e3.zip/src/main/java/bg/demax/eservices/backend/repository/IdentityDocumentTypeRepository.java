package bg.demax.eservices.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import bg.demax.eservices.backend.entity.applications.IdentityDocumentType;

@Repository
public interface IdentityDocumentTypeRepository extends JpaRepository<IdentityDocumentType, Integer> {

	@Query(value =  "FROM IdentityDocumentType idt JOIN TranslationValue tv ON tv.id.translationKey = idt.translationKey "
			+ "WHERE lower(tv.value) LIKE :phrase%  AND tv.id.language.code = :langCode")
	List<IdentityDocumentType> findByAutocompletePhraseAndLangCode(String phrase, String langCode);
}