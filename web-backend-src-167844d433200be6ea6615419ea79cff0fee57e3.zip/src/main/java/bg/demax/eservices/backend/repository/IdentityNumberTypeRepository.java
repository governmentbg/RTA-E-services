package bg.demax.eservices.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import bg.demax.eservices.backend.entity.subjects.IdentityNumberType;

public interface IdentityNumberTypeRepository extends JpaRepository<IdentityNumberType, Integer> {
	
	IdentityNumberType findByType(String type);
}
