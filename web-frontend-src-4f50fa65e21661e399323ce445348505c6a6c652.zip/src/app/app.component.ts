import { Component, OnInit, HostListener } from '@angular/core';
import { AuthenticationService } from './core/authentication/authentication.service';
import { RouteUtilService } from './core/services/route-util.service';
import { Location } from '@angular/common';
import { Subject } from 'rxjs';
import { PopUpService } from './core/services/pop-up.service';
import { PopUpTypes } from './shared/enums/pop-up-types';
import { POP_UP_MESSAGES_KEYS } from './shared/models/constants/pop-up-messages-keys';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
})
export class AppComponent implements OnInit {
	title = 'e-services';
	userActivity;
	userInactiveFor25Min: Subject<object> = new Subject();
	isPopUpShown: boolean;
	TWENTY_FIVE_MINUTES = 1500000;

	// TODO testing purposes only
	TWO_SECONDS = 2000;

	constructor(
		public authService: AuthenticationService,
		public routeUtilService: RouteUtilService,
		public location: Location
	) { }

	ngOnInit(): void {
		if (!this.authService.getAuthenticatedUser() && !this.routeUtilService.isInAuthenticationTab(location.pathname)) {
			this.authService.loadCurrentUserDetails();
		}

		if (!this.routeUtilService.isInAuthenticationTab(location.pathname)) {
			this.setTimeout();
			this.userInactiveFor25Min.subscribe(
				() => {
					let countdown;
					const countDownDate = new Date().setMinutes(new Date().getMinutes() + 5);
					const interval = setInterval(() => {

						const now = new Date().getTime();
						const distance = countDownDate - now;
						const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
						const seconds = Math.floor((distance % (1000 * 60)) / 1000);

						countdown = minutes + 'm ' + seconds + 's ';
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.warning_session_about_to_expire,
							subHeader: POP_UP_MESSAGES_KEYS.warning_time_before_auto_logout,
							extraInfo: countdown,
							text: POP_UP_MESSAGES_KEYS.warning_want_to_continue,
							type: PopUpTypes.WARNING
						});
						this.isPopUpShown = true;

						if (distance < 0) {
							clearInterval(interval);
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.info_session_expired,
								type: PopUpTypes.INFO
							});
							const currentSecondSubscription = PopUpService.subscribeToShowPopUp(
								(showPopUp) => {
									if (!showPopUp) {
										this.authService.logout();
									}
									this.isPopUpShown = false;
									clearTimeout(this.userActivity);
									currentSecondSubscription.unsubscribe();
								});
						}
					}, 1000);
					const currentSubscription = PopUpService.subscribeToPopUpResponse(
						(hasConfirmed) => {
							if (hasConfirmed) {
								this.authService.logout();
							}
							clearInterval(interval);
							clearTimeout(this.userActivity);
							this.isPopUpShown = false;
							currentSubscription.unsubscribe();
						});
				}
			);
		}
	}

	setTimeout() {
		this.userActivity = setTimeout(
			() => this.userInactiveFor25Min.next(undefined), this.TWENTY_FIVE_MINUTES);
	}

	@HostListener('window:mousemove')
	@HostListener('window:mousemove')
	refreshUserState() {
		if (!this.routeUtilService.isInAuthenticationTab(location.pathname) && !this.isPopUpShown) {
			clearTimeout(this.userActivity);
			this.setTimeout();
			this.isPopUpShown = false;
		}
	}
}
