import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS, HttpClientXsrfModule } from '@angular/common/http';
import { L10nConfig, L10nLoader, ProviderType, LocalizationModule, TranslationService, TranslationModule } from 'angular-l10n';
import { NgModule } from '@angular/core';

import { AdminModule } from './modules/admin/admin.module';
import { DatePipe } from '@angular/common';
import { AppRouting } from './app.routing';
import { AppComponent } from './app.component';
import { AppConstants } from './shared/enums/app-constants';
import { ApplicationModule } from './modules/application/application.module';
import { AuthenticationModule } from './modules/authentication/authentication.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import { ErrorInterceptor } from './core/interceptors/error.interceptor';
import { HeaderComponent } from './shared/components/header/header.component';
import { SubHeaderComponent } from './shared/components/sub-header/sub-header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxFileDropModule } from 'ngx-file-drop';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DevModule } from './modules/dev/dev.module';
import { SharedModule } from './shared/shared.module';
import { CoreModule } from './core/core.module';

const l10nConfig: L10nConfig = {
	locale: {
		defaultLocale: { languageCode: 'bg' }
	},
	translation: {
		providers: [
			{ type: ProviderType.WebAPI, path: 'api/translations/' }
		],
		caching: true,
		missingValue: 'No key'
	}
};

@NgModule({
	declarations: [
		AppComponent,
		HeaderComponent,
		SubHeaderComponent,
	],
	imports: [
		BrowserModule,
		AppRouting,
		AuthenticationModule,
		CoreModule,
		DashboardModule,
		SharedModule,
		ApplicationModule,
		AdminModule,
		DevModule,
		NgxFileDropModule,
		ReactiveFormsModule,
		FormsModule,
		HttpClientModule,
		HttpClientXsrfModule.withOptions({
			cookieName: AppConstants.CSRF_TOKEN_COOKIE_NAME,
			headerName: AppConstants.CSRF_TOKEN_HEADER_HEADER_NAME
		}),
		LocalizationModule.forRoot(l10nConfig),
		BrowserAnimationsModule
	],
	exports: [
		TranslationModule
	],
	providers: [
		DatePipe,
		TranslationService,
		{ provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true }
	],
	bootstrap: [AppComponent]
})
export class AppModule {
	constructor(
		private l10nLoader: L10nLoader,
		private translation: TranslationService) {

		this.l10nLoader.load();

		this.translation.translationError.subscribe((error) => {
			if (error) {
				console.log(error);
			}
		});
	}
}
