import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './core/guards/auth.guard';
import { RouteUrl } from './shared/enums/route-url.enum';
import { AppComponent } from './app.component';

const routes: Routes = [
	{
		path: '',
		component: AppComponent,
		canActivate: [AuthGuard]
	},
	{
		path: RouteUrl.LOG_IN,
		loadChildren: () => import('./modules/authentication/authentication.module').then(m => m.AuthenticationModule)
	},
	{
		path: RouteUrl.DASHBOARD,
		loadChildren: () => import('./modules/dashboard/dashboard.module').then(m => m.DashboardModule)
	},
	{
		path: RouteUrl.APPLICATION,
		loadChildren: () => import( './modules/application/application.module').then(m => m.ApplicationModule)
	},
	{
		path: RouteUrl.ADMIN,
		loadChildren: () => import('./modules/admin/admin.module').then(m => m.AdminModule)
	},
	{
		path: RouteUrl.DEV,
		loadChildren: () => import('./modules/dev/dev.module').then(m => m.DevModule)
	},
	{
		path: '**',
		redirectTo: ''
	}
];

@NgModule({
	imports: [
		RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })
	],
	exports: [
		RouterModule
	]
})
export class AppRouting { }
