import { Injectable } from '@angular/core';
import { ReplaySubject } from 'rxjs';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';
import { Router } from '@angular/router';
import { User } from '../../shared/models/user';
import { UserService } from './user.service';
import { UserDto } from '../../shared/interfaces/user-dto';


@Injectable({
	providedIn: 'root'
})
export class AuthenticationService {

	private userSubject: ReplaySubject<User> = new ReplaySubject<User>(1);
	private user: User;

	constructor(
		private userService: UserService,
		private router: Router
	) { }

	public loadCurrentUserDetails(): void {
		this.userService.getCurrentUserDetails()
			.subscribe(
				(userDto: UserDto) => {
					this.user = new User(userDto);
					this.userSubject.next(this.user);
				},
				(() => {
					this.resetCurrentUser();
				}));
	}

	public populateUserDetailsFromDto(userDto: UserDto): void {
		this.user = new User(userDto);
		this.userSubject.next(this.user);
	}

	public getAuthenticatedUserSubject(): ReplaySubject<User> {
		return this.userSubject;
	}

	public getAuthenticatedUser(): User {
		return this.user;
	}

	public logout() {
		return this.userService.logout().subscribe(() => this.handleLogOut());
	}

	public handleLogOut() {
		this.resetCurrentUser();
		this.router.navigateByUrl(RouteUrl.LOG_IN);
	}

	public resetCurrentUser() {
		this.userSubject.next(null);
		this.user = null;
	}
}
