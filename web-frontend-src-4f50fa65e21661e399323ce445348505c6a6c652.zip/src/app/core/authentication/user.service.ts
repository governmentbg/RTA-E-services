import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { PaginationParams } from 'src/app/shared/pagination/pagination-params';
import { UserDto } from '../../shared/interfaces/user-dto';
import { UserManagementListItemDto } from 'src/app/shared/interfaces/user-management-list-item-dto';
import { PageResultDto } from 'src/app/shared/interfaces/page-result-dto';
import { Utils } from 'src/app/shared/utils/utils';
import { UserManagementListQueryParams } from 'src/app/shared/interfaces/user-management-list-query-params';
import { UserManagementListItem } from 'src/app/shared/models/user-management-list-item';
import { map } from 'rxjs/operators';
import { UserRoleChangeRequestDto } from 'src/app/shared/interfaces/user-role-change-request-dto';

@Injectable({
	providedIn: 'root'
})
export class UserService {

	private URL = {
		LOGOUT: 'api/logout',
		CURRENT_USER_DETAILS: 'api/users/current',
		USERS: 'api/users'
	};

	constructor(
		private httpClient: HttpClient,
		private readonly utils: Utils) { }

	getCurrentUserDetails(): Observable<UserDto> {
		return this.httpClient.get<UserDto>(this.URL.CURRENT_USER_DETAILS);
	}

	public logout(): Observable<void> {
		return this.httpClient.post<void>(this.URL.LOGOUT, null);
	}

	public getUsers(pageParams: PaginationParams, searchParams: UserManagementListQueryParams): Observable<PageResultDto<UserManagementListItem>> {
		const params = this.utils.toHttpParamsWithDate(pageParams, searchParams);
		return this.httpClient.get<PageResultDto<UserManagementListItemDto>>(this.URL.USERS, { params })
			.pipe(map((pageResult: PageResultDto<UserManagementListItemDto>) => {
				return {
					totalCount: pageResult.totalCount,
					items: pageResult.items.map((userDto: UserManagementListItemDto) => {
						return new UserManagementListItem(userDto);
					})
				}
			}));
	}

	public changeUserRole(userId: number, requestDto: UserRoleChangeRequestDto): Observable<void> {
		return this.httpClient.put<void>(`${this.URL.USERS}/${userId}/roles`, requestDto);
	}
}
