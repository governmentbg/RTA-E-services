import { NgModule, Optional, SkipSelf } from '@angular/core';
import { ApplicationService } from './services/application.service';
import { CommonModule } from '@angular/common';
import { Utils } from '../shared/utils/utils';
import { DocumentService } from './services/document.service';

@NgModule({
	providers: [
		ApplicationService,
		DocumentService,
		Utils
	],
	declarations: [],
	imports: [
		CommonModule
	]
})
export class CoreModule {
	constructor(@Optional() @SkipSelf() parent: CoreModule) {
	if (parent) {
		return parent;
	}
	}
}
