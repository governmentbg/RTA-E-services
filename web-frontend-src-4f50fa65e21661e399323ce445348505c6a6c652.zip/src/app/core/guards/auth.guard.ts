import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable, ReplaySubject } from 'rxjs';
import { AuthenticationService } from '../authentication/authentication.service';
import { RouteUtilService } from '../services/route-util.service';
import { User } from 'src/app/shared/models/user';
import { RouteUrl } from '../../shared/enums/route-url.enum';
import { Environment } from 'src/environments/environment';
import { PopUpService } from '../services/pop-up.service';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {

	constructor(
				private authenticationService: AuthenticationService,
				private router: Router,
				private routeUtilService: RouteUtilService,
	) { }

	canActivate(
		route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<boolean> {
			return this.checkLogin(state.url, route);
	}

	canActivateChild(
		route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot): Observable<boolean> {
		return this.canActivate(route, state);
	}

	checkLogin(url: string, route: ActivatedRouteSnapshot): Observable<boolean> {
		const resultSubject = new ReplaySubject<boolean>();
		const currentUser = this.authenticationService.getAuthenticatedUser();
		const expectedRoles: string[] = this.getExpectedRoles(route);

		if (this.routeUtilService.isInAuthenticationTab(url)) {
			if (currentUser) {
				this.redirectToCorrectUrl(currentUser);
			} else {
				resultSubject.next(true);
			}
		} else if (currentUser && !this.routeUtilService.isInAuthenticationTab(url)) {
			resultSubject.next(this.processUserAccess(currentUser, url, expectedRoles));
		} else {
			const userSubscription = this.authenticationService.getAuthenticatedUserSubject()
				.subscribe((user: User) => {
					if (user) {
						resultSubject.next(this.processUserAccess(user, url, expectedRoles));
					} else {
						this.checkUrlIsEndpointForNewApplicationFromOtherWebApplicationLink(url);
						this.router.navigateByUrl(RouteUrl.LOG_IN);
					}
					userSubscription.unsubscribe();
				});
		}
		return resultSubject.asObservable();
	}

	private processUserAccess(user: User, url: string, expectedRoles: string[]): boolean {
		if (url === '/') {
			this.redirectToCorrectUrl(user);
			return false;
		} else if (url.includes(RouteUrl.DEV)) {
			if (Environment.dev) {
				return true;
			} else {
				return false;
			}
		} else if (user.isDemaxAdmin()) {
			return true;
		}

		if (user.hasAnyRole(...expectedRoles)) {
			return true;
		} else {
			PopUpService.showPopUp(DEFAULT_POP_UPS.error_access_denied);
			this.redirectToCorrectUrl(user);
			return false;
		}
	}

	private redirectToCorrectUrl(user: User): void {
		if (user.isDemaxAdmin() || user.isViewer() || user.isApprover()
			|| user.isDeskStaff() || user.isPersoCenterDemax()) {
			this.router.navigate([RouteUrl.ADMIN]);
		} else {
			this.router.navigate([RouteUrl.DASHBOARD]);
		}
	}

	private getExpectedRoles(route: ActivatedRouteSnapshot): string[] {
		let expectedRoles: string[];

		if (route != null && route.data != null) {
			expectedRoles = route.data.expectedRoles;
			if (expectedRoles == null || expectedRoles.length <= 0) {
				expectedRoles = this.getExpectedRoles(route.parent);
			}
		} else {
			return null;
		}
		return expectedRoles;
	}

	checkUrlIsEndpointForNewApplicationFromOtherWebApplicationLink(url: string): void {
		if (url) {
			const newAppUrl = '/' +  RouteUrl.APPLICATION + '/' + RouteUrl.NEW + '/';
			// TODO : change 3 to 7 when all application types are done
			const expression =  new RegExp('^' + newAppUrl + '[1-3]$');
			if (url.match(expression)) {
				const index = url.lastIndexOf('/');
				const applicationTypeId = url.substring(index + 1);
				const applicationType = { applicationTypeId, time: new Date() };
				localStorage.setItem(S_VARIABLES.CHOSEN_NEW_APPLICATION_TYPE_FROM_WEB_LINK , JSON.stringify(applicationType));
			}
		}
	}
}
