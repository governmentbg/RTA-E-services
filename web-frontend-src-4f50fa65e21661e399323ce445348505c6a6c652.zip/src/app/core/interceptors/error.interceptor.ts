
import { Injectable } from '@angular/core';
import {
	HttpEvent,
	HttpHandler,
	HttpRequest,
	HttpErrorResponse,
	HttpInterceptor
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';
import { PopUpService } from '../services/pop-up.service';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';

@Injectable({
	providedIn: 'root'
})
export class ErrorInterceptor implements HttpInterceptor {
	constructor(private router: Router) {
	}

	intercept(
		request: HttpRequest<any>,
		next: HttpHandler
	): Observable<HttpEvent<any>> {
		return next.handle(request)
			.pipe(
				catchError((error: HttpErrorResponse) => {
					let errorMessage = '';
					if (error.status === 400) {
						PopUpService.showPopUp(DEFAULT_POP_UPS.error_bad_request);
						errorMessage = `Error: ${error.statusText}`;
					} else if (error.status === 401) {
						window.location.href = RouteUrl.LOG_IN;
						errorMessage = `Error: ${error.error.message}`;
					} else if (error.status === 403) {
						PopUpService.showPopUp(DEFAULT_POP_UPS.error_access_denied);
						errorMessage = `Error: ${error.error.message}`;
					} else if (error.status === 404) {
						PopUpService.showPopUp(DEFAULT_POP_UPS.error_not_found);
						errorMessage = `Error: ${error.error.message}`;
					} else if (error.status === 500) {
						PopUpService.showPopUp(DEFAULT_POP_UPS.error);
						errorMessage = `Error Status: ${error.status}\nMessage: ${error.message}`;
					} else {
						return throwError(error);
					}

					return throwError(errorMessage);
				})
			);
	}
}
