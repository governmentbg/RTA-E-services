import { Injectable } from '@angular/core';
import { ApplicationSearchParams } from 'src/app/shared/models/application-query-params';
import { PaginationParams } from 'src/app/shared/pagination/pagination-params';

const BASE_URL = 'api/adr-cards';

@Injectable({
	providedIn: 'root'
})
export class AdminSearchService {

	filters: ApplicationSearchParams;
	pageParams: PaginationParams;
	
	public saveFilters(filterParams: ApplicationSearchParams): void {
		this.filters = filterParams;
	}

	public getFilters(): ApplicationSearchParams {
		return this.filters;
	}

	public savePageParams(pageParams: PaginationParams): void {
		this.pageParams = pageParams;
	}

	public getPageParams(): PaginationParams {
		return this.pageParams;
	}

	public hasAnyFilers(): boolean {
		return this.pageParams != null || this.filters != null;
	}

}
