import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AdrModuleDto } from 'src/app/shared/dtos/adr-module-dto';
import { ApplicationIdWrapperDto } from 'src/app/shared/dtos/application-id-wrapper-dto';

const BASE_URL = 'api/adr-cards';

@Injectable({
	providedIn: 'root'
})
export class AdrCardService {

	constructor(private http: HttpClient) { }

	public getModulesFromProxy(applicationId: number): Observable<AdrModuleDto[]> {
		return this.http.get<AdrModuleDto[]>(`${BASE_URL}/application/${applicationId}/modules`);
	}

	public getModulesForApprover(applicationId: number): Observable<AdrModuleDto[]> {
		return this.http.get<AdrModuleDto[]>(`${BASE_URL}/application/${applicationId}/approver/modules`);
	}

	public saveModule(applicationId: number, dto: AdrModuleDto): Observable<void> {
		return this.http.post<void>(`${BASE_URL}/application/${applicationId}/module`, dto);
	}

	public deleteModule(applicationId: number, moduleTypeId: number): Observable<void> {
		return this.http.delete<void>(`${BASE_URL}/application/${applicationId}/module/` +  moduleTypeId);
	}

	public saveTransitionForSelectedModules(applicationId: number): Observable<AdrModuleDto[]> {
		return this.http.post<AdrModuleDto[]>(`${BASE_URL}/application/${applicationId}/modules/transition`, null);
	}
}
