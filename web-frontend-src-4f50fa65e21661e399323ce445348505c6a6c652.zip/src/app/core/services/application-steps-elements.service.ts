import { Injectable } from '@angular/core';
import { Steps } from 'src/app/shared/enums/steps';
import { PopUpService } from './pop-up.service';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { Subject } from 'rxjs';
import { APPLICATION_TYPE } from 'src/app/shared/enums/application-types';

@Injectable({
	providedIn: 'root'
})
export class ApplicationStepsElementsService {

	private NUMBER_OF_STEPS_FOR_CARD_APPLICATION = 9;
	private NUMBER_OF_STEPS_FOR_TACHO_CARD_APPLICATION = 8;
	private NUMBER_OF_STEPS_FOR_EXAM_APPLICATION = 5;
	private COMPLETE_PROGRESS_SIZE = 100;

	public personalInfoEl: HTMLElement;
	public correspondenceEl: HTMLElement;
	public drivingLicenceEl: HTMLElement;
	public certificateEl: HTMLElement;
	public serviceOptionEl: HTMLElement;
	public deliveryEl: HTMLElement;
	public signingEl: HTMLElement;
	public signatureAndPhotoEl: HTMLElement;
	public paymentEl: HTMLElement;

	public adrExamServiceOptionsEl: HTMLElement;
	public adrExamPeopleEl: HTMLElement;
	public examOrgUnitSelectionEl: HTMLElement;
	public examProtocolSelectionEl: HTMLElement;
	public examMunicipalitySelectionEl: HTMLElement;
	public examRequiredDocumentsEl: HTMLElement;

	public examCategorySelectionEl: HTMLElement;

	public canSeeCorrespondence: boolean;
	public canSeeDL: boolean;
	public canSeeCertificate: boolean;
	public canSeeService: boolean;
	public canSeeDelivery: boolean;
	public canSeeSignatureAndPhoto = true;
	public canSeeSigning: boolean;
	public canSeePayment: boolean;

	public canSeeAdrExamServiceOptions: boolean;
	public canSeeAdrExamPeople: boolean;
	public canSeeOrgUnitSelection: boolean;
	public canSeeExamProtocolSelection: boolean;
	public canSeeExamMunicipalitySelection: boolean;
	public canSeeExamRequiredDocuments: boolean;
	public canSeeExamCategorySelection: boolean;

	public isPersonalInfoCurrent: boolean;
	public isCorrespondenceCurrent: boolean;
	public isDlCurrent: boolean;
	public isCertificateCurrent: boolean;
	public isServiceCurrent: boolean;
	public isDeliveryCurrent: boolean;
	public isSignatureAndPhotoCurrent: boolean;
	public isSigningCurrent: boolean;
	public isPaymentCurrent: boolean;
	public isMunicipalityCurrent: boolean;
	public isExamDocumentsCurrent: boolean;
	public isProtocolSelectCurrent: boolean;

	public isAdrExamServiceOptionsCurrent: boolean;
	public isAdrExamPeopleCurrent: boolean;
	public isOrgUnitSelectionCurrent: boolean;
	public isExamProtocolSelectionCurrent: boolean;
	public isExamCategorySelectionCurrent: boolean;

	public applicationProgress = new Subject<number>();
	public applicationTypeId: number;
	public passedSteps: string[] = [];
	public oneStepSize: number;

	public personalInfoNum: number;
	public correspondenceNum: number;
	public drivingLicenceNum: number;
	public certificateNum: number;
	public serviceNum: number;
	public deliveryNum: number;
	public signatureAndPhotoNum: number;
	public signingNum: number;
	public paymentNum: number;
	isEditing = Steps.EMPTY_STEP;

	public adrExamServiceOptionsNum: number;
	public adrExamPeopleNum: number;
	public examOrgUnitSelectionNum: number;
	public examProtocolSelectionNum: number;
	public examMunicipalitySelectionNum: number;
	public examRequiredDocumentsNum: number;
	public examCategorySelectionNum: number;

	public steps: Steps[] = [];

	constructor() { }

	public calculateOneStepSize(applicationTypeId: number) {
		this.applicationTypeId = applicationTypeId;
		if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_CARD
			|| this.applicationTypeId === APPLICATION_TYPE.APPLICATION_DQC) {
			this.oneStepSize = this.COMPLETE_PROGRESS_SIZE / this.NUMBER_OF_STEPS_FOR_CARD_APPLICATION;

		} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_TACHO_CARD) {
			this.oneStepSize = this.COMPLETE_PROGRESS_SIZE / this.NUMBER_OF_STEPS_FOR_TACHO_CARD_APPLICATION;

		} else {
			this.oneStepSize = this.COMPLETE_PROGRESS_SIZE / this.NUMBER_OF_STEPS_FOR_EXAM_APPLICATION;
		}

		this.steps.splice(0, this.steps.length);
		if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_TACHO_CARD) {
			this.steps.push(Steps.PERSONAL_INFO);
			this.steps.push(Steps.CORRESPONDENCE);
			this.steps.push(Steps.DRIVING_LICENCE);
			this.steps.push(Steps.SERVICE);
			this.steps.push(Steps.DELIVERY);
			this.steps.push(Steps.SIGNATURE_AND_PHOTO);
			this.steps.push(Steps.SIGNING);
			this.steps.push(Steps.PAYMENT);
		} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_DQC) {
			this.steps.push(Steps.PERSONAL_INFO);
			this.steps.push(Steps.CORRESPONDENCE);
			this.steps.push(Steps.DRIVING_LICENCE);
			this.steps.push(Steps.CERTIFICATE);
			this.steps.push(Steps.SERVICE);
			this.steps.push(Steps.DELIVERY);
			this.steps.push(Steps.SIGNATURE_AND_PHOTO);
			this.steps.push(Steps.SIGNING);
			this.steps.push(Steps.PAYMENT);
		} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_CARD) {
			this.steps.push(Steps.PERSONAL_INFO);
			this.steps.push(Steps.CORRESPONDENCE);
			this.steps.push(Steps.DRIVING_LICENCE);
			this.steps.push(Steps.CERTIFICATE);
			this.steps.push(Steps.SERVICE);
			this.steps.push(Steps.DELIVERY);
			this.steps.push(Steps.SIGNATURE_AND_PHOTO);
			this.steps.push(Steps.SIGNING);
			this.steps.push(Steps.PAYMENT);
		} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_EXAM) {
			this.steps.push(Steps.PERSONAL_INFO);
			this.steps.push(Steps.CORRESPONDENCE);
			this.steps.push(Steps.ADR_EXAM_PEOPLE);
			this.steps.push(Steps.EXAM_ORG_UNIT_SELECTION);
			this.steps.push(Steps.EXAM_PROTOCOL_SELECTION);
			this.steps.push(Steps.PAYMENT);
		} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_CONSULTANT_EXAM) {
			this.steps.push(Steps.PERSONAL_INFO);
			this.steps.push(Steps.CORRESPONDENCE);
			this.steps.push(Steps.ADR_EXAM_SERVICE_OPTIONS);
			this.steps.push(Steps.ADR_EXAM_PEOPLE);
			// this.steps.push(Steps.EXAM_ORG_UNIT_SELECTION);
			this.steps.push(Steps.EXAM_PROTOCOL_SELECTION);
			this.steps.push(Steps.PAYMENT);
		} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_MOTOR_EXAM) {
			this.steps.push(Steps.PERSONAL_INFO);
			this.steps.push(Steps.CORRESPONDENCE);
			this.steps.push(Steps.EXAM_CATEGORY_SELECTION);
			this.steps.push(Steps.EXAM_PROTOCOL_SELECTION);
			this.steps.push(Steps.PAYMENT);
		} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_TAXI_EXAM) {
			this.steps.push(Steps.PERSONAL_INFO);
			this.steps.push(Steps.CORRESPONDENCE);
			this.steps.push(Steps.DRIVING_LICENCE);
			this.steps.push(Steps.EXAM_MUNICIPALITY_SELECTION);
			this.steps.push(Steps.EXAM_REQUIRED_DOCUMENTS);
			this.steps.push(Steps.EXAM_PROTOCOL_SELECTION);
			this.steps.push(Steps.PAYMENT);
		}
		this.setStepsNumbers();
		this.completeReset();
	}

	setStepsNumbers() {
		this.personalInfoNum = this.steps.indexOf(Steps.PERSONAL_INFO) + 1;
		this.correspondenceNum = this.steps.indexOf(Steps.CORRESPONDENCE) + 1;
		this.drivingLicenceNum = this.steps.indexOf(Steps.DRIVING_LICENCE) + 1;
		this.certificateNum = this.steps.indexOf(Steps.CERTIFICATE) + 1;
		this.serviceNum = this.steps.indexOf(Steps.SERVICE) + 1;
		this.deliveryNum = this.steps.indexOf(Steps.DELIVERY) + 1;
		this.signatureAndPhotoNum = this.steps.indexOf(Steps.SIGNATURE_AND_PHOTO) + 1;
		this.signingNum = this.steps.indexOf(Steps.SIGNING) + 1;
		this.adrExamServiceOptionsNum = this.steps.indexOf(Steps.ADR_EXAM_SERVICE_OPTIONS) + 1;
		this.adrExamPeopleNum = this.steps.indexOf(Steps.ADR_EXAM_PEOPLE) + 1;
		this.examOrgUnitSelectionNum = this.steps.indexOf(Steps.EXAM_ORG_UNIT_SELECTION) + 1;
		this.examProtocolSelectionNum = this.steps.indexOf(Steps.EXAM_PROTOCOL_SELECTION) + 1;
		this.examMunicipalitySelectionNum = this.steps.indexOf(Steps.EXAM_MUNICIPALITY_SELECTION) + 1;
		this.examRequiredDocumentsNum = this.steps.indexOf(Steps.EXAM_REQUIRED_DOCUMENTS) + 1;
		this.examCategorySelectionNum = this.steps.indexOf(Steps.EXAM_CATEGORY_SELECTION) + 1;
		this.paymentNum = this.steps.indexOf(Steps.PAYMENT) + 1;

		// if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_EXAM) {
		// 	this.adrExamAvailableModulesNum = 3;
		// } else {
		// 	this.drivingLicenceNum = 3;
		// 	if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_DQC
		// 		|| this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_CARD) {
		// 		this.certificateNum = 4;
		// 		this.serviceNum = 5;
		// 		this.deliveryNum = 6;
		// 		this.signatureAndPhotoNum = 7;
		// 		this.signingNum = 8;
		// 		this.paymentNum = 9;
		// 	} else {
		// 		this.serviceNum = 4;
		// 		this.deliveryNum = 5;
		// 		this.signatureAndPhotoNum = 6;
		// 		this.signingNum = 7;
		// 		this.paymentNum = 8;
		// 	}
		// }
	}

	completeReset() {
		this.isPersonalInfoCurrent = false;
		this.isCorrespondenceCurrent = false;
		this.isDlCurrent = false;
		this.isCertificateCurrent = false;
		this.isServiceCurrent = false;
		this.isDeliveryCurrent = false;
		this.isSignatureAndPhotoCurrent = false;
		this.isSigningCurrent = false;
		this.isPaymentCurrent = false;


		this.isAdrExamServiceOptionsCurrent = false;
		this.isAdrExamPeopleCurrent = false;
		this.isOrgUnitSelectionCurrent = false;
		this.isExamProtocolSelectionCurrent = false;

		this.canSeeCorrespondence = false;
		this.canSeeDL = false;
		this.canSeeCertificate = false;
		this.canSeeService = false;
		this.canSeeDelivery = false;
		this.canSeeSignatureAndPhoto = false;
		this.canSeeSigning = false;
		this.canSeePayment = false;

		this.canSeeAdrExamServiceOptions = false;
		this.canSeeAdrExamPeople = false;
		this.canSeeOrgUnitSelection = false;
		this.canSeeExamProtocolSelection = false;
		this.canSeeExamMunicipalitySelection = false;
		this.canSeeExamRequiredDocuments = false;
		this.canSeeExamCategorySelection = false;

		this.passedSteps = [];
	}

	scrollToStep(step: Steps) {
		this.resetCurrent();
		const currentStepIndex = this.steps.indexOf(step);

		switch (step) {
			case Steps.PERSONAL_INFO:
				this.isPersonalInfoCurrent = true;
				this.personalInfoEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			case Steps.CORRESPONDENCE:
				if (!this.canSeeCorrespondence) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				this.savePassedStep(Steps.PERSONAL_INFO);
				this.isCorrespondenceCurrent = true;
				this.correspondenceEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			case Steps.DRIVING_LICENCE:
				if (!this.canSeeDL) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				if (currentStepIndex > 0) {
					this.savePassedStep(this.steps[currentStepIndex - 1]);
				}
				this.isDlCurrent = true;
				this.drivingLicenceEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			case Steps.CERTIFICATE:
				if (!this.canSeeCertificate) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				if (currentStepIndex > 0) {
					this.savePassedStep(this.steps[currentStepIndex - 1]);
				}
				this.isCertificateCurrent = true;
				this.certificateEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			case Steps.SERVICE:
				if (!this.canSeeService) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				if (currentStepIndex > 0) {
					this.savePassedStep(this.steps[currentStepIndex - 1]);
				}
				this.isServiceCurrent = true;
				this.serviceOptionEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			case Steps.DELIVERY:
				if (!this.canSeeDelivery) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				if (currentStepIndex > 0) {
					this.savePassedStep(this.steps[currentStepIndex - 1]);
				}
				this.isDeliveryCurrent = true;
				this.deliveryEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			case Steps.SIGNATURE_AND_PHOTO:
				if (!this.canSeeSignatureAndPhoto) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				if (currentStepIndex > 0) {
					this.savePassedStep(this.steps[currentStepIndex - 1]);
				}
				this.isSignatureAndPhotoCurrent = true;
				this.signatureAndPhotoEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			case Steps.SIGNING:
				if (!this.canSeeSigning) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				if (currentStepIndex > 0) {
					this.savePassedStep(this.steps[currentStepIndex - 1]);
				}
				this.isSigningCurrent = true;
				this.signingEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			case Steps.PAYMENT:
				if (!this.canSeePayment) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				if (currentStepIndex > 0) {
					this.savePassedStep(this.steps[currentStepIndex - 1]);
				}
				this.isPaymentCurrent = true;
				this.paymentEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;

			case Steps.ADR_EXAM_SERVICE_OPTIONS:
				if (!this.canSeeAdrExamServiceOptions) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				if (currentStepIndex > 0) {
					this.savePassedStep(this.steps[currentStepIndex - 1]);
				}
				this.isAdrExamServiceOptionsCurrent = true;
				this.adrExamServiceOptionsEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			case Steps.ADR_EXAM_PEOPLE:
				if (!this.canSeeAdrExamPeople) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				if (currentStepIndex > 0) {
					this.savePassedStep(this.steps[currentStepIndex - 1]);
				}
				this.isAdrExamPeopleCurrent = true;
				this.adrExamPeopleEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			case Steps.EXAM_ORG_UNIT_SELECTION:
				if (!this.canSeeOrgUnitSelection) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				if (currentStepIndex > 0) {
					this.savePassedStep(this.steps[currentStepIndex - 1]);
				}
				this.canSeeOrgUnitSelection = true;
				this.examOrgUnitSelectionEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			case Steps.EXAM_PROTOCOL_SELECTION:
				if (!this.canSeeExamProtocolSelection) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				if (currentStepIndex > 0) {
					this.savePassedStep(this.steps[currentStepIndex - 1]);
				}
				this.isExamProtocolSelectionCurrent = true;
				this.canSeeExamProtocolSelection = true;
				this.examProtocolSelectionEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			case Steps.EXAM_MUNICIPALITY_SELECTION:
				if (!this.canSeeExamMunicipalitySelection) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				this.isMunicipalityCurrent = true;
				this.canSeeExamMunicipalitySelection = true;
				this.examMunicipalitySelectionEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			case Steps.EXAM_REQUIRED_DOCUMENTS:
				if (!this.canSeeExamRequiredDocuments) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				if (currentStepIndex > 0) {
					this.savePassedStep(this.steps[currentStepIndex - 1]);
				}
				this.canSeeExamRequiredDocuments = true;
				this.isExamDocumentsCurrent = true;
				this.examRequiredDocumentsEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			case Steps.EXAM_CATEGORY_SELECTION:
				if (!this.canSeeExamCategorySelection) {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_section_locked);
					break;
				}
				if (currentStepIndex > 0) {
					this.savePassedStep(this.steps[currentStepIndex - 1]);
				}
				this.isExamCategorySelectionCurrent = true;
				this.examCategorySelectionEl.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
				break;
			default:
				this.savePassedStep(Steps.PAYMENT);
				break;
		}
	}

	continueToNextStepFromCurrent(currentStep: Steps) {
		const currentStepIndex = this.steps.indexOf(currentStep);
		const nextStepIndex = currentStepIndex + 1;
		let nextStep = null;
		if (nextStepIndex < this.steps.length) {
			nextStep = this.steps[nextStepIndex];
		}
		this.savePassedStep(currentStep);

		switch (nextStep) {
			// case Steps.PERSONAL_INFO:
			// 	//this.canSeeCorrespondence = true;
			// 	break;
			case Steps.CORRESPONDENCE:
				// if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_EXAM) {
				// 	this.canSeeAdrExamPeople = true;
				// } else {
				// 	this.canSeeDL = true;
				// }
				this.canSeeCorrespondence = true;
				break;
			case Steps.DRIVING_LICENCE:
				// if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_TACHO_CARD) {
				// 	this.canSeeService = true;
				// 	break;
				// }
				// this.canSeeCertificate = true;
				this.canSeeDL = true;
				break;
			case Steps.CERTIFICATE:
				this.canSeeCertificate = true;
				break;
			case Steps.SERVICE:
				this.canSeeService = true;
				break;
			case Steps.DELIVERY:
				this.canSeeDelivery = true;
				break;
			case Steps.SIGNATURE_AND_PHOTO:
				this.canSeeSignatureAndPhoto = true;
				break;
			case Steps.SIGNING:
				this.canSeeSigning = true;
				break;
			case Steps.ADR_EXAM_SERVICE_OPTIONS:
				this.canSeeAdrExamServiceOptions = true;
				break;
			case Steps.ADR_EXAM_PEOPLE:
				this.canSeeAdrExamPeople = true;
				break;
			case Steps.EXAM_ORG_UNIT_SELECTION:
				this.canSeeOrgUnitSelection = true;
				break;
			case Steps.EXAM_PROTOCOL_SELECTION:
				this.canSeeExamProtocolSelection = true;
				break;
			case Steps.EXAM_MUNICIPALITY_SELECTION:
				this.canSeeExamMunicipalitySelection = true;
				break;
			case Steps.EXAM_REQUIRED_DOCUMENTS:
				this.canSeeExamRequiredDocuments = true;
				break;
			case Steps.EXAM_CATEGORY_SELECTION:
				this.canSeeExamCategorySelection = true;
				break;
			case Steps.PAYMENT:
				this.canSeePayment = true;
				break;
			default:
				console.error('next step not handled.', nextStep);
				break;
		}
	}

	private resetCurrent() {
		this.isPersonalInfoCurrent = false;
		this.isCorrespondenceCurrent = false;
		this.isDlCurrent = false;
		this.isCertificateCurrent = false;
		this.isServiceCurrent = false;
		this.isDeliveryCurrent = false;
		this.isSignatureAndPhotoCurrent = false;
		this.isSigningCurrent = false;
		this.isPaymentCurrent = false;

		this.isAdrExamServiceOptionsCurrent = false;
		this.isAdrExamPeopleCurrent = false;
		this.isOrgUnitSelectionCurrent = false;
		this.isExamProtocolSelectionCurrent = false;
		this.isMunicipalityCurrent = false;
		this.isExamDocumentsCurrent = false;
	}

	private savePassedStep(passedStep: Steps) {
		if (!this.passedSteps.includes(passedStep)) {
			this.passedSteps.push(passedStep);
			this.applicationProgress.next(this.passedSteps.length * this.oneStepSize);
		}
	}

	setDefaultPassedStepsForSubmittedApplication() {
		this.canSeeCorrespondence = true;
		this.canSeeDL = true;
		this.canSeeCertificate = true;
		this.canSeeService = true;
		this.canSeeDelivery = true;
		this.canSeeSignatureAndPhoto = true;
		this.canSeeSigning = true;
		this.canSeePayment = true;

		if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_EXAM) {
			this.canSeeAdrExamPeople = true;
			this.canSeeOrgUnitSelection = true;
			this.canSeeExamProtocolSelection = true;

			this.savePassedStep(Steps.PERSONAL_INFO);
			this.savePassedStep(Steps.CORRESPONDENCE);
			this.savePassedStep(Steps.ADR_EXAM_PEOPLE);
			this.savePassedStep(Steps.EXAM_ORG_UNIT_SELECTION);
			this.savePassedStep(Steps.EXAM_PROTOCOL_SELECTION);
		} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_CONSULTANT_EXAM) {
			this.canSeeAdrExamServiceOptions = true;
			this.canSeeAdrExamPeople = true;
			this.canSeeExamProtocolSelection = true;

			this.savePassedStep(Steps.PERSONAL_INFO);
			this.savePassedStep(Steps.CORRESPONDENCE);
			this.savePassedStep(Steps.ADR_EXAM_SERVICE_OPTIONS);
			this.savePassedStep(Steps.ADR_EXAM_PEOPLE);
			this.savePassedStep(Steps.EXAM_PROTOCOL_SELECTION);
		} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_TAXI_EXAM) {
			this.savePassedStep(Steps.PERSONAL_INFO);
			this.savePassedStep(Steps.CORRESPONDENCE);
			this.savePassedStep(Steps.DRIVING_LICENCE);
			this.savePassedStep(Steps.EXAM_MUNICIPALITY_SELECTION);
			this.savePassedStep(Steps.EXAM_REQUIRED_DOCUMENTS);
			this.savePassedStep(Steps.EXAM_PROTOCOL_SELECTION);
		} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_MOTOR_EXAM) {
			this.canSeeExamCategorySelection = true;
			this.canSeeExamProtocolSelection = true;

			this.savePassedStep(Steps.PERSONAL_INFO);
			this.savePassedStep(Steps.CORRESPONDENCE);
			this.savePassedStep(Steps.EXAM_CATEGORY_SELECTION);
			this.savePassedStep(Steps.EXAM_PROTOCOL_SELECTION);
		}
	}

	public checkIfIsEditingAndSet(currentStepToEdit: Steps) {
		if (this.isEditing !== Steps.EMPTY_STEP && this.isEditing !== currentStepToEdit) {
			this.scrollToStep(this.isEditing);
			PopUpService.showPopUp(DEFAULT_POP_UPS.warning_finish_current_changes);
			return true;
		} else {
			this.isEditing = currentStepToEdit;
			return false;
		}
	}

	public setIsEditingToEmptyStep() {
		this.isEditing = Steps.EMPTY_STEP;
	}
}
