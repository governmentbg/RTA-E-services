import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { ApplicationTypeIdDto } from '../../shared/dtos/application-type-id-dto';
import { ApplicationDto } from '../../shared/interfaces/application-dto';
import { ApplicationLightDto } from 'src/app/shared/interfaces/application-light-dto';
import { PageResultDto } from 'src/app/shared/interfaces/page-result-dto';
import { ApplicantContactDetailsDto } from 'src/app/shared/interfaces/applicant-contact-details-dto';
import { DeliveryInfoDto } from 'src/app/shared/dtos/delivery-info-dto';
import { ApplicationSearchParams } from 'src/app/shared/models/application-query-params';
import { Utils } from '../../shared/utils/utils';
import { ChosenCorrespondenceDto } from 'src/app/shared/dtos/chosen-correspondence-dto';
import { CardDto } from 'src/app/shared/dtos/card-dto';
import { SubHeaderApplicationInfo } from 'src/app/shared/models/sub-header-application-info';
import { ApplicationDraftDto } from 'src/app/shared/interfaces/application-draft-dto';
import { ApplicationShortDto } from 'src/app/shared/interfaces/application-short-dto';
import { PaginationParams } from 'src/app/shared/pagination/pagination-params';
import { APPLICATION_STATUSES } from 'src/app/shared/enums/application-statuses';
import { OldCardDto } from 'src/app/shared/dtos/old-card-dto';
import { ContactViewDto } from 'src/app/shared/interfaces/contact-view-dto';
import { CardViewDto } from 'src/app/shared/interfaces/card-dto';
import { RemarkDto } from 'src/app/shared/dtos/remark-dto';
import { ApplicationRemarkViewDto } from 'src/app/shared/interfaces/application-remark-view-dto';

const BASE_URL = 'api/applications';

@Injectable()
export class ApplicationService {
	private $subHeaderApplicationInfo = new Subject<SubHeaderApplicationInfo>();
	public subHeaderApplicationInfo = this.$subHeaderApplicationInfo.asObservable();

	constructor(
		private readonly http: HttpClient,
		private readonly utils: Utils
	) { }

	public checkIfApplicationOfSameTypeAlreadyInProgress(applicationType: number) {
		return this.http.get<boolean>(BASE_URL + `/type/${applicationType}/in-progress`);
	}

	public createApplicationInDb(applicationTypeId: ApplicationTypeIdDto): Observable<number> {
		return this.http.post<number>(BASE_URL, applicationTypeId);
	}

	public getApplicationsShort(): Observable<ApplicationShortDto[]> {
		return this.http.get<ApplicationShortDto[]>(BASE_URL + '/created');
	}

	public getApplication(applicationId: number): Observable<ApplicationDto> {
		return this.http.get<ApplicationDto>(`${BASE_URL}/${applicationId}`);
	}

	public getApplicationDraft(applicationId: number): Observable<ApplicationDraftDto> {
		return this.http.get<ApplicationDraftDto>(`${BASE_URL}/${applicationId}/draft`);
	}

	public getApplicationPage(pageParams: PaginationParams, searchParams: ApplicationSearchParams)
		: Observable<PageResultDto<ApplicationLightDto>> {
		const params = this.utils.toHttpParamsWithDate(pageParams, searchParams);
		return this.http.get<PageResultDto<ApplicationLightDto>>(BASE_URL, { params });
	}

	public getApplicantContactDetails(applicationId: number): Observable<ApplicantContactDetailsDto> {
		return this.http.get<ApplicantContactDetailsDto>(`${BASE_URL}/${applicationId}/contact-details`);
	}

	public saveDeliveryInfo(applicationId: number, dto: DeliveryInfoDto): Observable<DeliveryInfoDto> {
		return this.http.put<DeliveryInfoDto>(`${BASE_URL}/${applicationId}/delivery`, dto);
	}

	public setCorrespondenceContact(applicationId: number, dto: ChosenCorrespondenceDto): Observable<ContactViewDto> {
		return this.http.put<ContactViewDto>(`${BASE_URL}/${applicationId}/correspondence`, dto);
	}

	public submitApplication(applicationId: number): Observable<HttpEvent<{}>> {
		return this.http.put<HttpEvent<{}>>(`${BASE_URL}/${applicationId}/submit`, null);
	}

	public getCardInfoFromService(applicationId: number): Observable<OldCardDto> {
		return this.http.get<OldCardDto>(`${BASE_URL}/${applicationId}/card-check`);
	}

	public getCardInfoFromServiceForApprover(applicationId: number): Observable<OldCardDto> {
		return this.http.get<OldCardDto>(`${BASE_URL}/${applicationId}/approver/card-check`);
	}

	public saveCardInfo(applicationId: number, dto: CardDto): Observable<CardViewDto> {
		return this.http.post<CardViewDto>(`${BASE_URL}/${applicationId}/card-renewal`, dto);
	}

	public cancelApplication(applicationId: number): Observable<void> {
		return this.http.put<void>(`${BASE_URL}/${applicationId}/cancel`, null);
	}

	public deleteApplication(applicationId: number): Observable<HttpEvent<{}>> {
		return this.http.delete<HttpEvent<{}>>(`${BASE_URL}/${applicationId}/delete`);
	}

	public returnApplication(applicationId: number): Observable<void> {
		return this.http.put<void>(`${BASE_URL}/${applicationId}/return`, null);
	}

	public deliveredPersonallyCardApplication(applicationId: number): Observable<void> {
		return this.http.put<void>(`${BASE_URL}/${applicationId}/deliver-client`, null);
	}

	public addRemark(applicationId: number, dto: RemarkDto): Observable<ApplicationRemarkViewDto[]> {
		return this.http.post<ApplicationRemarkViewDto[]>(`${BASE_URL}/${applicationId}/remark`, dto);
	}

	public rejectApplication(applicationId: number): Observable<void> {
		return this.http.put<void>(`${BASE_URL}/${applicationId}/reject`, null);
	}

	public approveApplication(applicationId: number): Observable<void> {
		return this.http.put<void>(`${BASE_URL}/${applicationId}/approve`, null);
	}

	public checkApplication(applicationId: string, recaptchaResponse: string): Observable<ApplicationShortDto> {
		return this.http.post<ApplicationShortDto>(`${BASE_URL}/check`,
			{ applicationId, reCaptchaResponse: recaptchaResponse });
	}

	public setApplicationInfoForHeader(applicationInfo: SubHeaderApplicationInfo) {
		this.$subHeaderApplicationInfo.next(applicationInfo);
	}

	public setToMilestone(applicationId: number, milestoneId: number): Observable<void> {
		return this.http.post<void>(`${BASE_URL}/${applicationId}/milestone/${milestoneId}`, null);
	}

	public canCancelApplication(applicationStatusId: number): boolean {
		return (applicationStatusId === APPLICATION_STATUSES.DRAFT || applicationStatusId === APPLICATION_STATUSES.SUBMITTED_WAITING_PAYMENT);
	}

	public canUserOpenApplication(applicationStatusId: number): boolean {
		return (applicationStatusId !== APPLICATION_STATUSES.CANCELED_BY_APPLICANT
			&&  applicationStatusId !== APPLICATION_STATUSES.REJECTED_NOT_PAID_ON_TIME
			&& applicationStatusId !== APPLICATION_STATUSES.SUBMITTED_REJECTED_IRREGULARITIES);
	}
}
