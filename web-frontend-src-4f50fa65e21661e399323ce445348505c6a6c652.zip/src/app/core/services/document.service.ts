import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpResponse } from '@angular/common/http';
import { Observable} from 'rxjs';
import { AttachedDocumentShortInfoDto } from 'src/app/shared/dtos/attached-document-short-info-dto';
import { RequiredDocumentTypeDto } from 'src/app/shared/interfaces/required-doc-type-dto';
import { ApplicationIdWrapperDto } from 'src/app/shared/dtos/application-id-wrapper-dto';
import { DocumentsDeclarationDto } from 'src/app/shared/dtos/documents-declaration-dto';
import { Certificate } from 'src/app/shared/models/certificate';
import { Translation } from 'src/app/shared/models/translation';
import { CERTIFICATE_TYPE_ID_TO_ATTACHED_DOCUMENT_TYPE_ID } from 'src/app/shared/models/constants/attached-documents/certificate-type-id';

@Injectable({
	providedIn: 'root'
})
export class DocumentService {

	constructor(private readonly http: HttpClient) { }

	private URL = {DOCUMENTS: 'api/documents'};

	public getRequiredDocumentTypes(applicationId: number): Observable<RequiredDocumentTypeDto[]> {
		return this.http.get<RequiredDocumentTypeDto[]>(this.URL.DOCUMENTS + '/application/' + applicationId + '/required-documents');
	}

	public confirmRequiredDocumentsAreAttached(applicationIdDto: ApplicationIdWrapperDto): Observable<HttpEvent<{}>> {
	return this.http.put<HttpEvent<{}>>(this.URL.DOCUMENTS + '/confirm-attached-documents', applicationIdDto);
	}

	public getDocumentPagesInfo(applicationId: number, documentTypeId: number): Observable<AttachedDocumentShortInfoDto> {
		return this.http.get<AttachedDocumentShortInfoDto>(
			this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId + '/pages-info');
	}

	public getGeneratedCardPdfApplication(applicationId: number): Observable<HttpEvent<any>>  {
		return this.http.get<HttpEvent<any>>(this.URL.DOCUMENTS + '/application/' + applicationId + '/pdf',
			{ responseType: 'blob' as 'json', reportProgress: true,	observe: 'events'});
	}

	public checkCanSubmitApplication(applicationId: number): Observable<boolean> {
		return this.http.get<boolean>(this.URL.DOCUMENTS + '/application/' + applicationId + '/can-submit');
	}

	public checkHaveAllRequiredDocumentToGenerateApplication(applicationId: number): Observable<boolean> {
		return this.http.get<boolean>(this.URL.DOCUMENTS + '/application/' + applicationId + '/check-all');
	}

	public saveDocument(applicationId: number, documentTypeId: number, formData: FormData): Observable<HttpEvent<any>> {
		return this.http.post<HttpEvent<any>>(this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId, formData,
			{reportProgress: true, observe: 'events'});
	}

	public saveOriginalAndGetAutoFixedPicture(applicationId: number, documentTypeId: number, formData: FormData): Observable<HttpEvent<any>> {
		return this.http.post<HttpEvent<any>>(
			this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId + '/auto-fixed', formData,
			{reportProgress: true, responseType: 'arrayBuffer' as 'json' , observe: 'events'});
	}

	public saveEditedPicture(applicationId: number, documentTypeId: number, formData: FormData): Observable<number> {
		return this.http.post<number>(
			this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId + '/edited',
			formData);
	}

	public getEditedPicture(applicationId: number, documentTypeId: number): Observable<HttpResponse<ArrayBuffer>> {
		return this.http.get<ArrayBuffer>(
			this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId + '/edited',
			{responseType: 'arrayBuffer' as 'json' , observe: 'response' });
	}

	public getAutoFixedPictureFromMvrCheck(applicationId: number, documentTypeId: number, formData: FormData): Observable<HttpResponse<ArrayBuffer>> {
		return this.http.post<ArrayBuffer>(
			this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId + '/auto-fixed/approver', formData,
			{responseType: 'arrayBuffer' as 'json' , observe: 'response' });
	}

	public getOriginalPictureOfFaceOrSignature(applicationId: number, documentTypeId: number): Observable<HttpResponse<ArrayBuffer>> {
		return this.http.get<ArrayBuffer>(
			this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId + '/original',
			{responseType: 'arrayBuffer' as 'json' , observe: 'response' });
	}

	public getAutoFixedPicture(applicationId: number, documentTypeId: number): Observable<HttpResponse<ArrayBuffer>> {
		return this.http.get<ArrayBuffer>(
			this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId + '/auto-fixed',
			{responseType: 'arrayBuffer' as 'json' , observe: 'response' });
	}

	public checkHasAutoFixed(applicationId: number, documentTypeId: number): Observable<boolean> {
		return this.http.get<boolean>(this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId + '/auto-fixed-check');
	}

	public hasDocument(applicationId: number, documentTypeId: number): Observable<boolean> {
		return this.http.get<boolean>(this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId + '/check');
	}

	public getDocument(applicationId: number, documentTypeId: number): Observable<HttpResponse<ArrayBuffer>>  {
		return this.http.get<ArrayBuffer>(this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId,
			{ responseType: 'arrayBuffer' as 'json' , observe: 'response' });
	}

	public getDocumentPage(applicationId: number, documentTypeId: number, documentPageId: number): Observable<HttpResponse<ArrayBuffer>>  {
		return this.http.get<ArrayBuffer>(
			this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId + '/page/' + documentPageId,
			{ responseType: 'arrayBuffer' as 'json' , observe: 'response' });
	}

	public getDeskSubjectFacePicture(applicationId: number): Observable<HttpResponse<ArrayBuffer>>  {
		return this.http.get<ArrayBuffer>(
			this.URL.DOCUMENTS + '/application/' + applicationId + '/desk-subject-face',
				{ responseType: 'arrayBuffer' as 'json' , observe: 'response' });
	}

	public removeDocument(applicationId: number, documentTypeId: number): Observable<HttpEvent<{}>> {
		return this.http.delete<HttpEvent<{}>>(this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId);
	}

	public removeDocumentPage(applicationId: number, documentTypeId: number, documentPageId: number): Observable<HttpEvent<{}>> {
		return this.http.delete<HttpEvent<{}>>(
			this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId + '/page/' + documentPageId);
	}

	public declareDocuments(applicationId: number, dto: DocumentsDeclarationDto): Observable<HttpEvent<{}>> {
		return this.http.put<HttpEvent<{}>>(this.URL.DOCUMENTS + '/application/' + applicationId + '/documents-declaration', dto);
	}

	public checkIfDocumentIsDeclared(applicationId: number, documentTypeId: number): Observable<boolean> {
		return this.http.get<boolean>(this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId + '/declared');
	}

	public setDocumentPagesOrder(applicationId: number, documentTypeId: number, pageIdsOrderedByPageNumber: number[])
		: Observable<HttpEvent<{}>>  {
		return this.http.put<HttpEvent<{}>>(this.URL.DOCUMENTS + '/application/' + applicationId + '/document/' + documentTypeId + '/page-order',
			pageIdsOrderedByPageNumber);
	}

	public areRequiredDocumentsAttached(applicationId: number): Observable<boolean> {
		return this.http.get<boolean>(this.URL.DOCUMENTS + '/application/' + applicationId + '/required-documents-attached');
	}

	public getRequiredDocumentTypesForGivenSection(applicationId: number, milestoneId: number): Observable<number[]> {
		return this.http.get<number[]>(
			this.URL.DOCUMENTS + '/application/' + applicationId + '/milestone/' + milestoneId + '/required-documents');
	}

	public checkAllManuallyUploadedCertificatesHasAndFiles(dqcCertificates: Certificate[], attachedDocuments: Translation[]){
		const manuallyUploadedCertificates = dqcCertificates.filter(certificate => certificate.attached === true);
		for (const certificate of manuallyUploadedCertificates) {
			const attachedDocTypeId = CERTIFICATE_TYPE_ID_TO_ATTACHED_DOCUMENT_TYPE_ID[certificate.typeId];
			const attachedDocType = attachedDocuments.find(doc => doc.id === attachedDocTypeId);
			if (!attachedDocType) {
				return false;
			}
		}
		return true;
	}
}
