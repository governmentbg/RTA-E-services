import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CertificateDto } from 'src/app/shared/dtos/certificate-dto';
import { ApplicationIdWrapperDto } from 'src/app/shared/dtos/application-id-wrapper-dto';
import { SimpleCertificateDto } from 'src/app/shared/dtos/simple-certificate-dto';
import { DqcCardDto } from 'src/app/shared/dtos/dqc-card-dto';

const BASE_URL = 'api/dqc';

@Injectable({
	providedIn: 'root'
})
export class DqcService {

	constructor(private http: HttpClient) { }

	public getCertificates(applicationId: number): Observable<CertificateDto[]> {
		return this.http.get<CertificateDto[]>(`${BASE_URL}/application/${applicationId}/certificates`);
	}

	public getAllCertificatesReadOnly(applicationId:number): Observable<SimpleCertificateDto[]> {
		return this.http.get<SimpleCertificateDto[]>(`${BASE_URL}/application/${applicationId}/all-certificates`);
	}

	public getAllCardsReadOnly(applicationId: number): Observable<DqcCardDto[]> {
		return this.http.get<DqcCardDto[]>(`${BASE_URL}/application/${applicationId}/all-cards`);
	}

	public getCertificateForApprover(applicationId: number): Observable<CertificateDto[]> {
		return this.http.get<CertificateDto[]>(`${BASE_URL}/application/${applicationId}/approver/certificates`);
	}

	public saveCertificate(applicationId: number, dto: CertificateDto): Observable<void> {
		return this.http.post<void>(`${BASE_URL}/application/${applicationId}/certificate`, dto);
	}

	public deleteCertificate(applicationId: number, typeId: number): Observable<void> {
		return this.http.delete<void>(`${BASE_URL}/application/${applicationId}/certificate/${typeId}`);
	}

	public saveTransitionForSelectedCertificates(applicationIdDto: ApplicationIdWrapperDto): Observable<CertificateDto[]> {
		return this.http.post<CertificateDto[]>(`${BASE_URL}/certificates/transition`, applicationIdDto);
	}
}
