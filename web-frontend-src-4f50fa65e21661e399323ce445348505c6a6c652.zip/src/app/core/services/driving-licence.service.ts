import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { RequestMvrDto } from 'src/app/shared/dtos/request-mvr-dto';
import { DrivingLicenceDto } from 'src/app/shared/dtos/driving-licence-dto';
import { DrivingLicenceViewDto } from 'src/app/shared/interfaces/driving-licence-view-dto';

@Injectable({
	providedIn: 'root'
})
export class DrivingLicenceService {

	private URL = {
		DRIVING_LICENCE: 'api/driving-licences'
	};

	constructor(private http: HttpClient) { }

	public getMvrDLInfo(requestMvrDto: RequestMvrDto): Observable<DrivingLicenceViewDto> {
		return this.http.post<DrivingLicenceViewDto>(`${this.URL.DRIVING_LICENCE}/mvr-info`, requestMvrDto);
	}

	public getMvrDLInfoForApprover(requestMvrDto: RequestMvrDto): Observable<DrivingLicenceViewDto> {
		return this.http.post<DrivingLicenceViewDto>(`${this.URL.DRIVING_LICENCE}/approver/mvr-info`, requestMvrDto);
	}

	public saveDrivingLicenceInfo(drivingLicence: DrivingLicenceDto): Observable<DrivingLicenceViewDto> {
		return this.http.post<DrivingLicenceViewDto>(this.URL.DRIVING_LICENCE, drivingLicence);
	}
}
