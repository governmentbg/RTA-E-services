import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EmailWrapperDto } from 'src/app/shared/dtos/email-wrapper-dto';
import { Observable } from 'rxjs';
import { VerificationTokenWrapperDto } from 'src/app/shared/dtos/verification-token-wrapper-dto';

const BASE_URL = 'api/emails';

@Injectable({
	providedIn: 'root'
})
export class EmailService {

	constructor(private http: HttpClient) { }

	public sendVerificationToken(emailDto: EmailWrapperDto): Observable<void> {
		return this.http.post<void>(BASE_URL + '/token', emailDto);
	}

	public enterVerificationToken(token: VerificationTokenWrapperDto): Observable<void> {
		return this.http.put<void>(BASE_URL + '/verify', token);
	}

	public getCurrentUserEmail(): Observable<string> {
		const headers = new HttpHeaders().set('Content-Type', 'text/plain; charset=utf-8');
		return this.http.get(BASE_URL + '/current', {headers, responseType: 'text'});
	}
}
