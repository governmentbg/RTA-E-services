import { Injectable } from '@angular/core';
import { PersonalInfo } from 'src/app/shared/models/personal-info';
import { DrivingLicenceView } from 'src/app/shared/models/driving-licence-view';
import { Category } from 'src/app/shared/models/category';
import { Certificate } from 'src/app/shared/models/certificate';
import { AdrModule } from 'src/app/shared/models/adr-module';
import { OldCard } from 'src/app/shared/models/old-card';
@Injectable({
	providedIn: 'root'
})
export class ErrorCheckerService {

	personalInfo: PersonalInfo;
	dbDrivingLicence: DrivingLicenceView;
	certificatesFromCheck: Certificate[];
	modules: AdrModule[];
	oldCard: OldCard;

	moduleTypeBasicId = 1;

	public setHasErrorsAndCountDifferencesInPersonalInfo(personalInfo: PersonalInfo, personalInfoFromCheck: PersonalInfo): PersonalInfo {
		let differences = 0;
		this.personalInfo = personalInfo;

		if (personalInfo?.identityNumber !== personalInfoFromCheck?.identityNumber) {
			differences++;
			this.personalInfo.identityNumberError = true;
		}
		if (personalInfo?.documentNumber !== personalInfoFromCheck?.documentNumber) {
			differences++;
			this.personalInfo.documentNumberError = true;
		}
		if (personalInfo?.dateOfExpiry.getTime() !== personalInfoFromCheck?.dateOfExpiry.getTime()) {
			differences++;
			this.personalInfo.dateOfExpiryError = true;
		}
		if (personalInfo?.dateOfIssue.getTime() !== personalInfoFromCheck?.dateOfIssue.getTime()) {
			differences++;
			this.personalInfo.dateOfIssueError = true;
		}
		if (personalInfo?.dateOfBirth.getTime() !== personalInfoFromCheck?.dateOfBirth.getTime()) {
			differences++;
			this.personalInfo.dateOfBirthError = true;
		}
		if (personalInfo?.nationality?.key !== personalInfoFromCheck?.nationality?.key) {
			differences++;
			this.personalInfo.nationalityError = true;
		}
		if (personalInfo?.gender?.key !== personalInfoFromCheck?.gender?.key) {
			differences++;
			this.personalInfo.genderError = true;
		}
		if (personalInfo?.documentIssuer?.key !== personalInfoFromCheck?.documentIssuer?.key) {
			differences++;
			this.personalInfo.documentIssuerError = true;
		}
		// names
		if (personalInfo?.personalNames?.firstNameCyr !== personalInfoFromCheck?.personalNames?.firstNameCyr) {
			differences++;
			this.personalInfo.personalNames.firstNameCyrError = true;
		}
		if (personalInfo?.personalNames?.fatherNameCyr !== personalInfoFromCheck?.personalNames?.fatherNameCyr) {
			differences++;
			this.personalInfo.personalNames.fatherNameCyrError = true;
		}
		if (personalInfo?.personalNames?.familyNameCyr !== personalInfoFromCheck?.personalNames?.familyNameCyr) {
			differences++;
			this.personalInfo.personalNames.familyNameCyrError = true;
		}
		if (personalInfo?.personalNames?.firstNameLat !== personalInfoFromCheck?.personalNames?.firstNameLat) {
			differences++;
			this.personalInfo.personalNames.firstNameLatError = true;
		}
		if (personalInfo?.personalNames?.fatherNameLat !== personalInfoFromCheck?.personalNames?.fatherNameLat) {
			differences++;
			this.personalInfo.personalNames.fatherNameLatError = true;
		}
		if (personalInfo?.personalNames?.familyNameLat !== personalInfoFromCheck?.personalNames?.familyNameLat) {
			differences++;
			this.personalInfo.personalNames.familyNameLatError = true;
		}
		// permanent address
		if (personalInfo?.permanentAddress?.region?.key !== personalInfoFromCheck?.permanentAddress?.region?.key) {
			differences++;
			this.personalInfo.permanentAddress.regionError = true;
		}
		if (personalInfo?.permanentAddress?.municipality?.key !== personalInfoFromCheck?.permanentAddress?.municipality?.key) {
			differences++;
			this.personalInfo.permanentAddress.municipalityError = true;
		}
		if (personalInfo?.permanentAddress?.city?.key !== personalInfoFromCheck?.permanentAddress?.city?.key) {
			differences++;
			this.personalInfo.permanentAddress.cityError = true;
		}
		if (personalInfo?.permanentAddress?.postalCode !== personalInfoFromCheck?.permanentAddress?.postalCode) {
			differences++;
			this.personalInfo.permanentAddress.postalCodeError = true;
		}
		if (personalInfo?.permanentAddress?.street !== personalInfoFromCheck?.permanentAddress?.street) {
			differences++;
			this.personalInfo.permanentAddress.streetError = true;
		}
		if (personalInfo?.permanentAddress?.streetNumber !== personalInfoFromCheck?.permanentAddress?.streetNumber) {
			differences++;
			this.personalInfo.permanentAddress.streetNumberError = true;
		}
		if (personalInfo?.permanentAddress?.building !== personalInfoFromCheck?.permanentAddress?.building) {
			differences++;
			this.personalInfo.permanentAddress.buildingError = true;
		}
		if (personalInfo?.permanentAddress?.entrance !== personalInfoFromCheck?.permanentAddress?.entrance) {
			differences++;
			this.personalInfo.permanentAddress.entranceError = true;
		}
		if (personalInfo?.permanentAddress?.apartment !== personalInfoFromCheck?.permanentAddress?.apartment) {
			differences++;
			this.personalInfo.permanentAddress.apartmentError = true;
		}
		// current address
		if (personalInfo?.currentAddress?.country?.key !== personalInfoFromCheck?.currentAddress?.country?.key) {
			differences++;
			this.personalInfo.currentAddress.countryError = true;
		}
		if (personalInfo?.currentAddress?.region?.key !== personalInfoFromCheck?.currentAddress?.region?.key) {
			differences++;
			this.personalInfo.currentAddress.regionError = true;
		}
		if (personalInfo?.currentAddress?.municipality?.key !== personalInfoFromCheck?.currentAddress?.municipality?.key) {
			differences++;
			this.personalInfo.currentAddress.municipalityError = true;
		}
		if (personalInfo?.currentAddress?.city?.key !== personalInfoFromCheck?.currentAddress?.city?.key) {
			differences++;
			this.personalInfo.currentAddress.cityError = true;
		}
		if (personalInfo?.currentAddress?.postalCode !== personalInfoFromCheck?.currentAddress?.postalCode) {
			differences++;
			this.personalInfo.currentAddress.postalCodeError = true;
		}
		if (personalInfo?.currentAddress?.street !== personalInfoFromCheck?.currentAddress?.street) {
			differences++;
			this.personalInfo.currentAddress.streetError = true;
		}
		if (personalInfo?.currentAddress?.streetNumber !== personalInfoFromCheck?.currentAddress?.streetNumber) {
			differences++;
			this.personalInfo.currentAddress.streetNumberError = true;
		}
		if (personalInfo?.currentAddress?.building !== personalInfoFromCheck?.currentAddress?.building) {
			differences++;
			this.personalInfo.currentAddress.buildingError = true;
		}
		if (personalInfo?.currentAddress?.entrance !== personalInfoFromCheck?.currentAddress?.entrance) {
			differences++;
			this.personalInfo.currentAddress.entranceError = true;
		}
		if (personalInfo?.currentAddress?.apartment !== personalInfoFromCheck?.currentAddress?.apartment) {
			differences++;
			this.personalInfo.currentAddress.apartmentError = true;
		}

		this.personalInfo.differences = differences;
		return this.personalInfo;
	}

	setHasErrorsAndCountDifferencesInDrivingLicence(
		dlInfo: DrivingLicenceView, dlInfoFromCheck: DrivingLicenceView, categoriesSameAsUsers: Category[]) {
		let differences = 0;
		this.dbDrivingLicence = dlInfo;

		if (dlInfo?.issuedOn.getTime() !== dlInfoFromCheck?.issuedOn.getTime()) {
			differences++;
			this.dbDrivingLicence.issuedOnError = true;
		}
		if (dlInfo?.documentNumber !== dlInfoFromCheck?.documentNumber) {
			differences++;
			this.dbDrivingLicence.documentNumberError = true;
		}
		if (dlInfo?.issuedBy?.key !== dlInfoFromCheck?.issuedBy?.key) {
			differences++;
			this.dbDrivingLicence.issuedByError = true;
		}
		if (dlInfo?.validity.getTime() !== dlInfoFromCheck?.validity.getTime()) {
			differences++;
			this.dbDrivingLicence.validityError = true;
		}
		for (let i = 0; i < dlInfo.categories.length - 1 ; i++) {
			if (dlInfo?.categories[i].acquisitionDate.getTime() !== categoriesSameAsUsers[i]?.acquisitionDate.getTime()) {
				differences++;
				this.dbDrivingLicence.categories[i].acquisitionDateError = true;
			}
		}

		this.dbDrivingLicence.differences = differences;
		return this.dbDrivingLicence;
	}

	setHasErrorsInCertificates(certificates: Certificate[], certificatesFromCheck: Certificate[]): Certificate[] {
		// сравняваме сертификати от еднакъв тип - пътници с пътници, товари с товари 
		this.certificatesFromCheck = certificatesFromCheck;

		for (let i = 0; i < certificates.length; i++) {
			for (let j = 0; j < certificatesFromCheck.length; j++) {
				if (certificates[i]?.typeId === certificatesFromCheck[j]?.typeId) {
					certificatesFromCheck[j] = this.setErrorsInCertificateFromCheck(certificates[i], certificatesFromCheck[j])
				}
			}
		}

		return this.certificatesFromCheck;
	}


	setErrorsInCertificateFromCheck(currentCertificate: Certificate, certificateFromCheck: Certificate): Certificate {
		if (currentCertificate?.permitNumber !== certificateFromCheck?.permitNumber) {
			certificateFromCheck.permitNumberError = true;
		}
		if (currentCertificate?.certificateNumber !== certificateFromCheck?.certificateNumber) {
			certificateFromCheck.certificateNumberError = true;
		}
		if (currentCertificate?.legalBasisType !== certificateFromCheck?.legalBasisType) {
			certificateFromCheck.legalBasisTypeError = true;
		}
		if (currentCertificate?.issuedOn.getTime() !== certificateFromCheck?.issuedOn.getTime()) {
			certificateFromCheck.issuedOnError = true;
		}
		if ((currentCertificate?.trainingEnd.getTime() !== certificateFromCheck?.trainingEnd.getTime())
			|| (currentCertificate?.trainingStart.getTime() !== certificateFromCheck?.trainingStart.getTime()) ) {
			certificateFromCheck.trainingError = true;
		}

		return certificateFromCheck;
	}

	countDifferencesInCertificates(certificates: Certificate[], certificatesFromCheck: Certificate[]): number {
		let differences = certificates.length;

		for (let i = 0; i < certificates.length; i++) {
			for (let j = 0; j < certificatesFromCheck.length; j++) {
				if (Certificate.areEqualForApprover(certificates[i], certificatesFromCheck[j])) {
					differences--;
				}
			}
		}
		return differences;
	}

	setHasErrorsInModules(modules: AdrModule[], modulesFromCheck: AdrModule[]): AdrModule[] {
		this.modules = modules;

		const validDateTimeFromCheck = new Date(modulesFromCheck[0]?.validTo).getTime();
		const basicModuleUploaded = this.modules.find(module => module?.typeId === this.moduleTypeBasicId);

		let validDateOfUploadedModules = null;
		if (basicModuleUploaded?.validTo) {
			validDateOfUploadedModules = new Date(basicModuleUploaded.validTo);
		} else {
			const issuingDate = new Date(basicModuleUploaded.issueDate);
			validDateOfUploadedModules = issuingDate.setDate(issuingDate.getFullYear() + 5);
		}
		// за всички прикачени модули да се гледа валидността спрямо върнатата от проверката
		for (let i = 0; i < this.modules.length; i++) {
			if (modules[i]?.validTo && new Date(modules[i].validTo).getTime() != validDateTimeFromCheck) {
				this.modules[i].validDateError = true;
			} else if (modules[i]?.issueDate) {
				const sameTypeModuleInCheck = modulesFromCheck.find(moduleInCheck => moduleInCheck?.typeId === modules[i]?.typeId);
				if (sameTypeModuleInCheck && validDateOfUploadedModules.getTime() != validDateTimeFromCheck) {
					this.modules[i].validDateError = true;
				}
			}
		}
		this.modules.forEach(module => {
			const sameTypeModuleInCheck = modulesFromCheck.find(moduleInCheck => moduleInCheck?.typeId === module?.typeId);
			if (!sameTypeModuleInCheck) {
				module.validDateError = true;
			}
		});

		return this.modules;
	}

	countDifferencesInModules(modules: AdrModule[], modulesFromCheck: AdrModule[]): number {
		let differences = 0;
		this.modules = modules;

		const validDateTimeFromCheck = new Date(modulesFromCheck[0]?.validTo).getTime();
		const basicModuleUploaded = this.modules.find(module => module?.typeId === this.moduleTypeBasicId);

		let validDateOfUploadedModules = null;
		if (basicModuleUploaded?.validTo) {
			validDateOfUploadedModules = new Date(basicModuleUploaded.validTo);
		} else {
			const issuingDate = new Date(basicModuleUploaded.issueDate);
			validDateOfUploadedModules = issuingDate.setDate(issuingDate.getFullYear() + 5);
		}
		// за всички прикачени модули да се гледа валидноста спрямо тази от проверката
		for (let i = 0; i < this.modules.length; i++) {
			if (modules[i]?.validTo && new Date(modules[i].validTo).getTime() != validDateTimeFromCheck) {
				differences++;
			} else if (modules[i]?.issueDate) {
				const sameTypeModuleInCheck = modulesFromCheck.find(moduleInCheck => moduleInCheck?.typeId === modules[i]?.typeId);
				if (sameTypeModuleInCheck && validDateOfUploadedModules.getTime() != validDateTimeFromCheck) {
					differences++;
				}
			}
		}
		this.modules.forEach(module => {
			const sameTypeModuleInCheck = modulesFromCheck.find(moduleInCheck => moduleInCheck?.typeId === module?.typeId);
			if (!sameTypeModuleInCheck) {
				differences++;
			}
		});

		return differences;
	}

	setHasErrorsAndCountDifferencesInCardInfo(oldCardView: OldCard, cardFromCheck: OldCard) : OldCard {
		let differences = 0;
		this.oldCard = oldCardView;

		if (oldCardView?.cardNumber !== cardFromCheck?.cardNumber) {
			differences++;
			this.oldCard.cardNumberError = true;
		}
		if (oldCardView?.issuingCountry?.key !== cardFromCheck?.issuingCountry?.key) {
			differences++;
			this.oldCard.issuingCountryError = true;
		}
		if (oldCardView?.issuedBy !== cardFromCheck?.issuedBy) {
			differences++;
			this.oldCard.issuedByError = true;
		}
		if (oldCardView?.validity.getTime() !== cardFromCheck?.validity.getTime()) {
			differences++;
			this.oldCard.validityError = true;
		}

		this.oldCard.differences = differences;
		return this.oldCard;
	}




}
