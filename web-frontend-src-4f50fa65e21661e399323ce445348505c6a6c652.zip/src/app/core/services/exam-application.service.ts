import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AdrConsultantExamEnrollmentRequestDto } from 'src/app/shared/dtos/adr-consultant-exam-enrollment-request-dto';
import { AdrExamEnrolmentRequestDto } from 'src/app/shared/dtos/adr-exam-enrolment-request-dto';
import { MotorExamEnrolmentRequestDto } from 'src/app/shared/dtos/motor-exam-enrolment-request-dto';
import { MotorExamPeopleQueryParams } from 'src/app/shared/dtos/motor-exam-people-query-params';
import { TaxiExamEnrolmentRequestDto } from 'src/app/shared/dtos/taxi-exam-enrollment-request-dto';
import { AdrExamPersonSelectionDto } from 'src/app/shared/interfaces/adr-exam-person-selection-dto';
import { AdrExamProtocolsResponseDto } from 'src/app/shared/interfaces/adr-exam-protocols-response-dto';
import { ConsultantExamLearningPlanSelectionDto } from 'src/app/shared/interfaces/consultant-exam-learning-plan-selection-dto';
import { MotorExamProtocolSelectionQueryParams } from 'src/app/shared/interfaces/exam/motor-exam-protocol-selection-query-params';
import { MotorExamProtocolsResponseDto } from 'src/app/shared/interfaces/exam/motor-exam-protocols-response-dto';
import { MotorExamPersonSelectionDto } from 'src/app/shared/interfaces/motor-exam-person-selection-dto';
import { MotorExamProtocolSelectionDto } from 'src/app/shared/interfaces/motor-exam-protocol-selection-dto';
import { Utils } from '../../shared/utils/utils';


const BASE_URL = 'api/exam-applications';

@Injectable({
	providedIn: 'root'
})
export class ExamApplicationService {


	constructor(
		private readonly http: HttpClient,
		private readonly utils: Utils
	) { }

	public getAdrExamPeopleForSelection(adrExamApplicationId: number) {
		return this.http.get<AdrExamPersonSelectionDto[]>(`${BASE_URL}/${adrExamApplicationId}/adr-exam-people`);
	}

	public getConsultantExamLearningPlansForExtension(consultantExamApplicationId: number) {
		return this.http.get<ConsultantExamLearningPlanSelectionDto[]>(`${BASE_URL}/${consultantExamApplicationId}/consultant-exam-learning-plans-for-extension`);
	}

	public getAdrExamProtocolsForSelection(adrExamApplicationId: number, orgUnitCode: string): Observable<AdrExamProtocolsResponseDto> {
		const params = this.utils.toHttpParamsWithDate({}, {orgUnitCode: orgUnitCode});
		return this.http.get<AdrExamProtocolsResponseDto>(`${BASE_URL}/${adrExamApplicationId}/adr-exam-protocols`, {params});
	}

	public getConsultantExamProtocolsForSelection(consultantExamApplicationId: number): Observable<AdrExamProtocolsResponseDto> {
		return this.http.get<AdrExamProtocolsResponseDto>(`${BASE_URL}/${consultantExamApplicationId}/consultant-exam-protocols`);
	}

	public enrolForAdrExam(adrExamApplicationId: number, adrExamEnrolmentRequestDto: AdrExamEnrolmentRequestDto) {
		return this.http.post(`${BASE_URL}/${adrExamApplicationId}/adr-exam-enrolment`, adrExamEnrolmentRequestDto);
	}

	public enrolForAdrConsultantExtensionExam(adrConsultantExamApplicationId: number, adrConsultantExamEnrolmentRequestDto: AdrConsultantExamEnrollmentRequestDto) {
		return this.http.post(`${BASE_URL}/${adrConsultantExamApplicationId}/consultant-extension-exam-enrolment`, adrConsultantExamEnrolmentRequestDto);
	}

	public getMotorExamPeopleForSelection(motoExamApplicationId: number, queryParams: MotorExamPeopleQueryParams): Observable<MotorExamPersonSelectionDto[]> {
		const params = this.utils.toHttpParamsWithDate({}, queryParams);
		return this.http.get<MotorExamPersonSelectionDto[]>(`${BASE_URL}/${motoExamApplicationId}/motor-exam-people`, { params });
	}

	public getMotorExamProtocolsForSelection(motoExamApplicationId: number, queryParams: MotorExamProtocolSelectionQueryParams): 
			Observable<MotorExamProtocolsResponseDto> {
		const params = this.utils.toHttpParamsWithDate({}, queryParams);
		return this.http.get<MotorExamProtocolsResponseDto>(`${BASE_URL}/${motoExamApplicationId}/motor-exam-protocols`, {params});
	}

	public enrolForMotorExam(motoExamApplicationId: number, motorExamEnrolemntRequestDto: MotorExamEnrolmentRequestDto): Observable<void> {
		return this.http.post<void>(`${BASE_URL}/${motoExamApplicationId}/motor-exam-enrolment`, motorExamEnrolemntRequestDto);
	}

	public getTaxiExamProtocols(taxiExamApplicationId: number, regionCode: string) {
		const params = this.utils.toHttpParamsWithDate({}, {regionCode: regionCode});
		return this.http.get<MotorExamProtocolsResponseDto>(`${BASE_URL}/${taxiExamApplicationId}/taxi-exam-protocols`, {params});
	}

	public enrolForTaxiExam(taxiExamApplicationId: number, taxiExamEnrolmentRequestDto: TaxiExamEnrolmentRequestDto) {
		return this.http.post(`${BASE_URL}/${taxiExamApplicationId}/taxi-exam-enrolment`, taxiExamEnrolmentRequestDto);
	}

}