import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';

@Injectable({
	providedIn: 'root'
})
export class FileService {

	public static DATA_IMAGE_AS_BASE_64 = 'data:image/jpg;base64,';

	constructor() { }

	public convertFromArrayBufferImageToBase64String(arrayBuffer: ArrayBuffer): string {
		const ascii = new Uint8Array(arrayBuffer);
		const stringChars = ascii.reduce((data, byte) => data + String.fromCharCode(byte), '');
		return FileService.DATA_IMAGE_AS_BASE_64 + btoa(stringChars);
	}

	public getFilenameFromResponse(response: HttpResponse<ArrayBuffer>): string {
		const disposition = response.headers.get('content-disposition');
		let filename = '';
		if (disposition && disposition.indexOf('attachment') !== -1) {
			const filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
			const matches = filenameRegex.exec(disposition);
			if (matches != null && matches[1]) {
				filename = matches[1].replace(/['"]/g, '');
			}
		}
		filename = decodeURIComponent(filename).replace(/\+/g, ' ');
		return filename;
	}

}
