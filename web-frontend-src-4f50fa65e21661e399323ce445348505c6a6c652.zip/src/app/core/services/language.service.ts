import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Language } from '../../shared/models/language';
import { map } from 'rxjs/operators';
import { LanguageDto } from '../../shared/interfaces/language-dto';
import { Observable } from 'rxjs';

@Injectable({
	providedIn: 'root'
})
export class LanguageService {

	private URL = {
		LANGUAGES: 'api/translations/languages',
	};

	constructor(private http: HttpClient) { }

	public getLanguages(): Observable<Language[]> {
		return this.http.get<Language[]>(this.URL.LANGUAGES)
			.pipe(map((languages: LanguageDto[]) => {
				return languages.map(language => {
					return new Language(language);
				});
			}));
	}
}
