import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RegionDto } from 'src/app/shared/dtos/region-dto';
import { CityDto } from 'src/app/shared/dtos/city-dto';
import { CountryCodeDto } from 'src/app/shared/interfaces/country-code-dto';
import { OrgUnitDto } from 'src/app/shared/dtos/org-unit-dto';
import { RequiredDocumentTypeDto } from 'src/app/shared/interfaces/required-doc-type-dto';
import { CategoryDto } from 'src/app/shared/interfaces/category-dto';
import { AdminSearchNomenclaturesDto } from 'src/app/shared/interfaces/admin-search-nomenclatures-dto';
import { DqcCertificateNomenclaturesDto } from 'src/app/shared/interfaces/dqc-certificate-nomenclatures-dto';
import { MunicipalityDto } from 'src/app/shared/dtos/municipality-dto';
import { AutocompleteDto } from 'src/app/shared/dtos/autocomplete-dto';
import { TranslationDto } from 'src/app/shared/interfaces/translation-dto';
import { RoleDto } from 'src/app/shared/interfaces/role-dto';
import { Role } from 'src/app/shared/models/role';
import { map } from 'rxjs/operators';
import { Translation } from 'src/app/shared/models/translation';
import { CountryDto } from 'src/app/shared/interfaces/country-dto';

@Injectable({
	providedIn: 'root'
})
export class NomenclatureService {
	constructor(
		private http: HttpClient) { }

	private URL = {
		BASE: 'api/nomenclatures',
		AUTOCOMPLETE: 'api/nomenclatures/autocomplete'
	};

	public getAllRegions(): Observable<RegionDto[]> {
		return this.http.get<RegionDto[]>(`${this.URL.BASE}/regions`);
	}

	public getAllMunicipalitiesByRegion(regionCode: string): Observable<MunicipalityDto[]> {
		return this.http.get<MunicipalityDto[]>(`${this.URL.BASE}/${regionCode}/municipalities`);
	}

	public getAllCitiesByRegion(regionCode: string): Observable<CityDto[]> {
		return this.http.get<CityDto[]>(`${this.URL.BASE}/${regionCode}/cities`);
	}

	public getAllCountries(): Observable<CountryDto[]> {
		return this.http.get<CountryDto[]>(`${this.URL.BASE}/countries`);
	}

	public getCountryByName(countryName: string): Observable<TranslationDto> {
		return this.http.get<TranslationDto>(`${this.URL.BASE}/countries/${countryName}`);
	}

	public getAllCountryCodes(): Observable<CountryCodeDto[]> {
		return this.http.get<CountryCodeDto[]>(`${this.URL.BASE}/country-codes`);
	}

	public getApplicationTypeDescriptionKeyById(applicationTypeId: number): Observable<string> {
		const requestOptions: object = { responseType: 'text' };
		return this.http.get<string>(`${this.URL.BASE}/application-types/${applicationTypeId}`, requestOptions);
	}

	public getAllOrgUnits(): Observable<OrgUnitDto[]> {
		return this.http.get<OrgUnitDto[]>(`${this.URL.BASE}/org-units`);
	}

	public getAllRequiredDocumentTypes(): Observable<RequiredDocumentTypeDto[]> {
		return this.http.get<RequiredDocumentTypeDto[]>(`${this.URL.BASE}/required-document-types`);
	}

	public getIdentityDocumentTypes(): Observable<TranslationDto[]> {
		return this.http.get<TranslationDto[]>(`${this.URL.BASE}/identity-document-types`);
	}

	public getIdentityDocumentIssuers(): Observable<TranslationDto[]> {
		return this.http.get<TranslationDto[]>(`${this.URL.BASE}/identity-document-issuers`);
	}

	public getAllDqcCertificateNomenclatures(): Observable<DqcCertificateNomenclaturesDto> {
		return this.http.get<DqcCertificateNomenclaturesDto>(`${this.URL.BASE}/dqc-certificate-nomenclatures`);
	}

	public getAllAdrModuleTypes(): Observable<TranslationDto[]> {
		return this.http.get<TranslationDto[]>(`${this.URL.BASE}/adr-module-types`);
	}

	public getAllCardIssuingReasons(): Observable<TranslationDto[]> {
		return this.http.get<TranslationDto[]>(`${this.URL.BASE}/card-issuing-reasons`);
	}

	public getAllCategories(): Observable<CategoryDto[]> {
		return this.http.get<CategoryDto[]>(`${this.URL.BASE}/categories`);
	}

	public getAllAdminSearchNomenclatures(): Observable<AdminSearchNomenclaturesDto> {
		return this.http.get<AdminSearchNomenclaturesDto>(`${this.URL.BASE}/admin-search`);
	}

	public getCountriesByAutocompletePhrase(autocompleteDto: AutocompleteDto): Observable<TranslationDto[]> {
		const params = this.getAutocompleteParams(autocompleteDto);
		return this.http.get<TranslationDto[]>(`${this.URL.AUTOCOMPLETE}/countries`, { params });
	}

	public getIssuersByAutocompletePhrase(autocompleteDto: AutocompleteDto): Observable<TranslationDto[]> {
		const params = this.getAutocompleteParams(autocompleteDto);
		return this.http.get<TranslationDto[]>(`${this.URL.AUTOCOMPLETE}/issuers`, { params });
	}

	public getRegionsByAutocompletePhrase(autocompleteDto: AutocompleteDto): Observable<RegionDto[]> {
		const params = this.getAutocompleteParams(autocompleteDto);
		return this.http.get<RegionDto[]>(`${this.URL.AUTOCOMPLETE}/regions`, { params });
	}

	public getMunicipalityByRegionAndAutocompletePhrase(regionCode: string, autocompleteDto: AutocompleteDto): Observable<MunicipalityDto[]> {
		const params = this.getAutocompleteParams(autocompleteDto);
		return this.http.get<MunicipalityDto[]>(`${this.URL.AUTOCOMPLETE}/${regionCode}/municipality`, { params });
	}

	public getCitiesByRegionAndAutocompletePhrase(regionCode: string, autocompleteDto: AutocompleteDto): Observable<CityDto[]> {
		const params = this.getAutocompleteParams(autocompleteDto);
		return this.http.get<CityDto[]>(`${this.URL.AUTOCOMPLETE}/${regionCode}/cities`, { params });
	}

	public getDocumentTypesByAutocompletePhrase(autocompleteDto: AutocompleteDto): Observable<TranslationDto[]> {
		const params = this.getAutocompleteParams(autocompleteDto);
		return this.http.get<TranslationDto[]>(`${this.URL.AUTOCOMPLETE}/document-types`, { params });
	}

	public getAllGenders(): Observable<TranslationDto[]> {
		return this.http.get<TranslationDto[]>(`${this.URL.BASE}/genders`);
	}

	public getAllRoles(): Observable<Role[]> {
		return this.http.get<RoleDto[]>(`${this.URL.BASE}/roles`)
			.pipe(map((roleDtos: RoleDto[]) => {
				return roleDtos.map((roleDto: RoleDto) => {
					return new Role(roleDto);
				});
			}));
	}

	public getAllAuthenticationMethods(): Observable<Translation[]> {
		return this.http.get<TranslationDto[]>(`${this.URL.BASE}/authentication-methods`)
			.pipe(map((translationDtos: TranslationDto[]) => {
				return translationDtos.map(translationDto => {
					return new Translation(translationDto);
				});
			}));
	}

	private getAutocompleteParams(autocompleteDto: AutocompleteDto) {
		const params = new HttpParams()
			.set('phrase', autocompleteDto.phrase)
			.set('lang', autocompleteDto.langCode);
		return params;
	}
}
