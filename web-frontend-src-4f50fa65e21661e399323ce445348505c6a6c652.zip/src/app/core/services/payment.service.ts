import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable} from 'rxjs';
import { PaymentDto } from 'src/app/shared/dtos/payment-dto';
import { PaymentTaxesViewDto } from 'src/app/shared/interfaces/payment-taxes-view-dto';
import { DocumentPageDto } from 'src/app/shared/dtos/document-page-dto';

@Injectable({
	providedIn: 'root'
})
export class PaymentService {

	constructor(private readonly http: HttpClient) { }

	private URL = {PAYMENTS: 'api/payments'};

	public getApplicationTaxes(applicationId: number): Observable<PaymentTaxesViewDto> {
		return this.http.get<PaymentTaxesViewDto>(this.URL.PAYMENTS + '/application/' + applicationId + '/taxes');
	}

	public createPaymentForApplication(applicationId: number, dto: PaymentDto): Observable<void> {
		return this.http.post<void>(this.URL.PAYMENTS + '/application/' + applicationId, dto);
	}

	public getGeneratedPaymentOrderForApplication(applicationId: number, paymentType: number): Observable<HttpResponse<ArrayBuffer>> {
		return this.http.get<ArrayBuffer>(
			this.URL.PAYMENTS + '/application/' + applicationId + '/payment-type/' + paymentType,
			{responseType: 'arrayBuffer' as 'json' , observe: 'response' });
	}

	public getPaymentDocumentPagesInfo(applicationId: number, documentTypeId: number): Observable<DocumentPageDto[]> {
		return this.http.get<DocumentPageDto[]>(
			this.URL.PAYMENTS + '/application/' + applicationId + '/document/' + documentTypeId + '/pages-info');
	}

	public getGeneratedInvoiceForApplication(applicationId: number): Observable<HttpResponse<ArrayBuffer>> {
		return this.http.get<ArrayBuffer>(
			this.URL.PAYMENTS + '/application/' + applicationId + '/invoice',
			{responseType: 'arrayBuffer' as 'json' , observe: 'response' });
	}
}
