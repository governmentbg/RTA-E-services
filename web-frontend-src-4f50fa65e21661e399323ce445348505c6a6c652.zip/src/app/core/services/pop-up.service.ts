import { Injectable } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import { PopUp } from 'src/app/shared/models/pop-text';

@Injectable({
	providedIn: 'root'
})
export class PopUpService {

	constructor() { }

	private static popUpSubject = new Subject<Partial<PopUp>>();
	private static popUpResponseSubject = new Subject<boolean>();
	private static showPopUpSubject = new Subject<boolean>();
	private static popUpInputSubject = new Subject<string>();

	static showPopUp(popUp: Partial<PopUp>) {
		this.popUpSubject.next(popUp);
	}

	static subscribeToPopUpResponse(next: (value: boolean) => void): Subscription {
		return this.popUpResponseSubject.subscribe(next);
	}

	static subscribeToPopUpSubjectChanges(next: (value: Partial<PopUp>) => void): Subscription {
		return this.popUpSubject.subscribe(next);
	}

	static subscribeToShowPopUp(next: (value: boolean) => void): Subscription {
		return this.showPopUpSubject.subscribe(next);
	}

	static closePopUp() {
		this.showPopUpSubject.next(false);
	}

	static setPopUpResponse(response: boolean) {
		this.popUpResponseSubject.next(response);
	}

	static setPopUpInput(message: string) {
		this.popUpInputSubject.next(message);
	}

	static subscribeToPopUpInput(next: (value: string) => void): Subscription {
		return this.popUpInputSubject.subscribe(next);
	}

}
