import { Injectable } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { RouteUrl } from '../../shared/enums/route-url.enum';
import { Location } from '@angular/common';
import { Subject } from 'rxjs';

@Injectable({
	providedIn: 'root'
})
export class RouteUtilService {

	public currentPath: string;
	public isAuthenticationTab: boolean;
	public isDashboardTab: boolean;
	public isAdminTab: boolean;
	public isUsersTab: boolean;
	public isApplicationTab: boolean;
	public initialPath: string;
	public previousPath: Subject<string> = new Subject();

	constructor(
				private router: Router,
				private location: Location) {
		router.events.pipe(
			filter(e => e instanceof NavigationEnd)
		).subscribe((event: NavigationEnd) => {
			this.initialPath = this.currentPath;
			this.previousPath.next(this.initialPath);
			const url = event.url;
			this.currentPath = url;
			this.isAuthenticationTab = this.isInAuthenticationTab(url);
			this.isDashboardTab = this.isInDashboardTab(url);
			this.isAdminTab = this.isInAdminTab(url);
			this.isUsersTab = this.isInUsersTab(url);
			this.isApplicationTab = this.isInApplicationTab(url);
		});
	}

	public isInTab(...routes: string[]): boolean {
		return routes.some(route => this.currentPath.includes(route));
	}

	public isInAuthenticationTab(url: string): boolean {
		return url.indexOf('/' + RouteUrl.LOG_IN) !== -1;
	}

	public isInDashboardTab(url: string): boolean {
		return url.startsWith('/' + RouteUrl.DASHBOARD);
	}

	public isInAdminTab(url: string): boolean {
		return url.startsWith('/' + RouteUrl.ADMIN);
	}

	public isInUsersTab(url: string): boolean {
		return url.startsWith('/' + RouteUrl.ADMIN + '/' + RouteUrl.USERS);
	}

	public isInDevTab(url: string): boolean {
		return url.startsWith('/' + RouteUrl.DEV);
	}

	public isInApplicationTab(url: string): boolean {
		return url.startsWith('/' + RouteUrl.APPLICATION);
	}

	public goBack() {
		this.location.back();
	}
}
