import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
	providedIn: 'root'
})
export class SubHeaderService {
	private $isFilterToggleChanged = new Subject<boolean>();
	public subHeaderFilterToggle = this.$isFilterToggleChanged.asObservable();
	public isToggleOn: boolean;

	public setFiltersToggleStatus(hasFilters: boolean) {
		this.$isFilterToggleChanged.next(hasFilters);
		this.isToggleOn = hasFilters;
	}

	public getFiltersToggleStatus(): boolean {
		return this.isToggleOn;
	}
}
