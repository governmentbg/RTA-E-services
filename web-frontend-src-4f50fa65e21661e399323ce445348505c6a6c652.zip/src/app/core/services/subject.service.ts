import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { RequestMvrDto } from 'src/app/shared/dtos/request-mvr-dto';
import { CurrentAddressNamesChangeDto } from 'src/app/shared/dtos/current-address-names-change-dto';
import { AddressDto } from 'src/app/shared/dtos/address-dto';
import { PersonalInfoDto } from 'src/app/shared/dtos/personal-info-form-dto';
import { PhotoAndSignatureDto } from 'src/app/shared/interfaces/photo-and-signature-dto';
import { ContractDto } from 'src/app/shared/interfaces/contract-dto';
@Injectable({
	providedIn: 'root'
})
export class SubjectService {
	private URL = {
		SUBJECT: 'api/subjects'
	};

	constructor(private http: HttpClient) { }

	public getPersonalInfoFromServices(requestMvrDto: RequestMvrDto): Observable<PersonalInfoDto> {
		return this.http.post<PersonalInfoDto>(`${this.URL.SUBJECT}/mvr-personal-info`, requestMvrDto);
	}

	public getPersonalInfoFromServicesForApprover(requestMvrDto: RequestMvrDto): Observable<PersonalInfoDto> {
		return this.http.post<PersonalInfoDto>(`${this.URL.SUBJECT}/approver/mvr-personal-info`, requestMvrDto);
	}

	public getPhotoAndSignatureFromMvrForApprover(requestMvrDto: RequestMvrDto): Observable<PhotoAndSignatureDto> {
		return this.http.post<PhotoAndSignatureDto>(`${this.URL.SUBJECT}/approver/mvr-pictures`, requestMvrDto);
	}

	public saveCurrentAddressAndNames(currentAddressNamesChangeDto: CurrentAddressNamesChangeDto): Observable<AddressDto> {
		return this.http.post<AddressDto>(`${this.URL.SUBJECT}/mvr-personal-info-additional`, currentAddressNamesChangeDto);
	}

	public savePersonalInfoForm(personalInfoFormDto: PersonalInfoDto): Observable<PersonalInfoDto> {
		return this.http.post<PersonalInfoDto>(`${this.URL.SUBJECT}/personal-info`, personalInfoFormDto);
	}

	public saveFaceAndPictureSectionTransition(applicationId: number): Observable<void> {
		return this.http.post<void>(`${this.URL.SUBJECT}/application/${applicationId}/picture-transition`, null);
	}

	public getActiveContractsFromNap(applicationId: number): Observable<ContractDto[]> {
		return this.http.get<ContractDto[]>(`${this.URL.SUBJECT}/application/${applicationId}/approver/nap-check`);
	}
}
