import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TranslationKeyValuesDto } from 'src/app/shared/interfaces/translation-key-values-dto';
import { PageResultDto } from 'src/app/shared/interfaces/page-result-dto';
import { Utils } from 'src/app/shared/utils/utils';
import { TranslationRequestDto } from 'src/app/shared/dtos/translation-request-dto';
import { PaginationParams } from 'src/app/shared/pagination/pagination-params';
import { TranslationFilters } from 'src/app/shared/models/translation-filters';
import { LocaleService } from 'angular-l10n';

@Injectable({
	providedIn: 'root'
})
export class TranslationKeyValuesService {

	private URL = {
		TRANSLATIONS: 'api/translations'
	};

	constructor(
		private http: HttpClient,
		private locale: LocaleService

	) { }

	public getTranslationsPage(pageParams: PaginationParams, searchFilters: TranslationFilters)
	: Observable<PageResultDto<TranslationKeyValuesDto>> {
		const params = Utils.toHttpParams(pageParams, searchFilters);
		return this.http.get<PageResultDto<TranslationKeyValuesDto>>(this.URL.TRANSLATIONS, {params});
	}

	public editTranslation(translationRequestDto: TranslationRequestDto): Observable<TranslationKeyValuesDto> {
		return this.http.put<TranslationKeyValuesDto>(this.URL.TRANSLATIONS, translationRequestDto);
	}

	public addNewTranslation(translationRequestDto: TranslationRequestDto): Observable<TranslationKeyValuesDto> {
		return this.http.post<TranslationKeyValuesDto>(this.URL.TRANSLATIONS, translationRequestDto);
	}

	public delete(key: string): Observable<HttpEvent<{}>> {
		return this.http.delete<HttpEvent<{}>>(this.URL.TRANSLATIONS + '/' + key);
	}

	public getTranslationKeyByValueAndLang(searchFilters: TranslationFilters): Observable<string[]> {
		const params = Utils.toHttpParams(searchFilters);
		return this.http.get<string[]>(this.URL.TRANSLATIONS + '/filter', {params});
	}
}
