import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { Roles } from 'src/app/shared/enums/roles';
import { AdminComponent } from './admin.component';
import { UsersListComponent } from './users-list/users-list.component';

const routes: Routes = [
	{
		path: '',
		canActivateChild: [AuthGuard],
		data: {
			expectedRoles: [
				Roles.ROLE_ADMIN_DEMAX,
				Roles.ROLE_VIEWER,
				Roles.ROLE_APPROVER,
				Roles.ROLE_DESK_STAFF,
				Roles.ROLE_PERSO_CENTER_DEMAX
			]
		},
		children: [
			{
				path: '',
				pathMatch: 'full',
				redirectTo: RouteUrl.DASHBOARD
			},
			{
				path: RouteUrl.DASHBOARD,
				component: AdminComponent
			},
			{
				path: RouteUrl.USERS,
				component: UsersListComponent
			}
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class AdminRoutingModule { }
