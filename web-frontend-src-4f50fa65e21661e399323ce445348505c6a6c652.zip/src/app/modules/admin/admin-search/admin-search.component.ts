import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { User } from '../../../shared/models/user';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { ApplicationSearchParams } from '../../../shared/models/application-query-params';

import { FLAG_TYPE_DROPDOWN } from '../../../shared/models/constants/dropdowns/flag-type-dropdown';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { AdminSearchNomenclaturesDto } from 'src/app/shared/interfaces/admin-search-nomenclatures-dto';
import { AdminSearchNomenclatures } from 'src/app/shared/models/admin-search-nomenclatures';
import { AdminSearchService } from 'src/app/core/services/admin-search.service';
import { Utils } from 'src/app/shared/utils/utils';

@Component({
	selector: 'app-admin-search',
	templateUrl: './admin-search.component.html',
})
export class AdminSearchComponent implements OnInit {
	@Input() loggedUserRole: string;
	@Input() hasFilters: boolean;
	@Input() totalCount: number;
	@Output() searchParams: EventEmitter<ApplicationSearchParams> = new EventEmitter<ApplicationSearchParams>();
	user: User;
	filterParams: ApplicationSearchParams;
	flagTypes = FLAG_TYPE_DROPDOWN;
	searchInput: string = null;
	searchInputOption: 'applicant' | 'applicationNumber' | 'applicantIdentityNumber' = 'applicationNumber';
	hasChosenFilter = false;
	nomenclatures: AdminSearchNomenclatures = null;
	today: Date = new Date();
	dateFrom: Date;
	dateTo: Date;

	constructor(
		private readonly authenticationService: AuthenticationService,
		private adminSearchService: AdminSearchService,
		private readonly nomenclatureService: NomenclatureService) {
		this.filterParams = new ApplicationSearchParams();
	}

	ngOnInit(): void {
		this.user = this.authenticationService.getAuthenticatedUser();
		this.getNomenclatures();
		const hasAnyFilters = this.adminSearchService.getFilters();
		if (hasAnyFilters) {
			this.hasChosenFilter = true;
			this.filterParams = this.adminSearchService.getFilters();
		}
	}

	getNomenclatures() {
		this.nomenclatureService.getAllAdminSearchNomenclatures()
			.subscribe((dto: AdminSearchNomenclaturesDto) => {
				this.nomenclatures = new AdminSearchNomenclatures(dto);
			});
	}

	getApplicationsBySearchParams(): void {
		this.setFilterButtonVisibility();
		if (this.searchInputOption  === 'applicationNumber' && this.searchInput) {
			this.filterParams.applicationId = +this.searchInput;
			this.searchParams.emit(this.filterParams);
			return;
		}
		if (this.searchInputOption === 'applicant' && this.searchInput) {
			this.convertInputToSearchNames(this.searchInput);
		}
		if (this.searchInputOption === 'applicantIdentityNumber' && this.searchInput) {
			this.filterParams.identityNumber = this.searchInput;
		}

		this.searchParams.emit(this.filterParams);
	}

	setDateFrom() {
		this.filterParams.dateFrom = new Date(this.dateFrom);
	}

	setDateTo() {
		this.filterParams.dateTo = new Date(this.dateTo);
		if (this.dateFrom && this.dateTo){
			this.getApplicationsBySearchParams();
		}
	}

	searchByDate() {
		this.getApplicationsBySearchParams();
	}

	getApplicationsBySearchButton() {
		if (this.searchInput) {
			this.getApplicationsBySearchParams();
		}
	}

	setFilterButtonVisibility(): void {
		if (!this.filterParams.hasParams() && !this.searchInput) {
			return;
		}
		if (this.filterParams.hasParams()) {
			this.hasChosenFilter = true;
		}
	}

	resetFilters(): void {
		this.filterParams.clearParams();
		this.dateTo = null;
		this.dateFrom = null;
		this.hasChosenFilter = false;
		this.getApplicationsBySearchParams();
	}

	resetSearch(): void {
		this.searchInput = null;
		this.filterParams.clearInputTypeParams();
		this.getApplicationsBySearchParams();
	}

	searchInputOnKey(input: string) {
		// TODO : input validations
		this.searchInput = '' + input;
	}

	convertInputToSearchNames(inputNames: string): void {
		const splitted = inputNames.split(' ').map((e: string) => e.trim())
			.filter((e: string) => e.length > 0);
		this.filterParams.firstName = splitted[0];
		this.filterParams.secondName = splitted[1];
		this.filterParams.familyName = splitted[2];
	}

	clearInput(): void {
		this.searchInput = null;
		this.filterParams.clearInputTypeParams();
	}

	ngOnDestroy() {
		this.adminSearchService.saveFilters(this.filterParams);
	}
}
