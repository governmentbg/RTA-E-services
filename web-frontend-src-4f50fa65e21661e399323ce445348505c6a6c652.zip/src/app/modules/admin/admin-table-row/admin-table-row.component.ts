import { Component, Input, EventEmitter, Output, OnInit} from '@angular/core';
import { S_VARIABLES } from '../../../shared/models/constants/s-variables';
import { ApplicationRowAdmin } from 'src/app/shared/models/application-row-admin';
import { Pagination } from 'src/app/shared/pagination/pagination';
import { TranslationService } from 'angular-l10n';
import { User } from 'src/app/shared/models/user';
@Component({
	selector: 'app-admin-table-row',
	templateUrl: './admin-table-row.component.html',
})
export class AdminTableRowComponent implements OnInit {
	@Input() application: ApplicationRowAdmin;
	@Input() index: number;
	@Input() user: User;
	@Input() currentLanguage: string;
	@Input() pagination: Pagination;
	@Output() applicationGet: EventEmitter<ApplicationRowAdmin> = new EventEmitter<ApplicationRowAdmin>();
	@Output() applicationDelete: EventEmitter<number> = new EventEmitter<number>();
	public languageBG = S_VARIABLES.LANGUAGE_BG;
	public dateFormat = S_VARIABLES.DATE_FORMAT;
	indexNumber: number;
	showStatusDescriptionTranslationKey: boolean;
	isAdmin: boolean;

	constructor(
		private translation: TranslationService) {}

	ngOnInit(): void {
		this.isAdmin = this.user.isDemaxAdmin();
		this.indexNumber = this.pagination.totalCount
			- (this.index + this.pagination.paginationParams.pageSize * (this.pagination.paginationParams.page - 1));
		const translatedValue = this.translation.translate(this.application.descriptionStatusTranslationKey);
		this.showStatusDescriptionTranslationKey = translatedValue === 'No key' ? false : true;
	}

	public openApplication() {
		this.applicationGet.emit(this.application);
	}

	// TODO: for testing purposes only
	deleteApplication() {
		this.applicationDelete.emit(this.application.applicationId);
	}
}
