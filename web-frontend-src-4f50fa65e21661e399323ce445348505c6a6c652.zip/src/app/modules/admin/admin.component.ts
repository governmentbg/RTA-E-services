import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { LocaleService } from 'angular-l10n';
import { PageResultDto } from 'src/app/shared/interfaces/page-result-dto';
import { ApplicationLightDto } from 'src/app/shared/interfaces/application-light-dto';
import { ApplicationService } from 'src/app/core/services/application.service';
import { Subscription } from 'rxjs';
import { ApplicationRowAdmin } from 'src/app/shared/models/application-row-admin';
import { map } from 'rxjs/operators';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';
import { ApplicationSearchParams } from '../../shared/models/application-query-params';
import { ApplicationTypes } from 'src/app/shared/enums/application-types';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { APPLICATION_STATUSES } from 'src/app/shared/enums/application-statuses';
import { SubHeaderService } from 'src/app/core/services/sub-header.service';
import { Pagination } from 'src/app/shared/pagination/pagination';
import { PaginationParams } from 'src/app/shared/pagination/pagination-params';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { TABLE_CLASS_NAME_BASED_ON_USER_ROLE } from 'src/app/shared/models/constants/icon-classes/table-class-name-admin';
import { User } from 'src/app/shared/models/user';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { AdminSearchService } from 'src/app/core/services/admin-search.service';

interface AdminPageData {totalCount: number; items: ApplicationRowAdmin[]; }
@Component({
	selector: 'app-admin',
	templateUrl: './admin.component.html'})
export class AdminComponent implements OnInit, OnDestroy {
	public pagination: Pagination = null;
	public adminTableSubscriptions: Subscription [] = [];
	public applications: ApplicationRowAdmin[] = [] ;
	public user: User;
	public totalCount: number;
	public currentLanguage: string;
	public pageParams: PaginationParams;
	public filterParams: ApplicationSearchParams;
	public applicationType: ApplicationTypes;
	public selectedApplicationType: number;
	public isLoading = false;
	public tableClassNameBasedOnUserRole: number;
	public hasFilters: boolean;
	isInInitInAdminComponent = true;
	canShowComponent = true;

	constructor(
		private readonly authenticationService: AuthenticationService,
		private readonly applicationService: ApplicationService,
		private readonly router: Router,
		private readonly subHeaderService: SubHeaderService,
		private adminSearchService: AdminSearchService,
		private locale: LocaleService
	) {}

	ngOnInit(): void {
		this.user = this.authenticationService.getAuthenticatedUser();
		if (localStorage.getItem(S_VARIABLES.CHOSEN_NEW_APPLICATION_TYPE_FROM_WEB_LINK)) {
			this.canShowComponent = false;
			this.relocateToNewApplicationBasedOnWebLink();
		}
		this.tableClassNameBasedOnUserRole = TABLE_CLASS_NAME_BASED_ON_USER_ROLE[this.user.getRoleId()];		
		this.currentLanguage = this.locale.getCurrentLanguage();
		this.adminTableSubscriptions.push(this.locale.languageCodeChanged.subscribe((currentCode: string) => {
			this.currentLanguage = currentCode;
		}));
		this.hasFilters = this.subHeaderService.getFiltersToggleStatus(); // in case toggle is on when enter in onInitAdminTable;
		this.adminTableSubscriptions.push(this.subHeaderService.subHeaderFilterToggle.subscribe((value: boolean) => {
			this.hasFilters = value;
		}));	
		this.setFilterParams();
		this.adminTableSubscriptions.push(this.pagination.subscribeToParamsChanges(() => {
			this.getPage();
		}));
	}

	setFilterParams() {
		this.pageParams = (this.adminSearchService.getPageParams() != null)
			? this.adminSearchService.getPageParams()
			: new PaginationParams({pageSize: S_VARIABLES.PAGE_SIZE_ADMIN_TABLE});
		this.filterParams = (this.adminSearchService.getFilters() != null)
			? this.adminSearchService.getFilters()
			: new ApplicationSearchParams();
		this.pagination = new Pagination(this.pageParams);
	}

	relocateToNewApplicationBasedOnWebLink() {
		const appTypeFromWebLink =
			JSON.parse(localStorage.getItem(S_VARIABLES.CHOSEN_NEW_APPLICATION_TYPE_FROM_WEB_LINK));
		localStorage.removeItem(S_VARIABLES.CHOSEN_NEW_APPLICATION_TYPE_FROM_WEB_LINK);
		const loginPageLoadedTime = new Date(appTypeFromWebLink.time);
		const time1MinAfterLoadingLoginPage = loginPageLoadedTime;
		time1MinAfterLoadingLoginPage.setMinutes(loginPageLoadedTime.getMinutes() + 1);
		const now = new Date();
		if (time1MinAfterLoadingLoginPage > now ) {
			this.router.navigate([ RouteUrl.APPLICATION, RouteUrl.NEW, appTypeFromWebLink.applicationTypeId]);
		}
	}

	openApplication(application: ApplicationRowAdmin) {
		if (application.applicationStatusId === APPLICATION_STATUSES.DRAFT) {
			this.router.navigate([RouteUrl.APPLICATION, RouteUrl.DRAFT, application.applicationId]);
		} else {
			this.router.navigate([RouteUrl.APPLICATION, application.applicationId]);
		}
	}

	public getApplicationsBySearchParams(filterParams: ApplicationSearchParams) {
		this.pageParams.page = 1;
		this.pageParams.pageSize = S_VARIABLES.PAGE_SIZE_ADMIN_TABLE;
		this.filterParams = filterParams;
		this.getPage();
	}

	getPage() {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.applicationService.getApplicationPage(this.pageParams, this.filterParams)
			.pipe(
				map(({totalCount, items}: PageResultDto<ApplicationLightDto>) => ({
					totalCount,
					items: items.map((itemDto: ApplicationLightDto) => new ApplicationRowAdmin(itemDto))
				}))
			)
			.subscribe(
				({totalCount, items}: AdminPageData) => {
				this.totalCount = totalCount;
				this.applications = items;
				this.pagination.setTotalCount(this.totalCount);
				this.pagination.goToPage(this.pageParams.page);
				this.isInInitInAdminComponent = false;
			},
			(errorResponse) => {
				this.isInInitInAdminComponent = false;
				if (errorResponse.error) {
					if (errorResponse.error.error === 'ApplicationException' ) {
						this.isInInitInAdminComponent = false;
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_cannot_upload_correctly_page,
							subHeader: POP_UP_MESSAGES_KEYS.error_contact_system_administrator,
							text: POP_UP_MESSAGES_KEYS.error_missing_application_info,
							type: PopUpTypes.ERROR
						});
					}
				}
			}).add(() => this.isLoading = false);
	}

	// TODO: for testing purposes only
	deleteApplication(applicationId: number) {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		PopUpService.showPopUp(DEFAULT_POP_UPS.delete_application);
		const currentSubscription = PopUpService.subscribeToPopUpResponse(
			(hasConfirmed) => {
				if (hasConfirmed) {
					this.applicationService
						.deleteApplication(applicationId)
						.subscribe(
							(success) => {
								this.isLoading = false;
								this.getPage();
							},
							(error) => {
								this.isLoading = false;
								PopUpService.showPopUp(DEFAULT_POP_UPS.error_could_not_delete_file);
							}
						);
				}
				currentSubscription.unsubscribe();
			}
		);
	}

	toggleSortDirection() {
		this.pageParams.toggleOrder();
		this.getPage();
	}

	ngOnDestroy(): void {
		this.adminSearchService.savePageParams(this.pageParams);
		this.adminTableSubscriptions.forEach((subscription) => subscription.unsubscribe());
	}
}

