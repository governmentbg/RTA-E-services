import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminComponent } from './admin.component';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminTableRowComponent } from './admin-table-row/admin-table-row.component';
import { CoreModule } from 'src/app/core/core.module';
import { TranslationModule } from 'angular-l10n';
import { AdminSearchComponent } from './admin-search/admin-search.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { UsersListComponent } from './users-list/users-list.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MAT_DATE_FORMATS } from '@angular/material/core';
import { MY_FORMATS } from 'src/app/shared/models/constants/date-formats';
@NgModule({
	declarations: [
		AdminComponent,
		AdminTableRowComponent,
		AdminSearchComponent,
		UsersListComponent
	],
	imports: [
		CommonModule,
		AdminRoutingModule,
		CoreModule,
		TranslationModule,
		FormsModule,
		SharedModule,
		MatDatepickerModule,
		MatInputModule,
	],
	providers: [
		MatDatepickerModule,
		{ provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
	]
})
export class AdminModule { }
