import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { UserService } from 'src/app/core/authentication/user.service';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';

import { SubHeaderService } from 'src/app/core/services/sub-header.service';
import { Roles } from 'src/app/shared/enums/roles';
import { RoleDto } from 'src/app/shared/interfaces/role-dto';
import { UserRoleChangeRequestDto } from 'src/app/shared/interfaces/user-role-change-request-dto';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { Role } from 'src/app/shared/models/role';
import { Translation } from 'src/app/shared/models/translation';
import { UserManagementListFilters, UserManagementListFilterSearchTypes } from 'src/app/shared/models/user-management-list-filters';
import { UserManagementListItem } from 'src/app/shared/models/user-management-list-item';
import { Pagination } from 'src/app/shared/pagination/pagination';
import { PaginationParams } from 'src/app/shared/pagination/pagination-params';

@Component({
	selector: 'app-users-list',
	templateUrl: './users-list.component.html'
})
export class UsersListComponent implements OnInit, OnDestroy {

	public readonly dateFormat = S_VARIABLES.DATE_FORMAT;
	public roles: Role[] = [];
	public authenticationMethods: Translation[] = [];

	public hasFilters: boolean;
	public pagination: Pagination;
	public pageParams: PaginationParams;
	public filters: UserManagementListFilters;
	public filterSearchTypes = UserManagementListFilterSearchTypes;
	public filterSearchTypeKeys = Object.keys(UserManagementListFilterSearchTypes);
	public isLoading = false;
	
	public users: UserManagementListItem[] = [];
	public userWithOpenOptionsMenu: UserManagementListItem = null;

	private subscriptions: Subscription [] = [];

	@HostListener('document:click', ['$event'])
	onClick() {
		this.userWithOpenOptionsMenu = null;
	}

	constructor(
		private readonly subHeaderService: SubHeaderService,
		private readonly nomenclatureService: NomenclatureService,
		private readonly userService: UserService) { }

	ngOnInit(): void {
		this.pageParams = new PaginationParams({pageSize: S_VARIABLES.PAGE_SIZE_ADMIN_TABLE});
		this.pagination = new Pagination(this.pageParams);
		this.filters = new UserManagementListFilters();
		this.filters.setOnResetCallback(() => {
			this.loadUsers();
		});
		
		this.hasFilters = this.subHeaderService.getFiltersToggleStatus();
		this.subscriptions.push(this.subHeaderService.subHeaderFilterToggle.subscribe((value: boolean) => {
			this.hasFilters = value;
		}));

		this.loadRoles();
		this.loadAuthenticationMethods();
		this.subscriptions.push(this.pagination.subscribeToParamsChanges(() => {
			this.loadUsers();
		}));
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach((subscription) => subscription.unsubscribe());
	}

	public toggleUserOptionsMenu(user: UserManagementListItem, $event: Event): void {
		$event.stopPropagation();
		if (this.userWithOpenOptionsMenu && this.userWithOpenOptionsMenu.id === user.id) {
			this.userWithOpenOptionsMenu = null;
		} else {
			this.userWithOpenOptionsMenu = user;
		}
	}

	public onRoleMenuItemSelected(user: UserManagementListItem, role: Role, $event: Event): void {
		this.changeUserRole(user, role);
		this.userWithOpenOptionsMenu = null;
	}

	private loadRoles(): void {
		this.nomenclatureService.getAllRoles()
			.subscribe(roles => {
				this.roles = roles;
			});
	}

	private loadAuthenticationMethods(): void {
		this.nomenclatureService.getAllAuthenticationMethods()
			.subscribe(authenticationMethods => {
				this.authenticationMethods = authenticationMethods;
			});
	}

	public loadUsers(): void {
		this.isLoading = true;
		this.userService.getUsers(this.pageParams, this.filters.toQueryParamsObject())
			.subscribe(pageResult => {
				this.pagination.setTotalCount(pageResult.totalCount);
				this.users = pageResult.items;
			}).add(() => {
				this.isLoading = false;
			});
	}

	private changeUserRole(user: UserManagementListItem, role: Role): void {
		const requestDto: UserRoleChangeRequestDto = {
			roleId: role.id
		};
		this.isLoading = true;
		this.userService.changeUserRole(user.id, requestDto)
			.subscribe()
			.add(() => {
				this.loadUsers();
			});
	}
}
