import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';
import { ApplicationComponent } from './application.component';
import { NewApplicationComponent } from './new-application/new-application.component';
import { Roles } from 'src/app/shared/enums/roles';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { SubmittedApplicationComponent } from './submitted-application/submitted-application.component';

const routes: Routes = [
	{
		path: '',
		component: ApplicationComponent,
		canActivateChild: [AuthGuard],

		children: [
			{
				path: RouteUrl.NEW_TYPE,
				component: NewApplicationComponent,
				data: {
					expectedRoles: [
						Roles.ROLE_ADMIN_DEMAX,
						Roles.ROLE_VIEWER,
						Roles.ROLE_APPLICANT_E_FACE,
						Roles.ROLE_APPLICANT_E_SIGN,
						Roles.ROLE_DESK_STAFF,
					]
				}
			},
			{
				path: RouteUrl.ID,
				component: SubmittedApplicationComponent,
				data: {
					expectedRoles: [
						Roles.ROLE_ADMIN_DEMAX,
						Roles.ROLE_VIEWER,
						Roles.ROLE_APPLICANT_E_FACE,
						Roles.ROLE_APPLICANT_E_SIGN,
						Roles.ROLE_DESK_STAFF,
						Roles.ROLE_APPROVER,
						Roles.ROLE_PERSO_CENTER_DEMAX
					]
				}
			},
			{
				path: RouteUrl.DRAFT_ID,
				component: NewApplicationComponent,
				data: {
					expectedRoles: [
						Roles.ROLE_ADMIN_DEMAX,
						Roles.ROLE_VIEWER,
						Roles.ROLE_APPLICANT_E_FACE,
						Roles.ROLE_APPLICANT_E_SIGN,
						Roles.ROLE_DESK_STAFF,
					]
				}
			},
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class ApplicationRoutingModule { }
