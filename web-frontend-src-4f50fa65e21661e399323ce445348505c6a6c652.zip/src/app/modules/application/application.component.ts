import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-application',
	templateUrl: './application.component.html'
})
export class ApplicationComponent implements OnInit {
	constructor() { }

	ngOnInit(): void {}

}
