import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { ImageCropperModule } from 'ngx-image-cropper';
import { ApplicationComponent } from './application.component';
import { ApplicationRoutingModule } from './application-routing.module';
import { TitleComponent } from '../../shared/components/title/title.component';
import { CorrespondenceInfoComponent } from './new-application/correspondence-info/correspondence-info.component';
// tslint:disable-next-line: max-line-length
import { CardDeliveryOptionsComponent } from './new-application/card-delivery-options/card-delivery-options.component';
import { NewApplicationComponent } from './new-application/new-application.component';
import { PaymentComponent } from './submitted-application/payment/payment.component';
import { PersonalInfoFormComponent } from './new-application/personal-info-section/personal-info-form/personal-info-form.component';
import { RouterModule } from '@angular/router';
import { ServiceOptionComponent } from './new-application/service-options/service-options.component';
import { SigningComponent } from './new-application/signing/signing.component';
import { StepsComponent } from './new-application/steps/steps.component';
import { PersonalInfoComponent } from './new-application/personal-info-section/personal-info.component';
import { DisplayAddressComponent } from 'src/app/shared/components/display-address/display-address.component';
// tslint:disable-next-line: max-line-length
import { PersonalInfoDisplayedComponent } from './new-application/personal-info-section/personal-info-displayed/personal-info-displayed.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SubmittedApplicationComponent } from './submitted-application/submitted-application.component';
import { TranslationModule } from 'angular-l10n';
import { NgxFileDropModule } from 'ngx-file-drop';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule, DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS } from '@angular/material/core';
// tslint:disable-next-line: max-line-length
import { AttachDocumentRowComponent } from 'src/app/shared/components/attach-single-document/attach-document-row/attach-document-row.component';
import { AttachMultipleDocumentsComponent } from 'src/app/shared/components/attach-multiple-documents/attach-multiple-documents.component';
import { AttachSingleDocumentComponent } from 'src/app/shared/components/attach-single-document/attach-single-document.component';
// tslint:disable-next-line: max-line-length
import { DrivingLicenseInfoFormComponent } from './new-application/driving-licence-section/driving-license-info-form/driving-license-info-form.component';
import { DrivingLicenseInfoComponent } from './new-application/driving-licence-section/driving-license-info.component';
// tslint:disable-next-line: max-line-length
import { DrivingLicenseInfoDisplayComponent } from './new-application/driving-licence-section/driving-license-info-display/driving-license-info-display.component';
// tslint:disable-next-line: max-line-length
import { AttachCertificateDocumentComponent } from 'src/app/shared/components/attach-certificate-document/attach-certificate-document.component';
// tslint:disable-next-line: max-line-length
import { AttachCertificateInfoRowComponent } from 'src/app/shared/components/attach-certificate-document/attach-certificate-info-row/attach-certificate-info-row.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { SignatureAndPhotoComponent } from './new-application/signature-and-photo/signature-and-photo.component';
// tslint:disable-next-line: max-line-length
import { ApplicationSummaryExtendedHeaderComponent } from './submitted-application/application-summary-extended-header/application-summary-extended-header.component';
// tslint:disable-next-line: max-line-length
import { PersonalInfoInitialFormComponent } from './new-application/personal-info-section/personal-info-initial-form/personal-info-initial-form.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
// tslint:disable-next-line: max-line-length
import { CorrespondenceInfoDisplayComponent } from './new-application/correspondence-info/correspondence-info-display/correspondence-info-display.component';
import { ServiceOptionDisplayComponent } from './new-application/service-options/service-option-display/service-option-display.component';
// tslint:disable-next-line: max-line-length
import { CardDeliveryDisplayComponent } from './new-application/card-delivery-options/card-delivery-display/card-delivery-display.component';
// tslint:disable-next-line: max-line-length
import { CertificatesInfoDisplayComponent } from './new-application/certificates-section/certificates-info-display/certificates-info-display.component';
import { CertificateInfoComponent } from './new-application/certificates-section/certificate-info.component';
// tslint:disable-next-line: max-line-length
import { PersonalInfoDisplayShortComponent } from './new-application/personal-info-section/personal-info-display-short/personal-info-display-short.component';
import { PhotoEditorComponent } from 'src/app/shared/components/photo-editor/photo-editor.component';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { MY_FORMATS } from 'src/app/shared/models/constants/date-formats';
import { AdrExamPeopleComponent } from './new-application/adr-exam-people/adr-exam-people.component';
// tslint:disable-next-line: max-line-length
import { PersonalInfoApproverComponent } from './new-application/personal-info-section/personal-info-approver/personal-info-approver.component';
// tslint:disable-next-line: max-line-length
import { DrivingLicenceApproverComponent } from './new-application/driving-licence-section/driving-licence-approver/driving-licence-approver.component';
// tslint:disable-next-line: max-line-length
import { CertificatesApproverComponent } from './new-application/certificates-section/certificates-approver/certificates-approver.component';
import { ServiceApproverComponent } from './new-application/service-options/service-approver/service-approver.component';
import { SignatureAndPhotoApproverComponent } from './new-application/signature-and-photo/signature-and-photo-approver/signature-and-photo-approver.component';
import { AdrExamServiceOptionsComponent } from './new-application/adr-exam-service-options/adr-exam-service-options.component';
import { ExamOrgUnitSelectionComponent } from './new-application/exam-org-unit-selection/exam-org-unit-selection.component';
import { ExamProtocolSelectionComponent } from './new-application/exam-protocol-selection/exam-protocol-selection.component';
import { ExamMunicipalitySelectionComponent } from './new-application/exam-municipality-selection/exam-municipality-selection.component';
import { ExamRequiredDocumentsComponent } from './new-application/exam-required-documents/exam-required-documents.component';
import { ExamCategorySelectionComponent } from './new-application/exam-category-selection/exam-category-selection.component';

@NgModule({
	declarations: [
		ApplicationComponent,
		AttachDocumentRowComponent,
		AttachSingleDocumentComponent,
		AttachMultipleDocumentsComponent,
		AttachCertificateInfoRowComponent,
		AttachCertificateDocumentComponent,
		ApplicationSummaryExtendedHeaderComponent,
		CorrespondenceInfoComponent,
		CardDeliveryOptionsComponent,
		DrivingLicenseInfoDisplayComponent,
		DrivingLicenseInfoFormComponent,
		DrivingLicenseInfoComponent,
		CertificateInfoComponent,
		PaymentComponent,
		PersonalInfoComponent,
		PersonalInfoDisplayedComponent,
		PersonalInfoFormComponent,
		ServiceOptionComponent,
		SigningComponent,
		StepsComponent,
		SubmittedApplicationComponent,
		TitleComponent,
		DisplayAddressComponent,
		PaymentComponent,
		NewApplicationComponent,
		SubmittedApplicationComponent,
		SignatureAndPhotoComponent,
		PersonalInfoInitialFormComponent,
		CorrespondenceInfoDisplayComponent,
		ServiceOptionDisplayComponent,
		CardDeliveryDisplayComponent,
		CertificatesInfoDisplayComponent,
		PersonalInfoDisplayShortComponent,
		PhotoEditorComponent,
		PersonalInfoInitialFormComponent,
		AdrExamPeopleComponent,
		PersonalInfoApproverComponent,
		DrivingLicenceApproverComponent,
		CertificatesApproverComponent,
		ServiceApproverComponent,
		SignatureAndPhotoApproverComponent,
		AdrExamServiceOptionsComponent,
		ExamOrgUnitSelectionComponent,
		ExamProtocolSelectionComponent,
		ExamMunicipalitySelectionComponent,
		ExamRequiredDocumentsComponent,
		ExamCategorySelectionComponent
	],
	imports: [
		ApplicationRoutingModule,
		CommonModule,
		RouterModule,
		FormsModule,
		ReactiveFormsModule,
		TranslationModule,
		NgxFileDropModule,
		MatDatepickerModule,
		MatFormFieldModule,
		MatNativeDateModule,
		MatInputModule,
		SharedModule,
		DragDropModule,
		PdfViewerModule,
		ImageCropperModule,
		MatAutocompleteModule
	],
	providers: [
		MatDatepickerModule,
		DragDropModule,
		{ provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
		{ provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
	]
})
export class ApplicationModule { }
