import { AdrExamModuleResultDto } from "src/app/shared/interfaces/adr-exam-module-result-dto";

export class AdrExamModuleResult {
    module: string;
	isPassed: boolean;

    constructor(dto: AdrExamModuleResultDto) {
        this.module = dto.module;
        this.isPassed = dto.isPassed;
    }

    get isPassedText(): string {
        if (this.isPassed === true) {
            return "Да";
        }
        return "за изпит";
    }
}