import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { ExamApplicationService } from 'src/app/core/services/exam-application.service';
import { Steps } from 'src/app/shared/enums/steps';
import { AdrExamPersonSelectionDto } from 'src/app/shared/interfaces/adr-exam-person-selection-dto';
import { ConsultantExamLearningPlanSelectionDto } from 'src/app/shared/interfaces/consultant-exam-learning-plan-selection-dto';
import { ServiceOptions } from '../adr-exam-service-options/adr-exam-service-options.component';
import { AdrExamPersonSelection } from './adr-exam-person-selection.model';
import { ConsultantExamLearningPlanSelection } from './consultant-exam-learning-plan-selection';

@Component({
  selector: 'app-adr-exam-people',
  templateUrl: './adr-exam-people.component.html',
  styleUrls: []
})
export class AdrExamPeopleComponent implements OnInit, AfterViewInit {

	@ViewChild('adrExamPeopleHtmlElement') htmlElement: { nativeElement: HTMLElement; };

	@Input() public number: number;
	@Input() isDraft: boolean;
	@Input() applicationId: number;
	
	public adrServiceOption: ServiceOptions = null;
	@Input() public set setAdrServiceOption(adrServiceOption: ServiceOptions) {
		this.adrServiceOption = adrServiceOption;

		if (this.adrServiceOption === ServiceOptions.EXTENSION) {
			this.loadAdrConsultantExamLearningPlansForExtension(this.applicationId);
		} else {
			this.loadAdrExamPeople(this.applicationId);
		}
	}

	@Output() public emitIsEditing = new EventEmitter<Steps>();
	@Output() public emitSelectedExamPerson = new EventEmitter<AdrExamPersonSelection>();
	@Output() public emitSelectedLearningPlan = new EventEmitter<ConsultantExamLearningPlanSelection>();

	adrExamPeople: AdrExamPersonSelection[] = [];

	selectedAdrExamPerson: AdrExamPersonSelection = null;
	@Input() public set setSelectedAdrExamPerson(examPerson: AdrExamPersonSelection) {
		if (!examPerson) {
			return;
		}
		if (this.isDraft === false) {
			this.adrExamPeople.push(examPerson);
			this.selectedAdrExamPerson = examPerson;
			this.appStepsElementService.canSeeAdrExamPeople = true;
		} else {
			throw new Error("selectedAdrExamPerson can be set only when isDraft is false");
		}
	}

	adrLearningPlans: ConsultantExamLearningPlanSelection[] = [];
	selectedAdrLearningPlan: ConsultantExamLearningPlanSelection = null;
	@Input() public set setSelectedAdrLearningPlan(learningPlan: ConsultantExamLearningPlanSelection) {
		if (!learningPlan) {
			return;
		}
		if (this.isDraft === false) {
			this.adrLearningPlans.push(learningPlan);
			this.selectedAdrLearningPlan = learningPlan;
			this.appStepsElementService.canSeeAdrExamPeople = true;
		} else {
			throw new Error("selectedAdrLearningPlan can be set only when isDraft is false");
		}
	}

	public isLoading = false;

	constructor(
		private appStepsElementService: ApplicationStepsElementsService,
		private examService: ExamApplicationService
	) { }

	ngOnInit(): void {
	}

	ngAfterViewInit(): void {
		setTimeout(() => {
			this.appStepsElementService.adrExamPeopleEl = this.htmlElement.nativeElement;
			this.appStepsElementService.scrollToStep(Steps.ADR_EXAM_PEOPLE);
			this.emitIsEditing.emit(Steps.ADR_EXAM_PEOPLE);
		});
	}

	private loadAdrExamPeople(applicationId: number): void {
		if (this.isDraft === false) {
			return;
		}
		this.adrExamPeople.splice(0, this.adrExamPeople.length);
		this.adrLearningPlans.splice(0, this.adrLearningPlans.length);

		this.isLoading = true;
		this.examService.getAdrExamPeopleForSelection(applicationId).subscribe((dtos: AdrExamPersonSelectionDto[]) => {
			this.adrExamPeople = dtos.map(dto => {
				return new AdrExamPersonSelection(dto);
			});
		}).add(() => {
			this.isLoading = false;
		});
	}

	private loadAdrConsultantExamLearningPlansForExtension(applicationId: number): void {
		this.adrExamPeople.splice(0, this.adrExamPeople.length);
		this.adrLearningPlans.splice(0, this.adrLearningPlans.length);

		this.isLoading = true;
		this.examService.getConsultantExamLearningPlansForExtension(applicationId)
			.subscribe((dtos: ConsultantExamLearningPlanSelectionDto[]) => {
				this.adrLearningPlans = dtos.map(dto => {
					return new ConsultantExamLearningPlanSelection(dto);
				});
			}).add(() => {
				this.isLoading = false;
			});
	}

	public selectAdrExamPerson(adrExamPerson: AdrExamPersonSelection) {
		this.selectedAdrExamPerson = adrExamPerson;
	}

	public selectAdrLearningPlan(adrLearningPlan: ConsultantExamLearningPlanSelection) {
		this.selectedAdrLearningPlan = adrLearningPlan;
	}

	public onContinueClicked(): void {
		if (this.adrServiceOption === ServiceOptions.EXTENSION) {
			this.emitSelectedLearningPlan.next(this.selectedAdrLearningPlan);
			this.appStepsElementService.continueToNextStepFromCurrent(Steps.ADR_EXAM_PEOPLE);
		} else {
			this.emitSelectedExamPerson.next(this.selectedAdrExamPerson);
			this.appStepsElementService.continueToNextStepFromCurrent(Steps.ADR_EXAM_PEOPLE);
		}
	}
}
