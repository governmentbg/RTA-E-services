import { AdrExamPersonSelectionDto } from "src/app/shared/interfaces/adr-exam-person-selection-dto";
import { AdrExamModuleResult } from "./adr-exam-module-result.model";

export class AdrExamPersonSelection {

    id: number;
	learningPlanName: string;
	learningValidTo: Date;
	examModuleResults: AdrExamModuleResult[];

    constructor(dto: AdrExamPersonSelectionDto) {
        this.id = dto.id;
        this.learningPlanName = dto.learningPlanName;
        this.learningValidTo = dto.learningValidTo;
        this.examModuleResults = dto.examModuleResults ? dto.examModuleResults.map(moduleResultDto => {
            return new AdrExamModuleResult(moduleResultDto);
        }) : [];
    }
}