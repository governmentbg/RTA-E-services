import { ConsultantExamLearningPlanSelectionDto } from "src/app/shared/interfaces/consultant-exam-learning-plan-selection-dto";

export class ConsultantExamLearningPlanSelection {

    id: number;
	description: string;

    constructor(dto: ConsultantExamLearningPlanSelectionDto) {
		this.id = dto.id;
		this.description = dto.description;
    }
}