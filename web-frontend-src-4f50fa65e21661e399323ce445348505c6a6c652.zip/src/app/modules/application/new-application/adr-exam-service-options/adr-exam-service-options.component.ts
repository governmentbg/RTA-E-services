import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { Steps } from 'src/app/shared/enums/steps';

export enum ServiceOptions {
	INITIAL = 'INITIAL',
	EXTENSION = 'EXTENSION',
}

@Component({
  selector: 'app-adr-exam-service-options',
  templateUrl: './adr-exam-service-options.component.html'
})
export class AdrExamServiceOptionsComponent implements OnInit, AfterViewInit {

	@ViewChild('adrExamServiceOptionsHtmlElement') htmlElement: { nativeElement: HTMLElement; };

	@Input() number: number;
	@Input() isDraft: boolean;
	@Output() public emitServiceType = new EventEmitter<ServiceOptions>();

	ServiceOptions = ServiceOptions;

	selectedServiceOption: ServiceOptions = null;
	@Input() public set setSelectedServiceOption(serviceOption: ServiceOptions) {
		if (!serviceOption) {
			return;
		}

		this.selectedServiceOption = serviceOption;
	}

	constructor(
		private appStepsElementService: ApplicationStepsElementsService
	) { }

	ngOnInit(): void {
	}

	ngAfterViewInit(): void {
		setTimeout(() => {
			this.appStepsElementService.adrExamServiceOptionsEl = this.htmlElement.nativeElement;
			this.appStepsElementService.scrollToStep(Steps.ADR_EXAM_SERVICE_OPTIONS);
			// this.emitIsEditing.emit(Steps.ADR_EXAM_SERVICE_OPTIONS);
		});
	}

	selectServiceOption(serviceOption: ServiceOptions) {
		this.selectedServiceOption = serviceOption;
	}

	continue() {
		if (!this.selectedServiceOption) {
			throw new Error("No service option is selected.");
		}
		this.emitServiceType.next(this.selectedServiceOption);
		this.appStepsElementService.continueToNextStepFromCurrent(Steps.ADR_EXAM_SERVICE_OPTIONS);
	}
}
