import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DeliveryInfo } from 'src/app/shared/models/delivery-info';
import { DeliveryTypes } from 'src/app/shared/enums/delivery-types';

@Component({
	selector: 'app-card-delivery-display',
	templateUrl: './card-delivery-display.component.html'
})
export class CardDeliveryDisplayComponent implements OnInit {
	@Input() isDraft: boolean;
	@Input() public number: number;
	@Input() public deliveryDto: DeliveryInfo;
	@Output() public emitEditSection = new EventEmitter<DeliveryInfo>();

	showContinueButton = true;

	deliveryTypes = DeliveryTypes;
	constructor() { }

	ngOnInit(): void {}

	editSection() {
		this.emitEditSection.next(this.deliveryDto);
		this.showContinueButton = true;
	}
}
