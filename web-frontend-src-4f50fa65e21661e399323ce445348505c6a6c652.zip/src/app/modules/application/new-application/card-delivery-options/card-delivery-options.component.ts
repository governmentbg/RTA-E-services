import { Component, OnInit, Input, ViewChild, AfterViewInit, Output, EventEmitter } from '@angular/core';
import { ApplicationService } from 'src/app/core/services/application.service';
import { OrgUnit } from 'src/app/shared/models/org-unit';
import { OrgUnitDto } from 'src/app/shared/dtos/org-unit-dto';
import { ApplicantContactDetails } from 'src/app/shared/models/applicant-contact-details';
import { ApplicantContactDetailsDto } from 'src/app/shared/interfaces/applicant-contact-details-dto';
import { Language } from 'angular-l10n';
import { ContactTypes } from 'src/app/shared/enums/contact-types';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { Steps } from 'src/app/shared/enums/steps';
import { AddressForm } from 'src/app/shared/utils/address-form';
import { DeliveryTypes } from 'src/app/shared/enums/delivery-types';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { MILESTONE_STATUSES } from 'src/app/shared/enums/milestone-statuses';
import { AddressDto } from 'src/app/shared/dtos/address-dto';
import { DeliveryInfo } from 'src/app/shared/models/delivery-info';
import { DeliveryInfoDto } from 'src/app/shared/dtos/delivery-info-dto';
import { APPLICATION_TYPE } from 'src/app/shared/enums/application-types';
import { CARD_ISSUING_REASONS } from 'src/app/shared/models/constants/card-issuing-reasons';

@Component({
	selector: 'app-card-delivery-options',
	templateUrl: './card-delivery-options.component.html'
})
export class CardDeliveryOptionsComponent implements OnInit, AfterViewInit {

	@Language() language: string;
	@Input() public number: number;
	@Input() isDraft: boolean;
	@Input() applicationId: number;
	@Input() applicationTypeId: number;
	@Input() issuingReasonId: number;
	@Input() deliveryInfo: DeliveryInfo;
	@Input() isEditing: Steps;
	@Output() public emitIsEditing = new EventEmitter<Steps>();
	@ViewChild('deliveryHtmlElement') htmlElement: { nativeElement: HTMLElement; };

	orgUnits: OrgUnit[] = [];
	selectedOrgUnitName: string = null;
	selectedOrgUnit: OrgUnit;
	addressForm: AddressForm;

	applicantContactDetails: ApplicantContactDetails;
	isInPersonSelected: boolean;
	isToAddressSelected: boolean;
	isPermanentAddressSelected: boolean;
	isCurrentAddressSelected: boolean;
	isOtherAddressSelected: boolean;
	selectedOrgUnitInvalid: boolean;

	showDisplayInfo: boolean;
	canShowToggle: boolean;

	constructor(
		private applicationService: ApplicationService,
		private nomenclatureService: NomenclatureService,
		private appStepsElementService: ApplicationStepsElementsService
	) { }

	ngOnInit() {
		if (!this.isDraft && this.deliveryInfo) {
			this.showDisplayInfo = true;
			return;
		}
		// return when logic to save delivery address for courier works
		// if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_TACHO_CARD
		// 	&& this.issuingReasonId !== CARD_ISSUING_REASONS.INITIAL_ISSUING.id) {
		// 		this.canShowToggle = false;
		// 		this.toggleInPerson();
		// } else {
		// 	this.canShowToggle = true;
		// }
		this.toggleInPerson();
		this.addressForm = new AddressForm();
		this.nomenclatureService.getAllOrgUnits()
			.subscribe((orgUnitDtos: OrgUnitDto[]) => {
				orgUnitDtos.forEach(orgUnitDto => {
					this.orgUnits.push(new OrgUnit(orgUnitDto));
				});
			});

		this.applicationService.getApplicantContactDetails(this.applicationId)
			.subscribe((dto: ApplicantContactDetailsDto) => {
				this.applicantContactDetails = new ApplicantContactDetails(dto);
			});

		if (this.deliveryInfo != null) {
			if (this.deliveryInfo.deliveryTypeId === DeliveryTypes.RECEIVE_IN_PERSON_ID) {
				this.isInPersonSelected = true;
			} else {
				this.isToAddressSelected = true;
				this.addressForm.setAddressFormInfo(this.deliveryInfo.address);
			}
			this.showDisplayInfo = true;
		}
	}

	ngAfterViewInit() {
		setTimeout(() => {
			this.appStepsElementService.deliveryEl = this.htmlElement.nativeElement;
			if (this.isDraft) {
				this.appStepsElementService.scrollToStep(Steps.DELIVERY);
			}
		})
	}

	toggleInPerson() {
		this.isInPersonSelected = true;
		// this.isInPersonSelected = !this.isInPersonSelected;
		this.isToAddressSelected = false;
	}

	toggleToAddress() {
		this.isToAddressSelected = !this.isToAddressSelected;
		this.isInPersonSelected = false;
	}

	selectPermanentAddress() {
		this.isPermanentAddressSelected = true;
		this.isCurrentAddressSelected = false;
		this.isOtherAddressSelected = false;
	}

	selectCurrentAddress() {
		this.isPermanentAddressSelected = false;
		this.isCurrentAddressSelected = true;
		this.isOtherAddressSelected = false;
	}

	selectOtherAddress() {
		this.isPermanentAddressSelected = false;
		this.isCurrentAddressSelected = false;
		this.isOtherAddressSelected = true;
	}

	saveDeliveryInfo() {
		let deliveryDto = new DeliveryInfoDto();
		if (!this.isToAddressSelected && !this.selectedOrgUnit) {
			this.selectedOrgUnitInvalid = true;
			this.addressForm.formGroup.markAsUntouched();
		} else if ((!this.isToAddressSelected && this.selectedOrgUnit)
			|| (this.isToAddressSelected && !this.isOtherAddressSelected)
			|| (this.isToAddressSelected && this.isOtherAddressSelected && this.addressForm.isValid())) {
			this.selectedOrgUnitInvalid = false;
			deliveryDto.orgUnitDto = this.selectedOrgUnit ? this.selectedOrgUnit : null;
			deliveryDto.deliveryTypeId = DeliveryTypes.RECEIVE_IN_PERSON_ID;

			if (this.isToAddressSelected) {
				deliveryDto.orgUnitDto = null;
				let addressDto = new AddressDto();
				if (this.isOtherAddressSelected) {
					addressDto = this.addressForm.toRequestDto();
					addressDto.addressTypeId = ContactTypes.ADDITIONAL_ADDRESS;
				} else if (this.isCurrentAddressSelected) {
					addressDto = this.applicantContactDetails.currentAddress.convertToAddressDto();
					addressDto.addressTypeId = ContactTypes.CURRENT_ADDRESS;
				} else if (this.isPermanentAddressSelected) {
					addressDto = this.applicantContactDetails.permanentAddress.convertToAddressDto();
					addressDto.addressTypeId = ContactTypes.PERMANENT_ADDRESS;
				}
				deliveryDto.address = addressDto;
				deliveryDto.deliveryTypeId = DeliveryTypes.RECEIVE_BY_ADDRESS_ID;
			}
			if (((this.isOtherAddressSelected && this.addressForm.isValid()) || !this.isOtherAddressSelected)
				&& !this.appStepsElementService.checkIfIsEditingAndSet(Steps.DELIVERY)) {
				if (!deliveryDto.deliveryTypeId) {
					deliveryDto = this.deliveryInfo.convertToDeliveryIntoDto();
				}
				this.applicationService.saveDeliveryInfo(this.applicationId, deliveryDto).subscribe(
					(response) => {
						this.deliveryInfo = new DeliveryInfo(response);
						this.showDisplayInfo = true;
						this.appStepsElementService.continueToNextStepFromCurrent(Steps.DELIVERY);
						this.appStepsElementService.setIsEditingToEmptyStep();
					},
					(error) => PopUpService.showPopUp(DEFAULT_POP_UPS.error)).add(() => {
						this.appStepsElementService.setIsEditingToEmptyStep();
					});
			}
		}
	}

	editSection(deliveryDto: DeliveryInfo) {
		if (this.appStepsElementService.checkIfIsEditingAndSet(Steps.DELIVERY)) {
			return;
		}
		this.applicationService.setToMilestone(this.applicationId, MILESTONE_STATUSES.SERVICE_OPTION_SELECTED).subscribe(
			() => {
				this.deliveryInfo = deliveryDto;
				if (deliveryDto.orgUnit && deliveryDto.orgUnit.address) {
					this.isToAddressSelected = false;
					this.isInPersonSelected = true;
					this.selectedOrgUnitName = deliveryDto.orgUnit.name;
					this.selectedOrgUnit = deliveryDto.orgUnit;

				} else {
					this.isToAddressSelected = true;
					this.isInPersonSelected = false;
					if (deliveryDto.address.addressTypeId === ContactTypes.PERMANENT_ADDRESS) {
						this.selectPermanentAddress();
					} else if (deliveryDto.address.addressTypeId === ContactTypes.CURRENT_ADDRESS) {
						this.selectCurrentAddress();
					} else if (deliveryDto.address.addressTypeId === ContactTypes.ADDITIONAL_ADDRESS) {
						this.addressForm.setAddressFormInfo(deliveryDto.address);
						this.selectOtherAddress();
					}
				}
				this.showDisplayInfo = false;
			},
			(error) => PopUpService.showPopUp(DEFAULT_POP_UPS.error)
		);
	}

	setNewOrgUnit(name: string) {
		this.selectedOrgUnit = this.orgUnits.filter(unit => unit.name === name)[0];
	}

}
