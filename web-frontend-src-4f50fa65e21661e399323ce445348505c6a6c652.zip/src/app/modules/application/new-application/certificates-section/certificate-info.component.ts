import { Component, OnInit, Input, ViewChild, AfterViewInit, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { DqcService } from 'src/app/core/services/dqc.service';
import { Certificate } from 'src/app/shared/models/certificate';
import { AdrModule } from 'src/app/shared/models/adr-module';
import { AttachDocumentTypes, ATTACHED_DOCUMENT_TYPE } from 'src/app/shared/enums/attached-document-types';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { AttachedDocumentShortInfo } from 'src/app/shared/models/attached-document-short-info';
import { APPLICATION_TYPE } from 'src/app/shared/enums/application-types';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { Steps } from 'src/app/shared/enums/steps';
import { CertificateDto } from 'src/app/shared/dtos/certificate-dto';
import { AdrCardService } from 'src/app/core/services/adr-card.service';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { AdrModuleDto } from 'src/app/shared/dtos/adr-module-dto';
import { ApplicationIdWrapperDto } from 'src/app/shared/dtos/application-id-wrapper-dto';
import { ApplicationService } from 'src/app/core/services/application.service';
import { MILESTONE_STATUSES } from 'src/app/shared/enums/milestone-statuses';
import { Translation } from 'src/app/shared/models/translation';
import { CERTIFICATE_TYPE_ID_TO_ATTACHED_DOCUMENT_TYPE_ID } from 'src/app/shared/models/constants/attached-documents/certificate-type-id';
import { DocumentService } from 'src/app/core/services/document.service';
import { SelectedCertificatesAndModulesDto } from 'src/app/shared/dtos/selected-certificates-and-modules-dto';
import { User } from 'src/app/shared/models/user';
import { DqcCardDto } from 'src/app/shared/dtos/dqc-card-dto';
import { SimpleCertificateDto } from 'src/app/shared/dtos/simple-certificate-dto';

@Component({
	selector: 'app-certificate-info',
	templateUrl: './certificate-info.component.html'
})
export class CertificateInfoComponent implements OnInit, AfterViewInit {
	@Input() public number: number;
	@Input() applicationId: number;
	@Input() applicationTypeId: number;
	@Input() dqcCertificates: Certificate[];
	@Input() adrModules: AdrModule[];
	@Input() isDraft: boolean;
	@Input() user: User;
	@Input() isEditing: Steps;
	@Input() attachedDocuments: Translation[];
	@Output() public emitIsEditing = new EventEmitter<Steps>();
	$isCertificateContinueButtonClicked = new BehaviorSubject(false);
	@ViewChild('certificateHtmlElement') htmlElement: { nativeElement: HTMLElement; };
	convertCertificateTypeIdToAttachedDocTypeId = CERTIFICATE_TYPE_ID_TO_ATTACHED_DOCUMENT_TYPE_ID;

	newCertMenuVisible: boolean;
	attachedDocumentType: AttachDocumentTypes;
	attachedDocumentTypeId: number;
	uploadedDocumentTypeIds: number[] = [];
	uploadedPagesInfo: AttachedDocumentShortInfo = null;
	showContinueButton: boolean;
	hasChosenCertificateFromRegister: boolean;
	dateFormat = S_VARIABLES.DATE_FORMAT;
	hasError = false;
	isLoading: boolean;
	displayInfo: boolean;
	hasErrorInAttachedCertificate = false;

	// *** DQC ***
	isDqcApplication: boolean;
	certificatesFromRegister: Certificate[] = [];
	uploadedCertificatesFromAttachment: Certificate[] = [];
	certificatesToDisplay: Certificate[] = [];
	allDqcCards: DqcCardDto[] = [];
	allDqcCertificates: SimpleCertificateDto[] = [];

	// *** ADR card ***
	isAdrCardApplication: boolean;
	modulesFromRegister: AdrModule[] = [];
	uploadedModulesFromAttachment: AdrModule[] = [];
	modulesToDisplay: AdrModule[] = [];

	MODULE_TYPE_BASIC_ID = 1;

	constructor(
		private dqcService: DqcService,
		private adrCardService: AdrCardService,
		private appStepsElementService: ApplicationStepsElementsService,
		private applicationService: ApplicationService,
		private reference: ChangeDetectorRef,
		private documentService: DocumentService,
	) { }

	ngOnInit() {
		this.setAttachedDocType();
		if (this.dqcCertificates != null) {
			this.certificatesToDisplay = this.dqcCertificates;
			const hasManuallyAttachedCertificate = this.checkHasManuallyAttachedCertificate();
			if (hasManuallyAttachedCertificate && this.isDraft) {
				const hasFiles = this.checkAllManuallyAttachedCertificatesHasAndAttachedFile();
				if (!hasFiles) {
					if (this.user.isEFaceApplicant()) {
						this.getUploadedCertificatesModulesFromUser();
					} else {
						this.getAllCertificatesOrModules(null);
					}
					return;
				}
			}
			this.displayInfo = true;
		} else if (this.adrModules != null) {
			this.modulesToDisplay = this.adrModules;
			this.displayInfo = true;
		} else {
			if (this.user.isEFaceApplicant()) {
				this.newCertMenuVisible = true;
				this.showContinueButton = true;
			} else {
				this.getAllCertificatesOrModules(null);
			}
		}
	}

	ngAfterViewInit() {
		setTimeout(() => {
			this.appStepsElementService.certificateEl = this.htmlElement.nativeElement;
			if (this.isDraft) {
				this.appStepsElementService.scrollToStep(Steps.CERTIFICATE);
			}
		})
	}

	setAttachedDocType() {
		if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_DQC) {
			this.isDqcApplication = true;
			this.attachedDocumentTypeId = ATTACHED_DOCUMENT_TYPE.DQC_CERTIFICATE;
		} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_CARD) {
			this.isAdrCardApplication = true;
			this.attachedDocumentTypeId = ATTACHED_DOCUMENT_TYPE.ADR_MODULE;
		}
	}

	private getAllCertificatesOrModules(selectedCertOrModules: SelectedCertificatesAndModulesDto) {
		this.isLoading = true;
		if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_DQC) {
			this.getReadOnlyDqcCards();
			this.getReadOnlyDqcCertificates();
			selectedCertOrModules
				? this.getAllCertificatesFromRegisterThenUploadedWhenEditing(selectedCertOrModules.certificates)
				: this.getAllCertificatesFromRegisterThenUploaded();
		} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_CARD) {
			selectedCertOrModules
				? this.getAllModulesFromRegisterThenUploadedWhenEditing(selectedCertOrModules.modules)
				: this.getAllModulesFromRegisterThenUploaded();
		}
	}

	getAllCertificatesFromRegisterThenUploaded() {
		this.certificatesFromRegister = [];
		this.isLoading = true;
		this.dqcService.getCertificates(this.applicationId)
			.subscribe((certificates: CertificateDto[]) => {
				if (certificates) {
					certificates.forEach(certificateDto => {
						this.certificatesFromRegister.push(new Certificate(certificateDto));
					});
				}
				this.preselectNewestCertificates();
			}).add(() => this.getUploadedCertificatesModulesFromUser());
	}

	getAllCertificatesFromRegisterThenUploadedWhenEditing(selectedCertificates: Certificate[]) {
		this.certificatesFromRegister = [];
		this.dqcService.getCertificates(this.applicationId)
			.subscribe((certificates: CertificateDto[]) => {
				if (certificates) {
					certificates.forEach(certificateDto => {
						const cert = new Certificate(certificateDto);
						selectedCertificates.forEach((selCert) => {
							if (selCert.certificateNumber === cert.certificateNumber) {
								cert.isSelected = true;
							}
						});
						this.certificatesFromRegister.push(cert);
					});
				}
			}).add(() => this.isLoading = false);
		if (selectedCertificates) {
			selectedCertificates.forEach(cert => {
				if (cert.attached) {
					this.uploadedCertificatesFromAttachment.push(cert);
					this.newCertMenuVisible = true;
				}
			});
		}
		this.showContinueButton = true;
	}

	getAllModulesFromRegisterThenUploaded() {
		this.modulesFromRegister = [];
		this.isLoading = true;
		this.adrCardService.getModulesFromProxy(this.applicationId)
			.subscribe((modules: AdrModuleDto[]) => {
				if (modules) {
					modules.forEach(moduleDto => {
						this.modulesFromRegister.push(new AdrModule(moduleDto));
					});
					this.preselectAllModulesFromRegister();
				}
			}).add(() => this.getUploadedCertificatesModulesFromUser());
	}

	getAllModulesFromRegisterThenUploadedWhenEditing(selectedModules: AdrModule[]) {
		this.modulesFromRegister = [];
		this.adrCardService.getModulesFromProxy(this.applicationId)
			.subscribe((modules: AdrModuleDto[]) => {
				if (modules) {
					modules.forEach(moduleDto => {
						const mod = new AdrModule(moduleDto);
						selectedModules.forEach((selMod) => {
							if (selMod.typeId === mod.typeId && selMod.issueDate === mod.issueDate) {
								mod.isSelected = true;
							}
						});
						this.modulesFromRegister.push(mod);
					});
				} else {	
					selectedModules.forEach((selMod) => {
						if (!selMod.attached) {
							this.modulesFromRegister.push(selMod);
						}
					});
				}
			}).add(() => this.isLoading = false);;

		selectedModules.forEach((mod) => {
			if (mod.attached) {
				this.uploadedModulesFromAttachment.push(mod);
				this.newCertMenuVisible = true;
			}
		});
		this.showContinueButton = true;
	}

	saveOrDeleteCertificateByToggleButton(certificate: Certificate) {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		if (!certificate.isSelected) {
			this.saveChosenCertificate(certificate);
			return;
		}
		this.deleteChosenCertificate(certificate);
	}

	showAddNewCertMenu() {
		this.showContinueButton = true;
		this.newCertMenuVisible = true;
		this.hasError = false;
	}

	hideAddNewCertMenu(hide: boolean) {
		this.newCertMenuVisible = !hide;
		if (hide) {
			this.hasErrorInAttachedCertificate = false;
		}
	}

	saveChosenCertificate(certificate: Certificate) {
		const dto = new CertificateDto();
		dto.permitNumber = certificate.permitNumber;
		dto.certificateNumber = certificate.certificateNumber;
		dto.typeId = certificate.typeId;
		dto.legalBasisId = certificate.legalBasisId;
		dto.issuedOn = certificate.issuedOn;
		dto.trainingStart = certificate.trainingStart;
		dto.trainingEnd = certificate.trainingEnd;
		dto.attached = false;
		this.dqcService.saveCertificate(this.applicationId, dto).subscribe(
			() => {
				certificate.isSelected = true;
				certificate.attached = false;
				this.showContinueButton = true;
				this.hasChosenCertificateFromRegister = true;
				this.hasError = false;
				this.isLoading = false;
			},
			(errorResponse) => {
				this.isLoading = false;
				if (errorResponse.error) {
					if (errorResponse.error.error === 'RepeatingTypesException') {
						PopUpService.showPopUp(DEFAULT_POP_UPS.error_certificate_of_type_already_exists);
					}
					return;
				}
				PopUpService.showPopUp(DEFAULT_POP_UPS.error);
			}
		).add(() => this.isLoading = false);
	}

	deleteChosenCertificate(certificate: Certificate) {
		this.dqcService.deleteCertificate(this.applicationId, certificate.typeId).subscribe(
			() => {
				certificate.isSelected = false;
				certificate.attached = false;
				this.setHasChosenCertificateFromRegister();
			},
			(error) => {
				PopUpService.showPopUp(DEFAULT_POP_UPS.error);
			}
		).add(() => this.isLoading = false);
	}

	setHasChosenCertificateFromRegister() {
		const certificateFromRegister = this.certificatesToDisplay.find(certificate => certificate.attached === false);
		if (certificateFromRegister) {
			this.hasChosenCertificateFromRegister = true;
		} else {
			this.hasChosenCertificateFromRegister = false;
		}
	}

	setHasChosenModuleFromRegister() {
		const moduleFromRegister = this.modulesToDisplay.find(module => module.attached === false);
		if (moduleFromRegister) {
			this.hasChosenCertificateFromRegister = true;
		} else {
			this.hasChosenCertificateFromRegister = false;
		}
	}

	getUploadedCertificatesModulesFromUser() {
		if ((this.dqcCertificates && this.dqcCertificates.length > 0) || (this.certificatesToDisplay && this.certificatesToDisplay.length > 0)) {
			this.showContinueButton = true;
			const uploadedCertificates = this.dqcCertificates != null ? this.dqcCertificates : this.certificatesToDisplay;
			this.uploadedCertificatesFromAttachment = uploadedCertificates.filter(certificate => certificate.attached === true);
			this.setToggleOnForSelectedCertificatesFromRegister();
		} else if ((this.adrModules && this.adrModules.length > 0) || (this.modulesToDisplay && this.modulesToDisplay.length > 0)) {
			this.showContinueButton = true;
			const modules = this.adrModules != null ? this.adrModules : this.modulesToDisplay;
			this.uploadedModulesFromAttachment = modules.filter(module => module.attached === true);
			this.setToggleOnForSelectedModulesFromRegister();
		}
		this.isLoading = false;
	}

	getReadOnlyDqcCards() {
		this.dqcService.getAllCardsReadOnly(this.applicationId).subscribe((response) => {
			this.allDqcCards = [];
			response.forEach((dto)=> this.allDqcCards.push(new DqcCardDto(dto)));
		})
	}

	getReadOnlyDqcCertificates() {
		this.dqcService.getAllCertificatesReadOnly(this.applicationId).subscribe((response) => {
			this.allDqcCertificates = [];
			response.forEach((dto)=> this.allDqcCertificates.push(new SimpleCertificateDto(dto)));
		});
	}

	continueToNextStep() {
		this.$isCertificateContinueButtonClicked.next(true);
		if (!this.appStepsElementService.checkIfIsEditingAndSet(Steps.CERTIFICATE)) {
			if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_CARD) {
				if ((this.newCertMenuVisible && !this.hasErrorInAttachedCertificate) || !this.newCertMenuVisible) {
					this.adrCardService.saveTransitionForSelectedModules(this.applicationId)
						.subscribe(
							(response) => {
								this.modulesToDisplay = [];
								response.forEach((dto) => this.modulesToDisplay.push(new AdrModule(dto)));
								this.displayInfo = true;
								this.appStepsElementService.continueToNextStepFromCurrent(Steps.CERTIFICATE);
							},
							(errorResponse) => {
								this.hasError = true;
								if (errorResponse.error) {
									if (errorResponse.error.error !== "MissingCertificateOrModuleException") {
										PopUpService.showPopUp(DEFAULT_POP_UPS.error_missing_module)
									} else if (errorResponse.error.error !== "MismatchException") {
										PopUpService.showPopUp(DEFAULT_POP_UPS.error_missing_basic_module)
									}
								}
							}
						);
				} else if (this.modulesToDisplay.length === 0 && this.uploadedDocumentTypeIds.length === 0 && !this.hasErrorInAttachedCertificate) {
					this.scrollToErrorInCertificateSection();
				}
			} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_DQC) {
				if ((this.newCertMenuVisible && !this.hasErrorInAttachedCertificate) || !this.newCertMenuVisible) {
					this.dqcService.saveTransitionForSelectedCertificates(new ApplicationIdWrapperDto(this.applicationId))
						.subscribe(
							(response) => {
								this.certificatesToDisplay = [];
								response.forEach((dto) => this.certificatesToDisplay.push(new Certificate(dto)));
								this.displayInfo = true;
								this.appStepsElementService.continueToNextStepFromCurrent(Steps.CERTIFICATE);
							},
							(errorResponse) => {
								if (errorResponse.error) {
									if (errorResponse.error.error !== 'MissingCertificateOrModuleException') {
										PopUpService.showPopUp(DEFAULT_POP_UPS.error_missing_certificate);
									}
								}
							});
				} else if (this.certificatesToDisplay.length === 0 && this.uploadedDocumentTypeIds.length === 0
						&& !this.hasErrorInAttachedCertificate) {
					this.scrollToErrorInCertificateSection();
				}
			}
			this.appStepsElementService.setIsEditingToEmptyStep();
		}
	}

	scrollToErrorInCertificateSection() {
		this.hasError = true;
		this.reference.detectChanges();
		const elements = document.getElementsByClassName('box-validation error');
		elements[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
	}

	getUploadedDocumentTypes(uploadedDocumentTypeId: number[]) {
		this.uploadedDocumentTypeIds = uploadedDocumentTypeId;
		this.showContinueButton = true;
	}

	setHasErrorInAttachedCertificate(hasError: boolean) {
		this.hasErrorInAttachedCertificate = hasError;
	}

	setToggleOnForSelectedModulesFromRegister() {
		this.modulesToDisplay.forEach(uploadedModule => {
			if (!uploadedModule.attached) {
				this.modulesFromRegister.find(module => {
					if ((module.typeId === uploadedModule.typeId) && (module.issueDate === uploadedModule.issueDate)) {
						module.isSelected = true;
						this.hasChosenCertificateFromRegister = true;
					}
				});
			}
		});
	}

	setToggleOnForSelectedCertificatesFromRegister() {
		this.certificatesToDisplay.forEach(uploadedCertificate => {
			if (!uploadedCertificate.attached) {
				this.certificatesFromRegister.find(certificate => {
					if ((certificate.typeId === uploadedCertificate.typeId)
						&& (certificate.legalBasisId === uploadedCertificate.legalBasisId)) {
						certificate.isSelected = true;
						this.hasChosenCertificateFromRegister = true;
					}
				});
			}
		});
	}

	saveOrDeleteModuleByToggleButton(module: AdrModule) {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		if (!module.isSelected) {
			this.saveChosenModule(module);
			return;
		}
		this.deleteChosenModule(module);
	}

	saveChosenModule(module: AdrModule) {
		const isAttаched = false;
		const dto = new AdrModuleDto();
		dto.typeId = module.typeId;
		dto.typeKey = module.typeKey;
		dto.validTo = module.validTo;
		dto.attached = isAttаched;

		this.adrCardService.saveModule(this.applicationId, dto).subscribe(
			() => {
				module.isSelected = true;
				module.attached = false;
				this.showContinueButton = true;
				this.hasChosenCertificateFromRegister = true;
				this.hasError = false;
				this.modulesToDisplay.push(module);
			},
			(errorResponse) => {
				if (errorResponse.error) {
					if (errorResponse.error.error === 'RepeatingTypesException') {
						PopUpService.showPopUp(DEFAULT_POP_UPS.error_certificate_of_type_already_exists);
					} else if (errorResponse.error.error === 'MissingCertificateOrModuleException') {
						PopUpService.showPopUp(DEFAULT_POP_UPS.error_must_choose_basic_module_first);
					}  else if (errorResponse.error.error === 'MismatchException') {
						PopUpService.showPopUp(DEFAULT_POP_UPS.error_date_of_chosen_module_not_correct);
					}
					return;
				}
				PopUpService.showPopUp(DEFAULT_POP_UPS.error);
			}
		).add(() => this.isLoading = false);
	}

	deleteChosenModule(module: AdrModule) {
		this.adrCardService.deleteModule(this.applicationId, module.typeId).subscribe(
			() => {
				module.isSelected = false;
				const index = this.modulesToDisplay.indexOf(module);
				this.modulesToDisplay.splice(index, 1);
				this.setHasChosenModuleFromRegister();
			},
			(error) => {
				PopUpService.showPopUp(DEFAULT_POP_UPS.error);
			}
		).add(() => this.isLoading = false);
	}

	editSection(selectedCertOrModules: SelectedCertificatesAndModulesDto) {
		if (this.appStepsElementService.checkIfIsEditingAndSet(Steps.CERTIFICATE)) {
			return;
		}
		this.applicationService.setToMilestone(this.applicationId, MILESTONE_STATUSES.DRIVING_LICENCE_INFO_ENTERED).subscribe(
			() => {
				this.uploadedCertificatesFromAttachment = [];
				this.uploadedModulesFromAttachment = [];
				if (this.user.isEFaceApplicant()) {
					this.newCertMenuVisible = true;
					this.getUploadedCertificatesModulesFromUser();
				} else {
					this.newCertMenuVisible = false;
					this.getAllCertificatesOrModules(selectedCertOrModules);
				}
				this.displayInfo = false;
			}
		);
	}

	checkHasManuallyAttachedCertificate(): boolean {
		const manuallyUploadedCertificates = this.dqcCertificates.find(certificate => certificate.attached === true);
		if (manuallyUploadedCertificates) {
			return true;
		}
		return false;
	}

	checkAllManuallyAttachedCertificatesHasAndAttachedFile(): boolean {
		return this.documentService.checkAllManuallyUploadedCertificatesHasAndFiles(this.dqcCertificates, this.attachedDocuments);
	}

	preselectNewestCertificates() {
		this.certificatesFromRegister.sort((cert1, cert2) => {
			return cert2.issuedOn.getTime() - cert1.issuedOn.getTime();
		});
		if (this.certificatesFromRegister.length <= 0) {
			return;
		}
		const newestCertDate = this.certificatesFromRegister[0].issuedOn.getTime();
		for (const cert1 of this.certificatesFromRegister) {
			if (cert1.issuedOn.getTime() === newestCertDate) {
				this.saveChosenCertificate(cert1);
				//select second certificate with different type
				for(const cert2 of this.certificatesFromRegister) {
					if (cert1.typeId !== cert2.typeId) {
						this.saveChosenCertificate(cert2);
						break;
					}
				}
				break;
			}
		}
	}

	preselectAllModulesFromRegister() {
		let seconds = 0;
		for (const module of this.modulesFromRegister) {
			setTimeout(() => this.saveChosenModule(module), seconds); // трябва да се запише първо основния, за да не хвърли грешка като записва втория модул
			seconds = seconds + 1000;
		}
	}
}
