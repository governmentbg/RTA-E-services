import { Component, Input, OnInit } from '@angular/core';
import { AdrCardService } from 'src/app/core/services/adr-card.service';
import { ErrorCheckerService } from 'src/app/core/services/error-checker.service';
import { DqcService } from 'src/app/core/services/dqc.service';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { AdrModuleDto } from 'src/app/shared/dtos/adr-module-dto';
import { CertificateDto } from 'src/app/shared/dtos/certificate-dto';
import { AdrModule } from 'src/app/shared/models/adr-module';
import { Certificate } from 'src/app/shared/models/certificate';
import { CERTIFICATE_TYPE_ID_TO_ATTACHED_DOCUMENT_TYPE_ID } from 'src/app/shared/models/constants/attached-documents/certificate-type-id';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';

@Component({
	selector: 'app-certificates-approver',
	templateUrl: './certificates-approver.component.html',
})
export class CertificatesApproverComponent implements OnInit {
	@Input() number: number;
	@Input() applicationId: number;
	@Input() certificatesToDisplay: Certificate[];
	@Input() modulesToDisplay: AdrModule[];
	dateFormat = S_VARIABLES.DATE_FORMAT;
	isLoading = false;
	convertCertificateTypeIdToAttachedDocTypeId = CERTIFICATE_TYPE_ID_TO_ATTACHED_DOCUMENT_TYPE_ID;
	hadCheck = false;
	hasErrors = false;
	differenceCount = 0;

	allCertificatesAreFromServices: boolean;
	showOptions = false;
	index: number;

	certificatesFromServices: Certificate[] = [];
	certificatesFromAttachment: Certificate[] = [];
	certificatesFromCheck: Certificate[] = [];

	modulesFromServices: AdrModule[] = [];
	modulesFromAttachment: AdrModule[] = [];
	modulesFromCheck: AdrModule[] = [];

	constructor(
		private dqcService: DqcService ,
		private adrCardService: AdrCardService,
		private errorCheckerService: ErrorCheckerService
	) { }

	ngOnInit(): void {
		if (this.certificatesToDisplay.length > 0) {
			this.certificatesFromServices = this.certificatesToDisplay.filter(certificate => certificate.attached === false);
			this.certificatesFromAttachment = this.certificatesToDisplay.filter(certificate => certificate.attached === true);
			this.allCertificatesAreFromServices = this.certificatesFromAttachment.length > 0 ? false : true;
		} else if (this.modulesToDisplay.length > 0) {
			this.modulesFromServices = this.modulesToDisplay.filter(module => module.attached === false);
			this.modulesFromAttachment = this.modulesToDisplay.filter(module => module.attached === true);
			this.allCertificatesAreFromServices = this.modulesFromAttachment.length > 0 ? false : true;
		}
	}

	setShowOptions() {
		this.showOptions = true;
	}

	doCertificatesCheck() {
		if (this.isLoading) {
			return;
		}
		this.showOptions = false;
		this.index = null;
		this.isLoading = true;
		this.certificatesFromCheck = [];
		this.dqcService.getCertificateForApprover(this.applicationId)
			.subscribe((certificates: CertificateDto[]) => {
				this.hadCheck = true;
				if (certificates) {
					certificates.forEach(certificateDto => {
						// tslint:disable-next-line: no-shadowed-variable
						const certificate = new Certificate(certificateDto);
						this.certificatesFromCheck.push(certificate);
					});
					this.certificatesFromCheck =
						this.errorCheckerService.setHasErrorsInCertificates(this.certificatesFromAttachment , this.certificatesFromCheck);
					this.differenceCount = 
						this.errorCheckerService.countDifferencesInCertificates(this.certificatesFromAttachment , this.certificatesFromCheck);
					this.hasErrors = !this.checkAllAttachedCertificatesOrModulesHasSameTypeFromCheck(
						this.certificatesFromAttachment, this.certificatesFromCheck);
				} else {
					this.hasErrors = true;
				}
			},
			(errorResponse) => {
				this.hasErrors = true;
				this.setErrorFromResponse(errorResponse);
			}
		).add(() => this.isLoading = false);

	}

	doModulesCheck() {
		if (this.isLoading) {
			return;
		}
		this.showOptions = false;
		this.index = null;
		this.isLoading = true;
		this.modulesFromCheck = [];
		this.adrCardService.getModulesForApprover(this.applicationId)
			.subscribe((modules: AdrModuleDto[]) => {
				this.hadCheck = true;
				if (modules) {
					modules.forEach(moduleDto => {
						const module = new AdrModule(moduleDto);
						this.modulesFromCheck.push(module);
					});
					this.modulesToDisplay =
						this.errorCheckerService.setHasErrorsInModules(this.modulesToDisplay , this.modulesFromCheck);
					this.differenceCount =
						this.errorCheckerService.countDifferencesInModules(this.modulesToDisplay , this.modulesFromCheck);
					this.hasErrors = !this.checkAllAttachedCertificatesOrModulesHasSameTypeFromCheck(
						this.modulesFromAttachment, this.modulesFromCheck);
				} else {
					this.hasErrors = true;
					this.differenceCount = this.modulesToDisplay.length;
					this.modulesToDisplay.forEach(module => module.validDateError = true);
				}
			},
			(errorResponse) => {
				this.hadCheck = false;
				this.setErrorFromResponse(errorResponse);
			}
		).add(() => this.isLoading = false);

	}

	hasSameTypeCertificateInCheckList(typeId: number, list: Certificate[] | AdrModule[]): boolean {
		if (this.modulesFromCheck?.length > 0 || this.certificatesFromCheck?.length > 0) {
			// tslint:disable-next-line: prefer-for-of
			for (let i = 0; i < list.length ; i++  ) {
				const currentCertificateOrModule = list[i];
				if (currentCertificateOrModule.typeId === typeId) {
					return true;
				}
			}
		}
		return false;
	}

	private checkAllAttachedCertificatesOrModulesHasSameTypeFromCheck(
		list: Certificate[] | AdrModule[], checkList: Certificate[] | AdrModule[]): boolean {
		if (list && list.length > 0) {
			// tslint:disable-next-line: prefer-for-of
			for (let i = 0; i < list.length ; i++  ) {
				const currentCertificateTypeId = list[i].typeId;
				let certificateFromCheckHasSameTypeAsAttached = null;
				// tslint:disable-next-line: prefer-for-of
				for (let y = 0; y < checkList.length ; y++ ) {
					if (checkList[y].typeId === currentCertificateTypeId) {
						certificateFromCheckHasSameTypeAsAttached = checkList[y];
					}
				}
				if (!certificateFromCheckHasSameTypeAsAttached) {
					return false;
				}
			}
		}

		return true;
	}

	setErrorFromResponse(errorResponse) {
		if (errorResponse.error) {
			if (errorResponse.error.error === 'ServiceNotWorkException') {
				PopUpService.showPopUp({
					header: POP_UP_MESSAGES_KEYS.error_service_not_work,
					text: POP_UP_MESSAGES_KEYS.try_again_later,
					type: PopUpTypes.ERROR
				});
			} else {
				PopUpService.showPopUp(DEFAULT_POP_UPS.error);
			}
		}
	}

	moduleIsMissingInCheck(moduleTypeId: number): boolean {
		const existInCheck = this.modulesFromCheck.find(module => module.typeId === moduleTypeId);
		return !existInCheck;
	}

	modulesFromCheckThatMissingInChosen(): AdrModule[] {
		const modulesFromCheckMissingInChosen : AdrModule[] = [];
		for (let i = 0; i < this.modulesFromCheck.length; i++) {
			const sameTypeModuleUploadedByUser = this.modulesToDisplay.find(module => module.typeId === this.modulesFromCheck[i].typeId);
			if (!sameTypeModuleUploadedByUser) {
				modulesFromCheckMissingInChosen.push(this.modulesFromCheck[i]);
			}
		}
		return modulesFromCheckMissingInChosen;
	}
}
