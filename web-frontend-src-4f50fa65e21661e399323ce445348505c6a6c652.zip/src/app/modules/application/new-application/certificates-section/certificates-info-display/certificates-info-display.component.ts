import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { AdrModule } from 'src/app/shared/models/adr-module';
import { CERTIFICATE_TYPE_ID_TO_ATTACHED_DOCUMENT_TYPE_ID } from 'src/app/shared/models/constants/attached-documents/certificate-type-id';
import { Certificate } from 'src/app/shared/models/certificate';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { SelectedCertificatesAndModulesDto } from 'src/app/shared/dtos/selected-certificates-and-modules-dto';

@Component({
	selector: 'app-certificates-info-display',
	templateUrl: './certificates-info-display.component.html'
})
export class CertificatesInfoDisplayComponent implements OnInit {
	@Input() public number: number;
	@Input() applicationId: number;
	@Input() isDraft: boolean;
	@Input() certificatesToDisplay: Certificate[];
	@Input() modulesToDisplay: AdrModule[];
	@Output() public emitEditSection = new EventEmitter<SelectedCertificatesAndModulesDto>();
	convertCertificateTypeIdToAttachedDocTypeId = CERTIFICATE_TYPE_ID_TO_ATTACHED_DOCUMENT_TYPE_ID;

	isAdrApplication = false;
	isApplicant: boolean;

	dateFormat = S_VARIABLES.DATE_FORMAT;

	constructor(private readonly authenticationService: AuthenticationService) { }

	ngOnInit(): void {
		this.isApplicant = this.authenticationService.getAuthenticatedUser().isApplicant();
		if (!this.certificatesToDisplay || this.certificatesToDisplay.length === 0) {
			this.isAdrApplication = true;
		}
	}

	editSection() {
		const selectedCertOrModules = new SelectedCertificatesAndModulesDto();
		if (this.isAdrApplication) {
			selectedCertOrModules.modules = this.modulesToDisplay;
		} else {
			selectedCertOrModules.certificates = this.certificatesToDisplay;
		}
		this.emitEditSection.next(selectedCertOrModules);
	}
}
