import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ContactView } from 'src/app/shared/models/contact-view';

@Component({
	selector: 'app-correspondence-info-display',
	templateUrl: './correspondence-info-display.component.html'
})
export class CorrespondenceInfoDisplayComponent implements OnInit {
	@Input() public number: number;
	@Input() isDraft: boolean;
	@Input() public correspondenceView: ContactView;
	@Output() public emitEditSection = new EventEmitter<boolean>();

	constructor() { }

	ngOnInit(): void {
	}

	editSection() {
		this.emitEditSection.next(true);
	}
}
