import { Component, OnInit, Input, ViewChild, AfterViewInit, Output, EventEmitter } from '@angular/core';
import { ApplicationService } from 'src/app/core/services/application.service';
import { ApplicantContactDetailsDto } from 'src/app/shared/interfaces/applicant-contact-details-dto';
import { ApplicantContactDetails } from 'src/app/shared/models/applicant-contact-details';
import { ChosenCorrespondenceDto } from 'src/app/shared/dtos/chosen-correspondence-dto';
import { PhoneNumberDto } from 'src/app/shared/dtos/phone-number-dto';
import { ContactTypes } from 'src/app/shared/enums/contact-types';
import { CountryCode } from 'src/app/shared/models/country-code';
import { CountryCodeDto } from 'src/app/shared/interfaces/country-code-dto';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { Steps } from 'src/app/shared/enums/steps';
import { AddressForm } from 'src/app/shared/utils/address-form';
import { MILESTONE_STATUSES } from 'src/app/shared/enums/milestone-statuses';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { AddressDto } from 'src/app/shared/dtos/address-dto';
import { Address } from 'src/app/shared/models/address';
import { CityDto } from 'src/app/shared/dtos/city-dto';
import { RegionDto } from 'src/app/shared/dtos/region-dto';
import { ContactView } from 'src/app/shared/models/contact-view';
import { MunicipalityDto } from 'src/app/shared/dtos/municipality-dto';
import { ChangeDetectorRef } from '@angular/core';

@Component({
	selector: 'app-correspondence-info',
	templateUrl: './correspondence-info.component.html'
})
export class CorrespondenceInfoComponent implements OnInit, AfterViewInit {
	@Input() public number: number;
	@Input() isDraft: boolean;
	@Input() applicationId: number;
	@Input() contactView: ContactView;
	@Input() isEditing: Steps;
	@Output() public emitIsEditing = new EventEmitter<Steps>();
	@ViewChild('correspondenceHtmlElement') htmlElement: { nativeElement: HTMLElement; };

	applicantContactDetails: ApplicantContactDetails;
	countryCodes: CountryCode[] = [];
	selectedCountryCode: CountryCode = null;
	bulgariaCountryCode = '359';

	isViaEmailSelected: boolean;
	isViaPhoneSelected: boolean;
	isToAddressSelected: boolean;
	isPermanentAddressSelected = true;
	isCurrentAddressSelected: boolean;
	isOtherAddressSelected: boolean;
	showDisplayInfo: boolean;
	correspondenceDto: ChosenCorrespondenceDto;
	isLoading: boolean;

	emailFieldInvalid = false;
	phoneFieldInvalid = false;
	addressIsNotSelected = false;
	email: string;
	phoneNumber: string;
	addressForm: AddressForm;
	address: Address;

	hasPermanentAddress = false;
	hasCurrentAddress = false;

	constructor(
		private applicationService: ApplicationService,
		private nomenclatureService: NomenclatureService,
		private appStepsElementService: ApplicationStepsElementsService,
		private authService: AuthenticationService,
		private reference: ChangeDetectorRef
	) { }

	ngOnInit() {
		if (!this.isDraft && this.contactView) {
			this.showDisplayInfo = true;
			return;
		}
		this.addressForm = new AddressForm();
		this.isLoading = true;
		
		this.nomenclatureService.getAllCountryCodes()
			.subscribe((countryCodes: CountryCodeDto[]) => {
				countryCodes.forEach(countryCodeDto => {
					const countryCode = new CountryCode(countryCodeDto);
					this.countryCodes.push(countryCode);
					if (countryCode.code === this.bulgariaCountryCode) {
						this.selectedCountryCode = countryCode;
					}
				});
			}).add(() => this.isLoading = false);

		this.applicationService.getApplicantContactDetails(this.applicationId)
			.subscribe((dto: ApplicantContactDetailsDto) => {
				this.applicantContactDetails = new ApplicantContactDetails(dto);
				this.setHasCurrentAddress();

				if (!this.contactView) {
					this.isPermanentAddressSelected = true;
				}
			}).add(() => {
				if (this.contactView != null) {
					this.setToggles();
					this.showDisplayInfo = true;
				} else {
					this.isViaEmailSelected = true;
				}
			});

		const user = this.authService.getAuthenticatedUser();
		if (user.isApplicant() && user.email) {
			this.email = user.email;
		}
	}

	private setToggles() {
		if (this.contactView.contactTypeId === ContactTypes.PERMANENT_ADDRESS
			|| this.contactView.contactTypeId === ContactTypes.CURRENT_ADDRESS
			|| this.contactView.contactTypeId === ContactTypes.ADDITIONAL_ADDRESS) {
			this.isToAddressSelected = true;
			this.selectCorrectAddress(this.contactView.contactTypeId);
		} else if (this.contactView.contactTypeId === ContactTypes.EMAIL) {
			this.isViaEmailSelected = true;
			this.email = this.contactView.email;
			this.selectCorrectAddress(this.contactView.address.addressTypeId);
		} else if (this.contactView.contactTypeId === ContactTypes.PHONE_NUMBER) {
			this.isViaPhoneSelected = true;
			this.phoneNumber = this.contactView.phoneNumberObj.phoneNumber;
			this.countryCodes.forEach((cc: CountryCode) => {
			if (cc.id === this.contactView.phoneNumberObj.countryCodeId) {
				this.selectedCountryCode = cc;
			}
			});
			this.selectCorrectAddress(this.contactView.address.addressTypeId);
		}
		
		if (this.isPermanentAddressSelected) {
			this.setCorrespondenceDtoFields(this.applicantContactDetails.permanentAddress);
		} else if (this.isCurrentAddressSelected) {
			this.setCorrespondenceDtoFields(this.applicantContactDetails.currentAddress);
		} else if (this.isOtherAddressSelected) {
			this.setCorrespondenceDtoFields(this.applicantContactDetails.otherAddress);
		}
	}

	setHasCurrentAddress() {
		if (this.applicantContactDetails?.currentAddress?.city) {
			this.hasCurrentAddress = true;
		}
	}

	private setCorrespondenceDtoFields(address: Address) {
		this.correspondenceDto = new ChosenCorrespondenceDto();
		this.correspondenceDto.email = this.email;
		this.correspondenceDto.phoneNumberDto = new PhoneNumberDto();
		this.correspondenceDto.phoneNumberDto.phoneNumber = this.phoneNumber;
		if (this.selectedCountryCode) {
			this.correspondenceDto.phoneNumberDto.countryCodeId = this.selectedCountryCode.id;
		}
		this.correspondenceDto.addressDto = new AddressDto();
		this.correspondenceDto.addressDto.addressTypeId = address.addressTypeId;
		this.correspondenceDto.addressDto.cityDto = new CityDto();
		if (address.city != null) {
			this.correspondenceDto.addressDto.cityDto.cityCode = address.city.cityCode;
			this.correspondenceDto.addressDto.cityDto.key = address.city.key;
		}
		this.correspondenceDto.addressDto.municipalityDto = new MunicipalityDto();
		this.correspondenceDto.addressDto.municipalityDto.code = address.municipality?.code;
		this.correspondenceDto.addressDto.municipalityDto.key = address.municipality?.key;
		this.correspondenceDto.addressDto.municipalityDto.regionCode = address.municipality?.regionCode;
		this.correspondenceDto.addressDto.regionDto = new RegionDto();
		this.correspondenceDto.addressDto.regionDto.key = address.region?.key;
		this.correspondenceDto.addressDto.regionDto.regionCode = address.region?.regionCode;
		this.correspondenceDto.addressDto.countryDto = null;
	}

	private selectCorrectAddress(addressContactTypeId: number) {
		if (addressContactTypeId === ContactTypes.PERMANENT_ADDRESS) {
			this.selectPermanentAddress();
		} else if (addressContactTypeId === ContactTypes.CURRENT_ADDRESS) {
			this.selectCurrentAddress();
		} else {
			this.selectOtherAddress();
		}
	}

	ngAfterViewInit() {
		setTimeout(() => {
			this.appStepsElementService.correspondenceEl = this.htmlElement.nativeElement;
			this.appStepsElementService.scrollToStep(Steps.CORRESPONDENCE);
		})
	}

	toggleViaEmail() {
		this.isViaEmailSelected = !this.isViaEmailSelected;
		this.isToAddressSelected = false;
		this.isViaPhoneSelected = false;
		this.phoneFieldInvalid = false;
	}

	toggleViaPhone() {
		this.isViaPhoneSelected = !this.isViaPhoneSelected;
		this.isViaEmailSelected = false;
		this.emailFieldInvalid = false;
		this.isToAddressSelected = false;
	}

	toggleToAddress() {
		this.isToAddressSelected = !this.isToAddressSelected;
		this.isViaEmailSelected = false;
		this.isViaPhoneSelected = false;
		this.emailFieldInvalid = false;
		this.phoneFieldInvalid = false;
	}

	selectPermanentAddress() {
		this.addressIsNotSelected = false;
		this.isPermanentAddressSelected = true;
		this.isCurrentAddressSelected = false;
		this.isOtherAddressSelected = false;
	}

	selectCurrentAddress() {
		this.addressIsNotSelected = false;
		this.isPermanentAddressSelected = false;
		this.isCurrentAddressSelected = true;
		this.isOtherAddressSelected = false;
	}

	selectOtherAddress() {
		if (this.contactView?.address?.addressTypeId === ContactTypes.ADDITIONAL_ADDRESS) {
			this.convertContactViewToAddressForm();
		}
		this.addressIsNotSelected = false;
		this.isPermanentAddressSelected = false;
		this.isCurrentAddressSelected = false;
		this.isOtherAddressSelected = true;
	}

	setCorrespondenceContact() {
		if (this.isLoading)	{
			return;
		}
		const dto = new ChosenCorrespondenceDto();
		let requestAddressDto = new AddressDto();
		if (this.isOtherAddressSelected && this.addressForm.setIsAddressValid()) {
			requestAddressDto = this.addressForm.toRequestDto();
			requestAddressDto.addressTypeId = ContactTypes.ADDITIONAL_ADDRESS;
			this.address = new Address(requestAddressDto);
		} else if (this.isCurrentAddressSelected) {
			requestAddressDto = this.applicantContactDetails.currentAddress.convertToAddressDto();
			requestAddressDto.addressTypeId = ContactTypes.CURRENT_ADDRESS;
			this.address = this.applicantContactDetails.currentAddress;
		} else if (this.isPermanentAddressSelected) {
			requestAddressDto = this.applicantContactDetails.permanentAddress.convertToAddressDto();
			requestAddressDto.addressTypeId = ContactTypes.PERMANENT_ADDRESS;
			this.address = this.applicantContactDetails.permanentAddress;
		} else {
			this.addressIsNotSelected = true;

			this.reference.detectChanges();
			const elements = document.getElementsByClassName('has-error');
			elements[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
			return;
		}
		requestAddressDto.countryDto = null;
		dto.addressDto = requestAddressDto;

		if (this.isViaEmailSelected) {
			const regexForEmailValidation = new RegExp('^[a-z0-9._%+-]+@[a-z0-9.-]+[.]+[a-z]{2,4}$');
			if (this.email !== undefined && regexForEmailValidation.test(this.email)) {
				dto.email = this.email;
				this.emailFieldInvalid = false;
			} else {
				this.emailFieldInvalid = true;
				return;
			}
		} else if (this.isViaPhoneSelected) {
			const regexForNumbersOnly = '^[0-9]+$';
			if (this.phoneNumber !== undefined && this.phoneNumber.match(regexForNumbersOnly)) {
				const phoneNumberDto = new PhoneNumberDto();
				phoneNumberDto.countryCodeId = this.selectedCountryCode.id;
				phoneNumberDto.phoneNumber = this.phoneNumber;
				dto.phoneNumberDto = phoneNumberDto;
			} else {
				this.phoneFieldInvalid = true;
				return;
			}
		} 
		this.correspondenceDto = dto;
		if (!this.appStepsElementService.checkIfIsEditingAndSet(Steps.CORRESPONDENCE) && (!this.addressIsNotSelected
			&& ((this.isViaPhoneSelected && !this.phoneFieldInvalid)
				|| (this.isViaEmailSelected && !this.emailFieldInvalid)
				|| this.isOtherAddressSelected || this.isCurrentAddressSelected || this.isPermanentAddressSelected))) {

			this.isLoading = true;
			this.applicationService.setCorrespondenceContact(this.applicationId, dto).subscribe(
				(contactViewResponse) => {
					this.contactView = new ContactView(contactViewResponse);
					this.showDisplayInfo = true;
					this.appStepsElementService.continueToNextStepFromCurrent(Steps.CORRESPONDENCE);
				},
				(error) => PopUpService.showPopUp(DEFAULT_POP_UPS.error)
			).add(() => { 
				this.isLoading = false;
				this.appStepsElementService.setIsEditingToEmptyStep();
			});
		}
	}

	editSection() {
		if (this.appStepsElementService.checkIfIsEditingAndSet(Steps.CORRESPONDENCE)) {
			return;
		}
		this.applicationService.setToMilestone(this.applicationId, MILESTONE_STATUSES.PERSONAL_DATA_ENTERED)
			.subscribe(
				() => {
					this.setToggles();
					this.showDisplayInfo = false;
				}
			);
	}

	convertContactViewToAddressForm() {
		this.addressForm = new AddressForm();
		this.addressForm.city.setValue(this.contactView.address.city);
		this.addressForm.region.setValue(this.contactView.address.region);
		this.addressForm.municipality.setValue(this.contactView.address.municipality);
		this.addressForm.postalCode.setValue(this.contactView.address.postalCode);
		this.addressForm.street.setValue(this.contactView.address.street);
		this.addressForm.streetNumber.setValue(this.contactView.address.streetNumber);
		this.addressForm.entrance.setValue(this.contactView.address.entrance);
		this.addressForm.building.setValue(this.contactView.address.building);
		this.addressForm.apartment.setValue(this.contactView.address.apartment);
	}

}
