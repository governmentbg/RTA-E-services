import { Component, Input, OnInit } from '@angular/core';
import { ErrorCheckerService } from 'src/app/core/services/error-checker.service';
import { DrivingLicenceService } from 'src/app/core/services/driving-licence.service';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { RequestMvrDto } from 'src/app/shared/dtos/request-mvr-dto';
import { IdentityDocumentTypes } from 'src/app/shared/enums/idenity-document-types';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { Category } from 'src/app/shared/models/category';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { DrivingLicenceView } from 'src/app/shared/models/driving-licence-view';
import { Translation } from 'src/app/shared/models/translation';
import { User } from 'src/app/shared/models/user';
import { Utils } from 'src/app/shared/utils/utils';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';

@Component({
	selector: 'app-driving-licence-approver',
	templateUrl: './driving-licence-approver.component.html',
	host: {
		"(window:click)": "onClick()"
	}
})
export class DrivingLicenceApproverComponent implements OnInit {
	@Input() number: number;
	@Input() user: User;
	@Input() applicationId: number;
	@Input() hasDlMvrCheck: boolean;
	@Input() dbDrivingLicence: DrivingLicenceView;
	@Input() applicationTypeId: number;
	@Input() identityNumberApplicant: string;
	@Input() startMilestoneStatusToGetDocumentsForSection: number;
	isLoading: boolean;
	dateFormat = S_VARIABLES.DATE_FORMAT;
	differenceCount: number;
	showOptions = false;

	isBulgarianDl: boolean;
	requestDlMvrDto: RequestMvrDto;
	dlInfoFromCheck: DrivingLicenceView;
	mvrCheckCategoryTypeSameAsUsers: Category[] = [];
	mvrCheckCategoryTypeDifferentThanUsers: Category[] = [];

	constructor(
		private drivingLicenceService: DrivingLicenceService,
		private errorCheckerService: ErrorCheckerService
		) { }

	ngOnInit(): void {
		this.isBulgarianDl = this.dbDrivingLicence.bulgarian;
	}

	onClick() {
		this.showOptions = false;
	}

	setShowOptions($event) {
		$event.stopPropagation();
		this.showOptions = true;
	}

	doDlMvrCheck() {
		this.showOptions = false;
		if (this.isLoading || !this.isBulgarianDl) {
			return;
		}
		this.isLoading = true;
		this.setRequestMvrDto();

		this.drivingLicenceService.getMvrDLInfoForApprover(this.requestDlMvrDto)
			.subscribe(
				(response) => {
					this.dlInfoFromCheck = new DrivingLicenceView(response);

					const categoryIdFromDbDrivingLicence = this.dbDrivingLicence.categories.map(category => category.categoryId);
					this.mvrCheckCategoryTypeSameAsUsers = this.dlInfoFromCheck.categories
						.filter(c => categoryIdFromDbDrivingLicence.includes(c.categoryId));
					this.mvrCheckCategoryTypeDifferentThanUsers = this.dlInfoFromCheck.categories
						.filter(c => !categoryIdFromDbDrivingLicence.includes(c.categoryId));

					if (!this.hasDlMvrCheck) {
						this.dbDrivingLicence =
							this.errorCheckerService.setHasErrorsAndCountDifferencesInDrivingLicence(
								this.dbDrivingLicence , this.dlInfoFromCheck, this.mvrCheckCategoryTypeSameAsUsers);
					}

					this.differenceCount = this.dbDrivingLicence.differences + this.mvrCheckCategoryTypeDifferentThanUsers.length;
				},
				(errorResponse) => {
					if (errorResponse.error) {
						if (errorResponse.error.error === 'PersonNotFoundMvrRegixException') {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_mvr_not_found_valid_document,
								text: POP_UP_MESSAGES_KEYS.input_valid_document,
								type: PopUpTypes.ERROR
							});
						} else if (errorResponse.error.error === 'DocumentExpiredException') {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_expired_document,
								text: POP_UP_MESSAGES_KEYS.input_not_expired_document,
								type: PopUpTypes.ERROR
							});
						} else if (errorResponse.error.error === 'MvrAndGraoDoNotWork'
							|| errorResponse.error.error === 'ProxyException') {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_service_not_work,
								text: POP_UP_MESSAGES_KEYS.try_again_later,
								type: PopUpTypes.ERROR
							});
						} else if (errorResponse.error.error === 'InvalidDocumentFromMvrException') {
							PopUpService.showPopUp({
								type: PopUpTypes.ERROR,
								text: Utils.formatString(POP_UP_MESSAGES_KEYS.mvr_check_invalid_document, 
									errorResponse.error.status, errorResponse.error.date, 
									errorResponse.error.statusReason)
							})
						} else if (errorResponse.error.error === 'MvrChangedResponseIssuerNameException') {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_service_not_work,
								text: POP_UP_MESSAGES_KEYS.error_contact_system_administrator,
								type: PopUpTypes.ERROR
							});
						}
					}
			}).add(() => {
				this.isLoading = false;
			});
	}

	setRequestMvrDto() {
		this.requestDlMvrDto = new RequestMvrDto();
		this.requestDlMvrDto.applicationId = this.applicationId;
		this.requestDlMvrDto.identityNumber = this.identityNumberApplicant;
		this.requestDlMvrDto.identityDocumentType = new Translation(null);
		this.requestDlMvrDto.identityDocumentType.id = IdentityDocumentTypes.DRIVING_LICENCE;
		this.requestDlMvrDto.documentNumber = this.dbDrivingLicence.documentNumber;
		this.requestDlMvrDto.isAuthorizedPerson = false;
	}

}
