import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { DrivingLicenceView } from 'src/app/shared/models/driving-licence-view';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';

@Component({
	selector: 'app-driving-license-info-display',
	templateUrl: './driving-license-info-display.component.html'})
export class DrivingLicenseInfoDisplayComponent implements OnInit {
	@Input() public number: number;
	@Input() isDraft: boolean;
	@Input() hasDlMvrCheck: boolean;
	@Input() drivingLicenceView: DrivingLicenceView;
	@Input() hasAttachedDocuments: boolean;
	@Output() editSection: EventEmitter<DrivingLicenceView> = new EventEmitter<DrivingLicenceView>();
	@Output() emitEditDocumentsSection: EventEmitter<Event> = new EventEmitter<Event>();
	dateFormat = S_VARIABLES.DATE_FORMAT;
	isApplicant: boolean;

	constructor(private readonly authenticationService: AuthenticationService) { }

	ngOnInit() {
		this.isApplicant = this.authenticationService.getAuthenticatedUser().isApplicant();
	}

	editDlSection() {
		this.editSection.emit(this.drivingLicenceView);
	}

	editDocumentsForSection(event: Event) {
		this.emitEditDocumentsSection.emit(event);
	}
}
