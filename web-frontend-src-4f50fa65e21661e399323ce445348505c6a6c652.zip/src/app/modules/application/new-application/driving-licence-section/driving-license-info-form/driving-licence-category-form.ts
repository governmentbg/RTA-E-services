import { AbstractForm } from 'src/app/shared/models/abstract-form';
import { FormGroup, Validators } from '@angular/forms';
import { CustomValidators } from 'src/app/shared/utils/custom-validators';
import { Category } from 'src/app/shared/models/category';
import { DrivingLicenceCategoryDto } from 'src/app/shared/dtos/driving-licence-category-dto';
import { Utils } from 'src/app/shared/utils/utils';

export class DrivingLicenceCategoryForm extends AbstractForm<DrivingLicenceCategoryDto> {

	constructor() {
		super();
		this.formGroup = this.createFormGroup();
	}

	get categoryId() {
		return this.formGroup.get('categoryId');
	}

	get startDate() {
		return this.formGroup.get('startDate');
	}

	get category() {
		return this.formGroup.get('category');
	}

	setCategoriesFromDto(dto: DrivingLicenceCategoryDto) {
		this.categoryId.setValue(dto.categoryId);
		this.startDate.setValue(dto.startDate);
	}

	private createFormGroup(): FormGroup {
		return this.formBuilder.group({
			categoryId: [0, [
				Validators.required, Validators.min(1)
			]],
			startDate: [null, [
				Validators.required, CustomValidators.isPastOrPresentDate()
			]],
			category: [null]
		});
	}

	public toRequestDto(): DrivingLicenceCategoryDto {
		return {
			categoryId: this.categoryId.value,
			startDate: Utils.convertDateToStringFormatted(new Date(this.startDate.value))
		};
	}
}
