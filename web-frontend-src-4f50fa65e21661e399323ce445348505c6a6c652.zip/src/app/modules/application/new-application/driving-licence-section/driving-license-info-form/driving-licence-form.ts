import { AbstractForm } from 'src/app/shared/models/abstract-form';
import { FormGroup, Validators } from '@angular/forms';
import { DrivingLicenceDto } from 'src/app/shared/dtos/driving-licence-dto';
import { DrivingLicenceCategoryForm } from './driving-licence-category-form';
import { DrivingLicenceCategoryDto } from 'src/app/shared/dtos/driving-licence-category-dto';
import { CustomValidators } from 'src/app/shared/utils/custom-validators';
import { Countries } from 'src/app/shared/enums/countries';
import { Utils } from 'src/app/shared/utils/utils';

export class DrivingLicenceForm extends AbstractForm<DrivingLicenceDto> {
	constructor() {
		super();
		this.formGroup = this.createFormGroup();
	}

	get applicationId() {
		return this.formGroup.get('applicationId');
	}

	get documentNumber() {
		return this.formGroup.get('documentNumber');
	}

	get documentNumberForeigner() {
		return this.formGroup.get('documentNumberForeigner');
	}

	get dateOfIssue() {
		return this.formGroup.get('dateOfIssue');
	}

	get dateOfExpiry() {
		return this.formGroup.get('dateOfExpiry');
	}

	get documentIssuer() {
		return this.formGroup.get('documentIssuer');
	}

	get country() {
		return this.formGroup.get('country');
	}

	get categories() {
		return this.formGroup.get('categories');
	}

	public setValuesFromDrivingLicenceDto(drivingLicenceDto: DrivingLicenceDto) {
		this.applicationId.setValue(drivingLicenceDto.applicationId);
		this.documentNumber.setValue(drivingLicenceDto.documentNumber);
		this.documentNumberForeigner.setValue(drivingLicenceDto.documentNumber);
		this.dateOfIssue.setValue(drivingLicenceDto.dateOfIssue);
		this.dateOfExpiry.setValue(drivingLicenceDto.dateOfExpiry);

		if (drivingLicenceDto.categories && drivingLicenceDto.categories.length > 0) {
			for (const category of drivingLicenceDto.categories) {
				const categoryForm = new DrivingLicenceCategoryForm();
				categoryForm.setCategoriesFromDto(category);
				this.categories.value.push(categoryForm);
			}
		}
	}

	private createFormGroup(): FormGroup {
		return this.formBuilder.group({
			applicationId: [0],
			documentNumber: [null, [
				Validators.required, Validators.pattern('^[A-Za-z0-9-\/]*$')
			]],
			documentNumberForeigner: [null, [
				Validators.pattern('^[A-Za-z0-9-\/]*$'),Validators.required, Validators.maxLength(16)
			]],
			documentIssuer: [null, [
				Validators.min(1)
			]],
			dateOfExpiry: [null, [
				Validators.required, CustomValidators.isFutureOrPresentDateOrExpiredLast6Months()
			]],
			dateOfIssue: [null, [
				Validators.required, CustomValidators.isPastOrPresentDate()
			]],
			country: ['', [
				Validators.required, Validators.min(1)
			]],
			categories: this.formBuilder.array([new DrivingLicenceCategoryForm()], [
				Validators.required,
				Validators.minLength(1)
			])
		});
	}

	public isValid() {
		let isValid = true;
		this.categories.value.forEach(form => {
			if (!form.isValid()) {
				isValid = false;
				return isValid;
			}
		});
		if (this.country.value.id === Countries.BULGARIA_ID) {
			isValid = this.documentNumber.valid;
		} else {
			isValid = this.documentNumberForeigner.valid;
		}

		return isValid && this.documentIssuer.valid && this.dateOfExpiry.valid 
			&& this.dateOfIssue.valid && this.country.valid;
	}

	public toRequestDto(): DrivingLicenceDto {
		const dlCategories: DrivingLicenceCategoryDto[] = [];

		this.categories.value.forEach((element: DrivingLicenceCategoryForm) => {
			dlCategories.push(element.toRequestDto());
		});
		let documentIssuerId = this.documentIssuer.value?.id;
		if (this.documentIssuer.value === 0) {
			documentIssuerId = null;
		}
		let isBulgarian = false;
		if (this.country.value.id === Countries.BULGARIA_ID) {
			isBulgarian = true;
		}
		return {
			applicationId: this.applicationId.value,
			documentNumber: this.documentNumber.value,
			documentIssuerId,
			dateOfExpiry: Utils.convertDateToStringFormatted(new Date(this.dateOfExpiry.value)),
			dateOfIssue: Utils.convertDateToStringFormatted(new Date(this.dateOfIssue.value)),
			countryId: this.country.value.id,
			categories: dlCategories,
			isBulgarian,
			isEditing: false
		};
	}
}
