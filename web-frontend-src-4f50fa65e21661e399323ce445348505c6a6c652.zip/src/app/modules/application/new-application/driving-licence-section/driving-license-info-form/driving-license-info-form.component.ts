import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { DrivingLicenceService } from 'src/app/core/services/driving-licence.service';
import { DrivingLicenceDto } from 'src/app/shared/dtos/driving-licence-dto';
import { DrivingLicenceForm } from './driving-licence-form';
import { DrivingLicenceView } from 'src/app/shared/models/driving-licence-view';
import { CategoryDto } from 'src/app/shared/interfaces/category-dto';
import { DrivingLicenceCategoryForm } from './driving-licence-category-form';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { Countries } from 'src/app/shared/enums/countries';
import { DrivingLicenceInitialInfoDto } from 'src/app/shared/dtos/driving-licence-initial-info-dto';
import { DrivingLicenceCompletedFormDto } from 'src/app/shared/dtos/driving-licence-completed-form-dto';
import { IdentityDocumentIssuers } from 'src/app/shared/enums/idenity-document-issuers';
import { CategoryDropDownDto } from 'src/app/shared/models/category-dropdown';
import { Translation } from 'src/app/shared/models/translation';
import { TranslationDto } from 'src/app/shared/interfaces/translation-dto';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { Steps } from 'src/app/shared/enums/steps';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { CountryDto } from 'src/app/shared/interfaces/country-dto';
import { Country } from 'src/app/shared/models/country';

@Component({
	selector: 'app-driving-license-info-form',
	templateUrl: './driving-license-info-form.component.html'
})
export class DrivingLicenseInfoFormComponent implements OnInit {
	@Input() public number: number;
	@Input() drivingLicenceDto: DrivingLicenceDto;
	@Input() dbDrivingLicence: DrivingLicenceView;
	@Output() emitCompletedDto = new EventEmitter<DrivingLicenceCompletedFormDto>();
	@Output() emitDlInitialInfoDto = new EventEmitter<DrivingLicenceInitialInfoDto>();
	@ViewChild('form') htmlElement;
	// TODO : да се изтрие , тък като бг се дърпа от базата 
	get countriesEnum() { return Countries; }

	public drivingLicenceForm: DrivingLicenceForm;
	public categoryForm: DrivingLicenceCategoryForm;
	public countries: Country[] = [];
	public identityDocumentIssuers: Translation[] = [];
	public categories: CategoryDropDownDto[] = [];
	public issuerCountryId = 0;
	public dlInitialInfoDto = new DrivingLicenceInitialInfoDto();
	public isLoading = false;
	public isCountryDisabled = false;
	public isCategorySelected = false;
	public isDatepickerOpen = true;

	today: Date = new Date();

	constructor(
		private drivingLicenceService: DrivingLicenceService,
		private nomenclatureService: NomenclatureService,
		private appStepsElements: ApplicationStepsElementsService
	) { }

	ngOnInit() {
		this.drivingLicenceForm = new DrivingLicenceForm();
		this.drivingLicenceForm.setValuesFromDrivingLicenceDto(this.drivingLicenceDto);
		if (this.drivingLicenceDto.countryId) {
			this.issuerCountryId = this.drivingLicenceDto.countryId;
		}
		this.dlInitialInfoDto.isBulgarian = this.drivingLicenceDto.isBulgarian;
		this.dlInitialInfoDto.isBulgarian ? this.isCountryDisabled = true : this.isCountryDisabled = false;
		this.dlInitialInfoDto.documentNumber = this.drivingLicenceDto.documentNumber;

		this.nomenclatureService.getAllCountries().subscribe(
			(countries: CountryDto[]) => {
				countries.forEach(countryDto => {
					this.countries.push(new Country(countryDto));
					if (countryDto.country.id === this.drivingLicenceDto.countryId) {
						this.drivingLicenceForm.country.setValue(countryDto.country);
					}
				});
			}
		);

		this.nomenclatureService.getIdentityDocumentIssuers().subscribe(
			(issuers: TranslationDto[]) => {
				issuers.forEach(issuerDto => {
					const issuer = new Translation(issuerDto);
					if (issuerDto.id !== IdentityDocumentIssuers.MVR && issuerDto.id !== IdentityDocumentIssuers.MVR_SOFIA_CITY) {
						this.identityDocumentIssuers.push(issuer);
					}
					if (issuerDto.id === this.drivingLicenceDto.documentIssuerId) {
						this.drivingLicenceForm.documentIssuer.setValue(issuer);
					}
				});
			}
		);

		this.nomenclatureService.getAllCategories().subscribe(
			(categoriesDto: CategoryDto[]) => {
				categoriesDto.forEach(catDto => {
					const catDropDownDto = new CategoryDropDownDto(catDto);
					this.categories.push(catDropDownDto);
					if (this.drivingLicenceDto.categories && this.drivingLicenceDto.categories.length > 0) {
						this.drivingLicenceDto.categories.forEach((cat) => {
							if (cat.categoryId === catDropDownDto.id) {
								catDropDownDto.isSelected = true;
								catDropDownDto.categoryForm.startDate.setValue(cat.startDate);
								this.isDatepickerOpen = false;
							}
						});
					}
				});
			}
		);
	}

	public editDocumentNumber() {
		this.emitDlInitialInfoDto.next(this.dlInitialInfoDto);
	}

	onSubmit() {
		if (!this.checkIfAtLeastOneCategoryIsSelected()) {
			PopUpService.showPopUp({ type: PopUpTypes.WARNING,
				header: POP_UP_MESSAGES_KEYS.warning_missing_driving_licence_categories
			});
			return;
		}
		if (!this.appStepsElements.checkIfIsEditingAndSet(Steps.DRIVING_LICENCE)) {
			this.drivingLicenceForm.categories.setValue([new DrivingLicenceCategoryForm()]);
			this.categories.forEach(cat => {
				if (cat.isSelected) {
					this.drivingLicenceForm.categories.value.push(cat.categoryForm);
				}
			});
			this.drivingLicenceForm.categories.value.shift();
			if (this.drivingLicenceForm.isValid()) {
				const requestDto = this.drivingLicenceForm.toRequestDto();
				if (!this.dlInitialInfoDto.isBulgarian && requestDto.countryId === Countries.BULGARIA_ID) {
					this.drivingLicenceForm.country.setErrors({ '': true });
				} else {
					this.isLoading = true;
					requestDto.applicationId = this.drivingLicenceDto.applicationId;
					requestDto.isEditing = this.drivingLicenceDto.isEditing;
					this.drivingLicenceService.saveDrivingLicenceInfo(requestDto).subscribe(
						(dto) => {
							const completedFormDto = new DrivingLicenceCompletedFormDto();
							completedFormDto.drivingLicenceDto = requestDto;
							completedFormDto.drivingLicenceView = new DrivingLicenceView(dto);
							this.dbDrivingLicence = new DrivingLicenceView(dto);
							this.emitCompletedDto.next(completedFormDto);
							this.appStepsElements.setIsEditingToEmptyStep();
						}
					).add(() => this.isLoading = false);
				}
			} else {
				this.drivingLicenceForm.scrollToFirstInvalidControl(this.htmlElement);
			}
		}
	}

	toggleCategory(category: CategoryDropDownDto) {
		category.isSelected = !category.isSelected;
	}

	checkIfAtLeastOneCategoryIsSelected(): boolean {
		return this.categories.find(cat => cat?.isSelected === true) !== undefined;
	}

}
