import { Component, OnInit, Input, ViewChild, AfterViewInit, EventEmitter, Output } from '@angular/core';
import { User } from 'src/app/shared/models/user';
import { RequestMvrDto } from 'src/app/shared/dtos/request-mvr-dto';
import { DrivingLicenceDto } from 'src/app/shared/dtos/driving-licence-dto';
import { DrivingLicenceService } from 'src/app/core/services/driving-licence.service';
import { IdentityDocumentTypes } from 'src/app/shared/enums/idenity-document-types';
import { DrivingLicenceView } from 'src/app/shared/models/driving-licence-view';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { Steps } from 'src/app/shared/enums/steps';
import { DrivingLicenceInitialInfoDto } from 'src/app/shared/dtos/driving-licence-initial-info-dto';
import { DrivingLicenceCompletedFormDto } from 'src/app/shared/dtos/driving-licence-completed-form-dto';
import { ApplicationService } from 'src/app/core/services/application.service';
import { MILESTONE_STATUSES } from 'src/app/shared/enums/milestone-statuses';

import { APPLICATION_TYPE } from 'src/app/shared/enums/application-types';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { DrivingLicenceCategoryDto } from 'src/app/shared/dtos/driving-licence-category-dto';
import { Utils } from 'src/app/shared/utils/utils';
import { Translation } from 'src/app/shared/models/translation';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { Countries } from 'src/app/shared/enums/countries';

@Component({
	selector: 'app-driving-license-info',
	templateUrl: './driving-license-info.component.html'
})
export class DrivingLicenseInfoComponent implements OnInit, AfterViewInit {
	DOCUMENT_NUM_LENGTH = 9;

	@Input() public number: number;
	@Input() isDraft: boolean;
	@Input() user: User;
	@Input() applicantIsBulgarian: boolean;
	@Input() identityNumberApplicant: string;
	@Input() applicationId: number;
	@Input() applicationTypeId: number;
	@Input() dbDrivingLicence: DrivingLicenceView;
	@Input() isEditing: Steps;
	@Input() bulgariaCountry: Translation;
	@Input() hasDlMvrCheck: boolean;
	@Input() hasAutoFixedPicturesFromMvr: boolean;
	@Input() alreadyAttachedDocTypes: Translation[] = [];
	@Output() public emitIsEditing = new EventEmitter<Steps>();
	@ViewChild('dlHtmlElement') htmlElement: { nativeElement: HTMLElement; };

	public requestMvrDto: RequestMvrDto;
	public drivingLicenceDto: DrivingLicenceDto;

	public showInitialInfoForm = true;
	public showDlForm: boolean;
	public showDlDisplay: boolean;

	public isBulgarianDl = true;

	public isDocumentNumberValid = true;
	public documentNumber: string;
	public isLoading: boolean;

	public isReadOnly: boolean;
	public hasAttachedDocuments = false;
	public startMilestoneStatusToGetDocumentsForSection = MILESTONE_STATUSES.CORRESPONDENCE_INFO_ENTERED;

	constructor(
		private drivingLicenceService: DrivingLicenceService,
		private appStepsElementService: ApplicationStepsElementsService,
		private applicationService: ApplicationService,
		private authenticationService: AuthenticationService
	) { }

	ngOnInit() {
		if (this.dbDrivingLicence != null) {
			if (!this.dbDrivingLicence?.bulgarian) {
				this.isBulgarianDl = false;
			}
			this.transferDbDataToFormObject();
			this.showInitialInfoForm = false;
			this.showDlDisplay = true;
			if ((this.applicationTypeId === APPLICATION_TYPE.APPLICATION_TACHO_CARD
				&& this.appStepsElementService.canSeeService) ||
				(this.applicationTypeId !== APPLICATION_TYPE.APPLICATION_TACHO_CARD
					&& this.appStepsElementService.canSeeCertificate)) {
				this.isReadOnly = true;
			}
		}

	}

	ngAfterViewInit() {
		setTimeout(() => {
			this.appStepsElementService.drivingLicenceEl = this.htmlElement.nativeElement;
			if (this.isDraft) {
				this.appStepsElementService.scrollToStep(Steps.DRIVING_LICENCE);
			}
		})
	}

	public submitBulgarianDl() {
		const isUserWithEFace = this.authenticationService.getAuthenticatedUser().isEFaceApplicant();
		if (isUserWithEFace || !this.applicantIsBulgarian) {
			this.hasDlMvrCheck = false;
			this.switchToDrivingLicenceForm();
			return;
		}
		
		const canMvrReturnInfoForDL = Utils.checkCanMvrReturnInfoForDL(this.documentNumber);
		if (this.documentNumber.length === this.DOCUMENT_NUM_LENGTH && this.documentNumber.match('^[0-9]*$') && canMvrReturnInfoForDL) {
			this.isLoading = true;
			this.getRequestMvrDto();

			this.drivingLicenceService.getMvrDLInfo(this.requestMvrDto).subscribe(
				(drivingLicenceViewDto) => {
					this.dbDrivingLicence = new DrivingLicenceView(drivingLicenceViewDto);
					this.showDlForm = false;
					this.showInitialInfoForm = false;
					this.showDlDisplay = true;
					this.isDocumentNumberValid = true;
					this.hasDlMvrCheck = true;
					this.hasAutoFixedPicturesFromMvr = drivingLicenceViewDto?.hasAutoFixedPictures;
				},
				(errorResponse) => {
					if (errorResponse.error) {
						var canContinue = true;
						if (errorResponse.error.error === 'PersonNotFoundMvrRegixException'
							|| errorResponse.error.error === 'MismatchException') {
							canContinue = false;
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_mvr_not_found_valid_document,
								text: POP_UP_MESSAGES_KEYS.input_valid_document,
								type: PopUpTypes.ERROR
							});
						} else if (errorResponse.error.error === 'DocumentExpiredException') {
							canContinue = false;
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_expired_document,
								text: POP_UP_MESSAGES_KEYS.input_not_expired_document,
								type: PopUpTypes.ERROR
							});
						} else if (errorResponse.error.error === 'ProxyException'
							|| errorResponse.error.error === 'MvrAndGraoDoNotWork') {
							this.switchToDrivingLicenceForm();
							this.drivingLicenceDto.countryId = this.bulgariaCountry.id;
						} else if (errorResponse.error.error === 'InvalidDocumentFromMvrException') {
							canContinue = false;
							PopUpService.showPopUp({
								type: PopUpTypes.ERROR,
								text: Utils.formatString(POP_UP_MESSAGES_KEYS.mvr_check_invalid_document, 
									errorResponse.error.status, errorResponse.error.date, 
									errorResponse.error.statusReason)
							})
						} else if (errorResponse.error.error === 'MvrChangedResponseIssuerNameException') {
							canContinue = false;
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_service_not_work,
								text: POP_UP_MESSAGES_KEYS.error_contact_system_administrator,
								type: PopUpTypes.ERROR
							});
						}
						if (!canContinue) {
							this.isDocumentNumberValid = false;
							return;
						}
					}
				}
				).add(() => {
					this.isLoading = false;
					this.appStepsElementService.setIsEditingToEmptyStep();
				});
		} else {
			this.isDocumentNumberValid = false;
		}
	}

	public submitForeignDl() {
		if (this.documentNumber) {
			this.switchToDrivingLicenceForm();
		} else {
			this.isDocumentNumberValid = false;
		}
	}

	
	private switchToDrivingLicenceForm() {
		if (this.dbDrivingLicence) {
			this.transferDbDataToFormObject();
			this.drivingLicenceDto.isBulgarian = this.isBulgarianDl;
		} else {
			this.drivingLicenceDto = new DrivingLicenceDto();
			this.drivingLicenceDto.applicationId = this.applicationId;
			this.drivingLicenceDto.isBulgarian = this.isBulgarianDl;
			if (this.drivingLicenceDto.isBulgarian) {
				this.drivingLicenceDto.countryId = Countries.BULGARIA_ID;
			}
		}
		this.drivingLicenceDto.documentNumber = this.documentNumber;
		this.showDlForm = true;
		this.showInitialInfoForm = false;
	}

	private getRequestMvrDto() {
		this.requestMvrDto = new RequestMvrDto();
		this.requestMvrDto.applicationId = this.applicationId;
		this.requestMvrDto.identityNumber = this.identityNumberApplicant;
		this.requestMvrDto.identityDocumentType = new Translation(null);
		this.requestMvrDto.identityDocumentType.id = IdentityDocumentTypes.DRIVING_LICENCE;
		this.requestMvrDto.documentNumber = this.documentNumber;
		this.requestMvrDto.nationality = this.bulgariaCountry;
		this.requestMvrDto.isAuthorizedPerson = false;
	}

	public checkValidity($event: Event) {
		if (!this.isBulgarianDl || ($event.target as HTMLInputElement).value.length === this.DOCUMENT_NUM_LENGTH
			&& ($event.target as HTMLInputElement).value.match('^[0-9]*$')) {
			this.isDocumentNumberValid = true;
		} else {
			this.isDocumentNumberValid = false;
		}
	}

	public setIsBulgarianDL(isBg: boolean) {
		this.isBulgarianDl = isBg;
	}

	public displayDrivingLicenceInfo(completedFormDto: DrivingLicenceCompletedFormDto) {
		this.dbDrivingLicence = completedFormDto.drivingLicenceView;
		this.drivingLicenceDto = completedFormDto.drivingLicenceDto;
		this.showDlForm = false;
		this.showDlDisplay = true;
	}

	private transferDbDataToFormObject() {
		this.drivingLicenceDto = new DrivingLicenceDto();
		this.drivingLicenceDto.applicationId = this.applicationId;
		this.drivingLicenceDto.documentNumber = this.dbDrivingLicence.documentNumber;
		this.drivingLicenceDto.dateOfIssue = Utils.convertDateToStringFormatted(new Date(this.dbDrivingLicence.issuedOn));
		this.drivingLicenceDto.categories = [];
		this.dbDrivingLicence.categories.forEach((category) => {
			const dlCategory = new DrivingLicenceCategoryDto();
			dlCategory.categoryId = category.categoryId;
			dlCategory.startDate = Utils.convertDateToStringFormatted(new Date(category.acquisitionDate));
			this.drivingLicenceDto.categories.push(dlCategory);
		});
		this.drivingLicenceDto.countryId = this.dbDrivingLicence.bulgarian ? this.bulgariaCountry?.id : this.dbDrivingLicence.issuedBy.id;
		this.drivingLicenceDto.dateOfExpiry = Utils.convertDateToStringFormatted(new Date(this.dbDrivingLicence.validity));
		this.drivingLicenceDto.documentIssuerId =
			(this.dbDrivingLicence.bulgarian && this.dbDrivingLicence.issuedBy) ? this.dbDrivingLicence.issuedBy.id : NaN;
	}

	public editInitialInfo(initialInfoDto: DrivingLicenceInitialInfoDto) {
		this.drivingLicenceDto = new DrivingLicenceDto();
		this.isBulgarianDl = initialInfoDto.isBulgarian;
		this.documentNumber = initialInfoDto.documentNumber;
		this.showInitialInfoForm = true;
		this.showDlForm = false;
	}

	public editSection() {
		if (this.appStepsElementService.checkIfIsEditingAndSet(Steps.DRIVING_LICENCE)) {
			return;
		}
		this.applicationService.setToMilestone(this.applicationId, MILESTONE_STATUSES.CORRESPONDENCE_INFO_ENTERED)
			.subscribe(
				() => {
					this.transferDbDataToFormObject();
					this.drivingLicenceDto.isEditing = true;
					this.isBulgarianDl = this.drivingLicenceDto.isBulgarian;
					this.showDlForm = true;
					this.showDlDisplay = false;
				}
			);
	}

	public continue(event: Event) {
		this.isReadOnly = true;
		this.appStepsElementService.continueToNextStepFromCurrent(Steps.DRIVING_LICENCE);
		this.appStepsElementService.setIsEditingToEmptyStep();
	}

	setHasAttachedDocuments(hasAttachedDocuments: boolean) {
		this.hasAttachedDocuments = hasAttachedDocuments;
	}

	editSectionDocuments() {
		if (this.appStepsElementService.checkIfIsEditingAndSet(Steps.DRIVING_LICENCE)) {
			return;
		}
		this.applicationService.setToMilestone(this.applicationId, MILESTONE_STATUSES.UPLOAD_DRIVING_LICENCE_DOCUMENTS).subscribe(
			() => {
				this.isReadOnly = false;
			},
			(error) => PopUpService.showPopUp(DEFAULT_POP_UPS.error)
		);
	}

}

