import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { ExamApplicationService } from 'src/app/core/services/exam-application.service';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { MotorExamPeopleQueryParams } from 'src/app/shared/dtos/motor-exam-people-query-params';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { Steps } from 'src/app/shared/enums/steps';
import { CategoryDto } from 'src/app/shared/interfaces/category-dto';
import { MotorExamPersonSelectionDto } from 'src/app/shared/interfaces/motor-exam-person-selection-dto';
import { Category } from 'src/app/shared/models/category';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { MotorExamPersonSelection } from 'src/app/shared/models/exam/motor-exam-person-selection';

@Component({
	selector: 'app-exam-category-selection',
	templateUrl: './exam-category-selection.component.html'
})
export class ExamCategorySelectionComponent implements OnInit, AfterViewInit {

	@ViewChild('examCategorySelectionHtmlElement') htmlElement: { nativeElement: HTMLElement; };

	@Input() public number: number;
	@Input() isDraft: boolean;
	@Input() applicationId: number;

	public categories: Category[] = [];
	public selectedCategory: Category = null;
	@Input() public set setSelectedCategory(category: Category) {
		if (!category) {
			return;
		}
		if (this.isDraft === false) {
			this.selectedCategory = category;
			this.appStepsElementService.canSeeExamCategorySelection = true;
		} else {
			throw new Error("selectedCategory can be set only when isDraft is false");
		}
		if (this.categories.length > 0) {
			for (const category of this.categories) {
				if (this.selectedCategory.categoryId === category.categoryId) {
					this.selectedCategory = category;
					break;
				}
			}
		}
	}

	private selectedExamPerson: MotorExamPersonSelection = null;
	
	@Output() public emitSelectedExamPerson = new EventEmitter<MotorExamPersonSelection>();
	@Output() public emitSelectedCategory = new EventEmitter<Category>();

	public isLoading = false;

	constructor(
		private readonly nomenclatureService: NomenclatureService,
		private readonly appStepsElementService: ApplicationStepsElementsService,
		private readonly examService: ExamApplicationService
	) { }

	ngOnInit(): void {
		this.loadCategories();
	}

	ngAfterViewInit(): void {
		setTimeout(() => {
			this.appStepsElementService.examCategorySelectionEl = this.htmlElement.nativeElement;
			this.appStepsElementService.scrollToStep(Steps.EXAM_CATEGORY_SELECTION);
			// this.emitIsEditing.emit(Steps.ADR_EXAM_PEOPLE);
		});
	}

	public selectCategory(category: Category): void {
		this.selectedCategory = category;
	}

	public onContinueClicked(): void {
		if (!this.selectedCategory) {
			return;
		}

		const queryParams: MotorExamPeopleQueryParams = {
			categoryId: this.selectedCategory.categoryId
		};

		this.isLoading = true;
		this.examService.getMotorExamPeopleForSelection(this.applicationId, queryParams)
			.subscribe((examPeopleDtos: MotorExamPersonSelectionDto[]) => {
				if (!examPeopleDtos || examPeopleDtos.length < 1) {
					PopUpService.showPopUp({
						header: POP_UP_MESSAGES_KEYS.motor_exam_can_not_enroll_for_category_header,
						subHeader: POP_UP_MESSAGES_KEYS.motor_exam_can_not_enroll_for_category_sub_header,
						type: PopUpTypes.WARNING
					});
					return;
				}

				if (examPeopleDtos.length > 1) {
					PopUpService.showPopUp({
						header: POP_UP_MESSAGES_KEYS.motor_exam_can_not_enroll_for_category_header,
						subHeader: POP_UP_MESSAGES_KEYS.motor_exam_can_not_enroll_for_category_sub_header,
						type: PopUpTypes.WARNING
					});
					throw new Error("More than one ExamPerson present.");
				}

				const examPeople = examPeopleDtos.map(examPersonDto => {
					return new MotorExamPersonSelection(examPersonDto);
				});

				this.selectedExamPerson = examPeople[0];

				this.continue();
			}).add(() => {
				this.isLoading = false;
			});
	}

	private continue(): void {
		this.emitSelectedExamPerson.next(this.selectedExamPerson);
		this.emitSelectedCategory.next(this.selectedCategory);
		this.appStepsElementService.continueToNextStepFromCurrent(Steps.EXAM_CATEGORY_SELECTION);
	}

	private loadCategories(): void {
		this.categories.splice(0, this.categories.length);
		this.isLoading = true;

		this.nomenclatureService.getAllCategories()
			.subscribe((categoryDtos: CategoryDto[]) => {
				this.categories = categoryDtos.map(categoryDto => {
					return new Category(categoryDto);
				});

				if (this.selectedCategory) {
					for (const category of this.categories) {
						if (this.selectedCategory.categoryId === category.categoryId) {
							this.selectedCategory = category;
							break;
						}
					}
				}
			}).add(() => {
				this.isLoading = false;
			});
	}
}
