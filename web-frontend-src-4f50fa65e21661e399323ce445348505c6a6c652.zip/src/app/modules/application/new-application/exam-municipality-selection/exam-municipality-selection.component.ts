import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { MunicipalityDto } from 'src/app/shared/dtos/municipality-dto';
import { Steps } from 'src/app/shared/enums/steps';
import { TaxiExamInfo } from 'src/app/shared/models/exam/taxi-exam-info';
import { Municipality } from 'src/app/shared/models/municipality'
import { Region } from 'src/app/shared/models/region';

@Component({
	selector: 'app-exam-municipality-selection',
	templateUrl: './exam-municipality-selection.component.html'
})
export class ExamMunicipalitySelectionComponent implements OnInit {

	@ViewChild('examMunicipalitySelectionHtmlElement') htmlElement: { nativeElement: HTMLElement; };

	@Input() public number: number;
	@Input() isDraft: boolean;

	@Input() taxiExamInfo: TaxiExamInfo;
 
	@Output() public emitIsEditing = new EventEmitter<Steps>();
	@Output() public emitMunicipality = new EventEmitter<Municipality>();

	public regions: Region[] = [];
	public municipalities: any[] = [];
	public selectedRegion: Region = null;
	public selectedMunicipality: Municipality = null;

	public isLoading: boolean = false;
	isReadonly: boolean;
	hasError = false;

	constructor(private nomenclatureService: NomenclatureService,
		private appStepsElementService: ApplicationStepsElementsService) { }

	ngOnInit(): void {
		this.isReadonly = !this.isDraft 
			? true 
			: (this.appStepsElementService.canSeeExamRequiredDocuments ? true : false);
		if (!this.isReadonly) {
			this.loadRegions();
		}
	}

	ngAfterViewInit() {
		setTimeout(()=> {
			this.appStepsElementService.examMunicipalitySelectionEl = this.htmlElement.nativeElement;
			this.appStepsElementService.scrollToStep(Steps.EXAM_MUNICIPALITY_SELECTION);
			this.emitIsEditing.emit(Steps.EXAM_MUNICIPALITY_SELECTION);
		})
	}

	private loadRegions(): void {
		if (this.isDraft === false) {
			return;
		}
		this.isLoading = true;
		this.nomenclatureService.getAllRegions()
			.subscribe(regionDtos => {
				this.regions = regionDtos.map(regionDto => {
					return new Region(regionDto);
				});
			}).add(() => {
				this.isLoading = false;
			});
	}

	loadMunicipalities(): void {
		if (this.isDraft === false) {
			return;
		}
		this.isLoading = true;
		this.municipalities = [];
		this.nomenclatureService.getAllMunicipalitiesByRegion(this.selectedRegion.regionCode)
			.subscribe((municipalities: MunicipalityDto[]) => {
				municipalities.forEach(municipalityDto => {
					this.municipalities.push(new Municipality(municipalityDto));
				});
			})
	}

	continue(): void {
		if (!this.selectedRegion || !this.selectedMunicipality) {
			this.hasError = true;
			return;
		}
		this.emitMunicipality.next(this.selectedMunicipality);
		this.appStepsElementService.continueToNextStepFromCurrent(Steps.EXAM_MUNICIPALITY_SELECTION);
		this.isReadonly = true;
	}

	setHasError() {
		if (this.selectedRegion && this.selectedMunicipality) {
			this.hasError = false;
		}
	}
}
