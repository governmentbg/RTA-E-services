import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { Steps } from 'src/app/shared/enums/steps';
import { OrgUnit } from 'src/app/shared/models/org-unit';

@Component({
  selector: 'app-exam-org-unit-selection',
  templateUrl: './exam-org-unit-selection.component.html'
})
export class ExamOrgUnitSelectionComponent implements OnInit, AfterViewInit {

	@ViewChild('examOrgUnitSelectionHtmlElement') htmlElement: { nativeElement: HTMLElement; };

	@Input() public number: number;
	@Input() isDraft: boolean;
	@Input() applicationId: number;
	@Output() public emitOrgUnit = new EventEmitter<OrgUnit>();

	public orgUnits: OrgUnit[] = [];
	public selectedOrgUnit: OrgUnit = null;
	@Input() public set setSelectedOrgUnit(orgUnit: OrgUnit) {
		if (!orgUnit) {
			return;
		}
		if (this.isDraft === false) {
			this.orgUnits.push(orgUnit);
			this.selectedOrgUnit = orgUnit;
			this.appStepsElementService.canSeeOrgUnitSelection = true;
		} else {
			throw new Error("selectedOrgUnit can be set only when isDraft is false");
		}
	}

	public isLoading: boolean = false;

	constructor(
		private nomenclatureService: NomenclatureService,
		private appStepsElementService: ApplicationStepsElementsService,
	) { }

	ngOnInit(): void {
		this.loadOrgUnits();
	}

	ngAfterViewInit(): void {
		setTimeout(() => {
			this.appStepsElementService.examOrgUnitSelectionEl = this.htmlElement.nativeElement;
			this.appStepsElementService.scrollToStep(Steps.EXAM_ORG_UNIT_SELECTION);
		});
	}

	private loadOrgUnits(): void {
		if (this.isDraft === false) {
			return;
		}
		this.isLoading = true;
		this.nomenclatureService.getAllOrgUnits()
			.subscribe(orgUnitDtos => {
				this.orgUnits = orgUnitDtos.map(orgUnitDto => {
					return new OrgUnit(orgUnitDto);
				});
			}).add(() => {
				this.isLoading = false;
			});
	}

	continue(event: Event): void {
		this.emitOrgUnit.next(this.selectedOrgUnit);
	}
}
