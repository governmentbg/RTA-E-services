import { AdrExamProtocolSelectionDto } from "src/app/shared/interfaces/adr-exam-protocol-selection-dto";

export class AdrExamProtocolSelection {
    
    id: number;
	number: string;
	examDateTime: Date;
	roomName: string;
	remainingSeats: number;
    remainingSeatsArray: number[] = [];

    constructor(dto: AdrExamProtocolSelectionDto) {
        this.id = dto.id;
        this.number = dto.number;
        this.examDateTime = dto.examDateTime;
        this.roomName = dto.roomName;
        this.remainingSeats = dto.remainingSeats;
        this.remainingSeatsArray = Array(this.remainingSeats).fill(0).map((_x,i)=>i);
    }
}