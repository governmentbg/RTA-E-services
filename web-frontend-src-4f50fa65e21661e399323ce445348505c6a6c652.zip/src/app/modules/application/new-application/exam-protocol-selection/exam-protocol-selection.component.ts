import { KeyValue } from '@angular/common';
import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Language } from 'angular-l10n';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { ExamApplicationService } from 'src/app/core/services/exam-application.service';
import { AdrConsultantExamEnrollmentRequestDto } from 'src/app/shared/dtos/adr-consultant-exam-enrollment-request-dto';
import { AdrExamEnrolmentRequestDto } from 'src/app/shared/dtos/adr-exam-enrolment-request-dto';
import { MotorExamEnrolmentRequestDto } from 'src/app/shared/dtos/motor-exam-enrolment-request-dto';
import { TaxiExamEnrolmentRequestDto } from 'src/app/shared/dtos/taxi-exam-enrollment-request-dto';
import { APPLICATION_TYPE } from 'src/app/shared/enums/application-types';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';
import { Steps } from 'src/app/shared/enums/steps';
import { AdrExamProtocolsResponseDto } from 'src/app/shared/interfaces/adr-exam-protocols-response-dto';
import { MotorExamProtocolSelectionQueryParams } from 'src/app/shared/interfaces/exam/motor-exam-protocol-selection-query-params';
import { MotorExamProtocolsResponseDto } from 'src/app/shared/interfaces/exam/motor-exam-protocols-response-dto';
import { Category } from 'src/app/shared/models/category';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { MotorExamPersonSelection } from 'src/app/shared/models/exam/motor-exam-person-selection';
import { Municipality } from 'src/app/shared/models/municipality';
import { OrgUnit } from 'src/app/shared/models/org-unit';
import { AdrExamPersonSelection } from '../adr-exam-people/adr-exam-person-selection.model';
import { ConsultantExamLearningPlanSelection } from '../adr-exam-people/consultant-exam-learning-plan-selection';
import { AdrExamProtocolSelection } from './adr-exam-protocol-selection.model';
import { MotorExamProtocolSelection } from './motor-exam-protocol-selection.model';

@Component({
	selector: 'app-exam-protocol-selection',
	templateUrl: './exam-protocol-selection.component.html'
})
export class ExamProtocolSelectionComponent implements OnInit, AfterViewInit {

	public readonly APPLICATION_TYPE = APPLICATION_TYPE;
	public readonly dateFormat = S_VARIABLES.DATE_FORMAT;
	public readonly timeFormat = S_VARIABLES.TIME_FORMAT;
	public readonly Steps = Steps;

	@Language() lang: string;

	@ViewChild('examProtocolSelectionHtmlElement') htmlElement: { nativeElement: HTMLElement; };

	dateKeyAscOrder = (a: KeyValue<Date, AdrExamProtocolSelection[]>, b: KeyValue<Date, AdrExamProtocolSelection[]>): number => {
		return a.key.getTime() < b.key.getTime() ? -1 : (b.key.getTime() < a.key.getTime() ? 1 : 0);
	}

	@Input() public number: number;
	@Input() isDraft: boolean;

	private applicationId: number;
	@Input() public set setApplicationId(applicationId: number) {
		this.applicationId = applicationId;
		if (applicationId && this.selectedOrgUnit) {
			this.loadProtocols();
		}
	}

	public selectedOrgUnit: OrgUnit;
	@Input() public set setSelectedOrgUnit(orgUnit: OrgUnit) {
		this.selectedOrgUnit = orgUnit;
		if (this.applicationId && orgUnit) {
			this.loadProtocols();
		}
	};

	public selectedMunicipality: Municipality;
	@Input() public set setSelectedMunicipality(municipality: Municipality) {
		this.selectedMunicipality = municipality;
		if (this.applicationId && municipality) {
			this.loadProtocols();
		}
	};

	public taxiExamRequestDto: TaxiExamEnrolmentRequestDto;
	@Input() public set setTaxiExamRequestDto(dto: TaxiExamEnrolmentRequestDto) {
		this.taxiExamRequestDto = dto;
	}
	@Input() isEditing: Steps;

	@Input() public selectedAdrExamPerson: AdrExamPersonSelection;
	@Input() public selectedAdrConsultantLearningPlan: ConsultantExamLearningPlanSelection;
	@Input() public selectedMotorExamPerson: MotorExamPersonSelection;
	@Input() public selectedMotorExamCategory: Category;

	@Output() public emitIsEditing = new EventEmitter<Steps>();

	public shortPaymentProtocolsByDateMap: Map<Date, AdrExamProtocolSelection[]> = new Map(); 
	public longPaymentProtocolsByDateMap: Map<Date, AdrExamProtocolSelection[]> = new Map(); 
	public availableProtocolsCount: number = 0;

	public selectedProtocol: AdrExamProtocolSelection | MotorExamProtocolSelection = null;
	@Input() public set setSelectedAdrProtocol(protocol: AdrExamProtocolSelection) {
		if (!protocol) {
			return;
		}
		if (this.isDraft === false) {
			this.selectedProtocol = protocol;
			this.appStepsElementService.canSeeExamProtocolSelection = true;
		} else {
			throw new Error("selectedProtocol can be set only when isDraft is false");
		}
	}
	@Input() public set setSelectedMotorProtocol(protocol: MotorExamProtocolSelection) {
		if (!protocol) {
			return;
		}
		if (this.isDraft === false) {
			this.selectedProtocol = protocol;
			this.appStepsElementService.canSeeExamProtocolSelection = true;
		} else {
			throw new Error("selectedProtocol can be set only when isDraft is false");
		}
	}

	@Input() public set setSelectedTaxiProtocol(protocol: MotorExamProtocolSelection) {
		if (!protocol) {
			return;
		}
		if (this.isDraft === false) {
			this.selectedProtocol = protocol;
			this.appStepsElementService.canSeeExamProtocolSelection = true;
		} else {
			throw new Error("selectedProtocol can be set only when isDraft is false");
		}
	}

	public isLoading = false;

	constructor(
		public readonly appStepsElementService: ApplicationStepsElementsService,
		private readonly examApplicationService: ExamApplicationService,
		private readonly router: Router
	) { }

	ngOnInit(): void {
		if (!this.selectedAdrExamPerson && !this.selectedAdrConsultantLearningPlan
			&& !this.selectedMotorExamPerson && !this.selectedMunicipality 
			&& (!this.selectedProtocol && this.appStepsElementService.applicationTypeId === APPLICATION_TYPE.APPLICATION_TAXI_EXAM)) {
			throw new Error('app-exam-protocol-selection component needs the selectedExamPerson' 
				+ ' or the selectedAdrConsultantLearningPlan' 
				+ ' or the selectedMunicipality'
				+ ' or selectedMotorExamPerson parameter'
				+ ' or selectedProtocol & application type = taxi has to be set.');
		}

		if (this.selectedMotorExamPerson) {
			this.setSelectedOrgUnit = this.selectedMotorExamPerson.orgUnit;
		}
	}

	ngAfterViewInit(): void {
		setTimeout(() => {
			this.appStepsElementService.examProtocolSelectionEl = this.htmlElement.nativeElement;
			this.appStepsElementService.scrollToStep(Steps.EXAM_PROTOCOL_SELECTION);
			this.emitIsEditing.emit(Steps.EXAM_PROTOCOL_SELECTION);
		});
	}

	private initializeProtocolsByDateMap(fromDate: Date, toDate: Date, minExamDayFromTodayForLongPayment: number,
			protocols: AdrExamProtocolSelection[] | MotorExamProtocolSelection[]): void {
		fromDate = new Date(fromDate);
		fromDate.setHours(0, 0, 0, 0);
		toDate = new Date(toDate);
		toDate.setHours(0, 0, 0, 0);

		this.selectedProtocol = null;
		this.shortPaymentProtocolsByDateMap.clear();
		this.longPaymentProtocolsByDateMap.clear();

		this.availableProtocolsCount = protocols.length;

		const protocolsByTimestampMap: Map<number, AdrExamProtocolSelection[]> = new Map();

		let date: Date = null;
		let i = 0;
		while (date == null || date.getTime() < toDate.getTime()) {
			date = new Date(fromDate);
			date.setDate(date.getDate() + i++);
			date.setHours(0, 0, 0, 0);
			protocolsByTimestampMap.set(date.getTime(), []);
		}
		for (let i = 0; i < protocols.length; i++) {
			const protocol = protocols[i];
			const examDate = new Date(protocol.examDateTime);
			examDate.setHours(0, 0, 0, 0);

			const protocolsArray = protocolsByTimestampMap.get(examDate.getTime());
			protocolsArray.push(protocol);
		}

		const minExamDateFromTodayForLongPayment = new Date();
		minExamDateFromTodayForLongPayment.setHours(0, 0, 0, 0);
		minExamDateFromTodayForLongPayment.setDate(minExamDateFromTodayForLongPayment.getDate() + minExamDayFromTodayForLongPayment)
		protocolsByTimestampMap.forEach((protocols: AdrExamProtocolSelection[], time: number) => {
			const protocolsDate = new Date(time);
			if (protocolsDate.getTime() < minExamDateFromTodayForLongPayment.getTime()) {
				this.shortPaymentProtocolsByDateMap.set(protocolsDate, protocols);
			} else {
				this.longPaymentProtocolsByDateMap.set(protocolsDate, protocols);
			}
		});

		setTimeout(() => {
			this.appStepsElementService.scrollToStep(Steps.EXAM_PROTOCOL_SELECTION);
		});
	}

	private loadProtocols(): void {
		if (this.isDraft === false) {
			return;
		}
		if (this.appStepsElementService.applicationTypeId === APPLICATION_TYPE.APPLICATION_CONSULTANT_EXAM) {
			this.loadConsultantExamProtocols();
		} else if (this.appStepsElementService.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_EXAM) {
			this.loadAdrExamProtocols();
		} else if (this.appStepsElementService.applicationTypeId === APPLICATION_TYPE.APPLICATION_TAXI_EXAM) {
			this.loadTaxiExamProtocols();
		} else if (this.appStepsElementService.applicationTypeId === APPLICATION_TYPE.APPLICATION_MOTOR_EXAM) {
			this.loadMotorExamProtocols();
		} else {
			throw new Error("Unsupported application type.");
		}
	}

	private loadAdrExamProtocols() {
		this.isLoading = true;

		this.selectedProtocol = null;
		this.shortPaymentProtocolsByDateMap.clear();
		this.longPaymentProtocolsByDateMap.clear();

		this.examApplicationService.getAdrExamProtocolsForSelection(this.applicationId, this.selectedOrgUnit.code)
			.subscribe((responseDto: AdrExamProtocolsResponseDto) => {
				const fromDate = responseDto.fromDate;
				const toDate = responseDto.toDate;
				const minExamDayFromTodayForLongPayment = responseDto.minExamDayFromTodayForLongPayment;
				if (responseDto.protocols) {
					const protocols = responseDto.protocols.map(protocolDto => {
						return new AdrExamProtocolSelection(protocolDto);
					});
					this.initializeProtocolsByDateMap(fromDate, toDate, minExamDayFromTodayForLongPayment, protocols);
				} else {
					this.initializeProtocolsByDateMap(fromDate, toDate, minExamDayFromTodayForLongPayment, []);
				}
			}).add(() => {
				this.isLoading = false;
			});
	}

	private loadConsultantExamProtocols() {
		this.isLoading = true;

		this.selectedProtocol = null;
		this.shortPaymentProtocolsByDateMap.clear();
		this.longPaymentProtocolsByDateMap.clear();

		this.examApplicationService.getConsultantExamProtocolsForSelection(this.applicationId)
			.subscribe((responseDto: AdrExamProtocolsResponseDto) => {
				const fromDate = responseDto.fromDate;
				const toDate = responseDto.toDate;
				const minExamDayFromTodayForLongPayment = responseDto.minExamDayFromTodayForLongPayment;
				if (responseDto.protocols) {
					const protocols = responseDto.protocols.map(protocolDto => {
						return new AdrExamProtocolSelection(protocolDto);
					});
					this.initializeProtocolsByDateMap(fromDate, toDate, minExamDayFromTodayForLongPayment, protocols);
				} else {
					this.initializeProtocolsByDateMap(fromDate, toDate, minExamDayFromTodayForLongPayment, []);
				}
			}).add(() => {
				this.isLoading = false;
			});
	}

	private loadTaxiExamProtocols() {
		this.examApplicationService.getTaxiExamProtocols(this.applicationId, this.selectedMunicipality.regionCode)
			.subscribe((responseDto: MotorExamProtocolsResponseDto) => {
				const fromDate = responseDto.fromDate;
				const toDate = responseDto.toDate;
				const minExamDayFromTodayForLongPayment = responseDto.minExamDayFromTodayForLongPayment;
				if (responseDto.protocols) {
					const protocols = responseDto.protocols.map(protocolDto => {
						return new MotorExamProtocolSelection(protocolDto);
					});
					this.initializeProtocolsByDateMap(fromDate, toDate, minExamDayFromTodayForLongPayment, protocols);
				} else {
					this.initializeProtocolsByDateMap(fromDate, toDate, minExamDayFromTodayForLongPayment, []);
				}
			}).add(() => {
				this.isLoading = false;
			});
	}

	private loadMotorExamProtocols(): void {
		const queryParams: MotorExamProtocolSelectionQueryParams = {
			orgUnitCode: this.selectedOrgUnit.code
		};

		this.isLoading = true;
		this.examApplicationService.getMotorExamProtocolsForSelection(this.applicationId, queryParams)
			.subscribe((responseDto: MotorExamProtocolsResponseDto) => {
				const fromDate = responseDto.fromDate;
				const toDate = responseDto.toDate;
				const minExamDayFromTodayForLongPayment = responseDto.minExamDayFromTodayForLongPayment;
				if (responseDto.protocols) {
					const protocols = responseDto.protocols.map(protocolDto => {
						return new MotorExamProtocolSelection(protocolDto);
					});
					this.initializeProtocolsByDateMap(fromDate, toDate, minExamDayFromTodayForLongPayment, protocols);
				} else {
					this.initializeProtocolsByDateMap(fromDate, toDate, minExamDayFromTodayForLongPayment, []);
				}
			}).add(() => {
				this.isLoading = false;
			});
	}

	public selectProtocol(protocol: AdrExamProtocolSelection | MotorExamProtocolSelection) {
		this.selectedProtocol = protocol;
		if (protocol['orgUnit'] !== undefined) {
			this.selectedOrgUnit = protocol['orgUnit'];
		}
	}

	public reserveExam(): void {
		if (!this.selectedProtocol) {
			console.error('Can not reserve exam. No protocol selected.');
			return;
		}

		console.log('reserveExam: ', this.appStepsElementService.applicationTypeId, this.selectedAdrConsultantLearningPlan);
		if (this.appStepsElementService.applicationTypeId === APPLICATION_TYPE.APPLICATION_CONSULTANT_EXAM
			&& this.selectedAdrConsultantLearningPlan) {
			this.enrolForConsultantExtensionExam();
		} else if (this.appStepsElementService.applicationTypeId === APPLICATION_TYPE.APPLICATION_CONSULTANT_EXAM
			&& this.selectedAdrExamPerson) {
			this.enrolForAdrExam();
		} else if (this.appStepsElementService.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_EXAM
			&& this.selectedAdrExamPerson) {
			this.enrolForAdrExam();
		} else if (this.appStepsElementService.applicationTypeId === APPLICATION_TYPE.APPLICATION_MOTOR_EXAM
			&& this.selectedMotorExamPerson && this.selectedMotorExamCategory) {
			this.enrolForMotorExam();
		} else if (this.appStepsElementService.applicationTypeId === APPLICATION_TYPE.APPLICATION_TAXI_EXAM 
			&& this.selectedMunicipality) {
			this.enrolForTaxiExam();
		} else {
			throw new Error("Unsupported application type.");
		}
	}

	private enrolForAdrExam(): void {
		const requestDto = new AdrExamEnrolmentRequestDto(this.selectedAdrExamPerson.id, this.selectedProtocol.id, 
			this.selectedOrgUnit.code);

		this.isLoading = true;
		this.examApplicationService.enrolForAdrExam(this.applicationId, requestDto)
			.subscribe(() => {
				this.continue();
			}).add(() => {
				this.isLoading = false;
			});
	}

	private enrolForConsultantExtensionExam(): void {
		const requestDto = new AdrConsultantExamEnrollmentRequestDto();
		requestDto.protocolId = this.selectedProtocol.id;
		requestDto.learningPlanId = this.selectedAdrConsultantLearningPlan.id;

		this.isLoading = true;
		this.examApplicationService.enrolForAdrConsultantExtensionExam(this.applicationId, requestDto)
			.subscribe(() => {
				this.continue();
			}).add(() => {
				this.isLoading = false;
			});
	}

	private enrolForMotorExam(): void {
		const requestDto: MotorExamEnrolmentRequestDto = {
			examPersonId: this.selectedMotorExamPerson.examPersonId,
			protocolId: this.selectedProtocol.id,
			selectCategoryId: this.selectedMotorExamCategory.categoryId
		};
		console.log('enrolForMotorExam requestDto: ', requestDto);
		this.isLoading = true;
		this.examApplicationService.enrolForMotorExam(this.applicationId, requestDto)
			.subscribe(() => {
				this.continue();
			}).add(() => {
				this.isLoading = false;
			});
	}

	private enrolForTaxiExam(): void {
		this.taxiExamRequestDto.municipalityCode = this.selectedMunicipality.code;
		this.taxiExamRequestDto.orgUnitCode = this.selectedOrgUnit.code;
		this.taxiExamRequestDto.protocolId = this.selectedProtocol.id;
		this.isLoading = true;
		this.examApplicationService.enrolForTaxiExam(this.applicationId, this.taxiExamRequestDto).subscribe(()=> {
			this.continue();
		}).add(()=> {
			this.isLoading = false;
		})
	}

	private continue(): void {
		this.appStepsElementService.continueToNextStepFromCurrent(Steps.EXAM_PROTOCOL_SELECTION);
		this.router.navigate([RouteUrl.APPLICATION, this.applicationId]);
	}
}
