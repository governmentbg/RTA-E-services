import { MotorExamProtocolSelectionDto } from "src/app/shared/interfaces/motor-exam-protocol-selection-dto";
import { OrgUnit } from "src/app/shared/models/org-unit";
import { AdrExamProtocolSelection } from "./adr-exam-protocol-selection.model";

export class MotorExamProtocolSelection extends AdrExamProtocolSelection {
    orgUnit: OrgUnit;

    constructor(dto: MotorExamProtocolSelectionDto) {
        super(dto);

        this.orgUnit = new OrgUnit(dto.orgUnit);
    }
}