import { FormGroup, Validators } from "@angular/forms";
import { TaxiExamEnrolmentRequestDto } from "src/app/shared/dtos/taxi-exam-enrollment-request-dto";
import { AbstractForm } from "src/app/shared/models/abstract-form";
import { Utils } from "src/app/shared/utils/utils";

export class ExamRequiredDocumentsFrom extends AbstractForm<TaxiExamEnrolmentRequestDto> {
	constructor(isDeskStaff?: boolean) {
		super();
		this.formGroup = this.createFormGroup(isDeskStaff);
	}

	get certificateOfConvictionCheck() {
		return this.formGroup.get('certificateOfConvictionCheck');
	}
	
	get certificateOfConvictionNumber() {
		return this.formGroup.get('certificateOfConvictionNumber');
	}

	get certificateOfConvictionIssueDate() {
		return this.formGroup.get('certificateofConvictionIssueDate');
	}

	get municipalityCode() {
		return this.formGroup.get("municipalityCode");
	}
	get protocolId() {
		return this.formGroup.get("protocolId");
	}

	get criminalRecordCertificateCheck() {
		return this.formGroup.get('criminalRecordCertificateCheck');
	}

	get criminalRecordCertificateNumber() {
		return this.formGroup.get('criminalRecordCertificateNumber');
	}
	
	get criminalRecordCertificateIssueDate() {
		return this.formGroup.get('criminalRecordCertificateIssueDate');
	}

	get convictionCheck() {
		return this.formGroup.get('convictionCheck');
	}

	get revokedDrivingLicenceCheck() {
		return this.formGroup.get('revokedDrivingLicenceCheck');
	}

	get certificateOfPsychologicalFitnessCheck() {
		return this.formGroup.get('certificateOfPsychologicalFitnessCheck');
	}

	get certificateOfPsychologicalFitnessNumber() {
		return this.formGroup.get('certificateOfPsychologicalFitnessNumber');
	}

	get certificateOfPsychologicalFitnessIssueDate() {
		return this.formGroup.get('certificateOfPsychologicalFitnessIssueDate');
	}

	get drivingLicenceCopyNumber() {
		return this.formGroup.get('drivingLicenceCopyNumber');
	}

	get drivingLicenceCopyIssueDate() {
		return this.formGroup.get('drivingLicenceCopyIssueDate');
	}

	get drivingLicenceCopyCheck() {
		return this.formGroup.get('drivingLicenceCopyCheck');
	}

	get drivingLicenceSuspensionCheck() {
		return this.formGroup.get('drivingLicenceSuspensionCheck');
	}

	get drivingLicenceSobrietyCheck() {
		return this.formGroup.get('drivingLicenceSobrietyCheck');
	}

	get imposedPenaltiesCheck() {
		return this.formGroup.get('imposedPenaltiesCheck');
	}

	public toRequestDto(params?: object): TaxiExamEnrolmentRequestDto {

		return {
			orgUnitCode: null,
			municipalityCode: null,
			protocolId: null,
			// certificateOfConvictionCheck: this.certificateOfConvictionCheck.value,
			criminalRecordCertificateNumber: this.criminalRecordCertificateNumber.value,
			criminalRecordCertificateIssueDate: Utils.convertDateToStringFormatted(new Date(this.criminalRecordCertificateIssueDate.value)),
			// criminalRecordCertificateCheck: this.criminalRecordCertificateCheck.value,
			certificateOfPsychologicalFitnessNumber: this.certificateOfPsychologicalFitnessNumber.value,
			certificateOfPsychologicalFitnessIssueDate: Utils.convertDateToStringFormatted(new Date(this.certificateOfPsychologicalFitnessIssueDate.value)),
			// certificateOfPsychologicalFitnessCheck: this.certificateOfPsychologicalFitnessCheck,
			// drivingLicenceSuspensionCheck: this.drivingLicenceSuspensionCheck.value,
			// drivingLicenceSobrietyCheck: this.drivingLicenceSobrietyCheck.value,
			// drivingLicenceCheck: this.drivingLicenceCheck.value
		}
	}

	private createFormGroup(isDeskStaff?: boolean, isServiceCheck?: boolean): FormGroup {
		if (isDeskStaff) {
			let formGroup = this.formBuilder.group({
				criminalRecordCertificateNumber: [null, Validators.required],
				criminalRecordCertificateIssueDate: [null, [
					Validators.required ]],
				convictionCheck: [false, Validators.requiredTrue],
				revokedDrivingLicenceCheck: [false, Validators.requiredTrue],
				certificateOfPsychologicalFitnessNumber: [null, [
					Validators.required
				]],
				certificateOfPsychologicalFitnessIssueDate: [null, Validators.required],
				drivingLicenceSuspensionCheck: [false, Validators.requiredTrue],
				drivingLicenceSobrietyCheck: [false, Validators.requiredTrue]
			});
			return formGroup;
		} else {
			return this.formBuilder.group({
				criminalRecordCertificateNumber: [null, Validators.required],
				criminalRecordCertificateIssueDate: [null, [
					Validators.required ]],
				convictionCheck: [false, Validators.requiredTrue],
				revokedDrivingLicenceCheck: [false, Validators.requiredTrue],
				criminalRecordCertificateCheck: [false, Validators.requiredTrue],
				drivingLicenceCopyNumber: [null, Validators.required],
				drivingLicenceCopyIssueDate: [null, Validators.required],
				drivingLicenceCopyCheck: [false, Validators.requiredTrue],
				certificateOfPsychologicalFitnessNumber: [null, [
					Validators.required
				]],
				certificateOfPsychologicalFitnessIssueDate: [null, Validators.required],
				certificateOfPsychologicalFitnessCheck: [false, Validators.requiredTrue],
				drivingLicenceSuspensionCheck: [false, Validators.requiredTrue],
				drivingLicenceSobrietyCheck: [false, Validators.requiredTrue],
				imposedPenaltiesCheck: [false, Validators.requiredTrue]
			});
		}
	}

	public isValid() {
		const invalid = [];
        const controls = this.formGroup.controls;
        for (const name in controls) {
            if (controls[name].invalid) {
                invalid.push(name);
            }
        }
		
		if (this.formGroup.valid) {
			return true;
		} else {
			return false;
		}
	}
	
}