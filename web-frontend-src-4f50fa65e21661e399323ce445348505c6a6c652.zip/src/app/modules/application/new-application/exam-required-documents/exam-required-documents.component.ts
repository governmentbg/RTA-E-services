import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { DrivingLicenceView } from 'src/app/shared/models/driving-licence-view';
import { TaxiExamEnrolmentRequestDto } from 'src/app/shared/dtos/taxi-exam-enrollment-request-dto';
import { Steps } from 'src/app/shared/enums/steps';
import { User } from 'src/app/shared/models/user';
import { ExamRequiredDocumentsFrom } from './exam-required-documents-form';

@Component({
	selector: 'app-exam-required-documents',
	templateUrl: './exam-required-documents.component.html'
})
export class ExamRequiredDocumentsComponent implements OnInit { examRequiredDocumentsHtmlElement

	@ViewChild('examRequiredDocumentsHtmlElement') htmlElement: { nativeElement: HTMLElement; };

	@Input() public number: number;
	@Input() user: User;
	@Input() dbDrivingLicence: DrivingLicenceView;

	@Output() public emitIsEditing = new EventEmitter<Steps>();
	@Output() public emitTaxiExamRequestDto = new EventEmitter<TaxiExamEnrolmentRequestDto>();

	public examDocumentsForm: ExamRequiredDocumentsFrom;

	isDeskStaff: boolean;
	today: Date = new Date();
	serviceCheck = false;
	isApplicant: boolean;

	constructor(private appStepsElementService: ApplicationStepsElementsService) { }

	ngOnInit(): void {
		this.isDeskStaff = this.user.isDeskStaff();
		this.examDocumentsForm = new ExamRequiredDocumentsFrom(this.isDeskStaff);
		this.isApplicant = this.user.isApplicant();

	}

	ngAfterViewInit() {
		setTimeout(()=> {
			this.appStepsElementService.examRequiredDocumentsEl = this.htmlElement.nativeElement;
			this.appStepsElementService.scrollToStep(Steps.EXAM_REQUIRED_DOCUMENTS);
			this.emitIsEditing.emit(Steps.EXAM_REQUIRED_DOCUMENTS);
		})
	}

	save() {
		if (this.examDocumentsForm.isValid()) {
			this.appStepsElementService.continueToNextStepFromCurrent(Steps.EXAM_REQUIRED_DOCUMENTS);
		}
		this.emitTaxiExamRequestDto.next(this.examDocumentsForm.toRequestDto());
	}

	toggleCertificateOfConvictionCheck() {
		this.examDocumentsForm.certificateOfConvictionCheck
			.setValue(!this.examDocumentsForm.certificateOfConvictionCheck.value);
	}

	toggleCriminalRecordCertificateCheck() {
		this.examDocumentsForm.criminalRecordCertificateCheck
			.setValue(!this.examDocumentsForm.criminalRecordCertificateCheck.value);
	}

	toggleConvictionCheck() {
		this.examDocumentsForm.convictionCheck
			.setValue(!this.examDocumentsForm.convictionCheck.value);
	}

	toggleRevokedDrivingLicenceCheck() {
		this.examDocumentsForm.revokedDrivingLicenceCheck
			.setValue(!this.examDocumentsForm.revokedDrivingLicenceCheck.value);
	}

	toggleCertificateOfPsychologicalFitnessCheck() {
		this.examDocumentsForm.certificateOfPsychologicalFitnessCheck
			.setValue(!this.examDocumentsForm.certificateOfPsychologicalFitnessCheck.value);
	}

	toggleDrivingLicenceCopyCheck() {
		this.examDocumentsForm.drivingLicenceCopyCheck
			.setValue(!this.examDocumentsForm.drivingLicenceCopyCheck.value);
	}

	toggleDrivingLicenceSuspensionCheck() {
		this.examDocumentsForm.drivingLicenceSuspensionCheck
			.setValue(!this.examDocumentsForm.drivingLicenceSuspensionCheck.value);
	}

	toggleDrivingLicenceSobrietyCheck() {
		this.examDocumentsForm.drivingLicenceSobrietyCheck
			.setValue(!this.examDocumentsForm.drivingLicenceSobrietyCheck.value);
	}

	toggleImposedPenaltiesCheck() {
		this.examDocumentsForm.imposedPenaltiesCheck
			.setValue(!this.examDocumentsForm.imposedPenaltiesCheck.value);
	}

	toggleServiceCheck() {
		this.serviceCheck = !this.serviceCheck;
		this.examDocumentsForm = new ExamRequiredDocumentsFrom(this.isDeskStaff);
	}

}
