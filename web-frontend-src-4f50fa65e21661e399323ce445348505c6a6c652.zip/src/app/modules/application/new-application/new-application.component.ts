import { ActivatedRoute, Router } from '@angular/router';
import { ApplicationDraft } from 'src/app/shared/models/application-draft';
import { ApplicationDraftDto } from 'src/app/shared/interfaces/application-draft-dto';
import { ApplicationService } from 'src/app/core/services/application.service';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { Subscription } from 'rxjs';
import { SubHeaderApplicationInfo } from 'src/app/shared/models/sub-header-application-info';
import { User } from 'src/app/shared/models/user';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';
import { Names } from 'src/app/shared/models/names';
import { DocumentService } from 'src/app/core/services/document.service';
import { APPLICATION_TYPE, CARD_APPLICATIONS } from 'src/app/shared/enums/application-types';
import { Certificate } from 'src/app/shared/models/certificate';
import { AdrModule } from 'src/app/shared/models/adr-module';
import { Translation } from 'src/app/shared/models/translation';
import { PersonalInfo } from 'src/app/shared/models/personal-info';
import { ContactView } from 'src/app/shared/models/contact-view';
import { DeliveryInfo } from 'src/app/shared/models/delivery-info';
import { Steps } from 'src/app/shared/enums/steps';
import { DrivingLicenceView } from 'src/app/shared/models/driving-licence-view';
import { CardView } from 'src/app/shared/models/card-renewal-view';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { TranslationDto } from 'src/app/shared/interfaces/translation-dto';
import { OrgUnit } from 'src/app/shared/models/org-unit';
import { AdrExamPersonSelection } from './adr-exam-people/adr-exam-person-selection.model';
import { ServiceOptions } from './adr-exam-service-options/adr-exam-service-options.component';
import { ConsultantExamLearningPlanSelection } from './adr-exam-people/consultant-exam-learning-plan-selection';
import { TaxiExamEnrolmentRequestDto } from 'src/app/shared/dtos/taxi-exam-enrollment-request-dto';
import { MotorExamPersonSelection } from 'src/app/shared/models/exam/motor-exam-person-selection';
import { Municipality } from 'src/app/shared/models/municipality';
import { Category } from 'src/app/shared/models/category';

@Component({
	selector: 'app-new-application',
	templateUrl: './new-application.component.html',
})
export class NewApplicationComponent implements OnInit, OnDestroy {
	@Input() user: User;
	title: string;
	private routeSubscription: Subscription;
	public applicationId: number;
	public applicationTypeId: number;
	public isDraft = true;
	public personalNumber: string;
	public applicationDraft: ApplicationDraft;
	public applicationProgress = 0;
	public isPersonalDataReady = false;
	public isEditing = Steps.EMPTY_STEP;

	public steps = Steps;

	public hasMvrCheck: boolean;

	public hasDlMvrCheck: boolean;
	public hasGraoCheck: boolean;
	public personalInfo: PersonalInfo = null;
	public applicantIsBulgarian: boolean;
	public contactView: ContactView = null;
	public drivingLicence: DrivingLicenceView = null;
	public cardView: CardView = null;
	public delivery: DeliveryInfo = null;

	public names: Names = null;
	public dqcCertificates: Certificate[] = null;
	public adrModules: AdrModule[] = null;
	public hasEditedPictures: boolean;
	public hasAutoFixedPicturesFromMvr: boolean;
	public areRequiredDocumentsAttached: boolean;
	public attachedDocuments: Translation[] = [];

	public adrServiceOption: ServiceOptions = null;

	public bulgariaCountry: Translation;

	public selectedExamOrgUnit: OrgUnit = null;
	public selectedAdrExamPerson: AdrExamPersonSelection = null;
	public selectedMotorExamPerson: MotorExamPersonSelection = null;
	public selectedMotorExamCategory: Category = null;
	public selectedAdrConsultantLearningPlan: ConsultantExamLearningPlanSelection;

	public selectedMunicipality: Municipality = null;
	public taxiExamRequestDto: TaxiExamEnrolmentRequestDto = null;

	private cardApplicationTypes = CARD_APPLICATIONS;

	constructor(
		private readonly router: Router,
		private readonly route: ActivatedRoute,
		private readonly nomenclatureService: NomenclatureService,
		private readonly applicationService: ApplicationService,
		private readonly authenticationService: AuthenticationService,
		private readonly documentService: DocumentService,
		public readonly appStepsElementService: ApplicationStepsElementsService,
	) { }

	ngOnInit() {
		this.user = this.authenticationService.getAuthenticatedUser();
		this.appStepsElementService.completeReset();
		this.getBulgariaCountryTranslation();
		this.routeSubscription = this.route.params.subscribe(params => {
			if (params.type) {
				this.applicationTypeId = +params.type;
				this.getChosenApplicationType(this.applicationTypeId);
				this.applicationService.setApplicationInfoForHeader(new SubHeaderApplicationInfo(null, 0, true));
				this.appStepsElementService.calculateOneStepSize(this.applicationTypeId);
				this.appStepsElementService.setStepsNumbers();
				this.isPersonalDataReady = true;
			} else if (params.id) {
				this.applicationId = +params.id;
				this.applicationService
					.getApplicationDraft(this.applicationId)
					.subscribe(
						(dto: ApplicationDraftDto) => {
							this.documentService
								.areRequiredDocumentsAttached(this.applicationId).subscribe((areRequiredDocumentsAttached: boolean) => {
									this.applicationDraft = new ApplicationDraft(dto);
									this.title = this.applicationDraft.applicationType.key;
									this.applicationTypeId = this.applicationDraft.applicationType.id;
									this.appStepsElementService.calculateOneStepSize(this.applicationTypeId);
									this.appStepsElementService.setStepsNumbers();
									this.hasMvrCheck = this.applicationDraft.hasMvrCheck;
									this.hasDlMvrCheck = this.applicationDraft.hasDlMvrCheck;
									this.hasGraoCheck = this.applicationDraft.hasGraoCheck; 
									this.hasAutoFixedPicturesFromMvr = this.applicationDraft.hasAutoFixedPicturesFromMvr;
									this.hasEditedPictures = this.applicationDraft.hasEditedPictures;
									this.areRequiredDocumentsAttached = areRequiredDocumentsAttached;
									this.attachedDocuments = this.applicationDraft.attachedDocs;
									this.cardView = this.applicationDraft.cardView;
									this.applicationService.setApplicationInfoForHeader(
										new SubHeaderApplicationInfo(this.applicationId, this.applicationProgress, true));
									if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_CONSULTANT_EXAM) {
										this.selectedExamOrgUnit = new OrgUnit({
											code: 'ИААА',
											name: 'org_unit.iaaa',
											address: 'org_unit_address.iaaa',
											phoneNumber: '-',
											cityTranslationKey: 'cities.gr_Sofia'
										});
									}
									this.personalNumber = this.applicationDraft.identityNumber;
									if (this.applicationDraft.personalInfo != null) {
										this.personalInfo = this.applicationDraft.personalInfo;
										this.applicantIsBulgarian = this.personalInfo?.nationality.id === this.bulgariaCountry.id;
										if (this.applicationDraft.contactView != null || areRequiredDocumentsAttached) {
											this.appStepsElementService.canSeeCorrespondence = true;
										}
									}
									this.isPersonalDataReady = true;
									if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_EXAM) {
										if (this.applicationDraft.contactView != null) {
											this.appStepsElementService.canSeeAdrExamPeople = true;
											this.contactView = this.applicationDraft.contactView;
										}
									} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_CONSULTANT_EXAM) {
										if (this.applicationDraft.contactView != null) {
											this.appStepsElementService.canSeeAdrExamServiceOptions = true;
											this.contactView = this.applicationDraft.contactView;
										}
									} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_MOTOR_EXAM) {
										if (this.applicationDraft.contactView != null) {
											this.appStepsElementService.canSeeExamCategorySelection = true;
											this.contactView = this.applicationDraft.contactView;
										}
									} else if (this.applicationDraft.contactView != null) {
										this.contactView = this.applicationDraft.contactView;
										if (this.applicationDraft.drivingLicence != null || areRequiredDocumentsAttached) {
											this.appStepsElementService.canSeeDL = true;
										}
									}

									if (this.applicationDraft.drivingLicence != null 
										&& this.cardApplicationTypes.includes(this.applicationDraft?.applicationType?.id)) {
										this.drivingLicence = this.applicationDraft.drivingLicence;
										if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_CARD
											|| this.applicationTypeId === APPLICATION_TYPE.APPLICATION_DQC) {
											if ((this.applicationDraft.adrModules != null
												|| this.applicationDraft.dqcCertificates != null)
												|| areRequiredDocumentsAttached) {
												this.appStepsElementService.canSeeCertificate = true;
											}
										} else if (this.applicationDraft.cardView != null || areRequiredDocumentsAttached) {
											this.appStepsElementService.canSeeService = true;
										}
									}
									if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_DQC
										&& this.applicationDraft.dqcCertificates != null) {
										this.dqcCertificates = this.applicationDraft.dqcCertificates;
										if (this.documentService.checkAllManuallyUploadedCertificatesHasAndFiles(this.dqcCertificates, this.attachedDocuments)) {
											this.appStepsElementService.canSeeService = true;
										}
									}
									if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_CARD
										&& this.applicationDraft.adrModules != null) {
										this.adrModules = this.applicationDraft.adrModules;
										this.appStepsElementService.canSeeService = true;
									}
									if (this.applicationDraft.drivingLicence != null 
										&& !this.cardApplicationTypes.includes(this.applicationDraft?.applicationType?.id)) {
										this.drivingLicence = this.applicationDraft.drivingLicence;
										this.appStepsElementService.canSeeExamMunicipalitySelection = true;
									}
									if (this.applicationDraft?.cardView?.issuingReason) {
										if (this.applicationDraft.delivery != null || areRequiredDocumentsAttached) {
											this.appStepsElementService.canSeeDelivery = true;
										}
									}
									if (this.applicationDraft.delivery != null) {
										this.delivery = this.applicationDraft.delivery;
										this.appStepsElementService.canSeeSignatureAndPhoto = true;
									}
									if (this.applicationDraft.names != null) {
										this.names = this.applicationDraft.names;
									}
									if (this.applicationDraft.hasEditedPictures && this.applicationDraft.delivery != null) {
										this.appStepsElementService.canSeeSigning = true;
									}
								});
						},
						(error) => {
							if (this.user.isApplicant()) {
								this.router.navigate([RouteUrl.DASHBOARD]);
							} else {
								this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]);
							}
						});
			} else {
				PopUpService.showPopUp(DEFAULT_POP_UPS.error_not_found);
			}
		});
	}

	setApplicationId(emittedApplicationId: number) {
		this.applicationId = emittedApplicationId;
	}

	setIsEditing(emitIsEditing: Steps) {
		this.isEditing = emitIsEditing;
	}

	setAdrServiceType(emitServiceOption: ServiceOptions) {
		this.adrServiceOption = emitServiceOption;
	}

	setSelectedAdrExamPerson(examPerson: AdrExamPersonSelection): void {
		this.selectedAdrExamPerson = examPerson;
	}

	setSelectedMotorExamPerson(examPerson: MotorExamPersonSelection): void {
		this.selectedMotorExamPerson = examPerson;
	}

	setSelectedAdrConsultantLearningPlan(selectedLearningPlan: ConsultantExamLearningPlanSelection) {
		this.selectedAdrConsultantLearningPlan = selectedLearningPlan;
	}

	setSelectedExamOrgUnit(orgUnit: OrgUnit) {
		this.selectedExamOrgUnit = orgUnit;
		this.appStepsElementService.continueToNextStepFromCurrent(Steps.EXAM_ORG_UNIT_SELECTION);
	}

	setSelectedExamMunicipality(municipality: Municipality) {
		this.selectedMunicipality = municipality;
		this.appStepsElementService.continueToNextStepFromCurrent(Steps.EXAM_MUNICIPALITY_SELECTION);
	}

	setTaxiExamRequestDto(dto: TaxiExamEnrolmentRequestDto) {
		this.taxiExamRequestDto = dto;
	}

	setSelectedMotorExamCategory(category: Category) {
		this.selectedMotorExamCategory = category;
	}

	getChosenApplicationType(applicationTypeId: number): void {
		this.nomenclatureService
			.getApplicationTypeDescriptionKeyById(applicationTypeId)
			.subscribe(
				(response) => {
					this.title = response;
				});
	}

	getBulgariaCountryTranslation() {
		this.nomenclatureService.getCountryByName(S_VARIABLES.BULGARIA_LATIN).subscribe(
			(countryDto: TranslationDto) => {
				this.bulgariaCountry = new Translation(countryDto);
			},
			(error) => {
				if (this.user.isApplicant()) {
					this.router.navigate([RouteUrl.DASHBOARD]);
				} else {
					this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]);
				}
			}
		);
	}

	ngOnDestroy(): void {
		this.routeSubscription.unsubscribe();
	}
}
