import { Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { ErrorCheckerService } from 'src/app/core/services/error-checker.service';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { SubjectService } from 'src/app/core/services/subject.service';
import { RequestMvrDto } from 'src/app/shared/dtos/request-mvr-dto';
import { APPLICATION_TYPE } from 'src/app/shared/enums/application-types';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { Address } from 'src/app/shared/models/address';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { PersonalInfo } from 'src/app/shared/models/personal-info';
import { Translation } from 'src/app/shared/models/translation';
import { Utils } from 'src/app/shared/utils/utils';

@Component({
	selector: 'app-personal-info-approver',
	templateUrl: './personal-info-approver.component.html',
	host: {
		"(window:click)": "onClick()"
	}
})
export class PersonalInfoApproverComponent implements OnInit {
	@Input() number: number;
	@Input() applicationId: number;
	@Input() hasMvrCheck: boolean;
	@Input() bulgariaCountry: Translation;
	@Input() personalInfo: PersonalInfo;
	@Input() applicationTypeId: number;
	@Input() startMilestoneStatusToGetDocumentsForSection: number;
	dateFormat = S_VARIABLES.DATE_FORMAT;
	isLoading: boolean;
	APPLICATION_TYPE = APPLICATION_TYPE;

	differenceCount: number;
	hasError = false;
	showOptions = false;
	showCurrentAddressDetails: boolean;
	showCurrentAddressDetailsFroCheck: boolean;

	canMvrReturnInfo: boolean;
	requestMvrDto: RequestMvrDto;
	personalInfoFromCheck: PersonalInfo;
	permanentAddress: Address;
	permanentAddressFromCheck: Address;
	currentAddress: Address;
	currentAddressFromCheck: Address;

	constructor(
		private subjectService: SubjectService,
		private errorCheckerService: ErrorCheckerService) { }

	ngOnInit(): void {
		this.canMvrReturnInfo = (this.personalInfo.nationality.id === this.bulgariaCountry.id) 
			&& Utils.checkCanMvrReturnPersonalInfo(this.personalInfo.documentNumber);

		this.permanentAddress = this.personalInfo.permanentAddress;	
		this.currentAddress = this.personalInfo.currentAddress;
		this.setShowCurrentAddressDetails();
	}

	setShowCurrentAddressDetails() {
		if (this.currentAddress?.apartment || this.currentAddress?.street || this.currentAddress?.building 
			|| this.currentAddress?.streetNumber || this.currentAddress?.entrance || this.currentAddress?.postalCode) {
				this.showCurrentAddressDetails = true;
		} else {
			this.showCurrentAddressDetails = false;
		}
	}

	setShowCurrentAddressDetailsFromCheck() {
		if (this.currentAddressFromCheck?.apartment || this.currentAddressFromCheck?.street || this.currentAddressFromCheck?.building 
			|| this.currentAddressFromCheck?.streetNumber || this.currentAddressFromCheck?.entrance || this.currentAddressFromCheck?.postalCode) {
				this.showCurrentAddressDetailsFroCheck = true;
		} else {
			this.showCurrentAddressDetailsFroCheck = false;
		}
	}


	onClick() {
		this.showOptions = false;
	}

	setShowOptions($event) {
		$event.stopPropagation();
		this.showOptions = !this.showOptions;
	}

	doMvrCheck() {
		this.showOptions = false;
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.setRequestMvrDto();

		this.subjectService.getPersonalInfoFromServicesForApprover(this.requestMvrDto)
			.subscribe(
				(response) => {
					this.personalInfoFromCheck = new PersonalInfo(response);
					this.permanentAddressFromCheck = this.personalInfoFromCheck.permanentAddress;
					if (response.currentAddressSameAsPermanent) {
						this.currentAddressFromCheck = this.permanentAddressFromCheck;
					} else {
						this.currentAddressFromCheck = this.personalInfoFromCheck.currentAddress;
					}
					if (!this.hasMvrCheck) {
						this.personalInfo =
							this.errorCheckerService.setHasErrorsAndCountDifferencesInPersonalInfo(this.personalInfo , this.personalInfoFromCheck);
					}
					this.setShowCurrentAddressDetailsFromCheck();
					this.differenceCount = this.personalInfo.differences;
				},
				(errorResponse) => {
					if (errorResponse.error) {
						if (errorResponse.error.error === 'PersonNotFoundMvrRegixException'
							|| errorResponse.error.error === 'MismatchException') {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_mvr_not_found_valid_document,
								text: POP_UP_MESSAGES_KEYS.input_valid_document,
								type: PopUpTypes.ERROR
							});
							this.hasError = true;
						} else if (errorResponse.error.error === 'DocumentExpiredException') {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_expired_document,
								text: POP_UP_MESSAGES_KEYS.input_not_expired_document,
								type: PopUpTypes.ERROR
							});
							this.hasError = true;
						} else if (errorResponse.error.error === 'MvrAndGraoDoNotWork'
							|| errorResponse.error.error === 'ProxyException') {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_service_not_work,
								text: POP_UP_MESSAGES_KEYS.try_again_later,
								type: PopUpTypes.ERROR
							});
						} else if (errorResponse.error.error === 'InvalidDocumentFromMvrException') {
							PopUpService.showPopUp({
								type: PopUpTypes.ERROR,
								header: POP_UP_MESSAGES_KEYS.mvr_check_invalid_document,
								extraInfo : (errorResponse.error.status + " / " +  errorResponse.error.statusReason),
								date: new Date(errorResponse.error.date)						
							})
							this.hasError = true;
						} else if (errorResponse.error.error === 'MvrChangedResponseIssuerNameException') {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_service_not_work,
								text: POP_UP_MESSAGES_KEYS.error_contact_system_administrator,
								type: PopUpTypes.ERROR
							});
						}
					}
			}).add(() => {
				this.isLoading = false;
			});
	}

	setRequestMvrDto() {
		this.requestMvrDto = new RequestMvrDto();
		this.requestMvrDto.applicationId = this.personalInfo.applicationId;
		this.requestMvrDto.documentNumber = this.personalInfo.documentNumber;
		this.requestMvrDto.identityDocumentType = this.personalInfo.identityDocumentType;
		this.requestMvrDto.identityNumber = this.personalInfo.identityNumber;
		this.requestMvrDto.isAuthorizedPerson = false;
		this.requestMvrDto.nationality = this.personalInfo.nationality;
	}

}
