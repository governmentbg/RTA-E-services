import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { RequestMvrDto } from 'src/app/shared/dtos/request-mvr-dto';
import { RequestMvrWrapperDto } from 'src/app/shared/dtos/request-mvr-wrapper-dto';
import { PersonalInfo } from 'src/app/shared/models/personal-info';

@Component({
	selector: 'app-personal-info-display-short',
	templateUrl: './personal-info-display-short.component.html'
})
export class PersonalInfoDisplayShortComponent implements OnInit {
	@Input() public isDraft: boolean;
	@Input() public hasMvrCheck: boolean;
	@Input() public requestMvrDto: RequestMvrDto;
	@Output() public emitRequestMvrDto = new EventEmitter<RequestMvrDto>();

	canEdit: boolean;
	countryKey: string;

	constructor() {}

	ngOnInit(): void {
		this.countryKey = this.requestMvrDto.nationality.key;
	}

	editInitialInfo() {
		this.emitRequestMvrDto.next(this.requestMvrDto);
	}
}
