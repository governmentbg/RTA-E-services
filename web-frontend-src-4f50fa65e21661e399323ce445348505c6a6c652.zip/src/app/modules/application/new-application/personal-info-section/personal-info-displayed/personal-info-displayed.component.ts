import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NamesDto } from 'src/app/shared/dtos/names-dto';
import { PersonalInfo } from 'src/app/shared/models/personal-info';
import { Address } from 'src/app/shared/models/address';
import { PersonalInfoDto } from 'src/app/shared/dtos/personal-info-form-dto';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { APPLICATION_TYPE } from 'src/app/shared/enums/application-types';
import { RequestMvrDto } from 'src/app/shared/dtos/request-mvr-dto';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';

@Component({
	selector: 'app-personal-info-displayed',
	templateUrl: './personal-info-displayed.component.html',
})
export class PersonalInfoDisplayedComponent implements OnInit {
	@Input() public number: number;
	@Input() public isDraft: boolean;
	@Input() public personalInfo: PersonalInfo;
	@Input() public personalInfoFormDto: PersonalInfoDto;
	@Input() public hasAttachedDocuments: boolean;
	@Input() public applicationTypeId: number;
	@Input() public hasMvrCheck: boolean;
	@Input() public hasGraoCheck: boolean;
	@Output() public emitEditSection = new EventEmitter<PersonalInfoDto>();
	@Output() public emitEditDocumentsSection: EventEmitter<Event> = new EventEmitter<Event>();
	@Output() public emitRequestMvrDto = new EventEmitter<RequestMvrDto>();
	dateFormat = S_VARIABLES.DATE_FORMAT;
	APPLICATION_TYPE = APPLICATION_TYPE;

	public permanentAddress: Address;
	public currentAddress: Address;
	public namesDto: NamesDto;
	public hasChangedNames: boolean;
	public fullNameCyr: string;
	public fullNameLat: string;
	isApplicant: boolean;
	currentAddressSameAsPermanent: boolean;
	canEdit = false;

	constructor(private readonly authenticationService: AuthenticationService) { }

	ngOnInit() {
		this.isApplicant = this.authenticationService.getAuthenticatedUser().isApplicant();
		this.hasChangedNames = this.personalInfo.hasChangedNames;
		this.currentAddressSameAsPermanent = this.personalInfo.currentAddressSameAsPermanent;
		this.permanentAddress = this.personalInfo.permanentAddress;
		this.currentAddress = this.personalInfo.currentAddress;

		this.fullNameCyr = this.personalInfo.personalNames.getFullNameCyr();
		this.fullNameLat = this.personalInfo.personalNames.getFullNameLat();
		
		this.canEdit = this.setCanEdit();
	}

	editSection() {
		this.personalInfoFormDto.isEditing = true;
		this.emitEditSection.emit(this.personalInfoFormDto);
	}

	editDocumentsForSection(event: Event) {
		this.emitEditDocumentsSection.emit(event);
	}

	setCanEdit(): boolean {
		return !this.hasMvrCheck || !this.hasGraoCheck
			|| (this.hasMvrCheck && this.personalInfo?.placeOfBirth.includes("."));
	}
}
