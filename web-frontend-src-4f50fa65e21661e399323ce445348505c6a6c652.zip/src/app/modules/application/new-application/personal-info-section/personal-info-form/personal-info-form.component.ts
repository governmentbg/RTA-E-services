import { Component, OnInit, Input, EventEmitter, Output, ViewChild } from '@angular/core';
import { SubjectService } from 'src/app/core/services/subject.service';
import { RequestMvrDto } from 'src/app/shared/dtos/request-mvr-dto';
import { PersonalInfoForm } from './personal-info-form';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { User } from 'src/app/shared/models/user';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { PersonalInfoDto } from 'src/app/shared/dtos/personal-info-form-dto';
import { Address } from 'src/app/shared/models/address';
import { Router } from '@angular/router';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';
import { AddressForm } from 'src/app/shared/utils/address-form';
import { Translation } from 'src/app/shared/models/translation';
import { TranslationDto } from 'src/app/shared/interfaces/translation-dto';
import { APPLICATION_TYPE } from 'src/app/shared/enums/application-types';
import { AddressDto } from 'src/app/shared/dtos/address-dto';
import { PersonalInfo } from 'src/app/shared/models/personal-info';
import { IdentityDocumentTypes } from 'src/app/shared/enums/idenity-document-types';
import { Utils } from 'src/app/shared/utils/utils';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';

@Component({
	selector: 'app-personal-info-form',
	templateUrl: './personal-info-form.component.html'
})
export class PersonalInfoFormComponent implements OnInit {
	@Input() public number: number;
	@Input() public bulgariaCountry: Translation;
	@Input() applicationId: number;
	@Input() applicationTypeId: number;
	@Input() public hasMvrCheck: boolean;
	@Input() public hasGraoCheck: boolean;
	@Input() personalInfo: PersonalInfo;
	@Input() public requestMvrDto: RequestMvrDto;
	@Input() public personalInfoFormDtoFilledOut: PersonalInfoDto;
	@Output() public emitPersonalInfoFormDto = new EventEmitter<PersonalInfoDto>();
	@Output() public emitRequestMvrDto = new EventEmitter<RequestMvrDto>();
	@Output() public emitRequestMvrDtoFromDto = new EventEmitter<RequestMvrDto>();
	@ViewChild('form') htmlElement;

	public countries: Translation[] = [];
	public personalInfoFormDto: PersonalInfoDto;
	public identityDocumentIssuers: Translation[] = [];
	public genders: Translation[] = [];
	public isEditingDocNumber = false;
	public documentNumber: string;
	public user: User;
	public APPLICATION_TYPE = APPLICATION_TYPE;
	public isLoading = false;
	isApplicant: boolean;
	chosenCountryKeyInPreviousForm: string;
	isWithEgn = false;
	dateFormat = S_VARIABLES.DATE_FORMAT;

	todayDate: Date = new Date();
	yesterday: Date = new Date();
	public fullNameCyr: string;
	public fullNameLat: string;
	public permanentAddress: Address;
	public currentAddress: Address;
	public personalInfoForm: PersonalInfoForm;

	selectedGender: Translation = null;
	canEditBirthPlaceLatin = true;
	currentAddressInBg: boolean;

	constructor(
		private nomenclatureService: NomenclatureService,
		private subjectService: SubjectService,
		private authService: AuthenticationService,
		private authenticationService: AuthenticationService,
		private readonly router: Router
	) { }

	ngOnInit() {
		this.user = this.authService.getAuthenticatedUser();
		this.isApplicant = this.authenticationService.getAuthenticatedUser().isApplicant();
		this.personalInfoForm = new PersonalInfoForm(this.applicationTypeId);
		if (this.personalInfo) {
			this.personalInfo.identityNumber = this.requestMvrDto.identityNumber;
			this.personalInfo.documentNumber = this.requestMvrDto.documentNumber;
			if (this.requestMvrDto?.nationality.key) {
				this.personalInfo.nationality = this.requestMvrDto.nationality;
			}
			this.personalInfo.identityDocumentType = this.requestMvrDto.identityDocumentType;
			this.personalInfoForm.setValuesFromPrevForm(this.personalInfo);
			this.documentNumber = this.requestMvrDto.documentNumber;
			this.setHasAddressesInBg();		
		} else if (this.requestMvrDto) {
			this.currentAddressInBg = true;
			this.documentNumber = this.requestMvrDto.documentNumber;
			this.personalInfoForm.setValuesFromRequestMvrDto(this.requestMvrDto);
			if (this.user.isApplicant()) {
				this.personalInfoForm.namesForm.value.setNamesFromFullNameStrings(this.user.fullNameCyr, this.user.fullNameLat);
			}
		}
		const documentsWithEgn = [IdentityDocumentTypes.IDENTITY_CARD, IdentityDocumentTypes.PASSPORT, IdentityDocumentTypes.REFUGEE_CARD];
		if (documentsWithEgn.includes(this.requestMvrDto.identityDocumentType.id)) {
			this.isWithEgn = true;
		}
		this.personalInfoForm.dateOfBirth.setValue(this.getDateOfBirth());
		this.chosenCountryKeyInPreviousForm = this.requestMvrDto.nationality.key;

		if (this.hasMvrCheck) {
			this.setFullNames();
			this.permanentAddress = this.personalInfo.permanentAddress;
			if (this.personalInfo.currentAddress) {
				this.currentAddress = this.personalInfo.currentAddress;
			} else {
				this.personalInfoForm.currentAddress.setValue(new AddressForm());
			}
			this.setCanEditBirthPlaceLatinAfterCheckInMvr();
		}

		this.yesterday.setDate(this.todayDate.getDate() - 1);
	
		this.nomenclatureService.getIdentityDocumentIssuers().subscribe(
			(issuers: TranslationDto[]) => {
				issuers.forEach(issuerDto => {
					const issuer = new Translation(issuerDto);
					this.identityDocumentIssuers.push(issuer);
					if ((this.personalInfoFormDtoFilledOut && issuerDto.id === this.personalInfoFormDtoFilledOut.documentIssuer.id)
						|| (this.personalInfo && this.personalInfo.documentIssuer && this.personalInfo.documentIssuer.id === issuerDto.id)) {
						this.personalInfoForm.issuedBy.setValue(issuer);
					}
				});
			}
		);
		if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_TACHO_CARD) {
			this.nomenclatureService.getAllGenders().subscribe(
				(genders: TranslationDto[]) => {
					genders.forEach(genderDto => {
						this.genders.push(new Translation(genderDto));
						if (this.personalInfoFormDtoFilledOut && genderDto.id === this.personalInfoFormDtoFilledOut.gender.id) {
							this.personalInfoForm.gender.setValue(new Translation(genderDto));
						} else if (this.personalInfo && this.personalInfo.gender.id === genderDto.id) {
							this.personalInfoForm.gender.setValue(new Translation(genderDto));
						}
					});
					if (this.personalInfoFormDtoFilledOut) {
						this.selectedGender = this.genders.find(gender => gender.id === this.personalInfoFormDtoFilledOut.gender.id);
					}
				}
			);
		}
	}

	private setCanEditBirthPlaceLatinAfterCheckInMvr() {
		if (this.personalInfo?.placeOfBirth.includes('.')) {
			this.canEditBirthPlaceLatin = true;
		 } else {
			this.canEditBirthPlaceLatin = false;
		}
	}

	private setHasAddressesInBg() {
		this.currentAddressInBg = !this.personalInfo?.currentAddress?.country ? true : false;
	}

	private setFullNames() {
		if (this.personalInfo.personalNames.fatherNameCyr && this.personalInfo.personalNames.familyNameCyr) {
			this.fullNameCyr = this.personalInfo.personalNames.firstNameCyr + ' '
				+ this.personalInfo.personalNames.fatherNameCyr + ' ' + this.personalInfo.personalNames.familyNameCyr;
		} else if (!this.personalInfo.personalNames.fatherNameCyr) {
			this.fullNameCyr = this.personalInfo.personalNames.firstNameCyr + ' ' + this.personalInfo.personalNames.familyNameCyr;
		} else {
			this.fullNameCyr = this.personalInfo.personalNames.firstNameCyr;
		}

		if (this.personalInfo.personalNames.fatherNameLat) {
			this.fullNameLat = this.personalInfo.personalNames.firstNameLat + ' '
				+ this.personalInfo.personalNames.fatherNameLat + ' ' + this.personalInfo.personalNames.familyNameLat;
		} else {
			this.fullNameLat = this.personalInfo.personalNames.firstNameLat + ' ' + this.personalInfo.personalNames.familyNameLat;
		}
	}

	editDocumentNumber() {
		this.isEditingDocNumber = true;
	}

	saveDocumentNumber() {
		if (this.personalInfoForm.documentNumber.valid) {
			this.requestMvrDto.documentNumber = this.personalInfoForm.documentNumber.value;
			this.documentNumber = this.requestMvrDto.documentNumber;
			this.isEditingDocNumber = false;
		}
	}

	editInitialInfo() {
		this.emitRequestMvrDto.next(this.requestMvrDto);
	}

	onSubmit() {
		if (this.personalInfoForm.isValid()) {
			this.personalInfoFormDto = this.personalInfoForm.toRequestDto();
			if (this.personalInfoFormDtoFilledOut) {
				this.personalInfoFormDto.identityDocumentType = this.personalInfoFormDtoFilledOut.identityDocumentType;
				this.personalInfoFormDto.applicationId = this.personalInfoFormDtoFilledOut.applicationId;
				if (this.personalInfoFormDto.applicationId == undefined) {
					this.personalInfoFormDto.applicationId = this.personalInfo.applicationId;
				}
			} else if (this.requestMvrDto) {
				this.personalInfoFormDto.identityDocumentType = this.requestMvrDto.identityDocumentType;
				this.personalInfoFormDto.applicationId = this.requestMvrDto.applicationId;
			} else {
				this.personalInfoFormDto.identityDocumentType = this.personalInfo.identityDocumentType;
				this.personalInfoFormDto.applicationId = this.personalInfo.applicationId;
			}
			if (this.personalInfoFormDtoFilledOut?.isEditing) {
				this.personalInfoFormDto.isEditing = true;
			}

			this.isLoading = true;
			this.subjectService.savePersonalInfoForm(this.personalInfoFormDto).subscribe(
				(dto) => {
					this.redirect();
					this.emitPersonalInfoFormDto.next(dto);
				},
				(errorResponse) => {
					if (errorResponse.error) {
						if (errorResponse.error.error === 'AddressException') {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_address_is_used,
								text: POP_UP_MESSAGES_KEYS.change_used_address,
								type: PopUpTypes.ERROR
						})};
					}}
			).add(() => {
				this.isLoading = false;
			});
		} else {
			this.personalInfoForm.scrollToFirstInvalidControl(this.htmlElement);
		}
	}

	isCountryName(): boolean {
		return !this.personalInfoFormDtoFilledOut.placeOfBirth.includes("."); // do not change to placeOfBirthLatin
	}

	convertToAddress(dto: AddressDto): Address {
		return new Address(dto);
	}

	redirect(){
		// това се прави с цел ако сме на този раут /при редактиране/ , да го презареди и да рефрешне дто-то 
		this.router.navigateByUrl('/application', {skipLocationChange: true}).then(()=>
		this.router.navigate([RouteUrl.APPLICATION, RouteUrl.DRAFT, this.applicationId]));
	 }

	 getDateOfBirth(): Date {
		if (this.personalInfo) {
			if (this.isWithEgn) {
						return Utils.extractDateOBirthFromEgn(this.personalInfo.identityNumber);
					} else {
						return this.personalInfo.dateOfBirth;
					}
		 } else {
			if (this.isWithEgn) {
				return Utils.extractDateOBirthFromEgn(this.requestMvrDto.identityNumber);
			}
		 }
	 }

	 currentAddressIsInBg() {
		this.currentAddressInBg = !this.currentAddressInBg;
		this.personalInfoForm.setNewCurrentAddressForm();
	 }
}
