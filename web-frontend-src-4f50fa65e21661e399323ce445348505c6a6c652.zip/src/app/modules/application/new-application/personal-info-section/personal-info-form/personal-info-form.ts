import { AbstractForm } from 'src/app/shared/models/abstract-form';
import { AddressForm } from 'src/app/shared/utils/address-form';
import { ContactTypes } from 'src/app/shared/enums/contact-types';
import { FormGroup, Validators } from '@angular/forms';
import { NamesForm } from 'src/app/shared/utils/names-form';
import { RequestMvrDto } from 'src/app/shared/dtos/request-mvr-dto';
import { CustomValidators } from 'src/app/shared/utils/custom-validators';
import { Address } from 'src/app/shared/models/address';
import { Utils } from 'src/app/shared/utils/utils';
import { AddressDto } from 'src/app/shared/dtos/address-dto';
import { PersonalInfoDto } from 'src/app/shared/dtos/personal-info-form-dto';
import { PersonalInfo } from 'src/app/shared/models/personal-info';
export class PersonalInfoForm extends AbstractForm<PersonalInfoDto> {
	public applicationTypeId: number;

	constructor(applicationTypeId: number) {
		super();
		this.formGroup = this.createFormGroup();
		this.applicationTypeId = applicationTypeId;
	}

	get namesForm() {
		return this.formGroup.get('namesForm');
	}

	get placeOfBirth() {
		return this.formGroup.get('placeOfBirth');
	}

	get placeOfBirthLatin() {
		return this.formGroup.get('placeOfBirthLatin');
	}

	get dateOfBirth() {
		return this.formGroup.get('dateOfBirth');
	}

	get documentNumber() {
		return this.formGroup.get('documentNumber');
	}

	get identityNumber() {
		return this.formGroup.get('identityNumber');
	}

	get validityDate() {
		return this.formGroup.get('validityDate');
	}

	get issueDate() {
		return this.formGroup.get('issueDate');
	}

	get nationality() {
		return this.formGroup.get('nationality');
	}

	get issuedBy() {
		return this.formGroup.get('issuedBy');
	}

	get permanentAddress() {
		return this.formGroup.get('permanentAddress');
	}

	get currentAddress() {
		return this.formGroup.get('currentAddress');
	}

	get isSameAddress() {
		return this.formGroup.get('isSameAddress');
	}

	get hasChangedNames() {
		return this.formGroup.get('hasChangedNames');
	}

	get isAuthorizedPerson() {
		return this.formGroup.get('isAuthorizedPerson');
	}

	get gender() {
		return this.formGroup.get('gender');
	}

	setValuesFromRequestMvrDto(requestMvrDto: RequestMvrDto) {
		this.identityNumber.setValue(requestMvrDto.identityNumber);
		this.documentNumber.setValue(requestMvrDto.documentNumber);
		this.isAuthorizedPerson.setValue(requestMvrDto.isAuthorizedPerson);
		this.isSameAddress.setValue(false);
		this.nationality.setValue(requestMvrDto.nationality);
		this.hasChangedNames.setValue(false);
	}

	setValuesFromPrevForm(personalInfo: PersonalInfo) {
		this.namesForm.value.setNames(personalInfo.personalNames);
		this.validityDate.setValue(new Date(personalInfo.dateOfExpiry));
		this.issueDate.setValue(new Date(personalInfo.dateOfIssue));

		this.identityNumber.setValue(personalInfo.identityNumber);
		this.documentNumber.setValue(personalInfo.documentNumber);
		this.isAuthorizedPerson.setValue(personalInfo.isAuthorizedPerson);
		this.hasChangedNames.setValue(personalInfo.hasChangedNames);

		this.issuedBy.setValue(personalInfo.documentIssuer);
		this.gender.setValue(personalInfo.gender);
		this.nationality.setValue(personalInfo.nationality);
		this.placeOfBirth.setValue(personalInfo.placeOfBirth);
		this.placeOfBirthLatin.setValue(personalInfo.placeOfBirthLatin);

		this.isSameAddress.setValue(personalInfo.currentAddressSameAsPermanent);
		if (personalInfo?.permanentAddress) {
			this.permanentAddress.value.setAddressFormInfo(personalInfo.permanentAddress);
		}
		if (personalInfo?.currentAddress) {
			this.currentAddress.value.setAddressFormInfo(personalInfo.currentAddress);
		}
	}

	setNewCurrentAddressForm() {
		this.currentAddress.value.setAddressFormInfo(new Address(null));
	}

	setIsSameAddress() {
		this.isSameAddress.setValue(!this.isSameAddress.value);
		if (this.isSameAddress.value === false) {
			this.currentAddress.value.setAddressFormInfo(new Address(null));
		}
	}

	setHasChangedNames() {
		this.hasChangedNames.setValue(!this.hasChangedNames.value);
	}

	private createFormGroup(): FormGroup {
		const formGroup = this.formBuilder.group({
			namesForm: [new NamesForm(), [
				Validators.required
			]],
			placeOfBirth: [null, [
				Validators.required, Validators.minLength(3), Validators.maxLength(255), Validators.pattern('[а-яА-Я].*[\\S].*')
			]],
			placeOfBirthLatin: [null, [
				Validators.required, Validators.minLength(3), Validators.maxLength(255), Validators.pattern('[a-zA-Z].*[\\S].*')
			]],
			dateOfBirth: [null, [
				Validators.required, CustomValidators.isPastDate()
			]],
			documentNumber: [null, [
				Validators.required, Validators.minLength(9),
			]],
			identityNumber: [null, [
				Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]*$')
			]],
			validityDate: [null, [
				Validators.required, CustomValidators.isFutureOrPresentDateOrExpiredLast6Months()
			]],
			issueDate: [null, [
				Validators.required, CustomValidators.isPastOrPresentDate()
			]],
			nationality: [null, [
				Validators.required, Validators.min(1)
			]],
			issuedBy: [null, [
				Validators.required, Validators.min(1)
			]],
			permanentAddress: [new AddressForm(), [
				Validators.required
			]],
			currentAddress: [new AddressForm(), [
				Validators.required
			]],
			isSameAddress: [null, [
				Validators.required
			]],
			hasChangedNames: [null, [
				Validators.required
			]],
			isAuthorizedPerson: [null, [
				Validators.required
			]],
			gender: [null]
		});
		CustomValidators.genderConditionalValidators(formGroup, this.applicationTypeId);
		return formGroup;
	}

	public isValid(): boolean {
		const isFormValid = super.isValid();
		let isPermAddressValid = true;
		let isCurrAddressValid = true;
		if (!this.permanentAddress.value.setIsAddressValid()) {
			isPermAddressValid = false;
			this.permanentAddress.value.formGroup.markAllAsTouched();
		}
		if (!this.isSameAddress.value) {
			if (!this.currentAddress.value.setIsAddressValid()) {
				isCurrAddressValid = false;
				this.currentAddress.value.formGroup.markAllAsTouched();
			}
		}

		return isFormValid && isPermAddressValid && isCurrAddressValid;
	}
	
	public toRequestDto(): PersonalInfoDto {
		const namesDto = this.namesForm.value.toRequestDto();
		const permanentAddressDto = this.permanentAddress.value.toRequestDto();
		permanentAddressDto.addressTypeId = ContactTypes.PERMANENT_ADDRESS;

		let currentAddressDto = new AddressDto();
		if (this.isSameAddress.value) {
			currentAddressDto = permanentAddressDto;
			currentAddressDto.addressTypeId = ContactTypes.CURRENT_ADDRESS;
		} else {
			currentAddressDto = this.currentAddress.value.toRequestDto();
			currentAddressDto.addressTypeId = ContactTypes.CURRENT_ADDRESS;
		}

		return {
			namesDto,
			identityNumber: this.identityNumber.value,
			nationality: this.nationality.value,
			documentNumber: this.documentNumber.value,
			dateOfExpiry: Utils.convertDateToStringFormatted(new Date(this.validityDate.value)),
			dateOfIssue: Utils.convertDateToStringFormatted(new Date(this.issueDate.value)),
			identityDocumentType: null,
			applicationId: 0,
			changedNames: this.hasChangedNames.value,
			currentAddressSameAsPermanent: this.isSameAddress.value,
			currentAddressDto,
			permanentAddressDto,
			isAuthorizedPerson: this.isAuthorizedPerson.value,
			documentIssuer: this.issuedBy.value,
			placeOfBirth: this.placeOfBirth.value,
			placeOfBirthLatin: this.placeOfBirthLatin.value,
			dateOfBirth: Utils.convertDateToStringFormatted(new Date(this.dateOfBirth.value)),
			isEditing: false,
			gender: this.gender.value,
			hasGraoCheck: null,
		};
	}

}
