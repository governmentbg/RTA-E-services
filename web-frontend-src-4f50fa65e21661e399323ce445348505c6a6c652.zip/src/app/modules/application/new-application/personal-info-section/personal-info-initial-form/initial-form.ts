import { AbstractForm } from 'src/app/shared/models/abstract-form';
import { FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { RequestMvrDto } from 'src/app/shared/dtos/request-mvr-dto';
import { IdentityDocumentTypes } from 'src/app/shared/enums/idenity-document-types';
export class InitialForm extends AbstractForm<RequestMvrDto> {

	constructor() {
		super();
		this.formGroup = this.createFormGroup();
	}

	get documentType() {
		return this.formGroup.get('documentType');
	}

	get documentNumber() {
		return this.formGroup.get('documentNumber');
	}

	get identityNumber() {
		return this.formGroup.get('identityNumber');
	}

	get nationality() {
		return this.formGroup.get('nationality');
	}

	get isAuthorizedPerson() {
		return this.formGroup.get('isAuthorizedPerson');
	}

	setInitialForm(requestMvrDto: RequestMvrDto) {
		this.documentNumber.setValue(requestMvrDto.documentNumber);
		this.identityNumber.setValue(requestMvrDto.identityNumber);
		this.isAuthorizedPerson.setValue(requestMvrDto.isAuthorizedPerson);
		this.nationality.setValue(requestMvrDto.nationality);
	}

	setIsAuthorizedPerson() {
		this.isAuthorizedPerson.setValue(!this.isAuthorizedPerson.value);
	}

	public isValid(): boolean {
		const isFormValid = super.isValid();
		const docTypeNap = this.formGroup.get("documentType").value.id === IdentityDocumentTypes.CERTIFICATE_FOR_REGISTRATION_FROM_NAP;
		const docNumber : string = this.formGroup.get("documentNumber").value;
		var hasError = false;

		if (docTypeNap) {
			if (docNumber.length > 30) {
				hasError = true;
			}
		} else {
			if (docNumber.length > 9 || docNumber.match('^[0-9]*$') == null) {
				hasError = true;
			}
		}
		if (hasError) {
			this.formGroup.get("documentNumber").setValue('');
		}
		return isFormValid && !hasError;
	}

	private createFormGroup(): FormGroup {
		return this.formBuilder.group({
			documentType: ['', [
				Validators.required, Validators.min(1)
			]],
			documentNumber: [null, [
				Validators.required, Validators.minLength(9)
			]],
			identityNumber: [null, [
				Validators.required, Validators.maxLength(10), Validators.minLength(10), Validators.pattern('^[0-9]*$')
			]],
			nationality: ['', [
				Validators.required, Validators.min(1)
			]],
			applicationId: [null],
			isAuthorizedPerson: [false, [
				Validators.required
			]]
		});
	}

	public toRequestDto(): RequestMvrDto {
		return {
			applicationId: 0,
			identityDocumentType: this.documentType.value,
			identityNumber: this.identityNumber.value,
			documentNumber: this.documentNumber.value,
			nationality: this.nationality.value,
			isWithLnch: false,
			isForeignerWithEgn: false,
			isAuthorizedPerson: this.isAuthorizedPerson.value
		};
	}
}
