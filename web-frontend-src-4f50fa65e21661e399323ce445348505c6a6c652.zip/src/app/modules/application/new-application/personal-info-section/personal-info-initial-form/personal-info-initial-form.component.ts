import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { InitialForm } from './initial-form';
import { RequestMvrDto } from 'src/app/shared/dtos/request-mvr-dto';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { Translation } from 'src/app/shared/models/translation';
import { TranslationDto } from 'src/app/shared/interfaces/translation-dto';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { PersonalInfo } from 'src/app/shared/models/personal-info';
import { IdentityDocumentTypes } from 'src/app/shared/enums/idenity-document-types';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { Utils } from 'src/app/shared/utils/utils';
import { CountryDto } from 'src/app/shared/interfaces/country-dto';
import { Country } from 'src/app/shared/models/country';

@Component({
	selector: 'app-personal-info-initial-form',
	templateUrl: './personal-info-initial-form.component.html',
})
export class PersonalInfoInitialFormComponent implements OnInit {
	@Input() public requestMvrDto: RequestMvrDto;
	@Input() hasMvrCheck: boolean;
	@Input() personalInfo: PersonalInfo;
	@Input() isLoading: boolean;
	@Input() public bulgariaCountry: Translation;
	@Output() public emitRequestMvrDto = new EventEmitter<RequestMvrDto>();

	public initialInfoForm: InitialForm;
	public countries: Country[] = [];
	public identityDocumentTypes: Translation[] = [];
	chosenNationalityKey: string;
	eUCountries: Translation[] = [];

	constructor(
		private nomenclatureService: NomenclatureService
	) { }

	ngOnInit(): void {
		this.initialInfoForm = new InitialForm();

		if (this.requestMvrDto) {
			this.initialInfoForm.setInitialForm(this.requestMvrDto);
			this.chosenNationalityKey = this.requestMvrDto.nationality.key;
		} 
		// TODO : страните да се вземат само веднъж при зареждане на application раута
		this.nomenclatureService.getAllCountries().subscribe(
			(countryDtos: CountryDto[]) => {
				countryDtos.forEach(countryDto => {
					this.countries.push(new Country(countryDto));
					if (this.initialInfoForm.nationality.value == "") {
						this.initialInfoForm.nationality.setValue(this.bulgariaCountry);
					}
				});
			}
		);

		this.nomenclatureService.getIdentityDocumentTypes().subscribe(
			(types: TranslationDto[]) => {
				types.forEach(typeDto => {
					this.identityDocumentTypes.push(new Translation(typeDto));
					if (this.requestMvrDto && typeDto.id === this.requestMvrDto.identityDocumentType.id) {
						this.initialInfoForm.documentType.setValue(typeDto);
					} else if (this.initialInfoForm.documentType.value == "") {
						if (typeDto.id === IdentityDocumentTypes.IDENTITY_CARD) {
							this.initialInfoForm.documentType.setValue(typeDto);
						}
					}
				});
			}
		);
	}

	public onSubmitInitialForm() {
		if (this.initialInfoForm.isValid()) {
			const isBulgarian = Utils.checkIsBulgarian(this.initialInfoForm.nationality.value.id);
			const canBeBgBasedOnDocType = Utils.canBeBgBasedOnDocType(this.initialInfoForm.documentType.value.id);
			if (isBulgarian && !canBeBgBasedOnDocType) {
				this.initialInfoForm.nationality.setValue('');
				this.initialInfoForm.isValid();
				PopUpService.showPopUp({
					header: POP_UP_MESSAGES_KEYS.error_choose_other_country_than_bg,
					type: PopUpTypes.ERROR
				});
				return;
			}

			const identityNumberIsEgn = (this.initialInfoForm.documentType.value.id === IdentityDocumentTypes.IDENTITY_CARD) 
				? true : false;
			if (identityNumberIsEgn && !Utils.isValidEgn(this.initialInfoForm.identityNumber.value)) {
				PopUpService.showPopUp({
					header: POP_UP_MESSAGES_KEYS.error_entered_not_valid_egn,
					text: POP_UP_MESSAGES_KEYS.enter_valid_egn,
					type: PopUpTypes.ERROR
				});
				return;
			}

			const euCitizensWithCertificateDocTypes = [IdentityDocumentTypes.CERTIFICATE_FOR_PROLONGED_RESIDENCE_EU_CITIZEN, 
				IdentityDocumentTypes.CERTIFICATE_FOR_PERMANENT_RESIDENCE_EU_CITIZEN];
			const isEuCitizenWithCertificate = euCitizensWithCertificateDocTypes.includes(this.initialInfoForm.documentType.value.id);
			if (isEuCitizenWithCertificate) {
				const euCountries = this.countries.filter(countryDto => countryDto.isEu === true).map( (c) => {return c.country.id});

				if (!euCountries.includes(this.initialInfoForm.nationality.value.id)) {
					this.initialInfoForm.nationality.setValue('');
					this.initialInfoForm.isValid();

					PopUpService.showPopUp({
						header: POP_UP_MESSAGES_KEYS.error_not_eu_citizen,
						text: POP_UP_MESSAGES_KEYS.enter_eu_country,
						type: PopUpTypes.ERROR
					});
					return;
				}
			}
			 
			var requestMvrDto = new RequestMvrDto();
			requestMvrDto = this.initialInfoForm.toRequestDto();
			this.emitRequestMvrDto.next(requestMvrDto);
		}
	}
}
