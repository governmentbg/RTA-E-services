import { ApplicationDto } from 'src/app/shared/interfaces/application-dto';
import { ApplicationService } from 'src/app/core/services/application.service';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { ApplicationTypeIdDto } from 'src/app/shared/dtos/application-type-id-dto';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { Component, OnInit, Input, Output, EventEmitter, ViewChild, AfterViewInit } from '@angular/core';
import { IdentityDocumentTypes } from 'src/app/shared/enums/idenity-document-types';
import { PersonalInfo } from 'src/app/shared/models/personal-info';
import { RequestMvrDto } from 'src/app/shared/dtos/request-mvr-dto';
import { Steps } from 'src/app/shared/enums/steps';
import { SubjectService } from 'src/app/core/services/subject.service';
import { User } from 'src/app/shared/models/user';
import { SubHeaderApplicationInfo } from 'src/app/shared/models/sub-header-application-info';
import { RequestMvrWrapperDto } from 'src/app/shared/dtos/request-mvr-wrapper-dto';
import { PersonalInfoDto } from 'src/app/shared/dtos/personal-info-form-dto';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { MILESTONE_STATUSES } from 'src/app/shared/enums/milestone-statuses';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { Translation } from 'src/app/shared/models/translation';
import { Utils } from 'src/app/shared/utils/utils';
import { PopUp } from 'src/app/shared/models/pop-text';

@Component({
	selector: 'app-personal-info',
	templateUrl: './personal-info.component.html',
})
export class PersonalInfoComponent implements OnInit, AfterViewInit {
	@Input() public number: number;
	@Input() public bulgariaCountry: Translation;
	@Input() public isDraft: boolean;
	@Input() public applicationId: number;
	@Input() public applicationTypeId: number;
	@Input() public user: User;
	@Input() public personalInfo: PersonalInfo;
	@Input() public identityNumber: string;
	@Input() public isEditing;
	@Input() public hasMvrCheck: boolean;
	@Input() public hasGraoCheck: boolean;
	@Input() public personalNumber: String;
	@Input() public alreadyAttachedDocTypes: Translation[] = [];

	@Output() public continueToNextSection = new EventEmitter();
	@Output() public emitApplicationId = new EventEmitter<number>();
	@Output() public emitIsEditing = new EventEmitter<Steps>();
	@ViewChild('personalInfoHtmlElement') htmlElement: { nativeElement: HTMLElement; };

	public applicationTypeIdDto: ApplicationTypeIdDto;

	public personalInfoFormDtoFilledOut: PersonalInfoDto;
	public isLoading = false;
	public documentNumber: string;
	public isDocNumInvalid = false;
	public application: ApplicationDto;
	public requestMvrWrapperDto = new RequestMvrWrapperDto();
	public requestMvrDto: RequestMvrDto;
	public isApplicantWithEFace: boolean;

	public showInitialForm = true;
	public showPersonalInfoForm = false;
	public showDisplayInfo = false;
	public mvrWorksGraoNot: boolean;

	public isReadOnly: boolean;
	public hasAttachedDocuments = false;
	public startMilestoneStatusToGetDocumentsForSection = MILESTONE_STATUSES.ENTERING_PERSONAL_DATA;
	DOCUMENT_NUM_LENGTH = 9;

	constructor(
		private appStepsElementService: ApplicationStepsElementsService,
		private applicationService: ApplicationService,
		private authService: AuthenticationService,
		private subjectService: SubjectService,
	) { }

	ngOnInit() {
		this.applicationTypeIdDto = new ApplicationTypeIdDto();
		this.applicationTypeIdDto.id = this.applicationTypeId;
		this.user = this.authService.getAuthenticatedUser();
		this.isApplicantWithEFace = this.authService.getAuthenticatedUser().isEFaceApplicant()
			&& !this.authService.getAuthenticatedUser().isDemaxAdmin();

		if (this.personalInfo != null) {
			this.showInitialForm = false;
			this.showDisplayInfo = true;

			if (this.appStepsElementService.canSeeCorrespondence) {
				this.isReadOnly = true;
			}

			this.personalInfoFormDtoFilledOut = this.personalInfo.convertToPersonalInfoDto();
			this.personalInfoFormDtoFilledOut.applicationId = this.applicationId;
			this.setRequestMvrDtoFromPersonalInfo();
		}
	}

	ngAfterViewInit() {
		setTimeout(() => {
			this.appStepsElementService.personalInfoEl = this.htmlElement.nativeElement;
			if (this.isDraft) {
				this.appStepsElementService.scrollToStep(Steps.PERSONAL_INFO);	
			}
		})
	}

	setRequestMvrDtoFromPersonalInfo() {
		this.requestMvrDto = new RequestMvrDto();
		this.requestMvrDto.applicationId = this.personalInfo.applicationId;
		this.requestMvrDto.documentNumber = this.personalInfo.documentNumber;
		this.requestMvrDto.identityDocumentType = this.personalInfo.identityDocumentType;
		this.requestMvrDto.identityNumber = this.personalInfo.identityNumber;
		this.requestMvrDto.isAuthorizedPerson = this.personalInfo.isAuthorizedPerson;
		this.requestMvrDto.nationality = this.personalInfo.nationality;
	}

	public saveDocumentNumberOfLoggedApplicantUser() {
		if (this.documentNumber && this.documentNumber.length === 9 && this.documentNumber.match('^[0-9]*$')) {
			if (this.personalInfo) {
				this.requestMvrDto.identityDocumentType = this.personalInfo.identityDocumentType;
			} else {
				this.requestMvrDto = new RequestMvrDto();
				this.requestMvrDto.identityDocumentType = new Translation(null);
				this.requestMvrDto.identityDocumentType.id = IdentityDocumentTypes.IDENTITY_CARD;
			}
			this.requestMvrDto.identityNumber = this.user.identityNumber; // не е на гише , за това се ползва така
			this.requestMvrDto.documentNumber = this.documentNumber;
			this.requestMvrDto.nationality = this.bulgariaCountry; // в кода е прието че този юзър е с бг националност
			this.requestMvrDto.isAuthorizedPerson = false;

			this.getPersonalInfoFromServices();
		} else {
			this.isDocNumInvalid = true;
		}
	}

	public checkValidity($event: Event) {
		if ((($event.target as HTMLInputElement).value.length === this.DOCUMENT_NUM_LENGTH)
		&& ($event.target as HTMLInputElement).value.match('^[0-9]*$')) {
			this.isDocNumInvalid = false;
		} else {
			this.isDocNumInvalid = true;
		}
	}

	public getInitialInfo(requestMvrDto: RequestMvrDto) {
		this.isDocNumInvalid = false;
		this.requestMvrDto = requestMvrDto;
		this.getPersonalInfoFromServices();
	}

	public getPersonalInfoFromServices() {
		const isBulgarian = Utils.checkIsBulgarian(this.requestMvrDto.nationality.id);
		const canMvrReturnInfo = Utils.checkCanMvrReturnPersonalInfo(this.requestMvrDto.documentNumber) 
			&& Utils.checkCanMvrReturnPersonalInfoBasedOnDocumentType(this.requestMvrDto.identityDocumentType.id);
		const canMakeRequestToMvr = !this.isApplicantWithEFace && isBulgarian && canMvrReturnInfo;

		if (!this.applicationId) {
			this.applicationService.createApplicationInDb(this.applicationTypeIdDto).subscribe(
				(appId) => {
					this.emitApplicationId.next(appId);
					this.applicationId = appId;
					this.applicationService.setApplicationInfoForHeader(new SubHeaderApplicationInfo(this.applicationId, 0, true));
					this.requestMvrDto.applicationId = appId;
					if (canMakeRequestToMvr) {
						this.requestPersonalInfoFromServices(this.requestMvrDto);
					} else {
						this.requestMvrWrapperDto.requestMvrDto = this.requestMvrDto;
						this.showInitialForm = false;
						this.showPersonalInfoForm = true;
					}
				});
		} else if (!this.isDocNumInvalid && !this.personalInfo && canMakeRequestToMvr) {
			this.requestMvrDto.applicationId = this.applicationId;
			this.requestPersonalInfoFromServices(this.requestMvrDto);
		} else if (!this.isDocNumInvalid) {
			this.requestMvrDto.applicationId = this.applicationId;
			this.showInitialForm = false;
			if (this.personalInfo != null) {
				this.personalInfo.documentNumber = this.requestMvrDto.documentNumber;
				this.personalInfo.nationality = this.requestMvrDto.nationality;
				this.personalInfo.identityNumber = this.requestMvrDto.identityNumber;
				this.personalInfoFormDtoFilledOut = this.personalInfo.convertToPersonalInfoDto();
				this.personalInfoFormDtoFilledOut.applicationId = this.applicationId;
			}
			this.showPersonalInfoForm = true;
		}
	}

	private requestPersonalInfoFromServices(requestMvrDto: RequestMvrDto) {
		this.isLoading = true;
		this.subjectService.getPersonalInfoFromServices(requestMvrDto).subscribe(
			(dto) => {
				this.hasMvrCheck = true;
				this.requestMvrWrapperDto.requestMvrDto = requestMvrDto;
				this.personalInfo = new PersonalInfo(dto);
				this.hasGraoCheck = this.personalInfo.hasGraoCheck;
				this.personalInfoFormDtoFilledOut = this.personalInfo.convertToPersonalInfoDto();

				this.showDisplayInfo = false;
				this.showPersonalInfoForm = true;
				this.showInitialForm = false;
				this.isDocNumInvalid = false;
			},
			(errorResponse) => {
				if (errorResponse.error) {
					var canContinue = true;
					if (errorResponse.error.error === 'PersonNotFoundMvrRegixException'
						|| errorResponse.error.error === 'MismatchException') {
						canContinue = false;
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_mvr_not_found_valid_document,
							text: POP_UP_MESSAGES_KEYS.input_valid_document,
							type: PopUpTypes.ERROR
						});
					} else if (errorResponse.error.error === 'DocumentExpiredException') {
						canContinue = false;
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_expired_document,
							text: POP_UP_MESSAGES_KEYS.input_not_expired_document,
							type: PopUpTypes.ERROR
						});
					} else if (errorResponse.error.error === 'InvalidDocumentFromMvrException') {
						canContinue = false;
						PopUpService.showPopUp({
							type: PopUpTypes.ERROR,
							header: POP_UP_MESSAGES_KEYS.mvr_check_invalid_document,
							extraInfo : (errorResponse.error.status + " / " +  errorResponse.error.statusReason),
							date: new Date(errorResponse.error.date)						
						})
					} else if (errorResponse.error.error === 'MvrChangedResponseIssuerNameException') {
						canContinue = false;
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_service_not_work,
							text: POP_UP_MESSAGES_KEYS.error_contact_system_administrator,
							type: PopUpTypes.ERROR
						});
					} else if (errorResponse.error.error === 'MvrAndGraoDoNotWork') {
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_mvr_does_not_work,
							text: POP_UP_MESSAGES_KEYS.enter_peronal_data_manually,
							type: PopUpTypes.INFO
						})
					}
					if (!canContinue) {
						this.setErrorAndInitialFormTrue(requestMvrDto);
						return;
					}
					this.personalNumber = requestMvrDto.identityNumber;
			        this.showInitialForm = false;
			        this.requestMvrWrapperDto.requestMvrDto = requestMvrDto;
					this.showPersonalInfoForm = true;
				}
			}).add(() => {
				this.isLoading = false;
			});
	}

	public setErrorAndInitialFormTrue(requestMvrDto: RequestMvrDto) {
		this.requestMvrWrapperDto = new RequestMvrWrapperDto();
		this.requestMvrWrapperDto.requestMvrDto = requestMvrDto;
		this.showInitialForm = true;
		this.showPersonalInfoForm = false;
		this.isDocNumInvalid = true;
	}

	public setPersonalInfoView(personalInfo: PersonalInfo) {
		this.personalInfo = personalInfo;
	}

	public setPersonalInfoFormDto(personalInfoDtoReady: PersonalInfoDto) {
		this.personalInfoFormDtoFilledOut = personalInfoDtoReady;
		this.personalInfo = new PersonalInfo(personalInfoDtoReady);
		this.lockSection();
	}

	editInitialInfo(requestMvrDto: RequestMvrDto) {
		this.requestMvrWrapperDto.requestMvrDto = requestMvrDto;
		this.showPersonalInfoForm = false;
		this.showDisplayInfo = false;
		this.showInitialForm = true;
		this.personalInfoFormDtoFilledOut = undefined;
	}

	editSection(personalInfoFormDto: PersonalInfoDto) {
		if (this.appStepsElementService.checkIfIsEditingAndSet(Steps.PERSONAL_INFO)) {
			return;
		}
		this.personalInfoFormDtoFilledOut = personalInfoFormDto;
		this.unlockSection();
		this.isReadOnly = false;
	}

	editSectionDocuments() {
		this.applicationService.setToMilestone(this.applicationId, MILESTONE_STATUSES.UPLOAD_PERSONAL_DOCUMENTS).subscribe(
			() => {
				this.isReadOnly = false;
			},
			(error) => PopUpService.showPopUp(DEFAULT_POP_UPS.error)
		);
	}

	unlockSection() {
		this.showInitialForm = false;
		this.showDisplayInfo = false;
		this.showPersonalInfoForm = true;
		this.emitIsEditing.emit(Steps.PERSONAL_INFO);
	}

	lockSection() {
		this.showInitialForm = false;
		this.showPersonalInfoForm = false;
		this.showDisplayInfo = true;
		this.appStepsElementService.setIsEditingToEmptyStep();
	}

	continue(event: Event) {
		this.isReadOnly = true;
		this.appStepsElementService.continueToNextStepFromCurrent(Steps.PERSONAL_INFO);
		this.lockSection();
	}

	setHasAttachedDocuments(hasAttachedDocuments: boolean) {
		this.hasAttachedDocuments = hasAttachedDocuments;
	}

}
