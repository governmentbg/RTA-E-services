import { AbstractForm } from 'src/app/shared/models/abstract-form';
import { FormGroup, Validators } from '@angular/forms';
import { CustomValidators } from 'src/app/shared/utils/custom-validators';
import { OldCardDto } from 'src/app/shared/dtos/old-card-dto';
import { Utils } from 'src/app/shared/utils/utils';

export class CardForm extends AbstractForm<OldCardDto> {

	constructor() {
		super();
		this.formGroup = this.createFormGroup();
	}

	get cardNumber() {
		return this.formGroup.get('cardNumber');
	}

	get validity() {
		return this.formGroup.get('validity');
	}

	get issuingCountry() {
		return this.formGroup.get('issuingCountry');
	}

	get issuedBy() {
		return this.formGroup.get('issuedBy');
	}

	get place() {
		return this.formGroup.get('place');
	}

	get date() {
		return this.formGroup.get('date');
	}

	public setCardFrom(cardDto: OldCardDto) {
		this.cardNumber.setValue(cardDto.cardNumber);
		this.validity.setValue(cardDto.validity);
		this.issuingCountry.setValue(cardDto.issuingCountry.id);
		this.issuedBy.setValue(cardDto.issuedBy);
		this.place.setValue(cardDto.place);
		this.date.setValue(cardDto.date);
	}

	private createFormGroup(): FormGroup {
		return this.formBuilder.group({
			issuingCountry: [null, [
				Validators.required
			]],
			cardNumber: [null, [
				Validators.required, Validators.pattern('([0-9A-Za-z]*[-,.]*)+')
			]],
			validity: [0, [
				Validators.required
			]],
			issuedBy: [null, [
				Validators.required, Validators.pattern('([А-Яа-яA-Za-z\\s]*[-,.]*)+')
			]],
			place: [null, [
				Validators.required, Validators.pattern('([А-Яа-яA-Za-z\\s]*[-,.]*)+')
			]],
			date: [0, [
				Validators.required, CustomValidators.isPastOrPresentDate()
			]],
		});
	}

	public isValidBaseOldCardInfo(): boolean {
		return this.issuingCountry.valid && this.cardNumber.valid && this.validity.valid && this.issuedBy.valid;
	}

	public isValidPlaceAndDate(): boolean {
		return this.place.valid && this.date.valid;
	}

	public toRequestDto(): OldCardDto {
		return {
			cardNumber: this.cardNumber.value,
			validity: new Date(Utils.convertDateToStringFormatted(new Date(this.validity.value))),
			issuingCountry: this.issuingCountry.value,
			issuedBy: this.issuedBy.value,
			place: this.place.value,
			date: new Date(Utils.convertDateToStringFormatted(new Date(this.date.value)))
		};
	}
}
