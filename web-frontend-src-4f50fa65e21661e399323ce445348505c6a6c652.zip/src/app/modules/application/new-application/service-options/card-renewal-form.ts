import { AbstractForm } from 'src/app/shared/models/abstract-form';
import { FormGroup, Validators } from '@angular/forms';
import { CardForm } from './card-form';
import { NamesForm } from 'src/app/shared/utils/names-form';
import { CardDto } from 'src/app/shared/dtos/card-dto';
import { CardIssuingReasons } from 'src/app/shared/enums/card-issuing-reasons';
import { CardView } from 'src/app/shared/models/card-renewal-view';
import { Translation } from 'src/app/shared/models/translation';

export class CardRenewalForm extends AbstractForm<CardDto> {

	constructor() {
		super();
		this.formGroup = this.createFormGroup();
	}

	get cardDto() {
		return this.formGroup.get('oldCardDto');
	}

	get namesDto() {
		return this.formGroup.get('namesDto');
	}

	get issuingReasonId() {
		return this.formGroup.get('issuingReasonId');
	}

	get isNameChangeSelected() {
		return this.formGroup.get('isNameChangeSelected');
	}

	public setCardRenewalForm(cardView: CardView) {
		if (cardView.oldCard) {
			this.cardDto.value.setCardFrom(cardView.oldCard);
		}
		if (cardView.names) {
			this.namesDto.value.setNames(cardView.names);
			this.isNameChangeSelected.setValue(true);
		}
		this.issuingReasonId.setValue(cardView.issuingReason.id);
	}

	private createFormGroup(): FormGroup {
		return this.formBuilder.group({
			oldCardDto: [new CardForm()],
			namesDto: [new NamesForm()],
			issuingReasonId: [0, [
				Validators.required
			]],
			isNameChangeSelected: [false]
		});
	}

	public isValid(): boolean {
		const isFormValid = super.isValid();
		let isNamesFormValid = true;
		let isCardFormValid = true;
		if (this.issuingReasonId.value !== 0) {
			if (!this.namesDto.value.isValid() && this.isNameChangeSelected.value) {
				isNamesFormValid = false;
				this.namesDto.value.formGroup.markAllAsTouched();
			}
			
			//TODO i think we don't need this
			// if (this.issuingReasonId.value !== CardIssuingReasons.LOST_ID
			// 	&& this.issuingReasonId.value !== CardIssuingReasons.STOLEN_ID
			// 	&& this.issuingReasonId.value !== CardIssuingReasons.EXPIRATION_ID
			// 		&& !this.cardDto.value.isValidBaseOldCardInfo() ) {
			// 	isCardFormValid = false;
			// 	this.cardDto.value.formGroup.markAllAsTouched();
			// } else if ((this.issuingReasonId.value === CardIssuingReasons.LOST_ID
			// 	|| this.issuingReasonId.value === CardIssuingReasons.STOLEN_ID
			// 	|| this.issuingReasonId.value !== CardIssuingReasons.EXPIRATION_ID)
			// 	&&  !this.cardDto.value.isValid() ) {
			// 	isCardFormValid = false;
			// 	this.cardDto.value.formGroup.markAllAsTouched();
			// }
		}

		return isFormValid && isCardFormValid && isNamesFormValid;
	}

	public toRequestDto(): CardDto {
		let personNamesDto = null;
		let oldCardDto = null;
		if (this.issuingReasonId.value !== CardIssuingReasons.INITIAL_ISSUING_ID) {
			oldCardDto = this.cardDto.value.toRequestDto();
			if (this.isNameChangeSelected.value || this.issuingReasonId.value === CardIssuingReasons.NAME_CHANGE_ID) {
				personNamesDto = this.namesDto.value.toRequestDto();
			}
		}

		const issuingReason = new Translation(null);
		issuingReason.id = this.issuingReasonId.value;

		return {
			oldCardDto,
			personNamesDto,
			issuingReason
		};
	}
}
