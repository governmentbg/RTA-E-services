import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { map } from 'rxjs/operators';
import { ApplicationService } from 'src/app/core/services/application.service';
import { ErrorCheckerService } from 'src/app/core/services/error-checker.service';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { SubjectService } from 'src/app/core/services/subject.service';
import { APPLICATION_TYPE } from 'src/app/shared/enums/application-types';
import { CardIssuingReasons } from 'src/app/shared/enums/card-issuing-reasons';
import { Countries } from 'src/app/shared/enums/countries';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';
import { ContractDto } from 'src/app/shared/interfaces/contract-dto';
import { CardView } from 'src/app/shared/models/card-renewal-view';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { Contract } from 'src/app/shared/models/contract';
import { OldCard } from 'src/app/shared/models/old-card';
import { Utils } from 'src/app/shared/utils/utils';

@Component({
	selector: 'app-service-approver',
	templateUrl: './service-approver.component.html',
	host: {
		"(window:click)": "onClick()"
	}
})
export class ServiceApproverComponent implements OnInit {
	@Input() number: number;
	@Input() applicationId: number;
	@Input() applicationTypeId: number;
	@Input() isEuCitizen: boolean;
	@Input() cardView: CardView;
	@Input() nationalityId: number;
	@Input() startMilestoneStatusToGetDocumentsForSection: number;
	dateFormat = S_VARIABLES.DATE_FORMAT;
	isLoading = false;
	differenceCount = 0;
	hasError = false;
	showOptions = false;

	isInitialIssuing: boolean;
	userIsBg: boolean;
	isForeignCard: boolean;
	hadApproverCheck = false;
	cardFromCheck: OldCard;
	cardNotFound: boolean;
	contracts: Contract[];
	missingContracts: boolean;

	constructor(
		private applicationService: ApplicationService,
		private errorCheckerService: ErrorCheckerService,
		private subjectService: SubjectService,
		private readonly router: Router
		) { }

	ngOnInit(): void {
		this.userIsBg = (this.nationalityId === Countries.BULGARIA_ID) ? true : false;
		if (this.cardView.issuingReason.id === CardIssuingReasons.INITIAL_ISSUING_ID) {
			this.isInitialIssuing = true;
		}
		this.isForeignCard = (this.cardView.oldCard && this.cardView.oldCard.issuingCountry.id !== Countries.BULGARIA_ID ) ? true : false;
	}

	onClick() {
		this.showOptions = false;
	}

	setShowOptions($event) {
		$event.stopPropagation();
		this.showOptions = true;
	}

	showActiveContracts() {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.showOptions = false;

		this.subjectService.getActiveContractsFromNap(this.applicationId)
			.pipe(map(
					(response: ContractDto[]) => response.map(
						(contractDto: ContractDto) => new Contract(contractDto)
					)))
			.subscribe(
				(response: Contract[]) => {
						this.contracts = response;
				}, (errorResponse) => {
					this.hasError = true;
					if (errorResponse.error) {
						if (errorResponse.error.error === 'ProxyException') {
							this.hasError = false;
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_nap_service_not_work,
								text: POP_UP_MESSAGES_KEYS.try_again_later,
								type: PopUpTypes.ERROR
							});
						} else if (errorResponse.error.error === 'NoContractFoundInNapException') {
							this.hasError = true;
							this.missingContracts = true;
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_nap_missing_contract,
								type: PopUpTypes.ERROR
							});

						}
					}
			}).add(() => {this.isLoading = false; });
	}

	checkCardFromService() {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.showOptions = false;
		this.applicationService.getCardInfoFromServiceForApprover(this.applicationId)
			.subscribe(
				(response) => {
					this.cardFromCheck = new OldCard(response);
					this.hadApproverCheck = true;
					if (!this.cardView.hasCardFromService) {
						this.cardView.oldCard =
							this.errorCheckerService.setHasErrorsAndCountDifferencesInCardInfo(this.cardView.oldCard, this.cardFromCheck );
						this.differenceCount = this.cardView.oldCard.differences;
					}
				},
				(errorResponse) => {
					this.hasError = true;
					if (errorResponse.error) {
						if (errorResponse.error.error === 'CardNotFoundException') {
							this.cardNotFound = true;
							// TODO : add logic for adr card and tacho card when services works
							if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_DQC && (this.isForeignCard || this.isInitialIssuing)) {
								this.hasError = false;
							}
							this.cardNotFound = true;

							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_card_not_found,
								type: PopUpTypes.ERROR
							});
						} else if (errorResponse.error.error === 'DocumentExpiredException') {
							// TODO : add logic for adr card and tacho card when services works
							if (this.isForeignCard || this.isInitialIssuing) {
								this.hasError = false;
							}

							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_expired_document,
								text: POP_UP_MESSAGES_KEYS.input_not_expired_document,
								type: PopUpTypes.ERROR
							});
						} else if (errorResponse.error.error === 'ProxyException') {
							this.hasError = false;
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_service_not_work,
								text: POP_UP_MESSAGES_KEYS.try_again_later,
								type: PopUpTypes.ERROR
							});
						} else if (errorResponse.error.error === 'TachoNetApplicationException') {
							PopUpService.showPopUp({
								text: Utils.getTachoNetExceptionMessage(errorResponse.error.message),
								type: PopUpTypes.ERROR
							});
						} else if (errorResponse.error.error === 'TachoNetUnknownApplicationException') {
							PopUpService.showPopUp({
								text: POP_UP_MESSAGES_KEYS.tachonet_unknown_error,
								type: PopUpTypes.ERROR
							});
						} else if (errorResponse.error.error === 'CardApplicationAlreadyStartedException') {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_already_has_started_process_for_same_card_type,
								text: POP_UP_MESSAGES_KEYS.error_can_not_continue_application_will_be_canceled,
								type: PopUpTypes.ERROR
							});
							this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]);
						}
					}
			}).add(() => {this.isLoading = false; });
	}

}
