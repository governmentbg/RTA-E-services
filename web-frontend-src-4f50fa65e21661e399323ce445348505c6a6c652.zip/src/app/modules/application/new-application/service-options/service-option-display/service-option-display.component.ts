import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CardIssuingReasons } from 'src/app/shared/enums/card-issuing-reasons';
import { CardView } from 'src/app/shared/models/card-renewal-view';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';

@Component({
	selector: 'app-service-option-display',
	templateUrl: './service-option-display.component.html'
})
export class ServiceOptionDisplayComponent implements OnInit {
	@Input() public number: number;
	@Input() isDraft: boolean;
	@Input() public cardView: CardView;
	@Input() public hasAttachedDocuments: boolean;
	@Output() public emitEditSection = new EventEmitter<CardView>();
	@Output() public emitEditDocumentsSection: EventEmitter<Event> = new EventEmitter<Event>();

	dateFormat = S_VARIABLES.DATE_FORMAT;
	isInitialIssuing = false;
	get cardIssuingReasonsEnum() { return CardIssuingReasons; }

	constructor() { }

	ngOnInit(): void {
		if (CardIssuingReasons.INITIAL_ISSUING_ID === this.cardView.issuingReason.id) {
			this.isInitialIssuing = true;
		}
	}

	editSection() {
		this.emitEditSection.next(this.cardView);
	}

	editDocumentsForSection(event: Event) {
		this.emitEditDocumentsSection.emit(event);
	}
}
