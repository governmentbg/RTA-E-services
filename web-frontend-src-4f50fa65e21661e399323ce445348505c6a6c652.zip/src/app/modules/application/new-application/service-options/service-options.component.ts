import { Component, OnInit, Input, ViewChild, AfterViewInit, Output, EventEmitter } from '@angular/core';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { CardIssuingReasons, 
	DQC_REASONS, 
	REASONS_WITHOUT_FIELDS_FOR_NAMES, REASONS_WITHOUT_FIELDS_FOR_PLACE_DATE_OR_NAMES, TACHO_REASONS } from 'src/app/shared/enums/card-issuing-reasons';
import { Countries } from 'src/app/shared/enums/countries';

import { ApplicationService } from 'src/app/core/services/application.service';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { Steps } from 'src/app/shared/enums/steps';
import { CardRenewalForm } from './card-renewal-form';
import { APPLICATION_TYPE } from 'src/app/shared/enums/application-types';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { CardView } from 'src/app/shared/models/card-renewal-view';
import { RequiredDocumentType } from 'src/app/shared/models/required-document-type';
import { MILESTONE_STATUSES } from 'src/app/shared/enums/milestone-statuses';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { Translation } from 'src/app/shared/models/translation';
import { User } from 'src/app/shared/models/user';
import { OldCardDto } from 'src/app/shared/dtos/old-card-dto';
import { OldCard } from 'src/app/shared/models/old-card';
import { CardDto } from 'src/app/shared/dtos/card-dto';
import { CardViewDto } from 'src/app/shared/interfaces/card-dto';
import { TranslationDto } from 'src/app/shared/dtos/translation-dto';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';
import { Router } from '@angular/router';
import { Utils } from 'src/app/shared/utils/utils';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { CountryDto } from 'src/app/shared/interfaces/country-dto';
import { Country } from 'src/app/shared/models/country';

@Component({
	selector: 'app-service-options',
	templateUrl: './service-options.component.html'
})
export class ServiceOptionComponent implements OnInit, AfterViewInit {
	@Input() number: number;
	@Input() isDraft: boolean;
	@Input() public user: User;
	@Input() isEuCitizen: boolean;
	@Input() applicationId: number;
	@Input() applicationTypeId: number;
	@Input() nationalityId: number;
	@Input() cardView: CardView;
	@Input() alreadyAttachedDocTypes: Translation[] = [];

	@Input() isEditing: Steps;
	@Output() public emitIsEditing = new EventEmitter<Steps>();
	@ViewChild('serviceHtmlElement') htmlElement: { nativeElement: HTMLElement; };
	dateFormat = S_VARIABLES.DATE_FORMAT;
	get cardIssuingReasonsEnum() { return CardIssuingReasons; }
	get countriesEnum() { return Countries; }

	bulgarianDocumentIssuers: Translation[] = [];
	cardIssuingReasons: Translation[] = [];
	initialIssuing: Translation;
	countries: Country[] = [];
	isInitialIssuingSelected: boolean;
	isLocked: boolean;
	isRenewalSelected: boolean;
	selectedCardIssuingReasonId = 0;
	matAutocomplete: MatAutocompleteModule;
	today: Date = new Date();
	isLoading = false;
	cardInfoToBeSaved: CardDto;

	showDisplayInfo: boolean;
	attachedDocTypes: RequiredDocumentType[] = [];
	cardRenewalForm: CardRenewalForm;
	oldCardFromService: OldCard;

	isReadOnly: boolean;
	startMilestoneStatusToGetDocumentsForSection = MILESTONE_STATUSES.CERTIFICATE_CHECKS_FINISHED;
	hasAttachedDocuments = false;

	constructor(
		private nomenclatureService: NomenclatureService,
		private applicationService: ApplicationService,
		private appStepsElementService: ApplicationStepsElementsService,
		private readonly router: Router,
	) { }

	ngOnInit() {
		if (!this.user.isApprover()) {
			this.cardRenewalForm = new CardRenewalForm();
			this.getNomenclatures();
		}
		
		if (!this.cardView) {
			this.isInitialIssuingSelected = false;
			this.checkForCardInService();
		} else if (this.cardView.issuingReason === null) {
			this.isInitialIssuingSelected = false;
			this.selectRenewal();
		} else {
			this.showDisplayInfo = true;
			if (this.cardView.issuingReason.id === CardIssuingReasons.INITIAL_ISSUING_ID) {
				this.isInitialIssuingSelected = true;
			}
			if (this.appStepsElementService.canSeeDelivery) {
				this.isReadOnly = true;
			}
		}
	}

	ngAfterViewInit() {
		setTimeout(() => {
			this.appStepsElementService.serviceOptionEl = this.htmlElement.nativeElement;
			if (this.isDraft) {
				this.appStepsElementService.scrollToStep(Steps.SERVICE);
			}
		})
	}

	getNomenclatures() {
		this.nomenclatureService.getAllCardIssuingReasons()
				.subscribe((reasonDtos: TranslationDto[]) => {
					reasonDtos.forEach((dto: TranslationDto) => {
						if (dto.id !== CardIssuingReasons.INITIAL_ISSUING_ID) {
							if (dto.id === CardIssuingReasons.TACHO_TAKEN_AWAY_ID) {
								if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_TACHO_CARD) {
									this.cardIssuingReasons.push(new Translation(dto));
								}
							} else {
								this.cardIssuingReasons.push(new Translation(dto));
							}
						} else {
							this.initialIssuing = new Translation(dto);
						}
					});
				});
		this.nomenclatureService.getIdentityDocumentIssuers()
			.subscribe((documentIssuers: TranslationDto[]) => {
				documentIssuers.forEach((dto: TranslationDto) => {
					this.bulgarianDocumentIssuers.push(new Translation(dto));
				});
			});
		this.nomenclatureService.getAllCountries()
			.subscribe((countriesDto: CountryDto[]) => {
				countriesDto.forEach((countriesDto: CountryDto) => {
					this.countries.push(new Country(countriesDto));
				});
			});
	}

	selectRenewal() {
		this.cardRenewalForm.issuingReasonId.setValue(0);
		this.isInitialIssuingSelected = false;
		this.isRenewalSelected = true;
		this.selectedCardIssuingReasonId = 0;
		if (this.cardView?.hasCardFromService) {
			this.cardRenewalForm.cardDto.value.setCardFrom(this.cardView.oldCard);
			//if old card has more that three month validity left don't show the expires option
			if (this.cardView.oldCard.validity > new Date(this.today.getFullYear(), this.today.getMonth() + 3, this.today.getDate())) {
				this.cardIssuingReasons = this.cardIssuingReasons.filter(x => x.id !== CardIssuingReasons.EXPIRATION_ID);
			}
		}
		this.filterCardIssuingReasons();
	}

	selectInitialIssuing() {
		if (this.cardView?.hasCardFromService) {
			return;
		}
		this.cardRenewalForm.issuingReasonId.setValue(CardIssuingReasons.INITIAL_ISSUING_ID);
		this.isInitialIssuingSelected = true;
		this.isRenewalSelected = false;
	}

	saveCard() {
		if ((this.isInitialIssuingSelected 
			|| (!this.isInitialIssuingSelected 
				&& this.cardRenewalForm.isValid()))
				&& !this.appStepsElementService.checkIfIsEditingAndSet(Steps.SERVICE)) {
			this.isLoading = true;
			if (this.isInitialIssuingSelected) {
				const issuingReason = new TranslationDto(CardIssuingReasons.INITIAL_ISSUING_ID);
				this.cardInfoToBeSaved = new CardDto(issuingReason);
			} else {
				this.cardInfoToBeSaved = this.cardRenewalForm.toRequestDto();
				if (this.cardView?.hasCardFromService) {
					this.setCardFromService();
				}
				this.cleanInputIfIsNotUsed();
			}
			this.applicationService.saveCardInfo(this.applicationId, this.cardInfoToBeSaved).subscribe(
				(response: CardViewDto) => {
					this.cardView = new CardView(response);
					this.showDisplayInfo = true;
				},
				(errorResponse) => {
					this.showDisplayInfo = false;
					if (errorResponse.error) {
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.try_again_later,
							type: PopUpTypes.ERROR
						});
					}
			}).add(() => {
				this.isLoading = false;
				this.cardInfoToBeSaved = null;
				this.appStepsElementService.setIsEditingToEmptyStep();
			});
		}
	}

	editSection(cardView: CardView) {
		if (this.appStepsElementService.checkIfIsEditingAndSet(Steps.SERVICE)) {
			return;
		}

		this.applicationService.setToMilestone(this.applicationId, MILESTONE_STATUSES.CERTIFICATE_CHECKS_FINISHED).subscribe(
			() => {
				if (cardView.issuingReason.id !== CardIssuingReasons.INITIAL_ISSUING_ID) {
					this.cardRenewalForm.setCardRenewalForm(cardView);
					this.countries.forEach((countryDto) => {
						if (countryDto.country.id === cardView.oldCard.issuingCountry.id) {
							this.cardRenewalForm.cardDto.value.issuingCountry.setValue(countryDto.country);
						}
					});
					this.isInitialIssuingSelected = false;
					this.isRenewalSelected = true;
				} else {
					this.isRenewalSelected = false;
					this.isInitialIssuingSelected = true;
				}
				this.selectedCardIssuingReasonId = cardView.issuingReason.id;
				this.showDisplayInfo = false;
			},
			(error) => PopUpService.showPopUp({
				header: error.error.message,
				type: PopUpTypes.ERROR
			})
		).add(() => {
			this.isLoading = false;
		});
	}

	continue(event: Event) {
		this.isReadOnly = true;
		this.appStepsElementService.continueToNextStepFromCurrent(Steps.SERVICE);
	}

	editSectionDocuments(event: Event) {
		if (this.appStepsElementService.checkIfIsEditingAndSet(Steps.SERVICE)) {
			return;
		}
		this.applicationService.setToMilestone(this.applicationId, MILESTONE_STATUSES.UPLOAD_CARD_DOCUMENTS).subscribe(
			() => {
				this.isReadOnly = false;
			},
			(error) => PopUpService.showPopUp(DEFAULT_POP_UPS.error)
		);
	}

	setHasAttachedDocuments(hasAttachedDocuments: boolean) {
		this.hasAttachedDocuments = hasAttachedDocuments;
	}

	checkForCardInService() {
		this.isLoading = true;
		this.applicationService.getCardInfoFromService(this.applicationId)
			.subscribe((oldCardDto: OldCardDto) => {
				if (oldCardDto) {
					this.cardView = new CardView();
					this.cardView.hasCardFromService = true;
					this.cardView.oldCard = new OldCard(oldCardDto);
					this.selectRenewal();
				}
			},
			(errorResponse) => {
				if (errorResponse.error.error === 'CardApplicationAlreadyStartedException') {
					PopUpService.showPopUp({
						header: POP_UP_MESSAGES_KEYS.error_already_has_started_process_for_same_card_type,
						text: POP_UP_MESSAGES_KEYS.error_can_not_continue_application_will_be_canceled,
						type: PopUpTypes.ERROR
					});
					if (this.user.isApplicant()) {
						this.router.navigate([RouteUrl.DASHBOARD]);
					} else {
						this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]);
					}
				} else if (errorResponse.error.error === 'TachoNetApplicationException') {
					PopUpService.showPopUp({
						text: Utils.getTachoNetExceptionMessage(errorResponse.error.message),
						type: PopUpTypes.ERROR
					});
				} else if (errorResponse.error.error === 'TachoNetUnknownApplicationException') {
					PopUpService.showPopUp({
						text: POP_UP_MESSAGES_KEYS.tachonet_unknown_error,
						type: PopUpTypes.ERROR
					});
				} else if (errorResponse.error.error === 'NoContractFoundInNapException') {
					PopUpService.showPopUp({
						header: POP_UP_MESSAGES_KEYS.check_in_nap_show_missing_contract,
						text: POP_UP_MESSAGES_KEYS.error_can_not_continue_application_will_be_canceled,
						type: PopUpTypes.ERROR
					});
					if (this.user.isApplicant()) {
						this.router.navigate([RouteUrl.DASHBOARD]);
					} else {
						this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]);
					}
				}
			}).add(() => {
				this.isLoading = false;
			});
	}

	setCardFromService() {
		this.cardInfoToBeSaved.oldCardDto.validity = this.cardView.oldCard.validity;
		this.cardInfoToBeSaved.oldCardDto.cardNumber = this.cardView.oldCard.cardNumber;
		this.cardInfoToBeSaved.oldCardDto.issuedBy = this.cardView.oldCard.issuedBy;
		const issuingCountry = new TranslationDto(null);
		issuingCountry.id = this.cardView.oldCard.issuingCountry.id;
		this.cardInfoToBeSaved.oldCardDto.issuingCountry = issuingCountry;
	}

	cleanInputIfIsNotUsed() {
		if (REASONS_WITHOUT_FIELDS_FOR_PLACE_DATE_OR_NAMES.includes(this.cardInfoToBeSaved.issuingReason.id)) {
			this.cardInfoToBeSaved.oldCardDto.date = null;
			this.cardInfoToBeSaved.oldCardDto.place = null;
			this.cardInfoToBeSaved.personNamesDto = null;
		} else if (REASONS_WITHOUT_FIELDS_FOR_NAMES.includes(this.cardInfoToBeSaved.issuingReason.id)) {
			this.cardInfoToBeSaved.personNamesDto = null;
		} else if (this.cardInfoToBeSaved.issuingReason.id === CardIssuingReasons.NAME_CHANGE_ID) {
			this.cardInfoToBeSaved.oldCardDto.date = null;
			this.cardInfoToBeSaved.oldCardDto.place = null;
		}
	}

	filterCardIssuingReasons() {
		if (this.applicationTypeId == APPLICATION_TYPE.APPLICATION_TACHO_CARD) {
			this.cardIssuingReasons = this.cardIssuingReasons.filter( reason => TACHO_REASONS.indexOf(reason.id) >= 1);
		}

		if (this.applicationTypeId == APPLICATION_TYPE.APPLICATION_DQC) {
			this.cardIssuingReasons = this.cardIssuingReasons.filter( reason => DQC_REASONS.indexOf(reason.id) >= 1);
		}
	}
}
