import { Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { SubjectService } from 'src/app/core/services/subject.service';
import { RequestMvrDto } from 'src/app/shared/dtos/request-mvr-dto';
import { ATTACHED_DOCUMENT_TYPE } from 'src/app/shared/enums/attached-document-types';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { PhotoAndSignatureDto } from 'src/app/shared/interfaces/photo-and-signature-dto';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { PersonalInfo } from 'src/app/shared/models/personal-info';
import { Translation } from 'src/app/shared/models/translation';
import { BehaviorSubject } from 'rxjs';
import { FileService } from 'src/app/core/services/file.service';
@Component({
	selector: 'app-signature-and-photo-approver',
	templateUrl: './signature-and-photo-approver.component.html',
	host: {
		"(window:click)": "onClick()"
	}
})
export class SignatureAndPhotoApproverComponent implements OnInit {
	@Input() number: number;
	@Input() applicationId: number;
	@Input() applicationTypeId: number;
	@Input() hasEditedPictures: boolean;
	@Input() hasAutoFixedPicturesFromMvr: boolean;
	@Input() personalInfo: PersonalInfo;
	@Input() bulgariaCountry: Translation;
	showOptions = false;
	isLoading = false;
	attachFaceDocTypeId = ATTACHED_DOCUMENT_TYPE.PICTURE_FACE;
	attachSignatureDocTypeId = ATTACHED_DOCUMENT_TYPE.PICTURE_SIGNATURE;

	requestMvrDto: RequestMvrDto;
	faceMvrFromCheck: string;
	hasError = false;
	isForeigner: boolean;
	hadApproverCheck = false;
	isSamePerson = false;

	pictureFromCheck: string;
	signatureFromCheck: string;

	editPictureFromCheck = false;
	isReadOnly = true;
	isReadOnlySignature = true;
	isReadOnlyFace = true;
	public $isContinueButtonClicked = new BehaviorSubject(false);

	constructor(private subjectService: SubjectService) { }

	ngOnInit(): void {
		this.isForeigner = (this.personalInfo.nationality.id === this.bulgariaCountry.id) ? false : true;
	}

	onClick() {
		this.showOptions = false;
	}

	setShowOptions($event) {
		$event.stopPropagation();
		this.showOptions = true;
	}

	setIsSamePerson(isSamePerson: boolean) {
		if (isSamePerson) {
			this.hasError = false;
			this.isSamePerson = true;
		} else {
			this.hasError = true;
			this.isSamePerson = false;
		}
	}

	doMvrPicturesCheck() {
		if (this.isLoading || !this.isReadOnlyFace || !this.isReadOnlySignature) {
			return;
		}
		this.isLoading = true;
		this.showOptions = false;
		this.isSamePerson = null;
		this.hasError = false;
		this.setRequestMvrDto();
		this.subjectService.getPhotoAndSignatureFromMvrForApprover(this.requestMvrDto)
			.subscribe(
				(response: PhotoAndSignatureDto) => {
					this.pictureFromCheck = FileService.DATA_IMAGE_AS_BASE_64 + response.picture;
					this.signatureFromCheck = FileService.DATA_IMAGE_AS_BASE_64 + response.signature;
					this.hadApproverCheck = true;
				},
				(errorResponse) => {
					this.hasError = true;
					this.pictureFromCheck = '';
					this.signatureFromCheck = '';

					if (errorResponse.error.error === 'PersonNotFoundMvrRegixException') {
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_mvr_not_found_valid_document,
							text: POP_UP_MESSAGES_KEYS.input_valid_document,
							type: PopUpTypes.ERROR
						});
					} else if (errorResponse.error.error === 'DocumentExpiredException') {
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_expired_document,
							text: POP_UP_MESSAGES_KEYS.input_not_expired_document,
							type: PopUpTypes.ERROR
						});
					} else if (errorResponse.error.error === 'MvrAndGraoDoNotWork'
							|| errorResponse.error.error === 'ProxyException') {
						this.hasError = false;
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_service_not_work,
							text: POP_UP_MESSAGES_KEYS.try_again_later,
							type: PopUpTypes.ERROR
						});
					}
			}).add(() => {
				this.isLoading = false; 
			});

	}

	setRequestMvrDto() {
		this.requestMvrDto = new RequestMvrDto();
		this.requestMvrDto.applicationId = this.personalInfo.applicationId;
		this.requestMvrDto.documentNumber = this.personalInfo.documentNumber;
		this.requestMvrDto.identityDocumentType = this.personalInfo.identityDocumentType;
		this.requestMvrDto.identityNumber = this.personalInfo.identityNumber;
		this.requestMvrDto.isAuthorizedPerson = false;
		this.requestMvrDto.nationality = this.personalInfo.nationality;
	}

	editSignature() {
		if (this.anyPictureIsEditing()) { 
			return;
		}
		this.isReadOnlySignature = false;
	}

	editFace() {
		if (this.anyPictureIsEditing()) {
			return;
		}
		this.isReadOnlyFace = false;
	}

	editMvrSignature() {
		if (this.anyPictureIsEditing()) {
			return;
		}
		this.isReadOnlySignature = false;
		this.editPictureFromCheck = true;
	}

	editMvrFace() {
		if (this.anyPictureIsEditing()) {
			return;
		}
		this.isReadOnlyFace = false;
		this.editPictureFromCheck = true;
	}

	approverEditSignature() {
		this.isReadOnlySignature = true;
		this.editPictureFromCheck = false;
	}

	approverEditFace() {
		this.isReadOnlyFace = true;
		this.editPictureFromCheck = false;
	}

	replaceSrcWithBlob(src: string) {
		return src.replace(FileService.DATA_IMAGE_AS_BASE_64, '');
	}

	anyPictureIsEditing() {
		return !this.isReadOnlySignature || !this.isReadOnlyFace;
	}

	getBlobSrc(src: string) {
		if (this.editPictureFromCheck) {
			return src.replace(FileService.DATA_IMAGE_AS_BASE_64, '');
		}
		return null;
	}
}
