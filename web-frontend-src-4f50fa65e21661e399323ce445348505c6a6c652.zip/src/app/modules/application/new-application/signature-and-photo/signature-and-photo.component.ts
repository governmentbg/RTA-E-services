import { Component, OnInit, Input, ViewChild, AfterViewInit, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { ATTACHED_DOCUMENT_TYPE } from 'src/app/shared/enums/attached-document-types';
import { BehaviorSubject } from 'rxjs';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { Steps } from 'src/app/shared/enums/steps';
import { SubjectService } from 'src/app/core/services/subject.service';
import { HttpResponse } from '@angular/common/http';
import { DocumentService } from 'src/app/core/services/document.service';
import { RequiredDocumentType } from 'src/app/shared/models/required-document-type';
import { FileService } from 'src/app/core/services/file.service';
import { ApplicationService } from 'src/app/core/services/application.service';
import { MILESTONE_STATUSES } from 'src/app/shared/enums/milestone-statuses';
import { User } from 'src/app/shared/models/user';
import { PersonalInfo } from 'src/app/shared/models/personal-info';
import { Translation } from 'src/app/shared/models/translation';

@Component({
	selector: 'app-signature-and-photo',
	templateUrl: './signature-and-photo.component.html',
})
export class SignatureAndPhotoComponent implements OnInit, AfterViewInit {
	@Input() number: number;
	@Input() isDraft: boolean;
	@Input() user: User;
	@Input() public applicationId: number;
	@Input() applicationTypeId: number;
	@Input() personalInfo: PersonalInfo;
	@Input() isEditing: Steps;
	@Input() bulgariaCountry: Translation;
	@Input() hasMvrCheck: boolean;
	@Input() hasEditedPictures: boolean;
	@Input() hasAutoFixedPicturesFromMvr: boolean;
	@Output() public emitIsEditing = new EventEmitter<Steps>();
	@ViewChild('signatureAndPhotoElement') htmlElement: { nativeElement: HTMLElement; };

	public $isContinueButtonClicked = new BehaviorSubject(false);
	attachFaceDocTypeId = ATTACHED_DOCUMENT_TYPE.PICTURE_FACE;
	attachSignatureDocTypeId = ATTACHED_DOCUMENT_TYPE.PICTURE_SIGNATURE;
	uploadedTypeIds: number[] = [];
	picUrl: string;
	signatureUrl: string;
	pictureOfUserOnDesk: string;
	isApplicant: boolean;
	isDeskStaff: boolean;
	isUserWithEFace: boolean;
	requiredDocTypeId: number;
	isLoading: boolean;
	showViewer = false;
	filename: string;
	srcFromArrayBuffer: ArrayBuffer;
	faceMvrOriginal: string;
	signatureMvrOriginal: string;
	isReadOnly: boolean;
	hasImageFromMvr = false;
	editedPicturesDocTypeIds: number[] = [];
	picturesAreLoaded = false;

	constructor(
		private applicationService: ApplicationService,
		private documentService: DocumentService,
		private appStepsElementService: ApplicationStepsElementsService,
		private reference: ChangeDetectorRef,
		private subjectService: SubjectService,
		private fileService: FileService
	) { }

	ngOnInit(): void {
		if (!this.user.isApprover()) {
			this.isUserWithEFace = this.user.isEFaceApplicant();
			this.isApplicant = this.user.isApplicant();
			this.isDeskStaff = this.user.isDeskStaff();

			if (this.isDraft && this.hasEditedPictures) {
				this.isReadOnly = true;
				// след изтестване на логване чрез упълномощено лице да решава дали да се показва И снимка на ауторизиранот лице за сравнение
				// if (this.isDeskStaff) {
				// 	this.getPictureOfUserOnDesk();
				// }
				this.appStepsElementService.continueToNextStepFromCurrent(Steps.SIGNATURE_AND_PHOTO);
			} else if (this.isDraft && !this.hasEditedPictures) {
				this.isReadOnly = false;
			} 
			if (this.hasAutoFixedPicturesFromMvr) {
				this.uploadedTypeIds.push(this.attachFaceDocTypeId);
			}

			if (!this.isDraft && !this.isApplicant && this.hasAutoFixedPicturesFromMvr) {
				this.getOriginalMvrPicturesOfFaceAndSignature();
			}
		}
		if (this.appStepsElementService.canSeeSigning) {
			this.isReadOnly = true;
		}
	}

	ngAfterViewInit() {
		setTimeout(() => {
			this.appStepsElementService.signatureAndPhotoEl = this.htmlElement.nativeElement;
			if (this.isDraft) {
				this.appStepsElementService.scrollToStep(Steps.SIGNATURE_AND_PHOTO);
			}
		})
	}

	getPictureOfUserOnDesk() {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.documentService
			.getDeskSubjectFacePicture(this.applicationId)
			.subscribe(
				(response: HttpResponse<ArrayBuffer>) => {
					this.srcFromArrayBuffer = response.body;
					this.pictureOfUserOnDesk = this.fileService.convertFromArrayBufferImageToBase64String(response.body);
					this.filename = this.fileService.getFilenameFromResponse(response);
				},
				(error) => {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_can_not_open_file_try_later);
				}).add(() => this.isLoading = false);
	}

	getUploadedDocumentType(type: RequiredDocumentType) {
		this.uploadedTypeIds.push(type.id);
	}

	continueToNextStep() {
		if (!this.appStepsElementService.checkIfIsEditingAndSet(Steps.SIGNATURE_AND_PHOTO)) {
			this.$isContinueButtonClicked.next(true);
			if (!this.hasEditedPictures) {
				if (this.uploadedTypeIds.indexOf(this.attachFaceDocTypeId) !== -1
					&& this.uploadedTypeIds.indexOf(this.attachSignatureDocTypeId) !== -1) {
						this.isLoading = true;
						this.subjectService.saveFaceAndPictureSectionTransition(this.applicationId).subscribe(
							() => {
								this.isReadOnly = true;
								this.appStepsElementService.continueToNextStepFromCurrent(Steps.SIGNATURE_AND_PHOTO);
								this.appStepsElementService.setIsEditingToEmptyStep();
								this.hasEditedPictures = true;
							}).add(() => this.isLoading = false);
				} else {
					this.reference.detectChanges();
					const elements = document.getElementsByClassName('box-validation error');
					elements[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
				}
			} else {
				this.isReadOnly = true;
				this.appStepsElementService.continueToNextStepFromCurrent(Steps.SIGNATURE_AND_PHOTO);
			}
		} else {
			this.appStepsElementService.setIsEditingToEmptyStep();
		}
	}

	openImageOfUserOnDesk() {
		this.showViewer = true;
	}

	hideViewer() {
		this.showViewer = false;
	}

	editSection() {
		if (this.appStepsElementService.checkIfIsEditingAndSet(Steps.SIGNATURE_AND_PHOTO)) {
			return;
		}
		this.applicationService.setToMilestone(this.applicationId, MILESTONE_STATUSES.DELIVERY_CHOSEN)
			.subscribe(
				() => {
					this.uploadedTypeIds = [];
					if (this.hasAutoFixedPicturesFromMvr) {
						this.uploadedTypeIds.push(this.attachFaceDocTypeId);
					}
					this.isReadOnly = false;
					this.hasEditedPictures = false;
					this.$isContinueButtonClicked = new BehaviorSubject(false);
				}
			);
	}

	getOriginalMvrPicturesOfFaceAndSignature() {
		this.documentService
			.getOriginalPictureOfFaceOrSignature(this.applicationId, ATTACHED_DOCUMENT_TYPE.PICTURE_FACE)
			.subscribe(
				(response: HttpResponse<ArrayBuffer>) => {
					if (response.body) {
						this.faceMvrOriginal = this.fileService.convertFromArrayBufferImageToBase64String(response.body);
						this.hasImageFromMvr = true;
					} else {
						this.hasImageFromMvr = false;
					}
				});
		this.documentService
			.getOriginalPictureOfFaceOrSignature(this.applicationId, ATTACHED_DOCUMENT_TYPE.PICTURE_SIGNATURE)
			.subscribe(
				(response: HttpResponse<ArrayBuffer>) => {
					if (response.body) {
						this.signatureMvrOriginal = this.fileService.convertFromArrayBufferImageToBase64String(response.body);
						this.hasImageFromMvr = true;
					} else {
						this.hasImageFromMvr = false;
					}
				});
	}

	editedPictureIsLoaded(docTypeId: number) {
		this.editedPicturesDocTypeIds.push(docTypeId);
		if (this.editedPicturesDocTypeIds.length === 2) {
			this.picturesAreLoaded = true;
		}
	}

}
