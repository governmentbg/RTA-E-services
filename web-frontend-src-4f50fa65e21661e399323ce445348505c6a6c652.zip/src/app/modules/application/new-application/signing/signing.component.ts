import { Component, OnInit, Input, AfterViewInit, ViewChild, EventEmitter } from '@angular/core';
import { ATTACHED_DOCUMENT_TYPE } from 'src/app/shared/enums/attached-document-types';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { Router } from '@angular/router';
import { ApplicationService } from 'src/app/core/services/application.service';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { Steps } from 'src/app/shared/enums/steps';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { RequiredDocumentType } from 'src/app/shared/models/required-document-type';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';
import { Output } from '@angular/core';
import { User } from 'src/app/shared/models/user';
import { AUTH_METHODS } from 'src/app/shared/enums/auth-methods';

@Component({
	selector: 'app-signing',
	templateUrl: './signing.component.html'
})

export class SigningComponent implements OnInit, AfterViewInit {
	@Input() number: number;
	@Input() applicationId: number;
	@Input() isDraft: boolean;
	@Input() applicationAuthMethodId: number;
	@Input() user: User;
	isReadOnly: boolean;
	@Output() approverGenerateApplication: EventEmitter<Event> = new EventEmitter();
	@ViewChild('signingHtmlElement') htmlElement: { nativeElement: HTMLElement; };

	public applicationDocumentTypeId: number;
	public $isContinueButtonClicked = new BehaviorSubject(false);
	private uploadedDocumentTypeId: number;
	public hasAllRequiredDocumentsAttached = true;

	constructor(
		private readonly router: Router,
		private readonly applicationService: ApplicationService,
		private readonly appStepsElementService: ApplicationStepsElementsService
	) { }

	ngOnInit() {
		if (this.isDraft) {
			this.isReadOnly = false;
		} else {
			const applicantIsWithEFace = (this.applicationAuthMethodId === AUTH_METHODS.E_FACE);
			if (this.user.isApprover() && applicantIsWithEFace) {
				this.isReadOnly = false;
			} else {
				this.isReadOnly = true;
			}
		}
		this.applicationDocumentTypeId = ATTACHED_DOCUMENT_TYPE.APPLICATION;
	}

	ngAfterViewInit() {
		setTimeout(() => {
			this.appStepsElementService.signingEl = this.htmlElement.nativeElement;
			if (this.isDraft) {
				this.appStepsElementService.scrollToStep(Steps.SIGNING);
			}
		})
	}

	continueToNextStep() {
		this.$isContinueButtonClicked.next(true);
	}

	getUploadedDocumentType(uploadedDocumentType: RequiredDocumentType) {
		this.uploadedDocumentTypeId = uploadedDocumentType.id;
		if (this.uploadedDocumentTypeId === this.applicationDocumentTypeId) {
			this.applicationService
				.submitApplication(this.applicationId)
				.subscribe(
					(success) => {
						PopUpService.showPopUp(DEFAULT_POP_UPS.success_application_submitted);
						this.isDraft = false;
						this.isReadOnly = true;
						this.appStepsElementService.continueToNextStepFromCurrent(Steps.SIGNING);
						this.router.navigate([RouteUrl.APPLICATION, this.applicationId]);
					},
					(error) => {
						PopUpService.showPopUp(DEFAULT_POP_UPS.error_application_not_submitted);
					});
		}
	}

	approverHasGeneratedApplication() {
		this.approverGenerateApplication.emit();
	}
}
