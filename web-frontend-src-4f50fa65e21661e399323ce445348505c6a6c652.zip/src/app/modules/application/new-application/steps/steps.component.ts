import { Component, OnInit, Inject, HostListener, Input } from '@angular/core';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { DOCUMENT } from '@angular/common';
import { Steps } from 'src/app/shared/enums/steps';
import { Subscription } from 'rxjs';
import { APPLICATION_TYPE } from 'src/app/shared/enums/application-types';

@Component({
	selector: 'app-steps',
	templateUrl: './steps.component.html',
})
export class StepsComponent implements OnInit {
	@Input() public applicationTypeId: number;

	public fixed = false;
	public Steps = Steps;
	public APPLICATION_TYPE = APPLICATION_TYPE;
	public eventSubscription: Subscription;
	PIXEL_HIGHT_FOR_ATTACHING_STEPS_MENU = 260;

	public passedSteps: string[] = [];

	constructor(
		public appStepsElementsService: ApplicationStepsElementsService,
		@Inject(DOCUMENT) private doc: Document
	) { }

	ngOnInit(): void {
	}

	@HostListener('window:scroll', ['$event'])
	onWindowScroll() {
		const num = this.doc.scrollingElement.scrollTop;
		if (num >= this.PIXEL_HIGHT_FOR_ATTACHING_STEPS_MENU) {
			this.fixed = true;
		} else if (this.fixed && num < this.PIXEL_HIGHT_FOR_ATTACHING_STEPS_MENU) {
			this.fixed = false;
		}
	}
}
