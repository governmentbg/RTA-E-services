import { Component, OnInit, Input, OnDestroy, HostListener, Output, EventEmitter } from '@angular/core';
import { LocaleService } from 'angular-l10n';
import { Application } from 'src/app/shared/models/application';
import { saveAs } from 'file-saver';
import { Subscription } from 'rxjs/internal/Subscription';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { SummaryInfo } from 'src/app/shared/models/summary-info';
import { DocumentService } from 'src/app/core/services/document.service';
import { HttpResponse } from '@angular/common/http/http';
import { Language } from 'angular-l10n';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { ApplicationService } from 'src/app/core/services/application.service';
import { Router } from '@angular/router';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { RemarkDto } from 'src/app/shared/dtos/remark-dto';
import { ApplicationRemarkViewDto } from 'src/app/shared/interfaces/application-remark-view-dto';
import { Remark } from 'src/app/shared/models/remark';
import { map } from 'rxjs/operators';
import { APPLICATION_STATUSES } from 'src/app/shared/enums/application-statuses';
import { User } from 'src/app/shared/models/user';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { AUTH_METHODS } from 'src/app/shared/enums/auth-methods';

@Component({
	selector: 'app-application-summary-extended-header',
	templateUrl: './application-summary-extended-header.component.html',
})
export class ApplicationSummaryExtendedHeaderComponent implements OnInit , OnDestroy {

	@Input() application: Application;
	@Input() statusId: number;
	@Input() user: User;
	@Input() approverHasGeneratedApplication: boolean;
 	@Output() emitRemarks: EventEmitter<Remark[]> = new EventEmitter<Remark[]>();
	@Language() lang: string;
	languageChangeSubscription: Subscription;
	languageBG = S_VARIABLES.LANGUAGE_BG;
	dateFormat = S_VARIABLES.DATE_FORMAT;
	currentLanguage: string;
	summaryInfo: SummaryInfo;
	isLoading: boolean;
	isAttachedDocumentsListVisible = false;
	isFlagListVisible = false;
	isApplicant: boolean;
	showOptions = false;
	// buttons for approver
	canApprove: boolean;
	canDeliver: boolean;

	@HostListener('document:click', ['$event'])
	onClick() {
		this.isAttachedDocumentsListVisible = false;
		this.isFlagListVisible = false;
		this.showOptions = false;
	}

	constructor(
		private readonly locale: LocaleService,
		private readonly documentService: DocumentService,
		private readonly applicationService: ApplicationService,
		private readonly authenticationService: AuthenticationService,
		private readonly router: Router,
	) { }

	ngOnInit(): void {
		this.isApplicant = this.authenticationService.getAuthenticatedUser().isApplicant();
		this.summaryInfo = new SummaryInfo(this.application);
		this.languageChangeSubscription = this.locale.languageCodeChanged.subscribe((currentCode: string) => {
			this.currentLanguage = currentCode;
		});
		this.currentLanguage = this.locale.getCurrentLanguage();
		this.setApproverButtonVisibility();
	}

	setApproverButtonVisibility() {
		const statusesForApprove = [APPLICATION_STATUSES.SUBMITTED_AND_PAID, APPLICATION_STATUSES.SUBMITTED_RETURNED];
		
		if (this.statusId === APPLICATION_STATUSES.APPROVED_IN_PRODUCTION) {
			this.canDeliver = true;
		} else if (statusesForApprove.includes(this.statusId)) {
			this.canApprove = true;
		}
	}


	goToChosenDocument(attachedDocumentTypeId: number) {
		document.getElementById(attachedDocumentTypeId.toString()).scrollIntoView({block: 'center'});
	}

	setAttachedDocumentListVisible(event) {
		event.stopPropagation();
		this.isFlagListVisible = false;
		this.isAttachedDocumentsListVisible = !this.isAttachedDocumentsListVisible;
	}

	setFlagListVisible(event) {
		event.stopPropagation();
		this.isAttachedDocumentsListVisible = false;
		this.isFlagListVisible = !this.isFlagListVisible;
	}

	downloadDocument(event: Event, documentTypeId: number) {
		event.stopPropagation();
		this.isAttachedDocumentsListVisible  = false;
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.documentService
			.getDocument(this.summaryInfo.applicationId, documentTypeId)
			.subscribe(
				(response: HttpResponse<ArrayBuffer>) => {
					this.openFile(response);
				});
	}

	openFile(response: HttpResponse<ArrayBuffer>) {
		const disposition = response.headers.get('content-disposition');
		let filename = '';
		if (disposition && disposition.indexOf('attachment') !== -1) {
			const filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
			const matches = filenameRegex.exec(disposition);
			if (matches != null && matches[1]) {
				filename = matches[1].replace(/['"]/g, '');
			}
		}
		filename = decodeURIComponent(filename).replace(/\+/g, ' ');
		const blob = new Blob([response.body], { type: 'application/multipart-file' });
		saveAs(blob, filename);
		this.isLoading = false;
	}

	showApproverOptions(event) {
		event.stopPropagation();
		this.showOptions = !this.showOptions;
	}

	approveApplication(event: Event) {
		event.stopPropagation();
		this.showOptions = false;
		const isCurrentStatusApproved = (this.application.statusId === APPLICATION_STATUSES.APPROVED_IN_PRODUCTION) ? true : false;
		if (this.isLoading || isCurrentStatusApproved) {
			this.showOptions = false;
			return;
		}

		const applicantIsEFace = (this.application.summary.authMethod.id === AUTH_METHODS.E_FACE);
		if (applicantIsEFace && !this.approverHasGeneratedApplication) {
			PopUpService.showPopUp({
				header: POP_UP_MESSAGES_KEYS.generate_application,
				type: PopUpTypes.ERROR
			});
			return;
		}

		this.isLoading = true;
		this.applicationService
			.approveApplication(this.summaryInfo.applicationId)
			.subscribe(
				(dto) => {
					this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]); 
				},
				(errorResponse) => {
					if (errorResponse.error) {
						if (errorResponse.error.error === 'CardCreationRequestException' ) {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_can_not_create_card,
								type: PopUpTypes.ERROR
							});
						} else if (errorResponse.error.error === 'ProxyException') {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_service_not_work,
								text: POP_UP_MESSAGES_KEYS.try_again_later,
								type: PopUpTypes.ERROR
							});
						} else if (errorResponse.error.error === 'MissingPaymentException') {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_can_not_create_card,
								text: POP_UP_MESSAGES_KEYS.error_missing_payment,
								type: PopUpTypes.ERROR
							});
						}
				}}
			).add( () => this.isLoading = false);
	}

	rejectApplication(event: Event) {
		event.stopPropagation();
		const isCurrentStatusRejected = (this.application.statusId === APPLICATION_STATUSES.SUBMITTED_REJECTED_IRREGULARITIES) ? true : false;
		if (this.isLoading || isCurrentStatusRejected) {
			this.showOptions = false;
			return;
		}
		this.isLoading = true;
		this.applicationService
			.rejectApplication(this.summaryInfo.applicationId)
			.subscribe(() => { this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]); })
			.add( () => this.isLoading = false);
	}

	returnApplication(event: Event) {
		event.stopPropagation();
		const isCurrentStatusReturned = (this.application.statusId === APPLICATION_STATUSES.SUBMITTED_RETURNED) ? true : false;
		if (this.isLoading || isCurrentStatusReturned) {
			this.showOptions = false;
			return;
		}
		this.isLoading = true;
		this.applicationService
			.returnApplication(this.summaryInfo.applicationId)
			.subscribe(() => { this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]); })
			.add( () => this.isLoading = false);
	}

	deliveredPersonally(event: Event) {
		event.stopPropagation();
		const isCurrentStatusDeliveredClient = (this.application.statusId === APPLICATION_STATUSES.DELIVERED_CLIENT) ? true : false;
		if (this.isLoading || isCurrentStatusDeliveredClient) {
			this.showOptions = false;
			return;
		}
		this.isLoading = true;
		this.applicationService
			.deliveredPersonallyCardApplication(this.summaryInfo.applicationId)
			.subscribe(() => { this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]); })
			.add( () => this.isLoading = false);
	}

	addRemarks(event) {
		event.stopPropagation();
		if (this.isLoading) {
			return;
		}

		PopUpService.showPopUp(DEFAULT_POP_UPS.info_approver_message);
		const currentSubscription = PopUpService.subscribeToPopUpInput(
			// tslint:disable-next-line: no-shadowed-variable
			(messageFromInput: string) => {
				if (!messageFromInput) {
					return;
				} else {
					this.isLoading = true;
					const  remarkDto = new RemarkDto();
					remarkDto.message = messageFromInput;

					this.applicationService
						.addRemark(this.summaryInfo.applicationId, remarkDto)
						.pipe(map(
							(data: ApplicationRemarkViewDto[]) => data.map(
								(itemDto: ApplicationRemarkViewDto) => new Remark(itemDto)
							)
						))
						.subscribe((data: Remark[]) => {
							this.emitRemarks.emit(data);
						}
						)
						.add( () => this.isLoading = false);
				}
				currentSubscription.unsubscribe();
			}
		);
	}

	ngOnDestroy(): void {
		this.languageChangeSubscription.unsubscribe();
	}

}
