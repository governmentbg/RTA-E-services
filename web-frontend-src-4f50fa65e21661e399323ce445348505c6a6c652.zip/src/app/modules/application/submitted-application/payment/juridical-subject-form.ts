import { FormGroup, Validators } from "@angular/forms";
import { JuridicalSubjectDto } from "src/app/shared/dtos/juridical-subject-dto";
import { AbstractForm } from "src/app/shared/models/abstract-form";

export class JuridicalSubjectForm extends AbstractForm<JuridicalSubjectDto> {

	constructor() {
		super();
		this.formGroup = this.createFormGroup();
	}

	get name() {
		return this.formGroup.get('name');
	}

	get address() {
		return this.formGroup.get('address');
	}

	get eik() {
		return this.formGroup.get('eik');
	}

	get vatNumber() {
		return this.formGroup.get('vatNumber');
	}

	private createFormGroup(): FormGroup {
		return this.formBuilder.group({
			name: ['', [
				Validators.required, Validators.min(1)
			]],
			address: [null, [
				Validators.required, Validators.minLength(5)
			]],
			eik: [null, [
				Validators.required, Validators.minLength(5), Validators.pattern('^[0-9]*$')
			]],
			vatNumber: ['', [
				Validators.required, Validators.min(5)
			]]
		});
	}

	
	public toRequestDto(params?: object): JuridicalSubjectDto {
		return {
			name: this.name.value,
			address: this.address.value,
			eik: this.eik.value,
			vatNumber: this.vatNumber.value
		};
	}
	
}