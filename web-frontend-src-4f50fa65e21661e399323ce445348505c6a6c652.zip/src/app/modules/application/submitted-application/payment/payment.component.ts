import { PaymentComponentAction as PaymentComponentActions } from '../../../../shared/enums/payment-component-actions';
import { HttpResponse } from '@angular/common/http';
import { Input } from '@angular/core';
import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Language } from 'angular-l10n';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { FileService } from 'src/app/core/services/file.service';
import { PaymentService } from 'src/app/core/services/payment.service';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { PaymentDto } from 'src/app/shared/dtos/payment-dto';
import { APPLICATION_TYPE } from 'src/app/shared/enums/application-types';
import { AttachDocumentTypes, ATTACHED_DOCUMENT_TYPE } from 'src/app/shared/enums/attached-document-types';
import { PaymentMethods, PAYMENT_METHODS } from 'src/app/shared/enums/payment-methods';
import { PaymentTypes, PAYMENT_TYPES } from 'src/app/shared/enums/payment-types';
import { saveAs } from 'file-saver';
import { PaymentTaxesViewDto } from 'src/app/shared/interfaces/payment-taxes-view-dto';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { PaymentInfo } from 'src/app/shared/models/payment-info';
import { PaymentTaxesView } from 'src/app/shared/models/payment-taxes-view';
import { JuridicalSubjectForm } from './juridical-subject-form';
import * as printJS from 'print-js';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { Router } from '@angular/router';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';

@Component({
	selector: 'app-payment',
	templateUrl: './payment.component.html'
})
export class PaymentComponent implements OnInit, AfterViewInit {
	@ViewChild('paymentHtmlElement') htmlElement: { nativeElement: HTMLElement; };
	@Input() public number: number;
	@Input() applicationId: number;
	@Input() applicationTypeId: number;
	@Input() applicationTypeKey: string;
	@Input() paymentInfo: PaymentInfo;
	@Input() issuingReasonKey: string;
	@Language() language: string;
	totalTaxes: string;
	isWaitingProcessingFee: boolean;
	isPaidProcessingFee: boolean;
	isWaitingPersonalizationFee: boolean;
	isPaidPersonalizationFee: boolean;
	isLoading: boolean;
	filename: string;
	srcFromArrayBuffer: ArrayBuffer;
	showViewer: boolean;
	attachedDocumentTypeId: number;
	attachedDocumentTypeEnum: AttachDocumentTypes = ATTACHED_DOCUMENT_TYPE;
	paymentTypeEnum: PaymentTypes = PAYMENT_TYPES;
	paymentMethodEnum: PaymentMethods = PAYMENT_METHODS;
	paymentComponentActions = PaymentComponentActions;
	taxes: PaymentTaxesView;
	isAdrCardApplication: boolean;
	showLoading = false;
	currentPaymentType: number;
	juridicalSubjectForm: JuridicalSubjectForm;
	isPhysicalSubject = true;
	paymentCreatedSuscessfully = false;

	private isApplicant: boolean;

	public get isCloseButtonVisible(): boolean {
		if (this.taxes && this.taxes.processingFee && this.taxes.personalizationFee 
			&& ((this.isWaitingProcessingFee && this.isWaitingPersonalizationFee) 
				|| (this.isPaidProcessingFee && this.isPaidPersonalizationFee)
				|| (this.isWaitingProcessingFee && this.isPaidPersonalizationFee)
				|| (this.isPaidProcessingFee && this.isWaitingPersonalizationFee)
				)) {
			return true;
		} else if (this.taxes && this.taxes.processingFee && !this.taxes.personalizationFee 
				&& (this.isWaitingProcessingFee || this.isPaidProcessingFee)
			) {
			return true;
		} else if (this.taxes && !this.taxes.processingFee && this.taxes.personalizationFee 
			&& (this.isWaitingPersonalizationFee || this.isPaidPersonalizationFee)) {
			return true;
		}
		return false;
	}

	constructor(
		private appStepsElementService: ApplicationStepsElementsService,
		private readonly paymentService: PaymentService,
		private readonly fileService: FileService,
		private authService: AuthenticationService,
		private router: Router,
	) { }

	ngOnInit() {
		this.juridicalSubjectForm = new JuridicalSubjectForm();
		this.isAdrCardApplication = this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_CARD ? true : false;

		this.getTaxesForApplication();
		this.isPaidProcessingFee = this.paymentInfo.isPaidProcessingFee;
		this.isWaitingProcessingFee = this.paymentInfo.isWaitingProcessingFee;
		this.isPaidPersonalizationFee = this.paymentInfo.isPaidPersonalizationFee;
		this.isWaitingPersonalizationFee = this.paymentInfo.isWaitingPersonalizationFee;
		// TODO: remove next 2 lines when other payment methods are implemented;
		this.paymentInfo.processingFeeMethodId = PAYMENT_METHODS.BANK;
		this.paymentInfo.personalizationFeeMethodId = PAYMENT_METHODS.BANK;

		this.authService.getAuthenticatedUserSubject().subscribe((user) => {
			if (user) {
				this.isApplicant = user.isApplicant();
			}
		}
		);
	}

	ngAfterViewInit(): void {
		setTimeout(() => {
			this.appStepsElementService.paymentEl = this.htmlElement.nativeElement;
			// this.appStepsElementService.scrollToStep(Steps.PAYMENT);
		})
	}

	getTaxesForApplication(): void {
		this.paymentService.getApplicationTaxes(this.applicationId)
			.subscribe(
				(response: PaymentTaxesViewDto) => {
					this.taxes = new PaymentTaxesView(response);
					this.totalTaxes = (
							(!this.isAdrCardApplication && this.taxes.processingFee ? this.taxes.processingFee : 0) 
								+ (this.taxes.personalizationFee ? this.taxes.personalizationFee : 0)
						).toFixed(2);
				},
				(error) => {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_can_not_get_application_taxes_try_later);
				});
	}

	createPayment(amount: number, paymentTypeId: number, paymentMethodId: number) {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.showLoading = true;
		this.currentPaymentType = paymentTypeId;

		const dto = new PaymentDto();
		dto.amount = amount;
		dto.paymentTypeId = paymentTypeId;
		dto.paymentMethodId = paymentMethodId;
		if (!this.isPhysicalSubject) {
			dto.juridicalSubject = this.juridicalSubjectForm.toRequestDto();
		}

		this.paymentService
			.createPaymentForApplication(this.applicationId, dto)
			.subscribe(
				(response) => {
					if (paymentTypeId === PAYMENT_TYPES.PROCESSING_FEE) {
						this.isWaitingProcessingFee = true;
					} else if (paymentTypeId === PAYMENT_TYPES.PERSONALIZATION_FEE) {
						this.isWaitingPersonalizationFee = true;
					}
					this.paymentCreatedSuscessfully = true;
				},
				(error) => {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_can_not_create_payment_try_later);
				}).add(() => { this.isLoading = false; this.showLoading = false; });
	}

	getGeneratedPaymentOrderForCurrentFee(paymentType: number, paymentComponentAction: PaymentComponentActions) {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.paymentService
			.getGeneratedPaymentOrderForApplication(this.applicationId, paymentType)
			.subscribe(
				(response: HttpResponse<ArrayBuffer>) => {
					this.filename = this.fileService.getFilenameFromResponse(response);
					this.srcFromArrayBuffer = response.body;
					if (paymentType === PAYMENT_TYPES.PROCESSING_FEE) {
						this.attachedDocumentTypeId = ATTACHED_DOCUMENT_TYPE.PAYMENT_ORDER_PROCESSING_FEE;
					} else if (paymentType === PAYMENT_TYPES.PERSONALIZATION_FEE) {
						this.attachedDocumentTypeId = ATTACHED_DOCUMENT_TYPE.PAYMENT_ORDER_PERSONALIZATION_FEE;
					}
					switch (paymentComponentAction) {
						case PaymentComponentActions.OPEN_VIEWER: {
							this.showViewer = true;
							break;
						}
						case PaymentComponentActions.DOWNLOAD: {
							const blob = new Blob([this.srcFromArrayBuffer], { type: 'application/multipart-file' });
							saveAs(blob, this.filename);
							break;
						}
						case PaymentComponentActions.PRINT: {
							const blob = new Blob([this.srcFromArrayBuffer], { type: 'application/pdf' });
							const url = window.URL.createObjectURL(blob);
							printJS({
								printable: url,
								type: 'pdf',
								onLoadingStart: () => { this.isLoading = true },
								onLoadingEnd: () => { this.isLoading = false }
							})
							break;
						}
					}
				},
				(error) => {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_can_not_generate_payment_order_try_later);
				}).add(() => this.isLoading = false);
	}

	hideViewer() {
		this.showViewer = false;
	}

	setPersonalizationPaymentMethod(paymentMethodId: number) {
		this.paymentInfo.personalizationFeeMethodId = paymentMethodId;
	}

	toggleIsPhysicalSubject() {
		this.isPhysicalSubject = !this.isPhysicalSubject;
	}

	goToDashboardNoPopup(): void {
		if (!this.isApplicant) {
			this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]);
		} else {
			this.router.navigate([RouteUrl.DASHBOARD]);
		}
	}
}
