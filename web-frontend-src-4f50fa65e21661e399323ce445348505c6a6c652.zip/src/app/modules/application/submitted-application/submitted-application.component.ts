import { Component, OnInit, OnDestroy} from '@angular/core';
import { ApplicationService } from 'src/app/core/services/application.service';
import { Subscription } from 'rxjs/internal/Subscription';
import { ActivatedRoute, Router } from '@angular/router';
import { SubHeaderApplicationInfo } from 'src/app/shared/models/sub-header-application-info';
import { ApplicationDto } from 'src/app/shared/interfaces/application-dto';
import { Application } from 'src/app/shared/models/application';
import { APPLICATION_STATUSES } from 'src/app/shared/enums/application-statuses';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { User } from 'src/app/shared/models/user';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { DrivingLicenceView } from 'src/app/shared/models/driving-licence-view';
import { Names } from 'src/app/shared/models/names';
import { AdrModule } from 'src/app/shared/models/adr-module';
import { Certificate } from 'src/app/shared/models/certificate';
import { ContactView } from 'src/app/shared/models/contact-view';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { PaymentInfo } from 'src/app/shared/models/payment-info';
import { APPLICATION_TYPE } from 'src/app/shared/enums/application-types';
import { PersonalInfo } from 'src/app/shared/models/personal-info';
import { DeliveryInfo } from 'src/app/shared/models/delivery-info';
import { CardView } from 'src/app/shared/models/card-renewal-view';
import { Remark } from 'src/app/shared/models/remark';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { TranslationDto } from 'src/app/shared/interfaces/translation-dto';
import { Translation } from 'src/app/shared/models/translation';
import { Steps } from 'src/app/shared/enums/steps';
import { TaxiExamInfo } from 'src/app/shared/models/exam/taxi-exam-info';

@Component({
	selector: 'app-submitted-application',
	templateUrl: './submitted-application.component.html'
})
export class SubmittedApplicationComponent implements OnInit, OnDestroy {
	private routeSubscription: Subscription;
	public isDraft = false;
	public user: User;
	public isApplicant: boolean;

	public submittedApplication: Application;
	public applicationId: number;
	public statusId: number;
	public applicationTypeId: number;
	public applicationTypeShortKey: string;
	public personalNumber: string;
	public isEuCitizen: boolean;
	public hasMvrCheck: boolean;
	public hasDlMvrCheck: boolean;
	public hasAutoFixedPicturesFromMvr: boolean;
	public personalInfo: PersonalInfo = null;
	public contactView: ContactView;
	public drivingLicence: DrivingLicenceView = null;
	public cardView: CardView = null;
	public deliveryInfo: DeliveryInfo = null;
	public names: Names = null;
	public dqcCertificates: Certificate[] = null;
	public adrModules: AdrModule[] = null;
	public paymentInfo: PaymentInfo = null;

	public taxiExamInfo: TaxiExamInfo;
	
	public Steps = Steps;
	public APPLICATION_TYPE = APPLICATION_TYPE;
	public bulgariaCountry: Translation;

	public approverHasGeneratedApplication = false;

	constructor(
		private readonly router: Router,
		private readonly route: ActivatedRoute,
		private readonly authenticationService: AuthenticationService,
		private readonly applicationService: ApplicationService,
		private readonly nomenclatureService: NomenclatureService,
		public appStepsElementService: ApplicationStepsElementsService,
	) { }

	ngOnInit(): void {
		this.user = this.authenticationService.getAuthenticatedUser();
		this.isApplicant = this.user.isApplicant();
		this.routeSubscription = this.route.params.subscribe(params => {
			this.applicationId = params.id;
		});
		this.getBulgariaCountryTranslation();
		if (+this.applicationId) {
			this.applicationService
			.getApplication(this.applicationId)
			.subscribe(
				(dto: ApplicationDto) => {
					this.submittedApplication = new Application(dto);
					const canCancel = this.applicationService.canCancelApplication(this.submittedApplication.statusId);
					this.applicationService.setApplicationInfoForHeader(new SubHeaderApplicationInfo(this.applicationId, 100 , canCancel));
					this.setPropertiesForSubmittedApplication();
					this.appStepsElementService.calculateOneStepSize(this.applicationTypeId);
					this.appStepsElementService.setStepsNumbers();
					this.appStepsElementService.setDefaultPassedStepsForSubmittedApplication();
					// this.appStepsElementService.scrollToStep(Steps.PERSONAL_INFO); не работи
				},
				(error) => {
					if (this.user.isApplicant()) {
						this.router.navigate([RouteUrl.DASHBOARD]);
					} else {
						this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]);
					}
			});
		} else {
			PopUpService.showPopUp(DEFAULT_POP_UPS.error_not_found);
		}
	}

	canCancelApplication(statusId: number) {
		return (statusId === APPLICATION_STATUSES.DRAFT || statusId === APPLICATION_STATUSES.SUBMITTED_WAITING_PAYMENT);
	}

	setRemarks(remarks: Remark[]) {
		this.submittedApplication.summary.shortApplication.remarks = remarks;
	}

	getBulgariaCountryTranslation() {
		this.nomenclatureService.getCountryByName(S_VARIABLES.BULGARIA_LATIN).subscribe(
			(countryDto: TranslationDto) => {
				this.bulgariaCountry = new Translation(countryDto);
			},
			(error) => {
				if (this.user.isApplicant()) {
					this.router.navigate([RouteUrl.DASHBOARD]);
				} else {
					this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]);
				}
			}
		);
	}

	setPropertiesForSubmittedApplication() {
		this.statusId = this.submittedApplication.statusId;
		this.applicationTypeId = this.submittedApplication.applicationTypeId;
		this.applicationTypeShortKey = this.submittedApplication.applicationTypeShortKey;
		this.names = this.submittedApplication.names;
		this.isEuCitizen = this.submittedApplication.isEuCitizen;
		this.hasMvrCheck = this.submittedApplication.hasMvrCheck;
		this.hasAutoFixedPicturesFromMvr = this.submittedApplication.hasAutoFixedPicturesFromMvr;
		this.personalNumber = this.submittedApplication.identityNumber;
		this.personalInfo = this.submittedApplication.personalInfo;
		this.contactView = this.submittedApplication.contactView;
		this.hasDlMvrCheck = this.submittedApplication.hasDlMvrCheck;
		this.drivingLicence = this.submittedApplication.drivingLicence;
		this.dqcCertificates = this.submittedApplication.dqcCertificates;
		this.adrModules = this.submittedApplication.adrModules;
		this.cardView = this.submittedApplication.cardView;
		this.deliveryInfo = this.submittedApplication.deliveryInfo;
		this.paymentInfo = this.submittedApplication.payment;

		this.taxiExamInfo = this.submittedApplication.taxiExamInfo;
	}

	approverGeneratedApplication() {
		this.approverHasGeneratedApplication = true;
	}


	ngOnDestroy(): void {
		this.routeSubscription.unsubscribe();
	}
}
