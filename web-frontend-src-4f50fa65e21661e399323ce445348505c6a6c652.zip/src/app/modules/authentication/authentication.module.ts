import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthenticationComponent } from './authentication.component';
import { AuthenticationRoutingModule } from './authentication-routing.module';
import { LoginComponent } from './login/login.component';
import { TranslationModule } from 'angular-l10n';

@NgModule({
	declarations: [AuthenticationComponent, LoginComponent],
	imports: [
		CommonModule,
		AuthenticationRoutingModule,
		TranslationModule
	]
})
export class AuthenticationModule { }
