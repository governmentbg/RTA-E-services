import { Component, EventEmitter, Output, OnInit } from '@angular/core';
import { APPLICATION_TYPE, ApplicationTypes } from '../../../shared/enums/application-types';

@Component({
	selector: 'app-choosing-new-application-type',
	templateUrl: './choosing-new-application-type.component.html'
})
export class ChoosingNewApplicationTypeComponent implements OnInit {
	public applicationTypes: ApplicationTypes;
	@Output() applicationCreate: EventEmitter<number> = new EventEmitter<number>();

	ngOnInit(): void {
		this.applicationTypes = APPLICATION_TYPE;
	}

	public createApplication(type: number) {
		// TODO : remove / change when implement not card app
		if (type !== APPLICATION_TYPE.APPLICATION_ADR_CARD
			&& type !== APPLICATION_TYPE.APPLICATION_DQC
			&& type !== APPLICATION_TYPE.APPLICATION_TACHO_CARD
			&& type !== APPLICATION_TYPE.APPLICATION_ADR_EXAM
			&& type !== APPLICATION_TYPE.APPLICATION_CONSULTANT_EXAM
			&& type !== APPLICATION_TYPE.APPLICATION_MOTOR_EXAM
			&& type !== APPLICATION_TYPE.APPLICATION_TAXI_EXAM) {
					return;
		}
		this.applicationCreate.emit(type);
	}
}

