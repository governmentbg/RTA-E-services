import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { EmailService } from 'src/app/core/services/email.service';
import { FormsModule } from '@angular/forms';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { EmailWrapperDto } from 'src/app/shared/dtos/email-wrapper-dto';
import { VerificationTokenWrapperDto } from 'src/app/shared/dtos/verification-token-wrapper-dto';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';

@Component({
	selector: 'app-confirm-email',
	templateUrl: './confirm-email.component.html'
})
export class ConfirmEmailComponent implements OnInit {
	@Output() emailVerificationChange = new EventEmitter<boolean>();

	isEmailSent = false;
	emailInput: string;

	constructor(
		private emailService: EmailService
	) { }

	ngOnInit(): void {
	}

	public sendVerificationToken() {
		this.emailService.sendVerificationToken(new EmailWrapperDto(this.emailInput))
		.subscribe(() => {
				this.isEmailSent = true;
				PopUpService.showPopUp({
					text: POP_UP_MESSAGES_KEYS.success_email_sent,
					type: PopUpTypes.SUCCESS
				})
			}, (errorResponse) => {
				this.isEmailSent = false;
				if (errorResponse.error.error = "EmailAlreadySentException") {
					PopUpService.showPopUp({
						text: POP_UP_MESSAGES_KEYS.email_already_sent,
						type: PopUpTypes.WARNING
					})
				}
			});
	}

	public changeEmail() {
		this.isEmailSent = false;
		this.emailInput = "";
	}

	public enterVerificationToken(token: string) {
		this.emailService.enterVerificationToken(new VerificationTokenWrapperDto(token))
			.subscribe(() => this.emailVerificationChange.emit(true));
	}
}
