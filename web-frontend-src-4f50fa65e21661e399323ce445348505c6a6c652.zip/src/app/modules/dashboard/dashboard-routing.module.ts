import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { Roles } from 'src/app/shared/enums/roles';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
// tslint:disable-next-line: max-line-length
import { ApplicationSummaryComponent } from 'src/app/shared/components/application-summary/application-summary.component';

const routes: Routes = [
	{
		path: '',
		component: DashboardComponent,
		canActivateChild: [AuthGuard],
		data: {
			expectedRoles: [
				Roles.ROLE_ADMIN_DEMAX,
				Roles.ROLE_APPLICANT_E_FACE,
				Roles.ROLE_APPLICANT_E_SIGN
			]
		},
		children: [
			{
				path: '',
				component: ApplicationSummaryComponent
			}
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class DashboardRoutingModule { }
