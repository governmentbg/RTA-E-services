import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplicationService } from '../../core/services/application.service';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';
import { map } from 'rxjs/operators';
import { ApplicationShort } from 'src/app/shared/models/application-short';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { User } from 'src/app/shared/models/user';
import { APPLICATION_STATUSES } from 'src/app/shared/enums/application-statuses';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { ApplicationShortDto } from 'src/app/shared/interfaces/application-short-dto';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';

@Component({
	selector: 'app-dashboard',
	templateUrl: './dashboard.component.html'
})
export class DashboardComponent implements OnInit {
	public shortApplicationInfoList: ApplicationShort[] = [];
	public user: User;
	public isEmailVerified = true;
	isLoading: boolean;
	canShowComponent = true;

	constructor(
		private readonly applicationService: ApplicationService,
		private readonly authenticationService: AuthenticationService,
		private readonly router: Router
	) {}

	ngOnInit(): void {
		this.user = this.authenticationService.getAuthenticatedUser();
		if (this.user.isApplicant() && !this.user.isVerified) {
			this.isEmailVerified = false;
		}
		if (localStorage.getItem(S_VARIABLES.CHOSEN_NEW_APPLICATION_TYPE_FROM_WEB_LINK)) {
			this.relocateToNewApplicationBasedOnWebLink();
		}
		this.getApplicationsShortInfo();
	}

	relocateToNewApplicationBasedOnWebLink() {
		const appTypeFromWebLink =
			JSON.parse(localStorage.getItem(S_VARIABLES.CHOSEN_NEW_APPLICATION_TYPE_FROM_WEB_LINK));
		localStorage.removeItem(S_VARIABLES.CHOSEN_NEW_APPLICATION_TYPE_FROM_WEB_LINK);
		const loginPageLoadedTime = new Date(appTypeFromWebLink.time);
		const time1MinAfterLoadingLoginPage = loginPageLoadedTime;
		time1MinAfterLoadingLoginPage.setMinutes(loginPageLoadedTime.getMinutes() + 1);
		const now = new Date();
		if (time1MinAfterLoadingLoginPage > now ) {
			this.canShowComponent = false;
			this.createApplication(appTypeFromWebLink.applicationTypeId);
		}
	}

	public createApplication(applicationType: number) {
		this.applicationService
			.checkIfApplicationOfSameTypeAlreadyInProgress(applicationType)
			.subscribe((existingApplication: boolean) => {
				if (existingApplication) {
					this.canShowComponent = true;
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_application_of_type_already_exists);
					return;
				} else {
					this.router.navigate([ RouteUrl.APPLICATION, RouteUrl.NEW, applicationType]);
				}
			});
	}

	public openApplication(ids: number[]) {
		const [applicationId, statusId] = ids;
		if (statusId === APPLICATION_STATUSES.DRAFT) {
			this.router.navigate([RouteUrl.APPLICATION, RouteUrl.DRAFT, applicationId]);
		} else {
			this.router.navigate([RouteUrl.APPLICATION, applicationId]);
		}
	}

	cancelApplication(application: ApplicationShort) {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		PopUpService.showPopUp(DEFAULT_POP_UPS.warning_application_will_be_canceled);
		const currentSubscription = PopUpService.subscribeToPopUpResponse(
			(hasConfirmed: boolean) => {
				if (hasConfirmed) {
					this.applicationService
						.cancelApplication(application.applicationId)
						.subscribe(
							(success) => {
								this.removeApplicationFromListOrChangeStatus(application);
							},
							(error) => {
								this.isLoading = false;
								PopUpService.showPopUp(DEFAULT_POP_UPS.error_can_not_cancel_application_now);
							}
						);
				} else {
					this.isLoading = false;
				}
				currentSubscription.unsubscribe();
			}
		);
	}

	public changeEmailVerificationStatus(verificationStatus: boolean) {
		this.isEmailVerified = verificationStatus;
	}

	removeApplicationFromListOrChangeStatus(application: ApplicationShort) {
		if (application.applicationStatus.generalStatus.id ===  APPLICATION_STATUSES.DRAFT) {
			const index = this.shortApplicationInfoList.indexOf(application);
			this.shortApplicationInfoList.splice(index, 1);
			this.isLoading = false;
		} else {
			this.getApplicationsShortInfo();
		}
	}

	getApplicationsShortInfo() {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.applicationService
			.getApplicationsShort()
			.pipe(map(
					(data: ApplicationShortDto[]) => data.map(
						(itemDto: ApplicationShortDto) => new ApplicationShort(itemDto)
					)
			))
			.subscribe((data: ApplicationShort[]) => {
				this.shortApplicationInfoList = data;
				this.isLoading = false;
			});
	}
}
