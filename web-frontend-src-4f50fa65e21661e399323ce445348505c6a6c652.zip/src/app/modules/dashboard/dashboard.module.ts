import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CoreModule } from '../../core/core.module';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { TranslationModule } from 'angular-l10n';
import { FormsModule } from '@angular/forms';

import { DashboardComponent } from './dashboard.component';
import { ChoosingNewApplicationTypeComponent } from './choosing-new-application-type/choosing-new-application-type.component';
import { ConfirmEmailComponent } from './confirm-email/confirm-email.component';
import { SharedModule } from 'src/app/shared/shared.module';
@NgModule({
	declarations: [
	DashboardComponent,
	ChoosingNewApplicationTypeComponent,
	ConfirmEmailComponent
	],
	imports: [CommonModule,
				DashboardRoutingModule,
				CoreModule,
				TranslationModule,
				SharedModule,
				FormsModule]
})
export class DashboardModule {}
