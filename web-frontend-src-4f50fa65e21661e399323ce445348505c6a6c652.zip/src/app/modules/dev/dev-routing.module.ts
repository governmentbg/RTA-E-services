import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TranslationKeyValueComponent } from './translation-key-value/translation-key-value.component';
import { RouteUrl } from 'src/app/shared/enums/route-url.enum';

const routes: Routes = [

	{
		path: '',
		pathMatch: 'full',
		redirectTo: RouteUrl.TRANSLATION_KEY_VALUE
	},
	{
		path: RouteUrl.TRANSLATION_KEY_VALUE,
		component: TranslationKeyValueComponent
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class DevRoutingModule { }
