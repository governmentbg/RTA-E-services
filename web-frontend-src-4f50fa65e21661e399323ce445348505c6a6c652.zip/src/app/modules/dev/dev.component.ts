import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-dev',
	templateUrl: './dev.component.html'})
export class DevComponent implements OnInit {

	constructor() { }

	ngOnInit(): void {
	}

}
