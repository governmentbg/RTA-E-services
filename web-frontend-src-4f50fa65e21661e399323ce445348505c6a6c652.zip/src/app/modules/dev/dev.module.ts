import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslationKeyValueComponent } from './translation-key-value/translation-key-value.component';
import { DevRoutingModule } from './dev-routing.module';
import { RouterModule } from '@angular/router';
import { DevComponent } from './dev.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';



@NgModule({
	declarations: [
		DevComponent,
		TranslationKeyValueComponent
	],
	imports: [
		RouterModule,
		DevRoutingModule,
		CommonModule,
		ReactiveFormsModule,
		FormsModule,
		SharedModule
	]
})
export class DevModule { }
