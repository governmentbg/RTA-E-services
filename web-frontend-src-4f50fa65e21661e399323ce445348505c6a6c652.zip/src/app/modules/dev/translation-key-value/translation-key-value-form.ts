import { Validators } from '@angular/forms';
import { AbstractForm } from 'src/app/shared/models/abstract-form';
import { TranslationKeyValues } from 'src/app/shared/models/translation-key-values';
import { TranslationRequestDto } from 'src/app/shared/dtos/translation-request-dto';

export class TranslationKeyValueForm extends AbstractForm<TranslationRequestDto> {

	constructor(translation: TranslationKeyValues) {
		super();
		this.formGroup = this.createFormGroup(translation);
	}

	get translationKey() {
		return this.formGroup.get('translationKey');
	}

	get translationValueEn() {
		return this.formGroup.get('translationValueEn');
	}

	get translationValueBg() {
		return this.formGroup.get('translationValueBg');
	}

	private createFormGroup(translation: TranslationKeyValues) {
		if (!translation) {
			return this.formBuilder.group({
				translationKey: ['', [
					Validators.required
				]],
				translationValueEn: ['', [
					Validators.required
				]],
				translationValueBg: ['', [
					Validators.required
				]]
			});
		}
		return this.formBuilder.group({
			translationKey: [translation.translationKey, [
				Validators.required
			]],
			translationValueEn: [translation.enTranslation, [
				Validators.required
			]],
			translationValueBg: [translation.bgTranslation, [
				Validators.required
			]]
		});
	}

	public toRequestDto(): TranslationRequestDto {
		const requestDto = new TranslationRequestDto();
		requestDto.translationKey = this.translationKey.value;
		requestDto.bgTranslationValue = this.translationValueBg.value;
		requestDto.enTranslationValue = this.translationValueEn.value;
		return requestDto;
	}
}
