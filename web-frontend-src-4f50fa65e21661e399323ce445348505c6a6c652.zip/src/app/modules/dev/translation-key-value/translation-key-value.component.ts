import { Component, OnInit, OnDestroy } from '@angular/core';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { PageResultDto } from 'src/app/shared/interfaces/page-result-dto';
import { Pagination } from 'src/app/shared/pagination/pagination';
import { PaginationParams } from 'src/app/shared/pagination/pagination-params';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { Subscription } from 'rxjs';
import { TranslationFilters } from 'src/app/shared/models/translation-filters';
import { TranslationKeyValueForm } from './translation-key-value-form';
import { TranslationKeyValuesDto } from 'src/app/shared/interfaces/translation-key-values-dto';
import { TranslationKeyValuesService } from 'src/app/core/services/translation-key-values.service';
import { map } from 'rxjs/operators';

@Component({
	selector: 'app-translation-key-value',
	templateUrl: './translation-key-value.component.html',
})
export class TranslationKeyValueComponent implements OnInit, OnDestroy {

	public pagination: Pagination;
	public filters: TranslationFilters;

	public translationKeyValuesForms: TranslationKeyValueForm [] = [];
	public newTranslationForm: TranslationKeyValueForm;
	public totalCount: number;
	public currentPage = 1;
	public isAddingNew = false;
	public subscriptions: Subscription [] = [];
	public searchInput: string;
	public searchInputOption: string;

	constructor(
		private translationKeyValueService: TranslationKeyValuesService
	) { }

	ngOnInit(): void {
		const paginationParams = new PaginationParams();
		paginationParams.orderBy = 'id.translationKey';
		paginationParams.direction = 'asc';
		this.pagination = new Pagination(paginationParams);
		this.filters = new TranslationFilters();

		this.subscriptions.push(this.pagination.subscribeToParamsChanges(() => {
			this.filters.resetToCurrentlyFiltered();
			this.loadPaginatedTranslations();
		}));
		this.clearNewTranslationForm();
	}

	public loadPaginatedTranslations() {
		const paginationParams = this.pagination.getPaginationParams();
		this.translationKeyValueService.getTranslationsPage(paginationParams, this.filters)
		.pipe(
			map(({totalCount, items}: PageResultDto<TranslationKeyValuesDto>) => ({
				totalCount,
				items: items.map((itemDto: TranslationKeyValuesDto) => new TranslationKeyValueForm(itemDto))
			}))
		)
		.subscribe(
			({totalCount, items}: PageResultDto<TranslationKeyValueForm>) => {
			this.translationKeyValuesForms = items;
			this.pagination.setTotalCount(totalCount);
			this.filters.resetToCurrentlyFiltered();
		},
		(error) => {
			this.filters.resetToCurrentlyFiltered();
		});
	}

	public search() {
		this.pagination.resetPage();
		this.filters.setLastLoadedTranslations(this.translationKeyValuesForms);
		this.setFilter();
		this.filters.updateFilters();
		this.loadPaginatedTranslations();
	}

	private setFilter() {
		if (this.searchInputOption === 'key') {
			this.filters.selectKey(this.searchInput);
		} else if (this.searchInputOption === 'bg') {
			this.filters.selectBg(this.searchInput);
		} else {
			this.filters.selectEn(this.searchInput);
		}
	}

	public addNewTranslation() {
		this.isAddingNew = true;
	}

	public saveTranslation(translationFrom: TranslationKeyValueForm) {
		if (this.isAddingNew) {
			this.translationKeyValueService.addNewTranslation(translationFrom.toRequestDto())
			.subscribe(
				() => {
					PopUpService.showPopUp(DEFAULT_POP_UPS.success);
					this.pagination.resetPage();
					this.loadPaginatedTranslations();
					this.clearNewTranslationForm();
					this.isAddingNew = false;
				}
			);
		} else {
			this.translationKeyValueService.editTranslation(translationFrom.toRequestDto())
				.subscribe(
					() => {
						this.pagination.resetPage();
						this.loadPaginatedTranslations();
					}
				);
		}
	}

	public deleteTranslation(translationFrom: TranslationKeyValueForm) {
		PopUpService.showPopUp(DEFAULT_POP_UPS.delete);
		const popUpSubscription = PopUpService.subscribeToPopUpResponse(
			(hasConfirmed) => {
				if (hasConfirmed) {
					this.translationKeyValueService.delete(translationFrom.translationKey.value)
						.subscribe(
							() => {
								this.pagination.resetPage();
								this.loadPaginatedTranslations();
							}
						);
				}
				popUpSubscription.unsubscribe();
			}
		);
	}

	public deleteNew() {
		this.isAddingNew = false;
		this.clearNewTranslationForm();
	}

	onKey(input: string) {
		this.searchInput = '' + input;
	}

	selectFilter(filter: string) {
		this.clearInput();
		this.searchInputOption = filter;
	}

	clearInput(): void {
		this.searchInput = null;
		this.filters.keyTranslation = null;
		this.filters.bgTranslation = null;
		this.filters.enTranslation = null;
	}

	private clearNewTranslationForm() {
		// tslint:disable-next-line: prefer-const
		let newForm: TranslationKeyValuesDto;
		this.newTranslationForm = new TranslationKeyValueForm(newForm);
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach((subscription) => subscription.unsubscribe());
	}

}
