
export interface TranslationQueryParams {
	key: string;
	bg: string;
	en: string;
}

