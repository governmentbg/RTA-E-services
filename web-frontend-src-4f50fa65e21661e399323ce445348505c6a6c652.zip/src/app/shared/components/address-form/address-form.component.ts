import { AddressForm } from '../../utils/address-form';
import { City } from '../../models/city';
import { CityDto } from '../../dtos/city-dto';
import { Component, OnInit, Input } from '@angular/core';
import { Municipality } from '../../models/municipality';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { Region } from '../../models/region';
import { RegionDto } from '../../dtos/region-dto';
import { MunicipalityDto } from '../../dtos/municipality-dto';

@Component({
	selector: 'app-address-form',
	templateUrl: './address-form.component.html'
})
export class AddressFormComponent implements OnInit {

	@Input() addressForm: AddressForm;
	@Input() showCountryInput: boolean;

	public regions: Region[] = [];
	public cities: City[] = [];
	public municipalities: Municipality[] = [];

	constructor(
		private nomenclatureService: NomenclatureService
	) { }

	ngOnInit(): void {
		this.nomenclatureService.getAllRegions().subscribe(
			(regions: RegionDto[]) => {
				regions.forEach(regionDto => {
					this.regions.push(new Region(regionDto));
				});
			}
		);
		if (this.addressForm.region.value) {
			this.selectRegion(this.addressForm.region.value);
			this.addressForm.region.valueChanges
				.subscribe((value) => this.selectRegion(value));
		}
	}

	selectRegion(region: RegionDto) {
		const regionCode = region.regionCode;
		this.municipalities = [];
		this.cities = [];
		this.nomenclatureService.getAllMunicipalitiesByRegion(regionCode).subscribe(
			(municipalities: MunicipalityDto[]) => {
				municipalities.forEach(municipalityDto => {
					this.municipalities.push(new Municipality(municipalityDto));
				});
			}
		);
		this.nomenclatureService.getAllCitiesByRegion(regionCode).subscribe(
			(cities: CityDto[]) => {
				cities.forEach(cityDto => {
					this.cities.push(new City(cityDto));
				});
			}
		);
	}
}
