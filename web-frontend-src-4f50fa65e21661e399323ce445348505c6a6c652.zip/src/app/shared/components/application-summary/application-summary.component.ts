import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { Language } from 'angular-l10n';
import { ApplicationShort } from 'src/app/shared/models/application-short';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { User } from '../../models/user';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { APPLICATION_STATUSES } from '../../enums/application-statuses';
import { ApplicationService } from 'src/app/core/services/application.service';
import { PaymentService } from 'src/app/core/services/payment.service';
import { HttpResponse } from '@angular/common/http';
import { FileService } from 'src/app/core/services/file.service';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { DEFAULT_POP_UPS } from '../../models/constants/pop-up-default-messages';

@Component({
	selector: 'app-application-summary',
	templateUrl: './application-summary.component.html'
})
export class ApplicationSummaryComponent implements OnInit {
	public dateFormat = S_VARIABLES.DATE_FORMAT;
	public dateTimeFormat = S_VARIABLES.DATE_TIME_FORMAT;
	public SUBMITTED_EXPECTS_PAYMENT_ID = 2;

	@Input() isSummaryHeader: boolean;
	user: User;
	isApplicant: boolean;
	isViewerOrAdmin: boolean;
	canCancel = false;
	canOpen = false;
	showInstructions = false;
	isLoading: boolean;
	filename: string;
	srcFromArrayBuffer: ArrayBuffer;
	showViewer: boolean;
	@Language() lang: string;
	@Input() shortApplicationInfo: ApplicationShort;
	@Output() getApplication: EventEmitter<number[]> = new EventEmitter<number[]>();
	@Output() emitCancelApplication: EventEmitter<ApplicationShort> = new EventEmitter<ApplicationShort>();

	constructor(
		private readonly authenticationService: AuthenticationService,
		private readonly applicationService: ApplicationService,
		private readonly paymentService: PaymentService,
		private readonly fileService: FileService,
	) { }

	ngOnInit(): void {
		this.user = this.authenticationService.getAuthenticatedUser();
		this.isApplicant = this.user.isApplicant();
		this.isViewerOrAdmin = (this.user.isDemaxAdmin() || this.user.isViewer());
		this.canOpen = this.applicationService.canUserOpenApplication(this.shortApplicationInfo.applicationStatus.generalStatus.id);
		this.canCancel = this.applicationService.canCancelApplication(this.shortApplicationInfo.applicationStatus.generalStatus.id);
		this.showInstructions = (this.shortApplicationInfo.warnings.length > 0 || this.shortApplicationInfo.remarks.length > 0)
			&& (this.shortApplicationInfo.applicationStatus.generalStatus.id !== APPLICATION_STATUSES.CANCELED_BY_APPLICANT
				&& this.shortApplicationInfo.applicationStatus.generalStatus.id !== APPLICATION_STATUSES.REJECTED_NOT_PAID_ON_TIME);
	}

	public openApplication(applicationId: number, statusId: number) {
		const ids = [applicationId, statusId];
		this.getApplication.emit(ids);
	}

	public cancelApplication(application: ApplicationShort) {
		this.emitCancelApplication.emit(application);
	}

	getInvoice() {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.paymentService
			.getGeneratedInvoiceForApplication(this.shortApplicationInfo.applicationId)
			.subscribe(
				(response: HttpResponse<ArrayBuffer>) => {
					this.filename = this.fileService.getFilenameFromResponse(response);
					this.srcFromArrayBuffer = response.body;
					this.showViewer = true;
				},
				(error) => {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_can_not_get_document_try_later);
				}).add(() => this.isLoading = false);
	}

	hideViewer() {
		this.showViewer = false;
	}
}
