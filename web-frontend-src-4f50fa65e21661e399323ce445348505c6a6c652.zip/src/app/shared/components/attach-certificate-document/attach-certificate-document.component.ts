import { Component, OnInit, EventEmitter, Output, Input, OnDestroy, ChangeDetectorRef,  } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { ATTACHED_DOCUMENT_TYPE_ACTION_KEY } from '../../models/constants/attached-documents/attached-document-type-action-keys';
import { ATTACHED_DOCUMENT_TYPE_KEY } from '../../models/constants/attached-documents/attached-document-type-keys';
import { AttachDocumentTypes, ATTACHED_DOCUMENT_TYPE } from '../../enums/attached-document-types';
import { Certificate } from '../../models/certificate';
import { AdrModule } from '../../models/adr-module';
import { CERTIFICATE_TYPE_ID_TO_ATTACHED_DOCUMENT_TYPE_ID } from '../../models/constants/attached-documents/certificate-type-id';
import { DEFAULT_POP_UPS } from '../../models/constants/pop-up-default-messages';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { DocumentService } from 'src/app/core/services/document.service';
import { POP_UP_MESSAGES_KEYS } from '../../models/constants/pop-up-messages-keys';
import { PopUpTypes } from '../../enums/pop-up-types';
import { Subscription } from 'rxjs/internal/Subscription';
import { DocumentsDeclarationDto } from '../../dtos/documents-declaration-dto';
import { DqcCertificateNomenclaturesDto } from '../../interfaces/dqc-certificate-nomenclatures-dto';
import { DqcCertificateNomenclatures } from '../../models/dqc-certificate-nomenclatures';
import { RequiredDocumentType } from '../../models/required-document-type';
import { Translation } from '../../models/translation';
import { TranslationDto } from '../../interfaces/translation-dto';

@Component({
	selector: 'app-attach-certificate-document',
	templateUrl: './attach-certificate-document.component.html',
})
export class AttachCertificateDocumentComponent implements OnInit, OnDestroy {
	@Input() isDraft: boolean;
	@Input() isReadOnly: boolean;

	@Input() applicationId: number;
	@Input() index: number;
	@Input() attachedDocumentTypeId: number;
	@Input() $isCertificateContinueButtonClicked: BehaviorSubject<boolean>;
	@Output() emitDocumentsAreUploaded: EventEmitter<number[]> = new EventEmitter<number[]>();
	@Output() emitHasErrorInAttachedCertificate: EventEmitter<boolean> = new EventEmitter<boolean>();
	@Output() hideCertificateComponent: EventEmitter<boolean> = new EventEmitter<boolean>();

	attachedDocumentType: AttachDocumentTypes;
	attachedDocumentTypeKey: string;
	actionKey: string;
	areDeclared = false;
	hasError = false;
	hasUploadedCertificatesWithFiles = false;
	documentTypesIds: number[] = []; // can be :  100, 12, 22 , 200
	attachedDocumentTypeIds: number[] = []; // can be : 0 , 12, 22
	maxNumberOfDiffCertificatesForApplication: number;
	canAddRow = true;
	isUserApplicant: boolean;
	isUserWithEFace: boolean;
	isLoading: boolean;
	showDeclareButton: boolean;
	buttonContinueIsClickedSubscription: Subscription = null;
	// DQC Certificates
	@Input() uploadedCertificates: Certificate[];
	dqcCertificateNomenclatures: DqcCertificateNomenclatures = null;
	isDqcCertificateAttachment = false;
	certificateToDisplay: Certificate[] = [];
	// ADR Modules
	@Input() uploadedModules: AdrModule[];
	adrModuleTypes: Translation[] = null;
	isAdrModuleAttachment = false;
	modulesToDisplay: AdrModule[] = [];

	constructor(
		private readonly documentService: DocumentService,
		private readonly nomenclatureService: NomenclatureService,
		private readonly authenticationService: AuthenticationService,
		private reference: ChangeDetectorRef ) {}

	ngOnInit(): void {
		this.isUserApplicant = this.authenticationService.getAuthenticatedUser().isApplicant();
		this.isUserWithEFace = this.authenticationService.getAuthenticatedUser().isEFaceApplicant();
		this.attachedDocumentType = ATTACHED_DOCUMENT_TYPE;
		this.actionKey = ATTACHED_DOCUMENT_TYPE_ACTION_KEY[this.attachedDocumentTypeId];
		this.attachedDocumentTypeKey = ATTACHED_DOCUMENT_TYPE_KEY[this.attachedDocumentTypeId];
		if (this.attachedDocumentTypeId === ATTACHED_DOCUMENT_TYPE.ADR_MODULE) {
			this.isAdrModuleAttachment = true;
			this.maxNumberOfDiffCertificatesForApplication = 4;
			this.setListWhenUploadAdrModule();
			this.getAdrModuleTypes();
		} else if (this.attachedDocumentTypeId === ATTACHED_DOCUMENT_TYPE.DQC_CERTIFICATE) {
			this.isDqcCertificateAttachment = true;
			this.maxNumberOfDiffCertificatesForApplication = 2;
			this.setListsWhenUploadDqcCertificate();
			this.getDqcNomenclatures();
		}
		this.showDeclareButton = this.checkIfUserMustDeclare();
		this.buttonContinueIsClickedSubscription = this.$isCertificateContinueButtonClicked.subscribe((value: boolean) => {
			if (value) {
				this.continueToNextSection();
			}
		});
	}

	checkIfUserMustDeclare(): boolean {
		return this.isUserApplicant && !this.isUserWithEFace && this.isDraft && this.isDqcCertificateAttachment;
	}

	addRow() {
		if (this.documentTypesIds.length + 1 > this.maxNumberOfDiffCertificatesForApplication || this.checkHasEmptyRow()) {
			this.canAddRow = false;
			return;
		}
		this.documentTypesIds.push(this.attachedDocumentTypeId);
		if (this.isDqcCertificateAttachment) {
			this.attachedDocumentTypeIds.push(0);
		}
		this.hasUploadedCertificatesWithFiles = false;
		this.areDeclared = false;
		this.emitDocumentsAreUploaded.emit([]);
	}

	checkHasEmptyRow(): boolean {
		return this.documentTypesIds.includes(ATTACHED_DOCUMENT_TYPE.ADR_MODULE)
			|| this.documentTypesIds.includes(ATTACHED_DOCUMENT_TYPE.DQC_CERTIFICATE);
	}

	deleteRow(index: number) {
		this.documentTypesIds.splice(index, 1);
		this.attachedDocumentTypeIds.splice(index, 1);
		this.uploadedCertificates.splice(index, 1);
		if (this.documentTypesIds.length < 1) {
			this.hasError = false;
			this.hasUploadedCertificatesWithFiles = false;
			this.hideCertificateComponent.emit(true);
			this.emitHasErrorInAttachedCertificate.emit(false);
		} else {
			this.hideCertificateComponent.emit(false);
			this.hasUploadedCertificatesWithFiles = this.checkAllRowsHasUploadedFile();
		}
		this.canAddRow = true;
	}

	setDocumentTypeId(uploadedDocumentTypeId: number, index: number) {
		this.documentTypesIds[index] = uploadedDocumentTypeId;
		if (!this.documentTypesIds.includes(ATTACHED_DOCUMENT_TYPE.DQC_CERTIFICATE) && this.isDqcCertificateAttachment) {
			this.hasUploadedCertificatesWithFiles = false;
			this.areDeclared = false;
		}
		if (this.isAdrModuleAttachment) {
			this.attachedDocumentTypeIds.push(uploadedDocumentTypeId);
			this.hasUploadedCertificatesWithFiles = true;
			this.hasError = false;
		}
	}

	setUploadedAttachmentDocumentTypeId(uploadedDocumentType: RequiredDocumentType, index: number) {
		if (uploadedDocumentType.id !== 0) {
			this.documentTypesIds[index] = uploadedDocumentType.id;
			this.attachedDocumentTypeIds[index] = uploadedDocumentType.id;
		} else {
			this.attachedDocumentTypeIds[index] = 0;
			this.hasUploadedCertificatesWithFiles = false;
			this.areDeclared = false;
			this.emitDocumentsAreUploaded.emit([]);
		}
		if (this.checkAllRowsHasUploadedFile()) {
			this.hasError = false;
			this.hasUploadedCertificatesWithFiles = true;
		}
	}

	continueToNextSection() {
		if (this.attachedDocumentTypeIds.includes(0) || this.attachedDocumentTypeIds.length === 0) {
			this.hasError = true;
			this.emitHasErrorInAttachedCertificate.emit(true);
			this.emitDocumentsAreUploaded.emit([]);
			this.scrollToFirstErrorInAttachedDocument();
			return;
		} else if (this.checkIfUserMustDeclare() && !this.areDeclared) {
			this.hasError = true;
			this.emitHasErrorInAttachedCertificate.emit(true);
			this.scrollToFirstErrorInAttachedDocument();
			return;
		} else if (!this.hasUploadedCertificatesWithFiles) {
			this.hasError = true;
			this.emitHasErrorInAttachedCertificate.emit(true);
			this.scrollToFirstErrorInAttachedDocument();
			return;
		}
		this.hasError = false;
		if (this.isAdrModuleAttachment) {
			this.addTranslationKeyToModulesToDisplay();
		} else if (this.isDqcCertificateAttachment) {
			this.addTranslationKeyToCertificatesToDisplay();
		}
		this.emitHasErrorInAttachedCertificate.emit(false);
		this.hasUploadedCertificatesWithFiles = true;
		this.emitDocumentsAreUploaded.emit(this.attachedDocumentTypeIds);
	}

	addTranslationKeyToModulesToDisplay() {
		this.modulesToDisplay.forEach((module) => {
			if (!module.typeKey) {
				this.adrModuleTypes.forEach((type) => {
					if (type.id === module.typeId) {
						module.typeKey = type.key;
					}
				});
			}
		});
	}

	addTranslationKeyToCertificatesToDisplay() {
		this.certificateToDisplay.forEach((certificate) => {
			if (!certificate.typeKey) {
				this.dqcCertificateNomenclatures.certificateTypes.forEach((cert) => {
					if (cert.id === certificate.typeId) {
						certificate.typeKey = cert.key;
					}
				});
			}
		});
	}

	scrollToFirstErrorInAttachedDocument() {
		this.reference.detectChanges();
		const elements = document.getElementsByClassName('box-validation error');
		elements[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
	}

	checkAllRowsHasUploadedFile(): boolean {
		if (this.attachedDocumentTypeIds.includes(0)) {
			return false;
		}
		this.hasError = false;
		return true;
	}

	declareAllToggle() {
		if (!this.areDeclared && !this.checkAllRowsHasUploadedFile()) {
			PopUpService.showPopUp({
				header: POP_UP_MESSAGES_KEYS.error_could_not_declare_missing_info,
				type: PopUpTypes.ERROR
			});
			return;
		}
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.areDeclared = !this.areDeclared;
		const attachDocIds = this.attachedDocumentTypeIds.filter(id => id !== 0);
		const dto = new DocumentsDeclarationDto(this.areDeclared, attachDocIds);
		this.documentService
			.declareDocuments(this.applicationId, dto)
			.subscribe(
				(response) => {
					if (this.areDeclared && this.hasUploadedCertificatesWithFiles) {
						this.hasError = false;
					}
					this.isLoading = false;
				},
				(error) => {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_could_not_declare_document);
					this.areDeclared = !this.areDeclared;
					this.isLoading = false;
				}
			);
	}

	setDeclareStatus(isDeclaredPage: boolean) {
		this.areDeclared = isDeclaredPage;
	}

	getDqcNomenclatures() {
		this.nomenclatureService.getAllDqcCertificateNomenclatures()
			.subscribe((dto: DqcCertificateNomenclaturesDto) => {
				this.dqcCertificateNomenclatures = dto ? new DqcCertificateNomenclatures(dto) : null;
			});
	}

	getAdrModuleTypes() {
		this.nomenclatureService.getAllAdrModuleTypes()
			.subscribe((dtos: TranslationDto[]) => {
				this.adrModuleTypes = dtos ? dtos.map((dto: TranslationDto) => new Translation(dto)) : null;
			});
	}

	setListsWhenUploadDqcCertificate() {
		if (this.uploadedCertificates.length > 0) {
			this.uploadedCertificates.forEach((certificate) => this.certificateToDisplay.push(new Certificate(certificate)));
			if (this.uploadedCertificates.length > 1) {
				this.canAddRow = false;
			}
			this.uploadedCertificates.forEach(
				certificate => {
					this.documentTypesIds.push(CERTIFICATE_TYPE_ID_TO_ATTACHED_DOCUMENT_TYPE_ID[certificate.typeId]);
					this.attachedDocumentTypeIds.push(0);
				});
		} else {
			this.documentTypesIds.push(ATTACHED_DOCUMENT_TYPE.DQC_CERTIFICATE);
			this.attachedDocumentTypeIds.push(0);
		}
	}

	setListWhenUploadAdrModule() {
		if (this.uploadedModules.length > 0) {
			this.uploadedModules.forEach((module) => this.modulesToDisplay.push(new AdrModule(module)));
			if (this.uploadedModules.length > 3) {
				this.canAddRow = false;
			}
			this.uploadedModules.forEach(
				module => {
					this.documentTypesIds.push(module.typeId);
				});
		} else {
			this.documentTypesIds.push(ATTACHED_DOCUMENT_TYPE.ADR_MODULE);
		}
	}

	addCertificateToDisplay(certView: Certificate) {
		this.certificateToDisplay.push(certView);
	}

	addModuleToDisplay(moduleView: AdrModule) {
		this.modulesToDisplay.push(moduleView);
	}

	ngOnDestroy(): void {
		this.buttonContinueIsClickedSubscription.unsubscribe();
	}
}
