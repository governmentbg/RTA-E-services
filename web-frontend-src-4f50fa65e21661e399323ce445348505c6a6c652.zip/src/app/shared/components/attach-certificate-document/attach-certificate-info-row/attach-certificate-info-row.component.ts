import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DqcService } from 'src/app/core/services/dqc.service';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { Certificate } from 'src/app/shared/models/certificate';
import { CertificateDto } from 'src/app/shared/dtos/certificate-dto';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { CERTIFICATE_TYPE_ID_TO_ATTACHED_DOCUMENT_TYPE_ID } from 'src/app/shared/models/constants/attached-documents/certificate-type-id';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { DqcCertificateNomenclatures } from 'src/app/shared/models/dqc-certificate-nomenclatures';
import { AdrModule } from 'src/app/shared/models/adr-module';
import { AdrCardService } from 'src/app/core/services/adr-card.service';
import { AdrModuleDto } from 'src/app/shared/dtos/adr-module-dto';
import { Translation } from 'src/app/shared/models/translation';
import { Utils } from 'src/app/shared/utils/utils';
import { S_VARIABLES } from 'src/app/shared/models/constants/s-variables';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';

@Component({
	selector: 'app-attach-certificate-info-row',
	templateUrl: './attach-certificate-info-row.component.html'
})
export class AttachCertificateInfoRowComponent implements OnInit {
	@Input() applicationId: number;
	@Input() index: number;
	@Input() hasErrorInParent: boolean;
	@Output() setDocumentTypeId: EventEmitter<number> = new EventEmitter();
	issuedDate: Date;
	trainingPeriodStart: Date;
	trainingPeriodEnd: Date;
	permitNumber: string;
	certificateNumber: string;
	selectedCertificateTypeId: number = null;
	hasCertificateInfo: boolean;
	hasMissingInfo = false;
	@Output() hasCertificate: EventEmitter<number> = new EventEmitter();
	@Output() deleteCertificateAndAttachedDocument: EventEmitter<Event> = new EventEmitter();

	// *** DQC certificate ***
	@Input() isDqcCertificateAttachment: boolean;
	@Input() dqcCertificate: Certificate;
	@Input() uploadedCertificates: Certificate[];
	@Input() dqcCertificateNomenclatures: DqcCertificateNomenclatures;
	@Output() emitCertificateToDisplay: EventEmitter<Certificate> = new EventEmitter();

	selectedLegalBasisId: number = null;

	// *** ADR module ***
	@Input() isAdrModuleAttachment: boolean;
	@Input() adrModule: AdrModule;
	@Input() uploadedModules: AdrModule[];
	@Input() adrModuleTypes: Translation[] = [];
	@Output() emitModuleToDisplay: EventEmitter<AdrModule> = new EventEmitter();

	public today: Date = new Date();
	dateFormat = S_VARIABLES.DATE_FORMAT;
	dateFormatRange = S_VARIABLES.DATE_FORMAT_RANGE;

	constructor(
		private readonly dqcService: DqcService,
		private readonly adrCardService: AdrCardService) { }

	ngOnInit(): void {
		if (this.dqcCertificate) {
			this.permitNumber = this.dqcCertificate.permitNumber;
			this.certificateNumber = this.dqcCertificate.certificateNumber;
			this.trainingPeriodStart = this.dqcCertificate.trainingStart;
			this.trainingPeriodEnd = this.dqcCertificate.trainingEnd;
			this.issuedDate = new Date(this.dqcCertificate.issuedOn);
			this.selectedCertificateTypeId = this.dqcCertificate.typeId;
			this.selectedLegalBasisId = this.dqcCertificate.legalBasisId;
			this.hasCertificateInfo = true;
			this.setDocumentTypeId.emit(CERTIFICATE_TYPE_ID_TO_ATTACHED_DOCUMENT_TYPE_ID[this.selectedCertificateTypeId]);
		} else if (this.adrModule) {
			this.issuedDate = new Date(this.adrModule.issueDate);
			this.selectedCertificateTypeId = this.adrModule.typeId;
			this.hasCertificateInfo = true;
			this.setDocumentTypeId.emit(this.selectedCertificateTypeId);
		} 
	}

	saveAdrModule() {
		if (!this.allAdrModuleFieldsAreFilled()) {
			return;
		}
		if (this.isCertificateTypeAlreadyUploaded()) {
			PopUpService.showPopUp(DEFAULT_POP_UPS.error_certificate_of_type_already_exists);
			return;
		}
		const isAttached = true;
		const dto = new AdrModuleDto();
		dto.typeId = this.selectedCertificateTypeId;
		dto.issueDate = this.issuedDate;
		dto.attached = isAttached;

		const dtoView = new AdrModule(dto);
		this.adrCardService
			.saveModule(this.applicationId, dto)
			.subscribe(
				() => {
					this.adrModule = new AdrModule(dto);
					this.hasCertificateInfo = true;
					this.uploadedModules.push(this.adrModule);
					this.setDocumentTypeId.emit(this.selectedCertificateTypeId);
					this.emitModuleToDisplay.emit(dtoView);
				},
				(errorResponse) => {
					this.hasCertificateInfo = false;
					if (errorResponse.error) {
						if (errorResponse.error.error === 'RepeatingTypesException') {
							PopUpService.showPopUp(DEFAULT_POP_UPS.error_certificate_of_type_already_exists);
						} else if (errorResponse.error.error === 'MissingCertificateOrModuleException') {
							PopUpService.showPopUp(DEFAULT_POP_UPS.error_must_choose_basic_module_first);
						} else if (errorResponse.error.error === 'MismatchException') {
							PopUpService.showPopUp(DEFAULT_POP_UPS.error_date_of_chosen_module_not_correct);
						}
						return;
					}
					PopUpService.showPopUp(DEFAULT_POP_UPS.error);
				}
			);
	}

	saveCertificate() {
		if (!this.allDqcCertificateFieldsAreFilled()) {
			return;
		}
		if (this.isCertificateTypeAlreadyUploaded()) {
			PopUpService.showPopUp({
				header: POP_UP_MESSAGES_KEYS.error_certificate_already_uloaded,
				type: PopUpTypes.ERROR
			});
			return;
		}
		const dto = new CertificateDto();
		dto.permitNumber = this.permitNumber;
		dto.certificateNumber = this.certificateNumber;
		dto.typeId = this.selectedCertificateTypeId;
		dto.legalBasisId = this.selectedLegalBasisId;
		//crazy workaround for timezone offset. can't understand why the problem is only in this place
		dto.issuedOn = new Date(Utils.convertDateToStringFormatted(new Date(this.issuedDate)));
		dto.trainingStart = new Date(Utils.convertDateToStringFormatted(new Date(this.trainingPeriodStart)));
		dto.trainingEnd = new Date(Utils.convertDateToStringFormatted(new Date(this.trainingPeriodEnd)));
		dto.attached = true;

		const dtoView = new Certificate(dto);
		this.dqcService
			.saveCertificate(this.applicationId, dto)
			.subscribe(
				(response) => {
					this.dqcCertificate = new Certificate(dto);
					this.hasCertificateInfo = true;
					this.uploadedCertificates.push(this.dqcCertificate);
					this.setDocumentTypeId.emit(CERTIFICATE_TYPE_ID_TO_ATTACHED_DOCUMENT_TYPE_ID[this.selectedCertificateTypeId]);
					this.emitCertificateToDisplay.emit(dtoView);
				},
				(errorResponse) => {
					this.hasCertificateInfo = false;
					if (errorResponse.error) {
						if (errorResponse.error.error === 'RepeatingTypesException') {
							PopUpService.showPopUp(DEFAULT_POP_UPS.error_certificate_of_type_already_exists);
						}
						return;
					}
					PopUpService.showPopUp(DEFAULT_POP_UPS.error);
				}
			);
	}

	isCertificateTypeAlreadyUploaded(): boolean {
		const certificateTypeId = this.uploadedCertificates
			.filter(certificate => certificate.typeId === this.selectedCertificateTypeId);
		const moduleTypeId = this.uploadedModules
			.filter(module => module.typeId === this.selectedCertificateTypeId);
		if (certificateTypeId.length > 0 || moduleTypeId.length > 0) {
			return true;
		}
		return false;
	}

	allDqcCertificateFieldsAreFilled(): boolean {
		if (!this.selectedCertificateTypeId || !this.selectedLegalBasisId
			|| !this.permitNumber || !this.certificateNumber || !this.issuedDate || !this.trainingPeriodStart || !this.trainingPeriodEnd) {
			this.hasMissingInfo = true;
			return false;
		}
		return true;
	}

	allAdrModuleFieldsAreFilled(): boolean {
		if (!this.selectedCertificateTypeId || !this.issuedDate) {
			this.hasMissingInfo = true;
			return false;
		}
		return true;
	}

	deleteDocumentWithCertificate(event: Event) {
		if (this.dqcCertificate) {
			PopUpService.showPopUp(DEFAULT_POP_UPS.delete);
			const currentSubscription = PopUpService.subscribeToPopUpResponse(
				(hasConfirmed) => {
					if (hasConfirmed) {
						this.dqcService
							.deleteCertificate(this.applicationId, this.dqcCertificate.typeId)
							.subscribe(
								(success) => {
									const index = this.uploadedCertificates.indexOf(this.dqcCertificate);
									this.uploadedCertificates.splice(index, 1);
									this.dqcCertificate = null;
									this.deleteCertificateAndAttachedDocument.emit(event);
									this.cleanFields();
									currentSubscription.unsubscribe();
								},
								(error) => {
									PopUpService.showPopUp(DEFAULT_POP_UPS.error);
									currentSubscription.unsubscribe();
								}
							);
					}
				});
		} else {
			this.deleteCertificateAndAttachedDocument.emit(event);
		}
	}

	deleteAdrModule(event: Event) {
		if (this.adrModule) {
			PopUpService.showPopUp(DEFAULT_POP_UPS.delete);
			const currentSubscription = PopUpService.subscribeToPopUpResponse(
				(hasConfirmed) => {
					if (hasConfirmed) {
						this.adrCardService
							.deleteModule(this.applicationId, this.adrModule.typeId)
							.subscribe(
								(success) => {
									const index = this.uploadedModules.indexOf(this.adrModule);
									this.uploadedModules.splice(index, 1);
									this.adrModule = null;
									this.deleteCertificateAndAttachedDocument.emit(event);
									this.cleanFields();
									currentSubscription.unsubscribe();
								},
								(error) => {
									PopUpService.showPopUp(DEFAULT_POP_UPS.error);
									currentSubscription.unsubscribe();
								}
							);
					}
				});
		} else {
			this.deleteCertificateAndAttachedDocument.emit(event);
		}
	}

	cleanFields() {
		this.selectedCertificateTypeId = null;
		this.selectedLegalBasisId = null;
		this.issuedDate = null;
		this.trainingPeriodStart = null;
		this.trainingPeriodEnd = null;
		this.permitNumber = null;
		this.certificateNumber = null;
		this.hasCertificateInfo = false;
	}

	dateRangeChange(dateRangeStart: HTMLInputElement, dateRangeEnd: HTMLInputElement) {
		this.trainingPeriodStart = new Date(dateRangeStart.value);
		this.trainingPeriodEnd = new Date(dateRangeEnd.value);
	}

}
