import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import { DocumentService } from 'src/app/core/services/document.service';
import { RequiredDocumentTypeDto } from '../../interfaces/required-doc-type-dto';
import { User } from '../../models/user';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { BehaviorSubject } from 'rxjs';
import { ApplicationIdWrapperDto } from '../../dtos/application-id-wrapper-dto';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { ATTACHED_DOCUMENT_TYPE } from '../../enums/attached-document-types';
import { APPLICATION_TYPE } from '../../enums/application-types';
import { RequiredDocumentType } from '../../models/required-document-type';
import { Translation } from '../../models/translation';

@Component({
	selector: 'app-attach-multiple-documents',
	templateUrl: './attach-multiple-documents.component.html'
})
export class AttachMultipleDocumentsComponent implements OnInit, OnChanges {
	@Input() public isDraft: boolean;
	@Input() public applicationId: number;
	@Input() public applicationTypeId: number;
	@Input() public isReadOnly: boolean;
	@Input() public alreadyAttachedDocTypes: Translation[] = [];
	@Input() milestoneStatusId: number;
	@Output() public emitContinue = new EventEmitter<Event>();
	@Output() public emitHasAttachedDocuments: EventEmitter<boolean> = new EventEmitter<boolean>();
	public $isContinueButtonClicked = new BehaviorSubject(false);
	public allRequiredDocTypes: RequiredDocumentType[] = [];
	public requiredDocTypesForSection: number[] = [];
	public user: User;
	public uploadedDocumentTypes: RequiredDocumentType[] = [];

	constructor(
		private documentService: DocumentService,
		private authenticationService: AuthenticationService,
		private nomenclatureService: NomenclatureService,
		private reference: ChangeDetectorRef
	) { }

	ngOnInit(): void {
		this.user = this.authenticationService.getAuthenticatedUser();
		if (this.isReadOnly) {
			this.documentService.getRequiredDocumentTypesForGivenSection(this.applicationId, this.milestoneStatusId)
				.subscribe(
					(docTypes: number[]) => {
						this.requiredDocTypesForSection = docTypes;

						if (this.requiredDocTypesForSection.length > 0) {
							const hasAllRequiredDocs = this.checkApplicationHasAllRequiredDocs();
							if (!hasAllRequiredDocs) {
								this.isReadOnly = false;
								return;
							}

							this.emitHasAttachedDocuments.emit(true);
						} else {
							this.continueToNextStep();
						}
					}
				);
		} else {
			this.getAllRequiredDocuments();
		}
	}

	checkApplicationHasAllRequiredDocs(): boolean {
		var hasDocs = true;
		const alreadyUploadedDocTypeIds = this.alreadyAttachedDocTypes.map(doc => {return doc.id});
		this.requiredDocTypesForSection.forEach(
			 requiredDoc =>  {
				 if (!alreadyUploadedDocTypeIds.includes(requiredDoc)) {
					hasDocs = false;
			 }}
		);
		return hasDocs;
	}

	getAllRequiredDocuments() {
		this.nomenclatureService.getAllRequiredDocumentTypes().subscribe(
			(docTypes: RequiredDocumentTypeDto[]) => {
				docTypes.forEach(type => {
					this.allRequiredDocTypes.push(new RequiredDocumentType(type));
				});
			}
		);
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (!this.isReadOnly) {
			this.documentService.getRequiredDocumentTypes(this.applicationId).subscribe(
				(docTypes: RequiredDocumentTypeDto[]) => {
					docTypes.forEach(type => {
						if (!this.requiredDocTypesForSection.includes(type.id)) {
							this.requiredDocTypesForSection.push(type.id);
						}
					});
					if (!this.isReadOnly && this.requiredDocTypesForSection.length > 0) {
						setTimeout(() => {
							const firstAttachedDocInSection = this.requiredDocTypesForSection[0];
							const element = document.getElementById(firstAttachedDocInSection.toString());
							element.scrollIntoView({ behavior: 'smooth', block: 'center' });
						}, 500);
					} else if (!this.isReadOnly && this.requiredDocTypesForSection.length === 0) {
						this.continueToNextStep();
					}
				}
			);
		}
	}

	getUploadedDocumentType(uploadedDocumentType: RequiredDocumentType) {
		if (uploadedDocumentType.id !== 0) {
			const alreadyUploaded = this.uploadedDocumentTypes.includes(uploadedDocumentType);
			if (!alreadyUploaded) {
				this.uploadedDocumentTypes.push(uploadedDocumentType);
			}
		} else {
			this.uploadedDocumentTypes = [];
		}
	}

	continueToNextStep() {
		this.$isContinueButtonClicked.next(true);
		let areRequiredDocsAttached = true;
		if (this.requiredDocTypesForSection.length > 0) {
			this.requiredDocTypesForSection.forEach((typeId) => {
				if (this.uploadedDocumentTypes.length === 0) {
					areRequiredDocsAttached = false;
				} else {
					for (let i = 0; i < this.uploadedDocumentTypes.length; i++) {
						if (this.uploadedDocumentTypes[i].id === typeId) {
							break;
						}
						if (i === this.uploadedDocumentTypes.length - 1
							&& (typeId !== ATTACHED_DOCUMENT_TYPE.MVR_NOTIFICATION_DOCUMENT
								|| (typeId === ATTACHED_DOCUMENT_TYPE.MVR_NOTIFICATION_DOCUMENT
									&& this.applicationTypeId === APPLICATION_TYPE.APPLICATION_TACHO_CARD))) {
							areRequiredDocsAttached = false;
						}
					}
					this.emitHasAttachedDocuments.emit(true);
				}
			});
		} else {
			this.emitHasAttachedDocuments.emit(false);
		}

		if (this.isDraft) {
			if (areRequiredDocsAttached) {
				this.$isContinueButtonClicked.next(false);
				if (!this.user.isApprover()) {
					this.documentService.confirmRequiredDocumentsAreAttached(new ApplicationIdWrapperDto(this.applicationId))
						.subscribe(() => {
							this.emitContinue.emit();
							this.isReadOnly = true;
						});
				}
			} else {
				// next row update your scope variable / to get error in class name /
				this.reference.detectChanges();
				const elements = document.getElementsByClassName('box-validation error');
				elements[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
			}
		}
	}
}
