import { Component, Input, Output, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { NgxFileDropEntry, FileSystemFileEntry } from 'ngx-file-drop';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { HttpResponse, HttpEventType } from '@angular/common/http';
import { ATTACHED_DOCUMENT_TYPE, AttachDocumentTypes } from '../../../enums/attached-document-types';
import { saveAs } from 'file-saver';
import { FileDownloadInfo } from 'src/app/shared/models/file-download-info';
import { DocumentPageInfo } from 'src/app/shared/models/document-page-info';
import { DocumentService } from 'src/app/core/services/document.service';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { DEFAULT_POP_UPS } from 'src/app/shared/models/constants/pop-up-default-messages';
import { POP_UP_MESSAGES_KEYS } from 'src/app/shared/models/constants/pop-up-messages-keys';
import { PopUpTypes } from 'src/app/shared/enums/pop-up-types';
import { FileService } from 'src/app/core/services/file.service';

@Component({
	selector: 'app-attach-document-row',
	templateUrl: './attach-document-row.component.html'
})
export class AttachDocumentRowComponent implements OnInit, OnChanges {
	private static readonly MANUALLY_EDITED = 'MANUALLY';
	private static readonly AUTO_EDITED = 'AUTO';
	private static readonly AUTO_FIXED_JPG = '_AUTO_FIXED.jpg';
	private static readonly FILE = 'file';
	private static readonly IMAGE_JPG = 'image/jpg';

	@Input() isDraft: boolean;
	@Input() isReadOnly: boolean;
	@Input() hasAutoFixedPicturesFromMvr: boolean;

	@Input() applicationId: number;
	@Input() applicationTypeId: number;
	@Input() documentCanHaveTwoSides: boolean;
	@Input() hasAlreadyUploadedFiles: boolean;
	@Input() isApprover: boolean;
	@Input() isUserApplicant: boolean;
	@Input() isUserWithEFace: boolean;
	@Input() attachedDocumentTypeId: number;
	@Input() uploadedPagesInfo: DocumentPageInfo[];

	@Input() isApplicationAttachment: boolean;
	@Input() isDqcCertificateAttachment: boolean;
	@Input() isSignatureAttachment: boolean;
	@Input() isFaceAttachment: boolean;
	@Input() isPaymentAttachment: boolean;

	@Input() srcPictureFromApproverMvrCheck: Blob;

	@Output() deletePage: EventEmitter<DocumentPageInfo> = new EventEmitter();
	@Output() deleteCurrentDocument: EventEmitter<Event> = new EventEmitter();
	@Output() checkFilesAndAdd: EventEmitter<File[]> = new EventEmitter();
	@Output() emitIsEditorVisible: EventEmitter<boolean> = new EventEmitter();
	@Output() generatedApplicationAction: EventEmitter<boolean> = new EventEmitter();
	@Output() emitEditedPictureIsLoaded: EventEmitter<number> = new EventEmitter<number>();
	@Output() applicationWasGeneratedForApprover: EventEmitter<Event> = new EventEmitter();
	showDropDown = false;
	isMouseOver: boolean;
	filesFromDropAndDragUpload: NgxFileDropEntry[] = [];
	filesFromUploadButton: File[] = [];
	filesForEmit: File[] = [];
	fileForDownload: FileDownloadInfo;
	math = Math;
	attachedDocumentType: AttachDocumentTypes;
	isLoading = false;
	isPdf = false;
	srcFromArrayBuffer: ArrayBuffer = null;
	showViewer =  false;
	currentPageToOpen: number;
	filename: string;
	alreadyOpenedPagesSourceMap: Map<number, ArrayBuffer> = new Map<number, ArrayBuffer>();
	downloadedApplicationResponse: HttpResponse<ArrayBuffer> = null;;
	// editor
	faceOrSignaturePdfFile: File;
	faceOrSignatureAsBase64: string;
	filenameWithoutExtension: string;
	@Input() showEditor: boolean;
	@Input() imageBase64AutoFixed: string;
	@Input() showLoading: boolean;
	@Input() hasPictureFromProcessing: boolean;
	uploadedFileForEditor: File;
	hasOnlyOriginalImage: boolean;
	autoFixedPicture: ArrayBuffer;
	showFinallyEditedPicture: boolean;
	imageBase64OfOrigin: string;
	imageBase64ForReadOnly: string;
	// application section
	isStartedDownloadingApplication = false;
	isDownloadingApplication = false;
	hasDownloadedApplication = false;

	constructor(
		private readonly documentService: DocumentService,
		private readonly fileService: FileService
	) { }

	ngOnInit(): void {
		this.attachedDocumentType = ATTACHED_DOCUMENT_TYPE;
		if (this.isFaceAttachment || this.isSignatureAttachment) {
			if (!this.isReadOnly && this.isApprover) {
				this.editFinallyPicture();
				return;
			}
 			this.setParamsAndGetPictures();
		}
	}

	ngOnChanges(): void {
		if (this.isSignatureAttachment || this.isFaceAttachment) {
			if (this.uploadedPagesInfo.length === 0) {
				this.deleteFieldsBeforeNewUpload();
			}
		}
	}

	setParamsAndGetPictures() {
		if (this.isDraft && !this.isReadOnly) {
			if (this.uploadedPagesInfo.length > 1) {
				this.showFinallyEditedPicture = true;
				this.showEditor = false;
				this.getEditedPictureOfFaceOrSignature();
			} else if (this.uploadedPagesInfo.length === 1) {
				this.showFinallyEditedPicture = false;
				this.getAutoFixedPicture();
				this.emitIsEditorVisible.emit(true);
			} else if (this.uploadedPagesInfo.length === 0 ) {
				this.emitIsEditorVisible.emit(true);
				this.showFinallyEditedPicture = false;
				this.hasPictureFromProcessing = false;
			}
		} else if (!this.isDraft || this.isReadOnly) {
			this.getEditedPictureOfFaceOrSignature();
		}
	}

	checkPictureIsFromAutoFixed() {
		return this.uploadedPagesInfo[1] && this.uploadedPagesInfo[1].pageName.includes(AttachDocumentRowComponent.AUTO_EDITED);
	}

	upload(files: File[]) {
		this.filesFromUploadButton = files;
		if (this.documentCanHaveTwoSides && ((files.length + this.uploadedPagesInfo.length) > 2)) {
			PopUpService.showPopUp(DEFAULT_POP_UPS.error_document_can_have_max_two_pages);
			return;
		} else if (this.isApplicationAttachment || this.isFaceAttachment || this.isSignatureAttachment) {
			if (files.length > 1) {
				PopUpService.showPopUp(DEFAULT_POP_UPS.error_cannot_upload_more_than_one_file);
				return;
			}
			if (this.isFaceAttachment || this.isSignatureAttachment) {
				this.checkImageIsCorrectAndEmit(this.filesFromUploadButton[0]);
				return;
			} else if (this.isApplicationAttachment) {
				this.checkIfUserHasBeenGeneratedApplicationAndHaveAllRequiredDocuments();
				return;
			}
		}
		if (this.filesFromUploadButton && !this.isApplicationAttachment) {
			this.checkFilesAndAdd.emit(this.filesFromUploadButton);
		}
	}

	checkImageIsCorrectAndEmit(file: File) {
		const filename = file.name;
		this.filenameWithoutExtension = filename.substr(0, filename.lastIndexOf('.'));
		const extension = file.name.split('.').pop().toLowerCase();
		if (extension === 'pdf') {
			this.checkPdfHasOnlyOnePage(file);
		} else {
			this.checkFilesAndAdd.emit(this.filesFromUploadButton);
		}
	}

	checkPdfHasOnlyOnePage(file: File) {
		const reader = new FileReader();
		reader.onload = this.handleFileFromPdf.bind(this);
		reader.readAsBinaryString(file);
		this.faceOrSignaturePdfFile = file;
	}

	handleFile(event) {
		const binaryString = event.target.result;
		this.faceOrSignatureAsBase64 = 'data:image/jpg;base64,' + btoa(binaryString);
	}

	handleFileFromPdf(event) {
		const binaryString = event.target.result;
		const array = btoa(binaryString);
		const binary = atob(array);
		const pageCount = binary.match(/\/Type\s*\/Page\b/g).length;
		if (pageCount > 1) {
			PopUpService.showPopUp({
				header: POP_UP_MESSAGES_KEYS.error_cannot_upload_pdf_with_many_pages ,
				type: PopUpTypes.ERROR
			});
			return;
		} else {
			this.checkFilesAndAdd.emit(this.filesFromUploadButton);
		}
	}

	deleteDocumentPage(page: DocumentPageInfo) {
		this.faceOrSignatureAsBase64 = null;
		this.srcFromArrayBuffer = null;
		this.deletePage.emit(page);
	}

	deleteDocument(event: Event) {
		this.deleteCurrentDocument.emit(event);
	}

	deleteFaceOrSignaturePicture(event: Event) {
		this.deleteCurrentDocument.emit(event);
	}

	deleteFieldsBeforeNewUpload() {
		this.showEditor = false;
		this.faceOrSignatureAsBase64 = null;
		this.srcFromArrayBuffer = null;
		this.imageBase64AutoFixed = null;
		this.imageBase64OfOrigin = null;
		this.imageBase64ForReadOnly = null;
		this.hasPictureFromProcessing = false;
	}

	showMenu() {
		this.showDropDown = true;
	}

	closeDropDown(event) {
		const target = event.target;
		if (!target.closest('.dropMenu')) {
			this.showDropDown = false;
		}
	}

	hideViewer(event: Event) {
		this.showViewer = false;
		this.alreadyOpenedPagesSourceMap = new Map<number, ArrayBuffer>();
	}

	getDocumentPageForViewer(page: number) {
		if (this.alreadyOpenedPagesSourceMap.get(page - 1)) {
			this.filename = this.uploadedPagesInfo[page - 1].pageName;
			this.srcFromArrayBuffer = this.alreadyOpenedPagesSourceMap.get(page - 1);
			this.currentPageToOpen = page;
			return;
		}
		this.openDocumentPage(this.uploadedPagesInfo[page - 1].pageId , page - 1);
	}

	dropped(files: NgxFileDropEntry[]) {
		this.filesFromDropAndDragUpload = files;
		if (this.documentCanHaveTwoSides && ((this.filesFromDropAndDragUpload.length + this.uploadedPagesInfo.length) > 2)) {
			PopUpService.showPopUp(DEFAULT_POP_UPS.error_document_can_have_max_two_pages);
			return;
		} else if (this.isApplicationAttachment || this.isFaceAttachment || this.isSignatureAttachment) {
			if (files.length > 1) {
				PopUpService.showPopUp(DEFAULT_POP_UPS.error_cannot_upload_more_than_one_file);
				return;
			}
			if ((this.isFaceAttachment || this.isSignatureAttachment) && this.checkIsFile()) {
				this.checkImageIsCorrectAndEmit(this.filesFromUploadButton[0]);
				return;
			} else if (this.isApplicationAttachment) {
				this.checkIfUserHasBeenGeneratedApplicationAndHaveAllRequiredDocuments();
				return;
			}
		} else {
			this.checkAreFilesAndEmit();
		}
	}

	checkAreFilesAndEmit() {
		if (this.filesFromDropAndDragUpload.every(this.isFile)) {
			this.filesFromDropAndDragUpload.forEach((f, index) => {
				this.getFileEntry(f, (file) => {
					this.filesForEmit.push(file);
					if (this.filesFromDropAndDragUpload.length - 1 === index) {
						this.checkFilesAndAdd.emit(this.filesForEmit);
						this.filesFromDropAndDragUpload = [];
						this.filesForEmit = [];
					}
				});
			});
		} else {
			PopUpService.showPopUp(DEFAULT_POP_UPS.error_cannot_upload_folder);
		}
	}

	hideEditorAndShowFinallyEditedPicture(event: Event) {
		this.showEditor = false;
		this.showFinallyEditedPicture = true;
		this.emitIsEditorVisible.emit(this.showEditor);
	}

	saveImageFromEditorAndShowReadonly(image: string) {
		if (this.showLoading || !this.uploadedPagesInfo[0]) {
			return;
		}
		fetch(image)
			.then(res => res.blob())
			.then(blob => {
				this.showLoading = true;
				const isAutoFixed = false;
				const fileForUpload = new File([blob], this.applicationId + '_MANUALLY_EDITED.jpg', { type: AttachDocumentRowComponent.IMAGE_JPG });
				const formData: FormData = new FormData();
				formData.append(AttachDocumentRowComponent.FILE, fileForUpload, fileForUpload.name);
				formData.append('autoFixed', JSON.stringify(isAutoFixed));

				this.documentService
					.saveEditedPicture(this.applicationId, this.attachedDocumentTypeId, formData)
					.subscribe(
						(pageId: number) => {
							if (this.isSignatureAttachment) {
								this.getEditedPictureOfFaceOrSignature();
							} else {
								this.imageBase64ForReadOnly = image;
							}
							if (this.uploadedPagesInfo.length > 1) {
								this.uploadedPagesInfo.splice(1, 1);
							}
							this.uploadedPagesInfo.push(new DocumentPageInfo(fileForUpload));
							this.uploadedPagesInfo[1].pageId = pageId;
							this.showEditor = false;
							this.showFinallyEditedPicture = true;
							this.emitIsEditorVisible.emit(this.showEditor);
						},
						(error) => {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_cannot_upload_file,
								text: POP_UP_MESSAGES_KEYS.try_again_later,
								type: PopUpTypes.ERROR
							});
						}).add(() => this.showLoading = false);
			});
	}

	getAutoFixImageAndHideEditor(event: Event) {
		if (this.srcPictureFromApproverMvrCheck) {
			this.getAutoFixedPictureFromMvrCheck();
		} else if (!this.imageBase64AutoFixed) {
				this.getAutoFixedPicture();
		} else {
			this.showEditor = false;
			this.showFinallyEditedPicture = false;
			this.hasPictureFromProcessing = true;
		}
	}

	editFinallyPicture() {
		this.showFinallyEditedPicture = false;
		this.emitIsEditorVisible.emit(true);
		if (this.isApprover) {
			if (this.srcPictureFromApproverMvrCheck) {
				this.hasPictureFromProcessing = false;
				this.imageBase64OfOrigin = FileService.DATA_IMAGE_AS_BASE_64 + this.srcPictureFromApproverMvrCheck;
				this.showEditor = true;
			} else {
				this.hasPictureFromProcessing = true;
				this.getOriginalPictureOfFaceOrSignature();
			}
			return;
		}

		this.documentService.checkHasAutoFixed(this.applicationId, this.attachedDocumentTypeId)
			.subscribe((
				(hasAutoFixed: boolean) => {
					if (hasAutoFixed) {
						this.imageBase64AutoFixed = this.imageBase64ForReadOnly;
						this.hasPictureFromProcessing = true;
					} else {
						if (!this.uploadedPagesInfo[0].file && !this.imageBase64OfOrigin) {
							this.getOriginalPictureOfFaceOrSignature();
						} else {
							this.showEditor = true;
						}
					}
				}));
	}

	base64ToFileAndSetName(fileAsBase64: string) {
		this.faceOrSignatureAsBase64 = fileAsBase64;
		const filename = this.filenameWithoutExtension + '.jpg';
		const arr = fileAsBase64.split(',');
		const mime = arr[0].match(/:(.*?);/)[1];
		const bstr = atob(arr[1]);
		let lengthNumber = bstr.length;
		const u8arr = new Uint8Array(lengthNumber);

		while (lengthNumber--) {
			u8arr[lengthNumber] = bstr.charCodeAt(lengthNumber);
		}

		return new File([u8arr], filename, { type: mime });
	}

	checkIsFile(): boolean {
		if (this.filesFromDropAndDragUpload[0]) {
			this.filesFromDropAndDragUpload.forEach((f, index) => {
				this.getFileEntry(f, (file) => {
					return true;
				});
			});
		} else {
			PopUpService.showPopUp(DEFAULT_POP_UPS.error_cannot_upload_folder);
			return false;
		}
	}

	isFile(entry: NgxFileDropEntry) {
		return entry.fileEntry.isFile;
	}

	getFileEntry(entry: NgxFileDropEntry, cb) {
		(entry.fileEntry as FileSystemFileEntry).file(f => cb(f));
	}

	fileOver(event: Event) {
		this.isMouseOver = true;
	}

	fileLeave(event: Event) {
		this.isMouseOver = false;
	}

	getFileExtension(filename: string): string {
		let extension = filename.split('.').pop();
		if (extension === 'jpeg') {
			extension = 'jpg';
		}
		return extension;
	}

	downloadDocument(event: Event) {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.documentService
			.getDocument(this.applicationId, this.attachedDocumentTypeId)
			.subscribe(
				(response: HttpResponse<ArrayBuffer>) => {
					this.downloadFileOnDisk(response);
					this.isLoading = false;
				},
				(error) => {
					this.isLoading = false;
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_can_not_open_file_try_later);
				});
	}

	downloadDocumentPage(pageId: number) {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.documentService
			.getDocumentPage(this.applicationId, this.attachedDocumentTypeId, pageId)
			.subscribe(
				(response: HttpResponse<ArrayBuffer>) => {
					this.downloadFileOnDisk(response);
					this.isLoading = false;
				},
				(error) => {
					this.isLoading = false;
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_can_not_open_file_try_later);
				});
	}

	openWrappedDocument(event: Event) {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.documentService
			.getDocument(this.applicationId, this.attachedDocumentTypeId)
			.subscribe(
				(response: HttpResponse<ArrayBuffer>) => {
					this.openWrappedFileInViewer(response);
					this.alreadyOpenedPagesSourceMap.set(1, response.body);
				},
				(error) => {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_can_not_open_file_try_later);
				}).add( () => this.isLoading = false);
	}

	openDocumentPage(pageId: number, pageIndex: number) {
		if (this.showLoading) {
			return;
		}
		this.showLoading = true;
		this.currentPageToOpen = pageIndex + 1;
		this.documentService
			.getDocumentPage(this.applicationId, this.attachedDocumentTypeId, pageId)
			.subscribe(
				(response: HttpResponse<ArrayBuffer>) => {
					this.openFileInViewer(response, pageIndex);
					this.alreadyOpenedPagesSourceMap.set(pageIndex, response.body);
					this.isLoading = false;
				},
				(error) => {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_can_not_open_file_try_later);
					this.isLoading = false;
				}).add( () => this.showLoading = false);
	}

	openWrappedFileInViewer(response: HttpResponse<ArrayBuffer>) {
		this.currentPageToOpen = 1;
		this.filename = this.fileService.getFilenameFromResponse(response);
		this.srcFromArrayBuffer = response.body;
		this.showViewer = true;
	}

	openFileInViewer(response: HttpResponse<ArrayBuffer>, pageIndex: number) {
		this.showViewer = true;
		this.filename = this.uploadedPagesInfo[pageIndex].pageName;
		this.srcFromArrayBuffer = response.body;
	}

	downloadFileOnDisk(response: HttpResponse<ArrayBuffer>) {
		let filename = '';
		filename = this.fileService.getFilenameFromResponse(response);
		const blob = new Blob([response.body], { type: 'application/multipart-file' });
		saveAs(blob, filename);
		this.isDownloadingApplication = false;
	}

	downloadGeneratedApplication(event: Event) {
		if (this.isLoading) {
			return;
		}
		this.fileForDownload = new FileDownloadInfo();
		this.isLoading = true;
		this.isDownloadingApplication = true;
		this.isStartedDownloadingApplication = true;
		const print = false;
		if (this.isApprover) {
			this.generateApplication(print);
		} else {
			this.documentService
				.checkHaveAllRequiredDocumentToGenerateApplication(this.applicationId)
				.subscribe(
					(canGenerate) => {
						if (canGenerate) {
							this.generateApplication(print);
						}
					},
					(error) => {
						this.isLoading = false;
						this.isDownloadingApplication = false;
						this.isStartedDownloadingApplication = false;
						this.fileForDownload = null;
						PopUpService.showPopUp(DEFAULT_POP_UPS.error_cannot_generate_application);
					}
				);
		}
	}

	printGeneratedApplication(event: Event) {
		if (this.isLoading) {
			return;
		}
		this.fileForDownload = new FileDownloadInfo();
		this.isLoading = true;
		this.isDownloadingApplication = true;
		this.isStartedDownloadingApplication = true;
		const print = true;

		if (this.isApprover) {
			this.generateApplication(print);
		} else {
			this.documentService
				.checkHaveAllRequiredDocumentToGenerateApplication(this.applicationId)
				.subscribe(
					(canGenerate) => {
						if (canGenerate) {
							this.generateApplication(print);
						}
					},
					(error) => {
						this.isLoading = false;
						this.isDownloadingApplication = false;
						this.isStartedDownloadingApplication = false;
						this.fileForDownload = null;
						PopUpService.showPopUp(DEFAULT_POP_UPS.error_cannot_generate_application);
					}
				);
		}
	}

	generateApplication(print: boolean) {
		const isResponseDownloadEventCompleted = false;
		let intervalIdToDelete = null;
		let isCompleted = false;
		this.documentService
			.getGeneratedCardPdfApplication(this.applicationId)
			.subscribe(
				(event) => {
					this.isStartedDownloadingApplication = false;
					if (event.type === HttpEventType.DownloadProgress) {
						const downloadProgress = Math.round((100 * event.loaded) / event.total);
						const intervalId = setInterval(() => {
							this.incrementDownloadPercent(downloadProgress, isResponseDownloadEventCompleted);
							if (this.fileForDownload !== null && this.fileForDownload.downloadProgress === downloadProgress) {
								clearInterval(intervalId);
							}
							if (!isCompleted && this.fileForDownload !== null && this.fileForDownload.downloadProgress === 100) {
								isCompleted = true; // да не се трие защото сваля файла 100 пъти иначе
								setTimeout(() => this.openOrDownloadGeneratedApplication(print), 1000);
								setTimeout(() => this.fileForDownload = null, 2000);
								this.hasDownloadedApplication = true;
								if (this.isApprover) {
									this.applicationWasGeneratedForApprover.emit();
								}
							}
						}, 20);
						intervalIdToDelete = intervalId;
					} else if (event.type === HttpEventType.Response) {
						this.downloadedApplicationResponse = event;
					}
				},
				(error) => {
					this.isStartedDownloadingApplication = false;
					this.isDownloadingApplication = false;
					clearInterval(intervalIdToDelete);
					this.fileForDownload = null;
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_cannot_generate_application);
				}).add( () => this.isLoading = false);
	}

	incrementDownloadPercent(downloadProgress: number, isResponseDownloadEventCompleted: boolean): void {
		if (this.fileForDownload !== null && this.fileForDownload.downloadProgress >= downloadProgress) {
			isResponseDownloadEventCompleted = true;
		}
		if (this.fileForDownload !== null &&  !isResponseDownloadEventCompleted) {
			this.fileForDownload.downloadProgress++;
		}
	}

	openOrDownloadGeneratedApplication(print: boolean) {
		if (print) {
			const blob = new Blob([this.downloadedApplicationResponse.body], { type: 'application/pdf' });
			const blobUrl = URL.createObjectURL(blob);

			const iframe = document.createElement('iframe');
			iframe.style.visibility = 'hidden';
			iframe.src = blobUrl;
			document.body.appendChild(iframe);
			iframe.contentWindow.focus();
			iframe.contentWindow.print();
			this.isDownloadingApplication = false;
		} else {
			this.downloadFileOnDisk(this.downloadedApplicationResponse);
			this.generatedApplicationAction.emit(true);
		}
	}

	checkIfUserHasBeenGeneratedApplicationAndHaveAllRequiredDocuments() {
		let canUploadApplication: boolean;
		this.documentService
			.checkCanSubmitApplication(this.applicationId)
			.subscribe(
				(response) => {
					canUploadApplication = response;
					if (!canUploadApplication) {
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_cannot_upload_file,
							text: POP_UP_MESSAGES_KEYS.generate_application,
							type: PopUpTypes.ERROR
						});
						return;
					}
					if (this.filesFromUploadButton && canUploadApplication) {
						this.checkFilesAndAdd.emit(this.filesFromUploadButton);
						this.filesFromUploadButton = null;
					}
					if (this.filesFromDropAndDragUpload && canUploadApplication) {
						this.checkAreFilesAndEmit();
					}
				},
				(error) => {
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_cannot_upload_file);
					return;
				}
			);
	}

	setDocumentPagesOrder(event: CdkDragDrop<string[]>) {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;

		if (event.previousIndex === event.currentIndex) {
			this.isLoading = false;
			return;
		}
		moveItemInArray(this.uploadedPagesInfo, event.previousIndex, event.currentIndex);
		const pageIds = this.uploadedPagesInfo.map((page: DocumentPageInfo) => page.pageId);
		this.documentService
			.setDocumentPagesOrder(this.applicationId, this.attachedDocumentTypeId, pageIds)
			.subscribe(
				(response) => {
					this.isLoading = false;
				},
				(error) => {
					moveItemInArray(this.uploadedPagesInfo, event.currentIndex, event.previousIndex);
					this.isLoading = false;
				}
			);
	}

	saveAutoFixedImageAndShowReadonly() {
		if (this.uploadedPagesInfo[1] && this.uploadedPagesInfo[1].pageName.includes(AttachDocumentRowComponent.AUTO_EDITED)
			&& !this.srcPictureFromApproverMvrCheck) {
			this.hasPictureFromProcessing = false;
			this.showFinallyEditedPicture = true;
			this.imageBase64ForReadOnly = this.imageBase64AutoFixed;
			this.emitIsEditorVisible.emit(false);
			return;
		}
		if (this.isLoading) {
			return;
		}
		// TODO : check can delete one of loadings
		this.isLoading = true;
		this.showLoading = true;
		let fileForUpload: File = null;
		fetch(this.imageBase64AutoFixed)
			.then(result => result.blob())
			.then(blob => {
				const isAutoFixed = true;
				fileForUpload = new File([blob], this.applicationId + AttachDocumentRowComponent.AUTO_FIXED_JPG, { type: AttachDocumentRowComponent.IMAGE_JPG });
				const formData: FormData = new FormData();
				formData.append(AttachDocumentRowComponent.FILE, fileForUpload, fileForUpload.name);
				formData.append('autoFixed', JSON.stringify(isAutoFixed));

				this.documentService
					.saveEditedPicture(this.applicationId, this.attachedDocumentTypeId, formData)
					.subscribe(
						(pageId: number) => {
							this.imageBase64ForReadOnly = this.imageBase64AutoFixed;
							if (this.uploadedPagesInfo.length > 1) {
								this.uploadedPagesInfo.splice(1, 1);
							}
							this.uploadedPagesInfo.push(new DocumentPageInfo(fileForUpload));
							this.uploadedPagesInfo[1].pageId = pageId;
							this.hasPictureFromProcessing = false;
							this.showFinallyEditedPicture = true;
							this.showEditor = false;
							this.emitIsEditorVisible.emit(this.showEditor);
						},
						(error) => {
							PopUpService.showPopUp({
								header: POP_UP_MESSAGES_KEYS.error_cannot_upload_file,
								text: POP_UP_MESSAGES_KEYS.try_again_later,
								type: PopUpTypes.ERROR
							});
						}).add( () => {this.isLoading = false ; this.showLoading = false;});
			});
	}

	editPictureManually() {
		this.showFinallyEditedPicture = false;
		this.hasPictureFromProcessing = false;
		this.getOriginalPictureForEditor();
	}

	getOriginalPictureForEditor() {
		if (this.imageBase64OfOrigin) {
			this.showEditor = true;
			return;
		}
		if (this.uploadedPagesInfo[0].file) {
			const extension = this.uploadedPagesInfo[0].file.name.split('.').pop().toLowerCase();
			if (extension !== 'pdf') {
				this.showEditor = true;
				this.convertOriginalFileToBase64(this.uploadedPagesInfo[0].file);
			} else if (extension === 'pdf') {
				this.getOriginalPictureOfFaceOrSignature();
			}
		} else {
			this.getOriginalPictureOfFaceOrSignature();
		}
	}

	convertOriginalFileToBase64(file: File): void {
		const reader = new FileReader();
		reader.onload = this.handleOriginFile.bind(this);
		reader.readAsBinaryString(file);
	}

	handleOriginFile(event) {
		const binaryString = event.target.result;
		this.imageBase64OfOrigin = 'data:image/jpg;base64,' + btoa(binaryString);
	}

	cancelAutoFitPreview() {
		this.emitIsEditorVisible.emit(false);
		this.hasPictureFromProcessing = false;
		this.showFinallyEditedPicture = true;
	}

	getAutoFixedPicture() {
		this.showLoading = true;
		this.documentService
			.getAutoFixedPicture(this.applicationId, this.attachedDocumentTypeId)
			.subscribe(
				(response: HttpResponse<ArrayBuffer>) => {
					this.hasPictureFromProcessing = true;
					this.imageBase64AutoFixed = this.fileService.convertFromArrayBufferImageToBase64String(response.body);
				}).add( () => {
					this.showLoading = false;
					this.showEditor = false;
					this.showFinallyEditedPicture = false;});
	}

	getAutoFixedPictureFromMvrCheck() {
		const fileForUpload = new File([this.srcPictureFromApproverMvrCheck], this.applicationId + '_MVR_APPROVER_CHECK.jpg', { type: AttachDocumentRowComponent.IMAGE_JPG });
		const formData: FormData = new FormData();
		formData.append(AttachDocumentRowComponent.FILE, fileForUpload, fileForUpload.name);

		this.showLoading = true;
		this.documentService
			.getAutoFixedPictureFromMvrCheck(this.applicationId, this.attachedDocumentTypeId, formData)
			.subscribe(
				(response: HttpResponse<ArrayBuffer>) => {
					this.hasPictureFromProcessing = true;
					this.imageBase64AutoFixed = this.fileService.convertFromArrayBufferImageToBase64String(response.body);
				}).add( () => {
					this.showLoading = false;
					this.showEditor = false;
					this.showFinallyEditedPicture = false;});
	}

	getEditedPictureOfFaceOrSignature() {
		this.documentService
			.getEditedPicture(this.applicationId, this.attachedDocumentTypeId)
			.subscribe(
				(response: HttpResponse<ArrayBuffer>) => {
					this.imageBase64ForReadOnly = this.fileService.convertFromArrayBufferImageToBase64String(response.body);
					this.emitEditedPictureIsLoaded.emit(this.attachedDocumentTypeId);
				});
	}

	getOriginalPictureOfFaceOrSignature() {
		this.showLoading = true;
		this.documentService
			.getOriginalPictureOfFaceOrSignature(this.applicationId, this.attachedDocumentTypeId)
			.subscribe(
				(response: HttpResponse<ArrayBuffer>) => {
					this.hasPictureFromProcessing = false;
					this.imageBase64OfOrigin = this.fileService.convertFromArrayBufferImageToBase64String(response.body);
					this.showEditor = true;
				}).add( () => this.showLoading = false);
	}

}
