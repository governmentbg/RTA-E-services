import { ATTACHED_DOCUMENT_TYPE, AttachDocumentTypes } from '../../enums/attached-document-types';
import { ATTACHED_DOCUMENT_TYPE_ACTION_KEY } from '../../models/constants/attached-documents/attached-document-type-action-keys';
import { ATTACHED_DOCUMENT_TYPE_KEY } from '../../models/constants/attached-documents/attached-document-type-keys';
import { AttachedDocumentShortInfo } from '../../models/attached-document-short-info';
import { AttachedDocumentShortInfoDto } from '../../dtos/attached-document-short-info-dto';
import { AuthenticationService } from '../../../core/authentication/authentication.service';
import { Component, OnInit, Input, EventEmitter, Output, OnDestroy } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';
import { DEFAULT_POP_UPS } from '../../models/constants/pop-up-default-messages';
import { DocumentPageInfo } from '../../models/document-page-info';
import { DocumentService } from 'src/app/core/services/document.service';
import { HttpEventType } from '@angular/common/http';
import { Language } from 'angular-l10n';
import { POP_UP_MESSAGES_KEYS } from '../../models/constants/pop-up-messages-keys';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { PopUpTypes } from '../../enums/pop-up-types';
import { map } from 'rxjs/operators';
import { DocumentsDeclarationDto } from '../../dtos/documents-declaration-dto';
import { RequiredDocumentType } from '../../models/required-document-type';
import { S_VARIABLES } from '../../models/constants/s-variables';
import { FileService } from 'src/app/core/services/file.service';
import { PaymentService } from 'src/app/core/services/payment.service';
import { DocumentPageDto } from '../../dtos/document-page-dto';

@Component({
	selector: 'app-attach-single-document',
	templateUrl: './attach-single-document.component.html',
})
export class AttachSingleDocumentComponent implements OnInit, OnDestroy {
	public static MAX_UPLOAD_DOCUMENT_PAGE_SIZE = 2097152; // bytes
	public static MAX_UPLOAD_APPLICATION_DOCUMENT_SIZE = 20971520; // bytes
	private static MAX_UPLOAD_DOCUMENT_SIZE = 20971520;
	private static MAX_NAME_LENGTH = 64;

	@Input() isDraft: boolean;
	@Input() isReadOnly: boolean;
	@Input() hasAutoFixedPicturesFromMvr: boolean;
	@Input() srcPictureFromApproverMvrCheck: Blob;

	@Input() applicationId: number;
	@Input() applicationTypeId: number;
	@Input() attachedDocumentTypeId: number;
	@Input() isDqcCertificateAttachment: boolean;

	@Input() $isContinueButtonClicked: BehaviorSubject<boolean>;
	@Output() uploadedDocumentType: EventEmitter<RequiredDocumentType> = new EventEmitter<RequiredDocumentType>();
	@Output() certificateDeclaredStatus: EventEmitter<boolean> = new EventEmitter<boolean>();
	@Output() emitEditedPictureIsLoaded: EventEmitter<number> = new EventEmitter<number>();
	@Output() approverEditPicture: EventEmitter<Event> = new EventEmitter<Event>();
	@Output() approverGenerateApplication: EventEmitter<Event> = new EventEmitter();
	@Language() lang: string;
	isUserApplicant: boolean;
	isUserWithEFace: boolean;
	isApprover: boolean;
	actionKey: string;
	attachedDocumentTypeKey: string;
	documentCanHaveTwoSides: boolean;
	isDeclared = false;
	isError = false;
	hasAlreadyUploadedFiles: boolean; // not set to default value
	uploadedPagesInfo: DocumentPageInfo[] = [];
	documentSize = 0;
	isLoading = false;
	showLoading = false;
	attachedDocumentTypeEnum: AttachDocumentTypes = ATTACHED_DOCUMENT_TYPE;
	buttonContinueIsClickedSubscription: Subscription = null;
	isGeneratedApplication = false;
	isApplicationAttachment: boolean;
	isSignatureAttachment: boolean;
	isFaceAttachment: boolean;
	isPaymentAttachment: boolean;
	isEditorVisible: boolean;
	imageBase64AutoFixed: string;
	hasPictureFromProcessing: boolean;
	showEditor: boolean;
	currentDownloadProgress: number;

	documentType: RequiredDocumentType;

	constructor(
		private readonly documentService: DocumentService,
		private readonly paymentService: PaymentService,
		private readonly authenticationService: AuthenticationService,
		private readonly fileService: FileService,
	) { }

	ngOnInit(): void {
		const user = this.authenticationService.getAuthenticatedUser();
		this.isApprover = user.isApprover();
		this.isUserApplicant = user.isApplicant();
		this.isUserWithEFace = user.isEFaceApplicant();
		this.actionKey = ATTACHED_DOCUMENT_TYPE_ACTION_KEY[this.attachedDocumentTypeId];
		this.attachedDocumentTypeKey = ATTACHED_DOCUMENT_TYPE_KEY[this.attachedDocumentTypeId];
		this.setDocumentCanHaveTwoSides();
		this.setAttachedDocumentTypeBoolean();
		if (!this.isReadOnly || this.isFaceAttachment || this.isSignatureAttachment) {
			if (this.attachedDocumentTypeId !== ATTACHED_DOCUMENT_TYPE.DQC_CERTIFICATE && !this.isPaymentAttachment) {
				this.loadDocumentPagesInfo();
			} else if (this.isPaymentAttachment) {
				this.loadPaymentDocumentPagesInfo();
			}
		} else {
			this.hasAlreadyUploadedFiles = true;
		}
		if (!this.isReadOnly && !this.isPaymentAttachment && !this.isApprover) {
			this.setContinueSubscription();
		}
	}

	setContinueSubscription(): void {
		if (!this.isDqcCertificateAttachment  && this.isDraft) {
			this.buttonContinueIsClickedSubscription = this.$isContinueButtonClicked.subscribe((isContinueClicked: boolean) => {
				if (isContinueClicked) {
					this.emitUploadedDocumentTypeId();
				}
			});
		}
	}

	setAttachedDocumentTypeBoolean(): void {
		if (this.attachedDocumentTypeId ===  this.attachedDocumentTypeEnum.PICTURE_FACE) {
			this.isFaceAttachment = true;
		} else if (this.attachedDocumentTypeId ===  this.attachedDocumentTypeEnum.PICTURE_SIGNATURE) {
			this.isSignatureAttachment = true;
		} else if (this.attachedDocumentTypeId ===  this.attachedDocumentTypeEnum.APPLICATION) {
			this.isApplicationAttachment = true;
		} else if (this.attachedDocumentTypeId ===  this.attachedDocumentTypeEnum.PAYMENT_ORDER_PROCESSING_FEE
			|| this.attachedDocumentTypeId ===  this.attachedDocumentTypeEnum.PAYMENT_ORDER_PERSONALIZATION_FEE) {
			this.isPaymentAttachment = true;
		}
	}

	loadPaymentDocumentPagesInfo() {
		this.paymentService
			.getPaymentDocumentPagesInfo(this.applicationId, this.attachedDocumentTypeId)
			.subscribe(
				(data: DocumentPageDto[]) => {
					if (data) {
						this.hasAlreadyUploadedFiles = true;
						this.uploadedPagesInfo = data.map((page: DocumentPageDto) => new DocumentPageInfo(page));
						this.isDeclared = true;
						this.documentSize = 0;
						Array.from(this.uploadedPagesInfo).forEach(page => {
							this.documentSize = this.documentSize + page.pageFileSize;
						});
					} else {
						this.hasAlreadyUploadedFiles = false;
					}
				},
				(error) => {
					this.hasAlreadyUploadedFiles = false;
				}
			);
	}

	loadDocumentPagesInfo() {
		this.documentService
			.getDocumentPagesInfo(this.applicationId, this.attachedDocumentTypeId)
			.pipe(map((data: AttachedDocumentShortInfoDto) => {
				if (data) {
					return new AttachedDocumentShortInfo(data);
				}
				return null;
			}))
			.subscribe(data => {
				if (data) {
					this.getPagesInfo(data);
					this.hasAlreadyUploadedFiles = true;
					if (this.isDqcCertificateAttachment) {
						this.certificateDeclaredStatus.emit(data.declared);
						this.uploadedDocumentType.emit(new RequiredDocumentType({
							id: this.attachedDocumentTypeId,
							type: this.attachedDocumentTypeKey
						}));
					}
				} else {
					this.hasAlreadyUploadedFiles = false;
				}
			});
	}

	getPagesInfo(data: AttachedDocumentShortInfo) {
		this.uploadedPagesInfo = data.pagesInfo;
		this.isDeclared = data.declared;
		this.documentSize = 0;
		Array.from(this.uploadedPagesInfo).forEach(page => {
			this.documentSize = this.documentSize + page.pageFileSize;
		});
	}

	declareToggle() {
		if (this.isLoading || !this.hasAlreadyUploadedFiles) {
			return;
		}
		this.isLoading = true;
		this.isDeclared = !this.isDeclared;
		const attachedDocumentTypeIds: number[] = [];
		attachedDocumentTypeIds.push(this.attachedDocumentTypeId);
		const dto = new DocumentsDeclarationDto(this.isDeclared, attachedDocumentTypeIds);
		this.documentService
			.declareDocuments(this.applicationId, dto)
			.subscribe(
				(response) => {
					if (this.isDeclared && this.hasAlreadyUploadedFiles) {
						this.isError = false;
					}
				},
				(error) => {
					this.isDeclared = !this.isDeclared;
					PopUpService.showPopUp(DEFAULT_POP_UPS.error_could_not_declare_document);
				}
			).add(() => this.isLoading = false);
	}

	uploadFiles(uploadedFiles: File[]) {
		const files = uploadedFiles;
		if (this.attachedDocumentTypeId === ATTACHED_DOCUMENT_TYPE.APPLICATION) {
			if (this.isApplicationFileCorrect(files[0])) {
				this.uploadedPagesInfo.push(new DocumentPageInfo(files[0]));
				this.saveFiles();
			}
			return;
		} else if (this.attachedDocumentTypeId === ATTACHED_DOCUMENT_TYPE.PICTURE_FACE
			|| this.attachedDocumentTypeId === ATTACHED_DOCUMENT_TYPE.PICTURE_SIGNATURE) {
				if (this.isFileCorrect(uploadedFiles[0])) {
					this.checkUploadedPicturePixelsSizeAreCorrectAndSave(uploadedFiles[0]);
				}
				return;
		} else {
			Array.from(files).forEach(file => {
				if (this.isFileCorrect(file)) {
					this.uploadedPagesInfo.push(new DocumentPageInfo(file));
					this.isError = false;
				}
			});
		}

		if (this.uploadedPagesInfo.length > 0) {
			this.saveFiles();
		}
	}

	deleteDocumentPage(pageInfo: DocumentPageInfo) {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		PopUpService.showPopUp(DEFAULT_POP_UPS.delete);
		const currentSubscription = PopUpService.subscribeToPopUpResponse(
			(hasConfirmed) => {
				if (hasConfirmed) {
					this.documentService
						.removeDocumentPage(this.applicationId, this.attachedDocumentTypeId, pageInfo.pageId)
						.subscribe(
							(success) => {
								const index = this.uploadedPagesInfo.indexOf(pageInfo);
								this.uploadedPagesInfo.splice(index, 1);
								this.documentSize = this.documentSize - pageInfo.pageFileSize;
								if (this.uploadedPagesInfo.length < 1) {
									this.hasAlreadyUploadedFiles = false;
									this.isDeclared = false;
									this.uploadedDocumentType.emit(new RequiredDocumentType({
										id: 0,
										type: ''
									}));
								}
							},
							(error) => {
								PopUpService.showPopUp(DEFAULT_POP_UPS.error_could_not_delete_file);
							}
						).add(() => this.isLoading = false);
				}
				currentSubscription.unsubscribe();
				this.isLoading = false;
			}
		);
	}

	deleteDocument() {
		PopUpService.showPopUp(DEFAULT_POP_UPS.delete);
		const currentSubscription = PopUpService.subscribeToPopUpResponse(
			(hasConfirmed) => {
				this.showEditor = false;
				if (hasConfirmed) {
					this.documentService
						.removeDocument(this.applicationId, this.attachedDocumentTypeId)
						.subscribe(
							(success) => {
								this.uploadedPagesInfo = [];
								this.hasAlreadyUploadedFiles = false;
								this.isDeclared = false;
								this.uploadedDocumentType.emit(new RequiredDocumentType({
									id: 0,
									type: ''
								}));
								this.hasPictureFromProcessing = false;
								this.imageBase64AutoFixed = null;
							},
							(error) => {
								PopUpService.showPopUp(DEFAULT_POP_UPS.error_could_not_delete_file);
							}
						);
				}
				currentSubscription.unsubscribe();
			});
	}

	setDocumentCanHaveTwoSides(): void {
		if (this.attachedDocumentTypeId === ATTACHED_DOCUMENT_TYPE.IDENTITY_DOCUMENT
			|| this.attachedDocumentTypeId === ATTACHED_DOCUMENT_TYPE.IDENTITY_DOCUMENT_AUTHORIZED_PERSON
			|| this.attachedDocumentTypeId === ATTACHED_DOCUMENT_TYPE.DRIVING_LICENCE
			|| this.attachedDocumentTypeId === ATTACHED_DOCUMENT_TYPE.DQC_EU
		) {
			this.documentCanHaveTwoSides = true;
			return;
		}
		this.documentCanHaveTwoSides = false;
	}


	isApplicationFileCorrect(file: File): boolean {
		if (file.name.match(/\./g).length > 1) { // not more than one dot
			PopUpService.showPopUp(DEFAULT_POP_UPS.error_file_name_not_correct);
			return false;
		}
		const extension = file.name.split('.').pop().toLowerCase();
		if (this.isUserApplicant && extension !== 'pdf') {
			PopUpService.showPopUp({
				header: POP_UP_MESSAGES_KEYS.error_only_upload_type_file,
				extraInfo: 'PDF',
				type: PopUpTypes.ERROR
			});
			return false;
		} else if (!this.isUserApplicant && 
			extension !== 'jpg' && extension !== 'jpeg' &&
				extension !== 'png' && extension !== 'pdf') {
			PopUpService.showPopUp({
				header: POP_UP_MESSAGES_KEYS.error_only_upload_type_file,
				extraInfo: ' JPG, JPEG, PNG, PDF',
				type: PopUpTypes.ERROR
			});
			return false;
		}

		if (file.size > AttachSingleDocumentComponent.MAX_UPLOAD_APPLICATION_DOCUMENT_SIZE) {
			PopUpService.showPopUp({
				header: POP_UP_MESSAGES_KEYS.error_max_upload_size,
				extraInfo: '20MB',
				type: PopUpTypes.ERROR
			});
			return false;
		}
		if (file.name.length > AttachSingleDocumentComponent.MAX_NAME_LENGTH) {
			PopUpService.showPopUp(DEFAULT_POP_UPS.error_file_name_too_long);
			return false;
		}
		return true;
	}

	isFileCorrect(file: File): boolean {
		const existingFile = this.findFile(file);
		if (existingFile) {
			PopUpService.showPopUp({
				header: POP_UP_MESSAGES_KEYS.error_file_already_uploaded,
				extraInfo: file.name,
				type: PopUpTypes.ERROR
			});
			return false;
		}
		if (!file.name.includes('.')) { // missing dot
			PopUpService.showPopUp({
				header: POP_UP_MESSAGES_KEYS.error_file_name_not_correct,
				extraInfo: file.name,
				type: PopUpTypes.ERROR
			});
			return false;
		}
		if (file.name.match(/\./g).length > 1) { // more than one dot
			PopUpService.showPopUp({
				header: POP_UP_MESSAGES_KEYS.error_file_name_not_correct,
				extraInfo: file.name,
				type: PopUpTypes.ERROR
			});
			return false;
		}
		const extension = file.name.split('.').pop().toLowerCase().trim();
		if (
			extension !== 'jpg' && extension !== 'jpeg' &&
			extension !== 'png' && extension !== 'pdf'
		) {
			PopUpService.showPopUp({
				header: POP_UP_MESSAGES_KEYS.error_only_upload_type_file,
				extraInfo: ' JPG, JPEG, PNG, PDF',
				type: PopUpTypes.ERROR
			});
			return false;
		}
		if (file.size > AttachSingleDocumentComponent.MAX_UPLOAD_DOCUMENT_PAGE_SIZE) {
			PopUpService.showPopUp({
				header: POP_UP_MESSAGES_KEYS.error_max_upload_size,
				extraInfo: ' 2MB',
				type: PopUpTypes.ERROR
			});
			return false;
		}
		if (file.size + this.documentSize > AttachSingleDocumentComponent.MAX_UPLOAD_DOCUMENT_SIZE) {
			PopUpService.showPopUp({
				header: POP_UP_MESSAGES_KEYS.error_max_upload_size,
				extraInfo: ' 20MB',
				type: PopUpTypes.ERROR
			});
			return false;
		}
		if (file.name.length > AttachSingleDocumentComponent.MAX_NAME_LENGTH) {
			PopUpService.showPopUp(DEFAULT_POP_UPS.error_file_name_too_long);
			return false;
		}

		return true;
	}

	checkUploadedPicturePixelsSizeAreCorrectAndSave(file: File): void {
		const extension = file.name.split('.').pop().toLowerCase();

		if (extension !== 'pdf') {
			const reader = new FileReader();
			reader.readAsDataURL(file);
			reader.onload = () => {
				const img = new Image();
				img.src = reader.result as string;
				img.onload = () => {
					const height = img.naturalHeight;
					const width = img.naturalWidth;
					if ((this.attachedDocumentTypeId === ATTACHED_DOCUMENT_TYPE.PICTURE_FACE
						&& (height < S_VARIABLES.MIN_FACE_PICTURE_HEIGHT || width < S_VARIABLES.MIN_FACE_PICTURE_WIDTH))
							|| (this.attachedDocumentTypeId === ATTACHED_DOCUMENT_TYPE.PICTURE_SIGNATURE
								&& (height < S_VARIABLES.MIN_SIGNATURE_PICTURE_HEIGHT || width < S_VARIABLES.MIN_SIGNATURE_PICTURE_WIDTH))) {
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_picture_pixels_size_not_correct,
							type: PopUpTypes.ERROR
						});
						return;
					} else {
						this.uploadedPagesInfo.push(new DocumentPageInfo(file));
						this.isError = false;
						this.saveOriginalAndGetAutoFixedPicture();
					}
				};
			};
		} else {
			this.uploadedPagesInfo.push(new DocumentPageInfo(file));
			this.isError = false;
			this.saveOriginalAndGetAutoFixedPicture();
		}
	}

	saveOriginalAndGetAutoFixedPicture() {
		if (this.showLoading) {
			return;
		}
		this.showLoading = true;
		const isResponseDownloadEventCompleted = false;
		let intervalIdToDelete = null;

		const formData: FormData = new FormData();
		formData.append('file', this.uploadedPagesInfo[0].file, this.uploadedPagesInfo[0].pageName);

		this.documentService
			.saveOriginalAndGetAutoFixedPicture(this.applicationId, this.attachedDocumentTypeId, formData)
			.subscribe(
				(event) => {
					if (event.type === HttpEventType.DownloadProgress) {
						const downloadProgress = Math.round((100 * event.loaded) / event.total);
						const intervalId = setInterval(() => {
							this.incrementDownloadPercent(downloadProgress, isResponseDownloadEventCompleted);
							if (this.uploadedPagesInfo[0].uploadProgress === downloadProgress) {
								clearInterval(intervalId);
							}
						}, 10);
						intervalIdToDelete = intervalId;
					} else if (event.type === HttpEventType.Response) {
						setTimeout(() => {
							this.imageBase64AutoFixed = this.fileService.convertFromArrayBufferImageToBase64String(event.body);
							this.hasAlreadyUploadedFiles = true;
							this.hasPictureFromProcessing = true;
							this.isEditorVisible = true;
						}, 2000);
					}
				},
				(errorResponse) => {
					if (intervalIdToDelete) {
						clearInterval(intervalIdToDelete);
					}
					const filename = this.uploadedPagesInfo[0].file.name;
					this.uploadedPagesInfo.splice(0, 1);
					const error = this.decodeErrorMessage(errorResponse.error);
					if (error === 'NotExactlyOneFaceDetectedException') {
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_missing_face_on_picture,
							type: PopUpTypes.ERROR
						});
						return;
					} else if (error === 'FacePictureNotCorrectException') {
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_upload_another_file_as_in_instructions,
							type: PopUpTypes.ERROR
						});
						return;
					} else if (error === 'SignatureThicknessException') {
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_photo_signature_thickness,
							type: PopUpTypes.ERROR
						});
						return;
					} else if (error === 'SignaturePictureNotCorrectException') {
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_missing_signature_on_picture,
							type: PopUpTypes.ERROR
						});
						return;
					} else if (error === 'NoImageOrPdfFileException') {
						PopUpService.showPopUp({
							header: POP_UP_MESSAGES_KEYS.error_cannot_upload_file,
							extraInfo: filename,
							text: POP_UP_MESSAGES_KEYS.error_file_has_wrong_content,
							type: PopUpTypes.ERROR
						});
						return;
					}
				}).add(() => this.showLoading = false);
	}

	incrementDownloadPercent(downloadProgress: number, isResponseDownloadEventCompleted: boolean): void {
		if (this.uploadedPagesInfo[0].uploadProgress >= downloadProgress) {
			isResponseDownloadEventCompleted = true;
		}
		if (!isResponseDownloadEventCompleted) {
			this.uploadedPagesInfo[0].uploadProgress++;
		}
	}

	decodeErrorMessage(response: ArrayBuffer): string {
		const decodedString = String.fromCharCode.apply(null, new Uint8Array(response));
		const obj = JSON.parse(decodedString);
		return obj.error;
	}

	findFile(file: File) {
		return this.uploadedPagesInfo.find((existingFile: DocumentPageInfo) => {
			return (
				existingFile.pageName === file.name &&
				existingFile.pageFileSize === file.size
			);
		});
	}

	emitUploadedDocumentTypeId() {
		if (this.isLoading || this.isEditorVisible) {
			this.isError = true;
			this.uploadedDocumentType.emit(new RequiredDocumentType({
				id: 0,
				type: ''
			}));
			return;
		} else if (this.attachedDocumentTypeId === ATTACHED_DOCUMENT_TYPE.APPLICATION) {
			if ((!this.isUserWithEFace && this.uploadedPagesInfo.length < 1) || (this.isUserWithEFace && !this.isGeneratedApplication)) {
				this.isError = true;
				this.uploadedDocumentType.emit(new RequiredDocumentType({
					id: 0,
					type: ''
				}));
				return;
			} else {
				this.checkCanSubmitApplicationAndEmit();
				return;
			}
		} else {
			if (this.uploadedPagesInfo.length < 1) {
				this.isError = true;
				this.uploadedDocumentType.emit(new RequiredDocumentType({
					id: 0,
					type: ''
				}));
				return;
			}
			if (this.isUserApplicant && !this.isUserWithEFace && !this.isDeclared) {
					this.isError = true;
					this.uploadedDocumentType.emit(new RequiredDocumentType({
						id: 0,
						type: ''
					}));
					return;
			}
			this.isError = false;
			this.hasAlreadyUploadedFiles = true;
			this.uploadedDocumentType.emit(new RequiredDocumentType({
				id: this.attachedDocumentTypeId,
				type: this.attachedDocumentTypeKey
			}));
		}
	}

	saveFiles() {
		if (this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.uploadedPagesInfo
			.filter((page: DocumentPageInfo) => !page.pageId)
			.forEach((page: DocumentPageInfo) => {
				const isResponseEventCompleted = false;
				const formData: FormData = new FormData();
				formData.append('file', page.file, page.pageName);
				let intervalIdToDelete = null;
				this.documentService
					.saveDocument(this.applicationId, this.attachedDocumentTypeId, formData)
					.subscribe(
						(event) => {
							if (event.type === HttpEventType.UploadProgress) {
								const progress = Math.round((100 * event.loaded) / event.total);
								const intervalId = setInterval(() => {
									this.incrementUploadPercent(progress, page, isResponseEventCompleted);
									if (page.uploadProgress === 100) {
										clearInterval(intervalId);
										this.hasAlreadyUploadedFiles = true;
										this.isError = false;
										if (this.isDqcCertificateAttachment) {
											this.uploadedDocumentType.emit(new RequiredDocumentType({
												id: this.attachedDocumentTypeId,
												type: this.attachedDocumentTypeKey}));
										}
									}
								}, 20);
								intervalIdToDelete = intervalId;
							} else if (event.type === HttpEventType.Response) {
								const dto: number = event.body;
								page.pageId = dto;
								if (this.isDqcCertificateAttachment) {
									this.uploadedDocumentType.emit(new RequiredDocumentType({
										id: this.attachedDocumentTypeId,
										type: this.attachedDocumentTypeKey
									}));
								}
								setTimeout(() => this.hasAlreadyUploadedFiles = true, 2000);
							}
						},
						(errorResponse) => {
							if (intervalIdToDelete) {
								clearInterval(intervalIdToDelete);
							}
							const fileName = page.pageName;
							const index = this.uploadedPagesInfo.indexOf(page);
							this.uploadedPagesInfo.splice(index, 1);
							this.isError = true;
							if (errorResponse.error) {
								if (errorResponse.error.error === 'InvalidPdfSignatureException') {
										PopUpService.showPopUp({
											header: POP_UP_MESSAGES_KEYS.error_cannot_upload_file,
											extraInfo: fileName,
											text: POP_UP_MESSAGES_KEYS.upload_pdf_with_valid_signature,
											type: PopUpTypes.ERROR
										});
								} else if (errorResponse.error.error === 'DigitalSignatureVerificationServiceException'
										|| errorResponse.error === 'ProxyException') {
										PopUpService.showPopUp({
											header: POP_UP_MESSAGES_KEYS.error_cannot_upload_file,
											extraInfo: fileName,
											text: POP_UP_MESSAGES_KEYS.try_again_later,
											type: PopUpTypes.ERROR
										});
								} else if (errorResponse.error.error === 'UploadedFileException'
									&& this.attachedDocumentTypeId === ATTACHED_DOCUMENT_TYPE.APPLICATION) {
										PopUpService.showPopUp({
											header: POP_UP_MESSAGES_KEYS.error_cannot_upload_file,
											extraInfo: fileName,
											text: POP_UP_MESSAGES_KEYS.error_file_empty_or_not_pdf,
											type: PopUpTypes.ERROR
										});
								} else if (errorResponse.error.error === 'NoImageOrPdfFileException') {
										PopUpService.showPopUp({
											header: POP_UP_MESSAGES_KEYS.error_cannot_upload_file,
											extraInfo: fileName,
											text: POP_UP_MESSAGES_KEYS.error_file_has_wrong_content,
											type: PopUpTypes.ERROR
										});
								} else {
										PopUpService.showPopUp({
											header: POP_UP_MESSAGES_KEYS.error_cannot_upload_file,
											extraInfo: fileName,
											text: POP_UP_MESSAGES_KEYS.try_again_later,
											type: PopUpTypes.ERROR
										});
								}
							}
						}
					).add(() => this.isLoading = false);
			});
	}

	incrementUploadPercent(progress: number, page: DocumentPageInfo, isResponseEventCompleted: boolean): void {
		if (page.uploadProgress >= progress) {
			isResponseEventCompleted = true;
		}
		if (page.uploadProgress === 100) {
			isResponseEventCompleted = true;
		}
		if (!isResponseEventCompleted) {
			page.uploadProgress++;
		}
	}

	checkCanSubmitApplicationAndEmit() {
		this.documentService
			.checkCanSubmitApplication(this.applicationId)
			.subscribe(
				(canContinue: boolean) => {
					if (canContinue) {
						this.hasAlreadyUploadedFiles = true;
						this.isError = false;
						PopUpService.showPopUp(DEFAULT_POP_UPS.warning_application_will_be_submitted);
						const currentSubscription = PopUpService.subscribeToPopUpResponse(
							(hasConfirmed) => {
								if (hasConfirmed) {
									this.uploadedDocumentType.emit(new RequiredDocumentType({
										id: this.attachedDocumentTypeId,
										type: this.attachedDocumentTypeKey
									}));
								}
								currentSubscription.unsubscribe();
							});
					} else {
						this.isError = true;
						this.hasAlreadyUploadedFiles = false;
					}
				},
				(error) => {
					this.isError = true;
					PopUpService.showPopUp(DEFAULT_POP_UPS.error);
				}
			);
	}

	checkIsGeneratedApplicationAction(isGenerated: boolean) {
		this.isGeneratedApplication = isGenerated;
		this.isError = false;
	}

	applicationWasGeneratedForApprover() {
		this.approverGenerateApplication.emit();
	}

	setIsEditorVisible(isVisible: boolean) {
		this.isEditorVisible = isVisible;
		if (!this.isEditorVisible) {
			this.isError = false;
		}
		if (this.isApprover && !this.isEditorVisible) {
			this.isReadOnly = true;
			this.approverEditPicture.emit();
		}
	}

	editedPictureIsLoaded(docTypeId: number) {
		this.emitEditedPictureIsLoaded.emit(docTypeId);
	}

	ngOnDestroy(): void {
		if (this.buttonContinueIsClickedSubscription) {
			this.buttonContinueIsClickedSubscription.unsubscribe();
		}
	}
}
