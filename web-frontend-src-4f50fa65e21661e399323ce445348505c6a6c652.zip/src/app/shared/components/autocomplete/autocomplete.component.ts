import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { FormControl } from '@angular/forms';
import { NomenclatureService } from 'src/app/core/services/nomenclature.service';
import { Subscription } from 'rxjs';
import { startWith, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { AutocompleteDto } from '../../dtos/autocomplete-dto';
import { LocaleService } from 'angular-l10n';
import { Region } from '../../models/region';

@Component({
	selector: 'app-autocomplete',
	templateUrl: './autocomplete.component.html'
})
export class AutocompleteComponent implements OnInit, OnDestroy {
	@Input() controller: FormControl;
	@Input() isCountry: boolean;
	@Input() isIssuer: boolean;
	@Input() isRegion: boolean;
	@Input() isMunicipality: boolean;
	@Input() isCity: boolean;
	@Input() isDocumentType: boolean;

	@Input() region: Region;

	isSelected: boolean;
	newItems: object[] = this._filter('');
	autocompleteDto: AutocompleteDto;

	private subscriptions: Subscription[] = [];

	constructor(
		private nomenclatureService: NomenclatureService,
		private locale: LocaleService
	) { }

	ngOnInit(): void {
		this.autocompleteDto = new AutocompleteDto();
		if (this.controller.value) {
			this.isSelected = true;
		}
		this.subscriptions.push(this.controller.valueChanges
			.pipe(
				debounceTime(300),
				distinctUntilChanged(),
				startWith(''),
			).subscribe(value => {
				this._filter(value);
			}));
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach(subscription => {
			subscription.unsubscribe();
		});
	}

	unSelect() {
		if (this.isSelected) {
			this.controller.setValue('');
		}
		this.isSelected = !this.isSelected;
	}

	triggerAutocomplete() {
		if (this.controller.value === '' || this.controller.value === null) {
			this.controller.setValue('');
		}
	}

	getDisplayText(option) {
		return option?.value;
	}

	// tslint:disable-next-line: no-any
	private _filter(value: any): object[] {
		if (!(value instanceof Object)) {
			if (this.isCountry) {
				this.autocompleteDto.langCode = this.locale.getCurrentLanguage();
				this.autocompleteDto.phrase = value;
				this.nomenclatureService.getCountriesByAutocompletePhrase(this.autocompleteDto).subscribe(
					(results) => {
						this.newItems = results;

					});
			} else if (this.isIssuer) {
				this.autocompleteDto.langCode = this.locale.getCurrentLanguage();
				this.autocompleteDto.phrase = value;
				this.nomenclatureService.getIssuersByAutocompletePhrase(this.autocompleteDto).subscribe(
					(results) => {
						this.newItems = results;

					});
			} else if (this.isRegion) {
				this.autocompleteDto.langCode = this.locale.getCurrentLanguage();
				this.autocompleteDto.phrase = value;
				this.nomenclatureService.getRegionsByAutocompletePhrase(this.autocompleteDto).subscribe(
					(results) => {
						this.newItems = results;

					});
			} else if (this.isMunicipality && this.region) {
				this.autocompleteDto.langCode = this.locale.getCurrentLanguage();
				this.autocompleteDto.phrase = value;
				this.nomenclatureService.getMunicipalityByRegionAndAutocompletePhrase(this.region.regionCode, this.autocompleteDto).subscribe(
					(results) => {
						this.newItems = results;

					});
			} else if (this.isCity && this.region) {
				this.autocompleteDto.langCode = this.locale.getCurrentLanguage();
				this.autocompleteDto.phrase = value;
				this.nomenclatureService.getCitiesByRegionAndAutocompletePhrase(this.region.regionCode, this.autocompleteDto).subscribe(
					(results) => {
						this.newItems = results;

					});
			} else if (this.isDocumentType) {
				this.autocompleteDto.langCode = this.locale.getCurrentLanguage();
				this.autocompleteDto.phrase = value;
				this.nomenclatureService.getDocumentTypesByAutocompletePhrase(this.autocompleteDto).subscribe(
					(results) => {
						this.newItems = results;
					});
			}
		} else if (value instanceof Object) {
			this.isSelected = true;

		}
		return this.newItems;
	}
}
