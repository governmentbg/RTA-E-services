import { Component, OnInit, Input } from '@angular/core';
import { Address } from '../../models/address';

@Component({
	selector: 'app-display-address',
	templateUrl: './display-address.component.html'})
export class DisplayAddressComponent implements OnInit {
	@Input() public address: Address;
	showAddressDetails = false;
	showCountryOnly = false;

	constructor() { }

	ngOnInit(): void {
		if (this.address?.country?.key) {
			this.showCountryOnly = true;
		} else if (this.address?.postalCode || this.address?.street || this.address?.streetNumber 
			|| this.address?.building || this.address?.entrance || this.address?.apartment) {
			this.showAddressDetails = true;
		}
	}
}
