import { Component, OnInit, Input } from '@angular/core';
import { NamesForm } from '../../utils/names-form';
import { NamesDto } from '../../dtos/names-dto';

@Component({
	selector: 'app-names',
	templateUrl: './names.component.html'
})
export class NamesComponent implements OnInit {
	@Input() namesForm: NamesForm;
	@Input() namesDto: NamesDto;
	@Input() canEdit: boolean;

	showReadOnlyNames: boolean;

	constructor() { }

	ngOnInit(): void {
		if (this.namesForm !== undefined && this.namesForm.firstNameCyr.value && !this.canEdit) {
			this.showReadOnlyNames = true;
			this.namesDto = this.namesForm.toRequestDto();
		}

		if (this.namesDto && !this.canEdit) {
			this.showReadOnlyNames = true;
		}
	}

}
