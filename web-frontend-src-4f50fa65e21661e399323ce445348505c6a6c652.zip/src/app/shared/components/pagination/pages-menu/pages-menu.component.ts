import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { Pagination } from 'src/app/shared/pagination/pagination';
import { Subscription } from 'rxjs';

@Component({
	selector: 'app-pages-menu',
	templateUrl: './pages-menu.component.html',
})
export class PagesMenuComponent implements OnInit, OnDestroy {

	@Input()
	pagination: Pagination;

	public pageArray: number[];
	public isInTheMiddle: boolean;
	public hasReachedLast: boolean;
	public morePages: boolean;

	private subscriptions: Subscription[] = [];

	ngOnInit(): void {
		this.isInTheMiddle = false;
		this.hasReachedLast = false;
		this.morePages = true;
		this.setPageNumbers();
	}

	setPageNumbers() {
		const MAX_FIRST_PAGE_NUMBERS = 8;
		const MAX_LAST_PAGE_NUMBERS = 5;

		this.subscriptions.push(this.pagination.subscribeToParamsChanges(() => {
			let currentPage: number;
			currentPage = this.pagination.paginationParams.page;
			if (this.pagination.getTotalPages() === 1) {
				this.isInTheMiddle = false;
				this.hasReachedLast = true;
				this.morePages = false;
				this.pageArray = [];
			} else if (this.pagination.getTotalPages() <= MAX_FIRST_PAGE_NUMBERS && this.pagination.getTotalPages() > 1) {
				this.pageArray = [];
				this.isInTheMiddle = false;
				this.hasReachedLast = true;
				this.morePages = false;
				let i = 2;
				while (i <= this.pagination.getTotalPages()) {
					this.pageArray.push(i++);
				}
			} else if (this.pagination.paginationParams.page >= MAX_FIRST_PAGE_NUMBERS
				&& currentPage < this.pagination.getTotalPages() - MAX_LAST_PAGE_NUMBERS) {
				this.isInTheMiddle = true;
				this.hasReachedLast = false;
				this.morePages = true;
				this.pageArray = [];
				this.pageArray = [
					currentPage - 2,
					currentPage - 1,
					currentPage,
					currentPage + 1,
					currentPage + 2,
				];
			} else if (currentPage >= this.pagination.getTotalPages() - MAX_LAST_PAGE_NUMBERS) {
				this.isInTheMiddle = false;
				this.hasReachedLast = true;
				this.morePages = true;
				this.pageArray = [];
				this.pageArray = [
					this.pagination.getTotalPages() - 5,
					this.pagination.getTotalPages() - 4,
					this.pagination.getTotalPages() - 3,
					this.pagination.getTotalPages() - 2,
					this.pagination.getTotalPages() - 1,
				];
			} else if (this.pagination.paginationParams.page <= MAX_FIRST_PAGE_NUMBERS && this.pagination.getTotalPages() > MAX_FIRST_PAGE_NUMBERS) {
				this.hasReachedLast = false;
				this.isInTheMiddle = false;
				this.morePages = true;
				this.pageArray = [];
				this.pageArray = [2, 3, 4, 5, 6, 7];
			}
		}));
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach(sub => sub.unsubscribe);
	}
}
