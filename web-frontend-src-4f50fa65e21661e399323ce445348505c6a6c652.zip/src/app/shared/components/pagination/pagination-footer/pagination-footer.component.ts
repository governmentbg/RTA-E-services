import { Component, Input, OnInit } from '@angular/core';
import { Pagination } from 'src/app/shared/pagination/pagination';
import { Subscription } from 'rxjs';

@Component({
	selector: 'app-pagination-footer',
	templateUrl: './pagination-footer.component.html',
})
export class PaginationFooterComponent {

	@Input()
	pagination: Pagination;
}
