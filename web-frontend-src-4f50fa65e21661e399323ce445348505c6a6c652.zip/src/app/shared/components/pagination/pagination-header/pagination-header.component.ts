import { Component, Input } from '@angular/core';
import { Pagination } from 'src/app/shared/pagination/pagination';

@Component({
	selector: 'app-pagination-header',
	templateUrl: './pagination-header.component.html',
})
export class PaginationHeaderComponent {

	@Input()
	pagination: Pagination;
}
