import { Component, OnInit, Input, EventEmitter, Output, OnChanges} from '@angular/core';
import { ImageCroppedEvent, ImageTransform, CropperPosition } from 'ngx-image-cropper';
import { ATTACHED_DOCUMENT_TYPE } from '../../enums/attached-document-types';
import { DocumentPageInfo } from '../../models/document-page-info';
import { APPLICATION_TYPE } from '../../enums/application-types';
import { S_VARIABLES } from '../../models/constants/s-variables';

@Component({
	selector: 'app-photo-editor',
	templateUrl: './photo-editor.component.html'
})
export class PhotoEditorComponent implements OnInit, OnChanges {
	// min px size of static cropped picture in html
	private static readonly ADR_CARD_FACE_PICTURE_WIDTH = 463;
	private static readonly ADR_CARD_FACE_PICTURE_HEIGHT = 581;
	private static readonly DQC_FACE_PICTURE_WIDTH = 394;
	private static readonly DQC_FACE_PICTURE_HEIGHT = 453;
	private static readonly TACHO_CARD_FACE_PICTURE_WIDTH = 461;
	private static readonly TACHO_CARD_FACE_PICTURE_HEIGHT = 574;

	@Input() applicationTypeId: number;
	@Input() documentTypeId: number;
	@Input() uploadedPagesInfo: DocumentPageInfo[];
	@Input() imageBase64: string;
	@Input() hasAlreadyUploadedFile: boolean;
	@Output() emitEditedImageAsBase64: EventEmitter<string> = new EventEmitter();
	@Output() emitShowAutoFixImage: EventEmitter<Event> = new EventEmitter();
	@Output() emitExitEditor: EventEmitter<Event> = new EventEmitter();
	// cropper params
	maintainAspectRatio: boolean;
	cropperInput: string;
	croppedImage = '';
	cropperMinWidth: number;
	cropperMinHeight: number;
	pictureRatio: number;
	transform: ImageTransform = {rotate: 0, scale: 1};
	cropper: CropperPosition = {x1: 0, y1: 0, x2: 0, y2: 0};

	rotate = 0;
	scale = 1;
	initCropperPosition: CropperPosition;
	initCropper = true;
	canZoomIn = true;
	currentCropperH: number;
	currentCropperW: number;
	isSignature: boolean;
	isFace: boolean;
	backgroundColor = S_VARIABLES.BACKGROUND_COLOR_WHITE;
	isLoading = false;
	constructor( ) { }

	ngOnInit(): void {
		this.setRatio();
	}

	ngOnChanges(): void {
		if (this.imageBase64) {
			this.cropperInput = this.imageBase64;
		}
	}

	setRatio() {
		if (this.documentTypeId === ATTACHED_DOCUMENT_TYPE.PICTURE_SIGNATURE) {
			this.pictureRatio = S_VARIABLES.MIN_SIGNATURE_PICTURE_WIDTH / S_VARIABLES.MIN_SIGNATURE_PICTURE_HEIGHT;
			this.cropperMinWidth = S_VARIABLES.MIN_SIGNATURE_PICTURE_WIDTH;
			this.cropperMinHeight = S_VARIABLES.MIN_SIGNATURE_PICTURE_HEIGHT;
			this.isSignature = true;
			this.maintainAspectRatio = false;
		} else if (this.documentTypeId === ATTACHED_DOCUMENT_TYPE.PICTURE_FACE) {
			if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_ADR_CARD) {
				this.pictureRatio = PhotoEditorComponent.ADR_CARD_FACE_PICTURE_WIDTH / PhotoEditorComponent.ADR_CARD_FACE_PICTURE_HEIGHT;
				this.cropperMinWidth = PhotoEditorComponent.ADR_CARD_FACE_PICTURE_WIDTH;
				this.cropperMinHeight = PhotoEditorComponent.ADR_CARD_FACE_PICTURE_HEIGHT;
			} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_DQC) {
				this.pictureRatio = PhotoEditorComponent.DQC_FACE_PICTURE_WIDTH / PhotoEditorComponent.DQC_FACE_PICTURE_HEIGHT;
				this.cropperMinWidth = PhotoEditorComponent.DQC_FACE_PICTURE_WIDTH;
				this.cropperMinHeight = PhotoEditorComponent.DQC_FACE_PICTURE_HEIGHT;
			} else if (this.applicationTypeId === APPLICATION_TYPE.APPLICATION_TACHO_CARD) {
				this.pictureRatio = PhotoEditorComponent.TACHO_CARD_FACE_PICTURE_WIDTH / PhotoEditorComponent.TACHO_CARD_FACE_PICTURE_HEIGHT;
				this.cropperMinWidth = PhotoEditorComponent.TACHO_CARD_FACE_PICTURE_WIDTH;
				this.cropperMinHeight = PhotoEditorComponent.TACHO_CARD_FACE_PICTURE_HEIGHT;
			}
			this.isFace = true;
			this.maintainAspectRatio = true;
		}
	}

	imageCropped(event: ImageCroppedEvent) {
		this.croppedImage = event.base64;
		if (this.initCropper) {
			this.initCropper = false;
			this.initCropperPosition = event.cropperPosition;
		}
		this.currentCropperH = event.height;
		this.currentCropperW = event.width;
		this.checkCanZoomIn();
		this.isLoading = false;
	}

	rotateLeft90() {
		if (!this.cropperInput || this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.rotate = this.rotate - 90;
		this.transform = {rotate: 0, scale: 1};
		this.transform.rotate = this.rotate;
		this.transform.scale = this.scale;
	}

	rotateLeftByStepOneDegree() {
		if (!this.cropperInput || this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.rotate = this.rotate - 1;
		this.transform = {rotate: 0 , scale: 1};
		this.transform.rotate = this.rotate;
		this.transform.scale = this.scale;
	}

	rotateRightByStepOneDegree() {
		if (!this.cropperInput || this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.rotate = this.rotate + 1;
		this.transform = {rotate: 0, scale: 1};
		this.transform.rotate = this.rotate;
		this.transform.scale = this.scale;
	}

	rotateRight90() {
		if (!this.cropperInput || this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.rotate = this.rotate + 90;
		this.transform = {rotate: 0, scale: 1};
		this.transform.rotate = this.rotate;
		this.transform.scale = this.scale;
	}

	resetImage() {
		if (!this.cropperInput) {
			return;
		}
		this.cropper  = {
			x1: this.initCropperPosition.x1,
			y1: this.initCropperPosition.y1,
			x2: this.initCropperPosition.x2,
			y2: this.initCropperPosition.y2
		};
		this.transform = {rotate: 0, scale: 1};
		this.rotate = 0;
		this.scale = 1;
	}

	zoomIn() {
		if (!this.cropperInput || this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.scale += .1;
		this.transform = {
			...this.transform,
			scale: this.scale
		};
	}

	zoomOut() {
		if (!this.cropperInput || this.isLoading) {
			return;
		}
		this.isLoading = true;
		this.scale -= .1;
		this.transform = {
			...this.transform,
			scale: this.scale
		};
	}

	checkCanZoomIn(): boolean {
		if (this.isFace &&
			(this.currentCropperH / (this.transform.scale + 0.1) < this.cropperMinHeight
			|| this.currentCropperW / (this.transform.scale + 0.1)  < this.cropperMinWidth)) {
				this.canZoomIn = false;
				return;
		}
		if (this.isSignature &&
			(this.currentCropperH / (this.transform.scale + 0.1) < this.cropperMinHeight
			|| this.currentCropperW / (this.transform.scale + 0.1)  < this.cropperMinWidth)) {
				this.canZoomIn = false;
				return;
		}
		this.canZoomIn = true;
	}

	clearCropperAndTransformForNewImage() {
		this.initCropper = true;
		this.canZoomIn = true;
		this.cropperInput = '';
		this.croppedImage = '';
		this.transform = {rotate: 0, scale: 1};
		this.cropper = {x1: 0, y1: 0, x2: 0, y2: 0};
		this.rotate = 0;
		this.scale = 1;
	}

	showAutoFixedPicture(event) {
		this.emitShowAutoFixImage.emit(event);
	}

	exitEditor(event) {
		this.cropperInput = '';
		this.emitExitEditor.emit(event);
	}

	saveImage() {
		this.emitEditedImageAsBase64.emit(this.croppedImage);
	}
}
