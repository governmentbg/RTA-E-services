import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { Subscription } from 'rxjs';
import { PopUpTypes } from '../../enums/pop-up-types';
import { PopUp } from '../../models/pop-text';
import { ApplicationService } from 'src/app/core/services/application.service';
import { ApplicationShortDto } from '../../interfaces/application-short-dto';
import { ApplicationShort } from '../../models/application-short';
import { Language } from 'angular-l10n';
import { S_VARIABLES } from '../../models/constants/s-variables';

@Component({
	selector: 'app-pop-up',
	templateUrl: './pop-up.component.html'
})
export class PopUpComponent implements OnInit, OnDestroy {

	@Language() lang: string;

	public isWarning: boolean;
	public isError: boolean;
	public isInfo: boolean;
	public isSuccess: boolean;
	public isCheck: boolean;
	public isApproverInput: boolean;

	public popUp: Partial<PopUp>;
	public popUpType: string;
	public isVisible: boolean;

	public inputText: string;
	public searchText: string;
	public applicationShort: ApplicationShort;
	public isSearched = false;
	private subscriptions: Subscription[] = [];
	public dateFormat = S_VARIABLES.DATE_FORMAT;

	constructor(private applicationService: ApplicationService) { }

	ngOnInit(): void {
		this.subscriptions.push(PopUpService.subscribeToPopUpSubjectChanges(
			(popUp) => {
				this.popUp = popUp;
				this.isError = false;
				this.isWarning = false;
				this.isInfo = false;
				this.isSuccess = false;
				this.isCheck = false;
				switch (popUp.type) {
					case PopUpTypes.ERROR:
						this.isError = true;
						break;

					case PopUpTypes.INFO:
						this.isInfo = true;
						break;

					case PopUpTypes.SUCCESS:
						this.isSuccess = true;
						break;

					case PopUpTypes.WARNING:
						this.isWarning = true;
						break;

					case PopUpTypes.CHECK:
						this.isCheck = true;
						break;

					case PopUpTypes.APPROVER_MESSAGE:
						this.isApproverInput = true;
						break;

					default:
						break;
				}

				this.isVisible = true;
			}
		));

		this.subscriptions.push(PopUpService.subscribeToShowPopUp(
			(isVisible) => this.isVisible = isVisible
		));
		if (this.isApproverInput) {
			this.subscriptions.push(PopUpService.subscribeToPopUpInput(
				(inputText) => this.inputText = inputText
			));
		}
	}

	closePopUp() {
		PopUpService.closePopUp();
		this.isSearched = false;
		this.searchText = undefined;
		this.inputText = undefined;
		this.applicationShort = undefined;
	}

	respond(response: boolean) {
		this.inputText = undefined;
		PopUpService.setPopUpResponse(response);
		PopUpService.closePopUp();
	}

	setInput() {
		if (!this.inputText) {
			return;
		}
		PopUpService.setPopUpInput(this.inputText);
		PopUpService.closePopUp();
		this.inputText = undefined;
	}

	resolvedCaptcha(captchaResponse: string) {
		this.searchText = this.searchText.trim();
		if (this.searchText == "" || this.searchText == undefined) {
			grecaptcha.reset();
			return;
		}
		this.applicationService.checkApplication(this.searchText, captchaResponse).subscribe((data: ApplicationShortDto) => {
			if (data === null) {
				return;
			}
			this.applicationShort = new ApplicationShort(data);
		});
		this.isSearched = true;
		grecaptcha.reset();
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach((subscription) => subscription.unsubscribe());
	}

	@HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
		this.closePopUp();
	}
}
