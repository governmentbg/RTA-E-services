import { Component, OnInit, HostListener, OnDestroy } from '@angular/core';
import { LocaleService } from 'angular-l10n';
import { Language } from '../../../shared/models/language';
import { AuthenticationService } from '../../../../app/core/authentication/authentication.service';
import { RouteUtilService } from 'src/app/core/services/route-util.service';
import { User } from '../../models/user';
import { Router } from '@angular/router';
import { LanguageService } from '../../../core/services/language.service';
import { Subscription } from 'rxjs/internal/Subscription';
import { RouteUrl } from '../../enums/route-url.enum';
import { ApplicationService } from 'src/app/core/services/application.service';
import { SubHeaderApplicationInfo } from '../../models/sub-header-application-info';
import { PopUpService } from 'src/app/core/services/pop-up.service';
import { DEFAULT_POP_UPS } from '../../models/constants/pop-up-default-messages';
import { ApplicationStepsElementsService } from 'src/app/core/services/application-steps-elements.service';
import { SubHeaderService } from 'src/app/core/services/sub-header.service';
import { APPLICATION_TYPE, ApplicationTypes } from '../../enums/application-types';
import { S_VARIABLES } from '../../models/constants/s-variables';

@Component({
	selector: 'app-sub-header',
	templateUrl: './sub-header.component.html'
})
export class SubHeaderComponent implements OnInit, OnDestroy {
	public isAuthenticationTab: boolean;
	public isAdminTab: boolean;
	public isApplicationTab: boolean;
	public isDashboardTab: boolean;
	public isUsersTab: boolean;
	public languages: Language[];
	public isLoading = false;
	public user: User;
	public firstAndLastNameCyr: string;
	public firstAndLastNameLat: string;
	public isApplicant: boolean;
	public isDeskStaff: boolean;
	public isAdmin: boolean;
	public applicationId: number;
	public isInDev = false;
	public canCancel = false;
	public canCreateNewApplication = true;
	public applicationProgress = 0;
	public languageCode: string;
	public isProfilePopUpVisible = false;
	public isCreateApplicationMenuVisible = false;
	public hasFilters = false;
	public applicationTypes: ApplicationTypes;
	public currentApplication: SubHeaderApplicationInfo;
	public subscriptions: Subscription[] = [];

	@HostListener('document:click', ['$event'])
	onClick() {
		this.isCreateApplicationMenuVisible = false;
		this.isProfilePopUpVisible = false;
	}

	constructor(
		private languageService: LanguageService,
		private locale: LocaleService,
		private authService: AuthenticationService,
		private applicationService: ApplicationService,
		private routeUtilService: RouteUtilService,
		private router: Router,
		private subHeaderService: SubHeaderService,
		private appStepsService: ApplicationStepsElementsService
	) { }

	ngOnInit(): void {
		this.router.events.subscribe(() => {
			this.isAuthenticationTab = this.routeUtilService.isAuthenticationTab;
			this.isAdminTab = this.routeUtilService.isAdminTab;
			this.isApplicationTab = this.routeUtilService.isApplicationTab;
			this.isDashboardTab = this.routeUtilService.isDashboardTab;
			this.isUsersTab = this.routeUtilService.isUsersTab;
			this.canCreateNewApplication = this.isDashboardTab || (this.isAdminTab && (this.isDeskStaff || this.isAdmin));
		});
		this.loadLanguages();
		this.isInDev = this.routeUtilService.isInDevTab(location.pathname);
		this.authService.getAuthenticatedUserSubject().subscribe((user) => {
			if (user) {
				this.user = user;
				this.isApplicant = this.user.isApplicant();
				this.isDeskStaff = this.user.isDeskStaff();
				this.isAdmin = this.user.isDemaxAdmin();
				this.processNames(user);
				if (this.user.isApplicant() && !this.user.isVerified) {
					this.canCreateNewApplication = false;
				}
			}
		}
		);
		this.applicationTypes = APPLICATION_TYPE;
		this.subscriptions.push(this.applicationService.subHeaderApplicationInfo.subscribe((data: SubHeaderApplicationInfo) => {
			this.currentApplication = data;
			this.applicationId = data.applicationId;
			this.canCancel = data.canCancel;
		}));

		this.subscriptions.push(this.appStepsService.applicationProgress.subscribe(
			(progress) => { this.applicationProgress = progress; }
		));
	}

	private processNames(user: User) {
		const namesLat: string[] = user.fullNameLat.split(' ');
		if (namesLat.length > 2) {
			this.firstAndLastNameLat = namesLat[0] + ' ' + namesLat[2];
		} else {
			this.firstAndLastNameLat = namesLat[0] + ' ' + namesLat[1];
		}
		const namesCyr: string[] = user.fullNameCyr.split(' ');
		if (namesCyr.length === 0) {
			this.firstAndLastNameCyr = this.firstAndLastNameLat;
		} else if (namesCyr.length > 2) {
			this.firstAndLastNameCyr = namesCyr[0] + ' ' + namesCyr[2];
		} else {
			this.firstAndLastNameCyr = namesCyr[0] + ' ' + namesCyr[1];
		}
	}

	public selectLanguage(language: string): void {
		this.locale.setDefaultLocale(language);
		this.locale.languageCodeChanged.next(language);
		this.languageCode = language;
		localStorage.setItem(S_VARIABLES.SELECTED_LANGUAGE, language);
	}

	public getCurrentLanguage(): string {
		return this.locale.getCurrentLanguage();
	}

	private loadLanguages() {
		this.isLoading = true;
		this.languageService.getLanguages()
			.subscribe((languages: Language[]) => {
				this.languages = languages;
			}).add(() => {
				this.isLoading = false;
			});
		if (!localStorage.getItem(S_VARIABLES.SELECTED_LANGUAGE)) {
			this.languageCode = S_VARIABLES.LANGUAGE_BG;
		} else {
			this.languageCode = localStorage.getItem(S_VARIABLES.SELECTED_LANGUAGE);
		}
		this.selectLanguage(this.languageCode);
	}

	public logout(): void {
		this.authService.logout();
	}

	cancelApplication() {
		PopUpService.showPopUp(DEFAULT_POP_UPS.warning_application_will_be_canceled);
		const currentSubscription = PopUpService.subscribeToPopUpResponse(
			(hasConfirmed: boolean) => {
				if (!hasConfirmed) {
					return;
				}
				if (!this.applicationId) {
					if (this.isApplicant) {
						this.router.navigate([RouteUrl.DASHBOARD]);
					} else {
						this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]);
					}
				} else {
					if (this.isLoading) {
						return;
					}
					this.isLoading = true;
					this.applicationService
						.cancelApplication(this.applicationId)
						.subscribe(
							(success) => {
								if (this.isApplicant) {
									this.router.navigate([RouteUrl.DASHBOARD]);
								} else {
									this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]);
								}
								this.isLoading = false;
							},
							(error) => {
								PopUpService.showPopUp(DEFAULT_POP_UPS.error_can_not_cancel_application_now);
								this.isLoading = false;
							}
						);
				}
				currentSubscription.unsubscribe();
			}
		);
	}

	goToDashboard() {
		if (this.isApplicationTab) {
			PopUpService.showPopUp(DEFAULT_POP_UPS.warning_changes_will_be_saved);
			const currentSubscription = PopUpService.subscribeToPopUpResponse(
				(hasConfirmed) => {
					if (hasConfirmed) {
						if (!this.isApplicant) {
							this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]);
						} else {
							this.router.navigate([RouteUrl.DASHBOARD]);
						}
					}
					currentSubscription.unsubscribe();
				});
		} else {
			if (!this.isApplicant) {
				this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]);
			} else {
				this.router.navigate([RouteUrl.DASHBOARD]);
			}
		}
	}

	goToDashboardNoPopup() {
		if (!this.isApplicant) {
			this.router.navigate([RouteUrl.ADMIN, RouteUrl.DASHBOARD]);
		} else {
			this.router.navigate([RouteUrl.DASHBOARD]);
		}
	}

	goToUsers() {
		if (this.isApplicationTab) {
			PopUpService.showPopUp(DEFAULT_POP_UPS.warning_changes_will_be_saved);
			const currentSubscription = PopUpService.subscribeToPopUpResponse(
				(hasConfirmed) => {
					if (hasConfirmed) {
						this.router.navigate([RouteUrl.ADMIN, RouteUrl.USERS]);
					}
					currentSubscription.unsubscribe();
				});
		} else {
			this.router.navigate([RouteUrl.ADMIN, RouteUrl.USERS]);
		}
	}

	setShowProfilePopUp(event) {
		if (this.isCreateApplicationMenuVisible) {
			return;
		}
		event.stopPropagation();
		this.isProfilePopUpVisible = !this.isProfilePopUpVisible;
	}

	setShowCreateApplicationMenuPopUp(event) {
		if (this.isProfilePopUpVisible) {
			return;
		}
		event.stopPropagation();
		this.isCreateApplicationMenuVisible = !this.isCreateApplicationMenuVisible;
	}

	goToProfilePage(event) {
		// TODO : module or sub route for profile page ?
		event.stopPropagation();
		this.isProfilePopUpVisible = false;
		alert('RELOCATE WHEN HAS HTML :)');
	}

	setFilterToggle() {
		this.hasFilters = !this.hasFilters;
		this.subHeaderService.setFiltersToggleStatus(this.hasFilters);
	}

	createApplication(event: Event, applicationType: number) {
		event.stopPropagation();
		this.isCreateApplicationMenuVisible = false;
		// TODO : remove / change when implement not card app
		if (applicationType !== APPLICATION_TYPE.APPLICATION_ADR_CARD
			&& applicationType !== APPLICATION_TYPE.APPLICATION_DQC
			&& applicationType !== APPLICATION_TYPE.APPLICATION_TACHO_CARD
			&& applicationType !== APPLICATION_TYPE.APPLICATION_ADR_EXAM
			&& applicationType !== APPLICATION_TYPE.APPLICATION_CONSULTANT_EXAM
			&& applicationType !== APPLICATION_TYPE.APPLICATION_MOTOR_EXAM
			&& applicationType !== APPLICATION_TYPE.APPLICATION_TAXI_EXAM) {
			return;
		}
		if (this.isApplicant) {
			this.applicationService
				.checkIfApplicationOfSameTypeAlreadyInProgress(applicationType)
				.subscribe((existingApplication: boolean) => {
					if (existingApplication) {
						PopUpService.showPopUp(DEFAULT_POP_UPS.error_application_of_type_already_exists);
						return;
					} else {
						this.router.navigate([RouteUrl.APPLICATION, RouteUrl.NEW, applicationType]);
					}
				});
		} else {
			this.router.navigate([RouteUrl.APPLICATION, RouteUrl.NEW, applicationType]);
		}
	}

	goToInstructions() {
		document.getElementById('INSTRUCTIONS').scrollIntoView({ block: 'center' });
	}

	showCheckApplicationPopUp() {
		PopUpService.showPopUp(DEFAULT_POP_UPS.check_application);
	}

	ngOnDestroy(): void {
		this.subscriptions.forEach((sub) => sub.unsubscribe());
	}
}
