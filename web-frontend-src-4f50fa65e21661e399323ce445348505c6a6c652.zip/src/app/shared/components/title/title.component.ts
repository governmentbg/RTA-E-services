import { Component, OnInit, Input } from '@angular/core';

@Component({
	selector: 'app-title',
	templateUrl: './title.component.html',
})
export class TitleComponent {
	@Input() public title: string;
	@Input() public applicationId: number;
}
