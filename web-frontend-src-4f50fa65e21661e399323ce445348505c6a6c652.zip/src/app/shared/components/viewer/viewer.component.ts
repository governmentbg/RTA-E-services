import { Component, OnInit, Input, EventEmitter, Output, SimpleChange, OnChanges } from '@angular/core';
import { ATTACHED_DOCUMENT_TYPE_KEY } from '../../models/constants/attached-documents/attached-document-type-keys';
import { saveAs } from 'file-saver';
import { Language } from 'angular-l10n';
import { PDFDocumentProxy } from 'ng2-pdf-viewer';

@Component({
	selector: 'app-viewer',
	templateUrl: './viewer.component.html',
})
export class ViewerComponent implements OnInit, OnChanges {
	@Input() srcFromArrayBuffer: ArrayBuffer;
	@Input() pageNumber: number;
	@Input() documentPages: number;
	@Input() attachedDocumentTypeId: number;
	@Input() fileName: string;
	@Output() hideViewerPopUp: EventEmitter<Event> = new EventEmitter();
	@Output() getAttachedDocumentPage: EventEmitter<number> = new EventEmitter();
	@Language() lang: string;
	isPdf: boolean;
	base64String: string;
	hasPreviousDocumentPage: boolean;
	hasNextDocumentPage: boolean;
	attachedDocumentTypeKey: string;
	totalPdfPages: number;
	currentPdfPage: number;
	hasPreviousPdfPage: boolean;
	hasNextPdfPage: boolean;
	initialized = false;
	isLoadingPage = false;

	constructor() {	}

	ngOnInit(): void {
		this.attachedDocumentTypeKey = ATTACHED_DOCUMENT_TYPE_KEY[this.attachedDocumentTypeId];
		this.setBase64FromArrayBufferIfIsNotPdf();
		this.setPreviousAndNextFileButtons();
		this.initialized = true;
	}

	ngOnChanges(changes: {[fileName: string]: SimpleChange}) {
		if (changes.fileName && this.fileName && this.initialized) {
			this.setBase64FromArrayBufferIfIsNotPdf();
			this.setPreviousAndNextFileButtons();
			this.isLoadingPage = false;
		}
	}

	setBase64FromArrayBufferIfIsNotPdf() {
		if (this.fileName.includes('.pdf')) {
			this.isPdf = true;
			this.currentPdfPage = 1;
		} else {
			this.isPdf = false;
			this.hasPreviousPdfPage = false;
			this.hasNextPdfPage = false;
			const ascii = new Uint8Array(this.srcFromArrayBuffer);
			const stringChars = ascii.reduce((data, byte) => data + String.fromCharCode(byte), '');
			this.base64String = 'data:image/jpg;base64,' + btoa(stringChars);
		}
	}

	closeViewer(event: Event) {
		this.hideViewerPopUp.emit(event);
	}

	getPreviousDocumentPage() {
		if (this.isLoadingPage) {
			return;
		}
		this.isLoadingPage = true;
		this.pageNumber -= 1;
		this.changePicture();
	}

	getNextDocumentPage() {
		if (this.isLoadingPage) {
			return;
		}
		this.isLoadingPage = true;
		this.pageNumber += 1;
		this.changePicture();
	}

	changePicture() {
		this.isPdf = false;
		this.getAttachedDocumentPage.emit(this.pageNumber);
	}

	setPreviousAndNextFileButtons() {
		if (this.pageNumber > 1) {
			this.hasPreviousDocumentPage = true;
		} else if (this.pageNumber === 1) {
			this.hasPreviousDocumentPage = false;
		}
		if (this.pageNumber < this.documentPages  ) {
			this.hasNextDocumentPage = true;
		} else if (this.pageNumber === this.documentPages) {
			this.hasNextDocumentPage = false;
		}
	}

	downloadPage() {
		const blob = new Blob([this.srcFromArrayBuffer], { type: 'application/multipart-file' });
		saveAs(blob, this.fileName);
	}

	afterPdfLoadComplete(pdf: PDFDocumentProxy) {
		this.totalPdfPages = pdf.numPages;
		this.setPreviousAndNextPdfPageButtons();
	}

	setPreviousAndNextPdfPageButtons() {
		if (this.currentPdfPage > 1) {
			this.hasPreviousPdfPage = true;
		} else if (this.currentPdfPage === 1) {
			this.hasPreviousPdfPage = false;
		}
		if (this.currentPdfPage < this.totalPdfPages  ) {
			this.hasNextPdfPage = true;
		} else if (this.currentPdfPage === this.totalPdfPages) {
			this.hasNextPdfPage = false;
		}
		this.isLoadingPage = false;
	}

	getPreviousPdfPage() {
		if (this.isLoadingPage) {
			return;
		}
		this.isLoadingPage = true;
		this.currentPdfPage -= 1;
		this.setPreviousAndNextPdfPageButtons();
	}

	getNextPdfPage() {
		if (this.isLoadingPage) {
			return;
		}
		this.isLoadingPage = true;
		this.currentPdfPage += 1;
		this.setPreviousAndNextPdfPageButtons();
	}
}
