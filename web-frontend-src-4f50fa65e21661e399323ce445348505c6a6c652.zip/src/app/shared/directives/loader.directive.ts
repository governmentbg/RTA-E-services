import { Directive, OnInit, OnDestroy, ElementRef, Input, OnChanges, SimpleChanges, Renderer2 } from '@angular/core';
import { Subscription, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

@Directive({
	selector: '[appLoader]'
})
export class LoaderDirective implements OnInit, OnDestroy, OnChanges {

	private static readonly LOADER_CLASS = 'loading';
	private static readonly LOADER_DELAY_MILLIS = 250;

	@Input('appLoader')
	isLoading = false;

	private loaderSubject = new Subject<boolean>();
	private loaderSubscription: Subscription;

	constructor(
		private renderer: Renderer2,
		private element: ElementRef) { }

	ngOnInit(): void {
		if (this.isLoading === true) {
			this.renderer.addClass(this.element.nativeElement, LoaderDirective.LOADER_CLASS);
		} else {
			this.renderer.removeClass(this.element.nativeElement, LoaderDirective.LOADER_CLASS);
		}
		this.loaderSubscription = this.loaderSubject.pipe(
			debounceTime(LoaderDirective.LOADER_DELAY_MILLIS),
			distinctUntilChanged()
		).subscribe((val) => {
			if (val === true) {
				this.renderer.addClass(this.element.nativeElement, LoaderDirective.LOADER_CLASS);
			} else {
				this.renderer.removeClass(this.element.nativeElement, LoaderDirective.LOADER_CLASS);
			}
		});
	}

	ngOnDestroy(): void {
		if (this.loaderSubscription) {
			this.loaderSubscription.unsubscribe();
		}
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes.isLoading) {
			const currentValue: boolean = changes.isLoading.currentValue;
			this.loaderSubject.next(currentValue);
		}
	}
}
