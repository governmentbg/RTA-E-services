import { CityDto } from './city-dto';
import { MunicipalityDto } from './municipality-dto';
import { RegionDto } from './region-dto';
import { TranslationDto } from './translation-dto';

export class AddressDto {
	countryDto: TranslationDto;
	cityDto: CityDto;
	regionDto: RegionDto;
	municipalityDto: MunicipalityDto;
	addressTypeId: number;

	postalCode: string;
	street: string;
	streetNumber: string;
	entrance: string;
	building: string;
	apartment: string;
}
