export class AdrConsultantExamEnrollmentRequestDto {
	learningPlanId: number;
	protocolId: number;
}