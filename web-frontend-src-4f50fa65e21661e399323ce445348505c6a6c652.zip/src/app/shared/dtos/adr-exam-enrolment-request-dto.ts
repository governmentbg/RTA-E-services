export class AdrExamEnrolmentRequestDto {
	examPersonId: number;
	protocolId: number;
	orgUnitCode: string;

	constructor(examPersonId: number, protocolId: number, orgUnitCode: string) {
		this.examPersonId = examPersonId;
		this.protocolId = protocolId;
		this.orgUnitCode = orgUnitCode;
	}
}