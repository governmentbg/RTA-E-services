export class AdrModuleDto {
	typeId: number;
	typeKey: string;
	issueDate: Date;
	validTo: Date;
	attached: boolean;
}
