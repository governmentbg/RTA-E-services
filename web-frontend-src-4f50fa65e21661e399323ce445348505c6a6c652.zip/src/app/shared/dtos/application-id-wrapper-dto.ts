export class ApplicationIdWrapperDto {
	id: number;

	constructor(applicationId: number) {
		this.id = applicationId;
	}
}
