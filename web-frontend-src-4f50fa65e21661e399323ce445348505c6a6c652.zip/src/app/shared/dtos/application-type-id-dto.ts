export class ApplicationTypeIdDto {
	id: number;
}
