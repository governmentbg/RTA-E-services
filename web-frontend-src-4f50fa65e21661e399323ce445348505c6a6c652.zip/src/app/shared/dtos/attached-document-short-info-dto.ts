import { DocumentPageDto } from './document-page-dto';

export interface AttachedDocumentShortInfoDto {
	declared: boolean;
	pagesInfoShort: DocumentPageDto[];
}
