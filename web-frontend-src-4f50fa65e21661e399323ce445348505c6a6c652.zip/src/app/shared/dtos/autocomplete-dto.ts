export class AutocompleteDto {
	phrase: string;
	langCode: string;
}
