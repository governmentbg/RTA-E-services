import { NamesDto } from './names-dto';
import { OldCardDto } from './old-card-dto';
import { Translation } from '../models/translation';
import { OldCard } from '../models/old-card';
import { Names } from '../models/names';
import { TranslationDto } from './translation-dto';

export class CardDto {
	oldCardDto: OldCardDto;
	personNamesDto: NamesDto;
	issuingReason: TranslationDto;

	constructor(issuingReason: TranslationDto, oldCard?: OldCardDto, personNames?: NamesDto) {
		this.oldCardDto = oldCard ? oldCard : null;
		this.personNamesDto = personNames ? personNames : null;
		this.issuingReason = issuingReason;
	}
}
