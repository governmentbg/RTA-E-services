
export class CertificateDto {
	permitNumber: string;
	certificateNumber: string;
	typeId: number;
	typeKey: string;
	legalBasisId: number;
	legalBasisKey: string;
	legalBasisType: string;
	issuedOn: Date;
	trainingStart: Date;
	trainingEnd: Date;
	attached: boolean;
}
