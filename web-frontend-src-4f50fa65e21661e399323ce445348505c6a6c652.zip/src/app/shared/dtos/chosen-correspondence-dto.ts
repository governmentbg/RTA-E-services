import { PhoneNumberDto } from './phone-number-dto';
import { AddressDto } from './address-dto';

export class ChosenCorrespondenceDto {
	email: string;
	phoneNumberDto: PhoneNumberDto;
	addressDto: AddressDto;
}
