export class CityDto {
	cityCode: string;
	key: string;
}
