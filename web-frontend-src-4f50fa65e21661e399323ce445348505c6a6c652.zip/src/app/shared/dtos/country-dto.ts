import { TranslationDto } from "./translation-dto";

export class CountryDto {
	country: TranslationDto;
	eu: boolean;
}