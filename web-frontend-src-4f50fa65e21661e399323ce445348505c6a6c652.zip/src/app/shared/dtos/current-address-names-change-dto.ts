import { AddressDto } from './address-dto';

export class CurrentAddressNamesChangeDto {
	applicationId: number;
	changedNames: boolean;
	currentAddressSameAsPermanent: boolean;
	currentAddress: AddressDto;
	isAuthorizedPerson: boolean;
}
