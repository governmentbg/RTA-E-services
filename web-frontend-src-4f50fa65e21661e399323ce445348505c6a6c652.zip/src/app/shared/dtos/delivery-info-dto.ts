import { OrgUnitDto } from '../dtos/org-unit-dto';
import { AddressDto } from '../dtos/address-dto';

export class DeliveryInfoDto {
	deliveryTypeId: number;
	address: AddressDto;
	orgUnitDto: OrgUnitDto;
}
