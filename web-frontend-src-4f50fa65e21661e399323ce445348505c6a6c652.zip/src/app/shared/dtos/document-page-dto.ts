export interface DocumentPageDto {
	id: number;
	name: string;
	size: number;
}
