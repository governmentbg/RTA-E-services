export class DocumentsDeclarationDto {
	declared: boolean;
	documentTypeIds: number[];

	constructor(declared: boolean, documentTypeIds: number[] ) {
		this.declared = declared;
		this.documentTypeIds = documentTypeIds;
	}
}
