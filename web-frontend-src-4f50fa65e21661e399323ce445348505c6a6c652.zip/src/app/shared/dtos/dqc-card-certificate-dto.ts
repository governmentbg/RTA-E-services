export class DqcCardCertificateDto {
	issuerNumber: string;
	certType: string;
	issuer: string;
	startDate: Date;
	endDate: Date;
	issuedOn: Date;
	validTo: Date;
	typeKey: string

	constructor(dto: any) {
		this.issuerNumber = dto.issuerNumber ? dto.issuerNumber : null;
		this.certType = dto.certType ? dto.certType : null;
		this.issuer = dto.issuer ? dto.issuer : null;
		this.startDate = dto.startDate ? new Date(dto.startDate) : null;
		this.endDate = dto.endDate ? new Date(dto.endDate) : null;
		this.issuedOn = dto.issueDate ? new Date(dto.issueDate) : null;
		this.validTo = dto.validTo ? new Date(dto.validTo) : null;
		this.typeKey = dto.typeKey ? dto.typeKey : null;
	}

}