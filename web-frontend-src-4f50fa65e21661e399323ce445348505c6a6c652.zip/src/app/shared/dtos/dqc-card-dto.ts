import { DqcCardCertificateDto } from "./dqc-card-certificate-dto";

export class DqcCardDto {
	number: string;
	issuedOn: Date;
	validTo: Date;
	status: string;
	certificates: DqcCardCertificateDto[];
	

	constructor(dto: any) {
		this.certificates = [];
		this.number = dto.number ? dto.number : null;
		this.status = dto.status ? dto.status : null;
		this.issuedOn = dto.issuedOn ? new Date(dto.issuedOn) : null;
		this.validTo = dto.validTo ? new Date(dto.validTo) : null;
		if(dto.certificates.length > 0) {
			dto.certificates.forEach(element => {
				this.certificates.push(new DqcCardCertificateDto(element));
			});
		}
	}
}