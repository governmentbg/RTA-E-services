
export class DrivingLicenceCategoryDto {
	categoryId: number;
	startDate: string;
}
