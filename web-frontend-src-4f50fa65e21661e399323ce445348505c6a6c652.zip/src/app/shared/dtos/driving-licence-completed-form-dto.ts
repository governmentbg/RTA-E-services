import { DrivingLicenceView } from '../models/driving-licence-view';
import { DrivingLicenceDto } from './driving-licence-dto';

export class DrivingLicenceCompletedFormDto {
	drivingLicenceView: DrivingLicenceView;
	drivingLicenceDto: DrivingLicenceDto;
}
