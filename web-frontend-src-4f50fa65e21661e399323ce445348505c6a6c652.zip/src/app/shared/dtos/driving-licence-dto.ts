import { DrivingLicenceCategoryDto } from './driving-licence-category-dto';

export class DrivingLicenceDto {
	applicationId: number;
	documentNumber: string;
	documentIssuerId: number;
	dateOfExpiry: string;
	dateOfIssue: string;
	countryId: number;
	categories: DrivingLicenceCategoryDto[] = [];
	isEditing = false;
	isBulgarian: boolean;
}
