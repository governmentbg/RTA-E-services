export class DrivingLicenceInitialInfoDto {
	documentNumber: string;
	isBulgarian: boolean;
}
