export class EmailWrapperDto {
	email: string;

	constructor(email: string) {
		this.email = email;
	}
}
