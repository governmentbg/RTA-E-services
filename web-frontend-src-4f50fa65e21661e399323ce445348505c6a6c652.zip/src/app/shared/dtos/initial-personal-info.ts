export class InitialPersonalInfoDto {
	applicationId: number;
	identityDocumentTypeId: number;
	nationalityId: number;
	identityNumber: string;
	documentNumber: string;
	email: string;
	isAuthorizedPerson: boolean;
}
