export class JuridicalSubjectDto {
	name: string;
	address: string;
	eik: string;
	vatNumber: string;
}