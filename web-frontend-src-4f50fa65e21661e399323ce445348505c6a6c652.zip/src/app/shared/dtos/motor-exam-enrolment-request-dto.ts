export interface MotorExamEnrolmentRequestDto {
    examPersonId: number;
    protocolId: number;
    selectCategoryId: number;
}