export interface MotorExamPeopleQueryParams {
    categoryId: number;
}