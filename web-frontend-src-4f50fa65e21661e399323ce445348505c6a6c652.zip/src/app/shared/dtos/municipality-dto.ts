export class MunicipalityDto {
	code: string;
	regionCode: string;
	key: string;
}
