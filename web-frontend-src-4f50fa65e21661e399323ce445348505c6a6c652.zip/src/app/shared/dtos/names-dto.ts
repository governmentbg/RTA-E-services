export class NamesDto {
	firstNameCyr: string;
	fatherNameCyr: string;
	familyNameCyr: string;
	firstNameLat: string;
	fatherNameLat: string;
	familyNameLat: string;
}
