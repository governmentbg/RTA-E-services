import { TranslationDto } from './translation-dto';

export class OldCardDto {
	cardNumber: string;
	validity: Date;
	issuingCountry: TranslationDto;
	issuedBy: string;
	place: string;
	date: Date;
}
