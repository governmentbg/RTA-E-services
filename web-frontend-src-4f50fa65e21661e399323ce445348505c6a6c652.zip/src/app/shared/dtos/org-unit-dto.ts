export class OrgUnitDto {
	code: string;
	name: string;
	cityTranslationKey: string;
	address: string;
	phoneNumber: string;
}
