import { JuridicalSubjectDto } from "./juridical-subject-dto";

export class PaymentDto {
	paymentTypeId: number;
	paymentMethodId: number;
	amount: number;
	juridicalSubject?: JuridicalSubjectDto
}
