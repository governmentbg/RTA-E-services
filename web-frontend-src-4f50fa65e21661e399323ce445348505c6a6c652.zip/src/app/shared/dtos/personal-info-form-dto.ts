import { NamesDto } from '../interfaces/names-dto';
import { AddressDto } from './address-dto';
import { TranslationDto } from '../interfaces/translation-dto';

export class PersonalInfoDto {
	applicationId: number;
	identityNumber: string;
	nationality: TranslationDto;
	placeOfBirth: string;
	placeOfBirthLatin: string;
	dateOfBirth: string;
	namesDto: NamesDto;
	changedNames: boolean;
	identityDocumentType: TranslationDto;
	documentNumber: string;
	dateOfExpiry: string;
	dateOfIssue: string;
	documentIssuer: TranslationDto;
	permanentAddressDto: AddressDto;
	currentAddressDto: AddressDto;
	currentAddressSameAsPermanent: boolean;

	gender: TranslationDto;
	isAuthorizedPerson: boolean;
	isEditing: boolean;
	hasGraoCheck: boolean;
}

