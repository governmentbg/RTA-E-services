export class PhoneNumberDto {
	countryCodeId: number;
	phoneNumber: string;
}
