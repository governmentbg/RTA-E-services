export class RegionDto {
	regionCode: string;
	key: string;
}
