export class RemarkDto {
	message: string;
	remarkKey: string;
}
