import { Translation } from '../models/translation';

export class RequestMvrDto {
	identityNumber: string;
	applicationId: number;
	documentNumber: string;
	identityDocumentType: Translation;
	nationality: Translation;
	isWithLnch = false;
	isForeignerWithEgn = false;
	isAuthorizedPerson: boolean;
}
