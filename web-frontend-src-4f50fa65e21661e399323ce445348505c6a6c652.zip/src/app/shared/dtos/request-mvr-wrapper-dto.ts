import { RequestMvrDto } from './request-mvr-dto';
import { PersonalInfoDto } from './personal-info-form-dto';
export class RequestMvrWrapperDto {
	requestMvrDto: RequestMvrDto;
	personalFormDtoMvrResponse: PersonalInfoDto;
}
