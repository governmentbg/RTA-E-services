import { AdrModule } from '../models/adr-module';
import { Certificate } from '../models/certificate';

export class SelectedCertificatesAndModulesDto {
	certificates: Certificate[];
	modules: AdrModule[];
}
