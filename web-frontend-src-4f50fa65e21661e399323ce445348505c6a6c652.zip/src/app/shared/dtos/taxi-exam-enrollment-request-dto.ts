export class TaxiExamEnrolmentRequestDto {
	orgUnitCode: string;
	municipalityCode: string;
	protocolId: number;
	criminalRecordCertificateNumber: string;
	criminalRecordCertificateIssueDate: string;
	certificateOfPsychologicalFitnessNumber: string;
	certificateOfPsychologicalFitnessIssueDate: string;
}