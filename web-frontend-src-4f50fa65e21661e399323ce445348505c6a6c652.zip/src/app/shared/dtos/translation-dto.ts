export class TranslationDto {
	id: number;
	key: string;

	constructor(id: number, key?: string) {
		this.id = id;
		this.key = key ? key : null;
	}
}
