export class TranslationRequestDto {
	translationKey: string;
	bgTranslationValue: string;
	enTranslationValue: string;
}
