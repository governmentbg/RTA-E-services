export class VerificationTokenWrapperDto {
	verificationToken: string;

	constructor(token: string) {
		this.verificationToken = token;
	}
}
