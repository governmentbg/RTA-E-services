export enum AddressDescriptions {
	STREET = 'ул.',
	NUMBER  = 'N',
	BUILDING  = 'сграда',
	ENTRANCE  = 'вх.',
	APARTMENT  = 'ап.',
	POSTAL_CODE  = 'п.к.',
}
