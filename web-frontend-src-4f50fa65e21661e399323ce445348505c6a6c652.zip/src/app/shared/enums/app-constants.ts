export enum AppConstants {
	CSRF_TOKEN_COOKIE_NAME = '_csrf',
	CSRF_TOKEN_HEADER_HEADER_NAME  = 'X-CSRF-TOKEN'
}
