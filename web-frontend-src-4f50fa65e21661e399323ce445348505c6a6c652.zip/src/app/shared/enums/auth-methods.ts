export enum AUTH_METHODS {
	E_FACE = 1,
	E_SIGN = 2,
	DESK = 3,
	ATTORNEY_DESK = 4,

}

export type AuthMethods = typeof AUTH_METHODS;