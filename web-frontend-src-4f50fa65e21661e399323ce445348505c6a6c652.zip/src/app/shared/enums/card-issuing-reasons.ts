export enum CardIssuingReasons {
	INITIAL_ISSUING_ID = 1,
	LOST_ID = 2,
	STOLEN_ID = 3,
	DAMAGED_ID = 4,
	NAME_CHANGE_ID = 5,
	PHOTO_CHANGE_ID = 6,
	DRIVING_LICENCE_CHANGE_ID = 7,
	DATA_CHANGE_ID = 8,
	REPLACE_FOREIGN_ID = 9,
	EXPIRATION_ID = 10,
	TACHO_TAKEN_AWAY_ID = 12,
	NEW_CERTIFICATE = 13
}

export const REASONS_WITHOUT_FIELDS_FOR_PLACE_DATE_OR_NAMES = [
		CardIssuingReasons.REPLACE_FOREIGN_ID,
		CardIssuingReasons.PHOTO_CHANGE_ID,
		CardIssuingReasons.DRIVING_LICENCE_CHANGE_ID,
		CardIssuingReasons.DATA_CHANGE_ID,
		CardIssuingReasons.DAMAGED_ID,
		CardIssuingReasons.EXPIRATION_ID,
		CardIssuingReasons.TACHO_TAKEN_AWAY_ID
];

export const REASONS_WITHOUT_FIELDS_FOR_NAMES = [
	CardIssuingReasons.LOST_ID,
	CardIssuingReasons.STOLEN_ID
];

export const DQC_REASONS = [
	CardIssuingReasons.INITIAL_ISSUING_ID,
	CardIssuingReasons.LOST_ID,
	CardIssuingReasons.STOLEN_ID,
	CardIssuingReasons.DAMAGED_ID,
	CardIssuingReasons.NAME_CHANGE_ID,
	CardIssuingReasons.DRIVING_LICENCE_CHANGE_ID,
	CardIssuingReasons.REPLACE_FOREIGN_ID,
	CardIssuingReasons.EXPIRATION_ID,
	CardIssuingReasons.TACHO_TAKEN_AWAY_ID,
	CardIssuingReasons.NEW_CERTIFICATE
];

export const TACHO_REASONS = [
	CardIssuingReasons.INITIAL_ISSUING_ID,
	CardIssuingReasons.LOST_ID,
	CardIssuingReasons.STOLEN_ID,
	CardIssuingReasons.DAMAGED_ID,
	CardIssuingReasons.NAME_CHANGE_ID,
	CardIssuingReasons.DRIVING_LICENCE_CHANGE_ID,
	CardIssuingReasons.REPLACE_FOREIGN_ID,
	CardIssuingReasons.EXPIRATION_ID,
	CardIssuingReasons.TACHO_TAKEN_AWAY_ID,
];

