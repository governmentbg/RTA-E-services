export enum DeliveryTypes {
	RECEIVE_IN_PERSON_ID = 1,
	RECEIVE_BY_ADDRESS_ID = 2
}
