export enum IdentityDocumentIssuers {
	MVR_SOFIA_CITY = 28,
	MVR = 29
}

