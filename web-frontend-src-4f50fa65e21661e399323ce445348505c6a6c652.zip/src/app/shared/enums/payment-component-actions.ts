export enum PaymentComponentAction {
	OPEN_VIEWER,
	DOWNLOAD,
	PRINT
}
