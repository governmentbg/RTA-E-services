export enum PAYMENT_METHODS {
	VIRTUAL_POS_TERMINAL = 1,
	E_PAY = 2,
	EASY_PAY = 3,
	BANK = 4,
	PHYSICAL_POS_TERMINAL = 4,
}

export type PaymentMethods = typeof PAYMENT_METHODS;
