export enum PAYMENT_TYPES {
	PROCESSING_FEE = 1,
	PERSONALIZATION_FEE = 2,
	DELIVERY_FEE = 3,
}

export type PaymentTypes = typeof PAYMENT_TYPES;
