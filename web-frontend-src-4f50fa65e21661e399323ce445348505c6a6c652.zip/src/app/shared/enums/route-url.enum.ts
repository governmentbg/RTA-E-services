
export enum RouteUrl {
	LOG_IN = 'login',
	DASHBOARD = 'dashboard',
	USER = 'user',
	ADMIN = 'admin',
	USERS = 'users',
	APPLICATION = 'application',
	ID = ':id',
	DRAFT = 'draft',
	DRAFT_ID = 'draft/:id',
	NEW = 'new',
	NEW_TYPE = 'new/:type',
	TRANSLATION_KEY_VALUE = 'translation-key-value',
	DEV = 'dev',
}
