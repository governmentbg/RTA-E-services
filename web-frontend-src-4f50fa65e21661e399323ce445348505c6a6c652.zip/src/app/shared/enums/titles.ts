export enum TITLES {
	DEFAULT = 'Заявления и услуги'
}
