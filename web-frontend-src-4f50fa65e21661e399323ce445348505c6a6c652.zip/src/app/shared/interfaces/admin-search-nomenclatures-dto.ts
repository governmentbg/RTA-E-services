import { TranslationDto } from './translation-dto';

export interface AdminSearchNomenclaturesDto {
	applicationTypes: TranslationDto[];
	authMethods: TranslationDto[];
	paymentStatuses: TranslationDto[];
	generalStatuses: TranslationDto[];
	deliveryKeys: string[];
}
