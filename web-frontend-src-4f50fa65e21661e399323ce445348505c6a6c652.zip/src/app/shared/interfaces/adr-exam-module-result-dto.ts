export interface AdrExamModuleResultDto {
	module: string;
	isPassed: boolean;
}