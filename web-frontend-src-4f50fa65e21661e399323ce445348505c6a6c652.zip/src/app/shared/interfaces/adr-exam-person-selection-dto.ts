import { AdrExamModuleResultDto } from "./adr-exam-module-result-dto";

export interface AdrExamPersonSelectionDto {
	id: number;
	learningPlanName: string;
	learningValidTo: Date;
	examModuleResults: AdrExamModuleResultDto[];
}