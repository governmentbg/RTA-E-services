export interface AdrExamProtocolSelectionDto {
	id: number;
	number: string;
	examDateTime: Date;
	roomName: string;
	remainingSeats: number;

}