import { AdrExamProtocolSelection } from "src/app/modules/application/new-application/exam-protocol-selection/adr-exam-protocol-selection.model";
import { AdrExamProtocolSelectionDto } from "./adr-exam-protocol-selection-dto";

export interface AdrExamProtocolsResponseDto {

    fromDate: Date;
    toDate: Date;
    minExamDayFromTodayForLongPayment: number;
    protocols: AdrExamProtocolSelectionDto[];
}