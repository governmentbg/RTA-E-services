import { AddressDto } from '../dtos/address-dto';

export interface ApplicantContactDetailsDto {
	permanentAddress: AddressDto;
	currentAddress: AddressDto;
	otherAddress: AddressDto;
}
