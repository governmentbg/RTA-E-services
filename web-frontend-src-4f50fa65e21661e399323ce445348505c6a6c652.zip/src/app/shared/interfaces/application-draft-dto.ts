import { NamesDto } from './names-dto';
import { CertificateDto } from '../dtos/certificate-dto';
import { AdrModuleDto } from '../dtos/adr-module-dto';
import { TranslationDto } from './translation-dto';
import { PersonalInfoDto } from '../dtos/personal-info-form-dto';
import { DrivingLicenceViewDto } from './driving-licence-view-dto';
import { ContactViewDto } from './contact-view-dto';
import { DeliveryInfoDto } from '../dtos/delivery-info-dto';
import { CardViewDto } from './card-dto';

export interface ApplicationDraftDto {
	applicationId: number;
	applicationType: TranslationDto;
	identityNumber: string;
	names: NamesDto;
	hasMvrCheck: boolean;
	hasDlMvrCheck: boolean;
	hasGraoCheck: boolean;
	hasAutoFixedPicturesFromMvr: boolean;
	attachedDocuments: TranslationDto[];
	personalInfoDto: PersonalInfoDto;
	drivingLicenceDto: DrivingLicenceViewDto;
	cardViewDto: CardViewDto;
	deliveryDto: DeliveryInfoDto;
	contactInfoDto: ContactViewDto;

	dqcCertificateDtos: CertificateDto[];
	adrModuleDtos: AdrModuleDto[];
}
