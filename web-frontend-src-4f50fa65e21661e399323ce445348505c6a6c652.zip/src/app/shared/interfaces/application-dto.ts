
import { SummaryDto } from './summary-dto';
import { NamesDto } from '../dtos/names-dto';
import { CertificateDto } from '../dtos/certificate-dto';
import { AdrModuleDto } from '../dtos/adr-module-dto';
import { ContactViewDto } from './contact-view-dto';
import { TranslationDto } from './translation-dto';
import { PaymentViewDto } from './payment-view-dto';
import { PersonalInfoDto } from '../dtos/personal-info-form-dto';
import { DrivingLicenceViewDto } from './driving-licence-view-dto';
import { DeliveryInfoDto } from '../dtos/delivery-info-dto';
import { CardViewDto } from './card-dto';
import { AdrExamInfo } from '../models/exam/adr-exam-info';
import { AdrExamInfoDto } from './exam/adr-exam-info-dto';
import { MotorExamInfoDto } from './exam/motor-exam-info-dto';
import { TaxiExamInfoDto } from './exam/taxi-exam-info-dto';

export interface ApplicationDto {
	applicationId: number;
	applicationTypeViewDto: TranslationDto;
	identityNumber: string;
	summaryDto: SummaryDto;
	names: NamesDto;
	euCitizen: boolean;
	hasMvrCheck: boolean;
	personalInfoDto: PersonalInfoDto;
	contactViewDto: ContactViewDto;
	hasDlMvrCheck: boolean;
	hasAutoFixedPicturesFromMvr: boolean;
	drivingLicenceDto: DrivingLicenceViewDto;
	cardViewDto: CardViewDto;
	deliveryViewDto: DeliveryInfoDto;
	dqcCertificateDtos: CertificateDto[];
	adrModuleDtos: AdrModuleDto[];
	attachedDocuments: TranslationDto[];
	paymentDto: PaymentViewDto;
	
	adrExamInfo: AdrExamInfoDto;
	motorExamInfo: MotorExamInfoDto;
	taxiExamInfo: TaxiExamInfoDto;
}
