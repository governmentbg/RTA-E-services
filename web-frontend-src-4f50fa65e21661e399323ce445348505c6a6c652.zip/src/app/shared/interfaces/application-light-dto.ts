import { NamesBilingualDto } from './names-bilingual-dto';
import { GeneralStatusDescriptionDto } from './general-status-description-dto';
import { TranslationDto } from './translation-dto';

export interface ApplicationLightDto {
	applicationId: number;
	applicationTypeId: number;
	applicationStatus: GeneralStatusDescriptionDto;
	authMethod: TranslationDto;
	date: Date;
	names: NamesBilingualDto;
	identityNumber: string;
	correspondenceTypeId: number;
	flags: number;
	paymentStatusId: number;
	lastStatusChange: Date;
	deliveryKey: string;
}
