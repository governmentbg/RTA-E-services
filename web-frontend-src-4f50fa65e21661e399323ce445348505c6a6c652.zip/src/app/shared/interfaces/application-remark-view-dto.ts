export interface ApplicationRemarkViewDto {
	message: string;
	remarkKey: string;
	messageTimestamp: Date;
}
