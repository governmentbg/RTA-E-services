import { PaymentShortDto } from './payment-short-dto';

import { WarningDto } from './warning-dto';
import { GeneralStatusDescriptionDto } from './general-status-description-dto';
import { TranslationDto } from './translation-dto';
import { ApplicationRemarkViewDto } from './application-remark-view-dto';

export interface ApplicationShortDto {
	applicationId: number;
	applicationType: TranslationDto;
	applicationStatus: GeneralStatusDescriptionDto;
	warningDtos: WarningDto[];
	remarkDtos: ApplicationRemarkViewDto[];
	hasInvoice: boolean;
	payments: PaymentShortDto[];
}
