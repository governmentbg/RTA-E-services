import { OldCardDto } from '../dtos/old-card-dto';
import { NamesDto } from './names-dto';
import { TranslationDto } from './translation-dto';

export interface CardViewDto {
	issuingReason: TranslationDto;
	oldCardDto: OldCardDto;
	personNamesDto: NamesDto;
	hasCardFromService: boolean;
}

