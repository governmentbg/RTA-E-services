export interface CardIssuingReasonDto {
	id: number;
	key: string;
}
