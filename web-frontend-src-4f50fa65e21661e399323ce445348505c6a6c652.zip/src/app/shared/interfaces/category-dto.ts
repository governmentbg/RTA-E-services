
export interface CategoryDto {
	categoryId: number;
	category: string;
	acquisitionDate: Date;
	imageClass: string;
}
