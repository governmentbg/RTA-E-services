export interface ConsultantExamLearningPlanSelectionDto {
	id: number;
	description: string;
}