export interface ContactInfoDto {
	contactType: string;
	contactValue: string;
}
