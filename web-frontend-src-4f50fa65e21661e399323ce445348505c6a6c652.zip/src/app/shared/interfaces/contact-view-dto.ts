import { AddressDto } from '../dtos/address-dto';
import { PhoneNumberDto } from '../dtos/phone-number-dto';

export interface ContactViewDto {
	address: AddressDto;
	email: string;
	phoneNumberDto: PhoneNumberDto;
	contactTypeId: number;
}
