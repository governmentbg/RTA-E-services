export interface ContractDto {
	startDate: Date;
	endDate: Date;
	timeLimit: Date;
	professionCode: string;
	professionName: string;
}