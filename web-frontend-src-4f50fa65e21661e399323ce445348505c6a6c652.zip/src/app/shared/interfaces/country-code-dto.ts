export interface CountryCodeDto {
	id: number;
	code: string;
	countryTranslationKey: string;
	countryCode2: string;
}
