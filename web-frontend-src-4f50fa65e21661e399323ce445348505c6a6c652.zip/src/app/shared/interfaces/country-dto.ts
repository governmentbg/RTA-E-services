import { TranslationDto } from "./translation-dto";

export interface CountryDto {
	country: TranslationDto;
	eu: boolean;
}