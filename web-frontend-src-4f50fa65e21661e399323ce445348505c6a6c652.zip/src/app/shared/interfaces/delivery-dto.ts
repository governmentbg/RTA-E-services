export interface DeliveryDto {
	deliveryType: string;
	orgUnit: string;
	address: string;
	municipalityTranslationKey: string;
	cityTranslationKey: string;
}
