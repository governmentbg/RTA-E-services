import { TranslationDto } from './translation-dto';

export interface DqcCertificateNomenclaturesDto {
	legalBasisTypes: TranslationDto[];
	certificateTypes: TranslationDto[];
}
