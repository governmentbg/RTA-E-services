import { PhoneNumberDto } from './phone-number-dto';

export interface DraftContactTypeDto {
	email: string;
	phoneNumberDto: PhoneNumberDto;
	contactTypeId: number;
	postalAddressTypeId: number;
}
