import { CategoryDto } from './category-dto';
import { TranslationDto } from './translation-dto';

export interface DrivingLicenceDto {
	documentNumber: string;
	expirationDate: Date;
	issuedOn: Date;
	bulgarian: boolean;
	issuedBy: TranslationDto;
	categories: CategoryDto[];
}
