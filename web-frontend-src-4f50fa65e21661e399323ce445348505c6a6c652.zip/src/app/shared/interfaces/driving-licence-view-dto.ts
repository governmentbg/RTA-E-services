import { CategoryDto } from './category-dto';
import { TranslationDto } from './translation-dto';

export interface DrivingLicenceViewDto {
	documentNumber: string;
	expirationDate: Date;
	issuedOn: Date;
	issuedBy: TranslationDto;
	categories: CategoryDto [];
	bulgarian: boolean;
	hasAutoFixedPictures: boolean;
}

