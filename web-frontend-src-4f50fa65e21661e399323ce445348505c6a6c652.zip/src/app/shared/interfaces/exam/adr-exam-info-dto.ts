import { OrgUnitDto } from "../../dtos/org-unit-dto";
import { AdrExamPersonSelectionDto } from "../adr-exam-person-selection-dto";
import { AdrExamProtocolSelectionDto } from "../adr-exam-protocol-selection-dto";

export interface AdrExamInfoDto {
    selectedAdrExamPerson: AdrExamPersonSelectionDto;
    selectedOrgUnit: OrgUnitDto;
    selectedAdrProtocol: AdrExamProtocolSelectionDto;
    isConsultantExtension: boolean;
}