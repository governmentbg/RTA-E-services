import { CategoryDto } from "../category-dto";
import { MotorExamPersonSelectionDto } from "../motor-exam-person-selection-dto";
import { MotorExamProtocolSelectionDto } from "../motor-exam-protocol-selection-dto";

export interface MotorExamInfoDto {
	selectedMotorExamPerson: MotorExamPersonSelectionDto;
	selectedMotorProtocol: MotorExamProtocolSelectionDto;
	selectedCategory: CategoryDto;
}