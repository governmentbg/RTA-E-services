export interface MotorExamProtocolSelectionQueryParams {
    orgUnitCode: string;
}