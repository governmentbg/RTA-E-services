import { MotorExamProtocolSelectionDto } from "../motor-exam-protocol-selection-dto";

export interface MotorExamProtocolsResponseDto {
    fromDate: Date;
    toDate: Date;
    minExamDayFromTodayForLongPayment: number;
    protocols: MotorExamProtocolSelectionDto[];
}