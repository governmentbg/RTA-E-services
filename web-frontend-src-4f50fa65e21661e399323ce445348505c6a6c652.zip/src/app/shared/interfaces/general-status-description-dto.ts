import { TranslationDto } from './translation-dto';

export interface GeneralStatusDescriptionDto {
	generalStatus: TranslationDto;
	statusDescriptionKey: string;
}
