export interface LanguageDto {
	code: string;
	name: string;
}
