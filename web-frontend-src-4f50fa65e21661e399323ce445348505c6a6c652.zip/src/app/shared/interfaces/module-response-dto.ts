export interface ModuleResponseDto {
	moduleNumber: string;
	moduleType: string;
	moduleDate: Date;
}