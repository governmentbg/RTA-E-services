import { OrgUnitDto } from "../dtos/org-unit-dto";
export interface MotorExamPersonSelectionDto {
	examPersonId: number;
	orgUnit: OrgUnitDto;
	learningPlanName: string;
	theoreticalExamResult: string;
}