import { OrgUnitDto } from "../dtos/org-unit-dto";
import { AdrExamProtocolSelectionDto } from "./adr-exam-protocol-selection-dto";

export interface MotorExamProtocolSelectionDto extends AdrExamProtocolSelectionDto {
	orgUnit: OrgUnitDto;
}