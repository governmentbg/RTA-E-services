export interface NamesBilingualDto {
	namesInCyr: string;
	namesInLat: string;
}
