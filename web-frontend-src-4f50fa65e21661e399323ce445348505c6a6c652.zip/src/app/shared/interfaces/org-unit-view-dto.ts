export interface OrgUnitViewDto {
	name: string;
	cityKey: string;
	phoneNumber: string;
	address: string;
}
