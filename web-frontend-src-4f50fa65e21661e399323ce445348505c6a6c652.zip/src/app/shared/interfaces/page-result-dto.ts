export interface PageResultDto<T> {
	items: T[];
	totalCount: number;
}
