
export interface PaymentShortDto {
	id: number;
	paymentStatusCode: string;
	paymentTypeKey: string;
}
