
export interface PaymentTaxesViewDto {
	processingFee: number;
	deliveryFee: number;
	personalizationFee: number;
}
