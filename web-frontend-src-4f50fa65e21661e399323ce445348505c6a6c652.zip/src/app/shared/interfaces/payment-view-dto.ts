export interface PaymentViewDto {
	applicationTypeShortKey: string;
	processingFeeStatus: string;
	processingFeeMethodId: number;
	personalizationFeeStatus: string;
	personalizationFeeMethodId: number;
}
