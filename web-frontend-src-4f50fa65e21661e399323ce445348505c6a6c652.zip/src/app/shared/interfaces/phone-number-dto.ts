export interface PhoneNumberDto {
	countryCodeId: number;
	phoneNumber: string;
}
