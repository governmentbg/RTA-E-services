export interface PhotoAndSignatureDto {
	picture: Blob;
	signature: Blob;
}
