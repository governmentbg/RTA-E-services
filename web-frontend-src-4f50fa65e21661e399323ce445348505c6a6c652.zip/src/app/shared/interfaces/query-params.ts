export interface QueryParams {
	toQueryParamsObject(): object;
}
