export interface RemarkDto {
	message: string;
	remarkMessageKey: string;
	messageTimestamp: Date;
}
