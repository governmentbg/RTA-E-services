
export interface RequiredDocumentTypeDto {
	id: number;
	type: string;
}
