import { TranslationDto } from "./translation-dto";

export interface RoleDto extends TranslationDto {
    role: string;
}