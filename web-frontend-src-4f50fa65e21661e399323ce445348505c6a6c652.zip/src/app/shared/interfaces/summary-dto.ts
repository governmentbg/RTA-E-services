import { ApplicationShortDto } from './application-short-dto';
import { TranslationDto } from './translation-dto';

export interface SummaryDto {
	authMethod: TranslationDto;
	paymentStatus: TranslationDto;
	submissionDate: Date;
	attachedDocuments: TranslationDto[];
	shortApplication: ApplicationShortDto;
}
