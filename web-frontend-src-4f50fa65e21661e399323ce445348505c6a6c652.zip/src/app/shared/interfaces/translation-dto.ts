export interface TranslationDto {
	id: number;
	key: string;
}
