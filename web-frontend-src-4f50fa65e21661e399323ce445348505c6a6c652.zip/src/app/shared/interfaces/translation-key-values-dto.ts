export interface TranslationKeyValuesDto {
	translationKey: string;
	bgTranslation: string;
	enTranslation: string;
}
