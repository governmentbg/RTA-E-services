
export interface UserDto {
	id: number;
	identityNumber: string;
	identityNumberType: string;
	fullNameCyr: string;
	fullNameLat: string;
	username: string;
	email: string;
	roles: string [];
	verified: boolean;
	authMethodKey: string;
}
