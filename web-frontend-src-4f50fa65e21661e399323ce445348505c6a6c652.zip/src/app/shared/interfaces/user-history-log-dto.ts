import { TranslationDto } from "./translation-dto";

export interface UserHistoryLogDto {
	id: number;
	time: Date;
	authenticationMethod: TranslationDto;
}