import { RoleDto } from "./role-dto";
import { UserHistoryLogDto } from "./user-history-log-dto";

export interface UserManagementListItemDto {
    id: number;
    identityNumber: string;
    fullName: string;
    email: string;
    roles: RoleDto[];
    lastLogin: UserHistoryLogDto;
}