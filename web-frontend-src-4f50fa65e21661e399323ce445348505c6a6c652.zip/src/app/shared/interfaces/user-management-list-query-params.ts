export interface UserManagementListQueryParams {
    identityNumber: string;
    name: string;
    role: string;
    authenticationMethodId: number;
}