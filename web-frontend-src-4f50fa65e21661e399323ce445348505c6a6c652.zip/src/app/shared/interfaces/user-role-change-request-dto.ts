export interface UserRoleChangeRequestDto {
    roleId: number;
}