export interface WarningDto {
	warningVariableInfo: string;
	warningMessageTranslationKey: string;
}
