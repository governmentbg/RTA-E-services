import { FormBuilder, FormGroup, AbstractControl, FormControl, FormArray } from '@angular/forms';

export abstract class AbstractForm<T> {

	protected formBuilder: FormBuilder = new FormBuilder();
	public formGroup: FormGroup;

	public getIsControlInvalid(controlName: string): boolean {
		return (this.formGroup.get(controlName).dirty || this.formGroup.get(controlName).touched)
			&& this.formGroup.get(controlName).invalid;
	}

	public isValid(): boolean {
		if (this.formGroup.invalid) {
			this.markAbstractControlAsTouched(this.formGroup);
			return false;
		}
		return true;
	}

	public abstract toRequestDto(params?: object): T;

	private markAbstractControlAsTouched(abstractControl: AbstractControl) {
		if (abstractControl instanceof FormControl) {
			abstractControl.markAsTouched({ onlySelf: true });
		} else if (abstractControl instanceof FormGroup) {
			Object.keys(abstractControl.controls).forEach(key => {
				const control = abstractControl.get(key);
				if (control instanceof FormControl) {
					control.markAsTouched({ onlySelf: true });
					if (control.value instanceof AbstractForm) {
						this.markAbstractControlAsTouched(control.value.formGroup);
					}
				} else {
					this.markAbstractControlAsTouched(control);
				}
			});
		} else if (abstractControl instanceof FormArray) {
			abstractControl.controls.forEach(control => {
				if (control instanceof FormControl) {
					control.markAsTouched({ onlySelf: true });
					if (control.value instanceof AbstractForm) {
						this.markAbstractControlAsTouched(control.value.formGroup);
					}
				} else {
					this.markAbstractControlAsTouched(control);
				}
			});
		}
	}

	// tslint:disable-next-line: no-any
	public scrollToFirstInvalidControl(htmlElement: any) {
		const firstInvalidControl: HTMLElement = htmlElement.nativeElement.querySelector(
			'form input.ng-invalid, select.ng-invalid'
		);
		if (firstInvalidControl) {
			window.scroll({
				top: this.getTopOffset(firstInvalidControl),
				left: 0,
				behavior: 'smooth'
			});
		}
	}

	private getTopOffset(controlEl: HTMLElement): number {
		const labelOffset = 50;
		return controlEl.getBoundingClientRect().top + window.scrollY - labelOffset;
	}
}
