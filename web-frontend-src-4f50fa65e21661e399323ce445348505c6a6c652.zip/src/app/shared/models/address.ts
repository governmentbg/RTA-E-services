import { AddressDto } from '../dtos/address-dto';
import { City } from './city';
import { Region } from './region';
import { Municipality } from './municipality';
import { CityDto } from '../dtos/city-dto';
import { RegionDto } from '../dtos/region-dto';
import { AddressDescriptions } from '../enums/address-descriptions';
import { MunicipalityDto } from '../dtos/municipality-dto';
import { Translation } from './translation';
import { TranslationDto } from '../dtos/translation-dto';

export class Address {
	country: Translation; // за тези които имат адрес в чужбина , визуализираме само страна , без подробности за адреса
	city: City;
	region: Region;
	municipality: Municipality;
	addressTypeId: number;

	postalCode: string;
	street: string;
	streetNumber: string;
	entrance: string;
	building: string;
	apartment: string;

	// APPROVER
	countryError: boolean;

	cityError: boolean;
	regionError: boolean;
	municipalityError: boolean;

	postalCodeError: boolean;
	streetError: boolean;
	streetNumberError: boolean;
	entranceError: boolean;
	buildingError: boolean;
	apartmentError: boolean;

	hasAdditionalAddress: boolean;

	constructor(dto: AddressDto) {
		this.country = dto?.countryDto ? new Translation(dto.countryDto) : null;
		this.city = dto?.cityDto ? new City(dto.cityDto) : null;
		this.municipality = dto?.municipalityDto ? new Municipality(dto.municipalityDto) : null;
		this.region = dto?.regionDto ? new Region(dto.regionDto) : null;
		this.addressTypeId = dto?.addressTypeId ? dto.addressTypeId : null;
		this.postalCode = dto?.postalCode ? dto.postalCode : '';
		this.street = dto?.street ? dto.street : '';
		this.streetNumber = dto?.streetNumber ? dto.streetNumber : '';
		this.entrance = dto?.entrance ? dto.entrance : '';
		this.building = dto?.building ? dto.building : '';
		this.apartment = dto?.apartment ? dto.apartment : '';
	}

	public convertToAddressDto(): AddressDto {
		const addressDto = new AddressDto();
		
		if (this.country != null) {
			const countryDto = new TranslationDto(null);
			countryDto.key = this.country.key;
			countryDto.id = this.country.id;
			addressDto.countryDto = countryDto;
			return addressDto;
		}

		addressDto.addressTypeId = this.addressTypeId;
		addressDto.cityDto = new CityDto();
		addressDto.cityDto.cityCode = this.city.cityCode;
		addressDto.cityDto.key = this.city.key;
		addressDto.municipalityDto = new MunicipalityDto();
		addressDto.municipalityDto.code = this.municipality.code;
		addressDto.municipalityDto.key = this.municipality.key;
		addressDto.municipalityDto.regionCode = this.municipality.regionCode;
		addressDto.regionDto = new RegionDto();
		addressDto.regionDto.regionCode = this.region.regionCode;
		addressDto.regionDto.key = this.region.key;
		addressDto.apartment = this.apartment;
		addressDto.postalCode = this.postalCode ? this.postalCode : null;
		addressDto.street = this.street;
		addressDto.streetNumber = this.streetNumber;
		addressDto.entrance = this.entrance;
		addressDto.building = this.building;
		return addressDto;
	}

	public getAdditionalAddressAsString(): string {
		let additionalAddress = this.street;
		if (this.streetNumber && this.street) {
			additionalAddress = additionalAddress + ' ' + AddressDescriptions.NUMBER + this.streetNumber;
		}
		if (this.building) {
			additionalAddress = additionalAddress + ' ' + AddressDescriptions.BUILDING + this.building;
		}
		if (this.entrance) {
			additionalAddress = additionalAddress + ' ' + AddressDescriptions.ENTRANCE + this.entrance;
		}
		if (this.apartment) {
			additionalAddress = additionalAddress + ' ' + AddressDescriptions.APARTMENT + this.apartment;
		}
		if (this.postalCode) {
			additionalAddress = additionalAddress + ' ' + AddressDescriptions.POSTAL_CODE + this.postalCode;
		}

		return additionalAddress;
	}
}
