import { AdminSearchNomenclaturesDto } from '../interfaces/admin-search-nomenclatures-dto';
import { Translation } from './translation';
import { TranslationDto } from '../interfaces/translation-dto';

export class AdminSearchNomenclatures {
	applicationTypes: Translation[];
	authMethods: Translation[];
	paymentStatuses: Translation[];
	generalStatuses: Translation[];
	deliveryUnitsKey: string[];

	constructor(dto: AdminSearchNomenclaturesDto) {
		this.applicationTypes = dto ? dto.applicationTypes.map((type: TranslationDto) => new Translation(type)) : null;
		this.authMethods = dto ? dto.authMethods.map((method: TranslationDto) => new Translation(method)) : null;
		this.paymentStatuses = dto ? dto.paymentStatuses.map((paymentStatus: TranslationDto) => new Translation(paymentStatus)) : null;
		this.generalStatuses = dto ? dto.generalStatuses.map((generalStatus: TranslationDto) => new Translation(generalStatus)) : null;
		this.deliveryUnitsKey = dto ? dto.deliveryKeys : null;
	}
}
