import { AdrModuleDto } from '../dtos/adr-module-dto';

export class AdrModule {
	typeId: number;
	typeKey: string;
	issueDate: Date;
	attached: boolean;
	validTo: Date
	isSelected: boolean;
	//APPROVER
	validDateError: boolean;

	constructor(dto: AdrModuleDto) {
		this.typeId = dto ? dto.typeId : null;
		this.typeKey = dto ? dto.typeKey : '';
		this.issueDate = dto ? dto.issueDate : null;
		this.validTo = dto.validTo ? dto.validTo : null;
		this.attached = dto ? dto.attached : false;
		this.isSelected = false;
	}
}
