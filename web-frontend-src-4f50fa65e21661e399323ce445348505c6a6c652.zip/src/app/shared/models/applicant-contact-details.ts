import { ApplicantContactDetailsDto } from '../interfaces/applicant-contact-details-dto';
import { Address } from './address';

export class ApplicantContactDetails {
	permanentAddress: Address;
	currentAddress: Address;
	otherAddress: Address;

	constructor(dto: ApplicantContactDetailsDto) {
		this.permanentAddress = dto ? new Address(dto.permanentAddress) : null;
		this.currentAddress = dto ? new Address(dto.currentAddress) : null;
		this.otherAddress = dto ? new Address(dto.otherAddress) : null;
	}
}
