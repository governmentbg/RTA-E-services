import { ApplicationDraftDto } from '../interfaces/application-draft-dto';
import { Names } from './names';
import { Certificate } from './certificate';
import { AdrModule } from './adr-module';
import { AdrModuleDto } from '../dtos/adr-module-dto';
import { CertificateDto } from '../dtos/certificate-dto';
import { ATTACHED_DOCUMENT_TYPE } from '../enums/attached-document-types';
import { Translation } from './translation';
import { TranslationDto } from '../interfaces/translation-dto';
import { PersonalInfo } from './personal-info';
import { DrivingLicenceView } from './driving-licence-view';
import { ContactView } from './contact-view';
import { DeliveryInfo } from './delivery-info';
import { CardView } from './card-renewal-view';

export class ApplicationDraft {
	applicationId: number;
	applicationType: Translation;
	cardView: CardView;
	identityNumber: string;
	names: Names;
	attachedDocs: Translation[] = [];
	personalInfo: PersonalInfo;
	hasMvrCheck: boolean;
	hasDlMvrCheck: boolean;
	hasGraoCheck: boolean;
	hasAutoFixedPicturesFromMvr: boolean;

	contactView: ContactView;
	drivingLicence: DrivingLicenceView;
	delivery: DeliveryInfo;
	dqcCertificates: Certificate[];
	adrModules: AdrModule[];
	hasEditedPictures: boolean;

	constructor(private readonly dto: ApplicationDraftDto) {
		this.applicationId = dto ? dto.applicationId : null;
		this.applicationType = dto ?  new Translation(dto.applicationType) : null;
		this.cardView = dto?.cardViewDto ? new CardView(dto.cardViewDto) : null;
		this.identityNumber = dto ? dto.identityNumber : '';
		this.names = dto?.names ? new Names(dto.names) : null;
		this.hasMvrCheck = dto?.hasMvrCheck ? dto.hasMvrCheck : false;
		this.hasDlMvrCheck = dto?.hasDlMvrCheck ? dto.hasDlMvrCheck : false;
		this.hasGraoCheck = dto?.hasGraoCheck ? dto.hasGraoCheck : false;
		this.hasAutoFixedPicturesFromMvr = dto?.hasAutoFixedPicturesFromMvr ? dto.hasAutoFixedPicturesFromMvr : false;
		this.attachedDocs = dto?.attachedDocuments ? dto.attachedDocuments.map(
			(doc: TranslationDto) => new Translation(doc)) : null;
		this.personalInfo = dto?.personalInfoDto ? new PersonalInfo(dto.personalInfoDto) : null;
		this.contactView = dto?.contactInfoDto ? new ContactView(dto.contactInfoDto) : null;
		this.drivingLicence = dto?.drivingLicenceDto ? new DrivingLicenceView(dto.drivingLicenceDto) : null;
		this.delivery = dto?.deliveryDto ? new DeliveryInfo(dto.deliveryDto) : null;

		this.dqcCertificates = dto?.dqcCertificateDtos
			? dto.dqcCertificateDtos.map((certificate: CertificateDto) => new Certificate(certificate)) : null;
		this.adrModules = dto?.adrModuleDtos ? dto.adrModuleDtos.map((module: AdrModuleDto) => new AdrModule(module)) : null;

		this.setHasEditedPictures();
	}

	setHasEditedPictures() {
		const idsOfFaceAndSignature = this.attachedDocs.filter((doc: Translation) => (
			(doc.id === ATTACHED_DOCUMENT_TYPE.PICTURE_FACE) || (doc.id === ATTACHED_DOCUMENT_TYPE.PICTURE_SIGNATURE)));
		const faceAndSignatureDocTotalNumber = 2;
		this.hasEditedPictures =  idsOfFaceAndSignature.length === faceAndSignatureDocTotalNumber ? true : false;
	}
}
