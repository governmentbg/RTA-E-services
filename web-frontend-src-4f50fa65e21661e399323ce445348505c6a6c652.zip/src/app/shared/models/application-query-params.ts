import { QueryParams } from '../interfaces/query-params';

export class ApplicationSearchParams implements QueryParams {

	applicationId: number = null;
	authMethodId: number = null;
	applicationTypeId: number = null;
	dateFrom: Date = null;
	dateTo: Date = null;
	flagTypeId: number = null;
	paymentStatusId: number = null;
	statusId: number = null;
	firstName: string = null;
	secondName: string = null;
	familyName: string = null;
	identityNumber: string = null;
	deliveryUnitCode: string = null;

	toQueryParamsObject(): object {
		throw new Error('Method not implemented.');
	}

	hasParams(): boolean {
		if (this.authMethodId || this.applicationTypeId || 	this.dateFrom || this.dateTo
			|| this.paymentStatusId || this.statusId ||	this.flagTypeId || this.deliveryUnitCode) {
			return true;
		} else {
			return false;
		}
	}

	clearParams(): void {
		this.applicationId = null;
		this.authMethodId = null;
		this.applicationTypeId = null;
		this.dateFrom = null;
		this.dateTo = null;
		this.flagTypeId = null;
		this.paymentStatusId = null;
		this.statusId = null;
		this.firstName = null;
		this.secondName = null;
		this.familyName = null;
		this.deliveryUnitCode = null;
	}

	clearInputTypeParams(): void {
		this.applicationId = null;
		this.firstName = null;
		this.secondName = null;
		this.familyName = null;
	}
}

