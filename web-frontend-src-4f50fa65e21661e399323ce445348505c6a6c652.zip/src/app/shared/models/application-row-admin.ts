import { ApplicationLightDto } from '../interfaces/application-light-dto';
import { APPLICATION_TYPE_ADMIN_ICONS } from './constants/icon-classes/application-type-admin-icon-class';
import { AUTH_METHOD_ICONS } from './constants/icon-classes/auth-method-icon-class';
import { CORRESPONDENCE_ADMIN_ICONS } from './constants/icon-classes/correspondence-type-admin-icon-class';
import { DELIVERY_METHOD_ADMIN_ICONS } from './constants/icon-classes/delivery-method-admin-icon-class';
import { PAYMENT_STATUS_ICONS } from './constants/icon-classes/payment-status-icon-class';
import { GeneralStatusDescription } from './general-status-description';
import { APPLICATION_STATUS_ICONS } from './constants/icon-classes/application-statuses-icon-class';

export class ApplicationRowAdmin {
	applicationId: number;
	date: Date;
	namesInCyr: string;
	namesInLat: string;
	identityNumber: string;
	flags: number;
	statusClassName: string;
	applicationIconClass: string;
	powerOfAttorneyIconClass: string;
	correspondenceIconClass: string;
	authIconClass: string;
	paymentIconClass: string;
	authMethodKey: string;
	applicationStatusId: number;
	mainStatusTranslationKey: string;
	descriptionStatusTranslationKey: string;
	applicationStatusIconClass: string;
	lastStatusChange: Date;
	deliveryKey: string;

	constructor(private readonly dto: ApplicationLightDto) {
		this.applicationId = dto ? this.dto.applicationId : null;
		this.date = dto ? this.dto.date : null;
		this.namesInCyr = dto ? this.dto.names.namesInCyr : null;
		this.namesInLat = dto ? this.dto.names.namesInLat : null;
		this.identityNumber = dto ? this.dto.identityNumber : null;
		this.flags = dto ? this.dto.flags : null;
		this.authMethodKey = dto ? this.dto.authMethod.key : null;
		this.applicationIconClass = dto ? APPLICATION_TYPE_ADMIN_ICONS[this.dto.applicationTypeId] : null;
		this.powerOfAttorneyIconClass = dto ? AUTH_METHOD_ICONS[this.dto.authMethod.id].power : null;
		this.correspondenceIconClass = dto ? CORRESPONDENCE_ADMIN_ICONS[this.dto.correspondenceTypeId ] : null;
		this.authIconClass = dto ? AUTH_METHOD_ICONS[this.dto.authMethod.id].icon : null;
		this.paymentIconClass = dto ? PAYMENT_STATUS_ICONS[this.dto.paymentStatusId].icon : null;
		const applicationStatus = dto ? new GeneralStatusDescription(this.dto.applicationStatus) : null;
		this.applicationStatusId = dto ? applicationStatus.generalStatus.id : null;
		this.mainStatusTranslationKey = applicationStatus ? applicationStatus.generalStatus.key : null;
		this.descriptionStatusTranslationKey = applicationStatus ? applicationStatus.statusDescriptionKey : null;
		this.applicationStatusIconClass = applicationStatus ? APPLICATION_STATUS_ICONS[this.applicationStatusId] : null;
		this.lastStatusChange = dto ? dto.lastStatusChange : null;
		this.deliveryKey = dto?.deliveryKey ? dto.deliveryKey : null;
	}
}
