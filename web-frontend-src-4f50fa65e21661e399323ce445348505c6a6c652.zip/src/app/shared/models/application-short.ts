import { PaymentShortDto } from './../interfaces/payment-short-dto';

import { ApplicationShortDto } from '../interfaces/application-short-dto';
import { Warning } from './warning';
import { Remark } from './remark';
import { GeneralStatusDescription } from './general-status-description';
import { APPLICATION_TYPE_APPLICANT_ICONS } from './constants/icon-classes/application-type-applicant-icon-class';
import { APPLICATION_STATUS_ICONS } from './constants/icon-classes/application-statuses-icon-class';
import { Translation } from './translation';
import { ApplicationRemarkViewDto } from '../interfaces/application-remark-view-dto';
import { PaymentShort } from './payment-short';

export class ApplicationShort {
	applicationId: number;
	applicationType: Translation;
	warnings: Warning[];
	remarks: Remark[];
	applicationIconClass: string;
	statusClassName: string;
	applicationStatus: GeneralStatusDescription;
	hasInvoice: boolean;
	payments: PaymentShort[];

	constructor(private readonly dto: ApplicationShortDto) {
		this.applicationId = dto ? this.dto.applicationId : NaN;
		this.applicationType = dto ? new Translation(this.dto.applicationType) : null;
		this.applicationStatus = dto ? new GeneralStatusDescription(dto.applicationStatus) : null;
		this.warnings = this.dto.warningDtos;
		this.remarks = dto?.remarkDtos ? dto.remarkDtos.map((remark: ApplicationRemarkViewDto) => new Remark(remark)) : null;
		this.statusClassName = APPLICATION_STATUS_ICONS[this.applicationStatus.generalStatus.id];
		this.applicationIconClass = APPLICATION_TYPE_APPLICANT_ICONS[this.applicationType.id];
		this.hasInvoice = dto?.hasInvoice ? true : false;
		this.payments = dto?.payments ? dto.payments.map((payment: PaymentShortDto) => new PaymentShort(payment)) : null;
	}
}

