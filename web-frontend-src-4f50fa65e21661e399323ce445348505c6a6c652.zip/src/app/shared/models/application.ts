import { ApplicationDto } from '../interfaces/application-dto';
import { Summary } from './summary';
import { Names } from './names';
import { Certificate } from './certificate';
import { AdrModule } from './adr-module';
import { CertificateDto } from '../dtos/certificate-dto';
import { AdrModuleDto } from '../dtos/adr-module-dto';
import { DrivingLicenceView } from './driving-licence-view';
import { ContactView } from './contact-view';
import { PaymentInfo } from './payment-info';
import { TranslationDto } from '../interfaces/translation-dto';
import { Translation } from './translation';
import { PersonalInfo } from './personal-info';
import { DeliveryInfo } from './delivery-info';
import { CardView } from './card-renewal-view';
import { AdrExamInfo } from './exam/adr-exam-info';
import { MotorExamInfo } from './exam/motor-exam-info';
import { TaxiExamInfo } from './exam/taxi-exam-info';

export class Application {
	applicationTypeId: number;
	applicationTypeShortKey: string;
	statusId: number ;
	identityNumber: string;
	names: Names;
	summary: Summary;
	isEuCitizen: boolean;
	hasMvrCheck: boolean;
	hasAutoFixedPicturesFromMvr: boolean;
	personalInfo: PersonalInfo;
	hasDlMvrCheck: boolean;
	drivingLicence: DrivingLicenceView;
	cardView: CardView;
	contactView: ContactView;
	dqcCertificates: Certificate[];
	adrModules: AdrModule[];
	deliveryInfo: DeliveryInfo;
	payment: PaymentInfo;
	attachedDocuments: Translation[];

	adrExamInfo: AdrExamInfo;
	motorExamInfo: MotorExamInfo;
	taxiExamInfo: TaxiExamInfo;

	constructor(private readonly dto: ApplicationDto) {
		this.applicationTypeId = dto?.applicationTypeViewDto ? dto.applicationTypeViewDto.id : NaN;
		this.applicationTypeShortKey = dto?.applicationTypeViewDto?.key;
		this.identityNumber = dto.identityNumber;
		this.isEuCitizen = dto?.euCitizen ? dto.euCitizen : false;
		this.statusId = dto.summaryDto.shortApplication.applicationStatus.generalStatus.id;
		this.names = dto?.names ? new Names(dto.names) : null;
		this.summary = new Summary(dto.summaryDto);
		this.hasMvrCheck = dto?.hasMvrCheck ? true : false;
		this.hasAutoFixedPicturesFromMvr = dto?.hasAutoFixedPicturesFromMvr ? true : false;
		this.personalInfo = dto?.personalInfoDto ? new PersonalInfo(dto.personalInfoDto) : null;
		this.contactView = dto?.contactViewDto ? new ContactView(dto.contactViewDto) : null;
		this.hasDlMvrCheck =  dto?.hasDlMvrCheck ? true : false;
		this.drivingLicence = dto?.drivingLicenceDto ? new DrivingLicenceView(dto.drivingLicenceDto) : null;
		this.cardView = dto?.cardViewDto ? new CardView(dto.cardViewDto) : null;

		this.adrExamInfo = dto?.adrExamInfo ? new AdrExamInfo(dto.adrExamInfo) : null;
		this.motorExamInfo = dto?.motorExamInfo ? new MotorExamInfo(dto.motorExamInfo) : null;
		this.taxiExamInfo = dto?.taxiExamInfo ? new TaxiExamInfo(dto.taxiExamInfo) : null;

		this.dqcCertificates = dto?.dqcCertificateDtos
			? dto.dqcCertificateDtos.map((certificate: CertificateDto) => new Certificate(certificate)) : null;
		this.adrModules = dto?.adrModuleDtos ? dto.adrModuleDtos.map((module: AdrModuleDto) => new AdrModule(module)) : null;
		this.deliveryInfo = dto?.deliveryViewDto ? new DeliveryInfo(dto.deliveryViewDto) : null;
		this.attachedDocuments = dto?.attachedDocuments ? dto.attachedDocuments.map(
			(doc: TranslationDto) => new Translation(doc)) : null;

		this.payment = dto?.paymentDto ? new PaymentInfo(dto.paymentDto) : null;
	}
}
