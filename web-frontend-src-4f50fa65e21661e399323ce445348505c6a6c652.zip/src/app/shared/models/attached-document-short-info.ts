import { DocumentPageInfo } from './document-page-info';
import { AttachedDocumentShortInfoDto } from '../dtos/attached-document-short-info-dto';
import { DocumentPageDto } from '../dtos/document-page-dto';

export class AttachedDocumentShortInfo {
	declared: boolean;
	pagesInfo: DocumentPageInfo[];

	constructor(dto: AttachedDocumentShortInfoDto) {
		this.declared = dto.declared;
		this.pagesInfo = dto.pagesInfoShort.map((page: DocumentPageDto) => new DocumentPageInfo(page));
	}
}

