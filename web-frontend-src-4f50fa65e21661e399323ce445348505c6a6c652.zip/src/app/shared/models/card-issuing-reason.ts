import { CardIssuingReasonDto } from '../interfaces/card-issuing-reason-dto';

export class CardIssuingReason {
	id: number;
	translationKey: string;

	constructor(dto: CardIssuingReasonDto) {
		this.id = dto ? dto.id : null;
		this.translationKey = dto ? dto.key : '';
	}
}
