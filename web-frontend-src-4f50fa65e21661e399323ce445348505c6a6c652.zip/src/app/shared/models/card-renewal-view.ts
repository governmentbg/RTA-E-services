import { OldCard } from './old-card';
import { Names } from './names';
import { Translation } from './translation';
import { CardViewDto } from '../interfaces/card-dto';
import { OldCardDto } from '../dtos/old-card-dto';


export class CardView {
	issuingReason: Translation;
	oldCard: OldCard;
	names: Names;
	hasCardFromService: boolean;

	constructor(dto?: CardViewDto) {
		this.issuingReason = dto?.issuingReason ? new Translation(dto.issuingReason) : null;
		this.oldCard = dto?.oldCardDto ? new OldCard(dto.oldCardDto) : null;
		this.names = dto?.personNamesDto ? new Names(dto.personNamesDto) : null;
		this.hasCardFromService = dto?.hasCardFromService ? dto.hasCardFromService : false;
	}
}
