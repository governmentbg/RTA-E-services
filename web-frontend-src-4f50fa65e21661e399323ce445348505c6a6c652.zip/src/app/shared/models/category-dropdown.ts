import { CategoryDto } from '../interfaces/category-dto';
import { DrivingLicenceCategoryForm
	} from 'src/app/modules/application/new-application/driving-licence-section/driving-license-info-form/driving-licence-category-form';

export class CategoryDropDownDto {
	id: number;
	category: string;
	imageClass: string;
	isSelected: boolean;
	categoryForm = new DrivingLicenceCategoryForm();

	constructor(dto: CategoryDto) {
		this.id = dto ? dto.categoryId : null;
		this.category = dto ? dto.category : '';
		this.imageClass = dto ? dto.imageClass : '';
		this.categoryForm.categoryId.setValue(this.id);
		this.categoryForm.category.setValue(this.category);
	}
}
