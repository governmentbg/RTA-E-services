import { CategoryDto } from '../interfaces/category-dto';

export class Category {
	categoryId: number;
	category: string;
	acquisitionDate: Date;
	imageClass: string;

	acquisitionDateError: boolean;

	constructor(dto: CategoryDto) {
		this.categoryId = dto ? dto.categoryId : null;
		this.category = dto ? dto.category : '';
		this.acquisitionDate = dto?.acquisitionDate ? new Date(dto.acquisitionDate) : null;
		this.imageClass = dto ? dto.imageClass : '';
	}
}
