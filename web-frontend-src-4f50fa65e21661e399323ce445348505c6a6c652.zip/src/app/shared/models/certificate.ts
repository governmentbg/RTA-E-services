import { CertificateDto } from '../dtos/certificate-dto';

export class Certificate {
	typeId: number;
	permitNumber: string;
	certificateNumber: string;
	typeKey: string;
	legalBasisId: number;
	legalBasisKey: string;
	legalBasisType: string;
	trainingStart: Date;
	trainingEnd: Date;
	issuedOn: Date;
	attached: boolean;
	isSelected: boolean;

	// APPROVER
	permitNumberError: boolean;
	certificateNumberError: boolean;
	issuedOnError: boolean;
	trainingError: boolean;
	legalBasisTypeError: boolean;

	constructor(dto: CertificateDto) {
		this.permitNumber = dto ? dto.permitNumber : '';
		this.certificateNumber = dto ? dto.certificateNumber : '';
		this.typeId = dto ? dto.typeId : null;
		this.typeKey = dto ? dto.typeKey : '';
		this.trainingStart = dto ? new Date(dto.trainingStart) : null;
		this.trainingEnd = dto ? new Date(dto.trainingEnd) : null;
		this.issuedOn = dto ? new Date(dto.issuedOn) : null;
		this.legalBasisId = dto ? dto.legalBasisId : null;
		this.legalBasisKey = dto ? dto.legalBasisKey : '';
		this.legalBasisType = dto?.legalBasisType ? dto.legalBasisType : '';
		this.attached = dto?.attached ? dto.attached : false;
		this.isSelected = false;
	}

	public static areEqualForApprover(certificate: Certificate, certificateFromCheck: Certificate) {
		if (certificate.certificateNumber === certificateFromCheck.certificateNumber
			&& certificate.permitNumber === certificateFromCheck.permitNumber
			&& certificate.typeId === certificateFromCheck.typeId
			&& certificate.legalBasisType === certificateFromCheck.legalBasisType
			&& certificate.issuedOn.toString() === certificateFromCheck.issuedOn.toString()
			&& certificate.trainingStart.toString() === certificateFromCheck.trainingStart.toString()
			&& certificate.trainingEnd.toString() === certificateFromCheck.trainingEnd.toString()) {
			return true;
		}
		
		return false;
	}
}
