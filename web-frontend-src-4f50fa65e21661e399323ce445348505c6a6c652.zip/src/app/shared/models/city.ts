import { CityDto } from '../dtos/city-dto';

export class City {
	cityCode: string;
	key: string;

	constructor(dto: CityDto) {
		this.cityCode = dto?.cityCode ? dto.cityCode : '';
		this.key = dto?.key ? dto.key : '';
	}
}
