export const CARD_ISSUING_REASONS = {
	INITIAL_ISSUING: {
		id: 1,
		translationKey: 'card_issuing_reasons.initial_issuing'
	},
	NAME_CHANGE: {
		id: 5,
		translationKey: 'card_issuing_reasons.name_change'
	},
	TACHO_TAKEN_AWAY: {
		id: 11,
		translationKey: 'card_issuing_reasons.taken_away'
	}
};
