export const DROPDOWN_INITIAL_STATES = {
	countries: {
		id: 0,
		countryTranslationKey: 'dropdown.choose_country'
	}
};

