export const FLAG_TYPE_DROPDOWN = [
	// TODO : remove ts.file when has nomenclature from backend
	{
		id: '1',
		name: 'Нужни проверки'
	},
	{
		id: '2',
		name: 'Предупреждения'
	},
	{
		id: '3',
		name: 'Забележки'
	}
];

