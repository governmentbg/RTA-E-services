export const APPLICATION_STATUS_ICONS = {
	// 'status-requested-partially-paid'
	1 : 'status-draft',
	2 : 'status-requested',
	3 : 'status-requested-rejected',
	4 : 'status-processing',
	5 : 'status-approved-rejected',
	6 : 'status-returned',
	7 : 'status-requested-rejected',
	8 : 'status-approved',
	9 : 'status-received-iaaa',
	10 : 'status-delivered',
};

