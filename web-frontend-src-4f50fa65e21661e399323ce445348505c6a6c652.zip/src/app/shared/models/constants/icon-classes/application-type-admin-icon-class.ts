export const APPLICATION_TYPE_ADMIN_ICONS = {
	1: 'icon-application-type-dt',
	2: 'icon-application-type-kk',
	3: 'icon-application-type-adr-card',
	4: 'icon-application-type-kkot',
	5: 'icon-application-type-ppu',
	6: 'icon-application-type-taxi',
	7: 'icon-application-type-adr'
};



