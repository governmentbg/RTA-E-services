export const APPLICATION_TYPE_APPLICANT_ICONS = {
	1: 'icon-application-request-type-dt',
	2: 'icon-application-request-type-kk',
	3: 'icon-application-request-type-adr-card',
	4: 'icon-application-request-type-kkot',
	5: 'icon-application-request-type-ppu',
	6: 'icon-application-request-type-taxi',
	7: 'icon-application-request-type-adr',
};
