export const AUTH_METHOD_ICONS = {
	1: { icon: 'icon-auth-face', power: 'icon-auth-in-person' },
	2: { icon: 'icon-auth-kep', power: 'icon-auth-in-person' },
	3: { icon: 'icon-auth-iaaa', power: 'icon-auth-in-person' },
	4: { icon: 'icon-auth-iaaa', power: 'icon-auth-with-attorney' },
};
