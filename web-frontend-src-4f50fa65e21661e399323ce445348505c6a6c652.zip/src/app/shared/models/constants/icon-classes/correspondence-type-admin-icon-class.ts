export const CORRESPONDENCE_ADMIN_ICONS = {
	0: 'icon-notification-mail', // no contact yet
	1: 'icon-notification-mail', // address
	2: 'icon-notification-mail', // address
	3: 'icon-notification-mail', // address
	4: 'icon-notification-mail', // email
	5: 'icon-notification-mail', // phone
};
