export const DELIVERY_METHOD_ADMIN_ICONS = {
	0: 'icon-delivery-iaaa', // Default picture grey
	1: 'icon-delivery-iaaa', // Desk
	2: 'icon-delivery-iaaa', // Courier
};
