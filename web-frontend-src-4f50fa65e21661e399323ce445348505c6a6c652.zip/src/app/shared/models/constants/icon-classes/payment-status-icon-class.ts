export const PAYMENT_STATUS_ICONS = {
	// TODO : change icon classes
	1: { icon: 'paid' },
	2: { icon: 'paid' },
	3: { icon: 'paid' },
	4: { icon: 'paid' },
};
