export const TABLE_CLASS_NAME_BASED_ON_USER_ROLE = {
	1 : 'role-status-desk',
	2 : 'role-status-desk',
	3 : 'role-status-approver',
	4 : 'role-status-accountant',
	5 : 'role-status-desk',
	6 : 'role-status-desk',
	7 : 'role-status-accountant',
	8 : 'role-status-desk',
	9 : 'role-status-perso',
};
