export const PAYMENT_STATUS_CODES = {
	WAITING : 'WAITING',
	PAID: 'PAID',
	DENIED: 'DENIED',
	EXPIRED: 'EXPIRED',
	ERROR: 'ERROR'
};

export type ApplicationPaymentStatuses = typeof PAYMENT_STATUS_CODES;
