import { PopUpTypes } from '../../enums/pop-up-types';
import { POP_UP_MESSAGES_KEYS } from './pop-up-messages-keys';

export const DEFAULT_POP_UPS = {
	error: {
		header: POP_UP_MESSAGES_KEYS.error_header_default,
		subHeader: POP_UP_MESSAGES_KEYS.try_again_later,
		type: PopUpTypes.ERROR
	},

	error_access_denied: {
		header: POP_UP_MESSAGES_KEYS.error_header_access_denied,
		type: PopUpTypes.ERROR
	},

	error_bad_request: {
		header: POP_UP_MESSAGES_KEYS.error_header_bad_request,
		type: PopUpTypes.ERROR
	},

	error_not_found: {
		header: POP_UP_MESSAGES_KEYS.error_header_not_found,
		type: PopUpTypes.ERROR
	},

	error_cannot_get_application_status: {
		header: POP_UP_MESSAGES_KEYS.error_header_not_found_app_status,
		subHeader: POP_UP_MESSAGES_KEYS.refresh_page,
		type: PopUpTypes.ERROR
	},

	error_mvr_does_not_work: {
		header: POP_UP_MESSAGES_KEYS.error_mvr_does_not_work,
		subHeader: POP_UP_MESSAGES_KEYS.try_again_later,
		type: PopUpTypes.ERROR
	},

	error_application_not_submitted: {
		header: POP_UP_MESSAGES_KEYS.error_application_not_submitted,
		subHeader: POP_UP_MESSAGES_KEYS.try_again_later,
		type: PopUpTypes.ERROR
	},

	error_application_of_type_already_exists: {
		header: POP_UP_MESSAGES_KEYS.error_application_not_created,
		subHeader: POP_UP_MESSAGES_KEYS.error_application_of_type_already_exists,
		type: PopUpTypes.ERROR
	},

	error_certificate_of_type_already_exists: {
		header: POP_UP_MESSAGES_KEYS.error_certificate_already_uloaded,
		subHeader: POP_UP_MESSAGES_KEYS.choose_different_type_certificate,
		type: PopUpTypes.ERROR
	},

	error_date_of_chosen_module_not_correct: {
		header: POP_UP_MESSAGES_KEYS.error_can_not_add_module,
		subHeader: POP_UP_MESSAGES_KEYS.error_date_of_chosen_module,
		type: PopUpTypes.ERROR
	},

	error_must_choose_basic_module_first: {
		header: POP_UP_MESSAGES_KEYS.error_can_not_add_module,
		subHeader: POP_UP_MESSAGES_KEYS.error_choose_basic_module_first,
		type: PopUpTypes.ERROR
	},

	error_missing_documents: {
		header: POP_UP_MESSAGES_KEYS.error_missing_documents,
		type: PopUpTypes.ERROR
	},

	error_missing_certificate_info: {
		header: POP_UP_MESSAGES_KEYS.error_missing_certificate_info,
		type: PopUpTypes.ERROR
	},

	error_missing_module: {
		header: POP_UP_MESSAGES_KEYS.error_missing_module,
		subHeader: POP_UP_MESSAGES_KEYS.error_can_not_continue_application,
		type: PopUpTypes.ERROR
	},

	error_missing_basic_module: {
		header: POP_UP_MESSAGES_KEYS.error_missing_basic_module,
		subHeader: POP_UP_MESSAGES_KEYS.error_can_not_continue_application,
		type: PopUpTypes.ERROR
	},

	error_missing_certificate: {
		header: POP_UP_MESSAGES_KEYS.error_missing_certificate,
		subHeader: POP_UP_MESSAGES_KEYS.error_can_not_continue_application,
		type: PopUpTypes.ERROR
	},

	error_document_can_have_max_two_pages: {
		header: POP_UP_MESSAGES_KEYS.error_document_can_have_max_two_pages,
		type: PopUpTypes.ERROR
	},

	error_cannot_upload_more_than_one_file: {
		header: POP_UP_MESSAGES_KEYS.error_cannot_upload_more_than_one_file,
		type: PopUpTypes.ERROR
	},

	error_cannot_upload_folder: {
		header: POP_UP_MESSAGES_KEYS.error_cannot_upload_folder,
		type: PopUpTypes.ERROR
	},

	error_cannot_generate_application: {
		header: POP_UP_MESSAGES_KEYS.error_cannot_generate_application,
		subHeader: POP_UP_MESSAGES_KEYS.try_again_later,
		type: PopUpTypes.ERROR
	},

	error_cannot_generate_application_missing_required_documents: {
		header: POP_UP_MESSAGES_KEYS.error_cannot_generate_application_missing_required_documents,
		type: PopUpTypes.ERROR
	},

	error_cannot_upload_file: {
		header: POP_UP_MESSAGES_KEYS.error_cannot_upload_file,
		subHeader: POP_UP_MESSAGES_KEYS.try_again_later,
		type: PopUpTypes.ERROR
	},

	error_could_not_delete_file: {
		header: POP_UP_MESSAGES_KEYS.error_could_not_delete_file,
		subHeader: POP_UP_MESSAGES_KEYS.try_again_later,
		type: PopUpTypes.ERROR
	},

	error_could_not_declare_document: {
		header: POP_UP_MESSAGES_KEYS.error_could_not_declare_document,
		subHeader: POP_UP_MESSAGES_KEYS.try_again_later,
		type: PopUpTypes.ERROR
	},

	error_file_name_too_long: {
		header: POP_UP_MESSAGES_KEYS.error_file_name_too_long,
		type: PopUpTypes.ERROR
	},

	error_only_upload_type_file: {
		header: POP_UP_MESSAGES_KEYS.error_only_upload_type_file,
		type: PopUpTypes.ERROR
	},

	error_max_upload_size: {
		header: POP_UP_MESSAGES_KEYS.error_max_upload_size,
		type: PopUpTypes.ERROR
	},

	error_file_name_not_correct: {
		header: POP_UP_MESSAGES_KEYS.error_file_name_not_correct,
		type: PopUpTypes.ERROR
	},

	error_can_not_open_file_try_later: {
		header: POP_UP_MESSAGES_KEYS.error_can_not_open_file_try_later,
		type: PopUpTypes.ERROR
	},

	error_section_locked: {
		header: POP_UP_MESSAGES_KEYS.error_complete_steps_to_continue,
		type: PopUpTypes.ERROR
	},

	error_can_not_cancel_application_now: {
		header: POP_UP_MESSAGES_KEYS.error_can_not_cancel_application_now,
		type: PopUpTypes.ERROR
	},

	error_can_not_generate_payment_order_try_later: {
		header: POP_UP_MESSAGES_KEYS.error_can_not_generate_payment_order_try_later,
		type: PopUpTypes.ERROR
	},

	error_can_not_get_document_try_later: {
		header: POP_UP_MESSAGES_KEYS.error_can_not_get_document_try_later,
		type: PopUpTypes.ERROR
	},

	error_can_not_create_payment_try_later: {
		header: POP_UP_MESSAGES_KEYS.error_can_not_create_payment_try_later,
		type: PopUpTypes.ERROR
	},

	error_can_not_get_application_taxes_try_later: {
		header: POP_UP_MESSAGES_KEYS.error_can_not_get_application_taxes_try_later,
		type: PopUpTypes.ERROR
	},

	delete: {
		header: POP_UP_MESSAGES_KEYS.delete_header,
		subHeader: POP_UP_MESSAGES_KEYS.delete_sub_header,
		text: POP_UP_MESSAGES_KEYS.delete_text,
		type: PopUpTypes.WARNING
	},

	delete_application: {
		header: POP_UP_MESSAGES_KEYS.warning_application_will_be_deleted,
		subHeader: POP_UP_MESSAGES_KEYS.delete_sub_header,
		text: POP_UP_MESSAGES_KEYS.delete_text,
		type: PopUpTypes.WARNING
	},

	success: {
		header: POP_UP_MESSAGES_KEYS.success_header_default,
		type: PopUpTypes.SUCCESS
	},

	warning_application_will_be_submitted: {
		header: POP_UP_MESSAGES_KEYS.warning_application_will_be_submitted,
		subHeader: POP_UP_MESSAGES_KEYS.warning_continue,
		type: PopUpTypes.WARNING
	},

	warning_application_will_be_canceled: {
		header: POP_UP_MESSAGES_KEYS.warning_application_will_be_canceled,
		subHeader: POP_UP_MESSAGES_KEYS.warning_continue,
		type: PopUpTypes.WARNING
	},

	warning_changes_will_be_saved: {
		header: POP_UP_MESSAGES_KEYS.warning_are_you_sure_want_leave_application,
		subHeader: POP_UP_MESSAGES_KEYS.warning_changes_will_be_saved,
		type: PopUpTypes.WARNING
	},

	warning_finish_current_changes: {
		header: POP_UP_MESSAGES_KEYS.warning_finish_your_current_changes,
		type: PopUpTypes.WARNING
	},

	success_application_submitted: {
		header: POP_UP_MESSAGES_KEYS.success_application_submitted,
		subHeader: POP_UP_MESSAGES_KEYS.hours_to_pay,
		type: PopUpTypes.SUCCESS
	},

	info_approver_message: {
		subHeader: POP_UP_MESSAGES_KEYS.info_enter_reasons,
		type: PopUpTypes.APPROVER_MESSAGE
	},

	check_application: {
		type: PopUpTypes.CHECK
	}
};
