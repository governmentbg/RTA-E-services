import { ContactInfoDto } from '../interfaces/contact-info-dto';

export class ContactInfo {
	contactType: string;
	contactValue: string;

	constructor(dto: ContactInfoDto) {
		this.contactType = dto ? dto.contactType : '';
		this.contactValue = dto ? dto.contactValue : '';
	}
}
