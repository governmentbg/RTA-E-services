import { ContactViewDto } from '../interfaces/contact-view-dto';
import { Address } from './address';
import { PhoneNumber } from './phone-number';

export class ContactView {
	address: Address;
	email: string;
	phoneNumberObj: PhoneNumber;
	contactTypeId: number;

	constructor(dto: ContactViewDto) {
		this.address = dto?.address ? new Address(dto.address) : null;
		this.email = dto ? dto.email : '';
		this.phoneNumberObj = dto?.phoneNumberDto ? new PhoneNumber(dto.phoneNumberDto) : null;
		this.contactTypeId = dto ? dto.contactTypeId : null;
	}
}
