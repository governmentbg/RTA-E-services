import { ContractDto } from '../interfaces/contract-dto';

export class Contract {
	startDate: Date;
	endDate: Date;
	timeLimit: Date;
	professionCode: string;
	professionName: string;

	constructor(dto: ContractDto) {
		this.startDate = dto?.startDate ? new Date(dto.startDate) : null;
		this.endDate = dto?.endDate ? new Date(dto.endDate) : null;
		this.timeLimit = dto?.timeLimit ? new Date(dto.timeLimit) : null;
		this.professionCode = dto?.professionCode ? dto.professionCode : '';
		this.professionName = dto?.professionName ? dto.professionName : '';
	}
}
