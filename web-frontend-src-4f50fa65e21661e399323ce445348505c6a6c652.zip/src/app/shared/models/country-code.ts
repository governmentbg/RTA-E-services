import { CountryCodeDto } from '../interfaces/country-code-dto';

export class CountryCode {
	id: number;
	code: string;
	countryTranslationKey: string;
	countryCode2: string;

	constructor(dto: CountryCodeDto) {
		this.id = dto ? dto.id : null;
		this.code = dto ? dto.code : '';
		this.countryTranslationKey = dto ? dto.countryTranslationKey : '';
		this.countryCode2 = dto ? dto.countryCode2 : '';
	}
}
