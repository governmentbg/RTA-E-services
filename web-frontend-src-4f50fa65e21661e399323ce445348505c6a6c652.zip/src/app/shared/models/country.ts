import { CountryDto } from "../interfaces/country-dto";
import { Translation } from "./translation";


export class Country {
	country: Translation;
	isEu: boolean;

	constructor(dto: CountryDto) {
		this.country = dto?.country ? new Translation(dto.country) : null;
		this.isEu = dto?.eu ? dto.eu : false;
	}
}