import { Address } from './address';
import { OrgUnit } from './org-unit';
import { DeliveryInfoDto } from '../dtos/delivery-info-dto';

export class DeliveryInfo {
	deliveryTypeId: number;
	orgUnit: OrgUnit;
	address: Address;

	constructor(dto: DeliveryInfoDto) {
		if (dto !== null) {
			this.deliveryTypeId = dto.deliveryTypeId;
			this.address = new Address(dto.address);
			this.orgUnit = new OrgUnit(dto.orgUnitDto);
		}
	}

	convertToDeliveryIntoDto(): DeliveryInfoDto {
		const dto = new DeliveryInfoDto();
		dto.address = this.address.convertToAddressDto();
		dto.deliveryTypeId = this.deliveryTypeId;
		dto.orgUnitDto = this.orgUnit.convertToOrgUnitDto();
		return dto;
	}
}
