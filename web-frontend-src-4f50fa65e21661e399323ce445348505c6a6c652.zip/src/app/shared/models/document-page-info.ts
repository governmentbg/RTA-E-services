import { DocumentPageDto } from '../dtos/document-page-dto';

export class DocumentPageInfo {
	pageId: number = null;
	pageName: string = null;
	pageFileSize: number = null;
	uploadProgress: number = null;
	file: File = null;

	constructor(data: DocumentPageDto | File) {
		// when file came from browser
		if (data instanceof File) {
			this.pageName = data.name;
			this.pageFileSize = data.size;
			this.uploadProgress = 0;
			this.file = data;
		} else { // when file came from database
			this.pageId = data.id;
			this.pageName = data.name;
			this.pageFileSize = data.size;
			this.uploadProgress = 100;
		}
	}
}
