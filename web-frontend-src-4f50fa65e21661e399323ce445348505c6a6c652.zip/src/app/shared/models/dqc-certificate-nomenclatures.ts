import { DqcCertificateNomenclaturesDto } from '../interfaces/dqc-certificate-nomenclatures-dto';
import { Translation } from './translation';
import { TranslationDto } from '../interfaces/translation-dto';

export class DqcCertificateNomenclatures {
	legalBasisTypes: Translation[];
	certificateTypes: Translation[];

	constructor(dto: DqcCertificateNomenclaturesDto) {
		this.legalBasisTypes = dto ? dto.legalBasisTypes.map((type: TranslationDto) => new Translation(type)) : null;
		this.certificateTypes = dto ? dto.certificateTypes.map((method: TranslationDto) => new Translation(method)) : null;
	}
}
