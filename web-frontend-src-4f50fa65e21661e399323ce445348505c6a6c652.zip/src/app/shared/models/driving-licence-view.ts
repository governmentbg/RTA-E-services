import { Category } from './category';
import { DrivingLicenceViewDto } from '../interfaces/driving-licence-view-dto';
import { Translation } from './translation';


export class DrivingLicenceView {
	documentNumber: string;
	validity: Date;
	issuedOn: Date;
	issuedBy: Translation;
	categories: Category [] = [];
	bulgarian: boolean;
	// APPROVER
	differences: number;
	documentNumberError: boolean;
	validityError: boolean;
	issuedOnError: boolean;
	issuedByError: boolean;
	bulgarianError: boolean;

	constructor(dto: DrivingLicenceViewDto) {
		this.documentNumber = dto ? dto.documentNumber : '';
		this.validity = dto?.expirationDate ? new Date(dto.expirationDate) : null;
		this.issuedOn = dto?.issuedOn ? new Date(dto.issuedOn) : null;
		this.issuedBy = dto?.issuedBy ? new Translation(dto.issuedBy) : null;
		this.bulgarian = dto?.bulgarian ? dto.bulgarian : false;
		if (dto != null && dto.categories != null) {
			dto.categories.forEach(category => {
				this.categories.push(new Category(category));
			});
		}
	}
}
