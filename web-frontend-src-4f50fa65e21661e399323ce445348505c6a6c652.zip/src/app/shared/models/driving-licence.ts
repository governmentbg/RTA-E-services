
import { DrivingLicenceDto } from '../interfaces/driving-licence-dto';
import { Category } from './category';
import { Translation } from './translation';

export class DrivingLicence {
	documentNumber: string;
	dateOfExpiry: Date;
	dateOfIssue: Date;
	bulgarian: boolean;
	issuedBy: Translation;
	categories: Category [] = [];

	constructor(dto: DrivingLicenceDto) {
		this.documentNumber = dto ? dto.documentNumber : '';
		this.dateOfIssue = dto ? dto.issuedOn : null;
		this.dateOfExpiry = dto ? dto.expirationDate : null;
		this.issuedBy = dto?.issuedBy ? new Translation(dto.issuedBy) : null;
		this.bulgarian = dto ? dto.bulgarian : null;
		if (dto != null && dto.categories != null) {
			dto.categories.forEach(category => {
				this.categories.push(new Category(category));
			});
		}
	}
}
