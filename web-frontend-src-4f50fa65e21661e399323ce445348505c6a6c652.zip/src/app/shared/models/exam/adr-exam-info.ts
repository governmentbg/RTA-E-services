import { AdrExamPersonSelection } from "src/app/modules/application/new-application/adr-exam-people/adr-exam-person-selection.model";
import { ServiceOptions } from "src/app/modules/application/new-application/adr-exam-service-options/adr-exam-service-options.component";
import { AdrExamProtocolSelection } from "src/app/modules/application/new-application/exam-protocol-selection/adr-exam-protocol-selection.model";
import { AdrExamInfoDto } from "../../interfaces/exam/adr-exam-info-dto";
import { OrgUnit } from "../org-unit";

export class AdrExamInfo {

    selectedAdrExamPerson: AdrExamPersonSelection;
    selectedOrgUnit: OrgUnit;
    selectedAdrProtocol: AdrExamProtocolSelection;
    isConsultantExtension: boolean;

    constructor(dto: AdrExamInfoDto) {
        this.selectedAdrExamPerson = new AdrExamPersonSelection(dto.selectedAdrExamPerson);
        this.selectedOrgUnit = new OrgUnit(dto.selectedOrgUnit);
        this.selectedAdrProtocol = new AdrExamProtocolSelection(dto.selectedAdrProtocol);
        this.isConsultantExtension = dto.isConsultantExtension;
    }

    public get selectedServiceOption(): ServiceOptions {
        if (this.isConsultantExtension === true) {
            return ServiceOptions.EXTENSION;
        } else if (this.isConsultantExtension === false) {
            return ServiceOptions.INITIAL;
        }
        return null;
    }
}