import { MotorExamProtocolSelection } from "src/app/modules/application/new-application/exam-protocol-selection/motor-exam-protocol-selection.model";
import { CategoryDto } from "../../interfaces/category-dto";
import { MotorExamInfoDto } from "../../interfaces/exam/motor-exam-info-dto";
import { MotorExamPersonSelectionDto } from "../../interfaces/motor-exam-person-selection-dto";
import { MotorExamProtocolSelectionDto } from "../../interfaces/motor-exam-protocol-selection-dto";
import { Category } from "../category";
import { MotorExamPersonSelection } from "./motor-exam-person-selection";

export class MotorExamInfo {
    selectedMotorExamPerson: MotorExamPersonSelectionDto;
	selectedMotorProtocol: MotorExamProtocolSelectionDto;
	selectedCategory: CategoryDto;

    constructor(dto: MotorExamInfoDto) {
		this.selectedMotorExamPerson = dto?.selectedMotorExamPerson ? new MotorExamPersonSelection(dto.selectedMotorExamPerson) : null;
		this.selectedMotorProtocol = dto?.selectedMotorProtocol ? new MotorExamProtocolSelection(dto.selectedMotorProtocol) : null;
		this.selectedCategory = dto?.selectedCategory ? new Category(dto.selectedCategory) : null;
    }
}