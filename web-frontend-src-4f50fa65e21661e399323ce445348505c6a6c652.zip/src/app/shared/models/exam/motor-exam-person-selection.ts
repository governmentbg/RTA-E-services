import { MotorExamPersonSelectionDto } from "../../interfaces/motor-exam-person-selection-dto";
import { OrgUnit } from "../org-unit";

export class MotorExamPersonSelection {
    examPersonId: number;
	orgUnit: OrgUnit;
	learningPlanName: string;
	theoreticalExamResult: string;

    constructor(dto: MotorExamPersonSelectionDto) {
        this.examPersonId = dto.examPersonId;
        this.learningPlanName = dto.learningPlanName;
        this.orgUnit = new OrgUnit(dto.orgUnit);
        this.theoreticalExamResult = dto.theoreticalExamResult;
    }
}