import { MotorExamProtocolSelection } from "src/app/modules/application/new-application/exam-protocol-selection/motor-exam-protocol-selection.model";
import { TaxiExamInfoDto } from "../../interfaces/exam/taxi-exam-info-dto";

export class TaxiExamInfo {
	selectedMotorProtocol: MotorExamProtocolSelection;

	constructor(dto: TaxiExamInfoDto) {
		this.selectedMotorProtocol = dto?.selectedMotorProtocol ? new MotorExamProtocolSelection(dto.selectedMotorProtocol) : null;
	}
}