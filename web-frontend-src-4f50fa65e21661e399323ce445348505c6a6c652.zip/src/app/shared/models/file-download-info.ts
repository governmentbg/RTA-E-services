export class FileDownloadInfo {
	downloadProgress = 0;
	blob: Blob = null;
}
