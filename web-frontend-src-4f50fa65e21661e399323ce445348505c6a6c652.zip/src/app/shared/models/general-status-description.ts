import { GeneralStatusDescriptionDto } from '../interfaces/general-status-description-dto';
import { Translation } from './translation';

export class GeneralStatusDescription {
	generalStatus: Translation;
	statusDescriptionKey: string;

	constructor(dto: GeneralStatusDescriptionDto) {
		this.generalStatus = dto ? new Translation(dto.generalStatus) : null;
		this.statusDescriptionKey = dto ? dto.statusDescriptionKey : '';
	}
}
