import { LanguageDto } from '../interfaces/language-dto';

export class Language {
	public code: string;
	public name: string;

	constructor(dto: LanguageDto) {
		this.code = dto ? dto.code : '';
		this.name = dto ? dto.name : '';
	}
}
