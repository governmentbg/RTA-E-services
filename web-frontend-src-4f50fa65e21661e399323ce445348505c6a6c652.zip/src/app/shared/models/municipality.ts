import { MunicipalityDto } from '../dtos/municipality-dto';

export class Municipality {
	code: string;
	regionCode: string;
	key: string;

	constructor(dto: MunicipalityDto) {
		this.code = dto ? dto.code : '';
		this.regionCode = dto ? dto.regionCode : '';
		this.key = dto ? dto.key : '';
	}
}
