import { NamesDto } from '../interfaces/names-dto';

export class Names {
	firstNameCyr: string;
	fatherNameCyr: string;
	familyNameCyr: string;
	firstNameLat: string;
	fatherNameLat: string;
	familyNameLat: string;
	// APPROVER
	firstNameCyrError: boolean;
	fatherNameCyrError: boolean;
	familyNameCyrError: boolean;
	firstNameLatError: boolean;
	fatherNameLatError: boolean;
	familyNameLatError: boolean;

	constructor(dto: NamesDto) {
		this.firstNameCyr = dto?.firstNameCyr ? dto.firstNameCyr : '';
		this.fatherNameCyr = dto?.fatherNameCyr ? dto.fatherNameCyr : '';
		this.familyNameCyr = dto?.familyNameCyr ? dto.familyNameCyr : '';
		this.firstNameLat = dto?.firstNameLat ? dto.firstNameLat : '';
		this.fatherNameLat = dto?.fatherNameLat ? dto.fatherNameLat : '';
		this.familyNameLat = dto?.familyNameLat ? dto.familyNameLat : '';
	}

	public getFullNameCyr(): string {
		if (this.fatherNameCyr && this.familyNameCyr) {
			return this.firstNameCyr + ' ' + this.fatherNameCyr + ' ' + this.familyNameCyr;
		} else if (!this.fatherNameCyr) {
			return this.firstNameCyr + ' ' + this.familyNameCyr;
		} else {
			return this.firstNameCyr;
		}
	}

	public getFullNameLat(): string {
		if (this.fatherNameLat) {
			return this.firstNameLat + ' ' + this.fatherNameLat + ' ' + this.familyNameLat;
		} else {
			return this.firstNameLat + ' ' + this.familyNameLat;
		}
	}
}
