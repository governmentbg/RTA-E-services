import { OldCardDto } from '../dtos/old-card-dto';
import { Translation } from './translation';

export class OldCard {
	cardNumber: string;
	validity: Date;
	issuingCountry: Translation;
	issuedBy: string;
	place: string;
	date: Date;

	//APPROVER
	differences: number;
	cardNumberError: boolean;
	validityError: boolean;
	issuedByError: boolean;
	issuingCountryError: boolean;

	constructor(dto: OldCardDto) {
		this.cardNumber = dto ? dto.cardNumber : null;
		this.validity = dto ? new Date(dto.validity) : null;
		this.place = dto?.place ? dto.place : null;
		this.date = dto?.date ? dto.date : null;
		this.issuingCountry = dto ? new Translation(dto.issuingCountry) : null;
		this.issuedBy = dto ? dto.issuedBy : '';
	}
}
