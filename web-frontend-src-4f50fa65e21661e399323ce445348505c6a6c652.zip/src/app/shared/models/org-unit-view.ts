import { OrgUnitViewDto } from '../interfaces/org-unit-view-dto';

export class OrgUnitView {
	name: string;
	cityKey: string;
	phoneNumber: string;
	address: string;

	constructor(dto: OrgUnitViewDto) {
		this.name = dto ? dto.name : '';
		this.cityKey = dto ? dto.cityKey : '';
		this.address = dto ? dto.address : '';
		this.phoneNumber = dto ? dto.phoneNumber : '';
	}
}
