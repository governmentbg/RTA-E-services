import { OrgUnitDto } from '../dtos/org-unit-dto';

export class OrgUnit {
	code: string;
	name: string;
	cityTranslationKey: string;
	address: string;
	phoneNumber: string;

	constructor(dto: OrgUnitDto) {
		if (dto !== null) {
			this.code = dto?.code ? dto.code : '';
			this.name = dto?.name ? dto.name : '';
			this.cityTranslationKey = dto?.cityTranslationKey ? dto.cityTranslationKey : '';
			this.address = dto?.address ? dto.address : '';
			this.phoneNumber = dto?.phoneNumber ? dto.phoneNumber : '';
		}
	}

	convertToOrgUnitDto(): OrgUnitDto {
		const dto = new OrgUnitDto();
		dto.address = this.address;
		dto.name = this.name;
		dto.cityTranslationKey = this.cityTranslationKey;
		dto.code = this.code;
		dto.phoneNumber = this.phoneNumber;
		// tslint:disable-next-line: triple-equals
		if (typeof this.address != 'undefined') {
			return null;
		}
		return dto;
	}
}
