
import { PAYMENT_METHODS } from '../enums/payment-methods';
import { PaymentViewDto } from '../interfaces/payment-view-dto';
import { PAYMENT_STATUS_CODES } from './constants/payment-status-codes';

export class PaymentInfo {
	applicationTypeKey: string;

	processingFeeStatus: string;
	processingFeeMethodId: number;
	isPaidProcessingFee: boolean;
	isWaitingProcessingFee: boolean;
	isProcessingMethodByBank: boolean;
	isProcessingMethodByEPay: boolean;
	isProcessingMethodByEasyPay: boolean;

	personalizationFeeStatus: string;
	personalizationFeeMethodId: number;
	isPaidPersonalizationFee: boolean;
	isWaitingPersonalizationFee: boolean;
	isPersonalizationMethodByBank: boolean;
	isPersonalizationMethodByEPay: boolean;
	isPersonalizationMethodByEasyPay: boolean;

	constructor(dto: PaymentViewDto) {
		this.applicationTypeKey = dto ? dto.applicationTypeShortKey : '';

		this.processingFeeStatus = dto?.processingFeeStatus ? dto.processingFeeStatus : '';
		this.processingFeeMethodId = dto?.processingFeeMethodId ? dto.processingFeeMethodId : NaN;
		this.isPaidProcessingFee = dto?.processingFeeStatus
			&& dto.processingFeeStatus === PAYMENT_STATUS_CODES.PAID ? true : false;
		this.isWaitingProcessingFee = dto?.processingFeeStatus
		&& dto.processingFeeStatus === PAYMENT_STATUS_CODES.WAITING ? true : false;
		this.isProcessingMethodByBank = this.processingFeeMethodId === PAYMENT_METHODS.BANK ? true : false;
		this.isProcessingMethodByEPay = this.processingFeeMethodId === PAYMENT_METHODS.E_PAY ? true : false;
		this.isProcessingMethodByEasyPay = this.processingFeeMethodId === PAYMENT_METHODS.EASY_PAY ? true : false;

		this.personalizationFeeStatus = dto ? dto.personalizationFeeStatus : '';
		this.personalizationFeeMethodId = dto ? dto.personalizationFeeMethodId : NaN;
		this.isPaidPersonalizationFee = dto?.personalizationFeeStatus
			&& dto.personalizationFeeStatus === PAYMENT_STATUS_CODES.PAID ? true : false;
		this.isWaitingPersonalizationFee = dto?.personalizationFeeStatus
			&& dto.personalizationFeeStatus === PAYMENT_STATUS_CODES.WAITING ? true : false;
		this.isPersonalizationMethodByBank = this.personalizationFeeMethodId === PAYMENT_METHODS.BANK ? true : false;
		this.isPersonalizationMethodByEPay = this.personalizationFeeMethodId === PAYMENT_METHODS.E_PAY ? true : false;
		this.isPersonalizationMethodByEasyPay = this.personalizationFeeMethodId === PAYMENT_METHODS.EASY_PAY ? true : false;
	}

}
