import { PAYMENT_STATUS_CODES } from './constants/payment-status-codes';
import { PaymentShortDto } from './../interfaces/payment-short-dto';

export class PaymentShort {
	id: number;
	paymentStatusCode: string;
	paymentTypeKey: string;

	constructor(private readonly dto: PaymentShortDto) {
		this.id = dto ? this.dto.id : NaN;
		this.paymentStatusCode = dto ? this.dto.paymentStatusCode : null;
		this.paymentTypeKey = dto ? this.dto.paymentTypeKey : null;
	}

	getStatusValueBg(): string {
		switch (this.paymentStatusCode) {
			case PAYMENT_STATUS_CODES.WAITING: {
				return 'очаква плащане';
			}
			case PAYMENT_STATUS_CODES.PAID: {
				return 'платено';
			}
			case PAYMENT_STATUS_CODES.DENIED: {
				return 'отхвърлено';
			}
			case PAYMENT_STATUS_CODES.EXPIRED: {
				return 'изтекло';
			}
			case PAYMENT_STATUS_CODES.ERROR: {
				return 'грешка';
			}
			default: {
				break;
			}
		}
	}
}

