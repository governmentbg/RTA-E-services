import { PaymentTaxesViewDto } from '../interfaces/payment-taxes-view-dto';

export class PaymentTaxesView {
	processingFee: number;
	deliveryFee: number;
	personalizationFee: number;

	constructor(dto: PaymentTaxesViewDto) {
		this.processingFee = dto?.processingFee ? dto.processingFee : NaN;
		this.personalizationFee = dto?.personalizationFee ? dto.personalizationFee : NaN;
		this.deliveryFee = dto?.deliveryFee ? dto.deliveryFee : NaN;
	}
}
