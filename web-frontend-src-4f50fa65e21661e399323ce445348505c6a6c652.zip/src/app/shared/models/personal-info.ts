import { Names } from './names';
import { Address } from './address';
import { Translation } from './translation';
import { PersonalInfoDto } from '../dtos/personal-info-form-dto';
import { Utils } from '../utils/utils';

export class PersonalInfo {
	applicationId: number;
	currentAddress: Address;
	dateOfBirth: Date;
	dateOfExpiry: Date;
	dateOfIssue: Date;
	documentIssuer: Translation;
	documentNumber: string;
	documentType: string;
	gender: Translation;
	hasChangedNames: boolean;
	identityDocumentType: Translation;
	identityNumber: string;
	isAuthorizedPerson: boolean;
	nationality: Translation;
	permanentAddress: Address;
	personalNames: Names;
	placeOfBirth: string;
	placeOfBirthLatin: string;
	isEditing: boolean;
	hasGraoCheck: boolean;
	currentAddressSameAsPermanent: boolean;
	// APPROVER
	differences: number;
	dateOfBirthError: boolean;
	dateOfExpiryError: boolean;
	dateOfIssueError: boolean;
	documentIssuerError: boolean;
	documentNumberError: boolean;
	genderError: boolean;
	identityNumberError: boolean;
	nationalityError: boolean;

	constructor(dto: PersonalInfoDto) {
		if (dto != null) {
			this.applicationId = dto.applicationId;
			this.personalNames = new Names(dto.namesDto);
			this.identityNumber = dto.identityNumber;
			this.nationality = new Translation(dto.nationality);
			this.documentNumber = dto.documentNumber;
			this.documentIssuer = new Translation(dto.documentIssuer);
			this.dateOfExpiry = new Date(dto.dateOfExpiry);
			this.dateOfIssue = new Date(dto.dateOfIssue);
			this.isAuthorizedPerson = dto.isAuthorizedPerson;
			this.placeOfBirth = dto.placeOfBirth;
			this.placeOfBirthLatin = dto.placeOfBirthLatin;
			this.dateOfBirth = new Date(dto.dateOfBirth);
			this.identityDocumentType = new Translation(dto.identityDocumentType);
			this.gender = dto?.gender ? new Translation(dto.gender) : null;
			this.isEditing = dto.isEditing;
			this.hasChangedNames = dto?.changedNames ? dto.changedNames : false;
			this.hasGraoCheck = dto?.hasGraoCheck ? dto.hasGraoCheck : false;

			this.permanentAddress = dto?.permanentAddressDto ? new Address(dto.permanentAddressDto) : null;
			this.currentAddressSameAsPermanent = dto?.currentAddressSameAsPermanent 
				? dto.currentAddressSameAsPermanent : false;
			if (dto.currentAddressDto !== null) {
				this.currentAddress = new Address(dto.currentAddressDto);
			} 
		}
	}

	convertToPersonalInfoDto(): PersonalInfoDto {
		const personalInfoFormDto = new PersonalInfoDto();
		personalInfoFormDto.namesDto = this.personalNames;
		personalInfoFormDto.changedNames = this.hasChangedNames;
		personalInfoFormDto.dateOfBirth = Utils.convertDateToStringFormatted(new Date(this.dateOfBirth));
		personalInfoFormDto.dateOfExpiry = Utils.convertDateToStringFormatted(new Date(this.dateOfExpiry));
		personalInfoFormDto.dateOfIssue = Utils.convertDateToStringFormatted(new Date(this.dateOfIssue));
		personalInfoFormDto.documentIssuer = this.documentIssuer;
		personalInfoFormDto.documentNumber = this.documentNumber;
		personalInfoFormDto.identityNumber = this.identityNumber;
		personalInfoFormDto.isAuthorizedPerson = this.isAuthorizedPerson;
		personalInfoFormDto.nationality = this.nationality;
		personalInfoFormDto.placeOfBirth = this.placeOfBirth;
		personalInfoFormDto.placeOfBirthLatin = this.placeOfBirthLatin;
		personalInfoFormDto.identityDocumentType = this.identityDocumentType;

		personalInfoFormDto.currentAddressSameAsPermanent = this.currentAddressSameAsPermanent;
		personalInfoFormDto.permanentAddressDto = this.permanentAddress.convertToAddressDto();
		
		if (this.currentAddress) {
			personalInfoFormDto.currentAddressDto = this.currentAddress.convertToAddressDto();
		}

		if (this.gender) {
			personalInfoFormDto.gender = this.gender;
		}

		return personalInfoFormDto;
	}
}
