import { PhoneNumberDto } from '../interfaces/phone-number-dto';

export class PhoneNumber {
	countryCodeId: number;
	phoneNumber: string;

	constructor(dto: PhoneNumberDto) {
		this.countryCodeId = dto ? dto.countryCodeId : null;
		this.phoneNumber = dto ? dto.phoneNumber : '';
	}
}
