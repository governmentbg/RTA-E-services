import { PopUpTypes } from '../enums/pop-up-types';

export class PopUp {
	header: string;
	subHeader: string;
	text: string;
	type: PopUpTypes;
	// tslint:disable-next-line: no-any
	extraInfo: any;
	date: Date;

	constructor(
		header: string,
		subHeader: string,
		text: string,
		type: PopUpTypes,
		// tslint:disable-next-line: no-any
		extraInfo: any,
		date : Date) {
		this.header = header ? header : '';
		this.subHeader = subHeader ? subHeader : '';
		this.text = text ? text : '',
		this.type = type ? type : null,
		this.extraInfo = extraInfo ? extraInfo : null;
		this.date = date ? date : null;
	}
}
