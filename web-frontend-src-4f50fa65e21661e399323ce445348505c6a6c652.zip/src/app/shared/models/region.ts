import { RegionDto } from '../dtos/region-dto';

export class Region {
	regionCode: string;
	key: string;

	constructor(dto: RegionDto) {
		this.regionCode = dto ? dto.regionCode : '';
		this.key = dto ? dto.key : '';
	}
}
