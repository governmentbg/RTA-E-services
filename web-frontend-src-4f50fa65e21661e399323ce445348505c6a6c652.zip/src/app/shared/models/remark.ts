import { ApplicationRemarkViewDto } from '../interfaces/application-remark-view-dto';

export class Remark {
	message: string;
	remarkKey: string;
	messageTimestamp: Date;

	constructor(dto: ApplicationRemarkViewDto) {
		this.remarkKey = dto?.remarkKey ? dto.remarkKey : null;
		this.messageTimestamp = dto ? new Date(dto.messageTimestamp) : null;
		this.message = dto?.message ? dto.message : null;
	}
}
