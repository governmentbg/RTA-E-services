import { RequiredDocumentTypeDto } from '../interfaces/required-doc-type-dto';

export class RequiredDocumentType {
	id: number;
	type: string;

	constructor(dto: RequiredDocumentTypeDto) {
		this.id = dto ? dto.id : 0;
		this.type = dto ? dto.type : '';
	}
}
