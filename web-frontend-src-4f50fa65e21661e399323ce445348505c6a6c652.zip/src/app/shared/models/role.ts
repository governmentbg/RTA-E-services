import { RoleDto } from "../interfaces/role-dto";
import { Translation } from "./translation";

export class Role extends Translation {
    role: string;

    constructor(dto: RoleDto) {
        super(dto);
        this.role = dto.role;
    }
}