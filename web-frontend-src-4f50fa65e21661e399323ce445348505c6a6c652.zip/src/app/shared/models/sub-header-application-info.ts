export class SubHeaderApplicationInfo {
	applicationId: number;
	applicationProgress: number;
	canCancel: boolean;

	constructor(applicationId: number, applicationProgress: number, canCancel: boolean) {
		this.applicationId = applicationId;
		this.applicationProgress = applicationProgress;
		this.canCancel = canCancel;
	}
}
