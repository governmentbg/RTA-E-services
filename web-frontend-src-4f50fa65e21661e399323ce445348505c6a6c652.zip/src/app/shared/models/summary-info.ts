import { Application } from './application';
import { AUTH_METHOD_ICONS } from './constants/icon-classes/auth-method-icon-class';
import { Names } from './names';
import { PAYMENT_STATUS_ICONS } from './constants/icon-classes/payment-status-icon-class';
import { Translation } from './translation';

export class SummaryInfo {
	applicationId: number;
	authMethodTranslationKey: string;
	authIconClass: string;
	paymentStatusTranslationKey: string;
	paymentIconClass: string;
	attachedDocuments: Translation[];
	submissionDate: Date;
	namesInCyr: string;
	namesInLat: string;

	constructor(source: Application) {
		this.applicationId = source.summary.shortApplication.applicationId;
		this.authMethodTranslationKey = source.summary.authMethod.key;
		this.authIconClass = AUTH_METHOD_ICONS[source.summary.authMethod.id].icon;
		this.paymentStatusTranslationKey = source.summary.paymentStatus.key;
		this.paymentIconClass = PAYMENT_STATUS_ICONS[source.summary.paymentStatus.id].icon;
		this.submissionDate = source.summary.submissionDate;
		this.setFullNames(source.names);
		this.attachedDocuments = source.summary.attachedDocuments;
	}

	setFullNames(names: Names): void {
		this.namesInCyr = (names.firstNameCyr === null ? '' : names.firstNameCyr)
			+  ' ' + (names.fatherNameCyr === null ? '' : names.fatherNameCyr)
				+ ' ' +  (names.familyNameCyr === null ? '' : names.familyNameCyr);
		this.namesInLat = names.firstNameLat
			+  ' '	+ (names.fatherNameLat === null ? '' : names.fatherNameLat)
				+  ' ' + (names.familyNameLat === null ? '' : names.familyNameLat);
	}
}
