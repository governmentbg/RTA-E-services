import { SummaryDto } from '../interfaces/summary-dto';
import { TranslationDto } from '../interfaces/translation-dto';
import { ApplicationShort } from './application-short';
import { Translation } from './translation';

export class Summary {
	authMethod: Translation;
	paymentStatus: Translation;
	submissionDate: Date;
	shortApplication: ApplicationShort;
	attachedDocuments: Translation[];

	constructor(dto: SummaryDto) {
		this.authMethod = new Translation(dto.authMethod);
		this.paymentStatus = new Translation(dto.paymentStatus);
		this.submissionDate = dto.submissionDate;
		this.shortApplication = new ApplicationShort(dto.shortApplication);
		this.attachedDocuments = dto.attachedDocuments.map((doc: TranslationDto) => new Translation(doc));
	}
}
