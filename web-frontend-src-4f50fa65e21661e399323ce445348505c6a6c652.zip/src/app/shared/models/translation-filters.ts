import { QueryParams } from '../interfaces/query-params';
import { TranslationQueryParams } from 'src/app/modules/dev/translation-key-value/translation-query-params';
import { TranslationKeyValueForm } from 'src/app/modules/dev/translation-key-value/translation-key-value-form';

export class TranslationFilters	implements QueryParams {
	keyTranslation: string;
	bgTranslation: string;
	enTranslation: string;

	currentFilteredKeyTranslation: string = null;
	currentFilteredBgTranslation: string = null;
	currentFilteredEnTranslation: string = null;
	lastLoadedTranslations: TranslationKeyValueForm [] = [];

	selectKey(key: string) {
		this.keyTranslation = key;
	}

	selectBg(bg: string) {
		this.bgTranslation = bg;
	}

	selectEn(en: string) {
		this.enTranslation = en;
	}

	public setLastLoadedTranslations(translations: TranslationKeyValueForm[]): void {
		this.lastLoadedTranslations = translations;
	}

	public updateFilters(): void {
		this.currentFilteredKeyTranslation = this.keyTranslation;
		this.currentFilteredBgTranslation = this.bgTranslation;
		this.currentFilteredEnTranslation = this.enTranslation;
	}

	public resetToCurrentlyFiltered(): void {
		this.keyTranslation = this.currentFilteredKeyTranslation;
		this.bgTranslation = this.currentFilteredBgTranslation;
		this.enTranslation = this.currentFilteredEnTranslation;
	}

	toQueryParamsObject(): TranslationQueryParams {
		return {
			key: this.keyTranslation,
			bg: this.bgTranslation,
			en: this.enTranslation,
		};
	}
}

