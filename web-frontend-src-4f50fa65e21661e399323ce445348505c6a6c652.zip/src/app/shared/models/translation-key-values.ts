import { TranslationKeyValuesDto } from '../interfaces/translation-key-values-dto';

export class TranslationKeyValues {
	translationKey: string;
	bgTranslation: string;
	enTranslation: string;

	constructor(dto: TranslationKeyValuesDto) {
		this.translationKey = dto ? dto.translationKey : '';
		this.bgTranslation = dto ? dto.bgTranslation : '';
		this.enTranslation = dto ? dto.enTranslation : '';
	}
}
