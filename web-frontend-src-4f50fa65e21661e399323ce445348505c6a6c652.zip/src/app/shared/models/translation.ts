import { TranslationDto } from '../interfaces/translation-dto';

export class Translation {
	id: number;
	key: string;

	constructor(dto: TranslationDto) {
		this.id = dto ? dto.id : null;
		this.key = dto ? dto.key : '';
	}
}
