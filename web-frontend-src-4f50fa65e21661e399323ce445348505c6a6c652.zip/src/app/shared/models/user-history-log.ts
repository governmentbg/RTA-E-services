import { UserHistoryLogDto } from "../interfaces/user-history-log-dto";
import { Translation } from "./translation";

export class UserHistoryLog {
    id: number;
    time: Date;
    authenticationMethod: Translation;

    constructor(dto: UserHistoryLogDto) {
        this.id = dto.id;
        this.time = dto.time;
        this.authenticationMethod = new Translation(dto.authenticationMethod);
    }
}