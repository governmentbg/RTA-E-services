import { QueryParams } from "../interfaces/query-params";
import { UserManagementListQueryParams } from "../interfaces/user-management-list-query-params";
import { Role } from "./role";
import { Translation } from "./translation";

export enum UserManagementListFilterSearchTypes {
    IDENTITY_NUMBER = "ЕГН", NAME = "Име"
};

export class UserManagementListFilters implements QueryParams {

    private onResetCallback: () => void = null;

    searchType: UserManagementListFilterSearchTypes = UserManagementListFilterSearchTypes.IDENTITY_NUMBER;
    searchText: string = null;
    role: Role = null;
    authenticationMethod: Translation = null;

    public clearSearchText(): void {
        this.searchText = null;
        if (this.onResetCallback) {
            this.onResetCallback();
        }
    }

    public clearAll(): void {
        this.searchText = null;
        this.role = null;
        this.authenticationMethod = null;
        if (this.onResetCallback) {
            this.onResetCallback();
        }
    }

    public setOnResetCallback(callback: () => void): void {
        this.onResetCallback = callback;
    }

    toQueryParamsObject(): UserManagementListQueryParams {
        return {
            name: this.searchType == UserManagementListFilterSearchTypes.NAME 
                && this.searchText && this.searchText !== '' ? this.searchText : null,
            identityNumber: this.searchType == UserManagementListFilterSearchTypes.IDENTITY_NUMBER 
                && this.searchText && this.searchText !== '' ? this.searchText : null,
            role: this.role ? this.role.role : null,
            authenticationMethodId: this.authenticationMethod ? this.authenticationMethod.id : null
        };
    }
}