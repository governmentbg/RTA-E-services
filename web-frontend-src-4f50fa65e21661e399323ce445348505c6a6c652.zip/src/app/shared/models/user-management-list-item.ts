import { RoleDto } from "../interfaces/role-dto";
import { UserManagementListItemDto } from "../interfaces/user-management-list-item-dto";
import { Role } from "./role";
import { UserHistoryLog } from "./user-history-log";

export class UserManagementListItem {
    
    id: number;
    identityNumber: string;
    fullName: string;
    email: string;
    lastLogin: UserHistoryLog;
    roles: Role[];

    constructor(dto: UserManagementListItemDto) {
        this.id = dto.id;
        this.identityNumber = dto.identityNumber;
        this.fullName = dto.fullName;
        this.email = dto.email;
        if (dto.roles) {
            this.roles = dto.roles.map((roleDto: RoleDto) => {
                return new Role(roleDto);
            });
        }
        if (dto.lastLogin) {
            this.lastLogin = new UserHistoryLog(dto.lastLogin);
        }
    }
}