import { UserDto } from '../interfaces/user-dto';
import { Roles } from '../enums/roles';
import { ROLES_NUMBER } from '../enums/roles-number';

export class User {
	identityNumber = '';
	identityNumberType = '';
	email = '';
	fullNameCyr = '';
	fullNameLat = '';
	roles: string[] = [];
	isVerified: boolean;
	authMethodKey = '';

	constructor(dto: UserDto) {
		this.identityNumber = dto.identityNumber;
		this.identityNumberType = dto.identityNumberType;
		this.email = dto.email;
		this.fullNameCyr = dto.fullNameCyr;
		this.fullNameLat = dto.fullNameLat;
		this.roles = dto.roles;
		this.isVerified = dto.verified;
		this.authMethodKey = dto.authMethodKey;
	}

	hasAnyRole(...expectedRoles: string[]): boolean {
		let result = false;
		if (expectedRoles && this.roles && this.roles.length > 0) {
			// tslint:disable-next-line: prefer-for-of
			for (let i = 0; i < expectedRoles.length; i++) {
				result = this.roles.includes(expectedRoles[i]);
				if (result) {
					break;
				}
			}
		}
		return result;
	}

	hasRole(expectedRole: string): boolean {
		if (this.roles && this.roles.length > 0 && expectedRole) {
			return this.roles.includes(expectedRole);
		}
		return false;
	}

	isDemaxAdmin(): boolean {
		if (this.hasRole(Roles.ROLE_ADMIN_DEMAX)) {
			return true;
		}
		return false;
	}

	isViewer(): boolean {
		if (this.hasAnyRole(Roles.ROLE_VIEWER)) {
			return true;
		}
		return false;
	}

	isApplicant(): boolean {
		if (this.hasRole(Roles.ROLE_APPLICANT_E_SIGN) || this.hasRole(Roles.ROLE_APPLICANT_E_FACE)) {
			return true;
		}
		return false;
	}

	isEFaceApplicant(): boolean {
		if (this.hasRole(Roles.ROLE_APPLICANT_E_FACE)) {
			return true;
		}
		return false;
	}

	isDeskStaff(): boolean {
		if (this.hasRole(Roles.ROLE_DESK_STAFF)) {
			return true;
		}
		return false;
	}

	isApprover(): boolean {
		if (this.hasRole(Roles.ROLE_APPROVER)) {
			return true;
		}
		return false;
	}

	isPersoCenterDemax(): boolean {
		if (this.hasRole(Roles.ROLE_PERSO_CENTER_DEMAX)) {
			return true;
		}
		return false;
	}

	getRoleId(): number {
		if (this.isDemaxAdmin()) {
			return ROLES_NUMBER.ROLE_ADMIN_DEMAX;
		} else if (this.isViewer()) {
			return ROLES_NUMBER.ROLE_VIEWER;
		} else if (this.isPersoCenterDemax()) {
			return ROLES_NUMBER.ROLE_PERSO_CENTER_DEMAX;
		} else if (this.isApprover()) {
			return ROLES_NUMBER.ROLE_APPROVER;
		}
		return ROLES_NUMBER.ROLE_DESK_STAFF;
	}
}
