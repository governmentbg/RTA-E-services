export class Warning {
	warningVariableInfo: string;
	warningMessageTranslationKey: string;
}
