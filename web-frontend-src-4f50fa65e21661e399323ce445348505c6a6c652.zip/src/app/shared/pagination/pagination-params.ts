import { QueryParams } from '../interfaces/query-params';

export class PaginationParams implements QueryParams {
	static DEFAULT_STATE = {
		page: 1,
		pageSize: 10,
		orderBy: 'id',
		direction: 'desc'
	};
	page: number;
	pageSize: number;
	orderBy: string;
	direction: string;

	constructor(initialState: { orderBy?: string, direction?: string, page?: number, pageSize?: number } = PaginationParams.DEFAULT_STATE) {
		const state = Object.assign({}, PaginationParams.DEFAULT_STATE, initialState);
		this.orderBy = state.orderBy;
		this.direction = state.direction;
		this.page = state.page;
		this.pageSize = state.pageSize;
	}

	toggleOrder() {
		this.direction === 'asc' ? this.direction = 'desc' : this.direction = 'asc';
	}

	toQueryParamsObject(): object {
		return {
			page: this.page,
			pageSize: this.pageSize,
			orderBy: this.orderBy,
			direction: this.direction
		};
	}
}
