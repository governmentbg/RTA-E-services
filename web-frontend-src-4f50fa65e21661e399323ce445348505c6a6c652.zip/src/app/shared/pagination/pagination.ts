import { PaginationParams } from './pagination-params';
import { BehaviorSubject, Subscription } from 'rxjs';

export class Pagination {
	public totalCount = 0;
	public paginationParams: PaginationParams;
	private paginationParamsSubject: BehaviorSubject<PaginationParams>;

	constructor(paginationParams: PaginationParams = new PaginationParams()) {
		this.paginationParams = paginationParams;
		this.paginationParamsSubject = new BehaviorSubject<PaginationParams>(this.paginationParams);
	}

	setTotalCount(totalCount: number): void {
		this.totalCount = totalCount;
	}

	getTotalCount() {
		return this.totalCount;
	}

	goToNextPage(): void {
		if (this.canGoToNextPage()) {
			this.paginationParams.page += 1;
			this.setNextPagingSubject();
		}
	}

	goToPrevPage(): void {
		if (this.canGoToPrevPage()) {
			this.paginationParams.page -= 1;
			this.setNextPagingSubject();
		}
	}

	goToPage(page: number): void {
		this.paginationParams.page = page;
		this.setNextPagingSubject();
	}

	canGoToNextPage() {
		return this.paginationParams.page < this.getTotalPages();
	}

	canGoToPrevPage() {
		return this.paginationParams.page > 1 && this.getTotalPages() > 1;
	}

	getTotalPages() {
		return Math.ceil(this.totalCount / this.paginationParams.pageSize);
	}

	getPageText(): string {
		return 'page ' + this.paginationParams.page + ' of ' + this.getTotalPages();
	}

	resetPage(): void {
		this.paginationParams.page = 1;
	}

	setNextPagingSubject() {
		this.paginationParamsSubject.next(this.paginationParams);
	}

	getPaginationParams(): PaginationParams {
		return this.paginationParams;
	}

	getItemNumberFromIndex(index: number) {
		const itemNumber = (this.paginationParams.page - 1) * this.paginationParams.pageSize + index + 1;
		if (this.paginationParams.direction === 'desc') {
			const itemNumberDesc = this.totalCount - itemNumber + 1;
			if (itemNumberDesc < 1) {
				return 1;
			}
			return itemNumberDesc;
		}
		return itemNumber;
	}

	subscribeToParamsChanges(next: (value: PaginationParams) => void): Subscription {
		return this.paginationParamsSubject.subscribe(next);
	}
}
