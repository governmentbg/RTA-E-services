import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginationFooterComponent } from './components/pagination/pagination-footer/pagination-footer.component';
import { PaginationHeaderComponent } from './components/pagination/pagination-header/pagination-header.component';
import { PagesMenuComponent } from './components/pagination/pages-menu/pages-menu.component';
import { AddressFormComponent } from './components/address-form/address-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PopUpComponent } from './components/pop-up/pop-up.component';
import { TranslationModule } from 'angular-l10n';
import { ApplicationSummaryComponent } from './components/application-summary/application-summary.component';
import { NamesComponent } from './components/names/names.component';
import { ViewerComponent } from './components/viewer/viewer.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { LoaderDirective } from './directives/loader.directive';
import { AutocompleteComponent } from './components/autocomplete/autocomplete.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { RecaptchaModule, RecaptchaSettings, RECAPTCHA_SETTINGS } from 'ng-recaptcha';
import { Environment } from '../../environments/environment';


const globalRecaptchaSettings: RecaptchaSettings = { siteKey: Environment.production
	? '6Lfrp-EZAAAAAABc_MX24KZU429H2VOLkePEDTso' : '6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI' };

@NgModule({
	declarations: [
		ApplicationSummaryComponent,
		PaginationFooterComponent,
		PaginationHeaderComponent,
		PagesMenuComponent,
		PopUpComponent,
		AddressFormComponent,
		PopUpComponent,
		NamesComponent,
		ViewerComponent,
		LoaderDirective,
		AutocompleteComponent,
	],
	exports: [
		ApplicationSummaryComponent,
		PaginationFooterComponent,
		PaginationHeaderComponent,
		PagesMenuComponent,
		AddressFormComponent,
		PopUpComponent,
		NamesComponent,
		ViewerComponent,
		LoaderDirective,
		AutocompleteComponent,
	],
	imports: [
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		TranslationModule,
		PdfViewerModule,
		MatAutocompleteModule,
		RecaptchaModule
	],
	providers: [
		{
			provide: RECAPTCHA_SETTINGS,
			useValue: globalRecaptchaSettings
		}
	]
})
export class SharedModule { }
