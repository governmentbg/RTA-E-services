import { AbstractForm } from 'src/app/shared/models/abstract-form';
import { FormGroup, Validators } from '@angular/forms';
import { AddressDto } from '../dtos/address-dto';
import { Address } from '../models/address';
import { Utils } from './utils';

export class AddressForm extends AbstractForm<AddressDto> {

	constructor() {
		super();
		this.formGroup = this.createFormGroup();
	}

	get country() {
		return this.formGroup.get('country');
	}

	get region() {
		return this.formGroup.get('region');
	}

	get municipality() {
		return this.formGroup.get('municipality');
	}

	get city() {
		return this.formGroup.get('city');
	}

	get postalCode() {
		return this.formGroup.get('postalCode');
	}

	get street() {
		return this.formGroup.get('street');
	}

	get streetNumber() {
		return this.formGroup.get('streetNumber');
	}

	get entrance() {
		return this.formGroup.get('entrance');
	}

	get building() {
		return this.formGroup.get('building');
	}

	get apartment() {
		return this.formGroup.get('apartment');
	}

	setAddressFormInfo(address: Address) {
		this.country.setValue(address?.country);
		this.region.setValue(address?.region);
		this.municipality.setValue(address?.municipality);
		this.city.setValue(address?.city);
		this.postalCode.setValue(address?.postalCode);
		this.street.setValue(address?.street);
		this.streetNumber.setValue(address?.streetNumber);
		this.entrance.setValue(address?.entrance);
		this.building.setValue(address?.building);
		this.apartment.setValue(address?.apartment);
	}

	public setIsAddressValid(): boolean {
		if (this.country.value != '' && this.country.valid) {
			this.municipality.setValue(null);
			this.city.setValue(null);
			this.region.setValue(null);
			this.postalCode.setValue('');
			this.street.setValue('');
			this.streetNumber.setValue('');
			this.building.setValue('');
			this.entrance.setValue('');
			this.apartment.setValue('');

			return true;

		} else if (this.region.valid && this.municipality.valid && this.city.valid && this.postalCode.valid
			&& this.street.valid && this.streetNumber.valid && this.building.valid
				&& this.entrance.valid && this.apartment.valid) {
			this.country.setValue(null);

			return true;
		} 
		
		this.isValid();
		return false;
	}

	private createFormGroup(): FormGroup {
		return this.formBuilder.group({
			country: ['', [
				Validators.required, Validators.min(1)
			]],
			region: ['', [
				Validators.required, Validators.min(1)
			]],
			municipality: ['', [
				Validators.required, Validators.min(1)
			]],
			city: ['', [
				Validators.required, Validators.min(1)
			]],
			postalCode: ['', [
				Validators.minLength(4), Validators.maxLength(4)
			] ],
			street: [''],
			streetNumber: [''],
			entrance: [''],
			building: [''],
			apartment: ['']
		});
	}

	public toRequestDto(): AddressDto {
		if (this.country.value) {
			return {
				countryDto: this.country.value,
				cityDto: null,
				regionDto: null,
				municipalityDto: null,
				postalCode: null,
				street: null,
				streetNumber:  null,
				entrance:  null,
				building: null,
				apartment:  null,
				addressTypeId: null
			};
		} else {
	
			return {
				countryDto:  null,
				cityDto: this.city.value,
				regionDto: this.region.value,
				municipalityDto: this.municipality.value,
				postalCode: this.postalCode.value ? this.postalCode.value : null,
				street: this.street.value,
				streetNumber: this.streetNumber.value,
				entrance: this.entrance.value,
				building: this.building.value,
				apartment: this.apartment.value,
				addressTypeId: null
			};
		}
	}
}
