import * as moment from 'moment';
import { ValidatorFn, AbstractControl, ValidationErrors, FormGroup, Validators } from '@angular/forms';
import { Countries } from '../enums/countries';
import { APPLICATION_TYPE } from '../enums/application-types';

export class CustomValidators {
	static FORMAT_DATE_AND_TIME = 'YYYY-M-D H:m';
	static FORMAT_DATE = 'YYYY-M-D';

	static isPastDate(): ValidatorFn {
		return (control: AbstractControl): ValidationErrors | null => {

			if (control.value == null) {
				return null;
			}

			const controlDate = moment(control.value, CustomValidators.FORMAT_DATE_AND_TIME);
			if (!controlDate.isValid()) {
				return null;
			}

			return controlDate.isBefore(moment()) ? null : {
				dateNotInThePast: {
					'current-date': moment().format(CustomValidators.FORMAT_DATE_AND_TIME),
					'actual-date': controlDate.format(CustomValidators.FORMAT_DATE_AND_TIME)
				}
			};
		};
	}

	static isPastOrPresentDate(): ValidatorFn {
		return (control: AbstractControl): ValidationErrors | null => {

			if (control.value == null) {
				return null;
			}

			const controlDate = moment(control.value, CustomValidators.FORMAT_DATE_AND_TIME);
			if (!controlDate.isValid()) {
				return null;
			}

			return (controlDate.isBefore(moment()) || controlDate.isSame(moment())) ? null : {
				dateIsNotPresentOrPast: {
					'current-date': moment().format(CustomValidators.FORMAT_DATE_AND_TIME),
					'actual-date': controlDate.format(CustomValidators.FORMAT_DATE_AND_TIME)
				}
			};
		};
	}

	static isFutureOrPresentDate(): ValidatorFn {
		return (control: AbstractControl): ValidationErrors | null => {

			if (control.value == null) {
				return null;
			}

			const controlDate = moment(control.value, CustomValidators.FORMAT_DATE);
			if (!controlDate.isValid()) {
				return null;
			}

			return (controlDate.isAfter(moment()) || controlDate.isSame(moment().startOf('day'))) ? null : {
				dateIsNotPresentOrFuture: {
					'current-date': moment().format(CustomValidators.FORMAT_DATE),
					'actual-date': controlDate.format(CustomValidators.FORMAT_DATE)
				}
			};
		};
	}

	static isFutureOrPresentDateOrExpiredLast6Months(): ValidatorFn { // CORONA - temp validation
		return (control: AbstractControl): ValidationErrors | null => {

			if (control.value == null) {
				return null;
			}

			const controlDate = moment(control.value, CustomValidators.FORMAT_DATE);
			if (!controlDate.isValid()) {
				return null;
			}

			const march3rd2020 = moment("11-03-2020").format('DD-MM-YYYY');
			const jan31th2021 = moment("31-01-2022").format('DD-MM-YYYY');
			
			if (controlDate.isBefore(moment()))  { 
				if (controlDate.isBefore(march3rd2020) || controlDate.isAfter(jan31th2021))
				return null;
			} 	
		};
	}

	static confirmEmail(group: FormGroup) {
		const email = group.get('email').value;
		const confirmEmail = group.get('emailConfirmation').value;
		return email === confirmEmail ? null : { emailNotSame: true };
	}

	static genderConditionalValidators(formGroup: FormGroup, applicationTypeId: number): void {
		if (applicationTypeId === APPLICATION_TYPE.APPLICATION_TACHO_CARD) {
			formGroup.get('gender').setValidators([Validators.min(1), Validators.required]);
		}
	}
}
