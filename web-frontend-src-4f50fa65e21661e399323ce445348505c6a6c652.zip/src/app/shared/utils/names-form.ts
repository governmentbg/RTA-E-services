import { AbstractForm } from 'src/app/shared/models/abstract-form';
import { FormGroup, Validators } from '@angular/forms';
import { NamesDto } from '../dtos/names-dto';

export class NamesForm extends AbstractForm<NamesDto> {

	constructor() {
		super();
		this.formGroup = this.createFormGroup();
	}

	get firstNameCyr() {
		return this.formGroup.get('firstNameCyr');
	}

	get fatherNameCyr() {
		return this.formGroup.get('fatherNameCyr');
	}

	get familyNameCyr() {
		return this.formGroup.get('familyNameCyr');
	}

	get firstNameLat() {
		return this.formGroup.get('firstNameLat');
	}

	get fatherNameLat() {
		return this.formGroup.get('fatherNameLat');
	}

	get familyNameLat() {
		return this.formGroup.get('familyNameLat');
	}

	setNamesFromFullNameStrings(fullNameCyr: string, fullNameLat: string) {
		const namesCyr = fullNameCyr.split(' ');
		const namesLat = fullNameLat.split(' ');
		this.firstNameCyr.setValue(namesCyr[0]);
		if (namesCyr.length > 2) {
			this.fatherNameCyr.setValue(namesCyr[1]);
			this.familyNameCyr.setValue(namesCyr[2]);
		} else {
			this.familyNameCyr.setValue(namesCyr[1]);
		}

		this.firstNameLat.setValue(namesLat[0]);
		if (namesLat.length > 2) {
			this.fatherNameLat.setValue(namesLat[1]);
			this.familyNameLat.setValue(namesLat[2]);
		} else {
			this.familyNameLat.setValue(namesLat[1]);
		}
	}

	setNames(names: NamesDto) {
		this.firstNameCyr.setValue(names.firstNameCyr);
		this.firstNameLat.setValue(names.firstNameLat);
		this.familyNameCyr.setValue(names.familyNameCyr);
		this.familyNameLat.setValue(names.familyNameLat);
		this.fatherNameCyr.setValue(names.fatherNameCyr);
		this.fatherNameLat.setValue(names.fatherNameLat);
	}

	private createFormGroup(): FormGroup {
		return this.formBuilder.group({
			firstNameCyr: [null, [
				Validators.minLength(2), Validators.maxLength(255), Validators.pattern('[а-яА-Я]*'), Validators.required
			]],
			fatherNameCyr: [null, [
				Validators.minLength(2), Validators.maxLength(255), Validators.pattern('[а-яА-Я]*')
			]],
			familyNameCyr: [null, [
				Validators.minLength(2), Validators.maxLength(255), Validators.pattern('[а-яА-Я]*'), Validators.required
			]],
			firstNameLat: [null, [
				Validators.minLength(2), Validators.maxLength(255), Validators.pattern('[a-zA-Z]*'), Validators.required
			]],
			fatherNameLat: [null, [
				Validators.minLength(2), Validators.maxLength(255), Validators.pattern('[a-zA-Z]*')
			]],
			familyNameLat: [null, [
				Validators.minLength(2), Validators.maxLength(255), Validators.pattern('[a-zA-Z]*'), Validators.required
			]],
		});
	}

	public toRequestDto(): NamesDto {
		return {
			firstNameCyr: this.firstNameCyr.value,
			fatherNameCyr: this.fatherNameCyr.value,
			familyNameCyr: this.familyNameCyr.value,
			firstNameLat: this.firstNameLat.value,
			fatherNameLat: this.fatherNameLat.value,
			familyNameLat: this.familyNameLat.value,
		};
	}
}
