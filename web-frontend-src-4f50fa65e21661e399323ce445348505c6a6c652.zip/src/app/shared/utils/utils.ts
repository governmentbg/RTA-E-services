import { HttpParams } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { S_VARIABLES } from '../models/constants/s-variables';
import { Injectable } from '@angular/core';
import { QueryParams } from '../interfaces/query-params';
import { AbstractControl, FormControl, FormGroup, FormArray } from '@angular/forms';
import * as moment from 'moment';
import { POP_UP_MESSAGES_KEYS } from '../models/constants/pop-up-messages-keys';
import { DOCUMENT_TYPES_WITH_BG_NATIONALITY, DOCUMENT_TYPE_FOR_CHECK_IN_MVR_VERSION_3 } from '../enums/idenity-document-types';
import { Countries } from '../enums/countries';

@Injectable({ providedIn: 'root' })
export class Utils {
	private static MONTH_INDICATOR_FOR_21ST_CENTURY_EGN_BEFORE_NOVEMBER = '4';
	private static MONTH_INDICATOR_FOR_21ST_CENTURY_EGN_AFTER_NOVEMBER = '5';
	private static BEGINNING_OF_YEAR_IN_21ST_CENTURY = '20';
	private static BEGINNING_OF_YEAR_IN_20TH_CENTURY = '19';
	private static BEGINNING_OF_MONTH_BEFORE_NOVEMBER = '0';
	private static BEGINNING_OF_MONTH_AFTER_NOVEMBER = '1';

	public constructor(private readonly datePipe: DatePipe) { }

	static toHttpParams(...queryParams: QueryParams[]): HttpParams {
		const paramsObject = Object.assign.apply({}, queryParams.map((queryParam) => {
			return queryParam.toQueryParamsObject();
		}));
		let params = new HttpParams(paramsObject);
		for (const key of Object.keys(paramsObject)) {
			const element = paramsObject[key];
			if (element !== null && element !== undefined && element !== '') {
				params = params.append(key, element);
			}
		}
		return params;
	}

	static markAbstractControlAsTouched(abstractControl: AbstractControl) {
		if (abstractControl instanceof FormControl) {
			abstractControl.markAsTouched({ onlySelf: true });
		} else if (abstractControl instanceof FormGroup) {
			Object.keys(abstractControl.controls).forEach(key => {
				const control = abstractControl.get(key);
				if (control instanceof FormControl) {
					control.markAsTouched({ onlySelf: true });
				} else {
					this.markAbstractControlAsTouched(control);
				}
			});
		} else if (abstractControl instanceof FormArray) {
			abstractControl.controls.forEach(control => {
				if (control instanceof FormControl) {
					control.markAsTouched({ onlySelf: true });
				} else {
					this.markAbstractControlAsTouched(control);
				}
			});
		}
	}

	static convertDateToStringFormatted(date: Date): string {
		const day = ('0' + date.getDate()).slice(-2);
		const month = ('0' + (date.getMonth() + 1)).slice(-2);
		const year = date.getFullYear();
		return year + '-' + month + '-' + day;
	}

	public toHttpParamsWithDate(pageParams: object, searchParams: object): HttpParams {
		let params = new HttpParams();
		Object.entries(pageParams).concat(Object.entries(searchParams)).forEach(([key, value]) => {
			if (value) {
				params = (value instanceof Date)
					? params.append(key, this.datePipe.transform(value, S_VARIABLES.URL_DATE_FORMAT))
					: params.append(key, value);
			}
		});

		return params;
	}

	static getTachoNetExceptionMessage(errorMsg: string): string {
		if (errorMsg.includes('request not valid')) {
			return POP_UP_MESSAGES_KEYS.tachonet_request_not_valid;
		} else if (errorMsg.includes('Person')) {
			return POP_UP_MESSAGES_KEYS.tachonet_person_not_found;
		} else if (errorMsg.includes('card was not found')) {
			return POP_UP_MESSAGES_KEYS.tachonet_card_not_found;
		} else if (errorMsg.includes('New Tacho card')) {
			return POP_UP_MESSAGES_KEYS.tachonet_new_card_not_allowed;
		} else if (errorMsg.includes('renewal')) {
			return POP_UP_MESSAGES_KEYS.tachonet_renewal_not_allowed;
		} else if (errorMsg.includes('replacement')) {
			return POP_UP_MESSAGES_KEYS.tachonet_replacement_not_allowed
		} else {
			return errorMsg;
		}
	} 

	static formatString(string: string, ...args): string {
		for (let i = 0; i < args.length; i++) {
            string = string.replace(new RegExp("\\{" + i + "\\}", "gi"), args[i]);
		}
		return string;
	}

	static extractDateOBirthFromEgn(identityNumber: string): Date {
		let year = identityNumber.substring(0, 2);
		let month = identityNumber.substring(2, 4);
		const day = identityNumber.substring(4, 6);
		if (month.startsWith(this.MONTH_INDICATOR_FOR_21ST_CENTURY_EGN_BEFORE_NOVEMBER)) {
			year = this.BEGINNING_OF_YEAR_IN_21ST_CENTURY + year;
			month = this.BEGINNING_OF_MONTH_BEFORE_NOVEMBER + month.substring(1);
		} else if (month.startsWith(this.MONTH_INDICATOR_FOR_21ST_CENTURY_EGN_AFTER_NOVEMBER)) {
			year = this.BEGINNING_OF_YEAR_IN_21ST_CENTURY + year;
			month = this.BEGINNING_OF_MONTH_AFTER_NOVEMBER + month.substring(1);
		} else {
			year = this.BEGINNING_OF_YEAR_IN_20TH_CENTURY + year;
		}
		const fullDate = `${day}/${month}/${year}`;
		const dateMomentObject = moment(fullDate, 'DD/MM/YYYY');
		return dateMomentObject.toDate();
	}

	static isValidEgn(egn: string): boolean {
		const weightsEgn = [2, 4, 8, 5, 10, 9, 7, 3, 6];
		let year: number;
		let month: number;
		let day: number;
		let sum = 0;

		if (egn === null) {
			return false;
		}

		if (egn.length !== 10) {
			return false;
		}

		if (!this.containsOnlyNumbers(egn)) {
			return false;
		}

		year = Number(egn.charAt(0) + egn.charAt(1));
		if (Number(egn.charAt(2)) === 0) {
			month = Number(egn.charAt(3));
		} else {
			month = Number(egn.charAt(2) + egn.charAt(3));
		}

		if (Number(egn.charAt(4)) === 0) {
			day = Number(egn.charAt(5));
		} else {
			day = Number(egn.charAt(4) + egn.charAt(5));
		}

		if (month >= 1 && month <= 12) {
			year += 1900;
		} else if (month >= 21 && month <= 32) {
			year += 1800;
			month -= 20;
		} else if (month >= 41 && month <= 52) {
			year += 2000;
			month -= 40;
		} else {
			return false;
		}

		for (let i = 0; i < egn.length - 1; i++) {
			sum += Number(egn.charAt(i)) * weightsEgn[i];
		}

		const m = sum % 11;

		if (m === 10 && Number(egn.charAt(9)) === 0) {
			return true;
		} else if (m === Number(egn.charAt(9))) {
			return true;
		} else {
			return false;
		}
	}

	public static containsOnlyNumbers(str: string): boolean {
		// It can't contain only numbers if it's null or empty...
		if (str == null || str.length === 0) {
			return false;
		}
		for (let i = 0; i < str.length; i++) {
			// If we find a non-digit character return false.
			if (isNaN(Number(str.charAt(i)))) {
				return false;
			}
		}
		return true;
	}

	public static checkCanMvrReturnPersonalInfo(documentNumber: string): boolean {
		return documentNumber.startsWith('1') || documentNumber.startsWith('6');
	}

	public static checkCanMvrReturnInfoForDL(documentNumber: string): boolean {
		return documentNumber.startsWith('28');
	}

	public static checkCanMvrReturnPersonalInfoBasedOnDocumentType(documentTypeId: number): boolean {
		return DOCUMENT_TYPE_FOR_CHECK_IN_MVR_VERSION_3.includes(documentTypeId);
	}

	public static checkIsBulgarian(nationalityId: number): boolean {
		return nationalityId === Countries.BULGARIA_ID;
	}

	public static canBeBgBasedOnDocType(docTypeId: number): boolean {
		return DOCUMENT_TYPES_WITH_BG_NATIONALITY.includes(docTypeId);
	}
}

