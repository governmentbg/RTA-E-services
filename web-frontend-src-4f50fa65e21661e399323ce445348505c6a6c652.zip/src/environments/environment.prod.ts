export const Environment = {
	production: true,
	dev: false
};
